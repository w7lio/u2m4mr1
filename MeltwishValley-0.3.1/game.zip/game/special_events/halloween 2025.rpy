label select_halloween_event:
    $ hide_screens()
    scene 1_halloween_select with dissolve
    menu:
        "Сначала":
            jump halloween_prestart
        "Сон с Соней":
            $ restart_scene = True
            scene black with dissolve
            jump halloween_sonya_dream
        "Сон с Маей":
            $ restart_scene = True
            scene black with dissolve
            jump halloween_maya_dream
        "Сон с Кейт":
            $ restart_scene = True
            scene black with dissolve
            jump halloween_kate_dream
        "Уйти":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label halloween_prestart:
    $ hide_screens()

    scene 1_halloween_3_pump with dissolve
    gg "Хм . . ."
    gg "А что это еще такое?"
    gg "Эта тыква будто манит меня дотронуться до нее"
    scene 2_halloween_3_pump with dissolve
    gg "Вроде ничего не случилось"
    gg "Просто обычная тыква"
    gg "Так не интересно"
    play sound feelbadpumpkin
    $ renpy.pause(delay=3.5, hard=True)
    scene 3_halloween_3_pump
    gg "Ай!" with hpunch
    gg "Почему так щипет"
    gg "Что то мне не хорошо"
    gg "Пойду отдохну"
    scene black with out_eye
    jump halloween_start
    return

label halloween_start:
    $ hide_screens()
    play music main_helloween loop fadein 1 fadeout 1
    scene 1_halloween_1_livingroom with in_eye
    Sonya "[povname]"
    scene 2_halloween_1_livingroom with dissolve
    Sonya "Знаешь, что я поняла?"
    gg "Что пора поспать?"
    scene 3_halloween_1_livingroom with dissolve
    Sonya "Что пора украшать дом"
    scene 4_halloween_1_livingroom with dissolve
    gg "Украшать?"
    scene 5_halloween_1_livingroom with dissolve
    Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    scene 6_halloween_1_livingroom with dissolve
    Sonya "Я хочу, чтобы всё выглядело"
    scene 7_halloween_1_livingroom with dissolve
    Sonya "Хотя бы немного празднично"
    scene 8_halloween_1_livingroom with dissolve
    Maya "Украшать?{w} Пора бы да"
    scene 9_halloween_1_livingroom with dissolve
    Maya "Можно повесить гирлянды и поставить свечи!"
    scene 10_halloween_1_livingroom with dissolve
    Sonya "Вот. Поддержка есть"
    scene 11_halloween_1_livingroom with dissolve
    gg "Видимо у меня нет выбора"
    scene 12_halloween_1_livingroom with dissolve
    Maya "Ты просто устал, тебе нужно отвлечься"
    scene 13_halloween_1_livingroom with dissolve
    Sonya "Вот именно"
    scene 14_halloween_1_livingroom with dissolve
    Sonya "Украшение дома - лучший антистресс"
    scene 15_halloween_1_livingroom with dissolve
    Maya "Тогда решено"
    Maya "Начнём с гостиной"
    scene 16_halloween_1_livingroom with dissolve
    Maya "Я за уют, но без перебора"
    scene 15_halloween_1_livingroom with dissolve
    Sonya "Надо позвать Кейт"
    Sonya "Без неё всё равно не обойдётся"
    scene 17_halloween_1_livingroom with dissolve
    Maya "Я напишу ей"
    Maya "Если не занята, придёт"
    scene 18_halloween_1_livingroom with dissolve
    Sonya "Пойдем поможешь мне"
    scene 19_halloween_1_livingroom with dissolve
    Sonya "У нас в кладовке чего только нету"
    scene 20_halloween_1_livingroom with dissolve
    Sonya "Осторожно, она тяжёлая"
    scene 21_halloween_1_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 22_halloween_1_livingroom with dissolve
    gg "Не волнуйся, я пока справляюсь"
    scene 23_halloween_1_livingroom with dissolve
    Maya "Написала, сказала, что уже бежит"
    scene 24_halloween_1_livingroom with dissolve
    Sonya "Это хорошо"
    scene 25_halloween_1_livingroom with dissolve
    Maya "О, смотри, старая паутина!"
    scene 26_halloween_1_livingroom with dissolve
    Sonya "Это не декор, не трогай!"
    scene 27_halloween_1_livingroom with dissolve
    Maya "Ты же знаешь я боюсь пауков!"
    gg "Ха ха"
    scene 28_halloween_1_livingroom with dissolve
    play sound closedoor 
    $ renpy.pause(delay=0.5, hard=True)
    scene 29_halloween_1_livingroom with dissolve
    Kate "Я пришла"
    Kate "Где вы, мои маленькие смертные?"
    Maya "Привет!"
    scene 30_halloween_1_livingroom with dissolve
    Kate "О, вы уже начали без меня?{w} Это предательство"
    scene 31_halloween_1_livingroom with dissolve
    Maya "Мы только подготовились"
    scene 32_halloween_1_livingroom with dissolve
    Sonya "Отлично, теперь можем начинать по-настоящему"
    scene 33_halloween_1_livingroom with dissolve
    Maya "Всё, распределяем задачи?"
    scene 34_halloween_1_livingroom with dissolve
    Kate "Так эту куклу повесим вон там, над теликом"
    Kate "Еще нужны паутины, гирлянда из флажков, черепа . . ."
    scene 35_halloween_1_livingroom with dissolve
    Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    scene 36_halloween_1_livingroom with dissolve
    gg "Ну это же Хэллоуин, а чем ты?"
    scene 37_halloween_1_livingroom with dissolve
    Sonya "Мая просто трусишка"
    scene 38_halloween_1_livingroom with dissolve
    Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "Можно сделать дом тёплым, как осень!"
    Maya "Листья и природу . . . И без жути . . ."
    scene 39_halloween_1_livingroom with dissolve
    Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    scene 40_halloween_1_livingroom with dissolve
    Sonya "Звучит как цель"
    scene 41_halloween_1_livingroom with dissolve
    Maya "Надеюсь, что все пройдет без происшествий"
    scene 42_halloween_1_livingroom with dissolve
    gg "Ну что же, давайте постараемся"
    scene halloween_1_livingroom1 with dissolve
    pause
    scene halloween_1_livingroom2 with dissolve
    pause
    scene halloween_1_livingroom3 with dissolve
    pause
    scene 43_halloween_1_livingroom with dissolve
    Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    scene 44_halloween_1_livingroom with dissolve
    Kate "ДА! Вышло супер, мы такие молодцы"
    scene 45_halloween_1_livingroom with dissolve
    Sonya "Давайте дальше украсим кухню!"
    Sonya "[povname] хватай коробки с украшениями!"
    scene black with out_eye
    play sound faststeps 
    $ renpy.pause(delay=1.5, hard=True)
    scene 1_halloween_1_kitchen with in_eye
    $ renpy.pause(delay=1, hard=True)
    scene 2_halloween_1_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 3_halloween_1_kitchen with dissolve
    Maya "Ну почему я должна ее вешать?"
    scene 4_halloween_1_kitchen with dissolve
    Kate "Потому что ты самая высокая, это же логично!"
    scene 5_halloween_1_kitchen with dissolve
    Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    scene 6_halloween_1_kitchen with dissolve
    gg "Тыкву тоже поставь на полку"
    scene 7_halloween_1_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 8_halloween_1_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 9_halloween_1_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound fall
    scene 10_halloween_1_kitchen with dissolve
    Maya "АААААААААА!" with hpunch
    scene 11_halloween_1_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 12_halloween_1_kitchen with dissolve
    gg "Все, я убрал, не бойся, он же не настоящий"
    scene 13_halloween_1_kitchen with dissolve
    Maya "Спасибо"
    scene 14_halloween_1_kitchen with dissolve
    gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    scene 15_halloween_1_kitchen with dissolve
    Maya "Еще чего!"
    Maya "Ты просто мешаешься на пути, вот и все!"
    Kate "Не поранились? Голубки"
    scene 16_halloween_1_kitchen with dissolve
    Maya "Все с паутиной мы закончили"
    Maya "Пойду возьму яблочного сидра"
    scene 17_halloween_1_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 18_halloween_1_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 19_halloween_1_kitchen with dissolve
    Sonya "Еще 5 минут и кексы готовы"
    scene 20_halloween_1_kitchen with dissolve
    Kate "Пахнет потрясающе"
    scene 21_halloween_1_kitchen with dissolve
    Maya "Всё, теперь осталось только подождать"
    Maya "Потом будем украшать"
    scene 22_halloween_1_kitchen with dissolve
    Kate "Эй а кем вы будете в ночь Хэллоуина?"
    scene 23_halloween_1_kitchen with dissolve
    Sonya "Я уже думала об этом!"
    Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    scene 24_halloween_1_kitchen with dissolve
    Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    scene 25_halloween_1_kitchen with dissolve
    Kate "Эй!! Неплохая идея"
    scene 26_halloween_1_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 27_halloween_1_kitchen with dissolve
    Kate "Королева демонов Уахахахаха!"
    Kate "Все должны пасть к моим ногам!"
    scene 28_halloween_1_kitchen with dissolve
    Sonya "Все, ей больше не наливать!"
    scene 29_halloween_1_kitchen with dissolve
    gg "Не знал что Кейт так быстро выносит с алкоголя"
    scene 30_halloween_1_kitchen with dissolve
    Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    scene 31_halloween_1_kitchen with dissolve
    Kate "Думаю тебе пойдет"
    scene 32_halloween_1_kitchen with dissolve
    Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    scene 33_halloween_1_kitchen with dissolve
    Maya "Ты как раз самая старшая"
    scene 34_halloween_1_kitchen with dissolve
    Sonya "Ах ты!"
    scene 35_halloween_1_kitchen with dissolve
    Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "Например дракончика или мистер тыковка . . ."
    scene 36_halloween_1_kitchen with dissolve
    Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    scene 37_halloween_1_kitchen with dissolve
    Maya "Что ты . . . {w}Он любит переодевашки"
    play sound microwaveclick
    scene 38_halloween_1_kitchen with dissolve
    Sonya "Вот и кексы готовы"
    scene 39_halloween_1_kitchen with dissolve
    gg "С кухней готово, что дальше?"
    Sonya "Предлагаю разделиться"
    Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "[povname], будешь помогать нам?"
    gg "Окей"
    scene black with out_eye
    jump halloween_prepare_mayaroom
    return

label halloween_prepare_mayaroom:
    $ hide_screens()

    scene 1_halloween_1_mroom with in_eye
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_halloween_1_mroom with dissolve
    gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "Мм. . . пахнет приятно"
    scene 3_halloween_1_mroom with dissolve
    Maya "Хватит нюхать женскую комнату!"
    scene 4_halloween_1_mroom with dissolve
    Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "Поставь эти тыквы в тот угол!"
    scene 5_halloween_1_mroom with dissolve
    gg "А где пожалуйста?"
    scene 6_halloween_1_mroom with dissolve
    Maya "Пожалуйста, не беси меня"
    scene 7_halloween_1_mroom with dissolve
    gg "Ох"
    scene 8_halloween_1_mroom with dissolve
    Maya "Мм. . . нет!"
    scene 9_halloween_1_mroom with dissolve
    Maya "Выглядит недостаточно хорошо!"
    scene 10_halloween_1_mroom with dissolve
    Maya "Давай лучше в тот угол!"
    scene 11_halloween_1_mroom with dissolve
    gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    scene 12_halloween_1_mroom with dissolve
    Maya "Говорю же туда неси!"
    scene 13_halloween_1_mroom with dissolve
    gg "Точно?"
    gg "Я больше двигать не буду, подумай хорошо"
    scene 14_halloween_1_mroom with dissolve
    Maya "Хотя как сейчас тоже неплохо . . ."
    scene 15_halloween_1_mroom with dissolve
    Maya "Все ты свободен!"
    scene 16_halloween_1_mroom with dissolve
    gg "Спасибо"
    Maya "Если что еще позову"
    scene 17_halloween_1_mroom with dissolve
    Maya "Все Давай, давай, живее!!"
    scene halloween_1_mroom with dissolve
    pause
    scene black with out_eye
    jump halloween_prepare_sonyaroom
    return

label halloween_prepare_sonyaroom:
    $ hide_screens()

    scene halloween_1_sroom with in_eye
    pause
    scene 1_halloween_1_sroom with dissolve
    Sonya "Ой" with hpunch
    scene 2_halloween_1_sroom with dissolve
    Sonya "Добро пожаловать в мою обитель!"
    scene 3_halloween_1_sroom with dissolve
    gg "У тебя в стиле майнкрафта все, очень милая комната"
    scene 4_halloween_1_sroom with dissolve
    Sonya "Да, у меня много игрушек осталось"
    gg "Чем то тебе помочь?"
    scene 5_halloween_1_sroom with dissolve
    Sonya "О можешь пожалуйста разложить остальные блоки"
    scene 6_halloween_1_sroom with dissolve
    gg "Хорошо давай"
    scene 7_halloween_1_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 8_halloween_1_sroom with dissolve
    Sonya "Так это сюда"
    scene 9_halloween_1_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 10_halloween_1_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 11_halloween_1_sroom with dissolve
    Sonya "О забыла я же еще кексов поставила"
    scene black with out_eye
    jump halloween_prepare_bathroom
    return

label halloween_prepare_bathroom:
    $ hide_screens()

    scene 1_halloween_1_bathroom with in_eye
    gg "Тук-Тук, к вам можно?"
    scene 2_halloween_1_bathroom with dissolve
    Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "Но не достаю, вот"
    scene 3_halloween_1_bathroom with dissolve
    Kate "Вот, видишь?"
    scene 4_halloween_1_bathroom with dissolve
    Kate "Хм . . . а если я встану на бортики ванной?"
    scene 5_halloween_1_bathroom with dissolve
    gg "Стой, это не безопасно"
    scene 6_halloween_1_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 7_halloween_1_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound fall
    scene 8_halloween_1_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 9_halloween_1_bathroom with dissolve
    Kate "ААй!" with hpunch
    Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    scene 10_halloween_1_bathroom with dissolve
    gg "Я так испугался за тебя"
    gg "За тобой глаз, да глаз, будь аккуратнее"
    scene 11_halloween_1_bathroom with dissolve
    Kate "Хорошо, я обещаю . . ."
    scene 12_halloween_1_bathroom with dissolve
    Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    scene 13_halloween_1_bathroom with dissolve
    gg "Ты такая легкая"
    scene 14_halloween_1_bathroom with dissolve
    Kate "Спасибо"



    scene black with out_eye
    jump halloween_prepare_myroom
    return

label halloween_prepare_myroom:
    $ hide_screens()

    play music dream_start loop fadein 1 fadeout 1
    scene 2_halloween_1_myroom with in_eye
    gg "Эх устал я помогать всем девочкам, и так спать хотел"
    scene 1_halloween_1_myroom with dissolve
    gg "Думаю посплю часик"
    scene black with out_eye
    jump halloween_sonya_dream
    return

label halloween_sonya_dream:
    $ hide_screens()

    play music dream_start loop fadein 1 fadeout 1
    $ renpy.pause(delay=1, hard=True)
    play sound nailsontable fadeout 0.5
    $ renpy.pause(delay=2, hard=True)
    scene 1_halloween_2_sonya with in_eye
    $ renpy.pause(delay=1, hard=True)
    scene 2_halloween_2_sonya with dissolve
    gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "Это на кухне?"
    scene 3_halloween_2_sonya with dissolve
    gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "На столе - что-то, чего там не было"
    gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg "Что за чёрт . . ."
    gg_chat "Она не выглядит новой"
    gg_chat "Скорее наоборот - как будто ей сотни лет"
    # gg_chat "Я обвожу её взглядом, но в доме тихо, даже холодильник не гудит"
    # gg_chat "Свет над плитой мигает пару раз"
    # gg_chat "Не знаю, почему, но в груди неприятно холодеет"
    scene 4_halloween_2_sonya with dissolve
    gg "Просто кто-то оставил{w} Мая? Соня?"
    gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    play sound caseclick
    scene 5_halloween_2_sonya with dissolve
    gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg "И всё? . . ."
    scene 6_halloween_2_sonya with dissolve
    gg "Ладно, пока возьму себе"
    gg_chat "Я поворачиваю её в пальцах"
    gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    scene 7_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 8_halloween_2_sonya with dissolve
    gg "Где же все?"
    play sound tvon
    $ renpy.pause(delay=1, hard=True)
    scene 9_halloween_2_sonya with dissolve
    play sound tvnoise loop fadeout 1.0
    gg "Чёрт. что за бред телевизор сам включился . . ."
    scene 10_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 11_halloween_2_sonya
    $ renpy.pause(delay=0.1, hard=True)
    scene 10_halloween_2_sonya 
    $ renpy.pause(delay=0.1, hard=True)
    scene 11_halloween_2_sonya
    $ renpy.pause(delay=0.1, hard=True)
    scene 10_halloween_2_sonya 
    $ renpy.pause(delay=0.1, hard=True)
    scene 11_halloween_2_sonya 
    $ renpy.pause(delay=0.1, hard=True)
    scene 10_halloween_2_sonya 
    $ renpy.pause(delay=0.1, hard=True)
    scene 11_halloween_2_sonya
    $ renpy.pause(delay=0.1, hard=True)
    scene 10_halloween_2_sonya 
    $ renpy.pause(delay=0.1, hard=True)
    scene 11_halloween_2_sonya
    $ renpy.pause(delay=0.1, hard=True)
    scene 10_halloween_2_sonya 
    $ renpy.pause(delay=0.1, hard=True)
    scene 11_halloween_2_sonya 
    $ renpy.pause(delay=0.1, hard=True)
    scene 10_halloween_2_sonya 
    $ renpy.pause(delay=0.1, hard=True)
    scene 11_halloween_2_sonya    

    $ renpy.pause(delay=0.5, hard=True)
    scene 12_halloween_2_sonya
    $ renpy.pause(delay=0.5, hard=True)
    scene 13_halloween_2_sonya
    stop sound fadeout 1
    play sound tvon
    gg "Что за бред"
    gg "Нужно проверить остальные комнаты"
    play sound closedoor
    scene 14_halloween_2_sonya with dissolve
    gg "Соня?"
    scene 15_halloween_2_sonya with dissolve
    gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    scene black with out_eye
    scene 16_halloween_2_sonya with in_eye
    gg "Просто показалось . . ."
    gg "Просто тень . . ."
    scene 17_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound lampbroke
    play music dream_start_h loop fadein 1 fadeout 1.0
    scene 18_halloween_2_sonya with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg ". . ."
    scene 19_halloween_2_sonya with dissolve
    Sonya "Как ты посмел меня разбудить!" with hpunch
    scene 20_halloween_2_sonya with dissolve
    gg "Соня, ты . . . {w}ты издеваешься? . . ."
    scene 21_halloween_2_sonya with dissolve
    gg "Это ты? Что это за грёбаные игры? . .  ."
    scene 22_halloween_2_sonya with dissolve
    Sonya "Имя звучит знакомо"
    Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    gg "Прекрати . . ."
    scene 23_halloween_2_sonya with dissolve
    Sonya "Дом теперь мой.{w} Я - его хозяин"
    scene 24_halloween_2_sonya with dissolve
    Sonya "Боишься?"
    gg "Да . . ."
    scene 25_halloween_2_sonya with dissolve
    Sonya "Хорошо"
    scene 26_halloween_2_sonya with dissolve
    Sonya "Страх делает кровь живой"
    scene 27_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 28_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 29_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 30_halloween_2_sonya with dissolve
    Sonya "Ты принёс монету?"
    scene 31_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 32_halloween_2_sonya with dissolve
    gg "Что? . . ."
    scene 33_halloween_2_sonya with dissolve
    Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "Ты впустил меня"
    scene 34_halloween_2_sonya with dissolve
    Sonya "Я не Соня"
    scene 35_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 36_halloween_2_sonya with dissolve
    Sonya "Я та, что носила её лицо"
    Sonya "И теперь ты мой"
    scene 37_halloween_2_sonya with dissolve
    Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    scene 38_halloween_2_sonya with dissolve
    Sonya "А теперь - перестань сопротивляться"
    play sound halloween_sex_sonya loop fadeout 0.1
    scene halloween_2_sonya with dissolve 
    pause
    Sonya "Да . . . вот оно. Жар под кожей. Сок, который ты копил для кого-то другого. Теперь он мой"
    Sonya "Я чувствую . . . как твоя суть отделяется от костей. Как светится . . . и течёт ко мне"
    Sonya "Скоро . . . скоро ты станешь пустым. Лёгким. И будешь спать"
    pause
    play sound halloween_sex_sonya loop fadein 0.1
    scene halloween_2_sonya2 with dissolve 
    pause
    Sonya "Сейчас. Отдай мне последнюю искру. Тот всполох, что зовут экстазом… я приму его как дань"
    stop sound fadeout 1
    scene 39_halloween_2_sonya with dissolve
    Sonya "ДА! Вот . . . пылающая монета твоей души . . . я беру её!"
    $ renpy.pause(delay=0.5, hard=True)
    scene 40_halloween_2_sonya with dissolve
    Sonya "Спи. В твоих снах будет песок. И глаза в темноте . . . мои глаза"
    $ renpy.pause(delay=0.5, hard=True)
    scene 41_halloween_2_sonya with dissolve
    Sonya "Может быть, я позову снова . . . когда проголодаюсь"
    $ renpy.pause(delay=0.5, hard=True)
    scene 42_halloween_2_sonya with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene black with dissolve
    stop music fadeout 1
    $ renpy.pause(delay=2, hard=True)
    if restart_scene:
        play music night loop fadeout 1 fadein 1
        call next_time_dialog
        $ restart_scene = False
        $ renpy.transition(dissolve)
        $ renpy.jump(current_label)
    else:
        jump halloween_maya_dream
    return

label halloween_maya_dream:
    $ hide_screens()

    play music dream_start2 loop fadein 1 fadeout 1
    $ renpy.pause(delay=2, hard=True)
    scene 1_halloween_3_maya with in_eye
    $ renpy.pause(delay=1, hard=True)
    scene 2_halloween_3_maya with dissolve
    gg "Чёрт . . . {w}нет, нет, снова это . . ."
    scene 3_halloween_3_maya with dissolve
    Maya "Эй, спокойно"
    scene 4_halloween_3_maya with dissolve
    Maya "Ты в безопасности"
    gg "Где я? . . ."
    gg "Что . . . что это за место?"
    scene 5_halloween_3_maya with dissolve
    Maya "Мой дом"
    scene 6_halloween_3_maya with dissolve
    gg "Почему . . . я . . . здесь? . . ."
    scene 7_halloween_3_maya with dissolve
    Maya "Потому что ты боялся"
    Maya "И кто-то должен был тебя остановить"
    scene 8_halloween_3_maya with dissolve
    gg "Нет . . .{w} не приближайся"
    gg "Я видел, как это начинается"
    gg "Сначала свет, потом . . ."
    $ renpy.pause(delay=2, hard=True)
    scene 9_halloween_3_maya with dissolve
    Maya "Никто не собирается тебя пугать"
    gg "Это сон?"
    scene 10_halloween_3_maya with dissolve
    Maya "Возможно"
    Maya "Но в этом сне тебе можно не убегать"
    scene 11_halloween_3_maya with dissolve
    Maya "Сядь.{w} Попробуй просто дышать"
    gg "Я . . .{w} не могу"
    scene 12_halloween_3_maya with dissolve
    Maya "Можешь{w}, начни только тихо"
    scene 13_halloween_3_maya with dissolve
    Maya "Ты думал, я кто-то другой, да?"
    scene 14_halloween_3_maya with dissolve
    gg "После всего . . ."
    gg "Я и не знаю, кому верить"
    Maya "Тогда не верь"
    Maya "Просто смотри"
    scene 15_halloween_3_maya with dissolve
    play sound heal
    $ renpy.pause(delay=2, hard=True)
    gg "Чувствуешь?{w} Здесь нет боли"
    scene 16_halloween_3_maya with dissolve
    Maya "Ты дрожишь"
    gg ". . ."
    # ☠️☠️☠️
    scene 17_halloween_3_maya with dissolve
    Maya "Бедный"
    scene 18_halloween_3_maya with dissolve
    Maya "Я давно не видела людей"
    scene 19_halloween_3_maya with dissolve
    Maya "Вот, видишь?{w} Уже лучше"
    gg "Не знаю, что это.{w} Но уже лучше"
    scene 20_halloween_3_maya with dissolve
    Maya "Сейчас кое что тебя поставит на ноги"
    play sound healpotion
    scene 21_halloween_3_maya with dissolve
    Maya "Здесь только травы"
    Maya "Лаванда, мята, немного корицы.{w} Попей"
    scene 22_halloween_3_maya with dissolve
    gg "Что это?"
    Maya "Это магия"
    scene 23_halloween_3_maya with dissolve
    Maya "Лечебное зелье, с небольшим побочным эфектом"
    scene 24_halloween_3_maya with dissolve
    gg "Каким еще эфектом"
    scene 25_halloween_3_maya with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Просто отдохни.{w} Не думай об этом"
    scene 26_halloween_3_maya with dissolve
    gg "А если я снова усну?"
    scene 27_halloween_3_maya with dissolve
    Maya "Тогда пусть этот сон, будет приятным"
    scene black with out_eye
    play sound halloween_sex_maya loop
    scene halloween_2_maya with in_eye
    pause
    Maya "Да . . . вот так . . . Ты так нуждаешься в этом. Я знала"
    gg "Майя . . . Я . . ."
    Maya "Какая прекрасная . . . реакция. Всё для меня?"
    Maya "О-ох . . . Да . . . Вот так"
    Maya "Да-да-да! Вот здесь! Чувствую, как ты пульсируешь!"
    scene 28_halloween_3_maya with dissolve
    Maya "Aaa-ох . . ."
    stop sound fadeout 1
    scene 29_halloween_3_maya with dissolve
    Maya "Идеально . . . Ты был идеален . . . Запомни это . . . Запомни меня . . ."
    $ renpy.pause(delay=0.5, hard=True)
    scene black with out_eye
    stop music fadeout 1
    if restart_scene:
        play music night loop fadeout 1 fadein 1
        call next_time_dialog
        $ restart_scene = False
        $ renpy.transition(dissolve)
        $ renpy.jump(current_label)
    else:
        jump halloween_kate_dream
    return

label halloween_kate_dream:
    $ hide_screens()

    play music dream_start3 loop fadein 1 fadeout 1
    scene 1_kate_1_night_kitchen with in_eye
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 3_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 4_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene halloween_3_kate1 with dissolve
    pause
    gg "Кейт? . . ."
    scene 5_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene halloween_3_kate2 with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Что . . . что происходит?"
    scene 6_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 7_kate_1_night_kitchen with dissolve
    Kate "{sc}{size=*1.2}Ты"
    scene 8_kate_1_night_kitchen with dissolve
    Kate "Вторгся в середину ритуала"
    Kate "Твоё присутствие нарушило поток"
    scene 9_kate_1_night_kitchen with dissolve
    gg "Гх . . . {w}Прости, я не знал . . ."
    scene 10_kate_1_night_kitchen with dissolve
    Kate "Ты не просто услышал. Ты почувствовал зов"
    scene 11_kate_1_night_kitchen with dissolve
    Kate "Иначе ты бы не вошёл"
    scene 12_kate_1_night_kitchen with dissolve
    Kate "Люди носят маски каждый день"
    Kate "Они молятся свету, а в темноте становятся теми, кем боятся быть"
    scene 13_kate_1_night_kitchen with dissolve
    gg "Кейт, пожалуйста . . . остановись"
    scene 14_kate_1_night_kitchen with dissolve
    Kate "Это имя лишь оболочка, которую я носила"
    Kate "Сейчас я — та, кто принимает исповедь. А исповедь требует . . . отдачи"
    scene 15_kate_1_night_kitchen with dissolve
    Kate "Ты боишься. Это хорошо. Страх очищает"
    Kate "Но за страхом . . . всегда прячется желание"
    scene 16_kate_1_night_kitchen with dissolve
    Kate "Мой ритуал требует энергии. Чистой, незамутнённой лицемерием"
    scene 17_kate_1_night_kitchen with dissolve
    Kate "Твой страх — это начало. Но чтобы завершить круг . . . нужно"
    scene 18_kate_1_night_kitchen with dissolve
    Kate "Нечто большее"
    scene 19_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Что ты хочешь? . . . "
    scene 20_kate_1_night_kitchen with dissolve
    Kate "Я хочу ту часть тебя, которая не боится тьмы"
    scene 21_kate_1_night_kitchen with dissolve
    Kate "Которая жаждет её"
    Kate "Это не сердце. Это — пустота, которую ты пытался заполнить ложью"
    scene 22_kate_1_night_kitchen with dissolve
    Kate "Позволь мне заполнить её истиной"
    gg "Гхк . . ."
    gg "Я не могу подвинуться"
    scene 23_kate_1_night_kitchen with dissolve
    Kate "Не сопротивляйся. Это тоже часть ритуала"
    scene 24_kate_1_night_kitchen with dissolve
    Kate "Ты отдаёшь — я принимаю. Так было всегда"
    scene 25_kate_1_night_kitchen with dissolve
    Kate "Видишь? Твоё тело уже понимает. Оно помнит правила"
    scene 26_kate_1_night_kitchen with dissolve
    play fx1 zipsound
    $ renpy.pause(delay=0.2, hard=True)
    scene 27_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=0.2, hard=True)
    scene 28_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=0.2, hard=True)
    scene 29_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=0.2, hard=True)
    scene 30_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 31_kate_1_night_kitchen with dissolve
    Kate "Это дрожь . . . пробуждения"
    play music dream_start3_2 fadein 1 fadeout 1 loop
    scene halloween_3_kate3 with dissolve
    $ renpy.pause(delay=4, hard=True)
    scene halloween_3_kate4 with dissolve
    pause
    play sound kate_helloween_moans1 loop
    scene halloween_3_kate5 with dissolve
    pause
    Kate "Тише. Не мешай"
    Kate "Я только знакомлюсь с тем, что моё"
    pause
    Kate "Ты . . . для этого . . .{w} и пришёл . . ."
    Kate "Чтоб тебя . . . размяли . . .{w} взяли в руки . . ."
    pause
    gg "Агхх . ."
    Kate "Да!"
    Kate "Вот так"
    Kate "Рвись! Кончай!{w} Отдавай это мне"
    stop sound fadeout 0.2
    scene 32_kate_1_night_kitchen with dissolve
    Kate "Ахахаха ха ха"
    scene 33_kate_1_night_kitchen with dissolve
    Kate "Видишь? Даже твой пик — в моей власти"
    Kate "Я решаю когда и как"
    scene 34_kate_1_night_kitchen with dissolve
    Kate "А теперь хватит игр"
    scene 35_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound fall
    scene 36_kate_1_night_kitchen with vpunch
    $ renpy.pause(delay=0.5, hard=True)
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 37_kate_1_night_kitchen with dissolve
    Kate "Всё, время нежностей кончилось"
    # Kate "Теперь ты просто сосуд. А я… буду наполняться"
    scene 38_kate_1_night_kitchen with dissolve
    Kate "Молчи и терпи. Это плата за твой глупый интерес"
    scene 39_kate_1_night_kitchen with dissolve
    Kate "А-ах . . . Так . . . Глубоко . . ."
    play sound kate_helloween_moans2 loop fadein 0.5
    scene halloween_3_kate6 with dissolve
    pause
    Kate "Да . . . Вот так"
    Kate "Отдай мне это.{w} Всю свою подавленную тьму.{w} Всю свою скрытую жажду"
    gg "Я . . . я не могу . . ."
    Kate "Можешь. И ты сделаешь.{w} Сейчас"
    pause
    stop sound fadeout 0.5
    scene 40_kate_1_night_kitchen with dissolve
    Kate "А-ах . . ."
    scene 41_kate_1_night_kitchen with dissolve
    Kate "Ха.."
    scene 42_kate_1_night_kitchen with dissolve
    Kate "Ритуал завершён. Ты отдал достаточно . . . чтобы я продолжила свой путь"
    scene 43_kate_1_night_kitchen with dissolve
    Kate "Ты проснёшься пустым.{w} Безнадёжно пустым. И, может быть, снова выползешь ко мне . . ."
    Kate "Чтобы снова украсть немного этой полноты"
    scene 44_kate_1_night_kitchen with dissolve
    Kate "Хотя бы на мгновение"
    scene 45_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 46_kate_1_night_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene black with out_eye
    $ renpy.pause(delay=1, hard=True)


    stop sound fadeout 1
    stop music fadeout 1
    play music night loop fadeout 1 fadein 1
    if restart_scene:
        $ restart_scene = False
        call next_time_dialog
        $ renpy.transition(dissolve)
        $ renpy.jump(current_label)
    else:
        $ helloween_flag = False
        call next_time_dialog
        call next_time_dialog
        scene bg_myroom_night with in_eye
        $ renpy.pause(delay=1, hard=True)
        gg ". . ."
        gg "Приснится же такое . . ."
        if not(helloween_complete):
            "Тыква хранит воспоминания"
            "Коснись её, чтобы вновь увидеть сцену"
            $ helloween_complete = True
        $ renpy.transition(dissolve)
        $ renpy.jump("myroom")
    return