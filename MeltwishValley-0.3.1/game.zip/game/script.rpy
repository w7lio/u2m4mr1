﻿
label start:
    $ config.menu_include_disabled = True
    $ characters_list = build_characters_list()
    hide screen time_display
    hide screen time_display_button
    hide screen map_icon
    hide screen check_obj
    hide screen rooms_in
    scene black with fade
    stop sound fadeout 2.0
    stop music fadeout 2.0
    $ current_label = "start"
    show screen check_obj
    $ renpy.pause(delay=1.0, hard=True)
    play ambient light_city_ambient fadein 1 fadeout 0.2 loop volume 0.5
    play music mc_everyday fadein 1 fadeout 0.2 loop
    $ povname = renpy.input(_("И как же вас зовут")).strip()
    if not povname:
        $ povname = "Dan"

    python:
        for character in characters_list:
            if character["origname"] == "gg":
                character["name"] = povname

    $ renpy.pause(delay=1.0, hard=True)         
    "Вы уже играли в нашу игру раньше?"
    "Интро содержит важные сюжетные события и знакомство с миром игры"
    "Если пропустить его при первом прохождении, вы рискуете упустить значительную часть истории и контента"
    menu:
        "Начать игру": 
            jump gg_intro
        "Пропустить интро":
            $ tutorialnavagation = True
            $ end_demo = True
            $ end_demo2 = False
            $ tutorialclock = True
            $ first_Morning = False
            $ current_time = time_order[0]
            $ current_time_translate = time_order_translate[0]
            $ current_day = day_order[1]
            $ current_day_translate = day_order_translate[1]
            $ current_day_abb = day_order_abb[1]
            $ day_number += 1
            stop ambient fadeout 0.3
            play music "audio/soundtracks/morning.mp3" fadein 0.5 fadeout 0.5 loop
            jump myroom
    return
