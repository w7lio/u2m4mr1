transform gradientPink:
    shader "horizontal.gradient"
    u_gradient_color_left (1.0000, 0.7529, 0.8510, 1.00)
    u_gradient_color_right (1.0000, 0.5647, 0.7373, 1.00)

transform gradientPlayer:
    shader "horizontal.gradient"
    u_gradient_color_left (0.7961, 0.8392, 0.9216, 1.00)
    u_gradient_color_right (0.9020, 0.8235, 0.9176, 1.00)

transform gradientbluepurple:
    shader "horizontal.gradient"
    u_gradient_color_left (0.5098, 0.6275, 0.8471, 1.00)
    u_gradient_color_right (0.9294, 0.7176, 0.9294, 1.00)

transform gradientPostGirl:
    shader "horizontal.gradient"
    u_gradient_color_left (1.0000, 0.7608, 0.7608, 1.00)
    u_gradient_color_right (0.9961, 0.6627, 0.8392, 1.00)

transform gradientRed:
    shader "horizontal.gradient"
    u_gradient_color_left (0.8392, 0.1176, 0.2667, 1.00)
    u_gradient_color_right (0.8353, 0.3765, 0.4392, 1.00)

transform gradientKate:
    shader "horizontal.gradient"
    u_gradient_color_left (0.9961, 0.8863, 0.4863, 1.00)
    u_gradient_color_right (1.0000, 0.9176, 0.7412, 1.00)

transform gradientWhite:
    shader "horizontal.gradient"
    u_gradient_color_left (1.0000, 1.0000, 1.0000, 1.00) 
    u_gradient_color_right (1.0000, 1.0000, 1.0000, 1.00) 

transform gradientTimeMorning:
    shader "horizontal.gradient"
    u_gradient_color_left (1.0000, 0.8275, 0.2627, 1.00)
    u_gradient_color_right (1.0000, 0.9098, 0.6157, 1.00)

transform gradientTimeDay:
    shader "horizontal.gradient"
    u_gradient_color_left (1.0000, 0.5490, 0.1529, 1.00)
    u_gradient_color_right (1.0000, 0.6941, 0.3882, 1.00)   

transform gradientTimeEvening:
    shader "horizontal.gradient"
    u_gradient_color_left (1.0000, 0.3569, 0.1255, 1.00)
    u_gradient_color_right (1.0000, 0.3882, 0.5216, 1.00)   

transform gradientTimeNight:
    shader "horizontal.gradient"
    u_gradient_color_left (0.4275, 0.2353, 1.0000, 1.00)
    u_gradient_color_right (0.4549, 0.6118, 1.0000, 1.00)

transform gradientTimeShadow:
    shader "horizontal.gradient"
    u_gradient_color_left (0.0, 0.0, 0.0, 0.30)
    u_gradient_color_right (0.0, 0.0, 0.0, 0.30)   
    
transform gradientNarator:
    shader "horizontal.gradient"
    u_gradient_color_left (0.8706, 0.8706, 0.8706, 1.00)
    u_gradient_color_right (0.8706, 0.8706, 0.8706, 1.00)
    
transform gradientAssistent:
    shader "horizontal.gradient"
    u_gradient_color_left (1.0000, 1.0000, 1.0000, 1.00)
    u_gradient_color_right (0.7451, 0.9961, 0.8078, 1.00)

transform gradientDirector:
    shader "horizontal.gradient"
    u_gradient_color_left (1.0000, 1.0000, 1.0000, 1.00)
    u_gradient_color_right (1.0000, 0.7608, 0.7608, 1.00)

transform gradientStranger:
    shader "horizontal.gradient"
    u_gradient_color_left (0.9961, 0.7059, 0.3020, 1.00)
    u_gradient_color_right (1.0000, 0.9490, 0.8392, 1.00)
    