screen devtools_screen():
    frame:
        background "#0000005d"
        yalign 0.5
        xalign 0.05
        vbox:
            hbox:
                vbox:
                    for i in range(len(day_order)):
                        textbutton day_order[i]:
                            action [
                                SetVariable("current_day", day_order[i]),
                                SetVariable("current_day_translate", day_order_translate[i]),
                                SetVariable("current_day_abb", day_order_abb[i]),
                                Jump(current_label)
                            ]
                            text_size 25
                null height 40
                vbox:
                    for i in range(len(time_order)):
                        textbutton time_order[i]:
                            action [
                                SetVariable("current_time", time_order[i]),
                                SetVariable("current_time_translate", time_order_translate[i]),
                                Jump(current_label)
                            ]
                            text_size 25

                textbutton "rooms" action ToggleScreen("side_block") text_size 25
            vbox:
                hbox:
                    bar value VariableValue("Maya_relations_main", 12) style "slider" xmaximum 200 mouse "button_menu" 
                    text "Maya: [Maya_relations_main]" size 25
                hbox:
                    bar value VariableValue("Sonya_relations_main", 7) style "slider"   xmaximum 200 mouse "button_menu"
                    text "Sonya: [Sonya_relations_main]" size 25
                hbox:
                    bar value VariableValue("Kate_relations_main", 1) style "slider"   xmaximum 200 mouse "button_menu"
                    text "Kate: [Kate_relations_main]" size 25
