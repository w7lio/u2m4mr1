# flags
default Sonya_relations_main = 0
default Unlock_Sonya = True
default Maya_relations_main = 0
default Unlock_Maya = True
default Kate_relations_main = 0
default Unlock_Kate = False
default gg_relations_main = 0
default Unlock_gg = True

default selected_char_quest = None
default day_number = 0
default gg_first_morning_mayaroom = False
default first_Morning = True
default restart_scene = False
default helloween_flag = True
default helloween_complete = False
default end_demo2 = True
default tutorialnavagation = False
default tutorialclock = False
default prev_location = "myroom"


default text_color = "#ff5050"
default path = "images/icons/etc/patreon.png"
default mask = "images/icons/etc/patreon button.png"

default morning_tracks = ["audio/soundtracks/morning.mp3", "audio/soundtracks/morning2.mp3", "audio/soundtracks/morning3.mp3"]
default ui_select_sounds = ["audio/ui/UI_Select.mp3", "audio/ui/UI_Select_high.mp3", "audio/ui/UI_Select_low.mp3", "audio/ui/UI_Select_Short.mp3"]
default ui_check_sounds = ["audio/ui/UI_Check.mp3", "audio/ui/UI_Check low pitch.mp3", "audio/ui/UI_Check low pitch L.mp3"]

# settings
define config.default_music_volume = .5
define config.default_sfx_volume = .5
$ config.hw_video = True
default persistent.tutorialplayed = False
default persistent.language = "english"
define config.window = "hide"
default social_icons = [
    {
        "name_soc": "discord",
        "path_idle": "images/icons/etc/discord.png",
        "path_hover": "images/icons/etc/discord_h.png",
        "link": "https://discord.gg/wvkNKZJz3x"
    },
    {
        "name_soc": "X",
        "path_idle": "images/icons/etc/X.png",
        "path_hover": "images/icons/etc/X_h.png",
        "link": "https://x.com/MeltwishValley"
    },
    {
        "name_soc": "tiktok",
        "path_idle": "images/icons/etc/tiktok.png",
        "path_hover": "images/icons/etc/tiktok_h.png",
        "link": "https://tiktok.com/@meltwishdev"
    },
    {
        "name_soc": "bluesky",
        "path_idle": "images/icons/etc/bluesky.png",
        "path_hover": "images/icons/etc/bluesky_h.png",
        "link": "https://bsky.app/profile/meltwishdev.bsky.social"
    },
]
default languages_choice = [
    {
        "lang_text": "Русский",
        "lang_name": "russian",
        "ai": False,
        "font": "fonts/PPPangramSansRounded-Bold.otf"
    },
    {
        "lang_text": "English",
        "lang_name": "english",
        "ai": False,
        "font": "fonts/PPPangramSansRounded-Bold.otf"
    },
    {
        "lang_text": "Français",
        "lang_name": "french",
        "ai": True,
        "font": "fonts/PPPangramSansRounded-Bold.otf"
    },
    {
        "lang_text": "Español",
        "lang_name": "spanish",
        "ai": True,
        "font": "fonts/PPPangramSansRounded-Bold.otf"
    },
    {
        "lang_text": "Português",
        "lang_name": "portugues",
        "ai": True,
        "font": "fonts/PPPangramSansRounded-Bold.otf"
    },
    {
        "lang_text": "中文 (简体)",
        "lang_name": "chinese",
        "ai": True,
        "font": "fonts/MPLUSRounded1c-Bold.ttf"
    },

]

default current_label = None
default hovering_button = False
default hideQuickMenu = False
default dialogue_box_opacity = 0.6

define config.mouse = {
    'default': [ ("images/custom_gui/cursor/idle.png", 1, 15) ],
    'button_menu': [ ("images/custom_gui/cursor/button_menu.png", 1, 15) ],
    'button_obj': [ ("images/custom_gui/cursor/hover_but.png", 1, 15) ],
    'button_dialog': [ ("images/custom_gui/cursor/hover_text.png", 1, 15) ],
}



define time_order = ["morning", "day", "evening", "night"]  # Порядок смены
define time_order_translate = [_("Утро"), _("День"), _("Вечер"), _("Ночь")]  # Порядок смены
default current_time_index = 0  # Начинаем с утра
default current_time = time_order[0]  # Текущее время
default current_time_translate = time_order_translate[0]  # Текущее время

define day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
define day_order_translate = [_("Понедельник"), _("Вторник"), _("Среда"), _("Четверг"), _("Пятница"), _("Суббота"), _("Воскресенье")]  # Порядок смены
define day_order_abb = [_("Пн."), _("Вт."), _("Ср."), _("Чт."), _("Пт."), _("Сб."), _("Вс.")]  # Порядок смены
default current_day_index = 0  # Начинаем с утра
default current_day = day_order[0]  # Текущее время
default current_day_translate = day_order_translate[0]
default current_day_abb = day_order_abb[0]


default location_type = "house"  # Активная группа локаций (дом, улица и т.д.)
default end_demo = False

init python:

    import renpy.store as store

    def cond_not_end_demo():
        return not bool(store.end_demo)

    def cond_end_demo():
        return bool(store.end_demo)

    def kate_special_condition():
        return bool(store.end_demo) and store.gg_relations_main == 1 and store.Kate_relations_main == 0

    def pumpkin_special_condition():
        return store.Maya_relations_main >= 11 and store.Sonya_relations_main >= 3 and bool(store.Unlock_Kate) and bool(store.helloween_flag)

    LOCATIONS = {
        "myroom":   {"title": _("Зал"),         "image": "bg_rooms_mini/bg_myroom_mini.png", "group": "house"},
        "girlroom": {"title": _("Соня"),        "image": "bg_rooms_mini/bg_sonya_mini.png",  "group": "house"},
        "mayaroom": {"title": _("Мая"),         "image": "bg_rooms_mini/bg_maya_mini.png",   "group": "house"},
        "kitchen":  {"title": _("Кухня"),       "image": "bg_rooms_mini/bg_kitchen_mini.png","group": "house"},
        "bathroom": {"title": _("Ванная"),      "image": "bg_rooms_mini/bg_bathroom_mini.png","group": "house"},
    }


    NPCS = {

        "maya": {
            "name": "Мая",
            "icon": "icons/npcrooms/maya.png",
            "icon_special": "icons/npcrooms/mayaspec.png",

            "states": [
                dict(loc="myroom", time="day", days=("Monday", "Thursday"),
                    rel=13, special=True, priority=100),

                dict(loc="girlroom", time="morning", days=("Monday", "Thursday"),
                    rel=12, special=True, priority=100),

                dict(loc="myroom", time="evening", days=("Tuesday", "Friday", "Sunday"),
                    rel=11, special=True, priority=100),

                dict(loc="bathroom", time="morning", days=("Tuesday", "Thursday", "Sunday"),
                    rel=10, special=True, priority=100),

                dict(loc="myroom", time="evening", days=("Wednesday", "Saturday"),
                    rel=9, special=True, priority=100),

                dict(loc="kitchen", time="day", days=("Tuesday", "Friday", "Sunday"),
                    rel=8, special=True, priority=100),

                dict(loc="mayaroom", time="morning", days=("Monday", "Tuesday", "Wednesday", "Thursday"),
                    rel=7, special=True, priority=100),

                dict(loc="mayaroom", time="night", days=("Monday", "Tuesday", "Saturday", "Sunday"),
                    rel=6, special=True, priority=100),

                dict(loc="myroom", time="evening", days=("Friday", "Sunday"),
                    rel=5, special=True, priority=100),

                dict(loc="mayaroom", time="night", days=("Wednesday", "Thursday", "Friday", "Saturday"),
                    rel=4, special=True, priority=100),

                dict(loc="mayaroom", time="morning", days=("Monday", "Thursday", "Sunday"),
                    rel=3, special=True, priority=100),

                dict(loc="kitchen", time="evening", days=("Monday", "Thursday", "Friday"),
                    rel=2, special=True, priority=100),

                dict(loc="mayaroom", time="day", days=("Tuesday", "Wednesday", "Friday", "Saturday"),
                    rel=1, special=True, priority=100),

                dict(loc="myroom", time="evening", days=("Tuesday", "Wednesday", "Sunday"),
                    rel=0, special=True, priority=100),

                dict(loc="mayaroom", time="day", days=("Monday"),
                    rel=0, special=True, priority=110, custom=cond_not_end_demo),


                dict(loc="myroom", time="morning", days=("Saturday"), priority=10, auto_idle=True),
                dict(loc="myroom", time="day", days=("Thursday"), priority=10, auto_idle=True),
                dict(loc="myroom", time="evening", days=("Sunday"), priority=10, auto_idle=True),

                dict(loc="mayaroom", time="morning", days=("Monday","Wednesday","Thursday","Sunday"), priority=10, auto_idle=True),
                dict(loc="mayaroom", time="day", days=("Tuesday","Friday","Saturday"), priority=10, auto_idle=True),
                dict(loc="mayaroom", time="evening", days=("Tuesday","Wednesday","Friday"), priority=10, auto_idle=True),
                dict(loc="mayaroom", time="night", days=("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"), priority=10, auto_idle=True),

                dict(loc="kitchen", time="morning", days=("Friday"), priority=10, auto_idle=True),
                dict(loc="kitchen", time="day", days=("Monday","Sunday"), priority=10, auto_idle=True),
                
                dict(loc="bathroom", time="evening", days=("Monday","Saturday"), priority=10, custom=cond_end_demo, auto_idle=True),
            ]
        },
        "sonya": {
            "name": "Соня",
            "icon": "icons/npcrooms/sonya.png",
            "icon_special": "icons/npcrooms/sonyaspec.png",

            "states": [
                dict(loc="myroom", time="night", days=("Monday", "Friday"),
                    rel=8, special=True, priority=100),

                dict(loc="kitchen", time="morning", days=("Thursday", "Saturday"),
                    rel=7, special=True, priority=100),

                dict(loc="girlroom", time="evening", days=("Thursday", "Sunday"),
                    rel=6, special=True, priority=100),

                dict(loc="myroom", time="evening", days=("Monday", "Thursday"),
                    rel=5, special=True, priority=100),

                dict(loc="bathroom", time="morning", days=("Monday", "Friday"),
                    rel=3, special=True, priority=100),

                dict(loc="bathroom", time="day", days=("Friday", "Saturday"),
                    rel=2, special=True, priority=100),

                dict(loc="girlroom", time="day", days=("Tuesday", "Wednesday", "Saturday"),
                    rel=1, special=True, priority=100),

                dict(loc="kitchen", time="morning", days=("Monday", "Wednesday", "Saturday"),
                    rel=0, special=True, priority=100),

                dict(loc="bathroom", time="evening", days=("Monday"),
                    rel=0, special=True, priority=110, custom=cond_not_end_demo),

                dict(loc="myroom", time="morning", days=("Wednesday"), auto_idle=True),
                dict(loc="myroom", time="day", days=("Tuesday", "Sunday"), auto_idle=True),
                dict(loc="myroom", time="evening", days=("Saturday"), auto_idle=True),

                dict(loc="girlroom", time="morning", days=("Sunday"), auto_idle=True),
                dict(loc="girlroom", time="day", days=("Monday","Thursday","Saturday"), auto_idle=True),
                dict(loc="girlroom", time="evening", days=("Monday","Friday","Sunday"), auto_idle=True),
                dict(loc="girlroom", time="night", days=("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"), priority=10, auto_idle=True),

                dict(loc="kitchen", time="morning", days=("Monday","Saturday"), priority=10, auto_idle=True),
                dict(loc="kitchen", time="day", days=("Friday",), priority=10, auto_idle=True),
                dict(loc="kitchen", time="evening", days=("Wednesday",), priority=10, auto_idle=True),

                dict(loc="bathroom", time="morning", days=("Tuesday","Friday"), priority=10, auto_idle=True),
                dict(loc="bathroom", time="evening", days=("Thursday",), priority=10, auto_idle=True),
            ]
        },
        "kate": {
            "name": "Kate",
            "icon": "icons/npcrooms/kate.png",
            "icon_special": "icons/npcrooms/katespec.png",

            "states": [
                dict(
                    loc="myroom",
                    time="day",
                    days=("Monday"),
                    special=True,
                    priority=100,
                    rel=0,
                    custom=kate_special_condition
                )
            ]
        },
        "special": {
            "name": "Special",
            "icon": "icons/npcrooms/quest.png",
            "icon_special": "icons/npcrooms/questspec.png",

            "states": [
                dict(loc="kitchen", time="morning", days=("Sunday"),
                    special=True, priority=110, custom=pumpkin_special_condition),
            ]
        },
        "pumpkin": {
            "name": "Тыква",
            "icon": "icons/npcrooms/pumpkin.png",
            "icon_special": "icons/npcrooms/pumpkinspec.png",

            "states": [
                dict(
                    loc="mayaroom",
                    time="day",
                    days=("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"),
                    special=True,
                    priority=100,
                    custom=pumpkin_special_condition
                )
            ]
        }
    }


    def get_rel(npc_id):
        return globals().get(f"{npc_id.capitalize()}_relations_main", 0)


    def get_active_npc_states():
        result = {}

        for npc_id, npc in NPCS.items():
            best_state = None
            best_priority = -1

            for s in npc["states"]:
                if current_time != s["time"]:
                    continue
                if current_day not in s["days"]:
                    continue
                if "rel" in s and get_rel(npc_id) != s["rel"]:
                    continue
                if "not_rel" in s and get_rel(npc_id) in s["not_rel"]:
                    continue
                if "custom" in s and not s["custom"]():
                    continue

                pr = s.get("priority", 0)
                if pr > best_priority:
                    best_priority = pr
                    best_state = s

            if not best_state:
                continue

            idle = best_state.get("idle")
            action = best_state.get("action")

            # 🔥 AUTO-IDLE
            if best_state.get("auto_idle"):
                idle = f"{npc_id}_Idle_{best_state['time']}_{best_state['loc']}"
                action = f"{idle}_scene"

            # 🛡 защита
            if idle and not renpy.has_image(idle):
                idle = None
                action = None

            result[npc_id] = {
                "npc_id": npc_id,
                "loc": best_state["loc"],
                "icon": npc["icon_special"] if best_state.get("special") else npc["icon"],
                "special": best_state.get("special", False),
                "idle": idle,
                "action": action,
                # "state": best_state,
            }

        return result

    def get_npcs_for_location(loc):
        all_npcs = get_active_npc_states()
        return [npc for npc in all_npcs.values() if npc["loc"] == loc]

    def get_idle_for_location(loc):
        result = []

        for npc in get_active_npc_states().values():
            if npc["loc"] != loc:
                continue

            # ❌ спец сцена → idle не показываем
            if npc_has_blocking_special(npc["npc_id"], loc):
                continue

            if npc["idle"] and npc["action"]:
                result.append(npc)

        return result

    def npc_has_blocking_special(npc_id, current_loc):
        npc = NPCS[npc_id]

        for s in npc["states"]:
            if not s.get("special"):
                continue
            if current_time != s["time"]:
                continue
            if current_day not in s["days"]:
                continue
            if "custom" in s and not s["custom"]():
                continue
            if "rel" in s and get_rel(npc_id) != s["rel"]:
                continue

            # спец в ДРУГОЙ комнате
            if s["loc"] != current_loc:
                return True

        return False


init python:
    def build_characters_list():
        return [
                {
                "name": povname,
                "origname": "gg",
                "icon_image": "images/icons/mc_icon.png",
                "full_image": "images/setting_videos/nulll.png",  
                "quest_image": "icons/npcrooms/questspec.png",
                "description": _("Спокойный и наблюдательный, он приехал в посёлок, чтобы сбежать от прошлого и найти себя заново. Не всегда уверен, но с каждым новым знакомством делает шаг ближе к тому, кем хочет стать"),
                "age": 25,
                "relations": gg_relations_main,
                "role": _("Союзник"),
                "quest": [
                    {
                        "days": [
                                _("Вс."),
                        ],
                        "time": _("Утро"),
                        "time_gr": "Morning",
                        "description_abb": _("Кухня"),
                        "description": _("Утро Кухня")
                    },
                    {
                        "description_abb": _("Ждем тебя в следующем патче"),
                        "description": _("Вы прошли все сюжетные события этого персонажа в текущем патче")
                    },
                ],
                "gradient": "gradientPlayer",
                "outlines": '[ (1.2, "#8c9ced", 1, 1) ]',
                "outlines_name": '[ (3, "#5f5170", 1, 1) ]'
            },
            {
                "name": _("Мая"),
                "origname": "Maya",
                "icon_image": "images/icons/maya_icon.png",
                "full_image": "big_book_maya",  
                "quest_image": "icons/npcrooms/mayaspec.png",
                "description": _("Дерзкая, ироничная и ленивая, кажется отстранённой, но чувствует глубже, чем показывает. Скрывает мягкость за сарказмом, пока не решит открыть себя по-настоящему. Не терпит слабости — особенно в себе"),
                "age": 25,
                "relations": Maya_relations_main,
                "role": _("Союзник"),
                "quest": [
                    {
                        "days": [
                                _("Вт."),
                                _("Ср."),
                                _("Вс."),
                        ],
                        "time": _("Вечер"),
                        "time_gr": "Evening",
                        "description_abb": _("Зал"),
                        "description": _("Вечер Зал")
                    },
                    {
                        "days": [
                                _("Вт."),
                                _("Ср."),
                                _("Пт."),
                                _("Сб."),
                        ],
                        "time": _("День"),
                        "time_gr": "Day",
                        "description_abb": _("Ее комната"),
                        "description": _("День Ее комната")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Чт."),
                                _("Пт."),
                        ],
                        "time": _("Вечер"),
                        "time_gr": "Evening",
                        "description_abb": _("Кухня"),
                        "description": _("Вечер кухня")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Чт."),
                                _("Вс."),
                        ],
                        "time": _("Утро"),
                        "time_gr": "Morning",
                        "description_abb": _("Ее комната"),
                        "description": _("Утро ее комната")
                    },
                    {
                        "days": [
                                _("Ср."),
                                _("Чт."),
                                _("Пт."),
                                _("Сб."),
                        ],
                        "time": _("Ночь"),
                        "time_gr": "Night",
                        "description_abb": _("Ее комната"),
                        "description": _("Ночь ее комната")
                    },
                    {
                        "days": [
                                _("Пт."),
                                _("Вс."),
                        ],
                        "time": _("Вечер"),
                        "time_gr": "Evening",
                        "description_abb": _("Зал"),
                        "description": _("Вечер зал")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Вт."),
                                _("Сб."),
                                _("Вс."),
                        ],
                        "time": _("Ночь"),
                        "time_gr": "Night",
                        "description_abb": _("Ее комната"),
                        "description": _("Ночь ее комната")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Вт."),
                                _("Ср."),
                                _("Чт."),
                        ],
                        "time": _("Утро"),
                        "time_gr": "Morning",
                        "description_abb": _("Ее комната"),
                        "description": _("Утро ее комната")
                    },
                    {
                        "days": [
                                _("Вт."),
                                _("Пт."),
                                _("Вс."),
                        ],
                        "time": _("День"),
                        "time_gr": "Day",
                        "description_abb": _("Кухня"),
                        "description": _("День кухня")
                    },
                    {
                        "days": [
                                _("Ср."),
                                _("Сб."),
                        ],
                        "time": _("Вечер"),
                        "time_gr": "Evening",
                        "description_abb": _("Зал"),
                        "description": _("Вечер зал")
                    },
                    {
                        "days": [
                                _("Вт."),
                                _("Чт."),
                                _("Вс."),
                        ],
                        "time": _("Утро"),
                        "time_gr": "Morning",
                        "description_abb": _("Ванная"),
                        "description": _("Утро ванная")
                    },
                    {
                        "days": [
                                _("Вт."),
                                _("Пт."),
                                _("Вс."),
                        ],
                        "time": _("Вечер"),
                        "time_gr": "Evening",
                        "description_abb": _("Зал"),
                        "description": _("Вечер зал")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Чт."),
                        ],
                        "time": _("Утро"),
                        "time_gr": "Morning",
                        "description_abb": _("Комната Сони"),
                        "description": _("Утро комната Сони")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Чт."),
                        ],
                        "time": _("День"),
                        "time_gr": "Day",
                        "description_abb": _("Зал"),
                        "description": _("День зал")
                    },
                    {
                        "description_abb": _("Ждем тебя в следующем патче"),
                        "description": _("Вы прошли все сюжетные события этого персонажа в текущем патче")
                    },
                ],
                "gradient": "gradientbluepurple",
                "outlines": '[ (1.2, "#8c9ced", 1, 1) ]',
                "outlines_name": '[ (3, "#7458AD", 1, 1) ]'
            },
            {
                "name": _("Соня"),
                "origname": "Sonya",
                "icon_image": "images/icons/sonya_icon.png",
                "full_image": "big_book_sonya",
                "quest_image": "icons/npcrooms/sonyaspec.png",
                "description": _("Тёплая и заботливая, но собранная и точная, как часы. Любит музыку, игры и порядок, иногда стесняется — но именно она делает шаг первой"),
                "age": 23,
                "relations": Sonya_relations_main,
                "role": _("Союзник"),
                "quest": [
                    {
                        "days": [
                                _("Пн."),
                                _("Ср."),
                                _("Сб."),
                        ],
                        "time": _("Утро"),
                        "time_gr": "Morning",
                        "description_abb": _("Кухня"),  
                        "description": _("Утро Кухня")
                    },
                    {
                        "days": [
                                _("Вт."),
                                _("Ср."),
                                _("Сб."),
                        ],
                        "time": _("День"),
                        "time_gr": "Day",
                        "description_abb": _("Ее комната"),
                        "description": _("День Ее комната")
                    },
                    {
                        "days": [
                                _("Пт."),
                                _("Сб."),
                        ],
                        "time": _("День"),
                        "time_gr": "Day",
                        "description_abb": _("Ванная"),
                        "description": _("День Ванная")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Пт."),
                        ],
                        "time": _("Утро"),
                        "time_gr": "Morning",
                        "description_abb": _("Ванная"),
                        "description": _("Утро Ванная")
                    },
                    {
                        "description_abb": _("Стоит подождать"),
                        "description": _("Думаю стоит подождать")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Чт."),
                        ],
                        "time": _("Вечер"),
                        "time_gr": "Evening",
                        "description_abb": _("Зал"),
                        "description": _("Вечер Зал")
                    },
                    {
                        "days": [
                                _("Чт."),
                                _("Вс."),
                        ],
                        "time": _("Вечер"),
                        "time_gr": "Evening",
                        "description_abb": _("Ее комната"),
                        "description": _("Вечер Ее комната")
                    },
                    {
                        "days": [
                                _("Чт."),
                                _("Сб."),
                        ],
                        "time": _("Утро"),
                        "time_gr": "Morning",
                        "description_abb": _("Кухня"),
                        "description": _("Утро Кухня")
                    },
                    {
                        "days": [
                                _("Пн."),
                                _("Пт."),
                        ],
                        "time": _("Ночь"),
                        "time_gr": "Night",
                        "description_abb": _("Зал"),
                        "description": _("Ночь Зал")
                    },
                    {
                        "description_abb": _("Ждем тебя в следующем патче"),
                        "description": _("Вы прошли все сюжетные события этого персонажа в текущем патче")
                    },
                ],
                "gradient": "gradientPink",
                "outlines": '[ (1.2, "#e288cf", 1, 1) ]',
                "outlines_name": '[ (3, "#af68a0", 1, 1) ]'
            },
            {
                "name": _("Кейт"),
                "origname": "Kate",
                "icon_image": "images/icons/kate_icon.png",
                "icon_image_locked": "images/icons/kate_icon_locked.png",
                "full_image": "big_book_kate",
                "quest_image": "icons/npcrooms/katespec.png",
                "description": _("Яркая и энергичная, Кейт не умеет сидеть на месте — она живёт движением и смехом. Кажется лёгкой и беззаботной, но за её улыбкой прячется страх остаться одной"),
                "age": 23,
                "relations": Kate_relations_main,
                "role": _("Союзник"),
                "quest": [
                    {
                        "days": [
                                _("Пн.")
                        ],
                        "time": _("День"),
                        "time_gr": "Day",
                        "description_abb": _("Зал"),
                        "description": _("День Зал")
                    },
                    {
                        "description_abb": _("Ждем тебя в следующем патче"),
                        "description": _("Вы прошли все сюжетные события этого персонажа в текущем патче")
                    },
                ],
                "gradient": "gradientKate",
                "outlines": '[ (1.2, "#b48203", 1, 1) ]',
                "outlines_name": '[ (3, "#b38000", 1, 1) ]'
            }
        ]

default characters_list = []

# default characters_list = [
#         {
#             "name": povname,
#             "origname": "gg",
#             "icon_image": "images/icons/mc_icon.png",
#             "full_image": "images/setting_videos/nulll.png",  
#             "quest_image": "icons/npcrooms/questspec.png",
#             "description": _("Спокойный и наблюдательный, он приехал в посёлок, чтобы сбежать от прошлого и найти себя заново. Не всегда уверен, но с каждым новым знакомством делает шаг ближе к тому, кем хочет стать"),
#             "age": 25,
#             "relations": gg_relations_main,
#             "role": _("Союзник"),
#             "quest": [
#                 {
#                     "days": [
#                             _("Вс."),
#                     ],
#                     "time": _("Утро"),
#                     "time_gr": "Morning",
#                     "description_abb": _("Кухня"),
#                     "description": _("Утро Кухня")
#                 },
#                 {
#                     "description_abb": _("Ждем тебя в следующем патче"),
#                     "description": _("Вы прошли все сюжетные события этого персонажа в текущем патче")
#                 },
#             ],
#             "gradient": "gradientPlayer",
#             "outlines": '[ (1.2, "#8c9ced", 1, 1) ]',
#             "outlines_name": '[ (3, "#5f5170", 1, 1) ]'
#         },
#         {
#             "name": _("Мая"),
#             "origname": "Maya",
#             "icon_image": "images/icons/maya_icon.png",
#             "full_image": "big_book_maya",  
#             "quest_image": "icons/npcrooms/mayaspec.png",
#             "description": _("Дерзкая, ироничная и ленивая, кажется отстранённой, но чувствует глубже, чем показывает. Скрывает мягкость за сарказмом, пока не решит открыть себя по-настоящему. Не терпит слабости — особенно в себе"),
#             "age": 25,
#             "relations": Maya_relations_main,
#             "role": _("Союзник"),
#             "quest": [
#                 {
#                     "days": [
#                             _("Вт."),
#                             _("Ср."),
#                             _("Вс."),
#                     ],
#                     "time": _("Вечер"),
#                     "time_gr": "Evening",
#                     "description_abb": _("Зал"),
#                     "description": _("Вечер Зал")
#                 },
#                 {
#                     "days": [
#                             _("Вт."),
#                             _("Ср."),
#                             _("Пт."),
#                             _("Сб."),
#                     ],
#                     "time": _("День"),
#                     "time_gr": "Day",
#                     "description_abb": _("Ее комната"),
#                     "description": _("День Ее комната")
#                 },
#                 {
#                     "days": [
#                             _("Пн."),
#                             _("Чт."),
#                             _("Пт."),
#                     ],
#                     "time": _("Вечер"),
#                     "time_gr": "Evening",
#                     "description_abb": _("Кухня"),
#                     "description": _("Вечер кухня")
#                 },
#                 {
#                     "days": [
#                             _("Пн."),
#                             _("Чт."),
#                             _("Вс."),
#                     ],
#                     "time": _("Утро"),
#                     "time_gr": "Morning",
#                     "description_abb": _("Ее комната"),
#                     "description": _("Утро ее комната")
#                 },
#                 {
#                     "days": [
#                             _("Ср."),
#                             _("Чт."),
#                             _("Пт."),
#                             _("Сб."),
#                     ],
#                     "time": _("Ночь"),
#                     "time_gr": "Night",
#                     "description_abb": _("Ее комната"),
#                     "description": _("Ночь ее комната")
#                 },
#                 {
#                     "days": [
#                             _("Пт."),
#                             _("Вс."),
#                     ],
#                     "time": _("Вечер"),
#                     "time_gr": "Evening",
#                     "description_abb": _("Зал"),
#                     "description": _("Вечер зал")
#                 },
#                 {
#                     "days": [
#                             _("Пн."),
#                             _("Вт."),
#                             _("Сб."),
#                             _("Вс."),
#                     ],
#                     "time": _("Ночь"),
#                     "time_gr": "Night",
#                     "description_abb": _("Ее комната"),
#                     "description": _("Ночь ее комната")
#                 },
#                 {
#                     "days": [
#                             _("Пн."),
#                             _("Вт."),
#                             _("Ср."),
#                             _("Чт."),
#                     ],
#                     "time": _("Утро"),
#                     "time_gr": "Morning",
#                     "description_abb": _("Ее комната"),
#                     "description": _("Утро ее комната")
#                 },
#                 {
#                     "days": [
#                             _("Вт."),
#                             _("Пт."),
#                             _("Вс."),
#                     ],
#                     "time": _("День"),
#                     "time_gr": "Day",
#                     "description_abb": _("Кухня"),
#                     "description": _("День кухня")
#                 },
#                 {
#                     "days": [
#                             _("Ср."),
#                             _("Сб."),
#                     ],
#                     "time": _("Вечер"),
#                     "time_gr": "Evening",
#                     "description_abb": _("Зал"),
#                     "description": _("Вечер зал")
#                 },
#                 {
#                     "days": [
#                             _("Вт."),
#                             _("Чт."),
#                             _("Вс."),
#                     ],
#                     "time": _("Утро"),
#                     "time_gr": "Morning",
#                     "description_abb": _("Ванная"),
#                     "description": _("Утро ванная")
#                 },
#                 {
#                     "days": [
#                             _("Вт."),
#                             _("Пт."),
#                             _("Вс."),
#                     ],
#                     "time": _("Вечер"),
#                     "time_gr": "Evening",
#                     "description_abb": _("Зал"),
#                     "description": _("Вечер зал")
#                 },
#                 {
#                     "description_abb": _("Ждем тебя в следующем патче"),
#                     "description": _("Вы прошли все сюжетные события этого персонажа в текущем патче")
#                 },
#             ],
#             "gradient": "gradientbluepurple",
#             "outlines": '[ (1.2, "#8c9ced", 1, 1) ]',
#             "outlines_name": '[ (3, "#7458AD", 1, 1) ]'
#         },
#         {
#             "name": _("Соня"),
#             "origname": "Sonya",
#             "icon_image": "images/icons/sonya_icon.png",
#             "full_image": "big_book_sonya",
#             "quest_image": "icons/npcrooms/sonyaspec.png",
#             "description": _("Тёплая и заботливая, но собранная и точная, как часы. Любит музыку, игры и порядок, иногда стесняется — но именно она делает шаг первой"),
#             "age": 23,
#             "relations": Sonya_relations_main,
#             "role": _("Союзник"),
#             "quest": [
#                 {
#                     "days": [
#                             _("Пн."),
#                             _("Ср."),
#                             _("Сб."),
#                     ],
#                     "time": _("Утро"),
#                     "time_gr": "Morning",
#                     "description_abb": _("Кухня"),  
#                     "description": _("Утро Кухня")
#                 },
#                 {
#                     "days": [
#                             _("Вт."),
#                             _("Ср."),
#                             _("Сб."),
#                     ],
#                     "time": _("День"),
#                     "time_gr": "Day",
#                     "description_abb": _("Ее комната"),
#                     "description": _("День Ее комната")
#                 },
#                 {
#                     "days": [
#                             _("Пт."),
#                             _("Сб."),
#                     ],
#                     "time": _("День"),
#                     "time_gr": "Day",
#                     "description_abb": _("Ванная"),
#                     "description": _("День Ванная")
#                 },
#                 {
#                     "days": [
#                             _("Пн."),
#                             _("Пт."),
#                     ],
#                     "time": _("Утро"),
#                     "time_gr": "Morning",
#                     "description_abb": _("Ванная"),
#                     "description": _("Утро Ванная")
#                 },
#                 {
#                     "description_abb": _("Стоит подождать"),
#                     "description": _("Думаю стоит подождать")
#                 },
#                 {
#                     "days": [
#                             _("Пн."),
#                             _("Чт."),
#                     ],
#                     "time": _("Вечер"),
#                     "time_gr": "Evening",
#                     "description_abb": _("Зал"),
#                     "description": _("Вечер Зал")
#                 },
#                 {
#                     "days": [
#                             _("Чт."),
#                             _("Вс."),
#                     ],
#                     "time": _("Вечер"),
#                     "time_gr": "Evening",
#                     "description_abb": _("Ее комната"),
#                     "description": _("Вечер Ее комната")
#                 },
#                 {
#                     "days": [
#                             _("Чт."),
#                             _("Сб."),
#                     ],
#                     "time": _("Утро"),
#                     "time_gr": "Morning",
#                     "description_abb": _("Кухня"),
#                     "description": _("Утро Кухня")
#                 },
#                 {
#                     "days": [
#                             _("Пн."),
#                             _("Пт."),
#                     ],
#                     "time": _("Ночь"),
#                     "time_gr": "Night",
#                     "description_abb": _("Зал"),
#                     "description": _("Ночь Зал")
#                 },
#                 {
#                     "description_abb": _("Ждем тебя в следующем патче"),
#                     "description": _("Вы прошли все сюжетные события этого персонажа в текущем патче")
#                 },
#             ],
#             "gradient": "gradientPink",
#             "outlines": '[ (1.2, "#e288cf", 1, 1) ]',
#             "outlines_name": '[ (3, "#af68a0", 1, 1) ]'
#         },
#         {
#             "name": _("Кейт"),
#             "origname": "Kate",
#             "icon_image": "images/icons/kate_icon.png",
#             "icon_image_locked": "images/icons/kate_icon_locked.png",
#             "full_image": "big_book_kate",
#             "quest_image": "icons/npcrooms/katespec.png",
#             "description": _("Яркая и энергичная, Кейт не умеет сидеть на месте — она живёт движением и смехом. Кажется лёгкой и беззаботной, но за её улыбкой прячется страх остаться одной"),
#             "age": 23,
#             "relations": Kate_relations_main,
#             "role": _("Союзник"),
#             "quest": [
#                 {
#                     "days": [
#                             _("Пн.")
#                     ],
#                     "time": _("День"),
#                     "time_gr": "Day",
#                     "description_abb": _("Зал"),
#                     "description": _("День Зал")
#                 },
#                 {
#                     "description_abb": _("Ждем тебя в следующем патче"),
#                     "description": _("Вы прошли все сюжетные события этого персонажа в текущем патче")
#                 },
#             ],
#             "gradient": "gradientKate",
#             "outlines": '[ (1.2, "#b48203", 1, 1) ]',
#             "outlines_name": '[ (3, "#b38000", 1, 1) ]'
#         }
#     ]

default selected_char = None

