label after_load:
    $ config.menu_include_disabled = True
    if (_version < "0.3"):
        "Привет. Игра претерпела большие изменения, получила новое интро и сцены"
        "Старые сейвы работать не будут(("
        "Пожалуйста, начните игру заново"
        $ MainMenu(confirm=False)()

    $ morning_tracks = ["audio/soundtracks/morning.mp3", "audio/soundtracks/morning2.mp3", "audio/soundtracks/morning3.mp3"]
    $ ui_select_sounds = ["audio/ui/UI_Select.mp3", "audio/ui/UI_Select_high.mp3", "audio/ui/UI_Select_low.mp3", "audio/ui/UI_Select_Short.mp3"]
    $ ui_check_sounds = ["audio/ui/UI_Check.mp3", "audio/ui/UI_Check low pitch.mp3", "audio/ui/UI_Check low pitch L.mp3"]

    $ characters_list = build_characters_list()

    $ selected_char = None
    return