init python:
    def hide_screens():
            renpy.hide_screen("time_display")
            renpy.hide_screen("time_display_button")
            renpy.hide_screen("map_icon")
            renpy.hide_screen("check_obj")
            renpy.hide_screen("rooms_in")
            renpy.hide_screen("side_block")

label splashscreen: 
    if not persistent.tutorialplayed:
        call screen language_choice
        $ persistent.tutorialplayed = True

    show screen disclaimer_bugs with dissolve
    $ renpy.pause(delay=5.0, hard=True)
    hide screen disclaimer_bugs with dissolve
    show screen disclaimer with dissolve 
    $ renpy.pause(delay=3.0, hard=True)
    hide screen disclaimer with dissolve
    $ renpy.pause(delay=1.0, hard=True)

    play sound "audio/rain.wav" fadein 2 fadeout 2 loop
    return

label next_time:
    if current_time != "night":
        $ current_time_index = (current_time_index + 1) % len(time_order)  # Всегда меняем индекс
        $ current_time = time_order[current_time_index]  # Обновляем время
        $ current_time_translate = time_order_translate[current_time_index]  # Обновляем время


        if current_time == "morning":
            play music renpy.random.choice(morning_tracks) fadein 0.5 fadeout 0.5 loop
        else:
            play music "audio/soundtracks/%s.mp3" % current_time fadein 0.5 fadeout 0.5 loop
        show screen time_display with dissolve
    $ renpy.jump(current_label)
    return  

label next_day:
    $ current_day_index = (current_day_index + 1) % len(day_order)  # Всегда меняем индекс
    $ current_day = day_order[current_day_index]
    $ current_day_translate = day_order_translate[current_day_index]  # Обновляем время
    $ current_day_abb = day_order_abb[current_day_index]
    return  

label next_time_button:
    if current_time != "night":
        $ current_time_index = (current_time_index + 1) % len(time_order)  # Всегда меняем индекс
        $ current_time = time_order[current_time_index]  # Обновляем время
        $ current_time_translate = time_order_translate[current_time_index]  # Обновляем время
        if current_time == "morning":
            play music renpy.random.choice(morning_tracks) fadein 0.5 fadeout 0.5 loop
        else:
            play music "audio/soundtracks/%s.mp3" % current_time fadein 0.5 fadeout 0.5 loop
        show screen time_display with dissolve
    else:
        if (current_label != "myroom"):
            "Пора спать"  
            jump myroom
    $ renpy.jump(current_label)
    return 

label next_time_dialog:
    if current_time != "night":
        $ current_time_index = (current_time_index + 1) % len(time_order)  # Всегда меняем индекс
        $ current_time = time_order[current_time_index]  # Обновляем время
        $ current_time_translate = time_order_translate[current_time_index]  # Обновляем время
        if current_time == "morning":
            play music renpy.random.choice(morning_tracks) fadein 0.5 fadeout 0.5 loop
        else:
            play music "audio/soundtracks/%s.mp3" % current_time fadein 0.5 fadeout 0.5 loop
    return  


label next_time_startup:
    $ current_time_index = (current_time_index + 1) % len(time_order)  # Всегда меняем индекс
    $ current_time = time_order[current_time_index]  # Обновляем время
    $ current_time_translate = time_order_translate[current_time_index]  # Обновляем время
    return  

label sleep_until_morning:
    if current_time == "night":
        hide screen check_obj
        hide screen rooms_in
        show black with Dissolve(1.0)
        $ renpy.pause(delay=1, hard=True)
        if (first_Morning):
            $ first_Morning = False
            call next_time_startup
            if current_time == "morning":
                play music renpy.random.choice(morning_tracks) fadein 0.5 fadeout 0.5 loop
            else:
                play music "audio/soundtracks/%s.mp3" % current_time fadein 0.5 fadeout 0.5 loop
            jump gg_first_morning 
        if current_day in ["Monday", "Thursday"] and Sonya_relations_main == 4:
            jump sonya_scene5_night_girlroom
        call next_day
        $ current_time_index = 0
        $ current_time = "morning"
        $ current_time_translate = _("Утро")    
        $ day_number += 1
        
        hide black with Dissolve(2.0)

        if current_time == "morning":
            play music renpy.random.choice(morning_tracks) fadein 0.5 fadeout 0.5 loop
        else:
            play music "audio/soundtracks/%s.mp3" % current_time fadein 0.5 fadeout 0.5 loop
        show screen check_obj
    else:
        hide screen check_obj
        "Думаю еще не время ложиться спать"
        show screen check_obj
    jump myroom
    return