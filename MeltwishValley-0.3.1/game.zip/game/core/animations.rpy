
image gg_act1_scene1_video1 = Movie(play="images/gg act1/1st scene/videos/video1.webm", start_image="images/gg act1/1st scene/videos/video1.png", keep_last_frame=True, loop=False)
image gg_act1_scene1_video2 = Movie(play="images/gg act1/1st scene/videos/video2.webm", start_image="images/gg act1/1st scene/videos/video2.png", keep_last_frame=True)
image gg_act1_scene1_video3 = Movie(play="images/gg act1/1st scene/videos/video3.webm", start_image="images/gg act1/1st scene/videos/video3.png", keep_last_frame=True)
image gg_act1_scene1_video4 = Movie(play="images/gg act1/1st scene/videos/video4.webm", start_image="images/gg act1/1st scene/videos/video4.png", keep_last_frame=True)
image gg_act1_scene1_video5 = Movie(play="images/gg act1/1st scene/videos/video5.webm", start_image="images/gg act1/1st scene/videos/video5.png", keep_last_frame=True, loop=False)
image gg_act1_scene1_video6 = Movie(play="images/gg act1/1st scene/videos/video6.webm", start_image="images/gg act1/1st scene/videos/video6.png", keep_last_frame=True)
image gg_act1_scene1_video7 = Movie(play="images/gg act1/4-5/video/video7.webm", start_image="images/gg act1/4-5/video/video7.png", keep_last_frame=True)
image gg_act1_scene1_video8 = Movie(play="images/gg act1/4-5/video/video8.webm", start_image="images/gg act1/4-5/video/video8.png", keep_last_frame=True)
image gg_act1_scene1_video9 = Movie(play="images/gg act1/4-5/video/video9.webm", start_image="images/gg act1/4-5/video/video9.png", keep_last_frame=True)
image gg_act1_scene1_video10 = Movie(play="images/gg act1/6/video/video10.webm", start_image="images/gg act1/6/video/video10.png", keep_last_frame=True)
image gg_act1_scene1_video11 = Movie(play="images/gg act1/6/video/video11.webm", start_image="images/gg act1/6/video/video11.png", keep_last_frame=True)
image gg_act1_scene1_video12 = Movie(play="images/gg act1/6/video/video12.webm", start_image="images/gg act1/6/video/video12.png", keep_last_frame=True)
image gg_act1_scene1_video13 = Movie(play="images/gg act1/6/video/video13.webm", start_image="images/gg act1/6/video/video13.png", keep_last_frame=True)
image gg_act1_scene2_video1 = Movie(play="images/gg act1/9/video1.webm", start_image="images/gg act1/9/video1.png", keep_last_frame=True)
image gg_act1_scene2_video2 = Movie(play="images/gg act1/9/video2.webm", start_image="images/gg act1/9/video2.png", keep_last_frame=True)
image gg_act1_scene2_video3 = Movie(play="images/gg act1/10/video/video15.webm", start_image="images/gg act1/10/video/video15.png", keep_last_frame=True)
image gg_act1_scene2_video4 = Movie(play="images/gg act1/10/video/video16.webm", start_image="images/gg act1/10/video/video16.png", keep_last_frame=True)
image gg_act1_scene3_video1 = Movie(play="images/gg act1/11/video/video17.webm", start_image="images/gg act1/11/video/video17.png", keep_last_frame=True)
image gg_act1_scene3_video2 = Movie(play="images/gg act1/11/video/video18.webm", start_image="images/gg act1/11/video/video18.png", keep_last_frame=True)
image gg_act1_scene3_video3 = Movie(play="images/gg act1/11/video/video19.webm", start_image="images/gg act1/11/video/video19.png", keep_last_frame=True, loop=False)
image gg_act1_scene3_video4 = Movie(play="images/gg act1/12/video/video20.webm", start_image="images/gg act1/12/video/video20.png", keep_last_frame=True)
image gg_act1_scene3_video5 = Movie(play="images/gg act1/12/video/video21.webm", start_image="images/gg act1/12/video/video21.png", keep_last_frame=True)
image gg_act2_scene1_video1 = Movie(play="images/act2/gg_events/2maya/video/mc_2_day_mroom_1.webm", start_image="images/act2/gg_events/2maya/video/mc_2_day_mroom_1.png", keep_last_frame=True, loop=True)
image gg_act2_scene1_video2 = Movie(play="images/act2/gg_events/2maya/video/mc_2_day_mroom_2.webm", start_image="images/act2/gg_events/2maya/video/mc_2_day_mroom_2.png", keep_last_frame=True, loop=True)
image gg_act2_scene1_video3 = Movie(play="images/act2/gg_events/2maya/video/mc_2_day_mroom_3.webm", start_image="images/act2/gg_events/2maya/video/mc_2_day_mroom_3.png", keep_last_frame=True, loop=True)
image gg_act2_scene3_video1 = Movie(play="images/act2/gg_events/3sonya/video/mc_3_day_bathroom_1.webm", start_image="images/act2/gg_events/3sonya/video/mc_3_day_bathroom_1.png", keep_last_frame=True, loop=True)


image gg_morning_kitchen1 = Movie(play="images/act2/gg_events/gg_morning_kitchen/vide/gg_morning_kitchen1.webm", loop=True, start_image="images/act2/gg_events/gg_morning_kitchen/vide/gg_morning_kitchen1.png")


image kate_morning_myroom1 = Movie(play="images/act2/kate_events/kate_morning_myroom/video/kate_morning_myroom1.webm", loop=True, start_image="images/act2/kate_events/kate_morning_myroom/video/kate_morning_myroom1.png")


image maya_act2_scene1_video1 = Movie(play="images/act2/maya_events/1/video/maya_1_evening_livingroom_1.webm", start_image="images/act2/maya_events/1/video/maya_1_evening_livingroom_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene4_video1 = Movie(play="images/act2/maya_events/4/video/maya_4_afternoon_mroom_1.webm", start_image="images/act2/maya_events/4/video/maya_4_afternoon_mroom_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene4_video2 = Movie(play="images/act2/maya_events/4/video/maya_4_afternoon_mroom_2.webm", start_image="images/act2/maya_events/4/video/maya_4_afternoon_mroom_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene5_video1 = Movie(play="images/act2/maya_events/5/video/maya_5_afternoon_mroom_1.webm", start_image="images/act2/maya_events/5/video/maya_5_afternoon_mroom_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene6_video1 = Movie(play="images/act2/maya_events/6/video/maya_6_evening_livingroom_1.webm", start_image="images/act2/maya_events/6/video/maya_6_evening_livingroom_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene6_video2 = Movie(play="images/act2/maya_events/6/video/maya_6_evening_livingroom_2.webm", start_image="images/act2/maya_events/6/video/maya_6_evening_livingroom_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene7_video1 = Movie(play="images/act2/maya_events/7/video/maya_7_night_mayaroom_1.webm", start_image="images/act2/maya_events/7/video/maya_7_night_mayaroom_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene7_video2 = Movie(play="images/act2/maya_events/7/video/maya_7_night_mayaroom_2.webm", start_image="images/act2/maya_events/7/video/maya_7_night_mayaroom_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene8_video1 = Movie(play="images/act2/maya_events/8/videos/maya_8_morning_mayaroom_1.webm", start_image="images/act2/maya_events/8/videos/maya_8_morning_mayaroom_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene8_video2 = Movie(play="images/act2/maya_events/8/videos/maya_8_morning_mayaroom_2.webm", start_image="images/act2/maya_events/8/videos/maya_8_morning_mayaroom_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene9_video1 = Movie(play="images/act2/maya_events/9/video/maya_3_video_1.webm", start_image="images/act2/maya_events/9/video/maya_3_video_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene9_video2 = Movie(play="images/act2/maya_events/9/video/maya_3_video_2.webm", start_image="images/act2/maya_events/9/video/maya_3_video_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene9_video3 = Movie(play="images/act2/maya_events/9/video/maya_3_video_3.webm", start_image="images/act2/maya_events/9/video/maya_3_video_3.png", keep_last_frame=True, loop=True)
image maya_act2_scene9_video4 = Movie(play="images/act2/maya_events/9/video/maya_3_video_4.webm", start_image="images/act2/maya_events/9/video/maya_3_video_4.png", keep_last_frame=True, loop=True)
image maya_act2_scene9_video5 = Movie(play="images/act2/maya_events/9/video/maya_3_video_5.webm", start_image="images/act2/maya_events/9/video/maya_3_video_5.png", keep_last_frame=True, loop=True)
image maya_act2_scene10_video1 = Movie(play="images/act2/maya_events/10/video/maya_10_evening_livingroom_1.webm", start_image="images/act2/maya_events/10/video/maya_10_evening_livingroom_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene10_video2 = Movie(play="images/act2/maya_events/10/video/maya_10_evening_livingroom_2.webm", start_image="images/act2/maya_events/10/video/maya_10_evening_livingroom_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene10_video3 = Movie(play="images/act2/maya_events/10/video/maya_10_evening_livingroom_3.webm", start_image="images/act2/maya_events/10/video/maya_10_evening_livingroom_3.png", keep_last_frame=True, loop=True)
image maya_act2_scene11_video1 = Movie(play="images/act2/maya_events/11/video/maya_4_video_1.webm", start_image="images/act2/maya_events/11/video/maya_4_video_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene11_video2 = Movie(play="images/act2/maya_events/11/video/maya_4_video_2.webm", start_image="images/act2/maya_events/11/video/maya_4_video_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene12_video1 = Movie(play="images/act2/maya_events/12/video/maya_5_video_1.webm", start_image="images/act2/maya_events/12/video/maya_5_video_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene12_video2 = Movie(play="images/act2/maya_events/12/video/maya_5_video_2.webm", start_image="images/act2/maya_events/12/video/maya_5_video_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene12_video3 = Movie(play="images/act2/maya_events/12/video/maya_5_video_3.webm", start_image="images/act2/maya_events/12/video/maya_5_video_3.png", keep_last_frame=True, loop=True)
image maya_act2_scene12_video4 = Movie(play="images/act2/maya_events/12/video/maya_5_video_4.webm", start_image="images/act2/maya_events/12/video/maya_5_video_4.png", keep_last_frame=True, loop=True)
image maya_act2_scene12_video5 = Movie(play="images/act2/maya_events/12/video/maya_5_video_5.webm", start_image="images/act2/maya_events/12/video/maya_5_video_5.png", keep_last_frame=True, loop=True)
image maya_act2_scene12_video6 = Movie(play="images/act2/maya_events/12/video/maya_5_video_6.webm", start_image="images/act2/maya_events/12/video/maya_5_video_6.png", keep_last_frame=True, loop=False)
image maya_act2_scene13_video1 = Movie(play="images/act2/maya_events/13/video/maya_13_morning_sroom_1.webm", start_image="images/act2/maya_events/13/video/maya_13_morning_sroom_1.png", keep_last_frame=True, loop=False)
image maya_act2_scene13_video2 = Movie(play="images/act2/maya_events/13/video/maya_13_morning_sroom_2.webm", start_image="images/act2/maya_events/13/video/maya_13_morning_sroom_2.png", keep_last_frame=True, loop=True)
image maya_act2_scene13_video3 = Movie(play="images/act2/maya_events/13/video/maya_13_morning_sroom_3.webm", start_image="images/act2/maya_events/13/video/maya_13_morning_sroom_3.png", keep_last_frame=True, loop=True)
image maya_act2_scene13_video4 = Movie(play="images/act2/maya_events/13/video/maya_13_morning_sroom_4.webm", start_image="images/act2/maya_events/13/video/maya_13_morning_sroom_4.png", keep_last_frame=True, loop=True)
image maya_act2_scene13_video5 = Movie(play="images/act2/maya_events/13/video/maya_13_morning_sroom_5.webm", start_image="images/act2/maya_events/13/video/maya_13_morning_sroom_5.png", keep_last_frame=True, loop=True)
image maya_act2_scene13_video6 = Movie(play="images/act2/maya_events/13/video/maya_13_morning_sroom_6.webm", start_image="images/act2/maya_events/13/video/maya_13_morning_sroom_6.png", keep_last_frame=True, loop=False)
image maya_act2_scene14_video1 = Movie(play="images/act2/maya_events/14/video/maya_13_afternoon_hall_1.webm", start_image="images/act2/maya_events/14/video/maya_13_afternoon_hall_1.png", keep_last_frame=True, loop=True)
image maya_act2_scene14_video2 = Movie(play="images/act2/maya_events/14/video/maya_13_afternoon_hall_2.webm", start_image="images/act2/maya_events/14/video/maya_13_afternoon_hall_2.png", keep_last_frame=True, loop=False)
image maya_act2_scene14_video3 = Movie(play="images/act2/maya_events/14/video/maya_13_afternoon_hall_3.webm", start_image="images/act2/maya_events/14/video/maya_13_afternoon_hall_3.png", keep_last_frame=True, loop=True)
image maya_act2_scene14_video4 = Movie(play="images/act2/maya_events/14/video/maya_13_afternoon_hall_4.webm", start_image="images/act2/maya_events/14/video/maya_13_afternoon_hall_4.png", keep_last_frame=True, loop=False)



image sonya_act2_scene1_video1 = Movie(play="images/act2/sonya_events/1/video/sonya_1_morning_kitchen_1.webm", start_image="images/act2/sonya_events/1/video/sonya_1_morning_kitchen_1.png", keep_last_frame=True, loop=True)
image sonya_act2_scene1_video2 = Movie(play="images/act2/sonya_events/1/video/sonya_1_morning_kitchen_2.webm", start_image="images/act2/sonya_events/1/video/sonya_1_morning_kitchen_2.png", keep_last_frame=True, loop=True)
image sonya_act2_scene2_video1 = Movie(play="images/act2/sonya_events/2/video/sonya_2_afternoon_sroom_1.webm", start_image="images/act2/sonya_events/2/video/sonya_2_afternoon_sroom_1.png", keep_last_frame=True, loop=True)
image sonya_act2_scene2_video2 = Movie(play="images/act2/sonya_events/2/video/sonya_2_afternoon_sroom_2.webm", start_image="images/act2/sonya_events/2/video/sonya_2_afternoon_sroom_2.png", keep_last_frame=True, loop=True)
image sonya_act2_scene3_video1 = Movie(play="images/act2/sonya_events/3/video/sonya_3_afternoon_bathroom_1.webm", start_image="images/act2/sonya_events/3/video/sonya_3_afternoon_bathroom_1.png", keep_last_frame=True, loop=False)
image sonya_act2_scene3_video2 = Movie(play="images/act2/sonya_events/3/video/sonya_3_afternoon_bathroom_2.webm", start_image="images/act2/sonya_events/3/video/sonya_3_afternoon_bathroom_2.png", keep_last_frame=True, loop=True)
image sonya_act2_scene4_video1 = Movie(play="images/act2/sonya_events/4/video/sonya bath 1_20.webm", start_image="images/act2/sonya_events/4/video/sonya bath 1_20.png", keep_last_frame=True, loop=False)
image sonya_act2_scene4_video2 = Movie(play="images/act2/sonya_events/4/video/sonya bath 1_30.webm", start_image="images/act2/sonya_events/4/video/sonya bath 1_30.png", keep_last_frame=True, loop=True)
image sonya_act2_scene5_video1 = Movie(play="images/act2/sonya_events/5/video/sonya_5_night_sroom_1.webm", start_image="images/act2/sonya_events/5/video/sonya_5_night_sroom_1.png", keep_last_frame=True, loop=True)
image sonya_act2_scene5_video2 = Movie(play="images/act2/sonya_events/5/video/sonya_4_night_sroom_2.webm", start_image="images/act2/sonya_events/5/video/sonya_4_night_sroom_2.png", keep_last_frame=True, loop=True)
image sonya_act2_scene5_video3 = Movie(play="images/act2/sonya_events/5/video/sonya_4_night_sroom_3.webm", start_image="images/act2/sonya_events/5/video/sonya_4_night_sroom_3.png", keep_last_frame=True, loop=False)
image sonya_act2_scene5_video4 = Movie(play="images/act2/sonya_events/5/video/sonya_4_night_sroom_4.webm", start_image="images/act2/sonya_events/5/video/sonya_4_night_sroom_4.png", keep_last_frame=True, loop=True)
image sonya_act2_scene6_video1 = Movie(play="images/act2/sonya_events/6/video/sonya_act2_scene6_video1.webm", start_image="images/act2/sonya_events/6/video/sonya_act2_scene6_video1.png", keep_last_frame=True, loop=True)
image sonya_act2_scene6_video2 = Movie(play="images/act2/sonya_events/6/video/sonya_act2_scene6_video2.webm", start_image="images/act2/sonya_events/6/video/sonya_act2_scene6_video2.png", keep_last_frame=True, loop=True)
image sonya_act2_scene7_video1 = Movie(play="images/act2/sonya_events/7/video/sonya_act2_scene7_video1.webm", start_image="images/act2/sonya_events/7/video/sonya_act2_scene7_video1.png", keep_last_frame=True, loop=True)
image sonya_act2_scene7_video2 = Movie(play="images/act2/sonya_events/7/video/sonya_act2_scene7_video2.webm", start_image="images/act2/sonya_events/7/video/sonya_act2_scene7_video2.png", keep_last_frame=True, loop=True)
image sonya_act2_scene7_video3 = Movie(play="images/act2/sonya_events/7/video/sonya_act2_scene7_video3.webm", start_image="images/act2/sonya_events/7/video/sonya_act2_scene7_video3.png", keep_last_frame=True, loop=True)
image sonya_act2_scene7_video4 = Movie(play="images/act2/sonya_events/7/video/sonya_act2_scene7_video4.webm", start_image="images/act2/sonya_events/7/video/sonya_act2_scene7_video4.png", keep_last_frame=True, loop=True)
image sonya_act2_scene7_video5 = Movie(play="images/act2/sonya_events/7/video/sonya_act2_scene7_video5.webm", start_image="images/act2/sonya_events/7/video/sonya_act2_scene7_video5.png", keep_last_frame=True, loop=False)
image sonya_act2_scene7_video6 = Movie(play="images/act2/sonya_events/7/video/sonya_act2_scene7_video6.webm", start_image="images/act2/sonya_events/7/video/sonya_act2_scene7_video6.png", keep_last_frame=True, loop=True)
image sonya_act2_scene7_video7 = Movie(play="images/act2/sonya_events/7/video/sonya_act2_scene7_video7.webm", start_image="images/act2/sonya_events/7/video/sonya_act2_scene7_video7.png", keep_last_frame=True, loop=False)
image sonya_act2_scene8_video1 = Movie(play="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_1.webm", start_image="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_1.png", keep_last_frame=True, loop=True)
image sonya_act2_scene8_video2 = Movie(play="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_2.webm", start_image="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_2.png", keep_last_frame=True, loop=True)
image sonya_act2_scene8_video3 = Movie(play="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_3.webm", start_image="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_3.png", keep_last_frame=True, loop=True)
image sonya_act2_scene8_video4 = Movie(play="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_4.webm", start_image="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_4.png", keep_last_frame=True, loop=True)
image sonya_act2_scene8_video5 = Movie(play="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_5.webm", start_image="images/act2/sonya_events/8/video/sonya_8_morning_kitchen_5.png", keep_last_frame=True, loop=False)
image sonya_act2_scene9_video1 = Movie(play="images/act2/sonya_events/9/video/sonya_9_night_hall_1.webm", start_image="images/act2/sonya_events/9/video/sonya_9_night_hall_1.png", keep_last_frame=True, loop=True)
image sonya_act2_scene9_video2 = Movie(play="images/act2/sonya_events/9/video/sonya_9_night_hall_2.webm", start_image="images/act2/sonya_events/9/video/sonya_9_night_hall_2.png", keep_last_frame=True, loop=True)
image sonya_act2_scene9_video3 = Movie(play="images/act2/sonya_events/9/video/sonya_9_night_hall_3.webm", start_image="images/act2/sonya_events/9/video/sonya_9_night_hall_3.png", keep_last_frame=True, loop=True)




image halloween_1_livingroom1 = Movie(play="images/special_events/halloween 2025/Part1/1start livingroom/video/halloween_1_livingroom_video1.webm", loop=True, start_image="images/special_events/halloween 2025/Part1/1start livingroom/video/halloween_1_livingroom_video1.png")
image halloween_1_livingroom2 = Movie(play="images/special_events/halloween 2025/Part1/1start livingroom/video/halloween_1_livingroom_video2.webm", loop=True, start_image="images/special_events/halloween 2025/Part1/1start livingroom/video/halloween_1_livingroom_video2.png")
image halloween_1_livingroom3 = Movie(play="images/special_events/halloween 2025/Part1/1start livingroom/video/halloween_1_livingroom_video3.webm", loop=True, start_image="images/special_events/halloween 2025/Part1/1start livingroom/video/halloween_1_livingroom_video3.png")
image halloween_1_mroom = Movie(play="images/special_events/halloween 2025/Part1/3 maya room/video/halloween_1_mroom_video.webm", loop=True, start_image="images/special_events/halloween 2025/Part1/3 maya room/video/halloween_1_mroom_video.png")
image halloween_1_sroom = Movie(play="images/special_events/halloween 2025/Part1/4 sonya room/video/halloween_1_sroom_video.webm", loop=True, start_image="images/special_events/halloween 2025/Part1/4 sonya room/video/halloween_1_sroom_video.png")
image halloween_2_sonya = Movie(play="images/special_events/halloween 2025/sonya/video/halloween_2_sonyavideo.webm", loop=True, start_image="images/special_events/halloween 2025/sonya/video/halloween_2_sonyavideo.png")
image halloween_2_sonya2 = Movie(play="images/special_events/halloween 2025/sonya/video/halloween_3_sonyavideo.webm", loop=True, start_image="images/special_events/halloween 2025/sonya/video/halloween_3_sonyavideo.png")
image halloween_2_maya = Movie(play="images/special_events/halloween 2025/maya/video/halloween_3_mayavideo.webm", loop=True, start_image="images/special_events/halloween 2025/maya/video/halloween_3_mayavideo.png")
image halloween_3_kate1 = Movie(play="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_1.webm", loop=True, start_image="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_1.png")
image halloween_3_kate2 = Movie(play="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_2.webm", loop=True, start_image="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_2.png")
image halloween_3_kate3 = Movie(play="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_3.webm", loop=False, start_image="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_3.png")
image halloween_3_kate4 = Movie(play="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_4.webm", loop=False, start_image="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_4.png", keep_last_frame=True)
image halloween_3_kate5 = Movie(play="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_5.webm", loop=True, start_image="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_5.png")
image halloween_3_kate6 = Movie(play="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_6.webm", loop=True, start_image="images/special_events/halloween 2025/kate/video/H25_kate_1_night_kitchen_6.png")


image sonya_Idle_morning_bathroomvideo = Movie(play="images/idle_buttons/newidles/sonya/morning/bath/video/sonya_Idle_morning_bathroom_1.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/morning/bath/video/sonya_Idle_morning_bathroom_1.png")
image sonya_Idle_evening_bathroomvideo = Movie(play="images/idle_buttons/newidles/sonya/evening/bath/video/sonya_Idle_evening_bathroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/evening/bath/video/sonya_Idle_evening_bathroomvideo.png")
image sonya_Idle_morning_kitchenvideo = Movie(play="images/idle_buttons/newidles/sonya/morning/kitchen/video/sonya_Idle_morning_kitchen_1.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/morning/kitchen/video/sonya_Idle_morning_kitchen_2.png")
image sonya_Idle_afternoon_kitchenvideo = Movie(play="images/idle_buttons/newidles/sonya/afternoon/kitchen/video/sonya_Idle_afternoon_kitchenvideo.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/afternoon/kitchen/video/sonya_Idle_afternoon_kitchenvideo.png")
image sonya_Idle_evening_kitchenvideo = Movie(play="images/idle_buttons/newidles/sonya/evening/kitchen/video/sonya_Idle_evening_kitchenvideo.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/evening/kitchen/video/sonya_Idle_evening_kitchenvideo.png")
image sonya_Idle_morning_sonyaroomvideo = Movie(play="images/idle_buttons/newidles/sonya/morning/sRoom/video/sonya_Idle_morning_sroom_1.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/morning/sRoom/sonya_Idle_morning_sroom_1.png")
image sonya_Idle_afternoon_sonyaroomvideo = Movie(play="images/idle_buttons/newidles/sonya/afternoon/Room/video/sonya_Idle_afternoon_sonyaroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/afternoon/Room/video/sonya_Idle_afternoon_sonyaroomvideo.png")
image sonya_Idle_evening_sonyaroomvideo = Movie(play="images/idle_buttons/newidles/sonya/evening/Room/video/sonya_Idle_evening_sonyaroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/evening/Room/video/sonya_Idle_evening_sonyaroomvideo.png")
image sonya_Idle_night_sonyaroomvideo = Movie(play="images/idle_buttons/newidles/sonya/night/sRoom/video/sonya_Idle_night_sonyaroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/night/sRoom/video/sonya_Idle_night_sonyaroomvideo.png")
image sonya_Idle_morning_myroomvideo = Movie(play="images/idle_buttons/newidles/sonya/morning/Zal/video/sonya_Idle_morning_zal.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/morning/Zal/video/sonya_Idle_morning_zal.png")
image sonya_Idle_afternoon_myroomvideo = Movie(play="images/idle_buttons/newidles/sonya/afternoon/Zal/video/sonya_Idle_afternoon_myroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/afternoon/Zal/video/sonya_Idle_afternoon_myroomvideo.png")
image sonya_Idle_evening_myroomvideo = Movie(play="images/idle_buttons/newidles/sonya/evening/Zal/video/sonya_Idle_evening_myroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/evening/Zal/video/sonya_Idle_evening_myroomvideo.png")
image sonya_Idle_morning_bathroom = Movie(play="images/idle_buttons/newidles/sonya/morning/bath/video/sonya_Idle_morning_bathroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/morning/bath/video/sonya_Idle_morning_bathroom.png", side_mask=True)
image sonya_Idle_evening_bathroom = Movie(play="images/idle_buttons/newidles/sonya/evening/bath/video/sonya_Idle_evening_bathroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/evening/bath/video/sonya_Idle_evening_bathroom.png", side_mask=True)
image sonya_Idle_morning_kitchen = Movie(play="images/idle_buttons/newidles/sonya/morning/kitchen/video/sonya_Idle_morning_kitchen.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/morning/kitchen/video/sonya_Idle_morning_kitchen.png", side_mask=True)
image sonya_Idle_day_kitchen = Movie(play="images/idle_buttons/newidles/sonya/afternoon/kitchen/video/sonya_Idle_afternoon_kitchen.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/afternoon/kitchen/video/sonya_Idle_afternoon_kitchen.png", side_mask=True)
image sonya_Idle_evening_kitchen = Movie(play="images/idle_buttons/newidles/sonya/evening/kitchen/video/sonya_Idle_evening_kitchen.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/evening/kitchen/video/sonya_Idle_evening_kitchen.png", side_mask=True)
image sonya_Idle_morning_girlroom = Movie(play="images/idle_buttons/newidles/sonya/morning/sRoom/video/sonya_Idle_morning_sonyaroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/morning/sRoom/video/sonya_Idle_morning_sonyaroom.png", side_mask=True)
image sonya_Idle_day_girlroom = Movie(play="images/idle_buttons/newidles/sonya/afternoon/Room/video/sonya_Idle_afternoon_sonyaroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/afternoon/Room/video/sonya_Idle_afternoon_sonyaroom.png", side_mask=True)
image sonya_Idle_evening_girlroom = Movie(play="images/idle_buttons/newidles/sonya/evening/Room/video/sonya_Idle_evening_sonyaroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/evening/Room/video/sonya_Idle_evening_sonyaroom.png", side_mask=True)
image sonya_Idle_night_girlroom = Movie(play="images/idle_buttons/newidles/sonya/night/sRoom/video/sonya_Idle_night_sonyaroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/night/sRoom/video/sonya_Idle_night_sonyaroom.png", side_mask=True)
image sonya_Idle_morning_myroom = Movie(play="images/idle_buttons/newidles/sonya/morning/Zal/video/sonya_Idle_morning_myroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/morning/Zal/video/sonya_Idle_morning_myroom.png", side_mask=True)
image sonya_Idle_day_myroom = Movie(play="images/idle_buttons/newidles/sonya/afternoon/Zal/video/sonya_Idle_afternoon_myroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/afternoon/Zal/video/sonya_Idle_afternoon_myroom.png", side_mask=True)

image sonya_Idle_evening_myroom = Movie(play="images/idle_buttons/newidles/sonya/evening/Zal/video/sonya_Idle_evening_myroom.webm", loop=True, start_image="images/idle_buttons/newidles/sonya/evening/Zal/video/sonya_Idle_evening_myroom.png", side_mask=True)
image maya_Idle_morning_kitchenvideo = Movie(play="images/idle_buttons/newidles/maya/morning/kitchen/video/maya_Idle_morning_kitchen_.webm", loop=True, start_image="images/idle_buttons/newidles/maya/morning/kitchen/video/maya_Idle_morning_kitchen_.png")
image maya_Idle_afternoon_kitchenvideo = Movie(play="images/idle_buttons/newidles/maya/afternoon/kitchen/video/maya_Idle_afternoon_kitchenvideo.webm", loop=True, start_image="images/idle_buttons/newidles/maya/afternoon/kitchen/video/maya_Idle_afternoon_kitchenvideo.png")
image maya_Idle_morning_mayaroomvideo = Movie(play="images/idle_buttons/newidles/maya/morning/mroom/video/maya_Idle_morning_mroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/morning/mroom/video/maya_Idle_morning_mroom.png")
image maya_Idle_afternoon_mayaroomvideo = Movie(play="images/idle_buttons/newidles/maya/afternoon/mroom/video/maya_Idle_afternoon_mayaroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/maya/afternoon/mroom/video/maya_Idle_afternoon_mayaroomvideo.png")
image maya_Idle_evening_mayaroomvideo = Movie(play="images/idle_buttons/newidles/maya/evening/mRoom/video/maya_Idle_evening_mayaroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/maya/evening/mRoom/video/maya_Idle_evening_mayaroomvideo.png")
image maya_Idle_night_mayaroomvideo = Movie(play="images/idle_buttons/newidles/maya/night/mRoom/video/maya_Idle_night_mayaroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/maya/night/mRoom/video/maya_Idle_night_mayaroomvideo.png")
image maya_Idle_morning_myroomvideo = Movie(play="images/idle_buttons/newidles/maya/morning/zal/video/maya_Idle_morning_zal2.webm", loop=True, start_image="images/idle_buttons/newidles/maya/morning/zal/video/maya_Idle_morning_zal2.png")
image maya_Idle_afternoon_myroomvideo = Movie(play="images/idle_buttons/newidles/maya/afternoon/livingroom/video/maya_afternoon_zal_.webm", loop=True, start_image="images/idle_buttons/newidles/maya/afternoon/livingroom/video/maya_afternoon_zal_.png")
image maya_Idle_evening_myroomvideo = Movie(play="images/idle_buttons/newidles/maya/evening/livingroom/video/maya_Idle_evening_myroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/maya/evening/livingroom/video/maya_Idle_evening_myroomvideo.png")
image maya_Idle_evening_bathroomvideo = Movie(play="images/idle_buttons/newidles/maya/evening/bathroom/video/maya_Idle_evening_bathroomvideo.webm", loop=True, start_image="images/idle_buttons/newidles/maya/evening/bathroom/video/maya_Idle_evening_bathroomvideo.png")
image maya_Idle_evening_bathroom = Movie(play="images/idle_buttons/newidles/maya/evening/bathroom/video/maya_Idle_evening_bathroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/evening/bathroom/video/maya_Idle_evening_bathroom.png", side_mask=True)
image maya_Idle_morning_kitchen = Movie(play="images/idle_buttons/newidles/maya/morning/kitchen/video/maya_Idle_morning_kitchen.webm", loop=True, start_image="images/idle_buttons/newidles/maya/morning/kitchen/video/maya_Idle_morning_kitchen.png", side_mask=True)
image maya_Idle_day_kitchen = Movie(play="images/idle_buttons/newidles/maya/afternoon/kitchen/video/maya_Idle_afternoon_kitchen.webm", loop=True, start_image="images/idle_buttons/newidles/maya/afternoon/kitchen/video/maya_Idle_afternoon_kitchen.png", side_mask=True)
image maya_Idle_morning_mayaroom = Movie(play="images/idle_buttons/newidles/maya/morning/mroom/video/maya_Idle_morning_mayaroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/morning/mroom/video/maya_Idle_morning_mayaroom.png", side_mask=True)
image maya_Idle_day_mayaroom = Movie(play="images/idle_buttons/newidles/maya/afternoon/mroom/video/maya_Idle_afternoon_mayaroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/afternoon/mroom/video/maya_Idle_afternoon_mayaroom.png", side_mask=True)
image maya_Idle_evening_mayaroom = Movie(play="images/idle_buttons/newidles/maya/evening/mRoom/video/maya_Idle_evening_mayaroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/evening/mRoom/video/maya_Idle_evening_mayaroom.png", side_mask=True)
image maya_Idle_night_mayaroom = Movie(play="images/idle_buttons/newidles/maya/night/mRoom/video/maya_Idle_night_mayaroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/night/mRoom/video/maya_Idle_night_mayaroom.png", side_mask=True)
image maya_Idle_morning_myroom = Movie(play="images/idle_buttons/newidles/maya/morning/zal/video/maya_Idle_morning_myroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/morning/zal/video/maya_Idle_morning_myroom.png", side_mask=True)
image maya_Idle_day_myroom = Movie(play="images/idle_buttons/newidles/maya/afternoon/livingroom/video/maya_Idle_afternoon_myroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/afternoon/livingroom/video/maya_Idle_afternoon_myroom.png", side_mask=True)
image maya_Idle_evening_myroom = Movie(play="images/idle_buttons/newidles/maya/evening/livingroom/video/maya_Idle_evening_myroom.webm", loop=True, start_image="images/idle_buttons/newidles/maya/evening/livingroom/video/maya_Idle_evening_myroom.png", side_mask=True)

image big_book_sonya = Movie(play="images/icons/big_book_sonya.webm", loop=True, start_image="images/icons/big_book_sonya.png", side_mask=True)
image big_book_maya = Movie(play="images/icons/big_book_maya.webm", loop=True, start_image="images/icons/big_book_maya.png", side_mask=True)
image big_book_kate = Movie(play="images/icons/big_book_kate.webm", loop=True, start_image="images/icons/big_book_kate.png", side_mask=True)

image exitvideo = Movie(play="images/setting_videos/exitvideo.webm", loop=True, start_image="images/setting_videos/exitvideo.png")

define in_eye = ImageDissolve("images/setting_videos/eye.png", 1.0)
define out_eye = ImageDissolve("images/setting_videos/eye.png", 1.0, reverse=True)
define in_eye2 = ImageDissolve("images/setting_videos/eye.png", 0.3)
define out_eye2 = ImageDissolve("images/setting_videos/eye.png", 0.3, reverse=True)

image sleep_seq = Animation(
    "images/sequences/sleep_seq/1.png", 0.0,
    "images/sequences/sleep_seq/2.png", 0.2,
    "images/sequences/sleep_seq/3.png", 0.2,
    "images/sequences/sleep_seq/4.png", 0.2,
    "images/sequences/sleep_seq/5.png", 0.2,
    "images/sequences/sleep_seq/6.png", 0.2,
    "images/sequences/sleep_seq/7.png", 0.2,
    "images/sequences/sleep_seq/1.png", 0.0
)

image pumpkin_seq = Animation(
    "images/sequences/pumpkin_seq/1.png", 0.0,
    "images/sequences/pumpkin_seq/2.png", 0.05,
    "images/sequences/pumpkin_seq/3.png", 0.05,
    "images/sequences/pumpkin_seq/4.png", 0.05,
    "images/sequences/pumpkin_seq/5.png", 0.05,
    "images/sequences/pumpkin_seq/6.png", 0.05,
    "images/sequences/pumpkin_seq/7.png", 0.05,
    "images/sequences/pumpkin_seq/8.png", 0.05,
    "images/sequences/pumpkin_seq/9.png", 0.05,
    "images/sequences/pumpkin_seq/10.png", 0.05,
    "images/sequences/pumpkin_seq/11.png", 0.05,
    "images/sequences/pumpkin_seq/12.png", 0.05,
    "images/sequences/pumpkin_seq/13.png", 0.05,
    "images/sequences/pumpkin_seq/14.png", 0.05,
    "images/sequences/pumpkin_seq/15.png", 0.05,
    "images/sequences/pumpkin_seq/16.png", 0.05,
    "images/sequences/pumpkin_seq/1.png", 0.0
)

transform move_center_to_lefttop_and_back:
    zoom 2
    xalign 0.5
    yalign 0.5
    easein 1.5 xalign 0.04 yalign 0.04
    pause .5
    easein .2 zoom 2.3
    easeout .2 zoom 2
    pause .5
    easein 1.5 xalign 0.5 yalign 0.5
    pause .5
    repeat

transform move_center_to_righttop_and_back:
    zoom 2
    xalign 0.5
    yalign 0.5
    easein 1.5 xalign 0.99 yalign 0.06
    pause .5
    easein .2 zoom 2.3
    easeout .2 zoom 2
    pause .5
    easein 1.5 xalign 0.5 yalign 0.5
    pause .5
    repeat


transform circular:
    alpha 1.0
    crop_relative True
    crop (0.0, 0.0, 1.0, 1.0)
    xysize (200, 200)  # Фиксированный размер
    align (0.5, 0.5)

transform move_center_to_right_and_back:
    zoom 2
    xalign 0.5
    yalign 0.5
    easein 1.5 xalign 0.98
    pause 1
    easein 1.5 xalign 0.5
    pause 1
    repeat

transform move_center_to_lefttop:
    alpha 1.0
    pause 0.5
    zoom 2
    xalign 0.5
    yalign 0.5
    easein 1.5 xalign 0.04 yalign 0.04
    pause 0.5
    easein 0.5 alpha 0.0
    repeat

transform move_center_to_right_and_scroll:
    zoom 2
    xalign 0.5
    yalign 0.5
    easein 1 xalign 0.93 yalign 0.2
    pause 0.3
    easein 1 xalign 0.93 yalign 0.4
    pause 0.3
    easein 1 xalign 0.93 yalign 0.57
    pause 0.3
    easein 1 xalign 0.93 yalign 0.75
    pause 0.3
    easein 1 xalign 0.93 yalign 0.95
    easein 1 xalign 0.5 yalign 0.5
    pause 1
    repeat

transform tutor_alpha:
    on show:
        alpha 0.0
        easein 0.5 alpha 1.0
    on hide:
        alpha 1.0
        easein 0.5 alpha 0.0