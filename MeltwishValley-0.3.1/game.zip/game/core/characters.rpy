init python:

    def get_gg_chat_name():
        return "*" + povname + "*"


default povname = None
define gg = DynamicCharacter('povname', color="#ffffff",
    what_outlines=[ (2, "#747faf", 1, 1) ],
    who_outlines=[ (3, "#747faf", 1, 1) ])

define gg_chat = DynamicCharacter(get_gg_chat_name, color="#ffffff",
    what_outlines=[ (2, "#747faf", 1, 1) ],
    who_outlines=[ (3, "#747faf", 1, 1) ])

define Sonya = Character(_('Соня'), color="#ffffff",
    what_outlines=[ (2, "#bf82b2", 1, 1) ],
    who_outlines=[ (3, "#bf82b2", 1, 1) ])

define Maya = Character(_('Мая'), color="#ffffff",
    what_outlines=[ (2, "#7a88cd", 1, 1) ],
    who_outlines=[ (3, "#7a88cd", 1, 1) ])

define Kate = Character(_('Кейт'), color="#ffffff",
    what_outlines=[ (2, "#b48203", 1, 1) ],
    who_outlines=[ (3, "#b38000", 1, 1) ])

define PostMan = Character(_('Почтальон'), color="#ffffff",
    what_outlines=[ (2, "#cd8896", 1, 1) ],
    who_outlines=[ (3, "#c17697", 1, 1) ])

define Assistant = Character(_('Секретарь'), color="#ffffff",
    what_outlines=[(2, "#29894e", 1, 1)],
    who_outlines=[(3, "#29894e", 1, 1)])

define Director = Character(_('Директор'), color="#ffffff",
    what_outlines=[ (2, "#700000", 1, 1) ],
    who_outlines=[ (3, "#700000", 1, 1) ])

define UnknownGirl = Character(_('Незнакомка'), color="#ffffff",
    what_outlines=[ (2, "#b47b2d", 1, 1) ],
    who_outlines=[ (3, "#b47b2d", 1, 1) ])