label gg_intro:
    $ renpy.pause(delay=1.0, hard=True)
    scene 1_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=3, hard=True)
    scene 2_mc_1_day_mchome
    play sound alarm
    $ renpy.pause(delay=1, hard=True)
    scene gg_act1_scene1_video1 with dissolve
    $ renpy.pause(delay=0.7, hard=True)
    play sound lighthittable
    $ renpy.pause(delay=2, hard=True)
    scene 3_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 4_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 5_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 6_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 7_mc_1_day_mchome with dissolve
    play sound yawn fadein 0.2 fadeout 0.2
    $ renpy.pause(delay=4, hard=True)
    scene 8_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=2, hard=True)
    image gg_act1_video2_ff = "images/gg act1/1st scene/videos/video2.png"
    scene gg_act1_video2_ff with dissolve
    scene gg_act1_scene1_video2
    $ renpy.pause(delay=0.6, hard=True)
    image gg_act1_video3_ff = "images/gg act1/1st scene/videos/video3.png"
    scene gg_act1_video3_ff with dissolve
    scene gg_act1_scene1_video3
    $ renpy.pause(delay=1.5, hard=True)
    scene 9_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene black with dissolve
    stop ambient fadeout 0.3
    play sound bus_amb fadein 1
    $ renpy.pause(delay=2, hard=True)
    scene gg_act1_scene1_video4 with dissolve
    $ renpy.pause(delay=3, hard=True)
    scene black with out_eye
    stop sound fadeout 0.5
    play fx1 office_amb fadein 0.2 fadeout 0.2
    play fx2 office_clock_amb fadein 0.2 fadeout 0.2
    image gg_act1_video5_ff = "images/gg act1/1st scene/videos/video5.png"
    scene gg_act1_video5_ff with in_eye
    scene gg_act1_scene1_video5
    $ renpy.pause(delay=2, hard=True)
    pause
    stop fx1 fadeout 0.2
    stop fx2 fadeout 0.2
    play ambient night_city_ambient fadein 1 fadeout 0.2 loop
    play fx3 car_high_speed fadein 0.3
    scene gg_act1_scene1_video6
    $ renpy.pause(delay=1.1, hard=True)
    stop fx3 fadeout 0.3
    scene 10_mc_1_day_mchome with fade
    $ renpy.pause(delay=1, hard=True)
    scene 11_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.7, hard=True)
    scene 12_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.7, hard=True)
    scene 13_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.7, hard=True)
    scene 14_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.7, hard=True)
    scene 15_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.7, hard=True)
    scene 16_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.7, hard=True)
    scene 17_mc_1_day_mchome
    $ renpy.pause(delay=0.7, hard=True)
    scene 18_mc_1_day_mchome
    $ renpy.pause(delay=0.7, hard=True)
    scene 19_mc_1_day_mchome
    $ renpy.pause(delay=0.7, hard=True)
    scene 20_mc_1_day_mchome
    $ renpy.pause(delay=0.7, hard=True)
    stop ambient fadeout 0.3
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)
    play ambient light_city_ambient fadein 1 fadeout 0.2 loop volume 0.5
    $ renpy.pause(delay=1, hard=True)
    scene 1_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=3, hard=True)
    scene 2_mc_1_day_mchome
    play sound alarm
    $ renpy.pause(delay=1, hard=True)
    scene gg_act1_scene1_video1 with dissolve
    $ renpy.pause(delay=0.7, hard=True)
    play sound lighthittable
    $ renpy.pause(delay=2, hard=True)
    scene 3_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 4_mc_1_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 5_mc_1_day_mchome with dissolve
    stop ambient
    stop music
    play fx1 black_scree_hit
    scene black
    $ renpy.pause(delay=1, hard=True)
    stop fx1 fadeout 3
    play fx2 time_ticks_1min fadein 1
    $ renpy.pause(delay=1, hard=True)
    scene 1_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 3_mc_2_day_mchome with dissolve
    gg "Чёрт . . . конец месяца"
    scene 4_mc_2_day_mchome with dissolve
    gg "Скоро платить по долгам . . ."
    scene 5_mc_2_day_mchome with dissolve
    gg "Ладно . . . хоть сегодня выходной"
    gg "Хоть что-то"
    scene 6_mc_2_day_mchome with dissolve
    gg "Может, хоть пару часов отдохну. . . {w}просто расслаблюсь"
    stop fx2 fadeout 1
    scene 7_mc_2_day_mchome with dissolve
    pause
    play sound mouse_click
    scene 8_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play fx1 steam_notification volume 0.3
    scene 9_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Ну хоть здесь кто-то есть . . ."
    scene black with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene 10_mc_2_day_mchome with dissolve
    gg "Найс, я их разнес"
    scene 11_mc_2_day_mchome with dissolve
    gg "Ладно . . . бывает"
    gg "Следующая будет норм"
    scene 12_mc_2_day_mchome with dissolve
    play sound aghbreathe
    $ renpy.pause(delay=2, hard=True)
    gg "бляя . . ."
    scene 13_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 14_mc_2_day_mchome with dissolve
    gg "вот суки"
    gg "Окей ладно супер последняя на победу"
    play sound hit_table_2
    play music mc_despair loop
    scene 15_mc_2_day_mchome
    gg "{sc}{size=*1.5}СУКА!{/size}{/sc}" with vpunch
    scene 16_mc_2_day_mchome with dissolve
    pause
    play sound mouse_click
    scene 17_mc_2_day_mchome with dissolve
    gg "Да пошло оно всё . . ."
    gg "Какая же трата времени"
    scene 18_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=2, hard=True)
    gg "Выходной . . . единственный день . . ."
    gg "И я просто убил его на эту грёбаную игру"
    scene 19_mc_2_day_mchome with dissolve
    gg "Экран это единственное с чем я общаюсь последнее время"
    scene 20_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 21_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 22_mc_2_day_mchome with dissolve
    gg "Я живу здесь . . . но эта квартира"
    gg "Просто точка между работой и снова работой"
    scene 23_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 25_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 26_mc_2_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 27_mc_2_day_mchome with dissolve
    gg "Только там . . ."
    scene 28_mc_2_day_mchome with dissolve
    gg "Я чувствовал себя живым"
    scene 24_mc_2_day_mchome with dissolve
    gg "Я . . . устал так жить"
    scene black with dissolve
    $ renpy.pause(delay=2, hard=True)

    scene gg_act1_scene1_video7 with dissolve
    play fx1 steps
    $ renpy.pause(delay=1.5, hard=True)
    stop fx1 fadeout 0.3
    scene gg_act1_scene1_video8
    play fx2 knocknewscene
    $ renpy.pause(delay=1, hard=True)
    stop fx2 fadeout 0.2
    scene black
    $ renpy.pause(delay=1, hard=True)
    scene 1_mc_4_day_mchome with in_eye
    $ renpy.pause(delay=2, hard=True)
    scene 2_mc_4_day_mchome with dissolve
    play fx2 knocknewscene
    $ renpy.pause(delay=1, hard=True)
    scene 3_mc_4_day_mchome with dissolve
    stop music fadeout 2 
    gg "Да иду я, иду . . ."
    play sound wake
    $ renpy.pause(delay=3, hard=True)
    scene 4_mc_4_day_mchome with dissolve
    gg "Кто там?"
    play sound opendoor
    play music mc_everyday fadein 1 fadeout 0.2 loop
    scene gg_act1_scene1_video9 with dissolve
    pause
    scene 5_mc_4_day_mchome with dissolve
    gg "Ты кто?"
    scene 6_mc_4_day_mchome with dissolve
    PostMan "Я почтальон"
    scene 5_mc_4_day_mchome with dissolve
    gg "Почтальоны теперь так одеваются?"
    scene 7_mc_4_day_mchome with dissolve
    PostMan "Вот смотри для тебя нарисовали"
    scene 8_mc_4_day_mchome with dissolve
    PostMan "А я одеваюсь как хочу"
    gg "Так а посылка?"
    scene 9_mc_4_day_mchome with dissolve
    PostMan "А! сейчас"
    scene 10_mc_4_day_mchome with dissolve
    PostMan "Вот, ты же [povname] правильно?"
    scene 11_mc_4_day_mchome with dissolve
    gg "Да, спасибо"
    scene 12_mc_4_day_mchome with dissolve
    PostMan "Доставка уже оплачена, так что до свидания"
    scene 13_mc_4_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound closedoor
    scene 14_mc_4_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 15_mc_4_day_mchome with dissolve
    gg_chat "Эта квартира слишком дорого мне обходится"
    scene 16_mc_4_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 17_mc_4_day_mchome with dissolve
    gg_chat "Эти долги меня скоро сьедят"
    scene 18_mc_4_day_mchome with dissolve
    scene 19_mc_4_day_mchome with dissolve
    gg_chat "Что? {w}Линда?"
    scene black with dissolve 
    $ renpy.pause(delay=1, hard=True)
    play sound openmail
    $ renpy.pause(delay=1.5, hard=True)
    gg_chat "От бабушки . . ."
    scene 20_mc_4_day_mchome with dissolve
    gg_chat "Давно не видел её . . ."
    gg_chat "Зачем она мне это?"
    "Дорогой мой, [povname]"
    "Пишу тебе это письмо с особым волнением — не потому, что что-то случилось"
    "А потому, что скоро мне предстоит небольшое, но долгое путешествие"
    "С тех пор, как ты уехал, тут многое стало тише, спокойнее"
    "Но рядом всё ещё живут хорошие люди — кто-то поможет, если нужно, кто-то просто заглянет поболтать"
    "Дом, в котором ты вырос летом, скоро останется без хозяйки . . ."
    "И мне очень бы не хотелось, чтобы он начал ветшать"
    scene 21_mc_4_day_mchome with dissolve
    "Я уезжаю на несколько лет — не волнуйся, здоровье моё в порядке, просто пришло время пожить немного иначе"
    "Пока меня не будет, хочу тебя попросить заглядывать в дом"
    "Пусть не пустеет, пусть скрипят половицы, пусть греется чайник"
    "Он живой, наш дом — если забросить, начнёт хандрить"
    gg "Она всегда так говорила . . . {w}будто дом — живой"
    scene 22_mc_4_day_mchome with dissolve
    "И ещё . . . цветы"
    "Мои две любимые. Они остались"
    "Одна крепкая, корнями в землю, упрямая, немного колючая, зато как зацветёт — всем на удивление"
    "Вторая — лёгкая, солнечная, смеётся даже в дождь, растёт, куда глянет, и всё ей в радость"
    scene 23_mc_4_day_mchome with dissolve
    gg_chat "Причем здесь цветы вообще . . ."
    "Уход у них разный, но суть одна — внимание"
    "Ты справишься — у тебя ведь моё упрямство и моё сердце"
    "Очень хочу, чтобы ты оказался там пораньше — дом ждёт тебя"
    "С любовью"
    "Твоя бабушка Линда"
    scene 20_mc_4_day_mchome with dissolve
    gg_chat "Бабушка была всегда рядом, её дом был моим домом"
    play fx1 time_ticks_1min fadein 0.3
    scene 24_mc_4_day_mchome with dissolve
    gg_chat "Зачем она меня просит присматривать за домом?"
    scene 25_mc_4_day_mchome with dissolve
    gg_chat "Просто взять и уехать?"
    scene 26_mc_4_day_mchome with dissolve
    gg_chat "Будто у меня тут ничего нет"
    scene 27_mc_4_day_mchome with dissolve
    gg_chat "У меня своих проблем по горло"
    scene 28_mc_4_day_mchome with dissolve
    gg_chat "Чёрт, я опаздываю"
    play fx2 hungry_sounds
    scene 29_mc_4_day_mchome with dissolve
    $ renpy.pause(delay=1.5, hard=True)
    gg_chat "Потом поем"
    scene 30_mc_4_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 31_mc_4_day_mchome with dissolve
    gg_chat "Я отвечу попозже, бабушка"
    stop fx1 fadeout 1
    scene black with dissolve
    play sound closedoor2
    $ renpy.pause(delay=1, hard=True)
    play ambient bus_amb fadein 1 loop
    $ renpy.pause(delay=1, hard=True)
    scene gg_act1_scene1_video10 with dissolve
    pause
    scene 1_mc_6_day_mchome with dissolve 
    gg_chat "Серьёзно? . . ."
    scene gg_act1_scene1_video11 with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene gg_act1_scene1_video10 with dissolve
    gg_chat "Блять . . ."
    gg_chat "Как всегда"
    scene black with dissolve
    stop music fadeout 0.4
    $ renpy.pause(delay=0.4, hard=True)
    play music mc_office loop fadein 0.3
    $ renpy.pause(delay=0.6, hard=True)
    stop ambient fadeout 0.7
    $ renpy.pause(delay=0.7, hard=True)
    play ambient office_amb fadein 0.4 loop
    $ renpy.pause(delay=0.4, hard=True)
    scene gg_act1_scene1_video12 with dissolve
    gg "Я пришел"
    scene gg_act1_scene1_video13 with dissolve
    Assistant "Опоздал. Как всегда"
    scene 2_mc_6_day_mchome with dissolve 
    Assistant "И напомню: если продолжишь, {w}то разговор о снижении зарплаты — это уже вопрос времени"
    scene 3_mc_6_day_mchome with dissolve 
    gg_chat "Да, конечно"
    scene 4_mc_6_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 5_mc_6_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 6_mc_6_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound closedoor 
    scene 7_mc_6_day_mchome with dissolve
    Director "Это срочно"
    scene 8_mc_6_day_mchome with dissolve
    Director "За Петрова сделаешь"
    scene 9_mc_6_day_mchome with dissolve
    gg "Это не мои задачи"
    gg "Почему я должен работать за другого"
    scene 10_mc_6_day_mchome with dissolve
    Director "Мне плевать"
    scene 11_mc_6_day_mchome with dissolve
    Director"Сделаешь всё до конца недели"
    scene 12_mc_6_day_mchome with dissolve
    $ renpy.pause(delay=2, hard=True) 
    Director"Не успеешь — сам знаешь последствия"
    $ renpy.pause(delay=2, hard=True) 
    play sound hit_table
    scene 13_mc_6_day_mchome with hpunch
    $ renpy.pause(delay=1, hard=True) 
    gg_chat "Им всегда плевать"
    gg_chat "Я здесь просто расходник"
    scene black with dissolve
    stop ambient fadeout 1
    $ renpy.pause(delay=1, hard=True) 
    play fx3 office_clock_amb loop fadein 0.3
    $ renpy.pause(delay=1, hard=True) 
    scene 1_mc_7_day_mchome with dissolve 
    gg_chat "Сколько ни работай, этому нет конца"
    $ renpy.pause(delay=1, hard=True) 
    scene 2_mc_7_day_mchome with dissolve 
    $ renpy.pause(delay=1, hard=True) 
    scene 1_mc_7_day_mchome with dissolve 
    $ renpy.pause(delay=1, hard=True) 
    scene 2_mc_7_day_mchome with dissolve 
    $ renpy.pause(delay=1, hard=True) 
    scene 1_mc_7_day_mchome with dissolve 
    play sound closedoor
    $ renpy.pause(delay=2, hard=True) 
    play sound faststeps
    $ renpy.pause(delay=1.5, hard=True) 
    Director "Секретарша сказала"
    $ renpy.pause(delay=1, hard=True)
    scene 3_mc_7_day_mchome with dissolve 
    Director "Что ты опоздал"
    scene 4_mc_7_day_mchome with dissolve
    Director "Если не сдашь это в срок"
    Director "Можешь искать новую работу"
    scene 5_mc_7_day_mchome with dissolve
    Director "Понял?"
    gg_chat "Вот сука"
    scene 6_mc_7_day_mchome with dissolve
    gg "Да"
    scene 7_mc_7_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 8_mc_7_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 9_mc_7_day_mchome with dissolve
    play sound "audio/wake.mp3"
    $ renpy.pause(delay=2, hard=True) 
    gg_chat "Да пошло оно все"
    scene 10_mc_7_day_mchome with dissolve
    gg_chat "С меня довольно"
    scene 11_mc_7_day_mchome with dissolve
    gg_chat "Не поспешил ли я?"
    scene 12_mc_7_day_mchome with dissolve
    gg_chat "Хватит"
    scene 13_mc_7_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    stop fx3 fadeout 0.2
    scene 14_mc_7_day_mchome with dissolve
    play sound opendoor
    $ renpy.pause(delay=1, hard=True) 
    play sound faststeps
    $ renpy.pause(delay=2, hard=True) 
    scene 15_mc_7_day_mchome with dissolve
    Director "Ты вообще что делаешь"
    scene 16_mc_7_day_mchome with dissolve
    gg "Я увольняюсь"
    scene 14_mc_7_day_mchome with dissolve
    Director "Как ты смеешь??"
    menu:
        "Послать нахуй":
            scene 17_mc_7_day_mchome with dissolve
        "Молча уйти":
            scene black with dissolve
    $ renpy.pause(delay=1, hard=True) 
    scene 18_mc_7_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 19_mc_7_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 20_mc_7_day_mchome with dissolve
    Assistant "Ой"
    scene 21_mc_7_day_mchome with dissolve
    Assistant "Ты что делаешь!?"
    gg "Счастливо оставаться"
    stop music fadeout 1
    play ambient light_city_ambient loop fadein 1
    $ renpy.pause(delay=1, hard=True) 
    play music mc_freedom loop fadein 1
    scene 22_mc_7_day_mchome with dissolve
    gg_chat "Наконец-то"
    scene 23_mc_7_day_mchome with dissolve
    gg_chat "Моя привычная жизнь закончилась"
    $ renpy.pause(delay=1, hard=True) 
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True) 
    gg_chat "На улице столько парочек гуляет"
    gg_chat "Жизнь будто проходит мимо"
    scene 1_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 2_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play fx1 heavy_bag_drop 
    scene 3_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 4_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 5_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 6_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 7_mc_8_day_mchome with dissolve
    gg_chat "Я даже не заметил"
    play fx2 key_handling
    scene 8_mc_8_day_mchome with dissolve
    gg_chat "Только у моего родного дома был такой ключ"
    scene 9_mc_8_day_mchome with dissolve
    gg_chat "Это шанс"
    stop ambient fadeout 0.5
    gg_chat "На новую жизнь"
    scene 10_mc_8_day_mchome with dissolve
    gg_chat "Это все мне больше не нужно"
    scene 11_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 12_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 13_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 14_mc_8_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 15_mc_8_day_mchome with dissolve
    gg_chat "Пора начать сначала"
    scene black with out_eye
    stop music fadeout 1
    $ renpy.pause(delay=1, hard=True) 
    play music mc_village loop fadein 1
    $ renpy.pause(delay=2, hard=True)
    play sound train_doors fadein 0.5 fadeout 1
    scene gg_act1_scene2_video1 with dissolve
    $ renpy.pause(delay=1.3, hard=True)
    play ambient village_amb loop fadein 1
    $ renpy.pause(delay=1, hard=True)
    scene gg_act1_scene2_video2 with dissolve
    $ renpy.pause(delay=15, hard=True)
    scene black with dissolve
    gg_chat "После города — будто другой мир"
    scene 1_mc_9_day_mchome with dissolve
    gg_chat "Даже к этому я отвык . . ."
    scene 2_mc_9_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 3_mc_9_day_mchome with dissolve
    gg_chat "Мне здесь придётся многому научиться"
    scene black with out_eye
    $ renpy.pause(delay=1, hard=True) 
    gg_chat "Я даже позабыл где дом . . ."
    $ renpy.pause(delay=2, hard=True) 
    gg_chat "Все, кого я вижу, со мной здороваются"
    gg_chat "Будто я тут не чужой"
    UnknownGirl "Эй парень, постой-ка!"
    scene gg_act1_scene2_video3 with dissolve
    gg "Здравствуйте"
    scene 1_mc_10_day_mchome with dissolve
    UnknownGirl "Давно тут новых лиц не видели"
    scene 2_mc_10_day_mchome with dissolve
    gg "Да только приехал"
    scene 3_mc_10_day_mchome with dissolve
    UnknownGirl "У нас тут новым людям всегда рады"
    scene 4_mc_10_day_mchome with dissolve
    UnknownGirl "Только вот"
    UnknownGirl "Настоящих мужчин не хватает"
    scene gg_act1_scene2_video4 with dissolve
    pause
    gg_chat "Что она вообще имеет в виду?"
    scene 5_mc_10_day_mchome with dissolve
    UnknownGirl "Ладно, не пугайся. Шучу"
    scene 6_mc_10_day_mchome with dissolve
    UnknownGirl "Если что-то нужно будет, спрашивай помощь у любого"
    scene 7_mc_10_day_mchome with dissolve
    UnknownGirl "Удачи тебе"
    scene 8_mc_10_day_mchome with dissolve
    gg "Хорошо и Вам отличного дня"
    scene black with dissolve
    gg_chat "Какая необычно добрая девушка"
    gg_chat "Бабушка, похоже, говорила правду о людях здесь"
    $ renpy.pause(delay=0.5, hard=True)
    stop music fadeout 1
    call next_time_startup
    stop ambient fadeout 1
    $ renpy.pause(delay=1, hard=True)
    play music mc_firstday_home fadeout 3
    scene 1_mc_11_day_mchome with dissolve
    gg_chat "А если там уже не так, как я помню?"
    scene 2_mc_11_day_mchome with dissolve
    gg_chat "Но назад пути нет"
    scene 3_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound "door ruchka.mp3" 
    scene 4_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 5_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 6_mc_11_day_mchome with dissolve
    gg_chat "Да, дом поменялся"
    play sound shower_sound fadein 3 volume 0.3
    scene 7_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 8_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=1, hard=True) 
    scene 9_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    
    scene 10_mc_11_day_mchome with dissolve
    gg_chat "Здесь кто-то есть?"
    scene 12_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=2, hard=True) 
    stop sound fadeout 1
    $ renpy.pause(delay=1, hard=True) 
    play fx1 opendoor volume 0.5
    scene 13_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 14_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene gg_act1_scene3_video1 with dissolve 
    $ renpy.pause(delay=0.5, hard=True) 
    gg ". . ."
    pause
    scene gg_act1_scene3_video2 with dissolve 
    pause
    scene gg_act1_scene3_video3 with dissolve 
    $ renpy.pause(delay=4, hard=True) 
    Sonya "АААА!"
    scene 16_mc_11_day_mchome with dissolve
    Sonya "МАЯ!"
    scene 17_mc_11_day_mchome with dissolve
    Sonya "МАЯ, ТУТ КТО-ТО ЕСТЬ!!"
    play fx1 closedoor3 volume 0.8
    scene 18_mc_11_day_mchome with hpunch
    $ renpy.pause(delay=2, hard=True)
    stop fx1 fadeout 0.2
    gg_chat "Что это сейчас было? . . ."
    scene 18_mc_11_day_mchome with dissolve
    gg_chat "Я . . ."
    scene 19_mc_11_day_mchome with dissolve
    gg_chat "Я ничего не понял"
    play fx1 faststeps
    $ renpy.pause(delay=2, hard=True)
    play fx2 doorloadclose
    scene 20_mc_11_day_mchome with hpunch
    Maya "Ты кто такой?"
    scene 21_mc_11_day_mchome with dissolve
    Maya "Убирайся отсюда. Сейчас же"
    scene 22_mc_11_day_mchome with dissolve
    gg "Стой, подожди"
    scene 23_mc_11_day_mchome with dissolve
    gg "Я внук хозяйки дома"
    scene 24_mc_11_day_mchome with dissolve
    gg "Это дом моей бабушки"
    scene 25_mc_11_day_mchome with dissolve
    Maya "Внук?"
    scene 26_mc_11_day_mchome with dissolve
    Maya "Что-то я такого внука никогда здесь не видела"
    scene 27_mc_11_day_mchome with dissolve
    Maya "Думаешь я совсем тупая"
    scene 28_mc_11_day_mchome with dissolve
    gg "Подожди"
    scene 29_mc_11_day_mchome with dissolve
    gg "Я не знал, что здесь кто-то живёт"
    scene 30_mc_11_day_mchome with dissolve
    Maya "Конечно не знал"
    scene 31_mc_11_day_mchome with dissolve
    Maya "А в чужие дома ты тоже «случайно» заходишь?"
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)
    play sound "mail swap.mp3"
    $ renpy.pause(delay=1, hard=True)
    scene 32_mc_11_day_mchome with dissolve
    gg "Вот"
    scene 33_mc_11_day_mchome with dissolve
    gg "Это письмо от моей бабушки"
    scene 34_mc_11_day_mchome with dissolve
    gg "Она попросила меня присмотреть за домом"
    scene 35_mc_11_day_mchome with dissolve
    Maya "И ты думаешь, я просто поверю этой бумажке?"
    scene 36_mc_11_day_mchome with dissolve
    gg "Я никуда не спешу"
    scene 37_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 38_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    play sound beathdown
    $ renpy.pause(delay=0.5, hard=True) 
    scene 39_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 40_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 41_mc_11_day_mchome with dissolve
    Maya "Дорогой"
    scene 42_mc_11_day_mchome with dissolve
    Maya "[povname]"
    scene 43_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 44_mc_11_day_mchome with dissolve
    Maya "Скоро останется без хозяйки"
    scene 45_mc_11_day_mchome with dissolve
    Maya "Уезжаю на несколько лет"
    scene 46_mc_11_day_mchome with dissolve
    Maya "Мои цветочки любимые. Они остались"
    scene 47_mc_11_day_mchome with dissolve
    Maya "Дом ждёт тебя"
    scene 48_mc_11_day_mchome with dissolve
    Maya "Твоя бабушка Линда"
    scene 49_mc_11_day_mchome with dissolve
    play sound beathdown
    $ renpy.pause(delay=1, hard=True) 
    scene 50_mc_11_day_mchome with dissolve
    Maya "Боже, ладно"
    Maya "Похоже на правду"
    scene 51_mc_11_day_mchome with dissolve
    Maya "Но это ничего не меняет"
    scene 52_mc_11_day_mchome with dissolve
    Maya "Ты здесь чужой"
    scene 53_mc_11_day_mchome with dissolve
    gg "Вообще-то это мой дом"
    scene 54_mc_11_day_mchome with dissolve
    Maya "Это мы с Соней решим!"
    scene 55_mc_11_day_mchome with dissolve
    Maya "{sc}{size=*1.5}СОНЯ{/sc}" with hpunch
    scene 56_mc_11_day_mchome with dissolve
    Maya "Всё нормально, он не опасный"
    scene 57_mc_11_day_mchome with dissolve
    gg "Я так и сказал"
    scene 58_mc_11_day_mchome with dissolve
    Maya "Слушай, если ты хоть что-то сделаешь"
    scene 59_mc_11_day_mchome with dissolve
    Maya "Я тебя мигом выгоню. Понял?"
    scene 60_mc_11_day_mchome with dissolve
    gg "Понял"
    scene 61_mc_11_day_mchome with dissolve
    Maya "Жди на кухне я передам письмо соне"
    scene 62_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene 63_mc_11_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    scene black with dissolve
    $ renpy.pause(delay=0.5, hard=True) 
    gg_chat "Вот это встреча"
    $ renpy.pause(delay=0.5, hard=True)
    call next_time_startup
    play music "audio/soundtracks/%s.mp3" % current_time fadein 5 fadeout 0.5 loop
    scene 1_mc_12_day_mchome with dissolve
    gg_chat "Я не ожидал такого"
    scene 2_mc_12_day_mchome with dissolve
    gg_chat "Почему бабушка ничего не сказала?"
    scene 1_mc_12_day_mchome with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 3_mc_12_day_mchome with dissolve
    play sound opendoor volume 0.3
    $ renpy.pause(delay=1, hard=True)
    scene 4_mc_12_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 5_mc_12_day_mchome with dissolve
    Sonya "Эм . . . привет"
    scene 6_mc_12_day_mchome with dissolve
    Sonya "Я . . . я Соня"
    scene 7_mc_12_day_mchome with dissolve
    Sonya "Я надеюсь ты не обиделся на Маю"
    scene 8_mc_12_day_mchome with dissolve
    gg "Нет. Всё нормально"
    scene 9_mc_12_day_mchome with dissolve
    gg "Я [povname]"
    scene 10_mc_12_day_mchome with dissolve
    Sonya "Мая сказала, что ты внук Линды"
    Sonya "Так . . . неожиданно получилось"
    scene 12_mc_12_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play fx2 light_switch 
    scene 13_mc_12_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    Sonya "И если честно"
    scene 14_mc_12_day_mchome with dissolve
    Sonya "Я сначала очень испугалась"
    scene 15_mc_12_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 16_mc_12_day_mchome with dissolve
    gg "Извини"
    scene 17_mc_12_day_mchome with dissolve
    gg "Я правда не хотел тебя пугать, стоило постучать"
    scene 18_mc_12_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 19_mc_12_day_mchome with dissolve
    Sonya "Нет-нет, всё нормально"
    scene 20_mc_12_day_mchome with dissolve
    Sonya "Просто не ожидали гостей"
    scene gg_act1_scene3_video4 with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene 21_mc_12_day_mchome with dissolve
    Sonya "Я прочла письмо Линды"
    scene 22_mc_12_day_mchome with dissolve
    Sonya "Там про цветы было"
    scene 23_mc_12_day_mchome with dissolve
    Sonya "Она всегда нас так называла"
    scene 24_mc_12_day_mchome with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 25_mc_12_day_mchome with dissolve
    Sonya "Мы с Маей живём здесь вместе"
    scene 26_mc_12_day_mchome with dissolve
    Sonya "Линда сначала просто сдавала нам комнаты"
    scene 27_mc_12_day_mchome with dissolve
    Sonya "А потом, когда уехала, сказала, что дом остаётся на нас"
    scene 28_mc_12_day_mchome with dissolve
    gg "То есть вы тут уже давно?"
    scene 29_mc_12_day_mchome with dissolve
    Sonya "Да"
    scene 30_mc_12_day_mchome with dissolve
    Sonya "Мы привыкли. Даже кота завели"
    scene 31_mc_12_day_mchome with dissolve
    Sonya "Это место для нас стало родным"
    scene 32_mc_12_day_mchome with dissolve
    Sonya "Линда иногда о тебе говорила"
    scene 33_mc_12_day_mchome with dissolve
    Sonya "Говорила, что ты хороший, по крайней мере в детстве"
    scene 34_mc_12_day_mchome with dissolve
    gg "Надеюсь, она не слишком приукрашивала"
    scene 35_mc_12_day_mchome with dissolve
    gg "Сейчас я сам не знаю, кем стал"
    scene 36_mc_12_day_mchome with dissolve
    Sonya "А ты . . ."
    scene 37_mc_12_day_mchome with dissolve
    Sonya "Ты надолго?"
    scene 38_mc_12_day_mchome with dissolve
    Sonya "Ну, какой у тебя дальше план?"
    scene 39_mc_12_day_mchome with dissolve
    gg "Я пока не знаю"
    scene 40_mc_12_day_mchome with dissolve
    gg "Мне нужно время"
    scene 41_mc_12_day_mchome with dissolve
    gg_chat "Хотя здесь приятно"
    scene gg_act1_scene3_video5 with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg_chat "И как-то спокойно"
    scene 42_mc_12_day_mchome with dissolve
    Sonya "Уже поздно"
    scene 43_mc_12_day_mchome with dissolve
    Sonya "Если захочешь мы еще поговорим"
    scene 44_mc_12_day_mchome with dissolve
    Sonya "А пока ты можешь лечь в зале"
    scene 45_mc_12_day_mchome with dissolve
    Sonya "Других мест спальных у нас нету"
    scene 46_mc_12_day_mchome with dissolve
    gg "Да, хорошо"
    scene 47_mc_12_day_mchome with dissolve
    gg "Спасибо за теплый прием"
    scene 48_mc_12_day_mchome with dissolve
    Sonya "Я положу все необходимое  на диван"
    scene 49_mc_12_day_mchome with dissolve
    gg_chat "Похоже, пока я могу здесь остаться"
    call next_time_startup
    $ current_label = "scene13"
    scene black with out_eye
    gg_chat "Я так устал за этот день"
    gg_chat "Пора отдыхать"
    "Ночью можно отдохнуть — нажми на кровать, чтобы начать новый день"
    play music "audio/soundtracks/%s.mp3" % current_time fadein 0.5 fadeout 0.5 loop
    $ renpy.transition(dissolve)
    jump myroom 
    return

label gg_first_morning: 
    $ hide_screens()
    play ambient village_amb loop fadein 0.5
    $ renpy.pause(delay=1, hard=True)
    scene 1_mc_13_day_mchome with in_eye 
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_mc_13_day_mchome with dissolve 
    gg_chat "Утро"
    scene 3_mc_13_day_mchome with dissolve 
    gg_chat "Давно я так не просыпался"
    scene 4_mc_13_day_mchome with dissolve 
    gg_chat "Никакой работы"
    scene 5_mc_13_day_mchome with dissolve 
    gg_chat "Никакого давления"
    scene 6_mc_13_day_mchome with dissolve 
    gg_chat "Природа"
    scene 7_mc_13_day_mchome with dissolve 
    gg_chat "Здесь я свободен"
    stop ambient fadeout 0.5
    scene 8_mc_13_day_mchome with dissolve 
    gg_chat "В городе я жил как белка в колесе"
    scene 9_mc_13_day_mchome with dissolve 
    gg_chat "Не жизнь, а выживание"
    scene 10_mc_13_day_mchome with dissolve 
    gg_chat "Эх, как же мне не хватало свободы"
    gg_chat "Кажется, я останусь"
    scene 11_mc_13_day_mchome with dissolve 
    gg_chat "Дорогой бабушке . . ."
    gg_chat "Спасибо, похоже, я нашёл то, чего мне не хватало"
    scene 12_mc_13_day_mchome with dissolve 
    gg_chat "Моя жизнь меняется"
    scene 13_mc_13_day_mchome with dissolve 
    gg_chat "Посмотрим, что из этого выйдет"
    jump gg_first_morning_kitchen
    return

label gg_first_morning_kitchen:
    $ hide_screens()
    scene 1_mc_1_day_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play fx1 light_switch
    scene 2_mc_1_day_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 3_mc_1_day_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 4_mc_1_day_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 5_mc_1_day_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 6_mc_1_day_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 7_mc_1_day_kitchen with dissolve
    gg_chat "Можно просто сидеть"
    gg_chat "Никуда не спешить"
    scene 8_mc_1_day_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 7_mc_1_day_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 9_mc_1_day_kitchen with dissolve
    gg_chat "Обычно меня раздражает мытье посуды. А тут даже приятно"
    scene 10_mc_1_day_kitchen with dissolve
    gg_chat "Нужно будет всё здесь изучить"
    scene 11_mc_1_day_kitchen with dissolve
    gg_chat "Хочу понять, как здесь живут"
    gg_chat "Как всё устроено"
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg_chat "Это теперь мой новый дом"
    $ renpy.pause(delay=1, hard=True)
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("kitchen")
    return

label gg_first_day_bathroom:
    $ hide_screens()
    scene 1_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play sound opendoor
    scene 2_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 3_mc_3_day_bathroom with dissolve
    Sonya "Ой"
    scene 4_mc_3_day_bathroom with dissolve
    Sonya "Я не думала, что ты сейчас зайдешь"
    Sonya "Хотела прибраться"
    scene 5_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 6_mc_3_day_bathroom with dissolve
    Sonya "Ты хотел в душ?"
    scene 7_mc_3_day_bathroom with dissolve
    Sonya "Я сейчас закончу"
    scene 8_mc_3_day_bathroom with dissolve
    gg "Нет, всё нормально"
    gg "Я подожду"
    scene 9_mc_3_day_bathroom with dissolve
    gg "Если тебе нужна помощь — скажи"
    scene 10_mc_3_day_bathroom with dissolve
    Sonya "Правда?"
    scene 11_mc_3_day_bathroom with dissolve
    Sonya "Ты не обязан, я просто"
    scene 12_mc_3_day_bathroom with dissolve
    Sonya "Ну, если тебе не сложно"
    scene 13_mc_3_day_bathroom with dissolve
    Sonya "Можешь тогда разложить вещи для стирки"
    scene 14_mc_3_day_bathroom with dissolve
    Sonya "Потом сложи, что уже высохло"
    scene 15_mc_3_day_bathroom with dissolve
    Sonya "Отнесу я сама"
    scene 16_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene gg_act2_scene3_video1 with dissolve
    pause 
    scene 17_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 18_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=1.0, hard=True)
    scene 19_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 20_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=1.0, hard=True)
    scene 21_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=1.0, hard=True)
    scene 22_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 23_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene 24_mc_3_day_bathroom with dissolve
    gg_chat "Как будто мы тут давно живём"
    scene 25_mc_3_day_bathroom with dissolve
    Sonya "Мне чуть чуть осталось"
    scene 26_mc_3_day_bathroom with dissolve
    Sonya "Обычно в доме только я убираюсь"
    scene 27_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 28_mc_3_day_bathroom with dissolve
    Sonya "А . . ."
    Sonya "Ты наверное хочешь в душ"
    scene 29_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 30_mc_3_day_bathroom with dissolve
    Sonya "Полотенца сейчас у меня в комнате"
    scene 31_mc_3_day_bathroom with dissolve
    Sonya "Мы можем сходить туда, если хочешь"
    scene 32_mc_3_day_bathroom with dissolve
    gg "Пойдем"
    scene 33_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 34_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 35_mc_3_day_bathroom with dissolve
    gg_chat "Как сильно поменялись комнаты"
    scene 36_mc_3_day_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 37_mc_3_day_bathroom with dissolve
    Sonya "Вот"
    scene 38_mc_3_day_bathroom with dissolve
    Sonya "Если что, там ещё есть"
    scene 39_mc_3_day_bathroom with dissolve
    Sonya "Ээ... нуу приятного купания"
    scene 40_mc_3_day_bathroom with dissolve
    gg "А, да, спасибо"
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg_chat "Оказывается, для уюта нужно совсем немного"
    $ renpy.pause(delay=1, hard=True)
    play fx1 shower_sound fadein 0.5
    $ renpy.pause(delay=3, hard=True)
    stop fx1 fadeout 0.5
    $ renpy.pause(delay=1, hard=True)

    $ end_demo = True
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("myroom")
    return

label gg_first_morning_mayaroom:
    $ hide_screens()
    scene 1_mc_2_day_mroom with dissolve
    Maya "Барси!"
    scene 2_mc_2_day_mroom with dissolve
    Maya "Барсик!"
    scene gg_act2_scene1_video1 with dissolve
    pause
    gg_chat "Что-то случилось?"
    $ renpy.pause(delay=1, hard=True)
    scene gg_act2_scene1_video2 with dissolve
    pause
    gg_chat "Лучше ей не мешать . . ."
    $ renpy.pause(delay=1, hard=True)
    play sound closedoor2 volume 0.3
    scene 4_mc_2_day_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 5_mc_2_day_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Стоп"
    play sound closedoor2 volume 0.5
    scene 6_mc_2_day_mroom with dissolve
    Maya "Ты кота не видел?"
    scene 7_mc_2_day_mroom with dissolve
    gg "Нет"
    scene 8_mc_2_day_mroom with dissolve
    gg "Но могу помочь"
    scene 9_mc_2_day_mroom with dissolve
    Maya "Твоя помощь мне не нужна"
    scene 10_mc_2_day_mroom with dissolve
    Maya "Хотя, если будешь молчать — помогай"
    scene 11_mc_2_day_mroom with dissolve
    gg_chat "Это так на помощь соглашаются"
    scene 12_mc_2_day_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene gg_act2_scene1_video3 with dissolve
    pause
    Maya "Ты где барсииик"
    $ renpy.pause(delay=1, hard=True)
    scene 13_mc_2_day_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)
    play sound catmya
    $ renpy.pause(delay=1, hard=True)
    scene 14_mc_2_day_mroom with dissolve
    gg_chat "Нашёлся"
    scene 15_mc_2_day_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 16_mc_2_day_mroom with dissolve
    gg_chat "Главное не разбудить"
    scene 17_mc_2_day_mroom with dissolve
    Maya "Всё хорошо"
    scene 18_mc_2_day_mroom with dissolve
    Maya "Я здесь барсик"
    play sound closedoor
    scene 19_mc_2_day_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Ты меня напугал"
    Maya "Глупый"
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg_chat "Она не совсем такая, какой кажется"
    $ gg_first_morning_mayaroom = True

    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("myroom")
    return

label kate_day_kitchen:
    $ hide_screens()

    scene 1_gg_1_morning_kitchen with dissolve
    Kate "Так, где у вас тут кофе прячут?"
    gg "Ты кто вообще?"
    scene 2_gg_1_morning_kitchen with dissolve
    Kate "О Привет"
    scene gg_morning_kitchen1 with dissolve
    pause
    Kate "Я Кейт"
    scene 3_gg_1_morning_kitchen with dissolve
    Kate "Не пугайся, я не вор"
    Kate "Просто кофе мне жизненно необходим"
    scene 4_gg_1_morning_kitchen with dissolve
    gg "Меня [povname] зовут"
    gg "Растворимый прям тут"
    scene 5_gg_1_morning_kitchen with dissolve
    Kate "О, спаситель!"
    scene 6_gg_1_morning_kitchen with dissolve
    Kate "Значит, ты и есть тот самый парень, который тут появился недавно?"
    scene 7_gg_1_morning_kitchen with dissolve
    gg "Судя по слухам — да, я"
    scene 8_gg_1_morning_kitchen with dissolve
    Kate "Мая рассказывала"
    scene 9_gg_1_morning_kitchen with dissolve
    Kate "Живёт с Соней давно, а потом появился ты"
    Kate "Интересная компания"
    scene 10_gg_1_morning_kitchen with dissolve
    gg "“Интересная” — мягко сказано"
    scene 14_gg_1_morning_kitchen with dissolve
    Kate "Серьёзно? Это растворимый?"
    scene 13_gg_1_morning_kitchen with dissolve
    gg "Ага"
    scene 14_gg_1_morning_kitchen with dissolve
    Kate "А ведь вкусно"
    Kate "Обычно от растворимого хочется заплакать"
    scene 15_gg_1_morning_kitchen with dissolve
    gg "Значит, я талантливый бариста"
    Kate "Или тебе повезло"
    scene 16_gg_1_morning_kitchen with dissolve
    Kate "Ну что, рассказывай, кто ты такой"
    scene 17_gg_1_morning_kitchen with dissolve
    gg "Обычно начинают с “как дела?”"
    scene 18_gg_1_morning_kitchen with dissolve
    Kate "Это скучно"
    scene 19_gg_1_morning_kitchen with dissolve
    Kate "Я сразу к сути. Ты кто: сосед, ухажёр, постоялец или просто [povname]"
    scene 20_gg_1_morning_kitchen with dissolve
    gg "Пусть будет просто [povname]"
    scene 21_gg_1_morning_kitchen with dissolve
    Kate "Значит, загадочный. Ладно, оставим интригу"
    $ renpy.pause(delay=1, hard=True)
    scene 22_gg_1_morning_kitchen with dissolve
    Kate "Тут уютно"
    Kate "Не думала, что Мая вообще когда-то научится жить без хаоса"
    play sound closedoor
    $ renpy.pause(delay=1, hard=True)
    scene 23_gg_1_morning_kitchen with dissolve
    Maya "Кейт! Ты тут"
    Maya "Я же сказала подожди меня!"
    scene 24_gg_1_morning_kitchen with dissolve
    Maya "Ага, ты уже познакомилась с этим балбесом"
    scene 25_gg_1_morning_kitchen with dissolve
    Kate "Да! И кофе у него отличный, между прочим"
    scene 26_gg_1_morning_kitchen with dissolve
    Maya "Хвалить не вздумай, зазнается. Нам пора"
    scene 27_gg_1_morning_kitchen with dissolve
    Kate "Спасибо за кофе, бариста"
    Kate "Ладно. Ещё увидимся"
    play sound faststeps
    $ renpy.pause(delay=1, hard=True)
    play sound closedoor

    $ Unlock_Kate = True
    $ gg_relations_main += 1
    call next_time_dialog
    $ renpy.jump("myroom")
    return


