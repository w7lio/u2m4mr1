label maya_scene1_evening_myroom:
    $ hide_screens()
    scene 1_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 2_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 tv_remote
    scene 3_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 4_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play fx1 tv_remote
    scene 5_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 6_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 tv_remote
    scene 7_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 8_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 9_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 tv_remote
    scene 10_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 11_maya_1_evening_livingroom with dissolve
    Maya "Да ты издеваешься"
    scene 12_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 13_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 14_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 15_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 16_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 drawer_open
    scene maya_act2_scene1_video1 with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Где они, блин"
    pause
    scene 17_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 18_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play fx1 tv_remote
    scene 19_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 20_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.3, hard=True)
    scene 21_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.3, hard=True)
    play fx1 plastic_drop
    scene 22_maya_1_evening_livingroom with hpunch
    Maya "Тьфу"
    scene 23_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 24_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 25_maya_1_evening_livingroom with dissolve
    Maya "Чё смотришь?"
    scene 26_maya_1_evening_livingroom with dissolve
    gg "Проверь плюс и минус"
    scene 27_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Проверяла"
    scene 28_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 29_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 30_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 31_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 32_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 tv_remote
    scene 33_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play music babymetal volume 0.3 fadein 0.5 fadeout 0.5
    scene 36_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene 34_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 35_maya_1_evening_livingroom with dissolve
    $ renpy.pause(delay=2, hard=True)

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label maya_scene2_day_mayaroom:
    $ hide_screens()
    play music babymetal volume 0.5 fadein 0.5 fadeout 0.5
    scene 1_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_maya_2_afternoon_mroom
    play fx1 knock_once
    $ renpy.pause(delay=0.3, hard=True)
    scene 1_maya_2_afternoon_mroom
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_maya_2_afternoon_mroom
    play fx1 knock_once
    $ renpy.pause(delay=1, hard=True)
    $ renpy.music.set_volume(0.2, delay=0.5, channel='music')
    $ renpy.pause(delay=1, hard=True)
    Maya "Кто там?"
    scene 3_maya_2_afternoon_mroom with dissolve
    gg "Это я. Можно зайти по делу?"
    Maya "Входи"
    play sound opendoor volume 0.3
    scene 4_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 5_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 6_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 7_maya_2_afternoon_mroom with dissolve
    gg "Музыку слушаешь?"
    scene 8_maya_2_afternoon_mroom with dissolve
    Maya "Нет, для соседей включила"
    scene 7_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 9_maya_2_afternoon_mroom with dissolve
    gg "Я решил, что останусь тут"
    scene 10_maya_2_afternoon_mroom with dissolve
    gg "Буду жить здесь"
    scene 11_maya_2_afternoon_mroom with dissolve
    Maya "Ну"
    scene 12_maya_2_afternoon_mroom with dissolve
    Maya "Соболезную"
    scene 13_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 14_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 15_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 16_maya_2_afternoon_mroom with dissolve
    Maya "Эй"
    scene 17_maya_2_afternoon_mroom with dissolve
    Maya "Дальше не надо"
    scene 18_maya_2_afternoon_mroom with dissolve
    gg "Я просто хотел"
    scene 19_maya_2_afternoon_mroom with dissolve
    Maya "Я всё услышала"
    scene 20_maya_2_afternoon_mroom with dissolve
    Maya "Мне пофиг, что ты тут живёшь"
    scene 21_maya_2_afternoon_mroom with dissolve
    Maya "Честно"
    scene 22_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 23_maya_2_afternoon_mroom with dissolve
    Maya "Но давай без этого"
    scene 24_maya_2_afternoon_mroom with dissolve
    gg "Без чего?"
    scene 25_maya_2_afternoon_mroom with dissolve
    Maya "Без контроля"
    scene 26_maya_2_afternoon_mroom with dissolve
    Maya "Без «я помогу»"
    scene 27_maya_2_afternoon_mroom with dissolve
    gg "Я не про контроль"
    gg "Если по дому что-то"
    scene 28_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 29_maya_2_afternoon_mroom with dissolve
    Maya "Мне не нужна опека"
    scene 30_maya_2_afternoon_mroom with dissolve
    gg "Я не это имел в виду"
    scene 31_maya_2_afternoon_mroom with dissolve
    Maya "А звучит именно так"
    scene 32_maya_2_afternoon_mroom with dissolve
    Maya "Мне пофиг, что ты тут живёшь"
    scene 33_maya_2_afternoon_mroom with dissolve
    Maya "Просто"
    scene 34_maya_2_afternoon_mroom with dissolve
    Maya "Не лезь"
    scene 35_maya_2_afternoon_mroom with dissolve
    Maya "В мои дела"
    scene 36_maya_2_afternoon_mroom with dissolve
    gg "Я понял"
    scene 37_maya_2_afternoon_mroom with dissolve
    Maya "И дверь закрывай"
    scene 38_maya_2_afternoon_mroom with dissolve
    Maya "Я не фанат"
    Maya "Открытых пространств"
    scene 39_maya_2_afternoon_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 40_maya_2_afternoon_mroom with dissolve
    play sound closedoor2 volume 0.5
    $ renpy.pause(delay=1, hard=True)

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("myroom")
    return

label maya_scene3_evening_kitchen:
    $ hide_screens()
    scene 1_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 3_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 4_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 5_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 6_maya_3_evening_kitchen with dissolve
    gg "Привет"
    scene 7_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 8_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 9_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 10_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 11_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 12_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Тебе еще кофе принести?"
    scene 13_maya_3_evening_kitchen with dissolve
    Maya "Нет"
    scene 14_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 15_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 16_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 17_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 18_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 19_maya_3_evening_kitchen
    Maya "Не . . ."
    scene 20_maya_3_evening_kitchen with dissolve
    gg "Что?"
    scene 21_maya_3_evening_kitchen with dissolve
    Maya "Ты вообще"
    scene 22_maya_3_evening_kitchen with dissolve
    Maya "Зачем так близко?"
    scene 23_maya_3_evening_kitchen with dissolve
    gg "Я просто"
    scene 24_maya_3_evening_kitchen with dissolve
    Maya "Я сказала, не надо"
    scene 25_maya_3_evening_kitchen with dissolve
    Maya "И не звала"
    scene 26_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 27_maya_3_evening_kitchen with dissolve
    Maya "Мне нужно было просто кофе"
    scene 28_maya_3_evening_kitchen with dissolve
    gg "Подожди"
    scene 29_maya_3_evening_kitchen with dissolve
    Maya "Не сейчас"
    $ renpy.pause(delay=0.5, hard=True)
    scene 30_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound doorloadclose
    scene 29_maya_3_evening_kitchen with dissolve
    $ renpy.pause(delay=2, hard=True)
    gg_chat "Как бы мне с ней поговорить"

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label maya_scene4_morning_mayaroom:
    $ hide_screens()
    play fx1 computerwork volume 0.4
    scene 1_maya_4_afternoon_mroom with dissolve
    Maya "Да что ж"
    scene 2_maya_4_afternoon_mroom with dissolve
    Maya "Ну давай же"
    scene 3_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 4_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 5_maya_4_afternoon_mroom with dissolve
    gg "Опять воюешь с техникой?"
    scene 6_maya_4_afternoon_mroom with dissolve
    Maya "Все работало час назад"
    scene 7_maya_4_afternoon_mroom with dissolve
    gg "Погоди, у меня была похожая проблема"
    scene 8_maya_4_afternoon_mroom with dissolve
    Maya "Конечно. У нашего местного игромана, разумеется, был подобный опыт"
    scene 9_maya_4_afternoon_mroom with dissolve
    gg "Это решается проще, чем кажется"
    scene 10_maya_4_afternoon_mroom with dissolve
    Maya "Я разберусь"
    play sound beathdown
    scene 11_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 12_maya_4_afternoon_mroom with dissolve
    Maya "Ладно, поскольку ты уже встал тут в позу спасителя"
    scene 13_maya_4_afternoon_mroom with dissolve
    Maya "Смотри"
    scene 14_maya_4_afternoon_mroom with dissolve
    Maya "Но если сломаешь, новый купишь"
    scene 15_maya_4_afternoon_mroom with dissolve
    gg_chat "Так посмотрим"
    scene 16_maya_4_afternoon_mroom with dissolve
    Maya "Только давай без «я же говорил»"
    scene 17_maya_4_afternoon_mroom with dissolve
    gg "Хорошо, не собирался"
    scene 18_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 19_maya_4_afternoon_mroom with dissolve
    scene 20_maya_4_afternoon_mroom with dissolve
    Maya "Главное делай вид, что понимаешь"
    scene 21_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 22_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 23_maya_4_afternoon_mroom with dissolve
    Maya "Ты что сделал?"
    scene maya_act2_scene4_video1 with dissolve
    pause
    Maya "Показывай"
    scene 24_maya_4_afternoon_mroom with dissolve
    Maya "Я уже готовлюсь к разочарованию"
    scene 25_maya_4_afternoon_mroom with dissolve
    gg "Пока ничего критичного"
    scene 26_maya_4_afternoon_mroom with dissolve
    Maya "Угу"
    scene 27_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 28_maya_4_afternoon_mroom with hpunch
    Maya "Эй!"
    scene 29_maya_4_afternoon_mroom with dissolve
    Maya "Стоп"
    scene 30_maya_4_afternoon_mroom with dissolve
    gg "Что"
    scene 31_maya_4_afternoon_mroom with dissolve
    Maya "Не надо ко мне лезть"
    scene 32_maya_4_afternoon_mroom with dissolve
    gg "Ты сама"
    scene 33_maya_4_afternoon_mroom
    Maya "Цыц"
    scene maya_act2_scene4_video2 with dissolve
    pause
    scene 34_maya_4_afternoon_mroom with dissolve
    Maya "Забей"
    scene 35_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 closelaptop
    scene 36_maya_4_afternoon_mroom
    Maya "Уже не важно"
    scene 37_maya_4_afternoon_mroom with dissolve
    Maya "Я разберусь потом"
    scene 38_maya_4_afternoon_mroom with dissolve
    gg "Я же просто"
    scene 39_maya_4_afternoon_mroom with dissolve
    Maya "Я сказала потом"
    scene 40_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 41_maya_4_afternoon_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 42_maya_4_afternoon_mroom with dissolve
    gg_chat "Нужно дать ей время"

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label maya_scene5_night_mayaroom:
    $ hide_screens()
    scene 1_maya_5_night_mroom with dissolve
    gg "Я зайду"
    play fx1 closedoor3 volume 0.3
    scene 2_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene 3_maya_5_night_mroom with dissolve
    gg "Слушай . . ."
    scene 4_maya_5_night_mroom with dissolve
    gg "Я хочу понять"
    scene 5_maya_5_night_mroom with dissolve
    gg "Ты всё время"
    gg "Отталкиваешь"
    gg "Резко"
    scene 6_maya_5_night_mroom with dissolve
    gg "Я не всегда понимаю"
    gg "Где именно граница"
    scene 7_maya_5_night_mroom
    Maya "Да нигде"
    scene 8_maya_5_night_mroom with dissolve
    Maya "Хочешь границы"
    Maya "Не лезь"
    gg "Я не . . .{nw=0.3}"
    scene 9_maya_5_night_mroom
    Maya "{size=*1.3}Не надо"
    scene 10_maya_5_night_mroom with dissolve
    Maya "Не делай вид"
    Maya "Что ты тут ни при чём"
    scene 11_maya_5_night_mroom with dissolve
    gg "Я не пытаюсь давить"
    gg "Я просто . . .{nw=0.3}"
    scene 12_maya_5_night_mroom
    Maya "{size=*1.3}Ты всегда «просто»"
    scene 13_maya_5_night_mroom with dissolve
    Maya "Просто заходишь"
    Maya "Просто начинаешь разговор"
    scene 14_maya_5_night_mroom with dissolve
    Maya "Просто помогаешь"
    scene 15_maya_5_night_mroom with dissolve
    Maya "{sc}Это бесит{/sc}"
    scene 16_maya_5_night_mroom with dissolve
    Maya "Всё"
    scene 17_maya_5_night_mroom with dissolve
    Maya "Разговор окончен"
    scene maya_act2_scene5_video1 with dissolve
    pause
    scene 18_maya_5_night_mroom with dissolve
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Прости"
    scene 18_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 19_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 20_maya_5_night_mroom with dissolve
    Maya "Хотя нет"
    scene 21_maya_5_night_mroom with dissolve
    Maya "Забей"
    scene 22_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 23_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 24_maya_5_night_mroom
    $ renpy.pause(delay=1, hard=True)
    scene 25_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=3, hard=True)
    scene 26_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 27_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 28_maya_5_night_mroom with dissolve
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Я . . ."
    scene 29_maya_5_night_mroom with dissolve
    Maya "Не это имела в виду"
    scene 30_maya_5_night_mroom with dissolve
    Maya "Всё"
    scene 31_maya_5_night_mroom with dissolve
    Maya "Иди"
    $ renpy.pause(delay=1, hard=True)
    scene 32_maya_5_night_mroom with dissolve
    Maya "Я сказала — иди{nw=2}"
    scene 34_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene 35_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 36_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 37_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 closedoor3 volume 0.5
    scene 38_maya_5_night_mroom with dissolve
    $ renpy.pause(delay=2, hard=True)


    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("myroom")
    return

label maya_scene6_evening_myroom:
    $ hide_screens()
    scene 1_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 2_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 3_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 4_maya_6_evening_livingroom with dissolve
    Maya "Ты сидишь будто"
    scene 5_maya_6_evening_livingroom with dissolve
    Maya "Ничего не было"
    scene 6_maya_6_evening_livingroom with dissolve
    gg "Я не делаю вид"
    scene 7_maya_6_evening_livingroom with dissolve
    Maya "Ладно, не важно"
    scene 8_maya_6_evening_livingroom with dissolve
    Maya "Залипай дальше"
    scene 9_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 10_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 11_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 12_maya_6_evening_livingroom with dissolve
    Maya "Слушай"
    Maya "А ты сейчас сильно занят?"
    scene 13_maya_6_evening_livingroom with dissolve
    gg "Если честно — нет"
    scene 14_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 15_maya_6_evening_livingroom with dissolve
    Maya "Я просто спросила"
    scene 16_maya_6_evening_livingroom with dissolve
    gg "А я просто отвечаю"
    Maya ". . ."
    scene 17_maya_6_evening_livingroom with dissolve
    Maya "Поможешь мне кое с чем"
    scene 18_maya_6_evening_livingroom with dissolve
    Maya "Это быстро"
    scene 19_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 20_maya_6_evening_livingroom with dissolve
    gg "С чем?"
    scene 21_maya_6_evening_livingroom with dissolve
    Maya "Увидишь"
    scene 22_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 23_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 24_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene black with dissolve
    play music romance2 fadein 0.5 fadeout 0.5 loop
    play sound closedoor2
    $ renpy.pause(delay=1, hard=True)
    scene 25_maya_6_evening_livingroom with dissolve
    Maya "Только без лишней заботы"
    scene 26_maya_6_evening_livingroom with dissolve
    gg "Как скажешь"
    scene 27_maya_6_evening_livingroom with dissolve
    Maya "Посмотрим на что ты способен"
    scene 28_maya_6_evening_livingroom with dissolve
    Maya "Ну"
    scene 29_maya_6_evening_livingroom with dissolve
    Maya "Вот"
    scene 30_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Что застыл"
    scene 31_maya_6_evening_livingroom with dissolve
    gg "О и давно у тебя это?"
    scene 32_maya_6_evening_livingroom with dissolve
    Maya "Очень"
    Maya "Ещё когда я делала вид"
    scene 33_maya_6_evening_livingroom with dissolve
    Maya "Что у меня есть дисциплина"
    scene 34_maya_6_evening_livingroom with dissolve
    gg "В смысле?"
    scene 35_maya_6_evening_livingroom with dissolve
    Maya "Спорт"
    scene 36_maya_6_evening_livingroom with dissolve
    Maya "Секции, график, «надо»"
    scene 37_maya_6_evening_livingroom with dissolve
    Maya "Потом одна удачная травма"
    scene 38_maya_6_evening_livingroom with dissolve
    Maya "И всё"
    scene 39_maya_6_evening_livingroom with dissolve
    Maya "Цирк закрылся"
    scene 40_maya_6_evening_livingroom with dissolve
    gg "И ты бросила?"
    scene 41_maya_6_evening_livingroom with dissolve
    Maya "Я бы назвала это"
    scene 42_maya_6_evening_livingroom with dissolve
    Maya "«Энергосберегающий режим»"
    scene 43_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 44_maya_6_evening_livingroom with dissolve
    gg "Теперь понятно почему ты так реагируешь"
    scene 45_maya_6_evening_livingroom with dissolve
    Maya "Я просто не люблю"
    Maya "Когда кто-то начинает"
    scene 46_maya_6_evening_livingroom with dissolve
    Maya "Объяснять мне как жить"
    $ renpy.pause(delay=2, hard=True)
    scene 47_maya_6_evening_livingroom with dissolve
    Maya "В общем, нужно нанести крем и забинтовать"
    scene 48_maya_6_evening_livingroom with dissolve
    gg "А к Соне почему не пошла?"
    scene 49_maya_6_evening_livingroom with dissolve
    Maya "По той же причине, а еще"
    Maya "Это всегда превращается"
    scene 50_maya_6_evening_livingroom with dissolve
    Maya "В «давай я»"
    scene 51_maya_6_evening_livingroom with dissolve
    Maya "Она начинает суетиться"
    Maya "Делать больше, чем надо"
    scene 52_maya_6_evening_livingroom with dissolve
    Maya "А потом я виноватой себя чувствую"
    scene 53_maya_6_evening_livingroom with dissolve
    gg "Кажется, это называется забота"
    scene 54_maya_6_evening_livingroom with dissolve
    Maya "Тогда давай посмотрим на твою заботу"
    scene 55_maya_6_evening_livingroom with dissolve
    Maya "Надеюсь только без драм"
    scene 56_maya_6_evening_livingroom with dissolve
    gg "Не собирался"
    scene 57_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 58_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Можно?"
    scene 59_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 58_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 60_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 61_maya_6_evening_livingroom with dissolve
    Maya "Не бойся"
    Maya "Я не из хрусталя"
    scene maya_act2_scene6_video1 with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Ты всегда такой спокойный?"
    gg "Не всегда"
    scene maya_act2_scene6_video2 with dissolve
    gg "Просто сейчас . . .{w} нет смысла психовать"
    scene maya_act2_scene6_video1 with dissolve
    Maya "Понятно"
    Maya "Экономишь нервы"
    Maya "Умно"
    scene maya_act2_scene6_video2 with dissolve
    gg "Можно сказать и так"
    $ renpy.pause(delay=1, hard=True)
    scene 62_maya_6_evening_livingroom with dissolve
    Maya "Теперь бинтуй"
    scene 63_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 64_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 65_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 66_maya_6_evening_livingroom with dissolve
    Maya "Левее"
    scene 67_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 68_maya_6_evening_livingroom with dissolve
    Maya "Нет{w} стой"
    scene 69_maya_6_evening_livingroom with dissolve
    Maya "Вот так"
    scene 70_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 71_maya_6_evening_livingroom with dissolve
    Maya "Ты вообще смотришь, что делаешь?"
    scene 72_maya_6_evening_livingroom with dissolve
    gg "Мая"
    scene 73_maya_6_evening_livingroom with dissolve
    Maya "Нет, серьёзно"
    Maya "Ты сейчас наугад это бинтуешь"
    scene 74_maya_6_evening_livingroom with dissolve
    Maya "Или делаешь вид"
    Maya "Что уверен"
    scene 75_maya_6_evening_livingroom with dissolve
    play sound aghbreathe
    $ renpy.pause(delay=1, hard=True)
    scene 76_maya_6_evening_livingroom with dissolve
    gg "Мая"
    scene 77_maya_6_evening_livingroom with dissolve
    gg "Если тебе так проще — я выйду"
    scene 78_maya_6_evening_livingroom
    Maya "Подожди"
    scene 79_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 80_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 81_maya_6_evening_livingroom with dissolve
    Maya "Я . . .{w} не это имела в виду"
    scene 82_maya_6_evening_livingroom with dissolve
    Maya "Просто . . ."
    scene 83_maya_6_evening_livingroom with dissolve
    Maya "Не уходи"
    scene 84_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 85_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 86_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 87_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 88_maya_6_evening_livingroom with dissolve
    gg "Иии"
    scene 89_maya_6_evening_livingroom with dissolve
    gg "Операция закончена"
    scene 90_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 91_maya_6_evening_livingroom with dissolve
    Maya "Спасибо"
    scene 92_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 93_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 94_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 95_maya_6_evening_livingroom
    play sound kiss
    $ renpy.pause(delay=0.5, hard=True)
    scene 96_maya_6_evening_livingroom
    $ renpy.pause(delay=1, hard=True)
    scene 97_maya_6_evening_livingroom with dissolve
    Maya "Не привыкай"
    scene 98_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=2, hard=True)
    gg "Не собирался"
    scene 99_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 100_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 101_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play sound closedoor2
    scene 102_maya_6_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)


    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("bathroom")
    return

label maya_scene7_night_mayaroom:
    $ hide_screens()
    play sound computerwork loop fadein 1 fadeout 1 volume 0.2
    scene 1_maya_2_night_mroom
    gg "Ты до сих пор за ноутом?"
    gg "Уже за полночь"
    scene 2_maya_2_night_mroom with dissolve
    Maya "И что?"
    Maya "У меня дела в отличие от некоторых"
    scene 3_maya_2_night_mroom with dissolve
    gg "Уже ночь"
    scene 4_maya_2_night_mroom with dissolve
    gg "А переписка это работа?"
    stop sound fadeout 1
    scene 5_maya_2_night_mroom with dissolve
    Maya "Да мои дела"
    scene 6_maya_2_night_mroom with dissolve
    Maya "Вечно лезешь туда, куда не зовут"
    scene 7_maya_2_night_mroom with dissolve
    gg "А дверь открытая{w}, значит ждала"
    scene 8_maya_2_night_mroom with dissolve
    Maya "Ждала?"
    scene 9_maya_2_night_mroom with dissolve
    Maya "Только если дурака, чтобы под руку мешался"
    gg_chat "На вид она слишком устала для настоящей злости"
    scene 10_maya_2_night_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play sound closelaptop
    scene 11_maya_2_night_mroom with hpunch 
    Maya "ЭЭ" 
    $ renpy.pause(delay=0.5, hard=True)
    scene 12_maya_2_night_mroom with dissolve
    Maya "Не смей! Это моё!" with hpunch 
    scene 13_maya_2_night_mroom with dissolve
    gg "Да я и не собирался читать"
    gg "Просто . . . {w}ты могла бы не прятать"
    scene 14_maya_2_night_mroom with dissolve
    Maya "Потому что . . ."
    scene 15_maya_2_night_mroom with dissolve
    Maya "C тобой я . . ."
    menu:
        "Договаривай":
            stop music fadeout 1
            $ renpy.pause(delay=1, hard=True)
            play music romance fadein 1
            scene 16_maya_2_night_mroom with dissolve
            Maya ". . . "
            Maya ". . . {w}Я не своя . . ."
            Maya "Я всё время о тебе думаю"
            scene 20_maya_2_night_mroom with dissolve
            $ renpy.pause(delay=1, hard=True)
        ". . .":
            scene 18_maya_2_night_mroom with dissolve
            Maya "С тобой я только и делаю, что тупею!"
            scene 19_maya_2_night_mroom with dissolve
            Maya "Вот и всё"
            stop music fadeout 1
            $ renpy.pause(delay=1, hard=True)
            play music romance fadein 1
            scene 20_maya_2_night_mroom with dissolve
            gg "Ты прячешься за словами, но глаза выдают всё"
    play sound kissing loop
    scene maya_act2_scene7_video1 with dissolve
    pause
    stop sound fadeout 1
    scene maya_act2_scene7_video2 with dissolve
    pause
    scene 21_maya_2_night_mroom with dissolve
    Maya "{size=*0.8}. . . Дурак . . .{/size}"
    Maya "Если кому-то скажешь - я тебя прибью" with hpunch
    menu:
        "Угрожаешь?":
            scene 23_maya_2_night_mroom with dissolve
            gg "Угрожаешь после такого? {w}Смелая"
        "Никому":
            scene 22_maya_2_night_mroom with dissolve
            gg "Никому {w}только между нами"

    stop music fadeout 1.0
    $ renpy.pause(delay=1, hard=True)
    play music night loop fadein 1.0
    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label maya_scene8_morning_mayaroom:
    $ hide_screens()

    scene 1_maya_1_morning_mroom 
    gg_chat "Она выглядит . . . спокойно {w}Никакой злости {w} даже странно"
    scene 2_maya_1_morning_mroom with dissolve 
    Maya "Ты чё . . . {w}уже встал?.."
    scene 3_maya_1_morning_mroom with dissolve 
    gg "Эм . . . да. Я не хотел мешать. Просто заглянул"
    scene 5_maya_1_morning_mroom with dissolve 
    Maya "Не уходи . . ."
    scene 6_maya_1_morning_mroom with dissolve 
    Maya "Сядь"
    play sound "<from 0 to 2>audio/dress off.mp3"  fadeout 1.0
    scene 7_maya_1_morning_mroom with dissolve 
    $ renpy.pause(delay=1, hard=True)
    scene 8_maya_1_morning_mroom with dissolve
    Maya "Спала ужасно . . ."
    scene 9_maya_1_morning_mroom with dissolve
    Maya "Всё крутилось в голове"
    Maya "Не выспалась"
    scene 10_maya_1_morning_mroom with dissolve
    gg "А у тебя будто энергии с утра через край"
    scene 11_maya_1_morning_mroom with dissolve
    Maya "Очень смешно . . . "
    scene 12_maya_1_morning_mroom with dissolve
    Maya "Я лентяйка {w}просто иногда притворяюсь"
    scene 13_maya_1_morning_mroom with dissolve
    Maya "Ляг"
    Maya "Просто . . . {w}чтоб теплее было"
    play sound "<from 0 to 2>audio/dress off.mp3"  fadeout 1.0
    scene 14_maya_1_morning_mroom with dissolve
    $ renpy.pause(delay=2, hard=True)
    gg "Ты не заболела случайно?"
    scene 15_maya_1_morning_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Убью, если кому-то расскажешь"
    scene 16_maya_1_morning_mroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg_chat "Может это мой шанс . . ."
    menu:
        "Тихо поцеловать её":
            play sound kissing
            scene maya_act2_scene8_video2 with dissolve
            $ renpy.pause(delay=2, hard=True)
            Maya "Дурак . . ."
            pause
            stop sound 
            scene 17_maya_1_morning_mroom with dissolve
            gg_chat "Слишком спокойно . . ."
            gg_chat "Значит, самое время тихо уйти"
            scene 18_maya_1_morning_mroom with dissolve
            $ renpy.pause(delay=2, hard=True)
            gg_chat "Никогда бы не подумал, что первый поцелуй с ней будет таким"
        "Уткнуться в ее грудь":
            scene maya_act2_scene8_video1 with dissolve
            $ renpy.pause(delay=2, hard=True)
            gg_chat "Вот бы всегда так . . ."
            gg_chat "Но, зная её, лучше не задерживаться"
            pause
            scene 17_maya_1_morning_mroom with dissolve
            $ renpy.pause(delay=0.5, hard=True)
            scene 18_maya_1_morning_mroom with dissolve
            gg_chat "Мягкость её груди всё ещё чувствовалась . . ."
            gg_chat "И отпускать не хотелось"

    play sound closedoor volume 0.4
    $ renpy.pause(delay=1, hard=True)

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.jump("myroom")
    return

label maya_scene9_day_kitchen:
    $ hide_screens()

    
    scene maya_act2_scene9_video1
    stop music fadeout 1
    $ renpy.pause(delay=1, hard=True)
    play fx1 cooking loop volume 0.1
    play music romance3 fadein 1
    pause
    Maya "О ты тут, помоги посыпать соль"
    scene 1_maya_3_day_kitchen with dissolve
    gg "Окей"
    scene maya_act2_scene9_video2 with dissolve
    pause
    Maya "И аккуратней, а то пересолишь"
    play fx2 saltshaker fadein 0.3 fadeout 0.3
    scene 2_maya_3_day_kitchen with dissolve
    $ renpy.pause(delay=1.5, hard=True)
    play fx2 saltstand 
    scene 3_maya_3_day_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    play sound breathingnormal fadein 0.3 fadeout 0.3 loop
    scene maya_act2_scene9_video3 with dissolve
    pause
    Maya "Так . . . {w}вот теперь оно прилипло к сковородке"
    Maya "Прям не оторвать"
    gg "Тогда надо поддеть снизу, чтобы не пригорело"
    scene maya_act2_scene9_video4 with dissolve
    play sound breathingdark volume 0.75 fadein 0.3 fadeout 0.3 loop
    Maya "Главное - не давить слишком резко"
    Maya "Иначе желток лопнет"
    gg "Но если аккуратно, всё останется целым"
    Maya "Угу . . . {w}мягче перемешивай"
    Maya "Тогда всё прожарится равномерно"
    scene maya_act2_scene9_video5 with dissolve
    pause
    Maya "Всё, почти готово . . ."
    Maya "Ещё чуть-чуть, и можно снимать с огня"
    gg "Думаю, будет очень вкусно"
    stop sound fadeout 1
    stop fx1 fadeout 1
    scene 4_maya_3_day_kitchen with dissolve
    Maya "Всё {w}a то сейчас пережарим"
    scene 5_maya_3_day_kitchen with dissolve
    Maya "Дальше сам себе готовь"
    scene black with out_eye
    gg_chat "Она подыгрывала"
    gg_chat "Но в конце всё равно сбежала . . ."

    $ renpy.pause(delay=1, hard=True)

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label maya_scene10_evening_myroom:
    $ hide_screens()
    scene 1_maya_10_evening_livingroom with dissolve
    play sound closedoor
    $ renpy.pause(delay=1, hard=True)
    scene 2_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 3_maya_10_evening_livingroom with dissolve
    Maya "Я дома"
    scene 4_maya_10_evening_livingroom with dissolve
    Maya "О, ты тут"
    scene 5_maya_10_evening_livingroom with dissolve
    gg "Привет. Как работа?"
    scene 6_maya_10_evening_livingroom with dissolve
    Maya "Словно вечность. Эти долбаные люди"
    scene 7_maya_10_evening_livingroom with dissolve
    gg "Хочешь чай? Или просто вырубиться?"
    scene 8_maya_10_evening_livingroom with dissolve
    Maya "Чай?{w} Ты решил внезапно заботиться?"
    scene 9_maya_10_evening_livingroom with dissolve
    Maya "Ладно . . . да, пожалуй. И два сахара"
    scene 10_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 11_maya_10_evening_livingroom with dissolve
    Maya "Уфф, устала"
    scene 12_maya_10_evening_livingroom with dissolve
    gg "Может, поговорим?"
    scene 13_maya_10_evening_livingroom with dissolve
    Maya "О чём?"
    scene 14_maya_10_evening_livingroom with dissolve
    Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Отстань"
    scene 15_maya_10_evening_livingroom with dissolve
    gg "Да ладно тебе, можно просто помолчать"
    scene 16_maya_10_evening_livingroom with dissolve
    Maya "Ты странный. Сидишь тут . . . как будто ждёшь чего-то"
    play music romance3 fadein 0.5 fadeout 0.5 loop
    scene 17_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Может, и жду"
    scene 18_maya_10_evening_livingroom with dissolve
    Maya "Ты же знаешь, что я . . . колючая"
    scene 19_maya_10_evening_livingroom with dissolve
    gg "Знаю"
    scene 20_maya_10_evening_livingroom with dissolve
    Maya "И что я всё испорчу"
    scene 21_maya_10_evening_livingroom with dissolve
    Maya "Обязательно ляпну какую-нибудь чушь"
    scene 22_maya_10_evening_livingroom with dissolve
    gg "{bt=a3-p2.0-s3.0}{size=*0.8}Привык уже"
    scene maya_act2_scene10_video1 with dissolve
    play sound kissing loop fadein 0.3 fadeout 0.3
    $ renpy.pause(delay=8)
    stop sound
    scene 23_maya_10_evening_livingroom with dissolve
    Maya "Ну конечно. Самое время для этого"
    scene 24_maya_10_evening_livingroom with dissolve
    gg "Май . . ."
    scene 25_maya_10_evening_livingroom with dissolve
    Maya "Заткнись"
    scene 26_maya_10_evening_livingroom with dissolve
    Maya "Просто . . . заткнись"
    scene maya_act2_scene10_video1 with dissolve
    play sound kissing loop fadein 0.3 fadeout 0.3
    pause
    scene maya_act2_scene10_video2 with dissolve
    pause
    scene 27_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    stop sound
    scene 28_maya_10_evening_livingroom
    Maya "Тише . . . Осторожно. Я не . . .{w} Я не готова ко всему сразу"
    scene maya_act2_scene10_video1 with dissolve
    play sound kissing loop fadein 0.3 fadeout 0.3
    pause
    scene maya_act2_scene10_video3 with dissolve
    pause
    Maya "Ох . . . боже . . ."
    scene 29_maya_10_evening_livingroom with dissolve
    play fx1 zipsound
    $ renpy.pause(delay=0.3, hard=True)
    scene 30_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=0.3, hard=True)
    scene 31_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=0.3, hard=True)
    scene 32_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=0.3, hard=True)
    stop sound
    scene 33_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=0.3, hard=True)
    Maya ". . ."
    scene 35_maya_10_evening_livingroom with dissolve
    Maya "Вот это да . . ."
    scene 36_maya_10_evening_livingroom with dissolve
    Maya "Ты это . . . там всё время носил?"
    scene 37_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 38_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 39_maya_10_evening_livingroom with dissolve
    Maya "Нет . . ."
    scene 40_maya_10_evening_livingroom with dissolve
    Maya "Нет, стоп"
    stop music fadeout 1
    play music intro_theme fadein 1 loop fadeout 1 volume 0.3
    scene 41_maya_10_evening_livingroom with dissolve
    Maya "Стоп, блядь"
    scene 42_maya_10_evening_livingroom with dissolve
    gg "Майя?"
    scene 43_maya_10_evening_livingroom with dissolve
    Maya "Выйди. Пожалуйста.{w} Просто . . . выйди"
    scene 44_maya_10_evening_livingroom with dissolve
    gg "Я . . .{w} Я не хотел . . ."
    scene 45_maya_10_evening_livingroom with dissolve
    Maya "{sc}{size=*1.2}Я ЗНАЮ{/size}{/sc}, что не хотел!"
    scene 46_maya_10_evening_livingroom with dissolve
    Maya "Именно поэтому — ВЫЙДИ!"
    scene 47_maya_10_evening_livingroom with dissolve
    Maya "Не сейчас . . .{w} Я не могу{w} Это слишком . . . реально"
    scene 49_maya_10_evening_livingroom with dissolve
    gg "Хорошо. Я . . .{w} Я ушёл"
    scene 50_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 51_maya_10_evening_livingroom with dissolve
    Maya "{size=*0.8}Чёрт . . . Чёрт . . . Чёрт . . ."
    Maya "{size=*0.8}Он такой . . . большой . . ."
    scene 52_maya_10_evening_livingroom with dissolve
    Maya "{size=*0.8}И мне . . ."
    Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Понравилось"
    scene 53_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play sound closedoor2
    scene 54_maya_10_evening_livingroom with dissolve
    $ renpy.pause(delay=1, hard=True)

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("myroom")
    return

label maya_scene11_morning_bathroom:
    $ hide_screens()

    scene 1_maya_4_morning_bath
    gg "Ты с утра за стиркой"
    gg "Это что то мифическое"
    scene 2_maya_4_morning_bath with dissolve
    Maya "Миф"
    scene 3_maya_4_morning_bath with dissolve
    Maya "Это если бы ты сам что-то постирал"
    scene 4_maya_4_morning_bath with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 5_maya_4_morning_bath with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Я хотя бы свои вещи складываю"
    scene 6_maya_4_morning_bath with dissolve
    gg "А твои валялись по всей комнате"
    scene 7_maya_4_morning_bath with dissolve
    Maya "И кто же их собрал? Не ты"
    scene 8_maya_4_morning_bath with dissolve
    gg "Ещё чуть-чуть, и я подумаю, что ты скрытая трудяга"
    scene 9_maya_4_morning_bath with dissolve
    Maya "Чего говоришь!"
    scene 11_maya_4_morning_bath with dissolve
    Maya "Думаешь я настолько лентяйка?"
    scene 11_maya_4_morning_bath with dissolve
    gg "Думаю"
    stop music fadeout 0.5
    $ renpy.pause(delay=0.5, hard=True)
    play music romance3 fadein 0.5 loop fadeout 1
    scene 12_maya_4_morning_bath with dissolve
    gg "Ты кое что забыла поставить на стирку"
    play sound "<from 0 to 1.5>audio/dress off.mp3"  fadeout 1.0
    $ renpy.pause(delay=1.0, hard=True)
    scene 13_maya_4_morning_bath with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 14_maya_4_morning_bath with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 15_maya_4_morning_bath with dissolve
    Maya "Ах так?"
    scene 16_maya_4_morning_bath with dissolve
    Maya "Тогда стираем всё"
    play sound "<from 0 to 1.5>audio/dress off.mp3"  fadeout 1.0
    $ renpy.pause(delay=1, hard=True)
    scene 17_maya_4_morning_bath with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 18_maya_4_morning_bath with dissolve
    Maya "Ага . . ."
    scene 19_maya_4_morning_bath with dissolve
    Maya "Похоже ЭТО нужно будет стирать деликатно"
    scene 20_maya_4_morning_bath with dissolve
    Maya "Думаю мы можем продолжить на чем закончили?"
    play sound maya_morning_bathroom loop
    scene maya_act2_scene11_video1 with dissolve
    pause
    Maya "Стиралка работает . . .  {w}но тут жарче, чем должно быть"
    gg "Главное - достирай до конца"
    gg "Если оставишь придется домывать . . ."
    pause
    stop sound fadeout 1.0
    scene maya_act2_scene11_video2 with dissolve
    pause 
    Maya "Так я думаю стиралка сама справится"
    scene 21_maya_4_morning_bath with dissolve
    scene 22_maya_4_morning_bath with dissolve
    Maya "А ты . . . {w}сам достирай свое"
    Maya "Белье . . ."
    scene black with out_eye
    play sound faststeps
    $ renpy.pause(delay=1, hard=True)
    play sound closedoor
    $ renpy.pause(delay=1, hard=True)
    gg_chat "Она ушла . . ."
    gg_chat "В следующий раз ее нельзя отпускать . . ."
    $ renpy.pause(delay=1, hard=True)

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label maya_scene12_evening_myroom:
    $ hide_screens()

    scene 1_maya_5_evening_zal with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_maya_5_evening_zal with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 3_maya_5_evening_zal with dissolve
    Maya "Ха, так вот где ты спрятался"
    scene 4_maya_5_evening_zal with dissolve
    Maya "И что ты смотришь?"
    scene 5_maya_5_evening_zal with dissolve
    gg "Подожди я в матче"
    gg "Если отвлекусь - проиграю"
    scene 6_maya_5_evening_zal with dissolve
    Maya "И это, по-твоему, веселье?"
    scene 7_maya_5_evening_zal with dissolve
    gg "Когда сам играешь намного веселее . . ."
    scene 8_maya_5_evening_zal with dissolve
    Maya "А по мне, как будто трата времени"
    scene 9_maya_5_evening_zal with dissolve
    gg "Эй!" with hpunch
    gg "Я ничего не вижу!"
    Maya "Ну и что?"
    scene 10_maya_5_evening_zal with dissolve
    Maya "Почему перестал играть?"
    scene 11_maya_5_evening_zal with dissolve
    gg "Я же сказал"
    scene 12_maya_5_evening_zal with dissolve
    gg "Теперь только тебя и вижу"
    scene 13_maya_5_evening_zal with dissolve
    Maya "Вот и отлично!"
    scene 14_maya_5_evening_zal with dissolve
    Maya "Я теперь главный игрок"
    scene 15_maya_5_evening_zal with dissolve
    gg "Ты щас мне рейтинг сольешь"
    scene 16_maya_5_evening_zal with dissolve
    Maya "Да ну, я просто проверяю"
    scene 17_maya_5_evening_zal with dissolve
    Maya "Как тут . . . прыгает!"
    scene 18_maya_5_evening_zal with dissolve
    Maya "Ой, а это что делает?"
    gg "Стой, не так"
    scene 19_maya_5_evening_zal with dissolve
    gg "Вот эта - стрелять, эта - использовать"
    scene 20_maya_5_evening_zal with dissolve
    gg "Держи крепче, смотри в экран"
    scene maya_act2_scene12_video1 with dissolve
    pause
    Maya "Мм . . ."
    Maya "Тут у тебя геймпад немного неудобный . . ."
    gg "Нет . . . {w}я про . . ."
    scene maya_act2_scene12_video2 with dissolve
    pause
    gg "Целься и стреляй"
    scene maya_act2_scene12_video1 with dissolve
    pause
    scene 21_maya_5_evening_zal with dissolve
    Maya "А! Я попала по нему!"
    Maya "Но всё равно проиграла . . ."
    gg "Нужно время, чтобы научиться"
    scene 22_maya_5_evening_zal with dissolve
    Maya "Время?"
    Maya "У меня терпения не хватит"
    stop music fadeout 0.5
    $ renpy.pause(delay=0.5, hard=True)
    play music romance3 loop fadein 0.5 fadeout 0.5
    scene 23_maya_5_evening_zal with dissolve
    Maya "Я лучше найду другой способ с тобой поиграть"
    scene 24_maya_5_evening_zal with dissolve
    gg "Похоже, тебе важнее сбить меня с толку . . ."
    scene maya_act2_scene12_video3 with dissolve
    pause
    Maya "Экран-то видишь ещё?"
    scene 25_maya_5_evening_zal with dissolve
    Maya "А это"
    scene 26_maya_5_evening_zal with dissolve
    Maya "Не интереснее?"
    scene maya_act2_scene12_video4 with dissolve
    pause
    gg "Интереснее, но я хочу выиграть"
    pause
    scene 27_maya_5_evening_zal with dissolve
    Maya "Ну-ну"
    Maya "Тогда держи удар"
    scene black with out_eye
    play sound zipsound
    scene 28_maya_5_evening_zal with in_eye
    Maya "Геймер"
    scene black with out_eye
    gg_chat "Она решила так играть? . . ."
    play sound maya_evening_myroom5 loop
    scene maya_act2_scene12_video5 with in_eye
    pause
    Maya "Давай, продолжай выигрывать"
    Maya "Интересно, надолго ли тебя хватит"
    gg "Мая . . ."
    gg "Ты . . ."
    Maya "Тише, я разбираюсь с управлением"
    play sound maya_evening_myroom6
    scene maya_act2_scene12_video6 with dissolve
    $ renpy.pause(delay=9.5, hard=True)
    scene 29_maya_5_evening_zal with dissolve
    stop sound
    Maya "Ну что?"
    Maya "Поражение засчитано?"
    gg "Это вообще нечестная игра"
    scene 30_maya_5_evening_zal with dissolve
    Maya "Нечестные победы самые сладкие"
    Maya "Теперь ты мой должник"
    $ renpy.pause(delay=1, hard=True)

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return


label maya_scene13_morning_girlroom:
    $ hide_screens()
    scene 1_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 closedoor3
    scene 2_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 3_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play fx1 yawn
    scene 4_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 5_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 6_maya_13_morning_sroom with dissolve
    gg_chat "Так, Cоня просила заказать новый шнур и заодно батарейки"
    $ renpy.pause(delay=0.5, hard=True)
    play fx1 steps
    play music romance3 fadein 0.5 fadeout 0.5 loop
    $ renpy.pause(delay=0.5, hard=True)
    scene maya_act2_scene13_video1 with dissolve
    $ renpy.pause(delay=1.5, hard=True)
    scene 7_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 8_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 9_maya_13_morning_sroom with dissolve
    gg "Ты чего?"
    scene 10_maya_13_morning_sroom with dissolve
    Maya "Ничего. Делай своё дело"
    scene maya_act2_scene13_video2 with dissolve
    pause
    scene 11_maya_13_morning_sroom with dissolve
    Maya "Не отвлекайся"
    play fx2 zipsound
    $ renpy.pause(delay=1, hard=True)
    play fx1 maya_act2_scene13_video3_s loop fadein 0.5 fadeout 0.5
    scene maya_act2_scene13_video3 with dissolve
    pause
    gg "Мая одну секунду . . ."
    Maya "Я же сказала, делай свое дело"
    stop fx1 fadeout 0.5
    scene 12_maya_13_morning_sroom with dissolve
    gg "Готово"
    scene 13_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 14_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 maya_act2_scene13_video4_s loop fadein 0.5 fadeout 0.5
    scene maya_act2_scene13_video4 with dissolve
    pause
    stop fx1 fadeout 0.5
    scene 15_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 16_maya_13_morning_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 maya_act2_scene13_video4_s loop fadein 0.5 fadeout 0.5
    scene maya_act2_scene13_video5 with dissolve
    pause
    play fx1 maya_act2_scene13_video6_s fadein 0.5
    scene maya_act2_scene13_video6 with dissolve
    
    $ renpy.pause(delay=5.5, hard=True)
    
    scene 17_maya_13_morning_sroom with dissolve
    stop fx1 fadeout 0.5
    Maya "Ну как тебе такое спокойное утро?"
    scene 18_maya_13_morning_sroom with dissolve
    gg "Замечательно"
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)


    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("myroom")
    return


label maya_scene14_afternoon_myroom:
    $ hide_screens()

    scene 1_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 2_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 3_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 4_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 5_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 6_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 3_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    Sonya "Эй . . . [povname] можешь помочь с коробками?"
    scene 7_maya_13_afternoon_hall with dissolve
    Maya "Ой. Тебя зовут"
    scene 8_maya_13_afternoon_hall with dissolve
    Maya "Беги. Не заставляй даму ждать"
    scene 9_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    stop music fadeout 1
    scene 10_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 11_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 12_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 13_maya_13_afternoon_hall with dissolve
    Maya "Слушай . . ."
    scene 14_maya_13_afternoon_hall with dissolve
    Maya "Не уходи"
    scene 15_maya_13_afternoon_hall with dissolve
    gg "Это из-за Сони?"
    scene 16_maya_13_afternoon_hall with dissolve
    Maya "Ты правда думаешь, что я буду это обсуждать?"
    scene 17_maya_13_afternoon_hall with dissolve
    play music romance3 fadein 1 fadeout 1 loop
    Maya "Мне не нравится, как легко ты вскакиваешь"
    scene 18_maya_13_afternoon_hall with dissolve
    Maya "Как будто меня тут нет"
    scene 19_maya_13_afternoon_hall with dissolve
    Maya "Пять минут"
    scene 20_maya_13_afternoon_hall with dissolve
    play sound kiss
    $ renpy.pause(delay=1, hard=True)
    scene 21_maya_13_afternoon_hall with dissolve
    Maya "Пять"
    scene 22_maya_13_afternoon_hall with dissolve
    Maya "И потом делай что хочешь"
    scene 23_maya_13_afternoon_hall with dissolve
    Maya "Только не думай, что это признание"
    scene 24_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 25_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 26_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    Maya "Чeрт . . . каждый раз будто в первый"
    play fx1 maya_myroom_afternoon_1 loop
    scene maya_act2_scene14_video1 with dissolve
    # $ mark ("maya_act2_scene14_video1")
    pause 
    stop fx1 fadeout 0.5
    scene 28_maya_13_afternoon_hall with dissolve   
    Maya "Неужели всё это . . . мне?"
    scene 29_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 30_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 31_maya_13_afternoon_hall with dissolve
    Maya "Такой . . . наглый"
    scene 32_maya_13_afternoon_hall with dissolve
    Maya "И такой тeплый . . ."
    play fx1 maya_myroom_afternoon_2
    scene maya_act2_scene14_video2 with dissolve
    $ renpy.pause(delay=3.5, hard=True)
    play fx1 maya_myroom_afternoon_3 loop
    scene maya_act2_scene14_video3
    pause
    scene 33_maya_13_afternoon_hall with dissolve
    Maya "Держись . . ."
    play fx1 maya_myroom_afternoon_4
    scene maya_act2_scene14_video4 with dissolve
    $ renpy.pause(delay=8.5, hard=True)
    scene 34_maya_13_afternoon_hall with dissolve
    stop fx1 fadeout 0.5
    Maya ". . . Всe"
    scene 35_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=.5, hard=True)
    scene 36_maya_13_afternoon_hall with dissolve
    Maya "Моe"
    scene 37_maya_13_afternoon_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 38_maya_13_afternoon_hall with dissolve
    Maya "Все"
    scene 39_maya_13_afternoon_hall with dissolve
    Maya "Иди"
    scene 40_maya_13_afternoon_hall with dissolve
    gg "Ты уверена?"
    scene 41_maya_13_afternoon_hall with dissolve
    Maya "Ага"
    scene 42_maya_13_afternoon_hall with dissolve
    Maya "Только не пропадай"
    scene 43_maya_13_afternoon_hall with dissolve
    Maya "Ты всё равно вернешься"

    $ Maya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return