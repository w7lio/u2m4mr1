
label kate_day_myroom:
    $ hide_screens()

    scene 1_kate_1_morning_livingroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_kate_1_morning_livingroom with dissolve
    Kate "О, живой человек"
    Kate "Я уже начала думать, что вы тут все в спячке"
    gg "Просто тихий день"
    gg "Мая опять заставила ждать?"
    scene 3_kate_1_morning_livingroom with dissolve
    Kate "Конечно. Я даже не удивляюсь"
    scene 4_kate_1_morning_livingroom with dissolve
    Kate "Знаешь"
    scene 5_kate_1_morning_livingroom with dissolve
    Kate "Я тут недавно проезжала мимо старого бассейна, который возле рощи"
    scene 6_kate_1_morning_livingroom with dissolve
    gg "Того, что сейчас с облупленной плиткой и заросшей дорожкой?"
    Kate "Ага. Ты его знаешь?"
    gg "Осталось воспоминание"
    gg "В детстве бабушка туда водила меня, интересно что же с ним случилось"
    scene 7_kate_1_morning_livingroom with dissolve
    Kate "Я случилась"
    scene 8_kate_1_morning_livingroom with dissolve
    Kate "Это был бассейн моего деда"
    Kate "Когда он умер, всё просто оставили. Я была маленькой"
    scene 9_kate_1_morning_livingroom with dissolve
    Kate "Тогда я часто туда ходила"
    Kate "Не знаю почему . . . {w}просто сидела, слушала, как эхо по плитке гуляет"
    scene 10_kate_1_morning_livingroom with dissolve
    gg "Я помню, там вода была — чистая, голубая"
    scene 11_kate_1_morning_livingroom with dissolve
    Kate "Да. А сейчас трещины пошли"
    scene 12_kate_1_morning_livingroom with dissolve
    Kate "И трава пробилась через бетон"
    Kate "Но место до сих пор . . . родное, понимаешь?"
    scene 13_kate_1_morning_livingroom with dissolve
    gg "Можно было бы восстановить"
    scene 14_kate_1_morning_livingroom with dissolve
    Kate "Ха, говоришь, как будто это просто"
    gg "Ну . . . {w}если там не обрушено дно — это реально"
    gg " Я могу помочь, если хочешь"
    scene 15_kate_1_morning_livingroom with dissolve
    Kate "Ты это серьёзно?"
    gg "Почему нет. Место стоящее"
    gg "И . . . {w} как будто жалко, что всё так осталось"
    scene 16_kate_1_morning_livingroom with dissolve
    Kate "Подожди, подожди!"
    Kate "То есть, если я найду цемент, кисти, старый насос — ты реально поможешь это оживить?"
    scene 17_kate_1_morning_livingroom with dissolve
    gg "Похоже, я только что подписался на летний ремонт"
    scene 18_kate_1_morning_livingroom with dissolve
    Kate "Господи, ты не понимаешь!"
    Kate "Там же можно сделать всё заново!"
    scene kate_morning_myroom1 with dissolve
    pause
    Kate "Подсветку включить, бортики покрасить . . ."
    Kate "Я даже помню, где лежала старая лестница!"
    scene 19_kate_1_morning_livingroom with dissolve
    Kate "Можем даже вывеску повесить — “Бассейн №1 Возрождён при участии безумцев”!"
    scene 20_kate_1_morning_livingroom with dissolve
    gg "Безумцев?"
    scene 21_kate_1_morning_livingroom with dissolve
    Kate "Ну, а кто ещё решит копаться в полузаброшенном дворе ради детской мечты?"
    $ renpy.pause(delay=1, hard=True)
    scene 22_kate_1_morning_livingroom with dissolve
    Kate "Если получится . . . я, наверное, наконец перестану чувствовать, что всё хорошее осталось “там”, в прошлом"
    gg "Значит, начнём с настоящего"
    scene 23_kate_1_morning_livingroom with dissolve
    Kate "Серьёзно!?"
    Kate "Спасибо. Ты первый, кто не сказал “забей”"
    gg "Я не умею “забивать”"
    play sound closedoor
    $ renpy.pause(delay=1, hard=True)
    play sound faststeps
    $ renpy.pause(delay=1, hard=True)
    scene 24_kate_1_morning_livingroom with dissolve
    Maya "Кейт! Я готова!"
    scene 25_kate_1_morning_livingroom with dissolve
    Kate "Опять вовремя"
    scene 26_kate_1_morning_livingroom with dissolve
    Kate "Тогда Увидимся у бассейна [povname], строитель мечтаний"

    $ Kate_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return