label sonya_scene1_morning_kitchen:
    $ hide_screens()
    scene 1_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 2_sonya_1_morning_kitchen with dissolve
    gg "Утречко"
    scene sonya_act2_scene1_video1 with dissolve
    pause
    scene sonya_act2_scene1_video2 with dissolve
    pause
    scene 3_sonya_1_morning_kitchen with dissolve
    Sonya "Доброе утро"
    scene 4_sonya_1_morning_kitchen with dissolve
    Sonya "Как тебе спалось?"
    scene 5_sonya_1_morning_kitchen with dissolve
    gg "Нормально"
    scene 6_sonya_1_morning_kitchen with dissolve 
    gg "Тихо"
    scene 7_sonya_1_morning_kitchen with dissolve 
    Sonya "Там диван, конечно, старый"
    scene 8_sonya_1_morning_kitchen with dissolve 
    Sonya "Но удобный"
    scene 9_sonya_1_morning_kitchen with dissolve 
    gg "Я заметил"
    scene 10_sonya_1_morning_kitchen with dissolve 
    Sonya "Ты уже успел пройтись по деревне?"
    scene 11_sonya_1_morning_kitchen with dissolve 
    Sonya "Или пока только дом вспоминаешь?"
    scene 12_sonya_1_morning_kitchen with dissolve 
    gg "Немного посмотрел"
    scene 13_sonya_1_morning_kitchen with dissolve 
    gg "Тут . . . Хорошие люди"
    scene 14_sonya_1_morning_kitchen with dissolve 
    Sonya "Да"
    scene 15_sonya_1_morning_kitchen with dissolve 
    Sonya "Ты к этому быстро привыкаешь"
    scene 16_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 17_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 18_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 19_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 20_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 21_sonya_1_morning_kitchen with dissolve
    Sonya "Если вдруг проголодаешься — бери что хочешь"
    scene 22_sonya_1_morning_kitchen with dissolve
    Sonya "У нас, обычно, никто особо не спрашивает"
    scene 23_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 24_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 25_sonya_1_morning_kitchen with dissolve
    gg "Спасибо"
    scene 26_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 27_sonya_1_morning_kitchen with dissolve
    Sonya "А вообще"
    scene 28_sonya_1_morning_kitchen with dissolve
    Sonya "Как тебе здесь?"
    scene 29_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 30_sonya_1_morning_kitchen with dissolve
    Sonya "В смысле . . . жить вместе"
    scene 31_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 32_sonya_1_morning_kitchen with dissolve
    gg "Непривычно"
    scene 33_sonya_1_morning_kitchen with dissolve
    gg "Но нормально"
    scene 34_sonya_1_morning_kitchen with dissolve
    Sonya "Да"
    scene 35_sonya_1_morning_kitchen with dissolve
    Sonya "Мы тоже не сразу привыкли"
    scene 36_sonya_1_morning_kitchen with dissolve
    Sonya "Когда людей в доме становится больше"
    scene 37_sonya_1_morning_kitchen with dissolve
    Sonya "Всё немного меняется"
    play fx1 long_beep
    $ renpy.pause(delay=0.3, hard=True)
    play fx1 long_beep
    $ renpy.pause(delay=5, hard=True)
    scene 38_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 39_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 26_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 27_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 26_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 40_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 41_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 42_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 43_sonya_1_morning_kitchen with dissolve
    pause
    gg_chat "Мае — завтрак"
    gg_chat "Если не успею — купи, пожалуйста, продукты"
    scene 44_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 45_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 46_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 47_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Ладно, я пойду"
    scene 48_sonya_1_morning_kitchen with dissolve
    gg "Не буду мешать"
    scene 49_sonya_1_morning_kitchen with dissolve
    Sonya "Да ты и не мешаешь"
    scene 50_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 51_sonya_1_morning_kitchen with dissolve
    Sonya "Но . . . хорошо"
    scene 52_sonya_1_morning_kitchen with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene black with dissolve
    $ renpy.pause(delay=2, hard=True)


    $ Sonya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label sonya_scene2_day_girlroom:
    $ hide_screens()
    scene 1_sonya_2_afternoon_sroom with dissolve
    gg "Сонь"
    scene sonya_act2_scene2_video1 with dissolve
    pause
    scene 2_sonya_2_afternoon_sroom with dissolve
    gg "Ты не знаешь, где у вас аптечка?"
    scene 3_sonya_2_afternoon_sroom with dissolve
    Sonya "Аптечка?"
    scene 4_sonya_2_afternoon_sroom with dissolve
    Sonya "А что случилось?"
    scene 5_sonya_2_afternoon_sroom with dissolve
    gg "Да так"
    scene 6_sonya_2_afternoon_sroom with dissolve
    gg "Поцарапался.{w} Ерунда"
    scene 7_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 8_sonya_2_afternoon_sroom with dissolve
    Sonya "Подожди"
    scene 9_sonya_2_afternoon_sroom with dissolve
    Sonya "Сейчас все сделаем"
    scene 10_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 11_sonya_2_afternoon_sroom with dissolve
    Sonya "А ты почти без вещей приехал"
    scene 12_sonya_2_afternoon_sroom with dissolve
    Sonya "Так и планировал . . ."
    Sonya "Или просто не успел собрать?"
    scene 13_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 14_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 15_sonya_2_afternoon_sroom with dissolve
    gg "Скорее второе"
    scene 16_sonya_2_afternoon_sroom with dissolve
    gg "Решил не тащить за собой старое"
    scene sonya_act2_scene2_video2 with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Посмотреть, как будет"
    scene 17_sonya_2_afternoon_sroom with dissolve
    Sonya "Будто новая жизнь"
    scene 18_sonya_2_afternoon_sroom with dissolve
    Sonya "Ты, получается, больше утренний человек?"
    scene 19_sonya_2_afternoon_sroom with dissolve
    Sonya "Или нет?"
    scene 20_sonya_2_afternoon_sroom with dissolve
    gg "Раньше — скорее вечерний"
    scene 21_sonya_2_afternoon_sroom with dissolve
    gg "А здесь почему-то весь день на ногах"
    scene 22_sonya_2_afternoon_sroom with dissolve
    gg "Сам удивляюсь"
    scene 23_sonya_2_afternoon_sroom with dissolve
    Sonya "Правда?"
    scene 24_sonya_2_afternoon_sroom with dissolve
    Sonya "Значит, деревня на тебя хорошо действует"
    scene 25_sonya_2_afternoon_sroom with dissolve
    Sonya "И часто ты так . . ."
    scene 26_sonya_2_afternoon_sroom with dissolve
    Sonya "Царапаешься?"
    scene 27_sonya_2_afternoon_sroom with dissolve
    gg "Не особо"
    scene 28_sonya_2_afternoon_sroom with dissolve
    gg "Просто ещё не привык к местной фауне"
    scene 29_sonya_2_afternoon_sroom with dissolve
    Sonya "А . . ."
    Sonya "Тогда понятно"
    scene 30_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 31_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 32_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Ты так аккуратно всё делаешь . . ."
    scene 33_sonya_2_afternoon_sroom with dissolve
    gg "Это привычка?"
    scene 34_sonya_2_afternoon_sroom with dissolve
    Sonya "Ага"
    Sonya "Мне так спокойнее"
    scene 35_sonya_2_afternoon_sroom with dissolve
    Sonya "Когда всё сделано как надо"
    scene 36_sonya_2_afternoon_sroom with dissolve
    Sonya "Готово"
    scene 37_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 38_sonya_2_afternoon_sroom with dissolve
    gg "Спасибо"
    scene 39_sonya_2_afternoon_sroom with dissolve
    Sonya "А у тебя . . ."
    scene 40_sonya_2_afternoon_sroom with dissolve
    Sonya "Там, в городе . . ."
    scene 41_sonya_2_afternoon_sroom with dissolve
    Sonya "Кто-нибудь остался?"
    scene 42_sonya_2_afternoon_sroom with dissolve
    gg "Был один человек"
    scene 43_sonya_2_afternoon_sroom with dissolve
    gg "Мы давно разошлись"
    scene 44_sonya_2_afternoon_sroom with dissolve
    gg "Сейчас . . .{w} скорее нет, чем да"
    scene 45_sonya_2_afternoon_sroom with dissolve
    Sonya "Понятно"
    scene 46_sonya_2_afternoon_sroom with dissolve
    Sonya "Я просто спросила"
    scene 47_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 48_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 49_sonya_2_afternoon_sroom with dissolve
    Sonya "Тогда я наверно . . ."
    scene 50_sonya_2_afternoon_sroom with dissolve
    Sonya "Буду дальше убираться, пыль быстро собирается"
    scene 51_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Спасибо еще раз"
    scene 52_sonya_2_afternoon_sroom with dissolve
    Sonya "Угу"
    scene 53_sonya_2_afternoon_sroom with dissolve
    Sonya "Если что аптечка всегда здесь"
    scene 54_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 55_sonya_2_afternoon_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)


    $ Sonya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("myroom")
    return

label sonya_scene3_day_bathroom:
    $ hide_screens()

    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)
    play fx1 shower_long 
    $ renpy.pause(delay=2, hard=True)
    scene sonya_act2_scene3_video1 with in_eye
    $ renpy.pause(delay=6, hard=True)
    scene black with out_eye
    $ renpy.pause(delay=2, hard=True)
    $ renpy.music.set_volume(0.3, delay=1, channel='fx1')
    scene 1_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 2_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Эмм Соня, я тут"
    scene 3_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 4_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene sonya_act2_scene3_video2 with dissolve
    pause
    scene 5_sonya_3_afternoon_bathroom with dissolve
    Sonya "Ой"
    scene 6_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 7_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 8_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    play sound doorloadclose
    scene 9_sonya_3_afternoon_bathroom with vpunch
    $ renpy.pause(delay=2, hard=True)
    scene 10_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 11_sonya_3_afternoon_bathroom with dissolve
    Sonya "Прости"
    scene 12_sonya_3_afternoon_bathroom with dissolve
    Sonya "Я думала, ванная свободна"
    scene 13_sonya_3_afternoon_bathroom with dissolve
    Sonya "Это моя ошибка"
    scene 14_sonya_3_afternoon_bathroom with dissolve
    gg "Всё нормально"
    scene 15_sonya_3_afternoon_bathroom with dissolve
    gg "Ничего страшного"
    scene 16_sonya_3_afternoon_bathroom with dissolve
    Sonya "{size=*1.3}Нет"
    scene 17_sonya_3_afternoon_bathroom with dissolve
    Sonya "Я просто сделаю вид"
    scene 18_sonya_3_afternoon_bathroom with dissolve
    Sonya "Что этого не было"
    play sound faststeps
    scene 19_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 20_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 21_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    stop fx1 fadeout 1
    scene black with out_eye
    $ renpy.pause(delay=1, hard=True)
    scene 22_sonya_3_afternoon_bathroom with in_eye
    $ renpy.pause(delay=1, hard=True)
    scene 23_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 24_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 26_sonya_3_afternoon_bathroom with dissolve
    Sonya "Я оставила тебе чай на кухне"
    scene 27_sonya_3_afternoon_bathroom with dissolve
    Sonya "Горячий, аккуратнее"
    scene 28_sonya_3_afternoon_bathroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Спасибо"
    $ renpy.pause(delay=1, hard=True)

    $ Sonya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump("myroom")
    return

label sonya_scene4_morning_bathroom:
    $ hide_screens()
    scene sonya_morning_bathroom (1) with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound closedoor
    scene sonya_morning_bathroom (2) with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_morning_bathroom (3) with dissolve
    pause
    scene sonya_act2_scene4_video1 with dissolve
    $ renpy.pause(delay=5, hard=True)
    scene sonya_morning_bathroom (4) with dissolve
    gg "Эм . . ."
    scene sonya_morning_bathroom (5) with dissolve
    Sonya "Ой . . ." with hpunch
    gg "Наверно, я зайду попозже"
    scene sonya_morning_bathroom (6) with dissolve
    Sonya "Стой"
    scene sonya_morning_bathroom (7) with dissolve
    Sonya "Не стесняйся. Чисти зубы, я уже заканчиваю"
    scene sonya_morning_bathroom (8) with dissolve
    gg_chat "Ого . . ."
    scene sonya_morning_bathroom (9) with dissolve
    $ renpy.pause(delay=1.2, hard=True)
    scene sonya_morning_bathroom (10) with dissolve
    Sonya "Тут раньше жили только мы с Маей"
    scene sonya_morning_bathroom (11)
    Sonya "Девушки"
    scene sonya_morning_bathroom (12)
    Sonya "Я привыкла ходить"
    scene sonya_morning_bathroom (13) with dissolve
    Sonya "Так"
    scene sonya_morning_bathroom (12) with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    Sonya "Никого это не смущало . . ."
    scene sonya_morning_bathroom (14) with dissolve
    gg "Да, где-то я уже такое видел"
    scene sonya_morning_bathroom (15) with dissolve
    Sonya "Ты смотришь . . ."
    scene sonya_morning_bathroom (16) with dissolve
    Sonya "Даже не пытаешься отвернуться"
    scene sonya_act2_scene4_video2 with dissolve
    pause
    Sonya "И знаешь . . ."
    scene sonya_morning_bathroom (17) with dissolve
    Sonya "Мне это нравится . . ."
    scene sonya_morning_bathroom (18) with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_morning_bathroom (19) with dissolve
    Sonya "Всё"
    scene sonya_morning_bathroom (20) with dissolve
    Sonya "Хватит тебе утренней зарядки для глаз"
    scene sonya_morning_bathroom (21) with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_morning_bathroom (22) with dissolve
    $ renpy.pause(delay=1, hard=True)
    Sonya "Но всё же . . ."
    scene sonya_morning_bathroom (23) with dissolve
    extend " Как ты можешь смотреть"
    scene sonya_morning_bathroom (24) with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_morning_bathroom (23) with dissolve
    Sonya "И не трогать?"
    scene sonya_morning_bathroom (25) with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play sound closedoor3 volume 0.5
    scene sonya_morning_bathroom (26) with dissolve
    $ renpy.pause(delay=1, hard=True)

    $ Sonya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label sonya_scene5_night_girlroom:
    play ambient crickets_night fadein 1 fadeout 1 loop
    $ renpy.pause(delay=1, hard=True)
    play music romance fadein 2 fadeout 2
    $ hide_screens()
    Sonya "[povname]"
    $ renpy.pause(delay=1, hard=True)
    Sonya "[povname] . . ."
    scene 1_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 2_sonya_5_night_sroom with dissolve
    Sonya "[povname] . . ."
    scene sonya_act2_scene5_video1 with dissolve
    pause
    gg "А что . . ."
    scene 3_sonya_5_night_sroom with dissolve
    Sonya "Прости"
    Sonya "Я не хотела тебя резко будить"
    scene 4_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    Sonya "Просто . . . не могу заснуть"
    scene 5_sonya_5_night_sroom with dissolve
    Sonya "Ты спишь так спокойно"
    scene 6_sonya_5_night_sroom with dissolve
    Sonya "Посидишь со мной немного?"
    scene 7_sonya_5_night_sroom with dissolve
    Sonya "Пока не отпустит"
    scene 8_sonya_5_night_sroom with dissolve
    gg "Ты устала?"
    scene 9_sonya_5_night_sroom with dissolve
    Sonya "Нет,{w} не совсем"
    scene 10_sonya_5_night_sroom with dissolve
    Sonya "Просто думала"
    scene 11_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "О чём?"
    scene 12_sonya_5_night_sroom with dissolve
    Sonya "Да не важно"
    scene 13_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 14_sonya_5_night_sroom with dissolve
    gg "Ты всё время так?"
    gg "Или бывает, что расслабляешься?"
    scene 15_sonya_5_night_sroom with dissolve
    Sonya "Раньше было легче"
    scene 16_sonya_5_night_sroom with dissolve
    Sonya "Просто я"
    scene 17_sonya_5_night_sroom with dissolve
    Sonya "Привыкла держать всё под контролем"
    scene sonya_act2_scene5_video2 with dissolve
    pause
    Sonya "Ладно . . ."
    scene sonya_act2_scene5_video3 with dissolve
    $ renpy.pause(delay=6, hard=True)
    Sonya "Вот видишь"
    scene 18_sonya_5_night_sroom with dissolve
    Sonya "Даже это нормально не могу"
    scene 19_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=0.2, hard=True)
    scene 20_sonya_5_night_sroom
    $ renpy.pause(delay=1, hard=True)
    scene 21_sonya_5_night_sroom with dissolve
    Sonya "Давай просто полежим"
    scene 22_sonya_5_night_sroom with dissolve
    Sonya "Я не хочу ни о чем думать . . ."
    scene 23_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 24_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 25_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 26_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=0.1, hard=True)
    scene black with out_eye
    $ renpy.pause(delay=1, hard=True)
    scene 27_sonya_5_night_sroom with in_eye
    $ renpy.pause(delay=2, hard=True)
    scene black with out_eye
    play ambient village_amb fadein 1 fadeout 1 loop volume 0.5
    play music morning fadein 1 fadeout 1 loop
    $ renpy.pause(delay=2, hard=True)
    scene 28_sonya_5_night_sroom with in_eye
    $ renpy.pause(delay=1, hard=True)
    scene 29_sonya_5_night_sroom with dissolve
    Sonya "Спасибо . . ."
    scene 30_sonya_5_night_sroom with dissolve
    Sonya "Я давно так нормально не спала"
    scene 31_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 32_sonya_5_night_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_act2_scene5_video4 with dissolve
    pause
    scene 33_sonya_5_night_sroom with dissolve
    Sonya "Если Мая увидит нас, будет много вопросов"
    scene 34_sonya_5_night_sroom with dissolve
    Sonya "Я сделаю тебе завтрак"
    scene 35_sonya_5_night_sroom with dissolve
    Sonya "Он будет вкусным, не переживай"
    scene 36_sonya_5_night_sroom with dissolve
    stop ambient fadeout 1
    $ renpy.pause(delay=1, hard=True)
   

    $ Sonya_relations_main += 1
    call next_day
    $ current_time_index = 0
    $ current_time = "morning"
    $ current_time_translate = _("Утро")    
    $ day_number += 1
    $ renpy.transition(dissolve)
    $ renpy.jump("girlroom")
    return

label sonya_scene6_evening_myroom:
    $ hide_screens()
    scene sonya_evening_myroom (1) with dissolve 
    gg "Привет!"
    scene sonya_evening_myroom (2) with dissolve 
    Sonya "Эй, ты аниме смотришь?"
    scene sonya_evening_myroom (3) with dissolve 
    Sonya "Тут только началось"
    scene sonya_evening_myroom (4) with dissolve 
    gg "Ага, почему бы и нет"
    play sound "<from 0 to 2>audio/dress off.mp3"  fadeout 1.0
    scene sonya_evening_myroom (5) with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_evening_myroom (6) with dissolve 
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_evening_myroom (7) with dissolve 
    gg "Забавно . . ."
    scene sonya_evening_myroom (8) with dissolve 
    extend "Теперь этот диван - моя кровать"
    scene sonya_evening_myroom (9) with dissolve 
    gg "Я привык на нём фильмы смотреть, а теперь ещё и сплю здесь"
    Sonya "Вообще - то"
    scene sonya_evening_myroom (10) with dissolve 
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_evening_myroom (11) with dissolve 
    extend " раньше это была моя кровать"
    scene sonya_evening_myroom (12) with dissolve 
    Sonya "До ухода Линды"
    scene sonya_evening_myroom (13) with dissolve 
    Sonya "А она тогда жила в моей комнатe"
    $ renpy.pause(delay=0.5, hard=True)
    gg "Серьёзно?"
    scene sonya_evening_myroom (14) with dissolve 
    Sonya "Да, но потом мы сделали ремонт, чтобы всё было по - нашему"
    scene sonya_evening_myroom (15) with dissolve 
    gg "Красиво получилось . . . {w}и дом где провел детство все еще чувствуется"
    scene sonya_evening_myroom (16) with dissolve 
    $ renpy.pause(delay=0.5, hard=True)
    play sound television fadein 1 loop
    scene sonya_evening_myroom (17) with dissolve 
    "Ты мог бы идти один. Я бы справилась"
    scene sonya_evening_myroom (18) with dissolve 
    "Ты слишком спокоен. Обычно люди стараются понравиться"
    scene sonya_evening_myroom (19) with dissolve 
    "А я не хочу «стараться». Хочу, чтобы ты узнала меня настоящего"
    scene sonya_evening_myroom (20) with dissolve 
    "Знаешь, у меня есть и более интересные дела"
    scene sonya_evening_myroom (21) with dissolve 
    "Тогда почему ты всё ещё здесь?"
    scene sonya_evening_myroom (22) with dissolve 
    stop sound fadeout 1
    Sonya "Вот смотри . . ."
    scene sonya_evening_myroom (23) with dissolve 
    extend " она играет „недоступную“"
    scene sonya_evening_myroom (24) with dissolve 
    Sonya "Хотя видно, что сохнет по нему . . ."
    scene sonya_evening_myroom (25) with dissolve 
    $ renpy.pause(delay=1, hard=True)
    gg "Может, в этом и драма?"
    scene sonya_evening_myroom (26) with dissolve 
    Sonya "Драма в том, что тянет резину"
    scene sonya_evening_myroom (27) with dissolve 
    Sonya "Зачем, если всё ясно?"
    Sonya "{sc}Это раздражает{/sc}" with hpunch
    scene sonya_evening_myroom (28) with dissolve 
    gg "Ты бы решила быстрее?"
    scene sonya_evening_myroom (29) with dissolve 
    Sonya "Намного быстрее . . ."
    scene sonya_evening_myroom (30) with dissolve 
    Sonya "Скучное аниме"
    scene sonya_evening_myroom (31) with dissolve 
    Sonya "Я не могу сидеть спокойно"
    scene sonya_evening_myroom (32) with dissolve 
    gg "Тогда ложись, может, так будет легче"
    scene sonya_evening_myroom (33) with dissolve 
    Sonya "Лечь говоришь?"
    scene black with out_eye
    stop music fadeout 1
    $ renpy.pause(delay=1, hard=True)
    play sound "<from 0 to 2>audio/dress off.mp3"  fadeout 1.0
    play music sex fadein 1
    scene sonya_act2_scene6_video1 with in_eye
    pause
    Sonya "Да так спокойнее . . ."
    $ renpy.pause(delay=1, hard=True)
    menu:
        "Играешь со мной?":
            scene sonya_evening_myroom (35) with dissolve 
            Sonya "{sc}Ах . . .{/sc}"
            play sound moans_sonya1 loop
            scene sonya_act2_scene6_video2 with dissolve
            Sonya "Вот так . . ."
            Sonya "Наконец - то"
            $ renpy.pause(delay=1, hard=True)
            Sonya "Не бойся, мне нравится"
            pause
        "Мне так хорошо":
            Sonya "В ванной ты только смотрел"
            scene sonya_evening_myroom (38) with dissolve 
            Sonya "Тут я тебе помогу"
            scene sonya_evening_myroom (39) with dissolve 
            Sonya "Я знаю, что ты хочешь"
            scene sonya_evening_myroom (40) with dissolve 
            Sonya "Просто помогаю"
            play sound moans_sonya1 loop
            scene sonya_act2_scene6_video2 with dissolve 
            pause
    Sonya "Мне приятно . . . {w}даже больше, чем я ожидала"
    gg "У тебя прекрасная грудь . . . {w}мягкая и тёплая"
    gg "Идеальная"
    Sonya "Хитрый . . ."
    Sonya "Знаешь ведь, что я краснею от таких слов"
    $ renpy.pause(delay=1, hard=True)
    Sonya "Но продолжай"
    $ renpy.music.set_volume(0.3, delay=1.0, channel='music')
    play sound opendoor 
    scene sonya_evening_myroom (41) with dissolve 
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_evening_myroom (42) with dissolve 
    play sound faststeps 
    $ renpy.pause(delay=0.8, hard=True)
    scene sonya_evening_myroom (43) with dissolve 
    Maya "А что это вы тут . . ."
    scene sonya_evening_myroom (44) with dissolve 
    Maya "В обнимку сидите?"
    scene sonya_evening_myroom (45) with dissolve 
    Sonya "Аниме смотрим. {w}Но он скучный"
    gg "Да, просто аниме"
    scene sonya_evening_myroom (46) with dissolve 
    Maya "Не думайте что я этого не видела . . ."
    play sound closedoor 
    scene sonya_evening_myroom (47) with dissolve 
    Sonya "Спасибо за вечер"
    scene sonya_evening_myroom (48) with dissolve 
    Sonya "Было . . . {w} приятно"   
    play sound kiss 
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_evening_myroom (49) with dissolve 
    Sonya "Давай оставим аниме на завтра"
    Sonya "Закончим на этом, а то я и сама не остановлюсь"
    scene sonya_evening_myroom (9) with dissolve 
    gg ". . ."
    

    $ Sonya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label sonya_scene7_evening_girlroom:
    $ hide_screens()
    scene 2_sonya_3_evening_sroom with dissolve  
    $ renpy.pause(delay=0.5, hard=True) 
    scene 3_sonya_3_evening_sroom with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    Sonya "Зайдёшь ко мне?"
    scene 4_sonya_3_evening_sroom with dissolve  
    Sonya "Просто . . . {w}хочу поговорить "
    scene 5_sonya_3_evening_sroom with dissolve  
    gg "Конечно"
    scene 6_sonya_3_evening_sroom with dissolve  
    gg "Ты какая-то задумчивая"
    scene 7_sonya_3_evening_sroom with dissolve  
    Sonya "Да . . ."
    scene 8_sonya_3_evening_sroom with dissolve  
    Sonya "Просто не могу всё выкинуть из головы"
    scene 9_sonya_3_evening_sroom with dissolve 
    Sonya "Всё как-то закрутилось слишком быстро"
    scene 10_sonya_3_evening_sroom with dissolve 
    gg "В каком смысле?"
    scene 11_sonya_3_evening_sroom with dissolve 
    Sonya "Ну . . . {w}обычно я держусь спокойно"
    scene 12_sonya_3_evening_sroom with dissolve 
    Sonya "Всё у меня под контролем"
    scene 13_sonya_3_evening_sroom with dissolve  
    Sonya "Но рядом с тобой . . . {w}всё иначе"
    scene 14_sonya_3_evening_sroom with dissolve  
    gg "Иначе - это плохо?"
    scene 15_sonya_3_evening_sroom with dissolve  
    Sonya "Иногда кажется, что я делаю глупости"
    scene 16_sonya_3_evening_sroom with dissolve  
    Sonya "Такие . . . {w}нелепые"
    scene 15_sonya_3_evening_sroom with dissolve  
    Sonya "Будто я снова подросток"
    scene 17_sonya_3_evening_sroom with dissolve  
    gg " . . ."
    scene 18_sonya_3_evening_sroom with dissolve  
    Sonya "Я не уверена в своём поведении"
    Sonya "Может, я слишком тороплюсь"
    scene 19_sonya_3_evening_sroom with dissolve  
    Sonya "Может, выгляжу смешно"
    scene 20_sonya_3_evening_sroom with dissolve  
    gg "Мне так не кажется"
    scene 22_sonya_3_evening_sroom with dissolve  
    Sonya "А если вдруг?"
    Sonya "Если я правда не такая, какой должна быть?"
    scene 23_sonya_3_evening_sroom with dissolve  
    Sonya "Ты всё равно примешь меня?"
    stop music fadeout 1
    $ renpy.pause(delay=1, hard=True)
    play music romance3 fadein 1 loop
    menu:
        "Такой ты и нужна":
            scene 27_sonya_3_evening_sroom with dissolve
            gg "Мне нравишься настоящая ты"
            $ renpy.pause(delay=0.5, hard=True)
            scene 28_sonya_3_evening_sroom with dissolve
            gg "Мне не нужно, чтобы ты была какой-то другой"
            $ renpy.pause(delay=0.5, hard=True)
            scene 29_sonya_3_evening_sroom with dissolve
            $ renpy.pause(delay=0.5, hard=True)
        "Поцеловать":
            scene 24_sonya_3_evening_sroom with dissolve
            $ renpy.pause(delay=0.5, hard=True)
            scene 25_sonya_3_evening_sroom with dissolve
            $ renpy.pause(delay=0.5, hard=True)
            scene 26_sonya_3_evening_sroom with dissolve
            $ renpy.pause(delay=0.5, hard=True)
    play sound kissing loop fadein 0.5  
    scene sonya_act2_scene7_video1 with dissolve
    pause
    scene sonya_act2_scene7_video1f with dissolve
    stop sound fadeout 1
    Sonya "Спасибо . . ."
    Sonya "Это именно то что я хотела"
    scene sonya_act2_scene7_video2 with dissolve
    pause
    play sound moans_sonya1 loop
    scene sonya_act2_scene7_video3 with dissolve
    $ renpy.pause(delay=2, hard=True)
    Sonya "{sc}Да . . . Так . . .{/sc}"
    pause
    scene sonya_act2_scene7_video2 with dissolve
    pause
    scene 30_sonya_3_evening_sroom with dissolve
    stop sound fadeout 1
    Sonya "На диване ты меня трогал"
    Sonya "Теперь - моя очередь"
    scene black with out_eye
    play sound zipsound
    $ renpy.pause(delay=1.3, hard=True)
    play sound sonya_evening_sonyaroom_audio1 loop
    scene sonya_act2_scene7_video4 with in_eye
    $ renpy.pause(delay=3, hard=True)
    Sonya "Смотри на меня"
    pause
    play sound sonya_evening_sonyaroom_audio2 
    scene sonya_act2_scene7_video5  with dissolve
    $ renpy.pause(delay=5.5, hard=True)
    play sound sonya_evening_sonyaroom_audio3 loop
    scene sonya_act2_scene7_video6
    $ renpy.pause(delay=2, hard=True)
    Sonya "Всё - ты теперь мой!"
    pause
    play sound sonya_evening_sonyaroom_audio4 
    scene sonya_act2_scene7_video7 with dissolve
    $ renpy.pause(delay=9.5, hard=True)
    scene 31_sonya_3_evening_sroom with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    scene 32_sonya_3_evening_sroom with dissolve
    Sonya "Подожди тут"
    scene 33_sonya_3_evening_sroom with dissolve
    Sonya "Я быстро"
    scene 34_sonya_3_evening_sroom with dissolve  
    play sound faststeps
    $ renpy.pause(delay=1.5, hard=True)
    play sound closedoor3
    $ renpy.pause(delay=0.5, hard=True)
    gg_chat "Это случилось так быстро . . . "
    $ renpy.pause(delay=1, hard=True)
    play sound faststeps
    $ renpy.pause(delay=1.5, hard=True)
    scene 35_sonya_3_evening_sroom with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 36_sonya_3_evening_sroom with dissolve  
    Sonya "Останься"
    scene 37_sonya_3_evening_sroom with dissolve  
    Sonya "Посиди со мной"
    scene 38_sonya_3_evening_sroom with dissolve  
    Sonya "И посмотрим, куда это нас приведёт."
    $ renpy.pause(delay=1, hard=True)
    scene black with out_eye
    gg_chat "Было тепло"
    gg_chat "Я хотел остаться рядом"
    stop music fadeout 1
    $ renpy.pause(delay=1, hard=True)
    
    $ Sonya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label sonya_scene8_morning_kitchen:
    $ hide_screens()
    scene sonya_act2_scene8_video2 with dissolve  
    pause
    scene sonya_act2_scene8_video1 with dissolve
    gg "Утречка"  
    scene 1_sonya_8_morning_kitchen with dissolve  
    Sonya "Доброе утро . . ."
    scene 2_sonya_8_morning_kitchen with dissolve  
    Sonya "Я . . . почти закончила готовить, садись"
    scene 3_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=1, hard=True)
    gg "Ты рано встала"
    scene 4_sonya_8_morning_kitchen with dissolve  
    Sonya "Не спалось"
    scene 5_sonya_8_morning_kitchen with dissolve  
    Sonya "Подумала . . ."
    scene 6_sonya_8_morning_kitchen with dissolve  
    Sonya "Раз ты всё равно проснёшься . . ."
    scene 7_sonya_8_morning_kitchen with dissolve  
    Sonya "Будет хорошо, заранее приготовить тебе"
    scene 8_sonya_8_morning_kitchen with dissolve  
    play fx1 kiss
    $ renpy.pause(delay=0.5, hard=True)
    scene 9_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=1, hard=True)
    scene 10_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 11_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 12_sonya_8_morning_kitchen with dissolve  
    Sonya "Можно?"
    scene 13_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.2, hard=True)
    scene 14_sonya_8_morning_kitchen with dissolve  
    gg "Конечно"
    scene 15_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 16_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=1, hard=True)
    gg "Очень вкусно"
    scene 17_sonya_8_morning_kitchen with dissolve  
    Sonya "Я рада"
    scene 18_sonya_8_morning_kitchen with dissolve  
    Sonya "Мне важно, чтобы тебе было хорошо"
    scene 19_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=1, hard=True)
    scene 20_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 21_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=1, hard=True)
    scene 22_sonya_8_morning_kitchen with dissolve  
    Sonya "Я всю ночь думала . . ."
    $ renpy.pause(delay=2, hard=True)
    scene 23_sonya_8_morning_kitchen with dissolve  
    Sonya "Раньше я беспокоилась"
    scene 24_sonya_8_morning_kitchen with dissolve  
    Sonya "А сегодня . . ."
    scene 25_sonya_8_morning_kitchen with dissolve  
    Sonya "Мне спокойно"
    scene 26_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 27_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=1, hard=True)
    scene 28_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    play music romance3 fadein 0.5 fadeout 0.5 loop
    scene 29_sonya_8_morning_kitchen with dissolve  
    Sonya "Если ты не против . . ."
    scene 30_sonya_8_morning_kitchen with dissolve  
    Sonya "Я могу . . ."
    scene 31_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=1, hard=True)
    scene 32_sonya_8_morning_kitchen with dissolve  
    Sonya "Быть чуть ближе"
    play fx1 kissing loop fadein 0.2 fadeout 0.2
    scene sonya_act2_scene8_video3 with dissolve
    pause
    scene 33_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 34_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 35_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    play fx2 zipsound
    $ renpy.pause(delay=1, hard=True)
    scene 36_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 37_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene sonya_act2_scene8_video3 with dissolve
    pause
    $ renpy.music.set_volume(0.3, delay=0.5, channel='fx1')
    play fx2 sonya_morning_kitchen1 loop fadein 0.2 fadeout 0.2 volume 0.7
    scene sonya_act2_scene8_video4 with dissolve
    pause
    Sonya "Чувствовать, как ты становишься твёрже . . ."
    Sonya "От моего прикосновения . . . {w}это так . . ."
    Sonya ". . . Заводит. {w}Сильнее, чем я думала"
    Sonya "Смотри на меня . . . только на меня . . ."
    scene sonya_act2_scene8_video3 with dissolve
    pause
    play fx2 sonya_morning_kitchen2
    scene sonya_act2_scene8_video5 with dissolve
    # $ mark ("sonya_act2_scene8_video5")
    $ renpy.pause(delay=9.5, hard=True)
    stop fx1 fadeout 0.2 
    stop fx2 fadeout 0.2 
    # scene 38_sonya_8_morning_kitchen with dissolve
    # $ renpy.pause(delay=1, hard=True)  
    Sonya "Я . . . не знаю, как правильно это сказать . . ."
    scene 39_sonya_8_morning_kitchen with dissolve  
    Sonya "Но мне хорошо, когда ты рядом"
    scene 40_sonya_8_morning_kitchen with dissolve  
    $ renpy.pause(delay=1, hard=True)
    scene black with dissolve
    $ renpy.pause(delay=1, hard=True)


    $ Sonya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return


label sonya_scene9_night_myroom:
    $ hide_screens()
    play music romance3 fadein 0.5 fadeout 0.5 loop
    scene sonya_act2_scene9_video1 with dissolve
    $ renpy.pause(delay=1, hard=True)
    gg "Привет"
    scene 1_sonya_9_night_hall with dissolve  
    Sonya "Привет ты ещё не ложишься?"
    scene 2_sonya_9_night_hall with dissolve  
    Sonya "Тогда пойдём вместе в ванную?"
    scene 3_sonya_9_night_hall with dissolve  
    Sonya "Я хочу голову помыть . . ."
    scene 4_sonya_9_night_hall with dissolve  
    Sonya "И тебе тоже"
    scene 5_sonya_9_night_hall with dissolve  
    gg "Ну пойдем"
    scene 6_sonya_9_night_hall with dissolve
    $ renpy.pause(delay=0.5, hard=True)
    play fx2 shower_sound fadein 0.5 loop fadeout 0.5 volume 0.6  
    $ renpy.pause(delay=0.5, hard=True)
    scene 7_sonya_9_night_hall with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 8_sonya_9_night_hall with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 9_sonya_9_night_hall with dissolve  
    Sonya "Ты тоже раздевайся давай"
    scene 10_sonya_9_night_hall with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 11_sonya_9_night_hall with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 12_sonya_9_night_hall with dissolve  
    Sonya "Подожди . . ."
    scene 13_sonya_9_night_hall with dissolve  
    Sonya "У тебя молния заела"
    scene 14_sonya_9_night_hall with dissolve  
    play fx1 zipsound
    $ renpy.pause(delay=0.5, hard=True)
    scene 15_sonya_9_night_hall with dissolve  
    $ renpy.pause(delay=0.5, hard=True)
    scene 16_sonya_9_night_hall with dissolve  
    Sonya "Быстро ты . . ."
    scene 17_sonya_9_night_hall with dissolve  
    Sonya "Давай садись"
    scene 18_sonya_9_night_hall with dissolve 
    Sonya "Стой . . . не двигайся"
    scene 19_sonya_9_night_hall with dissolve 
    Sonya "Я хочу сама"
    scene sonya_act2_scene9_video2 with dissolve
    # $ mark ("sonya_act2_scene9_video2")
    pause
    gg "У меня отличный вид"
    $ renpy.pause(delay=1, hard=True)
    Sonya "Я знаю"
    scene 20_sonya_9_night_hall with dissolve 
    Sonya "Мне просто приятно, что ты смотришь"
    scene 21_sonya_9_night_hall with dissolve 
    Sonya "Теперь ты меня"
    scene sonya_act2_scene9_video3 with dissolve
    pause
    scene 22_sonya_9_night_hall with dissolve 
    Sonya "Ты точно будешь пахнуть как я"
    scene 23_sonya_9_night_hall with dissolve 
    Sonya "Ты такой тёплый сейчас . . . мне это нравится"
    scene 24_sonya_9_night_hall with dissolve 
    Sonya "Пойдём спать вместе"
    scene 25_sonya_9_night_hall with dissolve 
    Sonya "Я не хочу сегодня одна"
    scene 26_sonya_9_night_hall with dissolve 
    Sonya "Но на сегодня приключений хватит . . . а то я завтра вообще не проснусь"
    stop fx2
    scene black with dissolve
    $ renpy.pause(delay=2, hard=True)
    scene 27_sonya_9_night_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 28_sonya_9_night_hall with dissolve 
    Sonya "Спокойной ночи"
    Sonya "{bt=a3-p2.0-s3.0}Любимый"
    scene 29_sonya_9_night_hall with dissolve
    $ renpy.pause(delay=1, hard=True)
    scene 30_sonya_9_night_hall with dissolve
    $ renpy.pause(delay=1, hard=True) 
    scene 31_sonya_9_night_hall with dissolve
    gg "Спокойной"
    gg "Я правда рад, что я с тобой"
    scene 32_sonya_9_night_hall with dissolve
    play fx1 kiss
    $ renpy.pause(delay=1, hard=True) 
    scene black with out_eye
    call next_day
    $ current_time_index = 0
    $ current_time = "morning"
    $ current_time_translate = _("Утро")    
    $ day_number += 1

    $ Sonya_relations_main += 1
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return
