label sonya_Idle_morning_bathroom_scene:
    $ hide_screens()
    scene sonya_Idle_morning_bathroomvideo with dissolve
    menu:
        "Доброе утро":
            scene 1_sonya_morning_bathroom with dissolve
            Sonya "О, кто-то перестал стучаться?"
            gg "А смысл, если дверь открыта . . ."
            scene 3_sonya_morning_bathroom with dissolve
            Sonya "Смелый стал с утра . . ."
            scene 2_sonya_morning_bathroom with dissolve
            gg "Просто решил не терять привычку к риску"
            gg_chat "Она даже в такие моменты выглядит так, будто специально проверяет, насколько далеко можно зайти"
            scene 4_sonya_morning_bathroom with dissolve
            Sonya "Хочешь полюбоваться видом?"
            scene 5_sonya_morning_bathroom with dissolve
            Sonya "Я не против"
            gg "С таким предложением даже утренний кофе станет лишним"
            scene 6_sonya_morning_bathroom with dissolve
            Sonya "Ну хоть кто-то ценит мой вклад в твое утро"
            scene 7_sonya_morning_bathroom with dissolve
            gg "Смотря, что ты предложишь взамен"
            scene 8_sonya_morning_bathroom with dissolve
            Sonya "Знаешь, я бы тоже не отказалась провести утро поинтереснее"
            scene 9_sonya_morning_bathroom with dissolve
            Sonya "Особенно с тобой"
            gg "Звучит как приглашение"
            scene 10_sonya_morning_bathroom with dissolve
            Sonya "Да это оно. Но, увы, у меня дела"
            gg "Ты знаешь это нечестно"
            scene 11_sonya_morning_bathroom with dissolve
            Sonya "Я просто оставляю десерт на потом"
            scene 12_sonya_morning_bathroom with dissolve
            Sonya "Ну что ж, герой, ванная вся твоя"
            Sonya "Главное, когда будешь мыться не забудь, кто тебя вдохновил"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Пойду":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_evening_bathroom_scene:
    $ hide_screens()
    scene sonya_Idle_evening_bathroomvideo with dissolve
    menu:
        "Потрясающе выглядишь":
            scene 1_sonya_evening_bathroom with dissolve
            gg "Не думал, что можно так красиво мыться под душем"
            Sonya "Я знала, что ты заглянешь"
            Sonya "У тебя шаги узнаются ещё до двери"
            scene 2_sonya_evening_bathroom with dissolve
            gg "Хотел убедиться, что ты не уплыла в параллельную реальность"
            Sonya "Ещё нет. Хотя, если бы там было потеплее — можно было бы и остаться"
            scene 3_sonya_evening_bathroom with dissolve
            Sonya "Знаешь, если бы я захотела — могла бы тебя соблазнить прямо сейчас"
            Sonya "Только чтобы забрать себе"
            scene 4_sonya_evening_bathroom with dissolve
            Sonya "Но ты ведь тогда точно не ушёл бы, да?"
            gg "Вряд ли бы смог"
            $ renpy.pause(delay=1, hard=True)
            scene 5_sonya_evening_bathroom with dissolve
            Sonya "Вот именно, поэтому уходи"
            Sonya "Пока Мая не заглянула и не устроила мне лекцию на тему “личных границ”"
            scene 6_sonya_evening_bathroom with dissolve
            gg "Значит, спасаю нас обоих"
            Sonya "Спасай. Но не надолго"
            gg_chat "Её слова звучали полушуткой, но от этого не становилось легче"
            gg_chat "В каждой улыбке Сони теперь пряталось что-то большее, чем просто игра"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Мне пора":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_morning_girlroom_scene:
    $ hide_screens()
    scene sonya_Idle_morning_sonyaroomvideo with dissolve
    menu: 
        "Доброе утро":
            scene 1_sonya_morning_sroom with dissolve
            gg "Доброе утро. Ты уже с рассветом на работе?"
            scene 2_sonya_morning_sroom with dissolve
            Sonya "Почти. У меня тут урожай созрел, не могу бросить"
            gg "А я думал, ты в такие игры не играешь"
            scene 3_sonya_morning_sroom with dissolve
            Sonya "А зря, это лучшая медитация"
            Sonya "Никакой спешки, просто строишь, выращиваешь, приручаешь кошек"
            scene 4_sonya_morning_sroom with dissolve
            Sonya "Вот, видишь? Мой котик"
            Sonya "Зовут Барсик"
            gg "Конечно. Даже тут он с тобой"
            Sonya "Да не совсем того цвета, хотя бы не ворует еду"
            Sonya "И на клавиатуру не ложится"
            Sonya "Я построила ему дом. Маленький, но уютный"
            scene 5_sonya_morning_sroom with dissolve
            gg "Как и в жизни"
            Sonya "Возможно. Я люблю, когда всё на своих местах. Даже в пикселях"
            gg "А с монстрами что делаешь?"
            scene 6_sonya_morning_sroom with dissolve
            Sonya "Ну избегаю. Я не про битвы, я про порядок"
            Sonya "Мне нравится, когда всё под контролем"
            scene 5_sonya_morning_sroom with dissolve
            gg "Даже кот в игре слушается. Везёт тебе"
            Sonya "А ты попробуй приручи кого-нибудь - узнаешь, что это целая наука"
            gg "Думаешь, справлюсь?"
            scene 7_sonya_morning_sroom with dissolve
            Sonya "Сомневаюсь"
            Sonya "Ты не тот тип, кто строит. Скорее тот, кто случайно всё ломает"
            gg "Эй, я в детстве играл. Даже базу под землёй сделал"
            scene 8_sonya_morning_sroom with dissolve
            Sonya "Ага, и подорвал через пять минут?"
            gg "Через десять. Но всё по плану"
            scene 9_sonya_morning_sroom with dissolve
            Sonya "Тогда аккуратнее с моим миром"
            Sonya "Тут всё с любовью и без взрывчатки"
            gg "Учту. Буду только наблюдать"
            Sonya "Если хочешь, потом покажу тебе свой сад"
            Sonya "Там столько цветов и пчелок"
            gg "Звучит как место, где тебе действительно спокойно"
            Sonya "Наверное да, думаю нам стоит поиграть в будущем вместе!"
            gg "Обязательно . . ."
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Уйти":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_day_girlroom_scene:
    $ hide_screens()
    scene sonya_Idle_afternoon_sonyaroomvideo with dissolve
    menu: 
        "Привет":
            gg "Привет как дела?"
            scene 1_sonya_afternoon_sroom with dissolve
            Sonya "Эти таблицы просто издеваются надо мной . . ."
            Sonya "Хоть бросай всё и иди пасти коров"
            scene 2_sonya_afternoon_sroom with dissolve
            gg "Похоже, у тебя с ними война"
            scene 3_sonya_afternoon_sroom with dissolve
            Sonya "Война, да. И я проигрываю с первого дня"
            Sonya "Не знаю, почему все эти цифры так упрямо меня не слушаются"
            $ renpy.pause(delay=1, hard=True)
            scene 4_sonya_afternoon_sroom with dissolve
            Sonya "Знаешь, я ведь здесь выросла"
            Sonya "Ну, не прямо в этом доме, но в этом посёлке"
            gg "Правда?"
            scene 5_sonya_afternoon_sroom with dissolve
            Sonya "Да. Тогда всё казалось больше - и улицы, и дома, и даже небо"
            Sonya "Потом я уехала, думала, найду место получше, что-то новое"
            scene 6_sonya_afternoon_sroom with dissolve
            Sonya "А в итоге вернулась туда, где мне и было хорошо с самого начала"
            gg "А как ты познакомилась с Линдой?"
            scene 7_sonya_afternoon_sroom with dissolve
            Sonya "О, это было случайно"
            Sonya "Я тогда снимала комнату в соседнем доме, а она как-то увидела, что я таскаю тяжелые коробки и просто подошла помочь"
            scene 8_sonya_afternoon_sroom with dissolve
            Sonya "С тех пор мы начали общаться"
            Sonya "Она часто звала меня на чай, а потом сказала, что у неё всё равно пустует комната - и я переехала"
            scene 7_sonya_afternoon_sroom with dissolve
            gg "То есть Линда тебя приютила?"
            scene 9_sonya_afternoon_sroom with dissolve
            Sonya "Можно и так сказать"
            Sonya "Она никогда не делала из этого что-то большое, просто . . . {w}была рядом"
            Sonya "Знаешь, таких людей немного"
            scene 10_sonya_afternoon_sroom with dissolve
            Sonya "А теперь вот я за ее столом"
            Sonya "Иногда кажется, что она всё ещё где-то рядом, наблюдает и тихо подсказывает, что делать"
            gg "Может, поэтому тебе так важно всё довести до идеала"
            scene 11_sonya_afternoon_sroom with dissolve
            Sonya "Возможно. Только вот с таблицами идеала точно не получится"
            scene 9_sonya_afternoon_sroom with dissolve
            Sonya "Спасибо, что подошёл"
            Sonya "Без тебя я бы и дальше злилась на эти несчастные ячейки"
            gg "Рад помочь"
            gg "Иногда лучший способ справиться с работой - просто отвлечься"
            scene 12_sonya_afternoon_sroom with dissolve
            Sonya "Ты прав. А можешь мне чаек сделать пожалуйста . . ."
            gg "Да конечно"
            scene 13_sonya_afternoon_sroom with dissolve
            Sonya "Спасибо огромное"
            gg_chat "В ней было что-то от Линды - то же спокойствие и мягкость, только моложе, живее"
            gg_chat "И, пожалуй, даже теплее"
            if end_demo:
                call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Не мешать":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_evening_girlroom_scene:
    $ hide_screens()
    scene sonya_Idle_evening_sonyaroomvideo with dissolve
    menu: 
        "Присесть рядом":
            scene 1_sonya_evening_mroom with dissolve
            gg "Можно присесть?"
            scene 2_sonya_evening_mroom with dissolve
            Sonya "Можно . . . {w}но с тебя - плата"
            gg "Какая?"
            scene 3_sonya_evening_mroom with dissolve
            Sonya "Остаться до конца вечера"
            Sonya "И не сбежать"
            gg "Если ты обещаешь не гнать - я и до утра не уйду"
            scene 4_sonya_evening_mroom with dissolve
            Sonya "Тогда, может, и расскажу что-нибудь . . . {w}личное"
            $ renpy.pause(delay=1, hard=True)
            scene 5_sonya_evening_mroom with dissolve
            Sonya "Забавно, получилось"
            Sonya "Мы с Маей обе любим тишину, но по-разному"
            gg "В каком смысле?"
            scene 6_sonya_evening_mroom with dissolve
            Sonya "Она включает музыку, чтобы заглушить всё вокруг"
            Sonya "А я наоборот - выключаю, чтобы услышать хоть что-то своё"
            gg "Тогда у тебя получается лучше"
            scene 7_sonya_evening_mroom with dissolve
            Sonya "Ну не знаю"
            Sonya "Просто по-другому"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Позже зайду":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_night_girlroom_scene:
    $ hide_screens()
    scene sonya_Idle_night_sonyaroomvideo with dissolve
    menu: 
        "Не тревожить":
            gg "Улыбается во сне . . ."
            gg "Интересно, что ей снится, раз выглядит такой довольной"
    call next_time_dialog
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label sonya_Idle_morning_kitchen_scene:
    $ hide_screens()
    scene sonya_Idle_morning_kitchenvideo with dissolve
    menu:
        "С добрым утром":
            scene 1_sonya_morning_kitchen with dissolve
            gg "Доброе утро, командир чистоты"
            Sonya "Кто-то же должен следить, чтобы кухня не превратилась в поле боя"
            scene 2_sonya_morning_kitchen with dissolve
            gg "А вдруг Мая проснётся и решит помочь?"
            scene 3_sonya_morning_kitchen with dissolve
            Sonya "Тогда я просто вымою всё заново"
            scene 4_sonya_morning_kitchen with dissolve
            gg "Значит, тебе нравится, когда всё блестит"
            scene 5_sonya_morning_kitchen with dissolve
            Sonya "Мне нравится, когда всё под контролем"
            gg "Даже люди?"
            $ renpy.pause(delay=1, hard=True)
            scene 6_sonya_morning_kitchen with dissolve
            Sonya "С людьми сложнее"
            Sonya "Они, в отличие от кухни, редко слушаются"
            gg "Может, им просто не хватает твоего руководства"
            scene 8_sonya_morning_kitchen with dissolve
            Sonya "Осторожнее с комплиментами, а то решу, что ты тоже хочешь быть чистеньким"
            gg "Обещаю быть примерным"
            gg "Хотя недолго"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Позже загляну":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_evening_kitchen_scene:
    $ hide_screens()
    scene sonya_Idle_evening_kitchenvideo with dissolve
    menu:
        "Вкусно пахнет":
            scene 1_sonya_evening_kitchen with dissolve
            gg "Пахнет так, будто кто-то очень старается"
            scene 2_sonya_evening_kitchen with dissolve
            Sonya "А я и стараюсь"
            Sonya "Без рецепта между прочем, просто . . . {w}хочется, чтобы получилось как дома"
            gg "Ты часто так готовишь?"
            scene 3_sonya_evening_kitchen with dissolve
            Sonya "Почти каждый день. С детства так привыкла"
            Sonya "Мне нравилось видеть, как люди садятся за стол и вдруг становятся добрее"
            scene 4_sonya_evening_kitchen with dissolve
            Sonya "Еда делает людей мягче"
            Sonya "Даже тех, кто обычно каменные"
            scene 5_sonya_evening_kitchen with dissolve
            gg "Может, потому что через неё ты делишься теплом"
            Sonya "Наверное"
            Sonya "Готовить - это ведь не просто накормить"
            Sonya "Это сказать: “ты можешь остаться”"
            scene 6_sonya_evening_kitchen with dissolve
            Sonya "Помню, в детстве всё время помогала на кухне"
            Sonya "Мама только улыбалась - говорила, что из меня выйдет не повар, а “дом в человеческом виде”"
            scene 7_sonya_evening_kitchen with dissolve
            gg "Звучит будто про тебя"
            scene 8_sonya_evening_kitchen with dissolve
            Sonya "Ну вот, ужин готов"
            Sonya "Без изысков, но с душой"
            scene 9_sonya_evening_kitchen with dissolve
            gg "Это вкуснее, чем изысканно"
            Sonya "Вот и хорошо"
            Sonya "Значит, не зря старалась"
            scene 10_sonya_evening_kitchen with dissolve
            Sonya "Знаешь, мне нравится кормить людей"
            Sonya "Это самое простое, но честное, что я умею делать"
            scene 11_sonya_evening_kitchen with dissolve
            Sonya "Когда кто - то ест то, что ты приготовил, - он словно доверяет тебе"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Пойду":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_day_kitchen_scene:
    $ hide_screens()
    scene sonya_Idle_afternoon_kitchenvideo with dissolve
    menu:
        "Ждешь чайник?":
            scene 1_sonya_afternoon_kitchen with dissolve
            gg "Всё ещё ждёшь, пока чайник закипит?"
            scene 2_sonya_afternoon_kitchen with dissolve
            Sonya "Этот чайник кипит только если чувствует внимание. И настроение"
            scene 3_sonya_afternoon_kitchen with dissolve
            gg "У него характер как у людей здесь"
            Sonya "Точно. Кстати чтобы узнать получше людей здесь"
            $ renpy.pause(delay=1, hard=True)
            scene 4_sonya_afternoon_kitchen with dissolve
            Sonya "Тут есть пара мест для прогулок"
            Sonya "Парк — небольшой, но с лавками, где можно застрять на час"   
            scene 5_sonya_afternoon_kitchen with dissolve
            gg "И всё?" 
            scene 6_sonya_afternoon_kitchen with dissolve
            Sonya "Ещё озеро. Маленькое, но красивое, особенно вечером"
            Sonya "Только вода бодрит так, что потом спать не хочется"
            scene 7_sonya_afternoon_kitchen with dissolve
            Sonya "По субботам базар. Там продают всё — от мёда до слухов"
            gg "А многоэтажка — это правда?"
            scene 8_sonya_afternoon_kitchen with dissolve
            Sonya "Правда. Наш “город в одном доме”"
            Sonya "Там почта, офис и девушка, которая считает себя айтишником"
            scene 9_sonya_afternoon_kitchen with dissolve
            Sonya "Вот и всё веселье. Но если смотреть внимательно — здесь больше жизни, чем кажется"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Уйти":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_morning_myroom_scene:
    $ hide_screens()
    scene sonya_Idle_morning_myroomvideo with dissolve
    menu:
        "Опять с тряпкой?":
            scene 1_sonya_morning_zal with dissolve
            Sonya "Ой . . . не разбудила?"
            gg "Нет, просто не привык, что по утрам кто-то сражается с пылью"
            scene 2_sonya_morning_zal with dissolve
            Sonya "У каждого своё утро"
            Sonya "Моё - с уборки"
            scene 3_sonya_morning_zal with dissolve
            gg "Не думал, что ты одна из тех, кто так любит уборку"
            scene 4_sonya_morning_zal with dissolve
            Sonya "Не люблю. {w}Просто, если не я, никто не сделает"
            Sonya "Когда я сюда приехала, дом был знаешь . . . {w}какой-то пустой"
            Sonya "Линда тогда часто уезжала, а Мая только въехала"
            Sonya "Всё было вверх дном"
            Sonya "Я осталась - просто чтобы стало немного тише"
            gg "И осталась до сих пор?"
            scene 5_sonya_morning_zal with dissolve
            Sonya "Ага. Потом привыкла"
            Sonya "Линда как-то сказала, что дом любит, когда в нём кто-то есть"
            scene 6_sonya_morning_zal with dissolve
            Sonya "Может, я просто не смогла уехать"
            scene 5_sonya_morning_zal with dissolve
            gg "А Мая? Вы ведь такие разные"
            scene 7_sonya_morning_zal with dissolve
            Sonya "Очень"
            scene 8_sonya_morning_zal with dissolve
            Sonya "Я - про порядок, она - про хаос. Но в этом и суть"
            $ renpy.pause(delay=1, hard=True)
            scene 9_sonya_morning_zal with dissolve
            Sonya "Знаешь, иногда кажется, что мы друг друга уравновешиваем"
            Sonya "Я заставляю её остановиться, а она - меня жить чуть громче"
            gg "Похоже, вы нашли баланс"
            scene 10_sonya_morning_zal with dissolve
            Sonya "Баланс - вещь хрупкая"
            scene 11_sonya_morning_zal with dissolve
            Sonya "Но, кажется, с тобой он только крепче стал"
            scene 8_sonya_morning_zal with dissolve
            Sonya "В смысле . . . просто в доме стало уютнее"
            scene 9_sonya_morning_zal with dissolve
            Sonya "Вот и всё"
            gg "Конечно. Только уют"
            Sonya "Вот именно. Только уют"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Пойду":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_day_myroom_scene:
    $ hide_screens()
    scene sonya_Idle_afternoon_myroomvideo with dissolve
    menu:
        "Привет":
            gg "Привет за цветами ухаживаешь?"
            scene 1_sonya_afternoon_zal with dissolve
            Sonya "Знаешь, за цветами нужно постоянно следить"
            scene 2_sonya_afternoon_zal with dissolve
            Sonya "Не слишком много воды, не слишком мало. . .  иначе начинают вянуть"
            gg "Значит, всё дело в балансе"
            scene 3_sonya_afternoon_zal with dissolve
            Sonya "Внимание и время - вот что им действительно нужно"
            Sonya "Не полил день - и всё, сразу обижаются"
            scene 4_sonya_afternoon_zal with dissolve
            Sonya "У каждого из них свой характер"
            scene 5_sonya_afternoon_zal with dissolve
            Sonya "Один тянется к свету, другой прячется в тень"
            Sonya "Есть те, кто растёт быстро, а есть, кому нужно просто больше терпения"
            gg "Звучит как целая наука"
            scene 6_sonya_afternoon_zal with dissolve
            Sonya "Может, и так. Только всё приходится чувствовать"
            scene 7_sonya_afternoon_zal with dissolve
            Sonya "Иногда они долго не цветут, и кажется, что всё зря"
            Sonya "А потом вдруг - один день, и раскрывается бутон"
            scene 8_sonya_afternoon_zal with dissolve
            Sonya "Линда всегда говорила, что цветы живут там, где им хорошо"
            Sonya "Не потому что солнце ярче, а потому что рядом кто-то заботится"
            gg "Наверное, это правда"
            scene 9_sonya_afternoon_zal with dissolve
            Sonya "Думаю, да"
            Sonya "Просто не все замечают, как это важно"
            Sonya "Иногда достаточно совсем немного - тепла, слова, присутствия"
            scene 10_sonya_afternoon_zal with dissolve
            Sonya "Главное - не перекормить заботой"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Уйти":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label sonya_Idle_evening_myroom_scene:
    $ hide_screens()
    scene sonya_Idle_evening_myroomvideo with dissolve
    menu:
        "Что смотрим?":
            scene 1_sonya_evening_zal with dissolve
            Sonya "Так, у нас есть романтика, комедия, и . . . хоррор"
            scene 2_sonya_evening_zal with dissolve
            gg "Хоррор? Ты же потом не заснёшь"
            scene 3_sonya_evening_zal with dissolve
            Sonya "Ну тогда разбужу тебя и будем болтать до утра . . ."
            Sonya "Вместе страдать от бессонницы"
            gg "Ну если ты вдруг случайно начнёшь засыпать - я тебе не дам"
            scene 4_sonya_evening_zal with dissolve
            Sonya "Просто люблю, когда немного страшно"
            Sonya "В таких фильмах хоть что-то происходит по-настоящему"
            scene 5_sonya_evening_zal with dissolve
            gg "А ты не боишься?"
            scene 6_sonya_evening_zal with dissolve
            Sonya "Боюсь. {w}Но мне нравится, когда страшно только снаружи, а внутри спокойно"
            scene 7_sonya_evening_zal with dissolve
            Sonya "Хотя, если вдруг будет слишком жутко - я, может, чуть-чуть прижмусь. Для науки"
            gg "Чисто научный эксперимент?"
            Sonya "Конечно. Проверим, снижается ли уровень паники при тесном контакте"
            scene 9_sonya_evening_zal with dissolve
            $ renpy.pause(delay=0.5, hard=True)
            scene 8_sonya_evening_zal with dissolve
            Sonya "Вот видишь, уже началось"
            gg "И как результаты эксперимента?"
            scene 10_sonya_evening_zal with dissolve
            Sonya "Пока эффект положительный"
            Sonya "Но для точности нужно дождаться кульминации"
            Sonya "В такие вечера даже страх кажется уютным"
            gg "Только если есть кому его разделить"
            Sonya "Думаю, у нас с этим всё в порядке"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Уйти":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return
