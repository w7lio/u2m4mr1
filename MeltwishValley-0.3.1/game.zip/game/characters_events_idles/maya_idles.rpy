label maya_Idle_day_myroom_scene:
    $ hide_screens()
    scene maya_Idle_afternoon_myroomvideo with dissolve
    menu:
        "Барсик у тебя?":
            scene 1_maya_afternoon_zal with dissolve
            gg "А я думал, этот предатель спит только у Сони"
            scene 2_maya_afternoon_zal with dissolve
            Maya "Он выбирает по настроению"
            Maya "Сегодня, видимо, у меня нужная температура коленей"
            gg "Или просто знаешь, чем подкупить"
            scene 3_maya_afternoon_zal with dissolve
            Maya "Конечно"
            Maya "Я его нашла - я и лицензированный поставщик любви и корма"
            gg "Нашла?"
            scene 4_maya_afternoon_zal with dissolve
            Maya "Год назад. Под дождём, под машиной сидел"
            Maya "Маленький, грязный, дрожал, а я шла домой с кофе"
            Maya "И подумала: “Ладно, кофе подождёт”"
            scene 5_maya_afternoon_zal with dissolve
            Maya "С тех пор он решил, что я его персональный обогреватель"
            scene 6_maya_afternoon_zal with dissolve
            gg "Повезло ему"
            scene 7_maya_afternoon_zal with dissolve
            Maya "Ага. Только не говори Соне, что я так сказала"
            Maya "Она делает вид, что ей всё равно, но я видела, как она однажды сушила ему лапы феном"
            gg "Правда? Не ожидал"
            Maya "Ну, она просто не из тех, кто сюсюкает. Но и не выгонит"
            Maya "Иногда подкармливает, когда думает, что я не вижу"
            Maya "У нас, знаешь, баланс: я - шум, она - порядок, а Барсик - нейтральная территория"
            gg "И кто из вас лидер?"
            scene 8_maya_afternoon_zal with dissolve
            Maya "Он. Сто процентов"
            Maya "Ему всё равно, кто орёт, кто убирает - он всё равно получает своё место и миску"
            scene 1_maya_afternoon_zal with dissolve
            Maya "Видишь? {w}Даже в доме с нами двумя кто-то умеет быть по-настоящему счастливым"
            scene 2_maya_afternoon_zal with dissolve
            gg "Может, секрет в том, чтобы просто мурчать и не спорить"
            Maya "Или в том, чтобы спать на тёплом и не думать"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Позже зайду":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label maya_Idle_morning_myroom_scene:
    $ hide_screens()
    scene maya_Idle_morning_myroomvideo with dissolve
    menu:
        "С книжкой с утра?":
            scene 1_maya_morning_zal with dissolve
            gg "Уже читаешь? . . ."
            Maya "Ага. Утро тихое, редкость"
            Maya "Грех не пользоваться, пока никто не шумит и не ищет кружку"
            gg "Что на этот раз?"
            scene 2_maya_morning_zal with dissolve
            Maya "Манга"
            Maya "После Линдиных книг захотелось чего-то полегче"
            scene 3_maya_morning_zal with dissolve
            Maya "Она могла читать про философию даже за ужином"
            Maya "Я же за ужином максимум комментирую философию людей в интернете"
            scene 4_maya_morning_zal with dissolve
            Maya "Хотя по этой манге не скажешь"
            Maya "Автор явно страдал, но красиво"
            gg "К картинкам и эмоциям?"
            scene 5_maya_morning_zal with dissolve
            Maya "К историям, где герои хотя бы честные"
            scene 6_maya_morning_zal with dissolve
            Maya "Иногда читаю японское или корейское"
            Maya "У них всё немного грустно, но по-тёплому"
            Maya "В отличие от наших драм, где все страдают просто из принципа"
            gg "Под настроение, значит"
            scene 7_maya_morning_zal with dissolve
            Maya "Угу. Когда настроение “оставьте меня в покое, но с уютом”"
            gg "Ты давно здесь?"
            scene 8_maya_morning_zal with dissolve
            Maya "Год, может чуть больше"
            Maya "После универа приехала в посёлок работать. Захотелось тишины и воздуха"
            scene 9_maya_morning_zal with dissolve
            Maya "Искала жильё - наткнулась на объявление: “Сдам комнату. Дом с садом”"
            Maya "Открывает дверь Линда и спрашивает: “Ты громкая?”"
            Maya "Я ответила: “Только когда думаю.” Она засмеялась и сказала: “Тогда уживайся”"
            gg "И Соня уже тут была?"
            scene 10_maya_morning_zal with dissolve
            Maya "Да. Мы познакомились на кухне, где я чуть не спалила чайник"
            Maya "С тех пор она - порядок, я - импровизация"
            Maya "Иногда даже чай кипит от ужаса"
            Maya "Линда звала нас “шум и тишина”"
            Maya "Хотя, скорее, “тишина и источник хаоса”"
            gg "А теперь ещё и я"
            scene 12_maya_morning_zal with dissolve
            Maya "Теперь да. Баланс окончательно нарушен, но зато весело"
            scene 11_maya_morning_zal with dissolve
            Maya "Вон, слышишь? Она уже с шести на ногах"
            Maya "Я так пробовала - уснула прямо с кружкой в руке"
            Maya "Зато хоть кто-то следит, чтобы дом не просыпался в хаосе. Я - больше за безделие"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Не мешаю":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label maya_Idle_evening_bathroom_scene:
    $ hide_screens()
    scene maya_Idle_evening_bathroomvideo with dissolve
    menu:
        "Ко сну готовишься?":
            scene 1_maya_evening_bathroom with dissolve
            gg "Ко сну готовишься?"
            Maya "Ага. Осталось немного. Главное, чтобы никто не отвлекал"
            Maya "А то всё придётся начинать заново — тут процесс деликатный"
            gg "Надеюсь, ты не про стирку опять"
            scene 2_maya_evening_bathroom with dissolve
            Maya "А что, если и про неё? Не все вещи выдерживают жёсткий режим"
            gg "В прошлый раз ты, кажется, не всё достирала"
            scene 3_maya_evening_bathroom with dissolve
            Maya "Ха. Ну, издержки ручной работы. Зато результат запомнился, верно?"
            gg "Даже слишком"
            scene 4_maya_evening_bathroom with dissolve
            Maya "Значит, не зря старалась"
            scene 5_maya_evening_bathroom with dissolve
            Maya "Правда, немного смущалась. Такое со мной редко бывает"
            gg "Удивительно. Я думал, ты вообще не из тех, кто смущается"
            scene 6_maya_evening_bathroom with dissolve
            Maya "Все когда-то ошибаются. Но не переживай, в следующий раз я компенсирую моральный ущерб"
            gg "Это угроза или обещание?"
            scene 7_maya_evening_bathroom with dissolve
            Maya "Назови это приглашением на повторный эксперимент"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Не буду мешать":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label maya_Idle_morning_kitchen_scene:
    $ hide_screens()
    scene maya_Idle_morning_kitchenvideo with dissolve
    menu:
        "Новый рецепт?":
            scene 1_maya_morning_kitchen with dissolve
            gg "Это так теперь готовят яищницу?"
            Maya "Умник. Не все рождаются с магией кулинарии, ладно?"
            Maya "Обычно Соня этим занимается"
            scene 2_maya_morning_kitchen with dissolve
            Maya "Вот, видишь? Сковородка меня ненавидит"
            gg "Ага, ты с ней просто не разговариваешь достаточно вежливо"
            scene 3_maya_morning_kitchen with dissolve
            Maya "Серьёзно? Может, ей ещё комплимент сказать?"
            gg "Можешь попробовать. Я подстрахую, если начнёт мстить"
            scene 4_maya_morning_kitchen with dissolve
            Maya "Вот именно поэтому я по утрам не встаю"
            scene 5_maya_morning_kitchen with dissolve
            Maya "Мир в это время суток явно против меня"
            gg "А я думал, это просто твой ритуал - проспать завтрак и появиться к обеду"
            scene 6_maya_morning_kitchen with dissolve
            Maya "Был"
            Maya "Но с твоим появлением режим сбился"
            scene 7_maya_morning_kitchen with dissolve
            Maya "Знаешь . . . {w}странно, когда в доме появился кто-то третий"
            scene 8_maya_morning_kitchen with dissolve
            gg "“Странно” - в хорошем смысле?"
            scene 9_maya_morning_kitchen with dissolve
            Maya "Скорее . . . непривычно."
            Maya "Мы с Соней как будто уже притёрлись. У неё - тишина, у меня - беспорядок"
            Maya "А теперь добавился ты. И вроде ничего не изменилось, но стало . . . другое"
            scene 8_maya_morning_kitchen with dissolve
            gg "Надеюсь, не хуже"
            Maya "Пока нет"
            Maya "Иногда даже спокойнее . . . а иногда бесишь"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Не мешаю":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label maya_Idle_day_kitchen_scene:
    $ hide_screens()
    scene maya_Idle_afternoon_kitchenvideo with dissolve
    menu:
        "Газировка кончилась?":
            scene 1_maya_afternoon_kitchen with dissolve
            gg "Не верится"
            gg "Ты с чаем? Где же твоя коллекция вредных газировок?"
            scene 2_maya_afternoon_kitchen with dissolve
            Maya "Иногда организм хочет чай и все"
            Maya "И не хочу, чтобы Соня опять читала лекцию о “здоровом балансе”"
            gg "О, значит, это не просто чай - это акт самопожертвования"
            scene 3_maya_afternoon_kitchen with dissolve
            Maya "Ага. Пью и страдаю"
            scene 4_maya_afternoon_kitchen with dissolve
            Maya "Ладно, раз уж ты сам подошёл - что планируешь делать?"
            gg "В смысле?"
            scene 5_maya_afternoon_kitchen with dissolve
            Maya "Ну, в целом"
            Maya "Сидеть, отдыхать, страдать или притворяться, что у тебя есть план?"
            gg "План есть - не иметь плана. Хотя, если честно, я просто устал от города"
            gg "Хотел отдохнуть, помочь бабушке с домом . . . {w}ну, а теперь, похоже, пора искать работу"
            scene 6_maya_afternoon_kitchen with dissolve
            Maya "Добро пожаловать в реальность"
            Maya "И где ищут работу люди, которые сбежали от людей?"
            scene 7_maya_afternoon_kitchen with dissolve
            gg "Пока не знаю. Может, в посёлке что-то найду"
            gg "Мне и ритм нравится - медленный, настоящий"
            Maya "Настоящий?"
            Maya "Это пока ты не застрянешь тут зимой"
            gg "Зато не метро и не толпы"
            scene 8_maya_afternoon_kitchen with dissolve
            Maya "Ну да. Только мы и Барсик, который судя по всему - местный депутат"
            gg "Главное, чтобы не требовал отчёта о проделанной работе"
            scene 9_maya_afternoon_kitchen with dissolve
            Maya "Ага. Хотя Соня могла бы - она бы тебе график расписала"
            gg "Я замечал. У неё всё как по часам"
            scene 10_maya_afternoon_kitchen with dissolve
            Maya "Потому что кто-то в этом доме должен компенсировать мой хаос"
            scene 11_maya_afternoon_kitchen with dissolve
            Maya "Так что, если решишь остаться надолго, готовься привыкать к контрастам"
            gg "Мне кажется, я уже начинаю"
            Maya "Осторожнее"
            Maya "Это затягивает"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Пойду":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label maya_Idle_morning_mayaroom_scene:
    $ hide_screens()
    scene maya_Idle_morning_mayaroomvideo with dissolve
    menu:
        "Не беспокоить":
            gg ". . . "
            gg "Так сладко спит"
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label maya_Idle_day_mayaroom_scene:
    $ hide_screens()
    scene maya_Idle_afternoon_mayaroomvideo with dissolve
    menu:
        "Музыку миксуешь?":
            scene 1_maya_afternoon_mroom with dissolve 
            gg "Серьёзный вид"
            gg "Ты что, музыку миксуешь?"
            scene 2_maya_afternoon_mroom with dissolve 
            Maya "Ха, мечтай. Работаю"
            gg "Звучит опасно. А я думал, ты против дисциплины"
            scene 3_maya_afternoon_mroom with dissolve 
            Maya "Я против бессмысленной дисциплины"
            Maya "Но если платят - можно и притвориться взрослой"
            gg "И что за работа?"
            scene 4_maya_afternoon_mroom with dissolve 
            Maya "Связано с проектами. Неинтересно"
            Maya "Раньше приходилось ездить в офис, а теперь могу делать всё из дома"
            scene 5_maya_afternoon_mroom with dissolve 
            Maya "Так что не мешай моей продуктивности"
            gg "Не мешаю"
            gg "Просто проверяю, не заснула ли ты с открытым документом"
            scene 6_maya_afternoon_mroom with dissolve 
            Maya "Ещё нет"
            Maya "Но если будешь стоять и таращиться, это ускорит процесс"
            $ renpy.pause(delay=1, hard=True)
            scene 1_maya_afternoon_mroom with dissolve 
            Maya "И да, на будущее . . ."
            Maya "Стучи, когда входишь"
            gg "А ты дверь закрывай, если хочешь секретности"
            scene 2_maya_afternoon_mroom with dissolve 
            Maya "Закрытая дверь - это скучно"
            Maya "Мне нравится знать, что кто-то может ввалиться в самый неподходящий момент. Добавляет адреналина"
            gg "Опасное хобби"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Уйти":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label maya_Idle_evening_mayaroom_scene:
    $ hide_screens()
    scene maya_Idle_evening_mayaroomvideo with dissolve
    menu:
        "Опять зависла?":
            scene 1_maya_evening_mroom with dissolve 
            gg "Опять зависла?"
            scene 2_maya_evening_mroom with dissolve 
            Maya "Называется “отдыхаю”"
            Maya "Иногда даже без музыки"
            gg "Опасный эксперимент"
            Maya "Ага. Учёные уже фиксируют первые побочные эффекты - мысли начали возвращаться"
            gg "О чём думаешь?"
            scene 3_maya_evening_mroom with dissolve 
            Maya "Ни о чём особенном. Просто день какой-то неспокойный"
            $ renpy.pause(delay=1, hard=True)
            Maya "Иногда мне кажется, что этот дом дышит"
            Maya "Когда все расходятся по комнатам, он будто вздыхает - типа “наконец-то”"
            gg "Может, он просто устал от нас"
            scene 4_maya_evening_mroom with dissolve 
            Maya "Или от тебя"
            Maya "Ты ж теперь главный источник событий"
            gg "Ну спасибо"
            gg "Хоть не шумовой загрязнитель"
            scene 5_maya_evening_mroom with dissolve 
            Maya "Не переживай, ты в двух шагах от этого звания"
            $ renpy.pause(delay=1, hard=True)
            scene 6_maya_evening_mroom with dissolve 
            gg "Ладно, не мешаю твоему “отдыханию”"
            Maya "Уже поздно. Ты в моём поле общения, это необратимо"
            gg "Тогда я официально заражён"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Уйти":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return

label maya_Idle_night_mayaroom_scene:
    $ hide_screens()
    scene maya_Idle_night_mayaroomvideo with dissolve
    menu:
        "Не беспокоить":
            gg "Спит без задних ног . . ."
            gg "Хоть будильник под ухом взрывай — не проснётся"
    $ renpy.transition(dissolve)
    $ renpy.jump(current_label)
    return

label maya_Idle_evening_myroom_scene:
    $ hide_screens()
    scene maya_Idle_evening_myroomvideo with dissolve
    menu:
        "Засыпаешь?":
            scene 1_maya_evening_zal with dissolve
            gg "Засыпаешь?"
            scene 2_maya_evening_zal with dissolve
            Maya "Нет. Просто отдыхаю в позе ленивой медитации"
            gg "Выглядит как битва с подушкой на выживание"
            scene 3_maya_evening_zal with dissolve
            Maya "Ха. Не завидуй"
            $ renpy.pause(delay=1, hard=True)
            gg "Соня говорила что спала раньше на этом диване. Он удобный"
            Maya "Ага. Она любила здесь засыпать под телевизор"
            Maya "Говорила, что этот гул помогает думать"
            $ renpy.pause(delay=1, hard=True)
            scene 4_maya_evening_zal with dissolve
            Maya "А теперь вот ты"
            Maya "И диван как будто сменил хозяина"
            gg "Ничего, я постараюсь не испортить его репутацию"
            Maya "Да уж, будь добр"
            Maya "У него длинная история, он видел больше ссор и сериалов, чем мы оба вместе"
            gg "Кстати, а вы вообще платите Линде за жильё? Или это всё “по знакомству”?"
            scene 5_maya_evening_zal with dissolve
            Maya "Платим . . . {w}Ну как “платим” - скорее благодарим"
            Maya "Сумма символическая, Линда больше из принципа берёт, чем из необходимости"
            Maya "Её это, кажется, успокаивает: типа дом не стоит пустой и приносит пользу"
            gg "Узнаю свою бабушку"
            scene 6_maya_evening_zal with dissolve
            Maya "Ага. Только вот было бы ещё хорошо, если бы она хотя бы предупредила, что внучок вот-вот приедет"
            Maya "Я чуть не упала тогда, когда ты появился в дверях"
            Maya "Уже чего только не думала"
            gg "Извини, я тоже не ожидал, что в доме будут люди"
            Maya "Вот и замечательно"
            Maya "Никто ничего не ожидал - поэтому всё как обычно"
            $ renpy.pause(delay=1, hard=True)
            scene 7_maya_evening_zal with dissolve
            Maya "Знаешь, может, это и к лучшему"
            gg "Я стараюсь как лучше"
            Maya "Ладно, ты уже часть декора"
            Maya "Даже телевизор теперь включается по тебе"
            gg "В смысле?"
            Maya "Стоит тебе появиться - сразу что-то происходит. Иногда полезное, иногда нет"
            Maya "Но скучно с тобой не бывает"
            scene 8_maya_evening_zal with dissolve
            Maya "Всё, вечер окончен"
            Maya "Телевизор устал смотреть на нас"
            gg "Тогда спокойной ночи"
            Maya "Ага. И не растяни диван - он к тебе уже привязался"
            call next_time_dialog
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
        "Уйти":
            $ renpy.transition(dissolve)
            $ renpy.jump(current_label)
    return