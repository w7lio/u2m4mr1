﻿################################################################################
## Инициализация
################################################################################



init offset = -1


################################################################################
## Стили
################################################################################
# init python:

#     class TrackCursor(renpy.Displayable):

#         def __init__(self, child, paramod, **kwargs):

#             super(TrackCursor, self).__init__()
#             self.child = renpy.displayable(child)

#             self.x = None
#             self.y = None
#             self.paramod = paramod

#         def render(self, width, height, st, at):

#             rv = renpy.Render(width, height)

#             if self.x is not None:
#                 cr = renpy.render(self.child, width, height, st, at)
#                 cw, ch = cr.get_size()
#                 rv.blit(cr, (self.x, self.y))

#             return rv

#         def event(self, ev, x, y, st):

#             if (x != self.x) or (y != self.y):
#                 self.x = -x /self.paramod
#                 self.y = -y /self.paramod
#                 renpy.redraw(self, 0)
init python:
    renpy.music.register_channel("fx1", "sfx", loop=False)
    renpy.music.register_channel("fx2", "sfx", loop=False)
    renpy.music.register_channel("fx3", "sfx", loop=False)
    renpy.music.register_channel("ambient", "sfx", loop=False)


init python:
    # Vertical gradient shader
    renpy.register_shader("vertical.gradient", variables="""
        uniform vec4 u_gradient_color_top;
        uniform vec4 u_gradient_color_bottom;
        uniform vec2 u_model_size;
        varying float v_gradient_done;
        attribute vec4 a_position;
    """, vertex_300="""
        v_gradient_done = a_position.y / u_model_size.y;
    """, fragment_300="""
        float gradient_done = v_gradient_done;
        gl_FragColor *= mix(u_gradient_color_top, u_gradient_color_bottom, gradient_done);
    """)

# Horizontal gradient shader
    renpy.register_shader("horizontal.gradient", variables="""
        uniform vec4 u_gradient_color_left;
        uniform vec4 u_gradient_color_right;
        uniform vec2 u_model_size;
        varying float v_gradient_done;
        attribute vec4 a_position;
    """, vertex_300="""
        v_gradient_done = a_position.x / u_model_size.x;
    """, fragment_300="""
        float gradient_done = v_gradient_done;
        gl_FragColor *= mix(u_gradient_color_left, u_gradient_color_right, gradient_done);
    """)



style default:
    properties gui.text_properties()
    language gui.language

style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

style hyperlink_text:
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True

style gui_text:
    properties gui.text_properties("interface")


style button:
    properties gui.button_properties("button")

style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5


style label_text is gui_text:
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    properties gui.text_properties("prompt")


style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.png" yalign 0.5
        

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"


style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)



################################################################################
## Внутриигровые экраны
################################################################################


## Экран разговора #############################################################
##
## Экран разговора используется для показа диалога игроку. Он использует два
## параметра — who и what — что, соответственно, имя говорящего персонажа и
## показываемый текст. (Параметр who может быть None, если имя не задано.)
##
## Этот экран должен создать текст с id "what", чтобы Ren'Py могла показать
## текст. Здесь также можно создать наложения с id "who" и id "window", чтобы
## применить к ним настройки стиля.
##
## https://www.renpy.org/doc/html/screen_special.html#say






screen say(who, what):

    window:
        id "window"
        add "gui/textbox.png" xalign 0.5 yalign 1.0 alpha dialogue_box_opacity
        if who is not None:
            window:
                id "namebox"
                style "namebox"
                if who == povname or who == "*" + povname + "*":
                    text who id "who" at gradientPlayer
                elif who in ['Мая', 'Maya', '可能', 'Maya', 'Maya', 'Maya']:
                    text who id "who" at gradientbluepurple
                elif who in ['Соня', 'Sonya', '索尼娅', 'Sonya', 'Sônia', 'Sonia']:
                    text who id "who" at gradientPink
                elif who in ['Кейт', 'Kate', '凯特', 'Kate', 'Kate', 'Kate']:
                    text who id "who" at gradientKate
                elif who in ['Почтальон', 'Postman', '邮差', 'Facteur', 'Carteira', 'Cartera']:
                    text who id "who" at gradientPostGirl
                elif who in ['Secretary', 'Секретарь', '秘书', 'Secrétaire', 'Secretária', 'Secretaria']:
                    text who id "who" at gradientAssistent
                elif who in ['Директор', 'Director', '导演', 'Directeur', 'Diretora', 'Director']:
                    text who id "who" at gradientDirector
                elif who in ['Незнакомка', 'Stranger', '陌生人', 'Étranger', 'Desconhecida', 'Desconocida']:
                    text who id "who" at gradientStranger
                else:
                    text who id "who"

                

        if who == povname or who == "*" + povname + "*":
            text what id "what" at gradientPlayer
        elif who in ['Мая', 'Maya', '可能', 'Maya', 'Maya', 'Maya']:
            text what id "what" at gradientbluepurple
        elif who in ['Соня', 'Sonya', '索尼娅', 'Sonya', 'Sônia', 'Sonia']:
            text what id "what" at gradientPink
        elif who in ['Кейт', 'Kate', '凯特', 'Kate', 'Kate', 'Kate']:
            text what id "what" at gradientKate
        elif who in ['Почтальон', 'Postman', '邮差', 'Facteur', 'Carteira', 'Cartera']:
            text what id "what" at gradientPostGirl
        elif who in ['Secretary', 'Секретарь', '秘书', 'Secrétaire', 'Secretária', 'Secretaria']:
            text what id "what" at gradientAssistent
        elif who in ['Директор', 'Director', '导演', 'Directeur', 'Diretora', 'Director']:
            text what id "what" at gradientDirector
        elif who in ['Незнакомка', 'Stranger', '陌生人', 'Fille étrangère', 'Desconhecida', 'Desconocida']:
            text what id "what" at gradientStranger
        else:
            text what id "what":
                
                at gradientNarator
                outlines [(2, "#696969", 1, 1)] 
                

    ## Если есть боковое изображение ("голова"), показывает её поверх текста.
    ## По стандарту не показывается на варианте для мобильных устройств — мало
    ## места.czz
    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0

# transform fadein_textbox:
#     alpha 0.0
#     linear 0.3 alpha 1.0


## Делает namebox доступным для стилизации через объект Character.
init python:
    config.character_id_prefixes.append('namebox')

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style window:
    xalign 0.5
    xsize 1045
    # background Solid("#d43434")
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    # background "gui/textbox.png" xalign=0.5 yalign=1.0 alpha=dialogue_box_opacity

style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding

style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5

style say_dialogue:
    # outlines [(2, "#000000", 0, 0)] 
    # background Solid("#d43434")
    properties gui.text_properties("dialogue")
    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos
    size 42
    

    adjust_spacing False

## Экран ввода #################################################################
##
## Этот экран используется, чтобы показывать renpy.input. Это параметр запроса,
## используемый для того, чтобы дать игроку ввести в него текст.
##
## Этот экран должен создать наложение ввода с id "input", чтобы принять
## различные вводимые параметры.
##
## https://www.renpy.org/doc/html/screen_special.html#input

screen input(prompt):
    style_prefix "input"

    window:

        vbox:
            xanchor gui.dialogue_text_xalign
            xpos gui.dialogue_xpos
            xsize gui.dialogue_width
            yalign gui.dialogue_ypos

            text prompt style "input_prompt"
            input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width


## Экран выбора ################################################################
##
## Этот экран используется, чтобы показывать внутриигровые выборы,
## представленные оператором menu. Один параметр, вложения, список объектов,
## каждый с заголовком и полями действия.
##
## https://www.renpy.org/doc/html/screen_special.html#choice

default shake_choice = 0

transform fade_in_pause(t):
    alpha 0.0
    xoffset 30
    pause t
    easein 0.5 xoffset 0 alpha 1.0

screen choice(items):
    modal True
    zorder 100
    style_prefix "choice"

    vbox:
        at fade_in
        xalign 0.97
        yalign 0.6
        spacing 30
        for i, item in enumerate(items):  # Используем enumerate для индексации
            # Расчет времени паузы, увеличиваем его с каждым элементом
            $ pause_time = 0.1 * (i + 1)    
            if item.caption:
                button:
                    padding (0, 15)
                    if item.args and item.args[0] == False:
                        background "gui/button/choice_hover_background.png"
                        mouse "button_obj"        
                        action [Play("fx3", ui_select_sounds[1]), NullAction()]  
                    else:
                        action [Play("fx3", ui_select_sounds[1]), item.action]  
                        mouse "button_dialog"
                    hover_sound ui_select_sounds[2]
                    at fade_in_pause(pause_time) 
                    
                      
                        
                    add Text(item.caption, xalign=0.0, xpos=50,italic=True, yalign=0.7, outlines=[(3, "#515354", 1, 1)])  at gradientWhite


style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    ypos 405
    yanchor 0.5
    spacing gui.choice_spacing

style choice_button is default:
    properties gui.button_properties("choice_button")
    

style choice_button_text is default:
    properties gui.text_properties("choice_button")


## Экран быстрого меню #########################################################
##
## Быстрое меню показывается внутри игры, чтобы обеспечить лёгкий доступ к
## внеигровым меню.

screen quick_menu():

    ## Гарантирует, что оно появляется поверх других экранов.
    zorder 100
    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 0.998

            textbutton _("Назад") action Rollback()
            # textbutton _("History") action ShowMenu('history')
            textbutton _("Пропуск") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Авто") action Preference("auto-forward", "toggle")
            textbutton _("Сохранить") action ShowMenu('save')
            textbutton _("Б.Сохр") action QuickSave()
            textbutton _("Б.Загр") action QuickLoad()
            textbutton _("Настройки") action ShowMenu('preferences')


## Данный код гарантирует, что экран быстрого меню будет показан в игре в любое
## время, если только игрок не скроет интерфейс.
init python:
    config.overlay_screens.append("quick_menu")

default quick_menu = True

style quick_button is default
style quick_button_text is button_text

style quick_button:
    properties gui.button_properties("quick_button")

style quick_button_text:
    properties gui.text_properties("quick_button")


################################################################################
## Экраны Главного и Игрового меню
################################################################################

## Экран навигации #############################################################
##
## Этот экран включает в себя главное и игровое меню, и обеспечивает навигацию к
## другим меню и к началу игры.
transform fade_in(delay=0.0):
    alpha 0.0
    pause delay  # Задержка перед появлением
    easein 0.5 alpha 1.0  # Плавное появление
    # on hover:
    #     easein 0.2 zoom 1.2
    # on idle:
    #     easein 0.2 zoom 1.0

init python:

    def set_global_chinese_font():
        style.default.font = "fonts/NotoSansTC-VariableFont_wght.ttf"

    def set_default_fonts():
        # Шрифт внутри игрового текста
        style.default.font = "fonts/PPPangramSansRounded-Semibold1.otf"
        
        # Шрифт имени персонажа
        style.say_label.font = "fonts/pfsquaresanspro-extrablack.ttf"

        # Шрифт интерфейса (меню, кнопки и т.д.)
        style.interface_text.font = "fonts/PPPangramSansRounded-Bold.otf"
        

screen language_choice():
    modal True  # Блокирует другие действия, пока меню открыто
    frame:
        xalign 0.5
        yalign 0.5
        background Solid("#fcfcfc00")
        vbox:
            spacing 25
            text "SELECT LANGUAGE":
                font "fonts/Nunito-Black.ttf"
                xalign 0.5 
                color ("#BCFF88")
                size 70
            for lang in languages_choice:
                button:
                    xalign 0.5 
                    xsize 402
                    ysize 111
                    if lang["ai"] == True:
                        idle_background "images/custom_gui/lang_but/idle_ai.png"
                        hover_background "images/custom_gui/lang_but/hover_ai.png"
                        text "AI":
                            ypos 0
                            xalign 1.14
                            color ("#FF6767")
                            font "fonts/PPPangramSansRounded-Bold.otf"
                            size 47
                            at transform:
                                rotate 12
                        text lang["lang_text"]:
                            yalign 0.6
                            xalign 0.5
                            color ("#000000ff")
                            font lang["font"]
                            size 56
                    else:
                        idle_background "images/custom_gui/lang_but/idle.png"
                        hover_background "images/custom_gui/lang_but/hover.png"
                        text lang["lang_text"]:
                            yalign 0.5
                            xalign 0.5
                            color ("#000000ff")
                            font lang["font"]
                            size 56
                    
                    action [SetVariable("persistent.language", lang["lang_name"]), Function(renpy.change_language, lang["lang_name"]), Function(set_default_fonts), Return()]
                    selected persistent.language == lang["lang_name"]
                    hover_sound "audio/menu_hover.mp3"
                    mouse "button_menu"
                    


            

init:

    style navigation_button is default:
        hover_sound ui_select_sounds[2]

default logo_zoom = 0.6
default logo_alpha = 1.0

screen logo():
    zorder 1
    if main_menu:
        if not (renpy.get_screen("preferences") or renpy.get_screen("load") or renpy.get_screen("about")):
            $ logo_zoom = 1.0
            $ logo_alpha = 1.0
        else:
            $ logo_zoom = 0.6
            $ logo_alpha = 1.0
    else:
        $ logo_zoom = 0.6
        $ logo_alpha = 1.0
    fixed:
        add "images/custom_gui/logo.png": 
            at logo_anim(logo_zoom, logo_alpha)
            xpos 50
            ypos 50
            xanchor 0.0
            yanchor 0.0

transform logo_anim(z, a):
    alpha 0.0
    parallel:
        easein 0.4 alpha a
    parallel:
        zoom z

screen menu_icons():
    tag menu_icons


    button:
        xsize 480
        ysize 110
        xalign 0.98
        yalign 0.02
        mouse "button_menu"

        hovered [
            Play("fx3", ui_select_sounds[3]),
            SetVariable("text_color", "#fff0d6"),
            SetVariable("path", "images/icons/etc/patreon_h.png"),
            SetVariable("mask", "images/icons/etc/patreon button_h.png"),
        ]
        unhovered [
            SetVariable("text_color", "#ff5050"),
            SetVariable("path", "images/icons/etc/patreon.png"),
            SetVariable("mask", "images/icons/etc/patreon button.png"),
        ]

        action [OpenURL("https://patreon.com/Meltwish_Valley"), Play("fx3", ui_select_sounds[1])]

        add AlphaMask(
            mask,  # <-- ВАЖНО: переменная
            Fixed(
                Text(
                    _("ИГРАЙ РАНЬШЕ ДРУГИХ"),
                    size=25,
                    color="#000000",
                    text_align=0.5,
                    yalign=0.43,
                    xalign=0.52,
                    font="fonts/Nunito-Black.ttf"
                ),
                xsize=345,
                ysize=47,
                xalign=0.5,
                yalign=0.5
            ),
            invert=True
        ):
            xalign 0.1
            yalign 0.1

        frame:
            background "#ff505000"
            xsize 345
            ysize 47
            xalign 0.1
            yalign 1.0
            text _("Бесплатные девлоги"):
                color text_color   # <-- ВАЖНО: переменная
                size 26
                xalign 0.5
                yalign 0.5
                font "fonts/Nunito-Black.ttf"
        imagebutton:
            xalign 1.0
            yalign 0.5
            idle path   # <-- ВАЖНО: переменная
        
    vbox:
        xalign 0.98
        yalign 0.95
        spacing 25
        for icon in social_icons:
            imagebutton:
                idle icon["path_idle"]
                hover icon["path_hover"]
                hover_sound ui_select_sounds[3]
                action [OpenURL(icon["link"]), Play("fx3", ui_select_sounds[1])]
                at fadeinout
                mouse "button_menu"

transform fadeinout:
    alpha 0.0
    easein 0.4 alpha 1.0

screen navigation():

    use logo
    if main_menu:
            if not(renpy.get_screen("preferences") or renpy.get_screen("load") or renpy.get_screen("about")):
                use menu_icons
    vbox:
        style_prefix "navigation"
        xalign 0.04
        yalign 0.92
        spacing gui.navigation_spacing

        if main_menu:
            if renpy.get_screen("preferences") or renpy.get_screen("load") or renpy.get_screen("about"):
                textbutton _("НОВАЯ ИГРА") action Start()
                textbutton _("ЗАГРУЗИТЬ") action ShowMenu("load")
                textbutton _("НАСТРОЙКИ") action ShowMenu("preferences")
                textbutton _("О ИГРЕ") action ShowMenu("about")
            else:
                textbutton _("НОВАЯ ИГРА") action Start() at fade_in(1)
                textbutton _("ЗАГРУЗИТЬ") action ShowMenu("load") at fade_in(1.1)
                textbutton _("НАСТРОЙКИ") action ShowMenu("preferences") at fade_in(1.2)
                textbutton _("О ИГРЕ") action ShowMenu("about") at fade_in(1.3)
        else:
            textbutton _("ИСТОРИЯ") action ShowMenu("history")
            textbutton _("СОХРАНИТЬ") action ShowMenu("save")
            textbutton _("ЗАГРУЗИТЬ") action ShowMenu("load")
            textbutton _("НАСТРОЙКИ") action ShowMenu("preferences")

        if _in_replay:
            textbutton _("ЗАВЕРШИТЬ ПОВТОР") action EndReplay(confirm=True)
        elif not main_menu:
            textbutton _("МЕНЮ") action MainMenu()

        if renpy.variant("pc"):
            if main_menu:
                if renpy.get_screen("preferences") or renpy.get_screen("load") or renpy.get_screen("about"):
                    textbutton _("ВЫХОД") action Quit(confirm=not main_menu) hover_sound random.choice(ui_select_sounds)
                else:
                    textbutton _("ВЫХОД") action Quit(confirm=not main_menu) at fade_in(1.4) hover_sound random.choice(ui_select_sounds)
            else:
                textbutton _("ВЫХОД") action Quit(confirm=not main_menu) hover_sound ui_select_sounds[1]

style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    size_group "navigation"
    properties gui.button_properties("navigation_button")
    # background "gui/overlay/buttonmenu.png"
    # background Solid("#d43434")

style navigation_button_text:
    properties gui.text_properties("navigation_button")
    xalign 0

## Экран главного меню #########################################################
##
## Используется, чтобы показать главное меню после запуска игры.
##
## https://www.renpy.org/doc/html/screen_special.html#main-menu

default background_done = False

screen main_menu():
    
    ## Этот тег гарантирует, что любой другой экран с тем же тегом будет
    ## заменять этот.
    tag menu

    add gui.main_menu_background


    ## Эта пустая рамка затеняет главное меню.
    frame:
        style "main_menu_frame"

    ## Оператор use включает отображение другого экрана в данном. Актуальное
    ## содержание главного меню находится на экране навигации.
    use navigation

    if gui.show_name:

        vbox:
            style "main_menu_vbox"

            text "[config.name!t]":
                style "main_menu_title"

            text "[config.version]":
                style "main_menu_version"


style main_menu_frame is empty
style main_menu_vbox is vbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text

# style main_menu_frame:
#     background "gui/overlay/dota2_social.png"

style main_menu_vbox:
    xalign 1.0
    xoffset -30
    xmaximum 1200
    yalign 1.0
    yoffset -30

style main_menu_text:
    properties gui.text_properties("main_menu", accent=True)

style main_menu_title:
    properties gui.text_properties("title")

style main_menu_version:
    properties gui.text_properties("version")


## Экран игрового меню #########################################################
##
## Всё это показывает основную, обобщённую структуру экрана игрового меню. Он
## вызывается с экраном заголовка и показывает фон, заголовок и навигацию.
##
## Параметр scroll может быть None или один из "viewport" или "vpgrid". Этот
## экран предназначен для использования с одним или несколькими дочерними
## элементами, которые трансклюдируются (помещаются) внутрь него.

screen game_menu(title, scroll=None, yinitial=0.0, spacing=0):

    style_prefix "game_menu"

    if main_menu:
        add gui.main_menu_background
    else:
        add gui.game_menu_background

    frame:
        style "game_menu_outer_frame"

        hbox:

            ## Резервирует пространство для навигации.
            # if not main_menu:
            frame:
                style "game_menu_navigation_frame"

            frame:
                style "game_menu_content_frame"

                if scroll == "viewport":

                    viewport:
                        yinitial yinitial
                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        pagekeys True

                        side_yfill True

                        vbox:
                            spacing spacing

                            transclude

                elif scroll == "vpgrid":

                    vpgrid:
                        cols 1
                        yinitial yinitial

                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        pagekeys True

                        side_yfill True

                        spacing spacing

                        transclude

                else:

                    transclude

    use navigation

    textbutton _("Вернуться"):
        style "return_button"
        text_xalign 1.0
        action [Play("fx3", ui_select_sounds[1]), Return()]

    label title

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")

screen game_menu_set(title, scroll=None, yinitial=0.0, spacing=0):

    style_prefix "game_menu"

    if main_menu:
        add gui.main_menu_background
    else:
        add gui.game_menu_background

    frame:
        style "game_menu_outer_frame"

        hbox:
            
            # if not main_menu:
            #     frame:
            #         style "game_menu_navigation_frame"
            # ## Резервирует пространство для навигации.

            frame:
                style "game_menu_content_frame"

                if scroll == "viewport":

                    viewport:
                        yinitial yinitial
                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        pagekeys True

                        side_yfill True

                        vbox:
                            spacing spacing

                            transclude

                elif scroll == "vpgrid":

                    vpgrid:
                        cols 1
                        yinitial yinitial

                        scrollbars "vertical"
                        mousewheel True
                        draggable True
                        pagekeys True

                        side_yfill True

                        spacing spacing

                        transclude

                else:

                    transclude


    textbutton _("Вернуться"):
        style "return_button"
        text_xalign 1.0
        action [Play("fx3", ui_select_sounds[1]), Return()]

    label title

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")


style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_outer_frame:
    bottom_padding 45
    top_padding 100

    background "gui/overlay/game_menu.png"

style game_menu_navigation_frame:
    xsize 420
    yfill True

style game_menu_content_frame:
    left_margin 60
    right_margin 30
    top_margin 15

style game_menu_viewport:
    xsize 1380

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 15

style game_menu_label:
    xpos 75
    ysize 180

style game_menu_label_text:
    size gui.title_text_size
    color gui.accent_color
    yalign 0.5

style return_button:
    xalign 1.0
    xoffset -50
    yalign 1.0
    yoffset -45



## Экран Об игре ###############################################################
##
## Этот экран показывает авторскую информацию об игре и Ren'Py.
##
## В этом экране нет ничего особенного, и он служит только примером того, каким
## можно сделать свой экран.

screen about():
    tag menu

    ## Этот оператор включает игровое меню внутрь этого экрана. Дочерний vbox
    ## включён в порт просмотра внутри экрана игрового меню.
    use game_menu("", scroll="viewport"):

        style_prefix "about"

        vbox:

            label "[config.name!t]"
            text _("Версия [config.version!t]\n")

            ## gui.about обычно установлено в options.rpy.
            if gui.about:
                text "[gui.about!t]\n":
                    line_spacing 2
                    at gradientNarator


style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text

style about_label_text:
    size gui.label_text_size



## Экраны загрузки и сохранения ################################################
##
## Эти экраны ответственны за возможность сохранять и загружать игру. Так
## как они почти одинаковые, оба реализованы по правилам третьего экрана —
## file_slots.
##
## https://www.renpy.org/doc/html/screen_special.html#save 

screen save():

    tag menu

    use file_slots("")


screen load():

    tag menu

    use file_slots("")


screen file_slots(title):

    default page_name_value = FilePageNameInputValue(pattern=_("{} страница"), auto=_("Автосохранения"), quick=_("Быстрые сохранения"))

    use game_menu(title):

        fixed:

            ## Это гарантирует, что ввод будет принимать enter перед остальными
            ## кнопками.
            order_reverse True

            ## Номер страницы, который может быть изменён посредством клика на
            ## кнопку.
            button:
                style "page_label"

                key_events True
                xalign 0.5
                action page_name_value.Toggle()

                input:
                    style "page_label_text"
                    value page_name_value

            ## Таблица слотов.
            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"

                xalign 0.5
                yalign 0.5

                spacing gui.slot_spacing

                for i in range(gui.file_slot_cols * gui.file_slot_rows):

                    $ slot = i + 1

                    button:
                        action FileAction(slot, confirm=False)

                        xsize gui.slot_button_width
                        ysize gui.slot_button_height

                        has vbox
                        
                        add FileScreenshot(slot) xalign 0.5

                        null height 15

                        text FileTime(slot, format=_("{#file_time}%A, %d %B %Y, %H:%M"), empty=_("Пустой слот")):
                            style "slot_time_text"

                        text FileSaveName(slot):
                            style "slot_name_text"

                        key "save_delete" action FileDelete(slot)

            ## Кнопки для доступа к другим страницам.
            vbox:

                style_prefix "page"

                xalign 0.5
                yalign 1.0

                hbox:
                    xalign 0.5

                    spacing gui.page_spacing

                    textbutton _("<") action FilePagePrevious()
                    key "save_page_prev" action FilePagePrevious()

                    if config.has_autosave:
                        textbutton _("{#auto_page}А") action FilePage("auto")

                    if config.has_quicksave:
                        textbutton _("{#quick_page}Б") action FilePage("quick")

                    ## range(1, 10) задаёт диапазон значений от 1 до 9.
                    for page in range(1, 10):
                        textbutton "[page]" action FilePage(page)

                    textbutton _(">") action FilePageNext()
                    key "save_page_next" action FilePageNext()

                # if config.has_sync:
                #     if CurrentScreenName() == "save":
                #         textbutton _("Загрузить Sync"):
                #             action UploadSync()
                #             xalign 0.5
                #     else:
                #         textbutton _("Скачать Sync"):
                #             action DownloadSync()
                #             xalign 0.5


style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text

style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 75
    ypadding 5

style page_label_text:
    textalign 0.5
    layout "subtitle"
    hover_color gui.hover_color

style page_button:
    properties gui.button_properties("page_button")

style page_button_text:
    properties gui.text_properties("page_button")

style slot_button:
    properties gui.button_properties("slot_button")

style slot_button_text:
    properties gui.text_properties("slot_button")


## Экран настроек ##############################################################
##
## Экран настроек позволяет игроку настраивать игру под себя.
##
## https://www.renpy.org/doc/html/screen_special.html#preferences
init python:
    style.lang_button = Style(style.radio_button)
    style.lang_button_text = Style(style.radio_button_text)
transform myrotate:
    rotate 15
screen preferences():

    tag menu

    use game_menu("", scroll="viewport"):

        vbox:

            hbox:
                spacing 320
                box_wrap True
                vbox:
                    spacing 50
                    vbox:
                        style_prefix "check"
                        label _("Пропуск")
                        textbutton _("Всего текста") action [Play("fx3", ui_select_sounds[1]),Preference("skip", "toggle")] mouse "button_menu" hover_sound ui_select_sounds[2]
                        textbutton _("После выборов") action [Play("fx3", ui_select_sounds[1]),Preference("after choices", "toggle")] mouse "button_menu" hover_sound ui_select_sounds[2]
                        # textbutton _("Переходов") action InvertSelected(Preference("transitions", "toggle")) mouse "button_menu"
                        
                    if renpy.variant("pc") or renpy.variant("web"):
                        vbox:
                            style_prefix "radio"
                            label _("Режим экрана")
                            textbutton _("Оконный") action [Play("fx3", ui_select_sounds[1]), Preference("display", "window")] mouse "button_menu" hover_sound ui_select_sounds[2]
                            textbutton _("Полный") action [Play("fx3", ui_select_sounds[1]), Preference("display", "fullscreen")] mouse "button_menu" hover_sound ui_select_sounds[2]

                vbox:
                    spacing 10
                    label _("Язык")
                    style_prefix "radio"
                    for lang in languages_choice:
                        button:
                            style "lang_button"
                            xsize 500
                            ysize 70
                            action [SetVariable("persistent.language", lang["lang_name"]), Function(renpy.change_language, lang["lang_name"]), Function(set_default_fonts), Return()]
                            selected persistent.language == lang["lang_name"]
                            hover_sound ui_select_sounds[0]
                            mouse "button_menu"
                            text lang["lang_text"] style "lang_button_text" font lang["font"]
                            if lang["ai"]: 
                                text "(AI)":
                                    yalign 0.5
                                    xalign 0.8
                                    font lang["font"]
                                    
                                
                                


                    
                    

            null height (4 * gui.pref_spacing)

            hbox:
                style_prefix "slider"
                box_wrap True

                vbox:

                    label _("Скорость текста")

                    bar value Preference("text speed") mouse "button_menu"

                    label _("Скорость авточтения")

                    bar value Preference("auto-forward time") mouse "button_menu"

                    label _("Прозрачность окна")

                    bar value VariableValue("dialogue_box_opacity", 1.0) style "slider" xmaximum 530 mouse "button_menu"
                vbox:

                    if config.has_music:
                        label _("Громкость музыки")

                        hbox:
                            bar value Preference("music volume") mouse "button_menu"

                    if config.has_sound:

                        label _("Громкость звуков")

                        hbox:
                            bar value Preference("sound volume") mouse "button_menu"

                            if config.sample_sound:
                                textbutton _("Тест") action Play("sound", config.sample_sound)


                    if config.has_voice:
                        label _("Громкость голоса")

                        hbox:
                            bar value Preference("voice volume") mouse "button_menu"

                            if config.sample_voice:
                                textbutton _("Тест") action Play("voice", config.sample_voice)

                    if config.has_music or config.has_sound or config.has_voice:
                        null height gui.pref_spacing

                        textbutton _("Без звука"):
                            action [Play("fx3", ui_select_sounds[1]),Preference("all mute", "toggle")] 
                            style "mute_all_button"
                            hover_sound ui_select_sounds[2]
                            mouse "button_menu"


style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 3

style pref_label_text:
    yalign 1.0

style pref_vbox:
    xsize 338

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.text_properties("radio_button")

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.text_properties("check_button")

style slider_slider:
    xsize 525

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 15

style slider_button_text:
    properties gui.text_properties("slider_button")

style slider_vbox:
    xsize 675


## Экран истории ###############################################################
##
## Этот экран показывает игроку историю диалогов. Хотя в этом экране нет ничего
## особенного, он имеет доступ к истории диалогов, хранимом в _history_list.
##
## https://www.renpy.org/doc/html/history.html

screen history():

    tag menu

    ## Избегайте предсказывания этого экрана, так как он может быть очень
    ## массивным.
    predict False

    use game_menu("", scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0, spacing=gui.history_spacing):

        style_prefix "history"

        for h in _history_list:

            window:

                ## Это всё правильно уравняет, если history_height будет
                ## установлен на None.
                has fixed:
                    yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False

                        ## Берёт цвет из who параметра персонажа, если он
                        ## установлен.
                        # if h.who == povname:
                        #     text_color h.who_args["color"] at gradientPlayer 
                        # elif h.who == "*" + povname + "*":
                        #     text_color h.who_args["color"] at gradientPlayer
                        # elif h.who == Maya.name:
                        #     text_color h.who_args["color"] at gradientbluepurple
                        # elif h.who == Sonya.name:
                        #     text_color h.who_args["color"] at gradientPink
                        # elif h.who == Kate.name:
                        #     text_color h.who_args["color"] at gradientKate
                        # elif h.who == PostMan.name:
                        #     text_color h.who_args["color"] at gradientPostGirl
                        # elif h.who == Assistant.name:
                        #     text_color h.who_args["color"] at gradientPostGirl
                        # elif h.who == Director.name:
                        #     text_color h.who_args["color"] at gradientPostGirl
                        # elif h.who == UnknownGirl.name:
                        #     text_color h.who_args["color"] at gradientPostGirl
                        # elif h.who == 'Maya':
                        #     text_color h.who_args["color"] at gradientbluepurple
                        # elif h.who == 'Sonya':
                        #     text_color h.who_args["color"] at gradientPink
                        # elif h.who == 'Kate':
                        #     text_color h.who_args["color"] at gradientKate
                        # elif h.who == 'Postman':
                        #     text_color h.who_args["color"] at gradientPostGirl
                        # elif h.who == 'Assistant':
                        #     text_color h.who_args["color"] at gradientPostGirl
                        # elif h.who == 'Director':
                        #     text_color h.who_args["color"] at gradientPostGirl
                        # elif h.who == 'UnknownGirl':
                        #     text_color h.who_args["color"] at gradientPostGirl
                        # else:
                        text_color h.who_args["color"]

                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                if h.who == povname:
                    text what id "what" at gradientPlayer
                elif h.who == "*" + povname + "*":
                    text what id "what" at gradientPlayer
                elif h.who == Maya.name:
                    text what id "what" at gradientbluepurple
                elif h.who == Sonya.name:
                    text what id "what" at gradientPink
                elif h.who == Kate.name:
                    text what id "what" at gradientKate
                elif h.who == PostMan.name:
                    text what id "what" at gradientPostGirl
                # elif who == Assistant.name:
                #     text what id "who" at gradientPostGirl
                # elif who == Director.name:
                #     text what id "who" at gradientPostGirl
                # elif who == UnknownGirl.name:
                #     text what id "who" at gradientPostGirl
                elif h.who == 'Maya':
                    text what id "what" at gradientbluepurple
                elif h.who == 'Sonya':
                    text what id "what" at gradientPink
                elif h.who == 'Kate':
                    text what id "what" at gradientKate
                elif h.who == 'Postman':
                    text what id "what" at gradientPostGirl
                # elif who == 'Assistant':
                #     text what id "who" at gradientPostGirl
                # elif who == 'Director':
                #     text what id "who" at gradientPostGirl
                # elif who == 'UnknownGirl':
                #     text what id "who" at gradientPostGirl
                else:
                    text what id "what"

        if not _history_list:
            label _("История диалогов пуста.")


## Это определяет, какие теги могут отображаться на экране истории.

define gui.history_allow_tags = { "alt", "noalt", "rt", "rb", "art" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos 0.5
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    textalign gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos 0.5
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    textalign gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5


## Экран помощи ################################################################
##
## Экран, дающий информацию о клавишах управления. Он использует другие экраны
## (keyboard_help, mouse_help, и gamepad_help), чтобы показывать актуальную
## помощь.

# screen help():

#     tag menu

#     default device = "keyboard"

#     use game_menu(_("Помощь"), scroll="viewport"):

#         style_prefix "help"

#         vbox:
#             spacing 23

#             hbox:

#                 textbutton _("Клавиатура") action SetScreenVariable("device", "keyboard")
#                 textbutton _("Мышь") action SetScreenVariable("device", "mouse")

#                 if GamepadExists():
#                     textbutton _("Геймпад") action SetScreenVariable("device", "gamepad")

#             if device == "keyboard":
#                 use keyboard_help
#             elif device == "mouse":
#                 use mouse_help
#             elif device == "gamepad":
#                 use gamepad_help


# screen keyboard_help():

#     hbox:
#         label _("Enter")
#         text _("Прохождение диалогов, активация интерфейса.")

#     hbox:
#         label _("Пробел")
#         text _("Прохождение диалогов без возможности делать выбор.")

#     hbox:
#         label _("Стрелки")
#         text _("Навигация по интерфейсу.")

#     hbox:
#         label _("Esc")
#         text _("Вход в игровое меню.")

#     hbox:
#         label _("Ctrl")
#         text _("Пропускает диалоги, пока зажат.")

#     hbox:
#         label _("Tab")
#         text _("Включает режим пропуска.")

#     hbox:
#         label _("Page Up")
#         text _("Откат назад по сюжету игры.")

#     hbox:
#         label _("Page Down")
#         text _("Откатывает предыдущее действие вперёд.")

#     hbox:
#         label "H"
#         text _("Скрывает интерфейс пользователя.")

#     hbox:
#         label "S"
#         text _("Делает снимок экрана.")

#     hbox:
#         label "V"
#         text _("Включает поддерживаемый {a=https://www.renpy.org/l/voicing}синтезатор речи{/a}.")

#     hbox:
#         label "Shift+A"
#         text _("Открывает меню специальных возможностей.")


# screen mouse_help():

#     hbox:
#         label _("Левый клик")
#         text _("Прохождение диалогов, активация интерфейса.")

#     hbox:
#         label _("Клик колёсиком")
#         text _("Скрывает интерфейс пользователя.")

#     hbox:
#         label _("Правый клик")
#         text _("Вход в игровое меню.")

#     hbox:
#         label _("Колёсико вверх")
#         text _("Откат назад по сюжету игры.")

#     hbox:
#         label _("Колёсико вниз")
#         text _("Откатывает предыдущее действие вперёд.")


# screen gamepad_help():

#     hbox:
#         label _("Правый триггер\nA/Нижняя кнопка")
#         text _("Прохождение диалогов, активация интерфейса.")

#     hbox:
#         label _("Левый Триггер\nЛевый Бампер")
#         text _("Откат назад по сюжету игры.")

#     hbox:
#         label _("Правый бампер")
#         text _("Откатывает предыдущее действие вперёд.")

#     hbox:
#         label _("Крестовина, Стики")
#         text _("Навигация по интерфейсу.")

#     hbox:
#         label _("Старт, Гид, B/Правая кнопка")
#         text _("Вход в игровое меню.")

#     hbox:
#         label _("Y/Верхняя кнопка")
#         text _("Скрывает интерфейс пользователя.")

#     textbutton _("Калибровка") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 12

style help_button_text:
    properties gui.text_properties("help_button")

style help_label:
    xsize 375
    right_padding 30

style help_label_text:
    size gui.text_size
    xalign 1.0
    textalign 1.0



################################################################################
## Дополнительные экраны
################################################################################


## Экран подтверждения #########################################################
##
## Экран подтверждения вызывается, когда Ren'Py хочет спросить у игрока вопрос
## Да или Нет.
##
## https://www.renpy.org/doc/html/screen_special.html#confirm
transform fadein:
    alpha 0.0
    linear 0.3 alpha 1.0

transform outline_glow:
    alpha 0.0
    linear 0.12 alpha 1.0
    linear 0.20 alpha 0.4
    linear 0.20 alpha 1.0
    repeat

screen confirm(message, yes_action, no_action):
    ## Гарантирует, что другие экраны будут недоступны, пока показан этот экран.
    modal True

    zorder 200
    style_prefix "confirm"


    add "exitvideo" at fadein

    imagebutton:
        xpos 80
        ypos 50
        at fadein
        idle "images/icons/etc/[_preferences.language].png"
        action [OpenURL("https://patreon.com/Meltwish_Valley"), Play("sound", ui_check_sounds[1])]
        mouse "button_menu"
        hovered Play("sound", ui_check_sounds[0])

    imagebutton:
        xalign 0.98
        yalign 0.98
        at fadein
        idle "images/icons/etc/[_preferences.language]_ds.png"
        action [OpenURL("https://discord.gg/wvkNKZJz3x"), Play("sound", ui_check_sounds[1])]
        mouse "button_menu"
        hovered Play("sound", ui_check_sounds[0])

    
    frame:
        
        at fadein
        vbox:
            xalign .5
            yalign .5
            spacing 45

            label _("Ты правда хочешь выйти") at gradientPink: 
                style "confirm_prompt"
                xalign 0.5

            hbox:
                xalign 0.5
                spacing 150
                textbutton _("Да") at gradientPink:
                    style "confirm_prompt"
                    action yes_action
                    mouse "button_menu"
                textbutton _("Нет") at gradientPink:
                    style "confirm_prompt"
                    action no_action
                    mouse "button_menu"

    ## Правый клик и esc, как ответ "Нет".
    key "game_menu" action no_action


style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    # background Frame([ "gui/confirm_frame.png", "gui/frame.png"], gui.confirm_frame_borders, tile=gui.frame_tile)
    background Solid("#00000000")
    padding gui.confirm_frame_borders.padding
    xalign .75
    yalign .30


style confirm_prompt_text:
    textalign 0.5
    layout "subtitle"
    outlines [ (2, "#e288cf", 1, 1) ]

style confirm_button:
    properties gui.button_properties("confirm_button")
    background Solid("#ff000000")

style confirm_button_text:
    properties gui.text_properties("confirm_button")
    outlines [ (1, "#e288cf", 1, 1) ]


## Экран индикатора пропуска ###################################################
##
## Экран индикатора пропуска появляется для того, чтобы показать, что идёт
## пропуск.
##
## https://www.renpy.org/doc/html/screen_special.html#skip-indicator

screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:
        yalign 0.14
        xalign 0.01
        hbox:
            spacing 9

            text "▸":
                style "skip_triangle" 
                size 50
                at [delayed_blink(0.0, 1.0), gradientNarator]
                outlines [(1, "#757575ff", 1, 1)] 
            text "▸":
                style "skip_triangle" 
                size 50
                at [delayed_blink(0.2, 1.0), gradientNarator]
                outlines [(1, "#757575ff", 1, 1)] 
            text "▸":
                style "skip_triangle" 
                size 50
                at [delayed_blink(0.4, 1.0), gradientNarator]
                outlines [(1, "#757575ff", 1, 1)] 


## Эта трансформация используется, чтобы мигать стрелками одна за другой.
transform delayed_blink(delay, cycle):
    alpha .5
    xoffset 0

    pause delay
    block:
        linear .2 xoffset 3 alpha 1.0
        linear .2 
        pause .2
        linear .2 xoffset 0 alpha 0.5
        linear .2 
        pause (cycle - .4)
        repeat


style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    ypos gui.skip_ypos
    # background Frame("gui/skip.png", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding

style skip_text:
    size gui.notify_text_size

style skip_triangle:
    ## Нам надо использовать шрифт, имеющий в себе символ U+25B8 (стрелку выше).
    font "DejaVuSans.ttf"


## Экран уведомлений ###########################################################
##
## Экран уведомлений используется, чтобы показать игроку оповещение. (Например,
## когда игра автосохранилась, или был сделан скриншот)
##
## https://www.renpy.org/doc/html/screen_special.html#notify-screen

screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    ypos gui.notify_ypos

    background Frame("gui/notify.png", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding

style notify_text:
    properties gui.text_properties("notify")


## Экран NVL ###################################################################
##
## Этот экран используется в диалогах и меню режима NVL.
##
## https://www.renpy.org/doc/html/screen_special.html#nvl


screen nvl(dialogue, items=None):

    window:
        style "nvl_window"

        has vbox:
            spacing gui.nvl_spacing

        ## Показывает диалог или в vpgrid, или в vbox.
        if gui.nvl_height:

            vpgrid:
                cols 1
                yinitial 1.0

                use nvl_dialogue(dialogue)

        else:

            use nvl_dialogue(dialogue)

        ## Показывает меню, если есть. Меню может показываться некорректно, если
        ## config.narrator_menu установлено на True.
        for i in items:

            textbutton i.caption:
                action i.action
                style "nvl_button"

    add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            fixed:
                yfit gui.nvl_height is None

                if d.who is not None:

                    text d.who:
                        id d.who_id

                text d.what:
                    id d.what_id


## Это контролирует максимальное число строк NVL, могущих показываться за раз.
define config.nvl_list_length = gui.nvl_list_length

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    textalign gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    textalign gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    textalign gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.text_properties("nvl_button")


## Пузырьковый экран ###########################################################
##
## Экран пузырьков используется для отображения диалога игроку при использовании
## речевых пузырьков. Экран пузырьков принимает те же параметры, что и экран
## say, должен создать отображаемый объект с id "what", и может создавать
## отображаемые объекты с id "namebox", "who" и "window".
##
## https://www.renpy.org/doc/html/bubble.html#bubble-screen

screen bubble(who, what):
    style_prefix "bubble"

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "bubble_namebox"

                text who:
                    id "who"

        text what:
            id "what"

style bubble_window is empty
style bubble_namebox is empty
style bubble_who is default
style bubble_what is default

style bubble_window:
    xpadding 30
    top_padding 5
    bottom_padding 5

style bubble_namebox:
    xalign 0.5

style bubble_who:
    xalign 0.5
    textalign 0.5
    color "#000"

style bubble_what:
    align (0.5, 0.5)
    text_align 0.5
    layout "subtitle"
    color "#000"

define bubble.frame = Frame("gui/bubble.png", 55, 55, 55, 95)
define bubble.thoughtframe = Frame("gui/thoughtbubble.png", 55, 55, 55, 55)

define bubble.properties = {
    "bottom_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "bottom_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "top_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "top_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "thought" : {
        "window_background" : bubble.thoughtframe,
    }
}

define bubble.expand_area = {
    "bottom_left" : (0, 0, 0, 22),
    "bottom_right" : (0, 0, 0, 22),
    "top_left" : (0, 22, 0, 0),
    "top_right" : (0, 22, 0, 0),
    "thought" : (0, 0, 0, 0),
}



################################################################################
## Мобильные варианты
################################################################################

style pref_vbox:
    variant "medium"
    xsize 675

## Раз мышь может не использоваться, мы заменили быстрое меню версией,
## использующей меньше кнопок, но больших по размеру, чтобы их было легче
## касаться.
screen quick_menu():
    variant "touch"

    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("Назад") action Rollback()
            textbutton _("Пропуск") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Авто") action Preference("auto-forward", "toggle")
            textbutton _("Меню") action ShowMenu()


style window:
    variant "small"
    # background "gui/phone/textbox.png"

style radio_button:
    variant "small"
    foreground "gui/phone/button/radio_[prefix_]foreground.png"

style check_button:
    variant "small"
    foreground "gui/phone/button/check_[prefix_]foreground.png"

style nvl_window:
    variant "small"
    background "gui/phone/nvl.png"

style main_menu_frame:
    variant "small"
    # background "gui/phone/overlay/main_menu.png"

style game_menu_outer_frame:
    variant "small"
    # background "gui/phone/overlay/game_menu.png"

style game_menu_navigation_frame:
    variant "small"
    xsize 510

style game_menu_content_frame:
    variant "small"
    top_margin 0

style pref_vbox:
    variant "small"
    xsize 600

style bar:
    variant "small"
    ysize gui.bar_size
    left_bar Frame("gui/phone/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/phone/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    variant "small"
    xsize gui.bar_size
    top_bar Frame("gui/phone/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/phone/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    variant "small"
    ysize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    variant "small"
    xsize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    variant "small"
    ysize gui.slider_size
    base_bar Frame("gui/phone/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/horizontal_[prefix_]thumb.png"

style vslider:
    variant "small"
    xsize gui.slider_size
    base_bar Frame("gui/phone/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/vertical_[prefix_]thumb.png"

style slider_vbox:
    variant "small"
    xsize None

style slider_slider:
    variant "small"
    xsize 900


screen rooms_in():
    if not renpy.get_screen("say"):
        button:
            background Solid("#ff000000")
            xsize 200
            ysize 900
            xalign 0.99
            yalign 0.8
            hovered Show("side_block")
            action NullAction()

screen rooms_in_tutorial():
    button:
        background Solid("#ff000000")
        xsize 200
        ysize 900
        xalign 0.99
        yalign 0.8
        action NullAction()

screen side_block():
    frame:
        xsize 380
        ysize 900
        xalign 0.99
        yalign 0.8
        background Solid("#00000000")

        at transform:
            alpha 1.0
            xoffset 0
            # on show:
            #     linear 0.1 alpha 1.0
            on hide:
                linear 0.1 alpha 0.0 xoffset 5

        mousearea:
            area (0.0, 0.0, 1.0, 1.0)
            unhovered [Hide("side_block"), SetVariable("hovering_button", False)]
        

        vbox:
            spacing 10

            for loc_id, loc in LOCATIONS.items():
                if loc["group"] == location_type:
                    $ pause_time = 0.04 * (list(LOCATIONS.keys()).index(loc_id) + 1)
                    button:
                        
                        at side_block_rooms(pause_time)
                        xfill True
                        ysize 170

                        idle_background im.MatrixColor(
                            loc["image"],
                            im.matrix.brightness(-0.1)
                        )
                        hover_background loc["image"]

                        action [Play("fx2", ui_select_sounds[1]), SetVariable("prev_location", current_label), Jump(loc_id)]
                        hovered [Play("fx3", ui_select_sounds[3]),SetVariable("hovering_button", True)]
                        unhovered SetVariable("hovering_button", False)
                        mouse "button_menu"

                        text loc["title"]:
                            xalign 0.5
                            yalign 1.0
                            size 24
                            outlines [ (1.2, "#6a6f88", 1, 1) ]
                            font "fonts/Nunito-Black.ttf"

                        $ npcs = get_npcs_for_location(loc_id) 
                        $ idx = 0

                        for npc in npcs:
                            $ xpos = 5 + idx * 70
                            $ ypos = 5
                            
                            add npc["icon"] xpos xpos ypos ypos

                            $ idx += 1  
                        
transform side_block_rooms(x):
    alpha 0.0
    xoffset 5
    pause x
    linear 0.1 alpha 1.0 xoffset 0

screen side_block_tutorial():
    frame:
        xsize 380
        ysize 900
        xalign 0.99
        yalign 0.8
        background Solid("#fffb2700")
        at transform:
            alpha 0.0
            on show:
                linear 0.1 alpha 1.0
            on hide:
                linear 0.1 alpha 0.0
        vbox:
            spacing 10

            for loc_id, loc in LOCATIONS.items():
                if loc["group"] == location_type:
                    
                    button:
                        xfill True
                        ysize 170

                        idle_background loc["image"]
                        hover_background loc["image"]

                        action NullAction()
                        hovered SetVariable("hovering_button", True)
                        unhovered SetVariable("hovering_button", False)
                        # mouse "button_menu"

                        text loc["title"]:
                            xalign 0.5
                            yalign 1.0
                            size 24
                            outlines [ (1.2, "#a4aeda", 1, 1) ]

                        # ===== Получаем NPC для локации =====
                        $ npcs = get_npcs_for_location(loc_id) 
                        $ idx = 0

                        for npc in npcs:
                            $ xpos = 5 + idx * 70
                            $ ypos = 5
                            
                            add npc["icon"] xpos xpos ypos ypos

                            $ idx += 1  
       
screen map_icon():
    if not renpy.get_screen("say"):
        imagebutton:
            idle "images/map_icon.png" 
            xpos 0.98
            ypos 0.02
            xanchor 1.0
            yanchor 0.0
            action Show("map_screen", transition=Dissolve(0.5))
            mouse "button_menu"
            

screen map_screen():
    modal True
    add "map_background.png"
    imagebutton:
        xpos 100
        ypos 200
        idle "meme-cat.png"
        action [Hide("map_screen", transition=Dissolve(0.5)), Jump("location1_label")]

    imagebutton:
        xpos 300
        ypos 400
        idle "meme-cat.png"
        action [Hide("map_screen", transition=Dissolve(0.5)),Jump("location2_label")]

    textbutton "Закрыть":
        xpos 0.95
        ypos 0.05
        xanchor 1.0
        yanchor 0.0
        action Hide("map_screen", transition=Dissolve(0.5))

transform quest_fade:
    alpha 0.0
    linear 0.1 alpha 1.0

screen quest_screen(): 
    frame:
        background "#00006600"
        xsize 550
        xpos 0
        ypos 261
        hbox:
            null width 7
            add selected_char_quest["quest_image"]:
                zoom 0.95
                yalign 1.15 
            null width 9
            vbox:
                hbox:
                    if "days" in selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]:
                        for day_text in selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]["days"]:
                            add AlphaMask(
                                "images/custom_gui/time_display/Small ellipse.png",
                                Fixed(
                                    Text(
                                        day_text,
                                        size=29,
                                        color="#000000",
                                        text_align=0.5,
                                        yalign=0.43,
                                        xalign=0.5,
                                    ),
                                    xsize=126,
                                    ysize=100,
                                    xalign=0.5,
                                    yalign=0.5
                                ),
                                invert=True
                            )
                hbox:
                    null width 9
                    text selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]["description_abb"]:
                        font "fonts/Nunito-ExtraBold.ttf"
                        outlines [(2, "#00000034", 0, 2)]
                    null width 9
                    if "time" in selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]:
                        text selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]["time"] at globals().get(f"gradientTime{selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]["time_gr"]}", None):
                            font "fonts/Nunito-ExtraBold.ttf"
                            if selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]["time_gr"] == "Morning":
                                outlines [(2, "#9F7A00", 0, 2)]
                            if selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]["time_gr"] == "Day":
                                outlines [(2, "#aa4f00ce", 0, 2)]
                            if selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]["time_gr"] == "Evening":
                                outlines [(2, "#932700d0", 0, 2)]
                            if selected_char_quest["quest"][eval(selected_char_quest["origname"] + "_relations_main")]["time_gr"] == "Night":
                                outlines [(2, "#2b1477d2", 0, 2)]
screen time_display_button():
    if not renpy.get_screen("say"):
        button:
            xpos 0.91
            ypos 0.01
            action Call("next_time_button")
            mouse "button_menu"
            add "images/icons/time/[current_time.capitalize()].png":
                at dissolve_transition
screen time_display():
    tag hud
    use quick_menu
    key "shift_K_7" action ToggleScreen("devtools_screen")
    if not (end_demo2):
        use icon_characters
    if not renpy.get_screen("say"):
        if selected_char_quest:
            if selected_char_quest["quest"]:
                use quest_screen
        frame:
            background "images/custom_gui/time_display/Darkpng.png"
            xsize 512
            ysize 357
            xalign 0.0  
            yalign 1.0
            text current_time_translate.capitalize():
                size 84
                xpos 42
                ypos 119
                at gradientTimeShadow
            text current_time_translate.capitalize():
                size 84
                xpos 41
                ypos 116
                at globals().get(f"gradientTime{current_time.capitalize()}", None)
            add "images/custom_gui/time_display/Line.png":
                xpos 34
                ypos 227
            add AlphaMask(
                "images/custom_gui/time_display/Ellipse.png",
                Fixed(
                    Text(
                        current_day_abb,
                        size=50,
                        color="#000",
                        text_align=0.5,
                        yalign=0.32,
                        xalign=0.5,
                    ),
                    xsize=126,
                    ysize=100,
                    xalign=0.5,
                    yalign=0.5
                ),
                invert=True
            ):
                xpos 46
                ypos 256
            hbox:
                text str(day_number):
                    font "fonts/Nunito-Black.ttf" 
                    size 45
                    xpos 184
                    ypos 259
                    at gradientTimeShadow
                text _("д"):
                    font "fonts/Nunito-Black.ttf" 
                    size 45
                    xpos 184
                    ypos 259
                    at gradientTimeShadow
            hbox:
                text str(day_number):
                    font "fonts/Nunito-Black.ttf" 
                    size 45
                    xpos 183
                    ypos 256
                    color "#FFEFDD"
                text _("д"):
                    font "fonts/Nunito-Black.ttf" 
                    size 45
                    xpos 183
                    ypos 256
                    color "#FFEFDD"

screen time_display_tutorial():
    button:
        xpos 0.91 
        ypos 0.01
        action NullAction()
        add "images/icons/time/[current_time.capitalize()].png":
            at dissolve_transition
    
    if selected_char_quest:
        if selected_char_quest["quest"]:
            use quest_screen
    frame:
        background "images/custom_gui/time_display/Darkpng.png"
        xsize 512
        ysize 357
        xalign 0.0  
        yalign 1.0
        text current_time_translate.capitalize():
            size 84
            xpos 42
            ypos 119
            at gradientTimeShadow
        text current_time_translate.capitalize():
            size 84
            xpos 41
            ypos 116
            at globals().get(f"gradientTime{current_time.capitalize()}", None)
        add "images/custom_gui/time_display/Line.png":
            xpos 34
            ypos 227
        add AlphaMask(
            "images/custom_gui/time_display/Ellipse.png",
            Fixed(
                Text(
                    current_day_abb,
                    size=50,
                    color="#000",
                    text_align=0.5,
                    yalign=0.32,
                    xalign=0.5,
                ),
                xsize=126,
                ysize=100,
                xalign=0.5,
                yalign=0.5
            ),
            invert=True
        ):
            xpos 46
            ypos 256
        hbox:
            text str(day_number):
                font "fonts/Nunito-Black.ttf" 
                size 45
                xpos 184
                ypos 259
                at gradientTimeShadow
            text _("д"):
                font "fonts/Nunito-Black.ttf" 
                size 45
                xpos 184
                ypos 259
                at gradientTimeShadow
        hbox:
            text str(day_number):
                font "fonts/Nunito-Black.ttf" 
                size 45
                xpos 183
                ypos 256
                color "#FFEFDD"
            text _("д"):
                font "fonts/Nunito-Black.ttf" 
                size 45
                xpos 183
                ypos 256
                color "#FFEFDD"

style time_text:
    color "#FFFFFF"
    xalign 0.5
    size 22

transform dissolve_transition:
    alpha 0.0
    easein 0.25 alpha 1.0

screen icon_characters():
    if not renpy.get_screen("say"):
        imagebutton:
            idle "images/icons/icon_characters.png"
            xpos 0.07 
            ypos 0.02 
            xsize 120
            ysize 120
            xanchor 1.0
            yanchor 0.0
            action Show("characters_screen", transition=Dissolve(0.5))
            mouse "button_menu"

screen icon_characters_tutorial():
    imagebutton:
        idle "images/icons/icon_characters.png" 
        xpos 0.07 
        ypos 0.02
        xsize 120
        ysize 120
        xanchor 1.0
        yanchor 0.0
        mouse "button_menu"



screen characters_screen():
    modal True
    add "gui/overlay/black_screen_menu.png"
    hbox:
            xalign 0.5
            yalign 0.5
            xfill True
            yfill True
            vbox:
                xsize 420
                hbox:
                    xfill True 
                    ysize 100 
                    text _("Персонажи"):
                        xalign 0.5 
                        yalign 0.5
                        at gradientWhite
                        outlines [(3, "#515354", 1, 1)]
                viewport:
                    xfill True 
                    ysize 880 
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    vbox:
                        xfill True 
                        spacing 5
                        for character in characters_list:
                            $ Unlock_char = eval("Unlock_" + character["origname"])
                            if Unlock_char:
                                button:
                                    background ("images/custom_gui/selected_button_char.png" if selected_char == character else "images/custom_gui/unselected_button_char.png")
                                    hover_background ("images/custom_gui/selected_button_char.png" if selected_char == character else "images/custom_gui/hover_button_char.png")
                                    hover_sound ui_select_sounds[1]
                                    xalign 0.5
                                    xsize 378
                                    ysize 108
                                    padding (15, 10)
                                    mouse "button_menu"
                                    hbox:
                                        spacing 15
                                        yalign 0.5
                                        if "icon_image" in character:
                                            add character["icon_image"]:
                                                size (90, 85)
                                                yoffset 4
                                                xoffset 7
                                        else:
                                            add Solid("#777777", xsize=80, ysize=80)
                                        
                                        text character.get("name", "Безымянный"):
                                            size 30
                                            yalign 0.55
                                            at eval(character.get("gradient", "gradientPlayer"))
                                            outlines eval(character.get("outlines_name", "gradientPlayer"))
                                    
                                    action [SetVariable("selected_char", character), Play("fx3", ui_select_sounds[2])]
                            else:
                                button:
                                    background ("images/custom_gui/selected_button_char.png" if selected_char == character else "images/custom_gui/unselected_button_char.png")
                                    hover_background ("images/custom_gui/selected_button_char.png" if selected_char == character else "images/custom_gui/hover_button_char.png")
                                    hover_sound ui_select_sounds[1]
                                    xalign 0.5
                                    xsize 378
                                    ysize 108
                                    padding (15, 10)
                                    mouse "button_menu"
                                    hbox:
                                        spacing 15
                                        yalign 0.5
                                        if "icon_image" in character:
                                            add character["icon_image_locked"]:
                                                size (90, 85)
                                                yoffset 4
                                                xoffset 7
                                        else:
                                            add Solid("#777777", xsize=80, ysize=80)
                                        
                                        text "???":
                                            size 30
                                            yalign 0.55
                                            at gradientWhite
                                            outlines [(3, "#515354", 1, 1)]
                                    
                                    action [SetVariable("selected_char", character), Play("fx3", ui_select_sounds[2])]
                hbox:
                    ysize 100 
                    xfill True 
                    button:
                        xfill True 
                        yfill True
                        mouse "button_menu"
                        text _("Вернуться"):
                            xalign 0.5
                            yalign 0.5
                            at gradientWhite
                            outlines [(3, "#515354", 1, 1)]
                        action  [Hide("characters_screen", transition=Dissolve(0.5)), SetVariable("selected_char", None), Play("fx3", ui_select_sounds[2])]
                    
            hbox:
                xfill True
                yfill True
                frame:
                    xsize 0.5
                    yfill True
                    padding (30, 30)
                    background "#ff000000"
                    if selected_char:
                        $ char_name = selected_char["origname"]
                        $ Unlock_charsel = eval("Unlock_" + char_name)
                        if Unlock_charsel:
                            if "quest" in selected_char:
                                $ relations_level = eval(char_name + "_relations_main")
                            vbox:
                                null height 40
                                $ outlinesname_value = eval(selected_char["outlines_name"])
                                $ outlines_value = eval(selected_char["outlines"])
                                hbox:
                                    ysize 20
                                    spacing  40
                                    xalign 0.5
                                    text selected_char["name"] at eval(selected_char["gradient"]) outlines outlinesname_value size 56 yalign 0.5
                                    if "relations" in selected_char:
                                        button:
                                            xsize 100
                                            ysize 100
                                            background "images/icons/relations_icon.png"
                                            text "[relations_level]" at gradientRed outlines outlines_value size 44 yalign 0.6 xalign 0.5
                                null height 40 
                                    
                                null height 40 
                                text selected_char["description"] size 36 at eval(selected_char["gradient"]) outlines outlines_value
                                
                                if "quest" in selected_char:
                                    null height 40
                                    text _("Подсказка"):
                                        size 28
                                        at gradientWhite
                                        outlines [(3, "#515354", 1, 1)]
                                    null height 5
                                    text selected_char["quest"][relations_level]["description"] size 36 at eval(selected_char["gradient"]) outlines outlines_value
                                    null height 5
                                    if "days" in selected_char["quest"][relations_level]:
                                        hbox:
                                            for day in selected_char["quest"][relations_level]["days"]:
                                                text day:
                                                    size 22
                                                    at gradientWhite 
                                                    outlines [(3, "#515354", 1, 1)]
                                    null height 15
                                    button:
                                        xsize 500
                                        ysize 50
                                        mouse "button_menu"
                                        hover_sound ui_select_sounds[1]
                                        if (not(selected_char_quest)) or selected_char_quest["origname"] != selected_char["origname"]:
                                            add "images/custom_gui/unpin.png"
                                            text _("Отслеживать квест"): 
                                                xpos 60
                                                yalign 0.35
                                                at gradientKate
                                                outlines [(3, "#b38000", 1, 1)]
                                                size 30  
                                            
                                        else:
                                            add "images/custom_gui/pin.png"
                                            text _("Перестать отслеживать"):
                                                xpos 60
                                                yalign 0.35
                                                at gradientKate
                                                outlines [(3, "#b38000", 1, 1)]
                                                size 30
                                        if (not(selected_char_quest)) or selected_char_quest["origname"] != selected_char["origname"]:
                                            action [SetVariable("selected_char_quest", selected_char), Play("sound", ui_check_sounds[0])]
                                        else:
                                            action [SetVariable("selected_char_quest", None), Play("sound", ui_check_sounds[0])]
                        else:
                            vbox:
                                null height 40
                                $ outlinesname_value = eval(selected_char["outlines_name"])
                                $ outlines_value = eval(selected_char["outlines"])
                                hbox:
                                    ysize 100
                                    spacing  40
                                    xalign 0.5
                                    text "???" at gradientWhite outlines [(3, "#515354", 1, 1)] size 56 yalign 0.5
                                null height 40
                                text _("Продвигайтесь по сюжету") size 36 at gradientWhite outlines [(1, "#515354", 1, 1)] 
                if selected_char:
                    $ char_name = selected_char["origname"]
                    $ Unlock_charsel = eval("Unlock_" + char_name)
                    if Unlock_charsel:
                        frame:
                            xsize 1.0
                            yfill True
                            background "#ff000000"
                            if selected_char:
                                vbox:
                                    xfill True
                                    yfill True
                                    spacing 20
                                    if "full_image" in selected_char:
                                        add selected_char["full_image"]:
                                            size (753, 1080)
                                            yalign 0.5
 
    
    

screen check_obj():
    $ idles = get_idle_for_location(current_label)

    if current_label == "bathroom":
        $ blocked_bathroom = (
            (current_day in ["Monday", "Saturday"] and current_time == "evening" and Maya_relations_main <= 10)
            or
            (((current_day in ["Tuesday", "Friday"] and current_time == "morning")
            or (current_day == "Thursday" and current_time == "evening"))
            and Sonya_relations_main <= 4)
        )

        if blocked_bathroom:
            null  # ничего не показываем => нечему "мигать"
        else:
            $ idles = get_idle_for_location(current_label)

            for npc in idles:
                imagebutton:
                    idle npc["idle"]
                    action Call(npc["action"])
                    mouse "button_dialog"
                    focus_mask True

    else:
        # ---- Все остальные локации: как было ----
        $ idles = get_idle_for_location(current_label)

        for npc in idles:
            imagebutton:
                idle npc["idle"]
                action Call(npc["action"])
                mouse "button_dialog"
                focus_mask True
    if current_label == "myroom":
        if (current_time != "night") and not (current_day == "Thursday" and current_time == "day"):
            imagebutton:
                idle im.MatrixColor("easter/frog_easter_egg.png", im.matrix.opacity(0.02))
                hover Fixed(
                    im.MatrixColor("easter/frog_easter_egg.png", im.matrix.opacity(0.02)),
                    im.MatrixColor("easter/froggy.png", im.matrix.opacity(1))
                )
                action NullAction()
                activate_sound "frog_easter_egg.mp3"
                mouse "button_menu"
                focus_mask True
        if (current_time == "night"):
            imagebutton:
                idle im.MatrixColor("bed.png", im.matrix.opacity(0.02))
                hover Fixed(
                    im.MatrixColor("bed.png", im.matrix.opacity(0.02)),
                    "bed_outline",
                    "sleep_seq"
                )
                action Call("sleep_until_morning")
                mouse "button_menu"
                focus_mask True

    if current_label == "bathroom":
        if not (current_day == "Thursday" and current_time == "evening"):
            imagebutton:
                idle im.MatrixColor("easter/duck_easter_egg.png", im.matrix.opacity(0.02))
                hover Fixed(
                    im.MatrixColor("easter/duck_easter_egg.png", im.matrix.opacity(0.02)),
                    im.MatrixColor("easter/utochka.png", im.matrix.opacity(1)),
                )
                action NullAction()
                activate_sound "duck_easter_egg.mp3"
                mouse "button_menu"
                focus_mask True

    if current_label == "mayaroom":
        imagebutton:
                if (Maya_relations_main >=11 and Sonya_relations_main >= 3 and Unlock_Kate and current_time == "day" and not(helloween_complete)):   
                    action Call("halloween_prestart")
                    idle Fixed(
                        im.MatrixColor("easter/pumpkin_easter_egg.png", im.matrix.opacity(0.02)),
                        "pumpkin_seq"
                    ) 
                    hover Fixed(
                        im.MatrixColor("easter/pumpkin_easter_egg.png", im.matrix.opacity(0.02)),
                        im.MatrixColor("easter/tucva.png", im.matrix.opacity(1)),
                        "pumpkin_seq"
                    )
                else:
                    if not(helloween_flag):
                        action Call("select_halloween_event")
                        idle im.MatrixColor("easter/pumpkin_easter_egg.png", im.matrix.opacity(0.02))
                        hover Fixed(
                            im.MatrixColor("easter/pumpkin_easter_egg.png", im.matrix.opacity(0.02)),
                            im.MatrixColor("easter/tucva.png", im.matrix.opacity(1)),
                        )
                    if helloween_flag:
                        idle im.MatrixColor("easter/pumpkin_easter_egg.png", im.matrix.opacity(0.02))
                        hover Fixed(
                            im.MatrixColor("easter/pumpkin_easter_egg.png", im.matrix.opacity(0.02)),
                            im.MatrixColor("easter/tucva.png", im.matrix.opacity(1)),
                        )
                        action NullAction()
                        activate_sound "pumpkin.mp3"
                mouse "button_menu"
                focus_mask True

    if current_label == "girlroom":
        imagebutton:
                idle im.MatrixColor("easter/guitar_easter_egg.png", im.matrix.opacity(0.02))
                hover Fixed(
                    im.MatrixColor("easter/guitar_easter_egg.png", im.matrix.opacity(0.02)),
                    im.MatrixColor("easter/guitarochka.png", im.matrix.opacity(1)),
                )
                action NullAction()
                activate_sound "guitarstring.mp3"
                mouse "button_menu"
                focus_mask True
 

screen disclaimer_bugs():
        add "images/disclaimer/bugs/[_preferences.language]_bugs.png"

screen disclaimer():
        add "images/disclaimer/disc/[_preferences.language]_disc.png"

screen time_skip_message(message):
    zorder 100
    tag time_skip

    add Solid("#000")  # черный фон

    text message:
        at fade_in_out
        xalign 0.5
        yalign 0.5
        size 60
        color "#ffffff"

transform fade_in_out:
    alpha 0.0
    linear 1.0 alpha 1.0  # плавно появится за 1 сек
    pause 2.0            # подержится 2 секунды
    linear 1.0 alpha 0.0  # плавно исчезнет за 1 сек