label mayaroom:
    hide screen time_display
    $ location_type = "house"
    $ current_label = "mayaroom"

    if not(end_demo) and not(gg_first_morning_mayaroom) and current_time == "day":
        jump gg_first_morning_mayaroom

    if current_day in ["Tuesday", "Wednesday", "Friday", "Saturday"] and current_time == "day" and Maya_relations_main == 1:
        jump maya_scene2_day_mayaroom
    if current_day in ["Monday", "Thursday", "Sunday"] and current_time == "morning" and Maya_relations_main == 3:
        jump maya_scene4_morning_mayaroom
    if current_day in ["Wednesday", "Thursday", "Friday", "Saturday"] and current_time == "night" and Maya_relations_main == 4:
        jump maya_scene5_night_mayaroom
    if current_day in ["Monday", "Tuesday", "Saturday", "Sunday"] and current_time == "night" and Maya_relations_main == 6:
        jump maya_scene7_night_mayaroom
    if current_day in ["Monday", "Tuesday", "Wednesday", "Thursday"] and current_time == "morning" and Maya_relations_main == 7:
        jump maya_scene8_morning_mayaroom
    

    scene expression "bg_rooms/bg_maya_[current_time].png"
    show screen check_obj
    if (tutorialclock):
        show screen time_display
        show screen time_display_button
    if(tutorialnavagation):
        show screen rooms_in
    $ renpy.checkpoint()
    $ ui.interact()
    return






