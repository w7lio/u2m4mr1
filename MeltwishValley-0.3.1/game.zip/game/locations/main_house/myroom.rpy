label myroom:
    hide screen time_display
    $ location_type = "house"
    $ current_label = "myroom" 
    if current_day in ["Tuesday", "Wednesday", "Sunday"] and current_time == "evening" and Maya_relations_main == 0:
        jump maya_scene1_evening_myroom
    if current_day in ["Friday", "Sunday"] and current_time == "evening" and Maya_relations_main == 5:
        jump maya_scene6_evening_myroom
    if current_day in ["Wednesday", "Saturday"] and current_time == "evening" and Maya_relations_main == 9:
        jump maya_scene10_evening_myroom
    if current_day in ["Tuesday", "Friday", "Sunday"] and current_time == "evening" and Maya_relations_main == 11:
        jump maya_scene12_evening_myroom
    if current_day in ["Monday", "Thursday"] and current_time == "day" and Maya_relations_main == 13:
        jump maya_scene14_afternoon_myroom

    if current_day in ["Monday", "Thursday"] and current_time == "evening" and Sonya_relations_main == 5:
        jump sonya_scene6_evening_myroom
    if current_day in ["Monday", "Friday"] and current_time == "night" and Sonya_relations_main == 8:
        jump sonya_scene9_night_myroom

    if current_day in ["Monday"] and current_time == "day" and gg_relations_main == 1 and Kate_relations_main == 0:
        jump kate_day_myroom
    
    scene expression "bg_rooms/bg_myroom_[current_time].png"

    if (current_label == "scene13"):
            $ renpy.pause(delay=0.5, hard=True)
            "Что бы лечь спать нажмите ночью на кровать"
    
    show screen check_obj 
    if end_demo and end_demo2 and current_time == "morning":
        show screen time_display_tutorial
        "Теперь ты можешь управлять временем суток"
        "Нажми на значок в правом верхнем углу, чтобы сменить время"
        show idle at move_center_to_righttop_and_back onlayer overlay
        "В левом нижнем углу отображаются текущее время суток, день недели и счётчик дней"
        hide screen time_display_tutorial
        hide idle at tutor_alpha
        "Также тебе доступна книга персонажей"
        show screen icon_characters_tutorial
        show idle at move_center_to_lefttop_and_back onlayer overlay
        "В ней ты можешь посмотреть описание каждой девушки и текущий уровень отношений"
        "Здесь же доступны подсказки к следующему событию и возможность закрепить активный квест"
        hide screen icon_characters_tutorial
        hide idle at tutor_alpha
        $ end_demo2 = False
        $ tutorialclock = True
    if (tutorialclock):
        show screen time_display
        show screen time_display_button
    if(tutorialnavagation):
        show screen rooms_in


    $ renpy.checkpoint()
    $ ui.interact()
    return























