label bathroom:
    hide screen time_display
    hide screen check_obj
    $ location_type = "house"
    $ current_label = "bathroom"
    if not(end_demo) and current_time == "evening":
        jump gg_first_day_bathroom
    if current_day in ["Tuesday", "Thursday", "Sunday"] and current_time == "morning" and Maya_relations_main == 10:
        jump maya_scene11_morning_bathroom
    if current_day in ["Friday", "Saturday"] and current_time == "day" and Sonya_relations_main == 2:
        jump sonya_scene3_day_bathroom
    if current_day in ["Monday", "Friday"] and current_time == "morning" and Sonya_relations_main == 3:
        jump sonya_scene4_morning_bathroom


    if current_day in ["Monday", "Saturday"] and current_time == "evening" and Maya_relations_main <= 10:
        hide screen side_block
        hide screen rooms_in
        gg "Наверное, я ещё недостаточно хорошо знаком с Маей"
        $ renpy.transition(dissolve)
        $ renpy.jump(prev_location)
    elif ((current_day in ["Tuesday", "Friday"] and current_time == "morning") or (current_day in ["Thursday"] and current_time == "evening")) and Sonya_relations_main <= 4:
        hide screen side_block
        hide screen rooms_in
        gg "Наверное, я ещё недостаточно хорошо знаком с Соней"
        $ renpy.transition(dissolve)
        $ renpy.jump(prev_location)
    else:
        show screen check_obj
    scene bg_bathroom
    if(tutorialnavagation):
        show screen rooms_in 
    if (tutorialclock):
        show screen time_display
        show screen time_display_button
    $ renpy.checkpoint()
    $ ui.interact()
    return