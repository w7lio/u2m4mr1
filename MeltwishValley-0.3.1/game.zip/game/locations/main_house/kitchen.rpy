label kitchen:
    hide screen time_display
    $ location_type = "house"
    $ current_label = "kitchen"
    if current_day in ["Monday", "Thursday", "Friday"] and current_time == "evening" and Maya_relations_main == 2:
        jump maya_scene3_evening_kitchen
    if current_day in ["Tuesday", "Friday", "Sunday"] and current_time == "day" and Maya_relations_main == 8:
        jump maya_scene9_day_kitchen

    if current_day in ["Monday", "Wednesday", "Saturday"] and current_time == "morning" and Sonya_relations_main == 0:
        jump sonya_scene1_morning_kitchen
    if current_day in ["Thursday", "Saturday"] and current_time == "morning" and Sonya_relations_main == 7:
        jump sonya_scene8_morning_kitchen

    if current_day in ["Sunday"] and end_demo and current_time == "morning" and gg_relations_main == 0:
        jump kate_day_kitchen
    

        
    
        
    
    scene expression "bg_rooms/bg_kitchen_[current_time].png"
    show screen check_obj
    if not(tutorialnavagation):
        scene expression "bg_rooms/bg_kitchen_[current_time].png" with in_eye
        "Привет, перед началом игры давай быстро разберемся с управлением"
        "Что бы перейти в другую комнату тебе нужно навестись мышкой в правую часть экрана"
        show screen side_block_tutorial
        show idle at move_center_to_right_and_scroll onlayer overlay
        "После выбери комнату в которую хочешь попасть"
        "На иконках комнат будут отображены девушки которые сейчас там находятся"
        "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой доступно ключевое действие"
        "Попробуй перейти в комнату Маи"
        hide screen side_block_tutorial
        hide idle at tutor_alpha
        window hide
        $ tutorialnavagation = True

    if (tutorialclock):
        show screen time_display
        show screen time_display_button
    if(tutorialnavagation):
        show screen rooms_in
    $ renpy.checkpoint()
    $ ui.interact()
    return