label girlroom:
    hide screen time_display
    $ location_type = "house"
    $ current_label = "girlroom"
    
    if current_day in ["Monday", "Thursday"] and current_time == "morning" and Maya_relations_main == 12:
        jump maya_scene13_morning_girlroom

    if current_day in ["Tuesday", "Wednesday", "Saturday"] and current_time == "day" and Sonya_relations_main == 1:
        jump sonya_scene2_day_girlroom
    if current_day in ["Thursday", "Sunday"] and current_time == "evening" and Sonya_relations_main == 6:
        jump sonya_scene7_evening_girlroom
    scene expression "bg_rooms/bg_sonya_[current_time].png" 

    show screen check_obj
    if(tutorialnavagation):
        show screen rooms_in
    if (tutorialclock):
        show screen time_display
        show screen time_display_button
    $ renpy.checkpoint()
    $ ui.interact()
    return