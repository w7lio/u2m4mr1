﻿# TODO: Translation updated at 2026-01-21 02:04

# game/script.rpy:25
translate spanish start_fe40380a:

    # "Вы уже играли в нашу игру раньше?"
    "¿Has jugado nuestro juego antes?"

# game/script.rpy:26
translate spanish start_dc363420:

    # "Интро содержит важные сюжетные события и знакомство с миром игры"
    "La introducción contiene importantes eventos de la trama y una introducción al mundo del juego."

# game/script.rpy:27
translate spanish start_96a117ce:

    # "Если пропустить его при первом прохождении, вы рискуете упустить значительную часть истории и контента"
    "Si te lo saltas en tu primera partida, corres el riesgo de perderte una parte importante de la historia y el contenido."

translate spanish strings:

    # game/script.rpy:15
    old "И как же вас зовут"
    new "¿Y cuál es tu nombre?"

    # game/script.rpy:17
    old "Дэн"
    new "Dan"

    # game/script.rpy:29
    old "Начать игру"
    new "Iniciar juego"

    # game/script.rpy:31
    old "Пропустить интро"
    new "Saltar introducción"

