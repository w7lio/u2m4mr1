﻿# TODO: Translation updated at 2026-01-21 02:04

translate spanish strings:

    # game/core/variables.rpy:88
    old "Понедельник"
    new "Lunes"

    # game/core/variables.rpy:88
    old "Вторник"
    new "Martes"

    # game/core/variables.rpy:88
    old "Среда"
    new "Miércoles"

    # game/core/variables.rpy:88
    old "Четверг"
    new "Jueves"

    # game/core/variables.rpy:88
    old "Пятница"
    new "Viernes"

    # game/core/variables.rpy:88
    old "Суббота"
    new "Sábado"

    # game/core/variables.rpy:88
    old "Воскресенье"
    new "Domingo"

    # game/core/variables.rpy:121
    old "Моя комната"
    new "Mi habitación"

# TODO: Translation updated at 2026-02-13 11:40

translate spanish strings:

    # game/core/variables.rpy:422
    old "Ночь Зал"
    new "Noche Sala"

# TODO: Translation updated at 2026-02-16 03:29

translate spanish strings:

    # game/core/variables.rpy:427
    old "Комната Сони"
    new "Habitación de Sonya"

    # game/core/variables.rpy:427
    old "Утро комната Сони"
    new "Mañana, habitación de Sonya"

    # game/core/variables.rpy:427
    old "День зал"
    new "Sala de día"

