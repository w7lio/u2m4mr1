﻿# TODO: Translation updated at 2026-01-21 02:04

translate spanish strings:

    # game/core/characters.rpy:28
    old "Почтальон"
    new "Cartera"

    # game/core/characters.rpy:32
    old "Секретарь"
    new "Secretaria"

    # game/core/characters.rpy:36
    old "Директор"
    new "Director"

    # game/core/characters.rpy:40
    old "Незнакомая девушка"
    new "Desconocida"

# TODO: Translation updated at 2026-01-26 03:23

translate spanish strings:

    # game/core/characters.rpy:40
    old "Незнакомка"
    new "Desconocida"

