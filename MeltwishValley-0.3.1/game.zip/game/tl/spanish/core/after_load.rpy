﻿# TODO: Translation updated at 2026-01-21 02:04

translate spanish strings:

    # game/core/after_load.rpy:9
    old "Спокойный и наблюдательный, он приехал в посёлок, чтобы сбежать от прошлого и найти себя заново. Не всегда уверен, но с каждым новым знакомством делает шаг ближе к тому, кем хочет стать"
    new "Tranquilo y observador, llegó al pueblo para escapar del pasado y reencontrarse consigo mismo. No siempre está seguro, pero con cada nuevo conocido, da un paso más hacia quién quiere ser"

    # game/core/after_load.rpy:9
    old "Союзник"
    new "Aliado"

    # game/core/after_load.rpy:9
    old "Вс."
    new "Do"

    # game/core/after_load.rpy:9
    old "Кухня"
    new "Cocina"

    # game/core/after_load.rpy:9
    old "Утро Кухня"
    new "Cocina matutina"

    # game/core/after_load.rpy:9
    old "Ждем тебя в следующем патче"
    new "Te esperamos en el próximo parche"

    # game/core/after_load.rpy:9
    old "Вы прошли все сюжетные события этого персонажа в текущем патче"
    new "Completaste todos los eventos de la historia para este personaje en el parche actual"

    # game/core/after_load.rpy:9
    old "Мая"
    new "Maya"

    # game/core/after_load.rpy:9
    old "Дерзкая, ироничная и ленивая, кажется отстранённой, но чувствует глубже, чем показывает. Скрывает мягкость за сарказмом, пока не решит открыть себя по-настоящему. Не терпит слабости — особенно в себе"
    new "Imprudente, irónica y perezosa, parece distante, pero sus sentimientos son más profundos de lo que muestra. Esconde dulzura detrás del sarcasmo hasta que decide revelarse de verdad. No tolera la debilidad, especialmente en sí misma"

    # game/core/after_load.rpy:9
    old "Вт."
    new "Ma"

    # game/core/after_load.rpy:9
    old "Ср."
    new "Mi"

    # game/core/after_load.rpy:9
    old "Вечер"
    new "Atardecer"

    # game/core/after_load.rpy:9
    old "Зал"
    new "Sala"

    # game/core/after_load.rpy:9
    old "Вечер Зал"
    new "Salón de Atardecer"

    # game/core/after_load.rpy:9
    old "Пт."
    new "Vi"

    # game/core/after_load.rpy:9
    old "Сб."
    new "Sá"

    # game/core/after_load.rpy:9
    old "День"
    new "Tarde"

    # game/core/after_load.rpy:9
    old "Ее комната"
    new "Su habitación"

    # game/core/after_load.rpy:9
    old "День Ее комната"
    new "Tarde su habitación"

    # game/core/after_load.rpy:9
    old "Пн."
    new "Lu"

    # game/core/after_load.rpy:9
    old "Чт."
    new "Ju"

    # game/core/after_load.rpy:9
    old "Вечер кухня"
    new "Cocina de Atardecer"

    # game/core/after_load.rpy:9
    old "День ее комната"
    new "Tarde su habitación"

    # game/core/after_load.rpy:9
    old "Ночь"
    new "Noche"

    # game/core/after_load.rpy:9
    old "Ночь ее комната"
    new "noche su habitación"

    # game/core/after_load.rpy:9
    old "Вечер зал"
    new "Sala de Atardecer"

    # game/core/after_load.rpy:9
    old "Утро ее комната"
    new "mañana su habitación"

    # game/core/after_load.rpy:9
    old "День кухня"
    new "Tarde de cocina"

    # game/core/after_load.rpy:9
    old "Ванная"
    new "Baño"

    # game/core/after_load.rpy:9
    old "Утро ванная"
    new "baño de la mañana"

    # game/core/after_load.rpy:9
    old "Соня"
    new "Sonia"

    # game/core/after_load.rpy:9
    old "Тёплая и заботливая, но собранная и точная, как часы. Любит музыку, игры и порядок, иногда стесняется — но именно она делает шаг первой"
    new "Cálida y cariñosa, pero serena y precisa, como un reloj. Le encantan la música, los juegos y el orden; a veces es tímida, pero es ella quien da el primer paso"

    # game/core/after_load.rpy:9
    old "День Ванная"
    new "Baño de Tarde"

    # game/core/after_load.rpy:9
    old "Утро Ванная"
    new "Baño de la mañana"

    # game/core/after_load.rpy:9
    old "Стоит подождать"
    new "vale la pena esperar"

    # game/core/after_load.rpy:9
    old "Думаю стоит подождать"
    new "creo que vale la pena esperar"

    # game/core/after_load.rpy:9
    old "Вечер Ее комната"
    new "Atardecer su habitación"

    # game/core/after_load.rpy:9
    old "Кейт"
    new "Kate"

    # game/core/after_load.rpy:9
    old "Яркая и энергичная, Кейт не умеет сидеть на месте — она живёт движением и смехом. Кажется лёгкой и беззаботной, но за её улыбкой прячется страх остаться одной"
    new "Brillante y enérgica, Kate no sabe quedarse quieta: vive del movimiento y la risa. Parece ligera y despreocupada, pero detrás de su sonrisa se esconde el miedo a estar sola"

    # game/core/after_load.rpy:9
    old "Утро Зал"
    new "Salón de la mañana"

# TODO: Translation updated at 2026-01-26 03:23

# game/core/after_load.rpy:4
translate spanish after_load_f281aeec:

    # "Привет. Игра потерпела большой реворк, получила новое интро и сцены"
    "Hola. El juego ha recibido un gran rediseño, con una nueva introducción y escenas"

# game/core/after_load.rpy:5
translate spanish after_load_92feb703:

    # "Старые сейвы работать не будут(("
    "Los guardados antiguos no funcionarán :("

# game/core/after_load.rpy:6
translate spanish after_load_dc6483bb:

    # "Пожалуйста начните игру заново"
    "Por favor, empieza el juego de nuevo"

# TODO: Translation updated at 2026-01-27 02:10

# game/core/after_load.rpy:4
translate spanish after_load_75a05417:

    # "Привет. Игра претерпела большие изменения, получила новое интро и сцены"
    "Hola. El juego ha sufrido grandes cambios y ahora tiene una nueva introducción y escenas."

# game/core/after_load.rpy:6
translate spanish after_load_c7ff0b32:

    # "Пожалуйста, начните игру заново"
    "Por favor, empieza el juego de nuevo"

# TODO: Translation updated at 2026-01-27 22:53

translate spanish strings:

    # game/core/after_load.rpy:13
    old "День Зал"
    new "Baño de Atardecer"

