﻿# TODO: Translation updated at 2026-01-21 02:04

# game/core/scripts.rpy:52
translate spanish next_time_button_9cf59ffc:

    # "Пора спать"
    "Es hora de dormir"

# game/core/scripts.rpy:97
translate spanish sleep_until_morning_caa36b56:

    # "Думаю еще не время ложиться спать"
    "Creo que todavía no es hora de acostarme"

