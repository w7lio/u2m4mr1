﻿# TODO: Translation updated at 2026-01-21 02:04

# game/special_events/halloween 2025.rpy:30
translate spanish halloween_prestart_6dc15a83_1:

    # gg "Хм . . ."
    gg "Hmm . . ."

# game/special_events/halloween 2025.rpy:31
translate spanish halloween_prestart_3173d374_1:

    # gg "А что это еще такое?"
    gg "¿Y esto qué es?"

# game/special_events/halloween 2025.rpy:32
translate spanish halloween_prestart_9d6bd7cd_1:

    # gg "Эта тыква будто манит меня дотронуться до нее"
    gg "Esta calabaza parece invitarme a tocarla"

# game/special_events/halloween 2025.rpy:34
translate spanish halloween_prestart_6b235c12_1:

    # gg "Вроде ничего не случилось"
    gg "Parece que no pasó nada"

# game/special_events/halloween 2025.rpy:35
translate spanish halloween_prestart_99b702cc_1:

    # gg "Так не интересно"
    gg "Qué aburrido"

# game/special_events/halloween 2025.rpy:36
translate spanish halloween_prestart_882ef6af_1:

    # gg "Так не интересно"
    gg "entonces no es interesante"

# game/special_events/halloween 2025.rpy:40
translate spanish halloween_prestart_2eb26325_1:

    # gg "Ай!" with hpunch
    gg "¡Ay!" with hpunch

# game/special_events/halloween 2025.rpy:41
translate spanish halloween_prestart_b858f49b_1:

    # gg "Почему так щипет"
    gg "¿Por qué pica tanto?"

# game/special_events/halloween 2025.rpy:42
translate spanish halloween_prestart_eb8d9b68_1:

    # gg "Что то мне не хорошо"
    gg "Me siento mal"

# game/special_events/halloween 2025.rpy:43
translate spanish halloween_prestart_462beaf3_1:

    # gg "Пойду отдохну"
    gg "Iré a descansar"

# game/special_events/halloween 2025.rpy:55
translate spanish halloween_start_941a30ef_1:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/special_events/halloween 2025.rpy:57
translate spanish halloween_start_2768572c_1:

    # Sonya "Знаешь, что я поняла?"
    Sonya "¿Sabes de qué me di cuenta?"

# game/special_events/halloween 2025.rpy:58
translate spanish halloween_start_b99b94d3_1:

    # gg "Что пора поспать?"
    gg "¿Que es hora de dormir?"

# game/special_events/halloween 2025.rpy:60
translate spanish halloween_start_73751dc8_1:

    # Sonya "Что пора украшать дом"
    Sonya "Que es hora de decorar la casa"

# game/special_events/halloween 2025.rpy:62
translate spanish halloween_start_2efbd354_1:

    # gg "Украшать?"
    gg "¿Decorar?"

# game/special_events/halloween 2025.rpy:64
translate spanish halloween_start_baa9dc02_1:

    # Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    Sonya "Tenemos Halloween en 2 días y la atmósfera es cero"

# game/special_events/halloween 2025.rpy:66
translate spanish halloween_start_d64dca0a_1:

    # Sonya "Я хочу, чтобы всё выглядело"
    Sonya "Quiero que todo se vea..."

# game/special_events/halloween 2025.rpy:68
translate spanish halloween_start_c1524153_1:

    # Sonya "Хотя бы немного празднично"
    Sonya "Al menos un poco festivo"

# game/special_events/halloween 2025.rpy:70
translate spanish halloween_start_c4c69fc7_1:

    # Maya "Украшать?{w} Пора бы да"
    Maya "¿Decorar?{w} Ya era hora, sí"

# game/special_events/halloween 2025.rpy:72
translate spanish halloween_start_f5a85bf6_1:

    # Maya "Можно повесить гирлянды и поставить свечи!"
    Maya "¡Podemos colgar guirnaldas y poner velas!"

# game/special_events/halloween 2025.rpy:74
translate spanish halloween_start_88ab11a7_1:

    # Sonya "Вот. Поддержка есть"
    Sonya "Ves. Tengo apoyo"

# game/special_events/halloween 2025.rpy:76
translate spanish halloween_start_f2b19d78_1:

    # gg "Видимо у меня нет выбора"
    gg "Parece que no tengo elección"

# game/special_events/halloween 2025.rpy:78
translate spanish halloween_start_bc7a61df_1:

    # Maya "Ты просто устал, тебе нужно отвлечься"
    Maya "Solo estás cansado, necesitas distraerte"

# game/special_events/halloween 2025.rpy:80
translate spanish halloween_start_06d0d58b_1:

    # Sonya "Вот именно"
    Sonya "Exactamente"

# game/special_events/halloween 2025.rpy:82
translate spanish halloween_start_041234b8_1:

    # Sonya "Украшение дома - лучший антистресс"
    Sonya "Decorar la casa es el mejor antiestrés"

# game/special_events/halloween 2025.rpy:84
translate spanish halloween_start_c578bb24_1:

    # Maya "Тогда решено"
    Maya "Entonces, decidido"

# game/special_events/halloween 2025.rpy:85
translate spanish halloween_start_6e15e900_1:

    # Maya "Начнём с гостиной"
    Maya "Empecemos por el salón"

# game/special_events/halloween 2025.rpy:87
translate spanish halloween_start_d298f1fa_1:

    # Maya "Я за уют, но без перебора"
    Maya "Me gusta la comodidad, pero sin exagerar"

# game/special_events/halloween 2025.rpy:89
translate spanish halloween_start_2a522c28_1:

    # Sonya "Надо позвать Кейт"
    Sonya "Hay que llamar a Kate"

# game/special_events/halloween 2025.rpy:90
translate spanish halloween_start_20197ce8_1:

    # Sonya "Без неё всё равно не обойдётся"
    Sonya "De todas formas, no saldrá bien sin ella"

# game/special_events/halloween 2025.rpy:92
translate spanish halloween_start_bcecc811_1:

    # Maya "Я напишу ей"
    Maya "Le escribiré"

# game/special_events/halloween 2025.rpy:93
translate spanish halloween_start_81baf5ad_1:

    # Maya "Если не занята, придёт"
    Maya "Si no está ocupada, vendrá"

# game/special_events/halloween 2025.rpy:95
translate spanish halloween_start_4a4b3e1e_1:

     # Sonya "Пойдем поможешь мне"
    Sonya "Ven, ayúdame"

# game/special_events/halloween 2025.rpy:97
translate spanish halloween_start_082fbdc3_1:

     # Sonya "У нас в кладовке чего только нету"
    Sonya "Tenemos de todo en el trastero"

# game/special_events/halloween 2025.rpy:99
translate spanish halloween_start_569f8605_1:

    # Sonya "Осторожно, она тяжёлая"
    Sonya "Cuidado, es pesada"

# game/special_events/halloween 2025.rpy:103
translate spanish halloween_start_08a41431_1:

    # gg "Не волнуйся, я пока справляюсь"
    gg "No te preocupes, de momento voy bien"

# game/special_events/halloween 2025.rpy:105
translate spanish halloween_start_2ee9b67e_1:

    # Maya "Написала, сказала, что уже бежит"
    Maya "Le escribí, dice que ya viene corriendo"

# game/special_events/halloween 2025.rpy:107
translate spanish halloween_start_56e25c3d_1:

    # Sonya "Это хорошо"
    Sonya "Eso es bueno"

# game/special_events/halloween 2025.rpy:109
translate spanish halloween_start_cc205380_1:

    # Maya "О, смотри, старая паутина!"
    Maya "¡Oh, mira, una telaraña vieja!"

# game/special_events/halloween 2025.rpy:111
translate spanish halloween_start_6d122aa8_1:

    # Sonya "Это не декор, не трогай!"
    Sonya "¡Eso no es decoración, no la toques!"

# game/special_events/halloween 2025.rpy:113
translate spanish halloween_start_1c832081_1:

    # Maya "Ты же знаешь я боюсь пауков!"
    Maya "¡Sabes que les tengo miedo a las arañas!"

# game/special_events/halloween 2025.rpy:114
translate spanish halloween_start_e8c9fd97_1:

    # gg "Ха ха"
    gg "Ja ja"

# game/special_events/halloween 2025.rpy:119
translate spanish halloween_start_5c8cb7fa_1:

    # Kate "Я пришла"
    Kate "Ya llegué"

# game/special_events/halloween 2025.rpy:120
translate spanish halloween_start_5cba982d_1:

    # Kate "Где вы, мои маленькие смертные?"
    Kate "¿Dónde estáis, mis pequeños mortales?"

# game/special_events/halloween 2025.rpy:121
translate spanish halloween_start_66671892_1:

    # Maya "Привет!"
    Maya "¡Hola!"

# game/special_events/halloween 2025.rpy:123
translate spanish halloween_start_41cac97b_1:

    # Kate "О, вы уже начали без меня?{w} Это предательство"
    Kate "Oh, ¿ya empezasteis sin mí?{w} Esto es una traición"

# game/special_events/halloween 2025.rpy:125
translate spanish halloween_start_3f833e29_1:

    # Maya "Мы только подготовились"
    Maya "Apenas nos hemos preparado"

# game/special_events/halloween 2025.rpy:127
translate spanish halloween_start_10a24600_1:

    # Sonya "Отлично, теперь можем начинать по-настоящему"
    Sonya "Genial, ahora podemos empezar de verdad"

# game/special_events/halloween 2025.rpy:129
translate spanish halloween_start_59716300_1:

    # Maya "Всё, распределяем задачи?"
    Maya "Bueno, ¿repartimos las tareas?"

# game/special_events/halloween 2025.rpy:131
translate spanish halloween_start_c6287aa3_1:

    # Kate "Так эту куклу повесим вон там, над теликом"
    Kate "Pues colguemos esta muñeca allá, sobre el televisor"

# game/special_events/halloween 2025.rpy:132
translate spanish halloween_start_ddd8aded_1:

    # Kate "Еще нужны паутины, гирлянда из флажков, черепа . . ."
    Kate "También necesitamos telarañas, una guirnalda de banderines, calaveras. . ."

# game/special_events/halloween 2025.rpy:134
translate spanish halloween_start_c1c2f306_1:

    # Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    Maya "¿Entonces en mi habitación nos ahorramos las decoraciones espeluznantes?"

# game/special_events/halloween 2025.rpy:136
translate spanish halloween_start_344d78c3_1:

    # gg "Ну это же Хэллоуин, а чем ты?"
    gg "Bueno, es Halloween, ¿y tú qué?"

# game/special_events/halloween 2025.rpy:138
translate spanish halloween_start_7e9f8506_1:

    # Sonya "Мая просто трусишка"
    Sonya "Maya es solo una miedosa"

# game/special_events/halloween 2025.rpy:140
translate spanish halloween_start_423eeb13_1:

    # Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "¡¡EY!! ¡Es que lo encuentro estúpido!"

# game/special_events/halloween 2025.rpy:141
translate spanish halloween_start_1c4935b1_1:

    # Maya "Можно сделать дом тёплым, как осень!"
    Maya "¡Podemos hacer la casa acogedora, como el otoño!"

# game/special_events/halloween 2025.rpy:142
translate spanish halloween_start_5acb8aac_1:

    # Maya "Листья и природу . . . И без жути . . ."
    Maya "Hojas y naturaleza. . . Y sin sustos. . ."

# game/special_events/halloween 2025.rpy:144
translate spanish halloween_start_9d95e4f7_1:

    # Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    Kate "Y yo quiero que dé tanto miedo que los niños del vecindario chillen de terror si se atreven a llamar a nuestra puerta"

# game/special_events/halloween 2025.rpy:146
translate spanish halloween_start_97fa9b09_1:

    # Sonya "Звучит как цель"
    Sonya "Suena como un objetivo"

# game/special_events/halloween 2025.rpy:148
translate spanish halloween_start_7a0152d7_1:

    # Maya "Надеюсь, что все пройдет без происшествий"
    Maya "Espero que todo transcurra sin incidentes"

# game/special_events/halloween 2025.rpy:150
translate spanish halloween_start_cd410fe4_1:

    # gg "Ну что же, давайте постараемся"
    gg "Bueno, pues esforcémonos"

# game/special_events/halloween 2025.rpy:158
translate spanish halloween_start_e7148dd7_1:

    # Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    Maya "¿Sabéis? No está tan mal, incluso es bastante bonito y acogedor"

# game/special_events/halloween 2025.rpy:160
translate spanish halloween_start_4203fcb3_1:

    # Kate "ДА! Вышло супер, мы такие молодцы"
    Kate "¡SÍ! Ha quedado genial, somos unos cracks"

# game/special_events/halloween 2025.rpy:162
translate spanish halloween_start_3c177eb8_1:

    # Sonya "Давайте дальше украсим кухню!"
    Sonya "¡Vamos a decorar la cocina ahora!"

# game/special_events/halloween 2025.rpy:163
translate spanish halloween_start_3fc97c96_1:

    # Sonya "[povname] хватай коробки с украшениями!"
    Sonya "[povname] ¡coge las cajas con los adornos!"

# game/special_events/halloween 2025.rpy:172
translate spanish halloween_start_c18a0daf_1:

    # Maya "Ну почему я должна ее вешать?"
    Maya "Bueno, ¿por qué tengo que colgarla yo?"

# game/special_events/halloween 2025.rpy:174
translate spanish halloween_start_538416e3_1:

    # Kate "Потому что ты самая высокая, это же логично!"
    Kate "¡Porque eres la más alta, es lógico!"

# game/special_events/halloween 2025.rpy:176
translate spanish halloween_start_fac78089_1:

    # Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    Maya "Puaj. No les tengo miedo a las arañas, es que son asquerosas, me dan repelús"

# game/special_events/halloween 2025.rpy:178
translate spanish halloween_start_196b4d6a_1:

    # gg "Тыкву тоже поставь на полку"
    gg "Pon la calabaza en el estante también"

# game/special_events/halloween 2025.rpy:187
translate spanish halloween_start_3ee05b57_1:

    # Maya "АААААААААА!" with hpunch
    Maya "¡¡¡AAAAAAAAAA!!!" with hpunch

# game/special_events/halloween 2025.rpy:191
translate spanish halloween_start_7410244b_1:

    # gg "Все, я убрал, не бойся, он же не настоящий"
    gg "Ya está, lo quité, no tengas miedo, no es de verdad"

# game/special_events/halloween 2025.rpy:193
translate spanish halloween_start_1ceba70d_1:

    # Maya "Спасибо"
    Maya "Gracias"

# game/special_events/halloween 2025.rpy:195
translate spanish halloween_start_5375f0ad_1:

    # gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    gg "Caes en mis brazos con demasiada frecuencia, ¿no lo harás a propósito?"

# game/special_events/halloween 2025.rpy:197
translate spanish halloween_start_ccd7999c_1:

    # Maya "Еще чего!"
    Maya "¡Qué va!"

# game/special_events/halloween 2025.rpy:198
translate spanish halloween_start_c938832e_1:

    # Maya "Ты просто мешаешься на пути, вот и все!"
    Maya "¡Es que te pones en medio, eso es todo!"

# game/special_events/halloween 2025.rpy:199
translate spanish halloween_start_5807bf69_1:

    # Kate "Не поранились? Голубки"
    Kate "¿No os habéis hecho daño? Tortolitas"

# game/special_events/halloween 2025.rpy:201
translate spanish halloween_start_180bf5f1_1:

    # Maya "Все с паутиной мы закончили"
    Maya "Hemos terminado con la telaraña"

# game/special_events/halloween 2025.rpy:202
translate spanish halloween_start_62eaed17_1:

    # Maya "Пойду возьму яблочного сидра"
    Maya "Voy a por sidra de manzana"

# game/special_events/halloween 2025.rpy:208
translate spanish halloween_start_6a9d122d_1:

    # Sonya "Еще 5 минут и кексы готовы"
    Sonya "5 minutos más y las magdalenas estarán listas"

# game/special_events/halloween 2025.rpy:210
translate spanish halloween_start_92462f90_1:

    # Kate "Пахнет потрясающе"
    Kate "Huele increíble"

# game/special_events/halloween 2025.rpy:212
translate spanish halloween_start_ada25b4b_1:

    # Maya "Всё, теперь осталось только подождать"
    Maya "Listo, ahora solo queda esperar"

# game/special_events/halloween 2025.rpy:213
translate spanish halloween_start_4ac68531_1:

    # Maya "Потом будем украшать"
    Maya "Luego decoraremos"

# game/special_events/halloween 2025.rpy:215
translate spanish halloween_start_7d203e0d_1:

    # Kate "Эй а кем вы будете в ночь Хэллоуина?"
    Kate "Oye, ¿y vosotros de qué vais a ir la noche de Halloween?"

# game/special_events/halloween 2025.rpy:217
translate spanish halloween_start_3e0fd7f3_1:

    # Sonya "Я уже думала об этом!"
    Sonya "¡Ya había pensado en eso!"

# game/special_events/halloween 2025.rpy:218
translate spanish halloween_start_21be6b25_1:

    # Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    Sonya "Mmm, Kate, un disfraz de demonio te quedaría bien"

# game/special_events/halloween 2025.rpy:220
translate spanish halloween_start_8fc9e335_1:

    # Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    Maya "Por cierto, sí, aunque pareces un angelito, eres astuta como un duende doméstico"

# game/special_events/halloween 2025.rpy:222
translate spanish halloween_start_6485ec70_1:

    # Kate "Эй!! Неплохая идея"
    Kate "¡¡Oye!! No es una mala idea"

# game/special_events/halloween 2025.rpy:226
translate spanish halloween_start_9ea771a0_1:

    # Kate "Королева демонов Уахахахаха!"
    Kate "¡La Reina de los Demonios, Wahahahaha!"

# game/special_events/halloween 2025.rpy:227
translate spanish halloween_start_dfa5392d_1:

    # Kate "Все должны пасть к моим ногам!"
    Kate "¡Todos deben caer a mis pies!"

# game/special_events/halloween 2025.rpy:229
translate spanish halloween_start_d1a70744_1:

    # Sonya "Все, ей больше не наливать!"
    Sonya "¡Basta, que no le sirvan más!"

# game/special_events/halloween 2025.rpy:231
translate spanish halloween_start_67a78ead_1:

    # gg "Не знал что Кейт так быстро выносит с алкоголя"
    gg "No sabía que el alcohol le afectaba tan rápido a Kate"

# game/special_events/halloween 2025.rpy:233
translate spanish halloween_start_89e99062_1:

    # Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    Maya "Me gustaría un disfraz de brujita o de alguna dríada mágica. . ."

# game/special_events/halloween 2025.rpy:235
translate spanish halloween_start_ccfee06e_1:

    # Kate "Думаю тебе пойдет"
    Kate "Creo que te quedará bien"

# game/special_events/halloween 2025.rpy:237
translate spanish halloween_start_8e96eaa2_1:

    # Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    Sonya "Y el otro día pedí 6 paquetes de vendas en lugar de 1, ¿parece una señal para hacer un disfraz de momia?"

# game/special_events/halloween 2025.rpy:239
translate spanish halloween_start_2aa5e0fb_1:

    # Maya "Ты как раз самая старшая"
    Maya "Resulta que eres la mayor"

# game/special_events/halloween 2025.rpy:241
translate spanish halloween_start_38bc2712_1:

    # Sonya "Ах ты!"
    Sonya "¡Ah, tú!"

# game/special_events/halloween 2025.rpy:243
translate spanish halloween_start_5d38e441_1:

    # Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "Espera, ¿y el gato? ¡Él también necesita un disfraz!"

# game/special_events/halloween 2025.rpy:244
translate spanish halloween_start_fb608953_1:

    # Maya "Например дракончика или мистер тыковка . . ."
    Maya "Por ejemplo, un dragoncito o un Señor Calabaza. . ."

# game/special_events/halloween 2025.rpy:246
translate spanish halloween_start_7fd69d94_1:

    # Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    Sonya "¡Intenta atraparlo y disfrazarlo, el Señor Barsik no se dejará!"

# game/special_events/halloween 2025.rpy:248
translate spanish halloween_start_70adb582_1:

    # Maya "Что ты . . . {w}Он любит переодевашки"
    Maya "Qué dices. . . {w}A él le encanta disfrazarse"

# game/special_events/halloween 2025.rpy:251
translate spanish halloween_start_c0036cba_1:

    # Sonya "Вот и кексы готовы"
    Sonya "Ya están listos los cupcakes"

# game/special_events/halloween 2025.rpy:253
translate spanish halloween_start_ae45c746_1:

    # gg "С кухней готово, что дальше?"
    gg "La cocina está lista, ¿qué sigue?"

# game/special_events/halloween 2025.rpy:254
translate spanish halloween_start_354f0704_1:

    # Sonya "Предлагаю разделиться"
    Sonya "Sugiero que nos dividamos"

# game/special_events/halloween 2025.rpy:255
translate spanish halloween_start_07a07420_1:

    # Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "Maya y yo decoraremos nuestras habitaciones, Kate, ¿tú decorarás el baño?"

# game/special_events/halloween 2025.rpy:256
translate spanish halloween_start_4e86ac78_1:

    # Sonya "[povname], будешь помогать нам?"
    Sonya "[povname], ¿nos ayudarás?"

# game/special_events/halloween 2025.rpy:257
translate spanish halloween_start_564e6225_1:

    # gg "Окей"
    gg "Vale"

# game/special_events/halloween 2025.rpy:271
translate spanish halloween_prepare_mayaroom_7afc2c47_1:

    # gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "Tienes aquí una auténtica guarida de bruja que prepara pociones con hierbas"

# game/special_events/halloween 2025.rpy:272
translate spanish halloween_prepare_mayaroom_63c64e7b_1:

    # gg "Мм. . . пахнет приятно"
    gg "Mmm. . . huele bien"

# game/special_events/halloween 2025.rpy:274
translate spanish halloween_prepare_mayaroom_1ca099b7_1:

    # Maya "Хватит нюхать женскую комнату!"
    Maya "¡Deja de olfatear la habitación de las chicas!"

# game/special_events/halloween 2025.rpy:276
translate spanish halloween_prepare_mayaroom_eded9518_1:

    # Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "Sólo estás aquí para seguir mis órdenes"

# game/special_events/halloween 2025.rpy:277
translate spanish halloween_prepare_mayaroom_799aa249_1:

    # Maya "Поставь эти тыквы в тот угол!"
    Maya "¡Pon esas calabazas en esa esquina!"

# game/special_events/halloween 2025.rpy:279
translate spanish halloween_prepare_mayaroom_292858b8_1:

    # gg "А где пожалуйста?"
    gg "¿Dónde, por favor?"

# game/special_events/halloween 2025.rpy:281
translate spanish halloween_prepare_mayaroom_ad71fbb0_1:

    # Maya "Пожалуйста, не беси меня"
    Maya "Por favor, no me enfurezcas"

# game/special_events/halloween 2025.rpy:283
translate spanish halloween_prepare_mayaroom_63b60e81_1:

    # gg "Ох"
    gg "Oh"

# game/special_events/halloween 2025.rpy:285
translate spanish halloween_prepare_mayaroom_977c102e_1:

    # Maya "Мм. . . нет!"
    Maya "Mmm. . . ¡No!"

# game/special_events/halloween 2025.rpy:287
translate spanish halloween_prepare_mayaroom_9cb8ca98_1:

    # Maya "Выглядит недостаточно хорошо!"
    Maya "¡No se ve lo suficientemente bien!"

# game/special_events/halloween 2025.rpy:289
translate spanish halloween_prepare_mayaroom_3b7bbda5_1:

    # Maya "Давай лучше в тот угол!"
    Maya "¡Mejor pongámoslas en esa otra esquina!"

# game/special_events/halloween 2025.rpy:291
translate spanish halloween_prepare_mayaroom_f714e642_1:

    # gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    gg "Decide primero exactamente dónde, para que no tenga que cargar estas calabazas cien veces"

# game/special_events/halloween 2025.rpy:293
translate spanish halloween_prepare_mayaroom_a2933c08_1:

    # Maya "Говорю же туда неси!"
    Maya "¡Te estoy diciendo que las lleves allí!"

# game/special_events/halloween 2025.rpy:295
translate spanish halloween_prepare_mayaroom_4c580716_1:

    # gg "Точно?"
    gg "¿Seguro?"

# game/special_events/halloween 2025.rpy:296
translate spanish halloween_prepare_mayaroom_fccb4de7_1:

    # gg "Я больше двигать не буду, подумай хорошо"
    gg "No las moveré más, piénsalo bien"

# game/special_events/halloween 2025.rpy:298
translate spanish halloween_prepare_mayaroom_4aa933c6_1:

    # Maya "Хотя как сейчас тоже неплохо . . ."
    Maya "Aunque tal como están ahora tampoco está mal. . ."

# game/special_events/halloween 2025.rpy:300
translate spanish halloween_prepare_mayaroom_b2b57087_1:

    # Maya "Все ты свободен!"
    Maya "¡Ya estás libre!"

# game/special_events/halloween 2025.rpy:302
translate spanish halloween_prepare_mayaroom_04c6c53d_1:

    # gg "Спасибо"
    gg "Gracias"

# game/special_events/halloween 2025.rpy:303
translate spanish halloween_prepare_mayaroom_dad56d9b_1:

    # Maya "Если что еще позову"
    Maya "Si necesito algo más, te llamaré"

# game/special_events/halloween 2025.rpy:305
translate spanish halloween_prepare_mayaroom_6a8ac153_1:

    # Maya "Все Давай, давай, живее!!"
    Maya "¡Vamos, vamos, más rápido!!"

# game/special_events/halloween 2025.rpy:321
translate spanish halloween_prepare_sonyaroom_b708d644_1:

    # Sonya "Ой" with hpunch
    Sonya "Ay" with hpunch

# game/special_events/halloween 2025.rpy:323
translate spanish halloween_prepare_sonyaroom_4b100306_1:

    # Sonya "Добро пожаловать в мою обитель!"
    Sonya "¡Bienvenido a mi morada!"

# game/special_events/halloween 2025.rpy:325
translate spanish halloween_prepare_sonyaroom_7fb491df_1:

    # gg "У тебя в стиле майнкрафта все, очень милая комната"
    gg "Todo está al estilo Minecraft, es una habitación muy bonita"

# game/special_events/halloween 2025.rpy:327
translate spanish halloween_prepare_sonyaroom_9dc8d94c_1:

    # Sonya "Да, у меня много игрушек осталось"
    Sonya "Sí, me quedan muchos juguetes"

# game/special_events/halloween 2025.rpy:328
translate spanish halloween_prepare_sonyaroom_1174b034_1:

    # gg "Чем то тебе помочь?"
    gg "¿Te ayudo en algo?"

# game/special_events/halloween 2025.rpy:330
translate spanish halloween_prepare_sonyaroom_36233e2b_1:

    # Sonya "О можешь пожалуйста разложить остальные блоки"
    Sonya "Oh, ¿podrías colocar los bloques restantes, por favor?"

# game/special_events/halloween 2025.rpy:332
translate spanish halloween_prepare_sonyaroom_51e25d01_1:

    # gg "Хорошо давай"
    gg "Vale, vamos"

# game/special_events/halloween 2025.rpy:336
translate spanish halloween_prepare_sonyaroom_5b80a77c_1:

    # Sonya "Так это сюда"
    Sonya "Entonces esto va aquí"

# game/special_events/halloween 2025.rpy:342
translate spanish halloween_prepare_sonyaroom_5e22d509_1:

    # Sonya "О забыла я же еще кексов поставила"
    Sonya "Oh, lo olvidé, también puse más cupcakes"

# game/special_events/halloween 2025.rpy:354
translate spanish halloween_prepare_bathroom_5d6a2459_1:

    # gg "Тук-Тук, к вам можно?"
    gg "Toc-toc, ¿se puede pasar?"

# game/special_events/halloween 2025.rpy:356
translate spanish halloween_prepare_bathroom_f77e9ebe_1:

    # Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "Oh, llegas justo a tiempo, justo iba a llamarte, quiero colgar un fantasma sobre la bañera"

# game/special_events/halloween 2025.rpy:357
translate spanish halloween_prepare_bathroom_65af0236_1:

    # Kate "Но не достаю, вот"
    Kate "Pero no llego, mira"

# game/special_events/halloween 2025.rpy:359
translate spanish halloween_prepare_bathroom_b38aeb93_1:

    # Kate "Вот, видишь?"
    Kate "¿Ves?"

# game/special_events/halloween 2025.rpy:361
translate spanish halloween_prepare_bathroom_e0f0e638_1:

    # Kate "Хм . . . а если я встану на бортики ванной?"
    Kate "Mmm. . . ¿y si me pongo de pie en el borde de la bañera?"

# game/special_events/halloween 2025.rpy:363
translate spanish halloween_prepare_bathroom_e11f6927_1:

    # gg "Стой, это не безопасно"
    gg "Para, eso no es seguro"

# game/special_events/halloween 2025.rpy:372
translate spanish halloween_prepare_bathroom_01550c8f_1:

    # Kate "ААй!" with hpunch
    Kate "¡Ay!" with hpunch

# game/special_events/halloween 2025.rpy:373
translate spanish halloween_prepare_bathroom_af26ae75_1:

    # Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    Kate "Oh, estoy demasiado borracha, qué bueno que estabas cerca, gracias"

# game/special_events/halloween 2025.rpy:375
translate spanish halloween_prepare_bathroom_78e2854b_1:

    # gg "Я так испугался за тебя"
    gg "Me asusté mucho por ti"

# game/special_events/halloween 2025.rpy:376
translate spanish halloween_prepare_bathroom_766703c6_1:

    # gg "За тобой глаз, да глаз, будь аккуратнее"
    gg "Hay que tener mucho cuidado contigo, ten más cuidado"

# game/special_events/halloween 2025.rpy:378
translate spanish halloween_prepare_bathroom_ef29b55b_1:

    # Kate "Хорошо, я обещаю . . ."
    Kate "Vale, lo prometo. . ."

# game/special_events/halloween 2025.rpy:380
translate spanish halloween_prepare_bathroom_61bd7d2f_1:

    # Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    Kate "¿Quizás ya podrías soltarme? No volveré a intentarlo"

# game/special_events/halloween 2025.rpy:382
translate spanish halloween_prepare_bathroom_77a74e82_1:

    # gg "Ты такая легкая"
    gg "Eres tan ligera"

# game/special_events/halloween 2025.rpy:384
translate spanish halloween_prepare_bathroom_a0e2f8bb_1:

    # Kate "Спасибо"
    Kate "Gracias"

# game/special_events/halloween 2025.rpy:400
translate spanish halloween_prepare_myroom_5692ba1f_1:

    # gg "Эх устал я помогать всем девочкам, и так спать хотел"
    gg "Ay, estoy cansado de ayudar a todas las chicas, y ya quería dormir"

# game/special_events/halloween 2025.rpy:402
translate spanish halloween_prepare_myroom_6e92de75_1:

    # gg "Думаю посплю часик"
    gg "Creo que dormiré una horita"

# game/special_events/halloween 2025.rpy:420
translate spanish halloween_sonya_dream_8c6442c7_1:

    # gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "Me despierto por un sonido extraño, como si alguien hubiera arrastrado una uña por la madera"

# game/special_events/halloween 2025.rpy:421
translate spanish halloween_sonya_dream_a05b8801_1:

    # gg_chat "Это на кухне?"
    gg_chat "¿Está en la cocina?"

# game/special_events/halloween 2025.rpy:423
translate spanish halloween_sonya_dream_514bb7b5_1:

    # gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "Salgo a la cocina frotándome los ojos"

# game/special_events/halloween 2025.rpy:424
translate spanish halloween_sonya_dream_045482c0_1:

    # gg_chat "На столе - что-то, чего там не было"
    gg_chat "Sobre la mesa hay algo que antes no estaba"

# game/special_events/halloween 2025.rpy:425
translate spanish halloween_sonya_dream_e953cb07_1:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg_chat "Un cofre.{w} Madera oscura, esquinas reforzadas con metal rojo sangre"

# game/special_events/halloween 2025.rpy:426
translate spanish halloween_sonya_dream_76809b89_1:

    # gg "Что за чёрт . . ."
    gg "Qué demonios. . ."

# game/special_events/halloween 2025.rpy:427
translate spanish halloween_sonya_dream_b5f93453_1:

    # gg_chat "Она не выглядит новой"
    gg_chat "No parece nueva"

# game/special_events/halloween 2025.rpy:428
translate spanish halloween_sonya_dream_5ac4f621_1:

    # gg_chat "Скорее наоборот - как будто ей сотни лет"
    gg_chat "Todo lo contrario: como si tuviera cientos de años"

# game/special_events/halloween 2025.rpy:433
translate spanish halloween_sonya_dream_a96a7298_1:

    # gg "Просто кто-то оставил{w} Мая? Соня?"
    gg "¿Simplemente alguien la dejó? {w}¿Maya? ¿Sonya?"

# game/special_events/halloween 2025.rpy:434
translate spanish halloween_sonya_dream_f60dffa6_1:

    # gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "Es estúpido, pero aun así toco la tapa"

# game/special_events/halloween 2025.rpy:435
translate spanish halloween_sonya_dream_7aa1f899_1:

    # gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    gg_chat "Calidez.{w} Como si bajo los dedos hubiera piel, no madera"

# game/special_events/halloween 2025.rpy:438
translate spanish halloween_sonya_dream_d4c068d1_1:

    # gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg_chat "Dentro hay una moneda. Vieja, desgastada, con un ojo grabado, y los bordes irregulares, como si alguien la hubiera mordido"

# game/special_events/halloween 2025.rpy:439
translate spanish halloween_sonya_dream_891135f2_1:

    # gg "И всё? . . ."
    gg "¿Eso es todo? . . ."

# game/special_events/halloween 2025.rpy:441
translate spanish halloween_sonya_dream_5bbdc303_1:

    # gg "Ладно, пока возьму себе"
    gg "Vale, me la quedo por ahora"

# game/special_events/halloween 2025.rpy:442
translate spanish halloween_sonya_dream_63ba62de_1:

    # gg_chat "Я поворачиваю её в пальцах"
    gg_chat "La giro entre mis dedos"

# game/special_events/halloween 2025.rpy:443
translate spanish halloween_sonya_dream_60e7c398_1:

    # gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    gg_chat "Extraña pesadez, como si la moneda no estuviera hecha de metal, sino de algo vivo"

# game/special_events/halloween 2025.rpy:447
translate spanish halloween_sonya_dream_b51c492c_1:

    # gg "Где же все?"
    gg "¿Dónde están todos?"

# game/special_events/halloween 2025.rpy:452
translate spanish halloween_sonya_dream_867b75aa_1:

    # gg "Чёрт. что за бред телевизор сам включился . . ."
    gg "Maldición. ¿Qué diablos? El televisor se encendió solo. . ."

# game/special_events/halloween 2025.rpy:487
translate spanish halloween_sonya_dream_cfa5487f_1:

    # gg "Что за бред"
    gg "¡Qué tontería!"

# game/special_events/halloween 2025.rpy:488
translate spanish halloween_sonya_dream_6ca44626_1:

    # gg "Нужно проверить остальные комнаты"
    gg "Necesito revisar las otras habitaciones"

# game/special_events/halloween 2025.rpy:491
translate spanish halloween_sonya_dream_3109e8d5_1:

    # gg "Соня?"
    gg "¿Sonya?"

# game/special_events/halloween 2025.rpy:493
translate spanish halloween_sonya_dream_af6b4c99_1:

    # gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    gg "Oye... ya es tarde, me estás asustando, de verdad"

# game/special_vents/halloween 2025.rpy:496
translate spanish halloween_sonya_dream_f09531f9_1:

    # gg "Просто показалось . . ."
    gg "Sólo me lo pareció..."

# game/special_events/halloween 2025.rpy:497
translate spanish halloween_sonya_dream_6fecd311_1:

    # gg "Просто тень . . ."
    gg "Sólo una sombra..."

# game/special_events/halloween 2025.rpy:504
translate spanish halloween_sonya_dream_b989363c_1:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:506
translate spanish halloween_sonya_dream_e5e215bc_1:

    # Sonya "Как ты посмел меня разбудить!" with hpunch
    Sonya "¡Cómo te atreves a despertarme!" with hpunch

# game/special_events/halloween 2025.rpy:508
translate spanish halloween_sonya_dream_cbf79f81_1:

    # gg "Соня, ты . . . {w}ты издеваешься? . . ."
    gg "Sonya, tú... {w}¿Estás bromeando?..."

# game/special_events/halloween 2025.rpy:510
translate spanish halloween_sonya_dream_ea23c51e_1:

    # gg "Это ты? Что это за грёбаные игры? . . ."
    gg "¿Eres tú? ¿Qué diablos son estos juegos?..."

# game/special_events/halloween 2025.rpy:512
translate spanish halloween_sonya_dream_c5bc9963_1:

    # Sonya "Имя звучит знакомо"
    Sonya "El nombre me suena"

# game/special_events/halloween 2025.rpy:513
translate spanish halloween_sonya_dream_4db18375_1:

    # Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    Sonya "Pero la que llamaste murió con esta casa"

# game/special_events/halloween 2025.rpy:514
translate spanish halloween_sonya_dream_f5284849_1:

    # gg "Прекрати . . ."
    gg "Basta..."

# game/special_events/halloween 2025.rpy:516
translate spanish halloween_sonya_dream_bf221ec2_1:

    # Sonya "Дом теперь мой.{w} Я - его хозяин"
    Sonya "La casa ahora es mía.{w} Soy su dueño"

# game/special_events/halloween 2025.rpy:518
translate spanish halloween_sonya_dream_2c4ebaa2_1:

    # Sonya "Боишься?"
    Sonya "¿Tienes miedo?"

# game/special_events/halloween 2025.rpy:519
translate spanish halloween_sonya_dream_0063da0b_1:

    # gg "Да . . ."
    gg "Sí..."

# game/special_events/halloween 2025.rpy:521
translate spanish halloween_sonya_dream_b67571be_1:

    # Sonya "Хорошо"
    Sonya "Bien"

# game/special_events/halloween 2025.rpy:523
translate spanish halloween_sonya_dream_14d503b0_1:

    # Sonya "Страх делает кровь живой"
    Sonya "El miedo hace que la sangre cobre vida"

# game/special_events/halloween 2025.rpy:531
translate spanish halloween_sonya_dream_ab894d3a_1:

    # Sonya "Ты принёс монету?"
    Sonya "¿Trajiste una moneda?"

# game/special_events/halloween 2025.rpy:535
translate spanish halloween_sonya_dream_c3bf29e7_1:

    # gg "Что? . . ."
    gg "¿Qué?..."

# game/special_events/halloween 2025.rpy:537
translate spanish halloween_sonya_dream_52cb176c_1:

    # Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "Un regalo que fue sellado. Lo abriste"

# game/special_events/halloween 2025.rpy:538
translate spanish halloween_sonya_dream_e3369996_1:

    # Sonya "Ты впустил меня"
    Sonya "Me dejaste entrar"

# game/special_events/halloween 2025.rpy:540
translate spanish halloween_sonya_dream_1f166693_1:

    # Sonya "Я не Соня"
    Sonya "No soy Sonya"

# game/special_events/halloween 2025.rpy:544
translate spanish halloween_sonya_dream_86fe7642_1:

    # Sonya "Я та, что носила её лицо"
    Sonya "Yo soy quien llevaba su cara"

# game/special_events/halloween 2025.rpy:545
translate spanish halloween_sonya_dream_625b9f75_1:

    # Sonya "И теперь ты мой"
    Sonya "Y ahora eres mío"

# game/special_events/halloween 2025.rpy:547
translate spanish halloween_sonya_dream_0ac9332f_1:

    # Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    Sonya "Todo lo que temías perder... ya lo tomé"

# game/special_events/halloween 2025.rpy:549
translate spanish halloween_sonya_dream_64ed8507_1:

    # Sonya "А теперь - перестань сопротивляться"
    Sonya "Ahora deja de resistir"

# game/special_events/halloween 2025.rpy:553
translate spanish halloween_sonya_dream_3d7ee945_1:

    # Sonya "Я выжму тебя досуха"
    Sonya "Te exprimiré hasta secarte"

# game/special_events/halloween 2025.rpy:588
translate spanish halloween_maya_dream_032be6f2_1:

    # gg "Чёрт . . . {w}нет, нет, снова это . . ."
    gg "Diablos... {w}no, no, esto de nuevo..."

# game/special_events/halloween 2025.rpy:590
translate spanish halloween_maya_dream_ff7388e6_1:

    # Maya "Эй, спокойно"
    Maya "Oye, cálmate"

# game/special_events/halloween 2025.rpy:592
translate spanish halloween_maya_dream_92686e55_1:

    # Maya "Ты в безопасности"
    Maya "Estás a salvo"

# game/special_events/halloween 2025.rpy:593
translate spanish halloween_maya_dream_edf9349e_1:

    # gg "Где я? . . ."
    gg "¿Dónde estoy?..."

# game/special_events/halloween 2025.rpy:594
translate spanish halloween_maya_dream_de23ff68_1:

    # gg "Что . . . что это за место?"
    gg "¿Qué... qué clase de lugar es este?"

# game/special_events/halloween 2025.rpy:596
translate spanish halloween_maya_dream_75c561e6_1:

    # Maya "Мой дом"
    Maya "Mi casa"

# game/special_events/halloween 2025.rpy:598
translate spanish halloween_maya_dream_912b1ea9_1:

    # gg "Почему . . . я . . . здесь? . . ."
    gg "¿Por qué... yo... aquí?..."

# game/special_events/halloween 2025.rpy:600
translate spanish halloween_maya_dream_05fc8512_1:

    # Maya "Потому что ты боялся"
    Maya "Porque tuviste miedo"

# game/special_events/halloween 2025.rpy:601
translate spanish halloween_maya_dream_657245c6_1:

    # Maya "И кто-то должен был тебя остановить"
    Maya "Y alguien debería haberte detenido"

# game/special_events/halloween 2025.rpy:603
translate spanish halloween_maya_dream_dcba1503_1:

    # gg "Нет . . .{w} не приближайся"
    gg "No...{w} no te acerques"

# game/special_events/halloween 2025.rpy:604
translate spanish halloween_maya_dream_e91592a1_1:

    # gg "Я видел, как это начинается"
    gg "Vi cómo empieza"

# game/special_events/halloween 2025.rpy:605
translate spanish halloween_maya_dream_d9b24014_1:

    # gg "Сначала свет, потом . . ."
    gg "Primero la luz, luego..."

# game/special_events/halloween 2025.rpy:608
translate spanish halloween_maya_dream_23c69478_1:

    # Maya "Никто не собирается тебя пугать"
    Maya "Nadie te va a asustar"

# game/special_events/halloween 2025.rpy:609
translate spanish halloween_maya_dream_fb15da85_1:

    # gg "Это сон?"
    gg "¿Es esto un sueño?"

# game/special_events/halloween 2025.rpy:611
translate spanish halloween_maya_dream_ef47f8b8_1:

    # Maya "Возможно"
    Maya "Tal vez"

# game/special_events/halloween 2025.rpy:612
translate spanish halloween_maya_dream_11e09330_1:

    # Maya "Но в этом сне тебе можно не убегать"
    Maya "Pero en este sueño no tienes que huir"

# game/special_events/halloween 2025.rpy:614
translate spanish halloween_maya_dream_e96ceee2_1:

    # Maya "Сядь.{w} Попробуй просто дышать"
    Maya "Siéntate.{w} Sólo intenta respirar"

# game/special_events/halloween 2025.rpy:615
translate spanish halloween_maya_dream_f1385d77_1:

    # gg "Я . . .{w} не могу"
    gg "Yo...{w} no puedo"

# game/special_events/halloween 2025.rpy:617
translate spanish halloween_maya_dream_38874e86_1:

    # Maya "Можешь{w}, начни только тихо"
    Maya "Puedes{w}, simplemente comienza tranquilamente"

# game/special_events/halloween 2025.rpy:619
translate spanish halloween_maya_dream_4a1eadac_1:

    # Maya "Ты думал, я кто-то другой, да?"
    Maya "Pensaste que era otra persona, ¿verdad?"

# game/special_events/halloween 2025.rpy:621
translate spanish halloween_maya_dream_8d83da3f_1:

    # gg "После всего . . ."
    gg "Después de todo..."

# game/special_events/halloween 2025.rpy:622
translate spanish halloween_maya_dream_9aa85be5_1:

    # gg "Я и не знаю, кому верить"
    gg "No sé a quién creer"

# game/special_events/halloween 2025.rpy:623
translate spanish halloween_maya_dream_95a67e98_1:

    # Maya "Тогда не верь"
    Maya "Entonces no creas"

# game/special_events/halloween 2025.rpy:624
translate spanish halloween_maya_dream_cf12428b_1:

    # Maya "Просто смотри"
    Maya "Sólo mira"

# game/special_events/halloween 2025.rpy:628
translate spanish halloween_maya_dream_5da82532_1:

    # gg "Чувствуешь?{w} Здесь нет боли"
    gg "¿Puedes sentirlo?{w} No hay dolor aquí"

# game/special_events/halloween 2025.rpy:630
translate spanish halloween_maya_dream_df19ec31_1:

    # Maya "Ты дрожишь"
    Maya "Estás temblando"

# game/special_events/halloween 2025.rpy:631
translate spanish halloween_maya_dream_b989363c_2:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:634
translate spanish halloween_maya_dream_718947a3_1:

    # Maya "Бедный"
    Maya "Pobre"

# game/special_events/halloween 2025.rpy:636
translate spanish halloween_maya_dream_20c45a93_1:

    # Maya "Я давно не видела людей"
    Maya "Hace mucho que no veo gente"

# game/special_events/halloween 2025.rpy:638
translate spanish halloween_maya_dream_0f6f1ec4_1:

    # Maya "Вот, видишь?{w} Уже лучше"
    Maya "¿Ves?{w} Ya es mejor"

# game/special_events/halloween 2025.rpy:639
translate spanish halloween_maya_dream_1db499d0_1:

    # gg "Не знаю, что это.{w} Но уже лучше"
    gg "No sé qué es.{w} Pero ya es mejor"

# game/special_events/halloween 2025.rpy:641
translate spanish halloween_maya_dream_927ad5b3_1:

    # Maya "Сейчас кое что тебя поставит на ноги"
    Maya "Ahora algo te pondrá de pie"

# game/special_events/halloween 2025.rpy:644
translate spanish halloween_maya_dream_9add8ae1_1:

    # Maya "Здесь только травы"
    Maya "Aquí sólo hay hierbas"

# game/special_events/halloween 2025.rpy:645
translate spanish halloween_maya_dream_338034af_1:

    # Maya "Лаванда, мята, немного корицы.{w} Попей"
    Maya "Lavanda, menta, un poco de canela.{w} Bebe"

# game/special_events/halloween 2025.rpy:647
translate spanish halloween_maya_dream_8f20081e_1:

    # gg "Что это?"
    gg "¿Qué es esto?"

# game/special_events/halloween 2025.rpy:648
translate spanish halloween_maya_dream_3fdb7032_1:

    # Maya "Это магия"
    Maya "Es magia"

# game/special_events/halloween 2025.rpy:650
translate spanish halloween_maya_dream_7c4cba20_1:

    # Maya "Лечебное зелье, с небольшим побочным эфектом"
    Maya "Poción curativa con efectos secundarios menores"

# game/special_events/halloween 2025.rpy:652
translate spanish halloween_maya_dream_59e469a3_1:

    # gg "Каким еще эфектом"
    gg "¿Qué otro efecto?"

# game/special_events/halloween 2025.rpy:655
translate spanish halloween_maya_dream_809b7a3a_1:

    # Maya "Просто отдохни.{w} Не думай об этом"
    Maya "Simplemente descansa.{w} No lo pienses"

# game/special_events/halloween 2025.rpy:657
translate spanish halloween_maya_dream_ae92cf27_1:

    # gg "А если я снова усну?"
    gg "¿Qué pasa si me vuelvo a dormir?"

# game/special_events/halloween 2025.rpy:659
translate spanish halloween_maya_dream_c1fe7b6b_1:

    # Maya "Тогда пусть этот сон, будет приятным"
    Maya "Entonces deja que este sueño sea placentero"

# game/special_events/halloween 2025.rpy:683
translate spanish halloween_maya_dream_b989363c_3:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:684
translate spanish halloween_maya_dream_5174a63c_1:

    # gg "Приснится же такое . . ."
    gg "Vaya sueño..."

# game/special_events/halloween 2025.rpy:686
translate spanish halloween_maya_dream_13dee7c8_1:

    # "Тыква хранит воспоминания"
    "La calabaza guarda recuerdos"

# game/special_events/halloween 2025.rpy:687
translate spanish halloween_maya_dream_bb8e42de_1:

    # "Коснись её, чтобы вновь увидеть сцену"
    "Tócala para volver a ver la escena"

translate spanish strings:

    # game/special_events/halloween 2025.rpy:8
    old "Сначала"
    new "Primero"

    # game/special_events/halloween 2025.rpy:10
    old "Сон с Соней"
    new "Sueño con Sonya"

    # game/special_events/halloween 2025.rpy:14
    old "Сон с Маей"
    new "Sueño con Maya"

# TODO: Translation updated at 2026-01-26 03:23

# game/special_events/halloween 2025.rpy:28
translate spanish halloween_prestart_6dc15a83:

    # gg "Хм . . ."
    gg "Hmm . . ."

# game/special_events/halloween 2025.rpy:29
translate spanish halloween_prestart_3173d374:

    # gg "А что это еще такое?"
    gg "¿Y esto qué es?"

# game/special_events/halloween 2025.rpy:30
translate spanish halloween_prestart_9d6bd7cd:

    # gg "Эта тыква будто манит меня дотронуться до нее"
    gg "Esta calabaza parece invitarme a tocarla"

# game/special_events/halloween 2025.rpy:32
translate spanish halloween_prestart_6b235c12:

    # gg "Вроде ничего не случилось"
    gg "Parece que no pasó nada"

# game/special_events/halloween 2025.rpy:33
translate spanish halloween_prestart_99b702cc:

    # gg "Просто обычная тыква"
    gg ""

# game/special_events/halloween 2025.rpy:34
translate spanish halloween_prestart_882ef6af:

    # gg "Так не интересно"
    gg "Qué aburrido"

# game/special_events/halloween 2025.rpy:38
translate spanish halloween_prestart_2eb26325:

    # gg "Ай!" with hpunch
    gg "¡Ay!" with hpunch

# game/special_events/halloween 2025.rpy:39
translate spanish halloween_prestart_b858f49b:

    # gg "Почему так щипет"
    gg "¿Por qué pica tanto?"

# game/special_events/halloween 2025.rpy:40
translate spanish halloween_prestart_eb8d9b68:

    # gg "Что то мне не хорошо"
    gg "Me siento mal"

# game/special_events/halloween 2025.rpy:41
translate spanish halloween_prestart_462beaf3:

    # gg "Пойду отдохну"
    gg "Iré a descansar"

# game/special_events/halloween 2025.rpy:50
translate spanish halloween_start_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/special_events/halloween 2025.rpy:52
translate spanish halloween_start_2768572c:

    # Sonya "Знаешь, что я поняла?"
    Sonya "¿Sabes de qué me di cuenta?"

# game/special_events/halloween 2025.rpy:53
translate spanish halloween_start_b99b94d3:

    # gg "Что пора поспать?"
    gg "¿Que es hora de dormir?"

# game/special_events/halloween 2025.rpy:55
translate spanish halloween_start_73751dc8:

    # Sonya "Что пора украшать дом"
    Sonya "Que es hora de decorar la casa"

# game/special_events/halloween 2025.rpy:57
translate spanish halloween_start_2efbd354:

    # gg "Украшать?"
    gg "¿Decorar?"

# game/special_events/halloween 2025.rpy:59
translate spanish halloween_start_baa9dc02:

    # Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    Sonya "Tenemos Halloween en 2 días y la atmósfera es cero"

# game/special_events/halloween 2025.rpy:61
translate spanish halloween_start_d64dca0a:

    # Sonya "Я хочу, чтобы всё выглядело"
    Sonya "Quiero que todo se vea..."

# game/special_events/halloween 2025.rpy:63
translate spanish halloween_start_c1524153:

    # Sonya "Хотя бы немного празднично"
    Sonya "Al menos un poco festivo"

# game/special_events/halloween 2025.rpy:65
translate spanish halloween_start_c4c69fc7:

    # Maya "Украшать?{w} Пора бы да"
    Maya "¿Decorar?{w} Ya era hora, sí"

# game/special_events/halloween 2025.rpy:67
translate spanish halloween_start_f5a85bf6:

    # Maya "Можно повесить гирлянды и поставить свечи!"
    Maya "¡Podemos colgar guirnaldas y poner velas!"

# game/special_events/halloween 2025.rpy:69
translate spanish halloween_start_88ab11a7:

    # Sonya "Вот. Поддержка есть"
    Sonya "Ves. Tengo apoyo"

# game/special_events/halloween 2025.rpy:71
translate spanish halloween_start_f2b19d78:

    # gg "Видимо у меня нет выбора"
    gg "Parece que no tengo elección"

# game/special_events/halloween 2025.rpy:73
translate spanish halloween_start_bc7a61df:

    # Maya "Ты просто устал, тебе нужно отвлечься"
    Maya "Solo estás cansado, necesitas distraerte"

# game/special_events/halloween 2025.rpy:75
translate spanish halloween_start_06d0d58b:

    # Sonya "Вот именно"
    Sonya "Exactamente"

# game/special_events/halloween 2025.rpy:77
translate spanish halloween_start_041234b8:

    # Sonya "Украшение дома - лучший антистресс"
    Sonya "Decorar la casa es el mejor antiestrés"

# game/special_events/halloween 2025.rpy:79
translate spanish halloween_start_c578bb24:

    # Maya "Тогда решено"
    Maya "Entonces, decidido"

# game/special_events/halloween 2025.rpy:80
translate spanish halloween_start_6e15e900:

    # Maya "Начнём с гостиной"
    Maya "Empecemos por el salón"

# game/special_events/halloween 2025.rpy:82
translate spanish halloween_start_d298f1fa:

    # Maya "Я за уют, но без перебора"
    Maya "Me gusta la comodidad, pero sin exagerar"

# game/special_events/halloween 2025.rpy:84
translate spanish halloween_start_2a522c28:

    # Sonya "Надо позвать Кейт"
    Sonya "Hay que llamar a Kate"

# game/special_events/halloween 2025.rpy:85
translate spanish halloween_start_20197ce8:

    # Sonya "Без неё всё равно не обойдётся"
    Sonya "De todas formas, no saldrá bien sin ella"

# game/special_events/halloween 2025.rpy:87
translate spanish halloween_start_bcecc811:

    # Maya "Я напишу ей"
    Maya "Le escribiré"

# game/special_events/halloween 2025.rpy:88
translate spanish halloween_start_81baf5ad:

    # Maya "Если не занята, придёт"
    Maya "Si no está ocupada, vendrá"

# game/special_events/halloween 2025.rpy:90
translate spanish halloween_start_4a4b3e1e:

    # Sonya "Пойдем поможешь мне"
    Sonya "Ven, ayúdame"

# game/special_events/halloween 2025.rpy:92
translate spanish halloween_start_082fbdc3:

    # Sonya "У нас в кладовке чего только нету"
    Sonya "Tenemos de todo en el trastero"

# game/special_events/halloween 2025.rpy:94
translate spanish halloween_start_569f8605:

    # Sonya "Осторожно, она тяжёлая"
    Sonya "Cuidado, es pesada"

# game/special_events/halloween 2025.rpy:98
translate spanish halloween_start_08a41431:

    # gg "Не волнуйся, я пока справляюсь"
    gg "No te preocupes, de momento voy bien"

# game/special_events/halloween 2025.rpy:100
translate spanish halloween_start_2ee9b67e:

    # Maya "Написала, сказала, что уже бежит"
    Maya "Le escribí, dice que ya viene corriendo"

# game/special_events/halloween 2025.rpy:102
translate spanish halloween_start_56e25c3d:

    # Sonya "Это хорошо"
    Sonya "Eso es bueno"

# game/special_events/halloween 2025.rpy:104
translate spanish halloween_start_cc205380:

    # Maya "О, смотри, старая паутина!"
    Maya "¡Oh, mira, una telaraña vieja!"

# game/special_events/halloween 2025.rpy:106
translate spanish halloween_start_6d122aa8:

    # Sonya "Это не декор, не трогай!"
    Sonya "¡Eso no es decoración, no la toques!"

# game/special_events/halloween 2025.rpy:108
translate spanish halloween_start_1c832081:

    # Maya "Ты же знаешь я боюсь пауков!"
    Maya "¡Sabes que les tengo miedo a las arañas!"

# game/special_events/halloween 2025.rpy:109
translate spanish halloween_start_e8c9fd97:

    # gg "Ха ха"
    gg "Ja ja"

# game/special_events/halloween 2025.rpy:114
translate spanish halloween_start_5c8cb7fa:

    # Kate "Я пришла"
    Kate "Ya llegué"

# game/special_events/halloween 2025.rpy:115
translate spanish halloween_start_5cba982d:

    # Kate "Где вы, мои маленькие смертные?"
    Kate "¿Dónde estáis, mis pequeños mortales?"

# game/special_events/halloween 2025.rpy:116
translate spanish halloween_start_66671892:

    # Maya "Привет!"
    Maya "¡Hola!"

# game/special_events/halloween 2025.rpy:118
translate spanish halloween_start_41cac97b:

    # Kate "О, вы уже начали без меня?{w} Это предательство"
    Kate "Oh, ¿ya empezasteis sin mí?{w} Esto es una traición"

# game/special_events/halloween 2025.rpy:120
translate spanish halloween_start_3f833e29:

    # Maya "Мы только подготовились"
    Maya "Apenas nos hemos preparado"

# game/special_events/halloween 2025.rpy:122
translate spanish halloween_start_10a24600:

    # Sonya "Отлично, теперь можем начинать по-настоящему"
    Sonya "Genial, ahora podemos empezar de verdad"

# game/special_events/halloween 2025.rpy:124
translate spanish halloween_start_59716300:

    # Maya "Всё, распределяем задачи?"
    Maya "Bueno, ¿repartimos las tareas?"

# game/special_events/halloween 2025.rpy:126
translate spanish halloween_start_c6287aa3:

    # Kate "Так эту куклу повесим вон там, над теликом"
    Kate "Pues colguemos esta muñeca allá, sobre el televisor"

# game/special_events/halloween 2025.rpy:127
translate spanish halloween_start_ddd8aded:

    # Kate "Еще нужны паутины, гирлянда из флажков, черепа . . ."
    Kate "También necesitamos telarañas, una guirnalda de banderines, calaveras. . ."

# game/special_events/halloween 2025.rpy:129
translate spanish halloween_start_c1c2f306:

    # Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    Maya "¿Entonces en mi habitación nos ahorramos las decoraciones espeluznantes?"

# game/special_events/halloween 2025.rpy:131
translate spanish halloween_start_344d78c3:

    # gg "Ну это же Хэллоуин, а чем ты?"
    gg "Bueno, es Halloween, ¿y tú qué?"

# game/special_events/halloween 2025.rpy:133
translate spanish halloween_start_7e9f8506:

    # Sonya "Мая просто трусишка"
    Sonya "Maya es solo una miedosa"

# game/special_events/halloween 2025.rpy:135
translate spanish halloween_start_423eeb13:

    # Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "¡¡EY!! ¡Es que lo encuentro estúpido!"

# game/special_events/halloween 2025.rpy:136
translate spanish halloween_start_1c4935b1:

    # Maya "Можно сделать дом тёплым, как осень!"
    Maya "¡Podemos hacer la casa acogedora, como el otoño!"

# game/special_events/halloween 2025.rpy:137
translate spanish halloween_start_5acb8aac:

    # Maya "Листья и природу . . . И без жути . . ."
    Maya "Hojas y naturaleza. . . Y sin sustos. . ."

# game/special_events/halloween 2025.rpy:139
translate spanish halloween_start_9d95e4f7:

    # Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    Kate "Y yo quiero que dé tanto miedo que los niños del vecindario chillen de terror si se atreven a llamar a nuestra puerta"

# game/special_events/halloween 2025.rpy:141
translate spanish halloween_start_97fa9b09:

    # Sonya "Звучит как цель"
    Sonya "Suena como un objetivo"

# game/special_events/halloween 2025.rpy:143
translate spanish halloween_start_7a0152d7:

    # Maya "Надеюсь, что все пройдет без происшествий"
    Maya "Espero que todo transcurra sin incidentes"

# game/special_events/halloween 2025.rpy:145
translate spanish halloween_start_cd410fe4:

    # gg "Ну что же, давайте постараемся"
    gg "Bueno, pues esforcémonos"

# game/special_events/halloween 2025.rpy:153
translate spanish halloween_start_e7148dd7:

    # Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    Maya "¿Sabéis? No está tan mal, incluso es bastante bonito y acogedor"

# game/special_events/halloween 2025.rpy:155
translate spanish halloween_start_4203fcb3:

    # Kate "ДА! Вышло супер, мы такие молодцы"
    Kate "¡SÍ! Ha quedado genial, somos unos cracks"

# game/special_events/halloween 2025.rpy:157
translate spanish halloween_start_3c177eb8:

    # Sonya "Давайте дальше украсим кухню!"
    Sonya "¡Vamos a decorar la cocina ahora!"

# game/special_events/halloween 2025.rpy:158
translate spanish halloween_start_3fc97c96:

    # Sonya "[povname] хватай коробки с украшениями!"
    Sonya "[povname] ¡coge las cajas con los adornos!"

# game/special_events/halloween 2025.rpy:167
translate spanish halloween_start_c18a0daf:

    # Maya "Ну почему я должна ее вешать?"
    Maya "Bueno, ¿por qué tengo que colgarla yo?"

# game/special_events/halloween 2025.rpy:169
translate spanish halloween_start_538416e3:

    # Kate "Потому что ты самая высокая, это же логично!"
    Kate "¡Porque eres la más alta, es lógico!"

# game/special_events/halloween 2025.rpy:171
translate spanish halloween_start_fac78089:

    # Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    Maya "Puaj. No les tengo miedo a las arañas, es que son asquerosas, me dan repelús"

# game/special_events/halloween 2025.rpy:173
translate spanish halloween_start_196b4d6a:

    # gg "Тыкву тоже поставь на полку"
    gg "Pon la calabaza en el estante también"

# game/special_events/halloween 2025.rpy:182
translate spanish halloween_start_3ee05b57:

    # Maya "АААААААААА!" with hpunch
    Maya "¡¡¡AAAAAAAAAA!!!" with hpunch

# game/special_events/halloween 2025.rpy:186
translate spanish halloween_start_7410244b:

    # gg "Все, я убрал, не бойся, он же не настоящий"
    gg "Ya está, lo quité, no tengas miedo, no es de verdad"

# game/special_events/halloween 2025.rpy:188
translate spanish halloween_start_1ceba70d:

    # Maya "Спасибо"
    Maya "Gracias"

# game/special_events/halloween 2025.rpy:190
translate spanish halloween_start_5375f0ad:

    # gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    gg "Caes en mis brazos con demasiada frecuencia, ¿no lo harás a propósito?"

# game/special_events/halloween 2025.rpy:192
translate spanish halloween_start_ccd7999c:

    # Maya "Еще чего!"
    Maya "¡Qué va!"

# game/special_events/halloween 2025.rpy:193
translate spanish halloween_start_c938832e:

    # Maya "Ты просто мешаешься на пути, вот и все!"
    Maya "¡Es que te pones en medio, eso es todo!"

# game/special_events/halloween 2025.rpy:194
translate spanish halloween_start_5807bf69:

    # Kate "Не поранились? Голубки"
    Kate "¿No os habéis hecho daño? Tortolitas"

# game/special_events/halloween 2025.rpy:196
translate spanish halloween_start_180bf5f1:

    # Maya "Все с паутиной мы закончили"
    Maya "Hemos terminado con la telaraña"

# game/special_events/halloween 2025.rpy:197
translate spanish halloween_start_62eaed17:

    # Maya "Пойду возьму яблочного сидра"
    Maya "Voy a por sidra de manzana"

# game/special_events/halloween 2025.rpy:203
translate spanish halloween_start_6a9d122d:

    # Sonya "Еще 5 минут и кексы готовы"
    Sonya "5 minutos más y las magdalenas estarán listas"

# game/special_events/halloween 2025.rpy:205
translate spanish halloween_start_92462f90:

    # Kate "Пахнет потрясающе"
    Kate "Huele increíble"

# game/special_events/halloween 2025.rpy:207
translate spanish halloween_start_ada25b4b:

    # Maya "Всё, теперь осталось только подождать"
    Maya "Listo, ahora solo queda esperar"

# game/special_events/halloween 2025.rpy:208
translate spanish halloween_start_4ac68531:

    # Maya "Потом будем украшать"
    Maya "Luego decoraremos"

# game/special_events/halloween 2025.rpy:210
translate spanish halloween_start_7d203e0d:

    # Kate "Эй а кем вы будете в ночь Хэллоуина?"
    Kate "Oye, ¿y vosotros de qué vais a ir la noche de Halloween?"

# game/special_events/halloween 2025.rpy:212
translate spanish halloween_start_3e0fd7f3:

    # Sonya "Я уже думала об этом!"
    Sonya "¡Ya había pensado en eso!"

# game/special_events/halloween 2025.rpy:213
translate spanish halloween_start_21be6b25:

    # Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    Sonya "Mmm, Kate, un disfraz de demonio te quedaría bien"

# game/special_events/halloween 2025.rpy:215
translate spanish halloween_start_8fc9e335:

    # Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    Maya "Por cierto, sí, aunque pareces un angelito, eres astuta como un duende doméstico"

# game/special_events/halloween 2025.rpy:217
translate spanish halloween_start_6485ec70:

    # Kate "Эй!! Неплохая идея"
    Kate "¡¡Oye!! No es una mala idea"

# game/special_events/halloween 2025.rpy:221
translate spanish halloween_start_9ea771a0:

    # Kate "Королева демонов Уахахахаха!"
    Kate "¡La Reina de los Demonios, Wahahahaha!"

# game/special_events/halloween 2025.rpy:222
translate spanish halloween_start_dfa5392d:

    # Kate "Все должны пасть к моим ногам!"
    Kate "¡Todos deben caer a mis pies!"

# game/special_events/halloween 2025.rpy:224
translate spanish halloween_start_d1a70744:

    # Sonya "Все, ей больше не наливать!"
    Sonya "¡Basta, que no le sirvan más!"

# game/special_events/halloween 2025.rpy:226
translate spanish halloween_start_67a78ead:

    # gg "Не знал что Кейт так быстро выносит с алкоголя"
    gg "No sabía que el alcohol le afectaba tan rápido a Kate"

# game/special_events/halloween 2025.rpy:228
translate spanish halloween_start_89e99062:

    # Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    Maya "Me gustaría un disfraz de brujita o de alguna dríada mágica. . ."

# game/special_events/halloween 2025.rpy:230
translate spanish halloween_start_ccfee06e:

    # Kate "Думаю тебе пойдет"
    Kate "Creo que te quedará bien"

# game/special_events/halloween 2025.rpy:232
translate spanish halloween_start_8e96eaa2:

    # Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    Sonya "Y el otro día pedí 6 paquetes de vendas en lugar de 1, ¿parece una señal para hacer un disfraz de momia?"

# game/special_events/halloween 2025.rpy:234
translate spanish halloween_start_2aa5e0fb:

    # Maya "Ты как раз самая старшая"
    Maya "Resulta que eres la mayor"

# game/special_events/halloween 2025.rpy:236
translate spanish halloween_start_38bc2712:

    # Sonya "Ах ты!"
    Sonya "¡Ah, tú!"

# game/special_events/halloween 2025.rpy:238
translate spanish halloween_start_5d38e441:

    # Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "Espera, ¿y el gato? ¡Él también necesita un disfraz!"

# game/special_events/halloween 2025.rpy:239
translate spanish halloween_start_fb608953:

    # Maya "Например дракончика или мистер тыковка . . ."
    Maya "Por ejemplo, un dragoncito o un Señor Calabaza. . ."

# game/special_events/halloween 2025.rpy:241
translate spanish halloween_start_7fd69d94:

    # Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    Sonya "¡Intenta atraparlo y disfrazarlo, el Señor Barsik no se dejará!"

# game/special_events/halloween 2025.rpy:243
translate spanish halloween_start_70adb582:

    # Maya "Что ты . . . {w}Он любит переодевашки"
    Maya "Qué dices. . . {w}A él le encanta disfrazarse"

# game/special_events/halloween 2025.rpy:246
translate spanish halloween_start_c0036cba:

    # Sonya "Вот и кексы готовы"
    Sonya "Ya están listos los cupcakes"

# game/special_events/halloween 2025.rpy:248
translate spanish halloween_start_ae45c746:

    # gg "С кухней готово, что дальше?"
    gg "La cocina está lista, ¿qué sigue?"

# game/special_events/halloween 2025.rpy:249
translate spanish halloween_start_354f0704:

    # Sonya "Предлагаю разделиться"
    Sonya "Sugiero que nos dividamos"

# game/special_events/halloween 2025.rpy:250
translate spanish halloween_start_07a07420:

    # Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "Maya y yo decoraremos nuestras habitaciones, Kate, ¿tú decorarás el baño?"

# game/special_events/halloween 2025.rpy:251
translate spanish halloween_start_4e86ac78:

    # Sonya "[povname], будешь помогать нам?"
    Sonya "[povname], ¿nos ayudarás?"

# game/special_events/halloween 2025.rpy:252
translate spanish halloween_start_564e6225:

    # gg "Окей"
    gg "Vale"

# game/special_events/halloween 2025.rpy:263
translate spanish halloween_prepare_mayaroom_7afc2c47:

    # gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "Tienes aquí una auténtica guarida de bruja que prepara pociones con hierbas"

# game/special_events/halloween 2025.rpy:264
translate spanish halloween_prepare_mayaroom_63c64e7b:

    # gg "Мм. . . пахнет приятно"
    gg "Mmm. . . huele bien"

# game/special_events/halloween 2025.rpy:266
translate spanish halloween_prepare_mayaroom_1ca099b7:

    # Maya "Хватит нюхать женскую комнату!"
    Maya "¡Deja de olfatear la habitación de las chicas!"

# game/special_events/halloween 2025.rpy:268
translate spanish halloween_prepare_mayaroom_eded9518:

    # Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "Sólo estás aquí para seguir mis órdenes"

# game/special_events/halloween 2025.rpy:269
translate spanish halloween_prepare_mayaroom_799aa249:

    # Maya "Поставь эти тыквы в тот угол!"
    Maya "¡Pon esas calabazas en esa esquina!"

# game/special_events/halloween 2025.rpy:271
translate spanish halloween_prepare_mayaroom_292858b8:

    # gg "А где пожалуйста?"
    gg "¿Dónde, por favor?"

# game/special_events/halloween 2025.rpy:273
translate spanish halloween_prepare_mayaroom_ad71fbb0:

    # Maya "Пожалуйста, не беси меня"
    Maya "Por favor, no me enfurezcas"

# game/special_events/halloween 2025.rpy:275
translate spanish halloween_prepare_mayaroom_63b60e81:

    # gg "Ох"
    gg "Oh"

# game/special_events/halloween 2025.rpy:277
translate spanish halloween_prepare_mayaroom_977c102e:

    # Maya "Мм. . . нет!"
    Maya "Mmm. . . ¡No!"

# game/special_events/halloween 2025.rpy:279
translate spanish halloween_prepare_mayaroom_9cb8ca98:

    # Maya "Выглядит недостаточно хорошо!"
    Maya "¡No se ve lo suficientemente bien!"

# game/special_events/halloween 2025.rpy:281
translate spanish halloween_prepare_mayaroom_3b7bbda5:

    # Maya "Давай лучше в тот угол!"
    Maya "¡Mejor pongámoslas en esa otra esquina!"

# game/special_events/halloween 2025.rpy:283
translate spanish halloween_prepare_mayaroom_f714e642:

    # gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    gg "Decide primero exactamente dónde, para que no tenga que cargar estas calabazas cien veces"

# game/special_events/halloween 2025.rpy:285
translate spanish halloween_prepare_mayaroom_a2933c08:

    # Maya "Говорю же туда неси!"
    Maya "¡Te estoy diciendo que las lleves allí!"

# game/special_events/halloween 2025.rpy:287
translate spanish halloween_prepare_mayaroom_4c580716:

    # gg "Точно?"
    gg "¿Seguro?"

# game/special_events/halloween 2025.rpy:288
translate spanish halloween_prepare_mayaroom_fccb4de7:

    # gg "Я больше двигать не буду, подумай хорошо"
    gg "No las moveré más, piénsalo bien"

# game/special_events/halloween 2025.rpy:290
translate spanish halloween_prepare_mayaroom_4aa933c6:

    # Maya "Хотя как сейчас тоже неплохо . . ."
    Maya "Aunque tal como están ahora tampoco está mal. . ."

# game/special_events/halloween 2025.rpy:292
translate spanish halloween_prepare_mayaroom_b2b57087:

    # Maya "Все ты свободен!"
    Maya "¡Ya estás libre!"

# game/special_events/halloween 2025.rpy:294
translate spanish halloween_prepare_mayaroom_04c6c53d:

    # gg "Спасибо"
    gg "Gracias"

# game/special_events/halloween 2025.rpy:295
translate spanish halloween_prepare_mayaroom_dad56d9b:

    # Maya "Если что еще позову"
    Maya "Si necesito algo más, te llamaré"

# game/special_events/halloween 2025.rpy:297
translate spanish halloween_prepare_mayaroom_6a8ac153:

    # Maya "Все Давай, давай, живее!!"
    Maya "¡Vamos, vamos, más rápido!!"

# game/special_events/halloween 2025.rpy:310
translate spanish halloween_prepare_sonyaroom_b708d644:

    # Sonya "Ой" with hpunch
    Sonya "Ay" with hpunch

# game/special_events/halloween 2025.rpy:312
translate spanish halloween_prepare_sonyaroom_4b100306:

    # Sonya "Добро пожаловать в мою обитель!"
    Sonya "¡Bienvenido a mi morada!"

# game/special_events/halloween 2025.rpy:314
translate spanish halloween_prepare_sonyaroom_7fb491df:

    # gg "У тебя в стиле майнкрафта все, очень милая комната"
    gg "Todo está al estilo Minecraft, es una habitación muy bonita"

# game/special_events/halloween 2025.rpy:316
translate spanish halloween_prepare_sonyaroom_9dc8d94c:

    # Sonya "Да, у меня много игрушек осталось"
    Sonya "Sí, me quedan muchos juguetes"

# game/special_events/halloween 2025.rpy:317
translate spanish halloween_prepare_sonyaroom_1174b034:

    # gg "Чем то тебе помочь?"
    gg "¿Te ayudo en algo?"

# game/special_events/halloween 2025.rpy:319
translate spanish halloween_prepare_sonyaroom_36233e2b:

    # Sonya "О можешь пожалуйста разложить остальные блоки"
    Sonya "Oh, ¿podrías colocar los bloques restantes, por favor?"

# game/special_events/halloween 2025.rpy:321
translate spanish halloween_prepare_sonyaroom_51e25d01:

    # gg "Хорошо давай"
    gg "Vale, vamos"

# game/special_events/halloween 2025.rpy:325
translate spanish halloween_prepare_sonyaroom_5b80a77c:

    # Sonya "Так это сюда"
    Sonya "Entonces esto va aquí"

# game/special_events/halloween 2025.rpy:331
translate spanish halloween_prepare_sonyaroom_5e22d509:

    # Sonya "О забыла я же еще кексов поставила"
    Sonya "Oh, lo olvidé, también puse más cupcakes"

# game/special_events/halloween 2025.rpy:340
translate spanish halloween_prepare_bathroom_5d6a2459:

    # gg "Тук-Тук, к вам можно?"
    gg "Toc-toc, ¿se puede pasar?"

# game/special_events/halloween 2025.rpy:342
translate spanish halloween_prepare_bathroom_f77e9ebe:

    # Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "Oh, llegas justo a tiempo, justo iba a llamarte, quiero colgar un fantasma sobre la bañera"

# game/special_events/halloween 2025.rpy:343
translate spanish halloween_prepare_bathroom_65af0236:

    # Kate "Но не достаю, вот"
    Kate "Pero no llego, mira"

# game/special_events/halloween 2025.rpy:345
translate spanish halloween_prepare_bathroom_b38aeb93:

    # Kate "Вот, видишь?"
    Kate "¿Ves?"

# game/special_events/halloween 2025.rpy:347
translate spanish halloween_prepare_bathroom_e0f0e638:

    # Kate "Хм . . . а если я встану на бортики ванной?"
    Kate "Mmm. . . ¿y si me pongo de pie en el borde de la bañera?"

# game/special_events/halloween 2025.rpy:349
translate spanish halloween_prepare_bathroom_e11f6927:

    # gg "Стой, это не безопасно"
    gg "Para, eso no es seguro"

# game/special_events/halloween 2025.rpy:358
translate spanish halloween_prepare_bathroom_01550c8f:

    # Kate "ААй!" with hpunch
    Kate "¡Ay!" with hpunch

# game/special_events/halloween 2025.rpy:359
translate spanish halloween_prepare_bathroom_af26ae75:

    # Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    Kate "Oh, estoy demasiado borracha, qué bueno que estabas cerca, gracias"

# game/special_events/halloween 2025.rpy:361
translate spanish halloween_prepare_bathroom_78e2854b:

    # gg "Я так испугался за тебя"
    gg "Me asusté mucho por ti"

# game/special_events/halloween 2025.rpy:362
translate spanish halloween_prepare_bathroom_766703c6:

    # gg "За тобой глаз, да глаз, будь аккуратнее"
    gg "Hay que tener mucho cuidado contigo, ten más cuidado"

# game/special_events/halloween 2025.rpy:364
translate spanish halloween_prepare_bathroom_ef29b55b:

    # Kate "Хорошо, я обещаю . . ."
    Kate "Vale, lo prometo. . ."

# game/special_events/halloween 2025.rpy:366
translate spanish halloween_prepare_bathroom_61bd7d2f:

    # Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    Kate "¿Quizás ya podrías soltarme? No volveré a intentarlo"

# game/special_events/halloween 2025.rpy:368
translate spanish halloween_prepare_bathroom_77a74e82:

    # gg "Ты такая легкая"
    gg "Eres tan ligera"

# game/special_events/halloween 2025.rpy:370
translate spanish halloween_prepare_bathroom_a0e2f8bb:

    # Kate "Спасибо"
    Kate "Gracias"

# game/special_events/halloween 2025.rpy:383
translate spanish halloween_prepare_myroom_5692ba1f:

    # gg "Эх устал я помогать всем девочкам, и так спать хотел"
    gg "Ay, estoy cansado de ayudar a todas las chicas, y ya quería dormir"

# game/special_events/halloween 2025.rpy:385
translate spanish halloween_prepare_myroom_6e92de75:

    # gg "Думаю посплю часик"
    gg "Creo que dormiré una horita"

# game/special_events/halloween 2025.rpy:400
translate spanish halloween_sonya_dream_8c6442c7:

    # gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "Me despierto por un sonido extraño, como si alguien hubiera arrastrado una uña por la madera"

# game/special_events/halloween 2025.rpy:401
translate spanish halloween_sonya_dream_a05b8801:

    # gg_chat "Это на кухне?"
    gg_chat "¿Está en la cocina?"

# game/special_events/halloween 2025.rpy:403
translate spanish halloween_sonya_dream_514bb7b5:

    # gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "Salgo a la cocina frotándome los ojos"

# game/special_events/halloween 2025.rpy:404
translate spanish halloween_sonya_dream_045482c0:

    # gg_chat "На столе - что-то, чего там не было"
    gg_chat "Sobre la mesa hay algo que antes no estaba"

# game/special_events/halloween 2025.rpy:405
translate spanish halloween_sonya_dream_e953cb07:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg_chat "Un cofre.{w} Madera oscura, esquinas reforzadas con metal rojo sangre"

# game/special_events/halloween 2025.rpy:406
translate spanish halloween_sonya_dream_76809b89:

    # gg "Что за чёрт . . ."
    gg "Qué demonios. . ."

# game/special_events/halloween 2025.rpy:407
translate spanish halloween_sonya_dream_b5f93453:

    # gg_chat "Она не выглядит новой"
    gg_chat "No parece nueva"

# game/special_events/halloween 2025.rpy:408
translate spanish halloween_sonya_dream_5ac4f621:

    # gg_chat "Скорее наоборот - как будто ей сотни лет"
    gg_chat "Todo lo contrario: como si tuviera cientos de años"

# game/special_events/halloween 2025.rpy:413
translate spanish halloween_sonya_dream_a96a7298:

    # gg "Просто кто-то оставил{w} Мая? Соня?"
    gg "¿Simplemente alguien la dejó? {w}¿Maya? ¿Sonya?"

# game/special_events/halloween 2025.rpy:414
translate spanish halloween_sonya_dream_f60dffa6:

    # gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "Es estúpido, pero aun así toco la tapa"

# game/special_events/halloween 2025.rpy:415
translate spanish halloween_sonya_dream_7aa1f899:

    # gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    gg_chat "Calidez.{w} Como si bajo los dedos hubiera piel, no madera"

# game/special_events/halloween 2025.rpy:418
translate spanish halloween_sonya_dream_d4c068d1:

    # gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg_chat "Dentro hay una moneda. Vieja, desgastada, con un ojo grabado, y los bordes irregulares, como si alguien la hubiera mordido"

# game/special_events/halloween 2025.rpy:419
translate spanish halloween_sonya_dream_891135f2:

    # gg "И всё? . . ."
    gg "¿Eso es todo? . . ."

# game/special_events/halloween 2025.rpy:421
translate spanish halloween_sonya_dream_5bbdc303:

    # gg "Ладно, пока возьму себе"
    gg "Vale, me la quedo por ahora"

# game/special_events/halloween 2025.rpy:422
translate spanish halloween_sonya_dream_63ba62de:

    # gg_chat "Я поворачиваю её в пальцах"
    gg_chat "La giro entre mis dedos"

# game/special_events/halloween 2025.rpy:423
translate spanish halloween_sonya_dream_60e7c398:

    # gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    gg_chat "Extraña pesadez, como si la moneda no estuviera hecha de metal, sino de algo vivo"

# game/special_events/halloween 2025.rpy:427
translate spanish halloween_sonya_dream_b51c492c:

    # gg "Где же все?"
    gg "¿Dónde están todos?"

# game/special_events/halloween 2025.rpy:432
translate spanish halloween_sonya_dream_867b75aa:

    # gg "Чёрт. что за бред телевизор сам включился . . ."
    gg "Maldición. ¿Qué diablos? El televisor se encendió solo. . ."

# game/special_events/halloween 2025.rpy:467
translate spanish halloween_sonya_dream_cfa5487f:

    # gg "Что за бред"
    gg "¡Qué tontería!"

# game/special_events/halloween 2025.rpy:468
translate spanish halloween_sonya_dream_6ca44626:

    # gg "Нужно проверить остальные комнаты"
    gg "Necesito revisar las otras habitaciones"

# game/special_events/halloween 2025.rpy:471
translate spanish halloween_sonya_dream_3109e8d5:

    # gg "Соня?"
    gg "¿Sonya?"

# game/special_events/halloween 2025.rpy:473
translate spanish halloween_sonya_dream_af6b4c99:

    # gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    gg "Oye... ya es tarde, me estás asustando, de verdad"

# game/special_events/halloween 2025.rpy:476
translate spanish halloween_sonya_dream_f09531f9:

    # gg "Просто показалось . . ."
    gg "Sólo me lo pareció..."

# game/special_events/halloween 2025.rpy:477
translate spanish halloween_sonya_dream_6fecd311:

    # gg "Просто тень . . ."
    gg "Sólo una sombra..."

# game/special_events/halloween 2025.rpy:484
translate spanish halloween_sonya_dream_b989363c:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:486
translate spanish halloween_sonya_dream_e5e215bc:

    # Sonya "Как ты посмел меня разбудить!" with hpunch
    Sonya "¡Cómo te atreves a despertarme!" with hpunch

# game/special_events/halloween 2025.rpy:488
translate spanish halloween_sonya_dream_cbf79f81:

    # gg "Соня, ты . . . {w}ты издеваешься? . . ."
    gg "Sonya, tú... {w}¿Estás bromeando?..."

# game/special_events/halloween 2025.rpy:490
translate spanish halloween_sonya_dream_ea23c51e:

    # gg "Это ты? Что это за грёбаные игры? . . ."
    gg "¿Eres tú? ¿Qué diablos son estos juegos?..."

# game/special_events/halloween 2025.rpy:492
translate spanish halloween_sonya_dream_c5bc9963:

    # Sonya "Имя звучит знакомо"
    Sonya "El nombre me suena"

# game/special_events/halloween 2025.rpy:493
translate spanish halloween_sonya_dream_4db18375:

    # Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    Sonya "Pero la que llamaste murió con esta casa"

# game/special_events/halloween 2025.rpy:494
translate spanish halloween_sonya_dream_f5284849:

    # gg "Прекрати . . ."
    gg "Basta..."

# game/special_events/halloween 2025.rpy:496
translate spanish halloween_sonya_dream_bf221ec2:

    # Sonya "Дом теперь мой.{w} Я - его хозяин"
    Sonya "La casa ahora es mía.{w} Soy su dueño"

# game/special_events/halloween 2025.rpy:498
translate spanish halloween_sonya_dream_2c4ebaa2:

    # Sonya "Боишься?"
    Sonya "¿Tienes miedo?"

# game/special_events/halloween 2025.rpy:499
translate spanish halloween_sonya_dream_0063da0b:

    # gg "Да . . ."
    gg "Sí..."

# game/special_events/halloween 2025.rpy:501
translate spanish halloween_sonya_dream_b67571be:

    # Sonya "Хорошо"
    Sonya "Bien"

# game/special_events/halloween 2025.rpy:503
translate spanish halloween_sonya_dream_14d503b0:

    # Sonya "Страх делает кровь живой"
    Sonya "El miedo hace que la sangre cobre vida"

# game/special_events/halloween 2025.rpy:511
translate spanish halloween_sonya_dream_ab894d3a:

    # Sonya "Ты принёс монету?"
    Sonya "¿Trajiste una moneda?"

# game/special_events/halloween 2025.rpy:515
translate spanish halloween_sonya_dream_c3bf29e7:

    # gg "Что? . . ."
    gg "¿Qué?..."

# game/special_events/halloween 2025.rpy:517
translate spanish halloween_sonya_dream_52cb176c:

    # Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "Un regalo que fue sellado. Lo abriste"

# game/special_events/halloween 2025.rpy:518
translate spanish halloween_sonya_dream_e3369996:

    # Sonya "Ты впустил меня"
    Sonya "Me dejaste entrar"

# game/special_events/halloween 2025.rpy:520
translate spanish halloween_sonya_dream_1f166693:

    # Sonya "Я не Соня"
    Sonya "No soy Sonya"

# game/special_events/halloween 2025.rpy:524
translate spanish halloween_sonya_dream_86fe7642:

    # Sonya "Я та, что носила её лицо"
    Sonya "Yo soy quien llevaba su cara"

# game/special_events/halloween 2025.rpy:525
translate spanish halloween_sonya_dream_625b9f75:

    # Sonya "И теперь ты мой"
    Sonya "Y ahora eres mío"

# game/special_events/halloween 2025.rpy:527
translate spanish halloween_sonya_dream_0ac9332f:

    # Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    Sonya "Todo lo que temías perder... ya lo tomé"

# game/special_events/halloween 2025.rpy:529
translate spanish halloween_sonya_dream_64ed8507:

    # Sonya "А теперь - перестань сопротивляться"
    Sonya "Ahora deja de resistir"

# game/special_events/halloween 2025.rpy:533
translate spanish halloween_sonya_dream_9d9be648:

    # Sonya "Да . . . вот оно. Жар под кожей. Сок, который ты копил для кого-то другого. Теперь он мой"
    Sonya "Sí... aquí está. El calor bajo la piel. El jugo que acumulabas para otro. Ahora es mío"

# game/special_events/halloween 2025.rpy:534
translate spanish halloween_sonya_dream_709e3011:

    # Sonya "Я чувствую . . . как твоя суть отделяется от костей. Как светится . . . и течёт ко мне"
    Sonya "Siento... cómo tu esencia se separa de los huesos. Cómo brilla... y fluye hacia mí"

# game/special_events/halloween 2025.rpy:535
translate spanish halloween_sonya_dream_5e3f412d:

    # Sonya "Скоро . . . скоро ты станешь пустым. Лёгким. И будешь спать"
    Sonya "Pronto... pronto estarás vacío. Ligero. Y dormirás"

# game/special_events/halloween 2025.rpy:540
translate spanish halloween_sonya_dream_8f2a3a2a:

    # Sonya "Сейчас. Отдай мне последнюю искру. Тот всполох, что зовут экстазом… я приму его как дань"
    Sonya "Ahora. Entrégame la última chispa. Eso que llaman éxtasis... lo aceptaré como tributo"

# game/special_events/halloween 2025.rpy:543
translate spanish halloween_sonya_dream_279834b2:

    # Sonya "ДА! Вот . . . пылающая монета твоей души . . . я беру её!"
    Sonya "¡SÍ! Aquí... la moneda ardiente de tu alma... ¡la tomo!"

# game/special_events/halloween 2025.rpy:546
translate spanish halloween_sonya_dream_feb25de8:

    # Sonya "Спи. В твоих снах будет песок. И глаза в темноте . . . мои глаза"
    Sonya "Duerme. En tus sueños habrá arena. Y ojos en la oscuridad... mis ojos"

# game/special_events/halloween 2025.rpy:549
translate spanish halloween_sonya_dream_dbd299d0:

    # Sonya "Может быть, я позову снова . . . когда проголодаюсь"
    Sonya "Quizás te llame de nuevo... cuando tenga hambre"

# game/special_events/halloween 2025.rpy:574
translate spanish halloween_maya_dream_032be6f2:

    # gg "Чёрт . . . {w}нет, нет, снова это . . ."
    gg "Diablos... {w}no, no, esto de nuevo..."

# game/special_events/halloween 2025.rpy:576
translate spanish halloween_maya_dream_ff7388e6:

    # Maya "Эй, спокойно"
    Maya "Oye, cálmate"

# game/special_events/halloween 2025.rpy:578
translate spanish halloween_maya_dream_92686e55:

    # Maya "Ты в безопасности"
    Maya "Estás a salvo"

# game/special_events/halloween 2025.rpy:579
translate spanish halloween_maya_dream_edf9349e:

    # gg "Где я? . . ."
    gg "¿Dónde estoy?..."

# game/special_events/halloween 2025.rpy:580
translate spanish halloween_maya_dream_de23ff68:

    # gg "Что . . . что это за место?"
    gg "¿Qué... qué clase de lugar es este?"

# game/special_events/halloween 2025.rpy:582
translate spanish halloween_maya_dream_75c561e6:

    # Maya "Мой дом"
    Maya "Mi casa"

# game/special_events/halloween 2025.rpy:584
translate spanish halloween_maya_dream_912b1ea9:

    # gg "Почему . . . я . . . здесь? . . ."
    gg "¿Por qué... yo... aquí?..."

# game/special_events/halloween 2025.rpy:586
translate spanish halloween_maya_dream_05fc8512:

    # Maya "Потому что ты боялся"
    Maya "Porque tuviste miedo"

# game/special_events/halloween 2025.rpy:587
translate spanish halloween_maya_dream_657245c6:

    # Maya "И кто-то должен был тебя остановить"
    Maya "Y alguien debería haberte detenido"

# game/special_events/halloween 2025.rpy:589
translate spanish halloween_maya_dream_dcba1503:

    # gg "Нет . . .{w} не приближайся"
    gg "No...{w} no te acerques"

# game/special_events/halloween 2025.rpy:590
translate spanish halloween_maya_dream_e91592a1:

    # gg "Я видел, как это начинается"
    gg "Vi cómo empieza"

# game/special_events/halloween 2025.rpy:591
translate spanish halloween_maya_dream_d9b24014:

    # gg "Сначала свет, потом . . ."
    gg "Primero la luz, luego..."

# game/special_events/halloween 2025.rpy:594
translate spanish halloween_maya_dream_23c69478:

    # Maya "Никто не собирается тебя пугать"
    Maya "Nadie te va a asustar"

# game/special_events/halloween 2025.rpy:595
translate spanish halloween_maya_dream_fb15da85:

    # gg "Это сон?"
    gg "¿Es esto un sueño?"

# game/special_events/halloween 2025.rpy:597
translate spanish halloween_maya_dream_ef47f8b8:

    # Maya "Возможно"
    Maya "Tal vez"

# game/special_events/halloween 2025.rpy:598
translate spanish halloween_maya_dream_11e09330:

    # Maya "Но в этом сне тебе можно не убегать"
    Maya "Pero en este sueño no tienes que huir"

# game/special_events/halloween 2025.rpy:600
translate spanish halloween_maya_dream_e96ceee2:

    # Maya "Сядь.{w} Попробуй просто дышать"
    Maya "Siéntate.{w} Sólo intenta respirar"

# game/special_events/halloween 2025.rpy:601
translate spanish halloween_maya_dream_f1385d77:

    # gg "Я . . .{w} не могу"
    gg "Yo...{w} no puedo"

# game/special_events/halloween 2025.rpy:603
translate spanish halloween_maya_dream_38874e86:

    # Maya "Можешь{w}, начни только тихо"
    Maya "Puedes{w}, simplemente comienza tranquilamente"

# game/special_events/halloween 2025.rpy:605
translate spanish halloween_maya_dream_4a1eadac:

    # Maya "Ты думал, я кто-то другой, да?"
    Maya "Pensaste que era otra persona, ¿verdad?"

# game/special_events/halloween 2025.rpy:607
translate spanish halloween_maya_dream_8d83da3f:

    # gg "После всего . . ."
    gg "Después de todo..."

# game/special_events/halloween 2025.rpy:608
translate spanish halloween_maya_dream_9aa85be5:

    # gg "Я и не знаю, кому верить"
    gg "No sé a quién creer"

# game/special_events/halloween 2025.rpy:609
translate spanish halloween_maya_dream_95a67e98:

    # Maya "Тогда не верь"
    Maya "Entonces no creas"

# game/special_events/halloween 2025.rpy:610
translate spanish halloween_maya_dream_cf12428b:

    # Maya "Просто смотри"
    Maya "Sólo mira"

# game/special_events/halloween 2025.rpy:614
translate spanish halloween_maya_dream_5da82532:

    # gg "Чувствуешь?{w} Здесь нет боли"
    gg "¿Puedes sentirlo?{w} No hay dolor aquí"

# game/special_events/halloween 2025.rpy:616
translate spanish halloween_maya_dream_df19ec31:

    # Maya "Ты дрожишь"
    Maya "Estás temblando"

# game/special_events/halloween 2025.rpy:617
translate spanish halloween_maya_dream_b989363c:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:620
translate spanish halloween_maya_dream_718947a3:

    # Maya "Бедный"
    Maya "Pobre"

# game/special_events/halloween 2025.rpy:622
translate spanish halloween_maya_dream_20c45a93:

    # Maya "Я давно не видела людей"
    Maya "Hace mucho que no veo gente"

# game/special_events/halloween 2025.rpy:624
translate spanish halloween_maya_dream_0f6f1ec4:

    # Maya "Вот, видишь?{w} Уже лучше"
    Maya "¿Ves?{w} Ya es mejor"

# game/special_events/halloween 2025.rpy:625
translate spanish halloween_maya_dream_1db499d0:

    # gg "Не знаю, что это.{w} Но уже лучше"
    gg "No sé qué es.{w} Pero ya es mejor"

# game/special_events/halloween 2025.rpy:627
translate spanish halloween_maya_dream_927ad5b3:

    # Maya "Сейчас кое что тебя поставит на ноги"
    Maya "Ahora algo te pondrá de pie"

# game/special_events/halloween 2025.rpy:630
translate spanish halloween_maya_dream_9add8ae1:

    # Maya "Здесь только травы"
    Maya "Aquí sólo hay hierbas"

# game/special_events/halloween 2025.rpy:631
translate spanish halloween_maya_dream_338034af:

    # Maya "Лаванда, мята, немного корицы.{w} Попей"
    Maya "Lavanda, menta, un poco de canela.{w} Bebe"

# game/special_events/halloween 2025.rpy:633
translate spanish halloween_maya_dream_8f20081e:

    # gg "Что это?"
    gg "¿Qué es esto?"

# game/special_events/halloween 2025.rpy:634
translate spanish halloween_maya_dream_3fdb7032:

    # Maya "Это магия"
    Maya "Es magia"

# game/special_events/halloween 2025.rpy:636
translate spanish halloween_maya_dream_7c4cba20:

    # Maya "Лечебное зелье, с небольшим побочным эфектом"
    Maya "Poción curativa con efectos secundarios menores"

# game/special_events/halloween 2025.rpy:638
translate spanish halloween_maya_dream_59e469a3:

    # gg "Каким еще эфектом"
    gg "¿Qué otro efecto?"

# game/special_events/halloween 2025.rpy:641
translate spanish halloween_maya_dream_809b7a3a:

    # Maya "Просто отдохни.{w} Не думай об этом"
    Maya "Simplemente descansa.{w} No lo pienses"

# game/special_events/halloween 2025.rpy:643
translate spanish halloween_maya_dream_ae92cf27:

    # gg "А если я снова усну?"
    gg "¿Qué pasa si me vuelvo a dormir?"

# game/special_events/halloween 2025.rpy:645
translate spanish halloween_maya_dream_c1fe7b6b:

    # Maya "Тогда пусть этот сон, будет приятным"
    Maya "Entonces deja que este sueño sea placentero"

# game/special_events/halloween 2025.rpy:650
translate spanish halloween_maya_dream_6274b812:

    # Maya "Да . . . вот так . . . Ты так нуждаешься в этом. Я знала"
    Maya "Sí... así... Lo necesitas tanto. Lo sabía"

# game/special_events/halloween 2025.rpy:651
translate spanish halloween_maya_dream_c101e994:

    # gg "Майя . . . Я . . ."
    gg "Maya... Yo..."

# game/special_events/halloween 2025.rpy:652
translate spanish halloween_maya_dream_5e852895:

    # Maya "Какая прекрасная . . . реакция. Всё для меня?"
    Maya "Qué hermosa... reacción. ¿Todo para mí?"

# game/special_events/halloween 2025.rpy:653
translate spanish halloween_maya_dream_cab511be:

    # Maya "О-ох . . . Да . . . Вот так"
    Maya "O-oh... Sí... Así"

# game/special_events/halloween 2025.rpy:654
translate spanish halloween_maya_dream_87be51c0:

    # Maya "Да-да-да! Вот здесь! Чувствую, как ты пульсируешь!"
    Maya "¡Sí-sí-sí! ¡Aquí! ¡Siento cómo late!"

# game/special_events/halloween 2025.rpy:656
translate spanish halloween_maya_dream_aafdbf4d:

    # Maya "Aaa-ох . . ."
    Maya "Aaa-oh..."

# game/special_events/halloween 2025.rpy:659
translate spanish halloween_maya_dream_162eda56:

    # Maya "Идеально . . . Ты был идеален . . . Запомни это . . . Запомни меня . . ."
    Maya "Perfecto... Fuiste perfecto... Recuérdalo... Recuérdame..."

# game/special_events/halloween 2025.rpy:687
translate spanish halloween_kate_dream_2a6a4db2:

    # gg "Кейт? . . ."
    gg "¿Kate?..."

# game/special_events/halloween 2025.rpy:692
translate spanish halloween_kate_dream_3c8f411e:

    # gg "Что . . . что происходит?"
    gg "¿Qué... qué está pasando?"

# game/special_events/halloween 2025.rpy:696
translate spanish halloween_kate_dream_6b307304:

    # Kate "{sc}{size=*1.2}Ты"
    Kate "{sc}{size=*1.2}Tú"

# game/special_events/halloween 2025.rpy:698
translate spanish halloween_kate_dream_21111df8:

    # Kate "Вторгся в середину ритуала"
    Kate "Te has entrometido en medio del ritual"

# game/special_events/halloween 2025.rpy:699
translate spanish halloween_kate_dream_2caa82ea:

    # Kate "Твоё присутствие нарушило поток"
    Kate "Tu presencia ha interrumpido el flujo"

# game/special_events/halloween 2025.rpy:701
translate spanish halloween_kate_dream_bc58cb35:

    # gg "Гх . . . {w}Прости, я не знал . . ."
    gg "Gh... {w}Perdona, no sabía..."

# game/special_events/halloween 2025.rpy:703
translate spanish halloween_kate_dream_91b43246:

    # Kate "Ты не просто услышал. Ты почувствовал зов"
    Kate "No solo lo oíste. Lo sentiste"

# game/special_events/halloween 2025.rpy:705
translate spanish halloween_kate_dream_211858ba:

    # Kate "Иначе ты бы не вошёл"
    Kate "De otra forma no habrías entrado"

# game/special_events/halloween 2025.rpy:707
translate spanish halloween_kate_dream_0f5b8117:

    # Kate "Люди носят маски каждый день"
    Kate "La gente usa máscaras cada día"

# game/special_events/halloween 2025.rpy:708
translate spanish halloween_kate_dream_4fc89b6e:

    # Kate "Они молятся свету, а в темноте становятся теми, кем боятся быть"
    Kate "Rezan a la luz, pero en la oscuridad se convierten en quienes temen ser"

# game/special_events/halloween 2025.rpy:710
translate spanish halloween_kate_dream_fd7485b5:

    # gg "Кейт, пожалуйста . . . остановись"
    gg "Kate, por favor... para"

# game/special_events/halloween 2025.rpy:712
translate spanish halloween_kate_dream_21bb7ba7:

    # Kate "Это имя лишь оболочка, которую я носила"
    Kate "Ese nombre es solo una cáscara que usé"

# game/special_events/halloween 2025.rpy:713
translate spanish halloween_kate_dream_54373c98:

    # Kate "Сейчас я — та, кто принимает исповедь. А исповедь требует . . . отдачи"
    Kate "Ahora soy la que recibe la confesión. Y la confesión requiere... entrega"

# game/special_events/halloween 2025.rpy:715
translate spanish halloween_kate_dream_6aceb243:

    # Kate "Ты боишься. Это хорошо. Страх очищает"
    Kate "Tienes miedo. Es bueno. El miedo purifica"

# game/special_events/halloween 2025.rpy:716
translate spanish halloween_kate_dream_6993148d:

    # Kate "Но за страхом . . . всегда прячется желание"
    Kate "Pero tras el miedo... siempre se esconde el deseo"

# game/special_events/halloween 2025.rpy:718
translate spanish halloween_kate_dream_5f463a3c:

    # Kate "Мой ритуал требует энергии. Чистой, незамутнённой лицемерием"
    Kate "Mi ritual requiere energía. Pura, no corrompida por la hipocresía"

# game/special_events/halloween 2025.rpy:720
translate spanish halloween_kate_dream_e52aea01:

    # Kate "Твой страх — это начало. Но чтобы завершить круг . . . нужно"
    Kate "Tu miedo es el comienzo. Pero para completar el círculo... se necesita"

# game/special_events/halloween 2025.rpy:722
translate spanish halloween_kate_dream_6c364d34:

    # Kate "Нечто большее"
    Kate "Algo más"

# game/special_events/halloween 2025.rpy:725
translate spanish halloween_kate_dream_4729db36:

    # gg "Что ты хочешь? . . . "
    gg "¿Qué quieres?..."

# game/special_events/halloween 2025.rpy:727
translate spanish halloween_kate_dream_14ab3952:

    # Kate "Я хочу ту часть себя, которая не боится тьмы"
    Kate "Quiero esa parte de ti que no teme a la oscuridad"

# game/special_events/halloween 2025.rpy:729
translate spanish halloween_kate_dream_d9bfbc43:

    # Kate "Которая жаждет её"
    Kate "Que la ansía"

# game/special_events/halloween 2025.rpy:730
translate spanish halloween_kate_dream_2a999a14:

    # Kate "Это не сердце. Это — пустота, которую ты пытался заполнить ложью"
    Kate "No es el corazón. Es el vacío que intentaste llenar con mentiras"

# game/special_events/halloween 2025.rpy:732
translate spanish halloween_kate_dream_62c66a6e:

    # Kate "Позволь мне заполнить её истиной"
    Kate "Permíteme llenarlo con verdad"

# game/special_events/halloween 2025.rpy:733
translate spanish halloween_kate_dream_6f6518cc:

    # gg "Гхк . . ."
    gg "Ghk..."

# game/special_events/halloween 2025.rpy:734
translate spanish halloween_kate_dream_a32c9003:

    # gg "Я не могу подвинуться"
    gg "No puedo moverme"

# game/special_events/halloween 2025.rpy:736
translate spanish halloween_kate_dream_12b2e70f:

    # Kate "Не сопротивляйся. Это тоже часть ритуала"
    Kate "No te resistas. También es parte del ritual"

# game/special_events/halloween 2025.rpy:738
translate spanish halloween_kate_dream_fd3fd304:

    # Kate "Ты отдаёшь — я принимаю. Так было всегда"
    Kate "Tú das, yo tomo. Así ha sido siempre"

# game/special_events/halloween 2025.rpy:740
translate spanish halloween_kate_dream_7cee1ec3:

    # Kate "Видишь? Твоё тело уже понимает. Оно помнит правила"
    Kate "¿Ves? Tu cuerpo ya lo entiende. Recuerda las reglas"

# game/special_events/halloween 2025.rpy:753
translate spanish halloween_kate_dream_e36daadf:

    # Kate "Это дрожь . . . пробуждения"
    Kate "Este temblor... del despertar"

# game/special_events/halloween 2025.rpy:761
translate spanish halloween_kate_dream_18a21981:

    # Kate "Тише. Не мешай"
    Kate "Silencio. No interrumpas"

# game/special_events/halloween 2025.rpy:762
translate spanish halloween_kate_dream_64b1ddea:

    # Kate "Я только знакомлюсь с тем, что моё"
    Kate "Solo estoy conociendo lo que es mío"

# game/special_events/halloween 2025.rpy:764
translate spanish halloween_kate_dream_fa83af8e:

    # Kate "Ты . . . для этого . . .{w} и пришёл . . ."
    Kate "Tú... para esto...{w} viniste..."

# game/special_events/halloween 2025.rpy:765
translate spanish halloween_kate_dream_475590f4:

    # Kate "Чтоб тебя . . . размяли . . .{w} взяли в руки . . ."
    Kate "Para que te... amasaran...{w} te tomaran en mano..."

# game/special_events/halloween 2025.rpy:767
translate spanish halloween_kate_dream_020e238d:

    # gg "Агхх . ."
    gg "Aghh..."

# game/special_events/halloween 2025.rpy:768
translate spanish halloween_kate_dream_0c86ca7b:

    # Kate "Да!"
    Kate "¡Sí!"

# game/special_events/halloween 2025.rpy:769
translate spanish halloween_kate_dream_d0b4a1d1:

    # Kate "Вот так"
    Kate "Así"

# game/special_events/halloween 2025.rpy:770
translate spanish halloween_kate_dream_854a0208:

    # Kate "Рвись! Кончай!{w} Отдавай это мне"
    Kate "¡Desátate! ¡Acaba!{w} Entrégamelo"

# game/special_events/halloween 2025.rpy:772
translate spanish halloween_kate_dream_4402c96f:

    # Kate "Ахахаха ха ха"
    Kate "Ajajaja ja ja"

# game/special_events/halloween 2025.rpy:774
translate spanish halloween_kate_dream_c8fc9712:

    # Kate "Видишь? Даже твой пик — в моей власти"
    Kate "¿Ves? Incluso tu clímax está en mi poder"

# game/special_events/halloween 2025.rpy:775
translate spanish halloween_kate_dream_ab9b9a56:

    # Kate "Я решаю когда и как"
    Kate "Yo decido cuándo y cómo"

# game/special_events/halloween 2025.rpy:777
translate spanish halloween_kate_dream_d8951333:

    # Kate "А теперь хватит игр"
    Kate "Y ahora, basta de juegos"

# game/special_events/halloween 2025.rpy:786
translate spanish halloween_kate_dream_088e1fcf:

    # Kate "Всё, время нежностей кончилось"
    Kate "Se acabó, se terminó el tiempo de delicadezas"

# game/special_events/halloween 2025.rpy:789
translate spanish halloween_kate_dream_d84a2e22:

    # Kate "Молчи и терпи. Это плата за твой глупый интерес"
    Kate "Calla y aguanta. Es el precio por tu estúpida curiosidad"

# game/special_events/halloween 2025.rpy:791
translate spanish halloween_kate_dream_959b5201:

    # Kate "А-ах . . . Так . . . Глубоко . . ."
    Kate "A-ah... Así... Profundo..."

# game/special_events/halloween 2025.rpy:794
translate spanish halloween_kate_dream_ad7fd02e:

    # Kate "Да . . . Вот так"
    Kate "Sí... Así"

# game/special_events/halloween 2025.rpy:795
translate spanish halloween_kate_dream_e0d93040:

    # Kate "Отдай мне это.{w} Всю свою подавленную тьму.{w} Всю свою скрытую жажду"
    Kate "Entrégamelo.{w} Toda tu oscuridad reprimida.{w} Todo tu anhelo oculto"

# game/special_events/halloween 2025.rpy:796
translate spanish halloween_kate_dream_3f099ced:

    # gg "Я . . . я не могу . . ."
    gg "Yo... no puedo..."

# game/special_events/halloween 2025.rpy:797
translate spanish halloween_kate_dream_0e94451f:

    # Kate "Можешь. И ты сделаешь.{w} Сейчас"
    Kate "Puedes. Y lo harás.{w} Ahora"

# game/special_events/halloween 2025.rpy:800
translate spanish halloween_kate_dream_866aa006:

    # Kate "А-ах . . ."
    Kate "A-ah..."

# game/special_events/halloween 2025.rpy:802
translate spanish halloween_kate_dream_25c1049a:

    # Kate "Ха.."
    Kate "Ja..."

# game/special_events/halloween 2025.rpy:804
translate spanish halloween_kate_dream_c4c58437:

    # Kate "Ритуал завершён. Ты отдал достаточно . . . чтобы я продолжила свой путь"
    Kate "El ritual está completo. Has dado suficiente... para que yo continúe mi camino"

# game/special_events/halloween 2025.rpy:806
translate spanish halloween_kate_dream_c5ab54b2:

    # Kate "Ты проснёшься пустым.{w} Безнадёжно пустым. И, может быть, снова выползешь ко мне . . ."
    Kate "Despertarás vacío.{w} Desesperadamente vacío. Y quizás vuelvas a arrastrarte hacia mí..."

# game/special_events/halloween 2025.rpy:807
translate spanish halloween_kate_dream_0eb6bd42:

    # Kate "Чтобы снова украсть немного этой полноты"
    Kate "Para robar un poco de esa plenitud de nuevo"

# game/special_events/halloween 2025.rpy:809
translate spanish halloween_kate_dream_2f7f297c:

    # Kate "Хотя бы на мгновение"
    Kate "Al menos por un momento"

# game/special_events/halloween 2025.rpy:832
translate spanish halloween_kate_dream_b989363c:

    # gg ". . ."
    gg "..."
    
# game/special_events/halloween 2025.rpy:833
translate spanish halloween_kate_dream_5174a63c:

    # gg "Приснится же такое . . ."
    gg "Vaya sueño..."

# game/special_events/halloween 2025.rpy:835
translate spanish halloween_kate_dream_13dee7c8:

    # "Тыква хранит воспоминания"
    "La calabaza guarda recuerdos"

# game/special_events/halloween 2025.rpy:836
translate spanish halloween_kate_dream_bb8e42de:

    # "Коснись её, чтобы вновь увидеть сцену"
    "Tócala para volver a ver la escena"

translate spanish strings:

    # game/special_events/halloween 2025.rpy:15
    old "Сон с Кейт"
    new "Sueño con Kate"

# TODO: Translation updated at 2026-01-27 02:10

# game/special_events/halloween 2025.rpy:727
translate spanish halloween_kate_dream_195da2d7:

    # Kate "Я хочу ту часть тебя, которая не боится тьмы"
    Kate "Quiero esa parte de ti que no le teme a la oscuridad"
