﻿# TODO: Translation updated at 2026-01-21 02:04

# game/locations/main_house/myroom.rpy:22
translate spanish myroom_c1835e38:

    # "Что бы лечь спать нажмите ночью на кровать"
    "Para acostarte, haz clic en la cama por la noche"

# game/locations/main_house/myroom.rpy:27
translate spanish myroom_edb2c466:

    # "Теперь вы можешь управлять временем суток"
    "Ahora puedes controlar el momento del día"

# game/locations/main_house/myroom.rpy:28
translate spanish myroom_1cd5975b:

    # "Нажмите на значок в правом верхнем углу, чтобы изменить время"
    "Haz clic en el icono de la esquina superior derecha para cambiar la hora."

# game/locations/main_house/myroom.rpy:30
translate spanish myroom_2f1c23a7:

    # "В левом нижнем углу отображаются текущее время суток, день недели и счётчик дней"
    "En la esquina inferior izquierda se muestran el momento del día, el día de la semana y el contador de días"

# game/locations/main_house/myroom.rpy:33
translate spanish myroom_4dcc1b35:

    # "Теперь вам доступна книга персонажей"
    "Ahora tienes acceso al libro de personajes"

# game/locations/main_house/myroom.rpy:36
translate spanish myroom_f5a7354e:

    # "В ней вы можете посмотреть описание каждой девушки и текущий уровень отношений"
    "En él puedes ver la descripción de cada chica y el nivel actual de relación"

# game/locations/main_house/myroom.rpy:37
translate spanish myroom_b927df5c:

    # "Здесь же доступны подсказки к следующему событию и возможность закрепить активный квест"
    "Aquí también encontrarás sugerencias para el próximo evento y la opción de fijar una misión activa."

# TODO: Translation updated at 2026-01-26 03:23

# game/locations/main_house/myroom.rpy:27
translate spanish myroom_71fb3107:

    # "Теперь вы можете управлять временем суток"
    "Ahora puedes controlar la hora del día."

# game/locations/main_house/myroom.rpy:28
translate spanish myroom_a6aee4e7:

    # "Нажмите на значок в правом верхнем углу, чтобы сменить время"
    "Haz clic en el icono de la esquina superior derecha para cambiar el momento del día"

# game/locations/main_house/myroom.rpy:33
translate spanish myroom_b9554520:

    # "Также вам доступна книга персонажей"
    "También tienes acceso al libro de personajes."

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/myroom.rpy:27
translate spanish myroom_ac4e4f25:

    # "Теперь ты можешь управлять временем суток"
    "Ahora puedes controlar la hora del día."

# game/locations/main_house/myroom.rpy:28
translate spanish myroom_6784fea3:

    # "Нажми на значок в правом верхнем углу, чтобы сменить время"
    "Haz clic en el icono de la esquina superior derecha para cambiar el momento del día"

# game/locations/main_house/myroom.rpy:33
translate spanish myroom_b3480ee4:

    # "Также тебе доступна книга персонажей"
    "También tienes disponible el libro de personajes."

# game/locations/main_house/myroom.rpy:36
translate spanish myroom_030a80cc:

    # "В ней ты можешь посмотреть описание каждой девушки и текущий уровень отношений"
    "En él puedes ver la descripción de cada chica y el nivel actual de relación"

