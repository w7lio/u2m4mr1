﻿# TODO: Translation updated at 2026-01-21 02:04

# game/locations/main_house/bathroom.rpy:18
translate spanish bathroom_3da38f85:

    # gg "Я думаю я не так сильно знаком с Маей"
    gg "Supongo que todavía no conozco lo suficiente a Maya."

# game/locations/main_house/bathroom.rpy:23
translate spanish bathroom_1dae98de:

    # gg "Я думаю я не так сильно знаком с Соней"
    gg "Supongo que todavía no conozco lo suficiente a Sonya."

# TODO: Translation updated at 2026-01-26 03:23

# game/locations/main_house/bathroom.rpy:19
translate spanish bathroom_8df379f4:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Маей"
    gg "Supongo que todavía no conozco lo suficiente a Maya"

# game/locations/main_house/bathroom.rpy:25
translate spanish bathroom_675eb9d2:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Соней"
    gg "Supongo que todavía no conozco lo suficiente a Sonya."

