﻿# TODO: Translation updated at 2026-01-21 02:04

# game/locations/main_house/kitchen.rpy:24
translate spanish kitchen_e44eab80:

    # "Привет, перед началом игры давай быстро разберемся с управлением"
    "Hola, antes de empezar el juego, repasemos rápidamente los controles"

# game/locations/main_house/kitchen.rpy:25
translate spanish kitchen_e9ff8856:

    # "Что бы перейти в другую комнату тебе нужно навестись мышкой в правую часть экрана"
    "Para ir a otra habitación, mueve el cursor hacia la parte derecha de la pantalla"

# game/locations/main_house/kitchen.rpy:28
translate spanish kitchen_22e95808:

    # "После выбери комнату в которую хочешь попасть"
    "Luego, selecciona la habitación a la que quieres ir"

# game/locations/main_house/kitchen.rpy:29
translate spanish kitchen_c3e67100:

    # "На иконках комнат будут отображены девушки которые сейчас там находятся"
    "En los iconos de las habitaciones se mostrarán las chicas que están allí en ese momento"

# game/locations/main_house/kitchen.rpy:30
translate spanish kitchen_ffc31834:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой ключевое действие"
    "Junto al icono aparecerá una {color=#fffb27ff}estrella{/color} si hay una acción clave disponible con la chica"

# game/locations/main_house/kitchen.rpy:31
translate spanish kitchen_4c3bfaea:

    # "Попробуйте перейти в комнату Маи"
    "Intenta ir a la habitación de Maya"

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/kitchen.rpy:30
translate spanish kitchen_b2963125:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой доступно ключевое действие"
    "Junto al icono aparecerá una {color=#fffb27ff}estrella{/color} si hay una acción clave disponible con la chica"

# game/locations/main_house/kitchen.rpy:31
translate spanish kitchen_b1f7eb9e:

    # "Попробуй перейти в комнату Маи"
    "Intenta ir a la habitación de Maya"

