﻿# TODO: Translation updated at 2026-01-21 02:04

translate spanish strings:

    # game/screens.rpy:427
    old "Назад"
    new "Atrás"

    # game/screens.rpy:429
    old "Пропуск"
    new "Omitir"

    # game/screens.rpy:430
    old "Авто"
    new "Auto"

    # game/screens.rpy:431
    old "Сохранить"
    new "Guardar"

    # game/screens.rpy:432
    old "Б.Сохр"
    new "Guard. rápido"

    # game/screens.rpy:433
    old "Б.Загр"
    new "Carg. rápido"

    # game/screens.rpy:434
    old "Настройки"
    new "Ajustes"

    # game/screens.rpy:583
    old "НОВАЯ ИГРА"
    new "NUEVO JUEGO"

    # game/screens.rpy:584
    old "ЗАГРУЗИТЬ"
    new "CARGAR"

    # game/screens.rpy:585
    old "НАСТРОЙКИ"
    new "AJUSTES"

    # game/screens.rpy:586
    old "О ИГРЕ"
    new "ACERCA DEL JUEGO"

    # game/screens.rpy:593
    old "ИСТОРИЯ"
    new "HISTORIA"

    # game/screens.rpy:594
    old "СОХРАНИТЬ"
    new "GUARDAR"

    # game/screens.rpy:599
    old "ЗАВЕРШИТЬ ПОВТОР"
    new "FINALIZAR REPETICIÓN"

    # game/screens.rpy:601
    old "МЕНЮ"
    new "MENÚ"

    # game/screens.rpy:606
    old "ВЫХОД"
    new "SALIR"

    # game/screens.rpy:758
    old "Вернуться"
    new "Volver"

    # game/screens.rpy:912
    old "Версия [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:951
    old "{} страница"
    new "{} página"

    # game/screens.rpy:951
    old "Автосохранения"
    new "Autoguardados"

    # game/screens.rpy:951
    old "Быстрые сохранения"
    new "Guardados rápidos"

    # game/screens.rpy:999
    old "{#file_time}%A, %d %B %Y, %H:%M"
    new "{#file_time}%A, %d %B %Y, %H:%M"

    # game/screens.rpy:999
    old "Пустой слот"
    new "Ranura vacía"

    # game/screens.rpy:1020
    old "<"
    new "<"

    # game/screens.rpy:1024
    old "{#auto_page}А"
    new "{#auto_page}A"

    # game/screens.rpy:1027
    old "{#quick_page}Б"
    new "{#quick_page}B"

    # game/screens.rpy:1033
    old ">"
    new ">"

    # game/screens.rpy:1105
    old "Всего текста"
    new "Texto total"

    # game/screens.rpy:1106
    old "После выборов"
    new "Después de las decisiones"

    # game/screens.rpy:1112
    old "Режим экрана"
    new "Modo de pantalla"

    # game/screens.rpy:1113
    old "Оконный"
    new "Ventana"

    # game/screens.rpy:1114
    old "Полный"
    new "Completo"

    # game/screens.rpy:1118
    old "Язык"
    new "Idioma"

    # game/screens.rpy:1151
    old "Скорость текста"
    new "Velocidad del texto"

    # game/screens.rpy:1155
    old "Скорость авточтения"
    new "Velocidad de autolectura"

    # game/screens.rpy:1159
    old "Прозрачность окна"
    new "Transparencia de la ventana"

    # game/screens.rpy:1165
    old "Громкость музыки"
    new "Volumen de música"

    # game/screens.rpy:1172
    old "Громкость звуков"
    new "Volumen de sonido"

    # game/screens.rpy:1178
    old "Тест"
    new "Prueba"

    # game/screens.rpy:1182
    old "Громкость голоса"
    new "Volumen de voz"

    # game/screens.rpy:1193
    old "Без звука"
    new "Sin sonido"

    # game/screens.rpy:1378
    old "История диалогов пуста."
    new "El historial de diálogo está vacío."

    # game/screens.rpy:1621
    old "Ты правда хочешь выйти"
    new "¿De verdad quieres salir?"

    # game/screens.rpy:1628
    old "Да"
    new "Sí"

    # game/screens.rpy:1632
    old "Нет"
    new "No"

    # game/screens.rpy:1686
    old "Пропускаю"
    new "Saltando"

    # game/screens.rpy:1997
    old "Меню"
    new "Menú"

    # game/screens.rpy:2362
    old "д"
    new "d"

    # game/screens.rpy:2488
    old "Персонажи"
    new "Personajes"

    # game/screens.rpy:2608
    old "Подсказка"
    new "Pista"

    # game/screens.rpy:2627
    old "Отслеживать квест"
    new "Seguir misión"

    # game/screens.rpy:2636
    old "Перестать отслеживать"
    new "Dejar de rastrear"

    # game/screens.rpy:2657
    old "Продвигайтесь по сюжету"
    new "Avanza en la trama"

# TODO: Translation updated at 2026-01-27 02:10

translate spanish strings:

    # game/screens.rpy:574
    old "ИГРАЙ РАНЬШЕ ДРУГИХ"
    new "JUEGA ANTES QUE OTROS"

# TODO: Translation updated at 2026-01-27 02:18

translate spanish strings:

    # game/screens.rpy:602
    old "Бесплатные девлоги"
    new "Devlogs gratuitos"

