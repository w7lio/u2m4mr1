﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/sonya_events.rpy:6
translate spanish sonya_scene1_morning_kitchen_a756dbc0:

    # gg "Утречко"
    gg "Buenas"

# game/characters_events_idles/sonya_events.rpy:12
translate spanish sonya_scene1_morning_kitchen_2641e2c9:

    # Sonya "Доброе утро"
    Sonya "Buen día"

# game/characters_events_idles/sonya_events.rpy:14
translate spanish sonya_scene1_morning_kitchen_50dcebad:

    # Sonya "Как тебе спалось?"
    Sonya "¿Cómo dormiste?"

# game/characters_events_idles/sonya_events.rpy:16
translate spanish sonya_scene1_morning_kitchen_9fdea20a:

    # gg "Нормально"
    gg "Bien"

# game/characters_events_idles/sonya_events.rpy:18
translate spanish sonya_scene1_morning_kitchen_c923e04f:

    # gg "Тихо"
    gg "Tranquilo"

# game/characters_events_idles/sonya_events.rpy:20
translate spanish sonya_scene1_morning_kitchen_367f1af9:

    # Sonya "Там диван конечно старый"
    Sonya "El sofá de allí es viejo, claro"

# game/characters_events_idles/sonya_events.rpy:22
translate spanish sonya_scene1_morning_kitchen_0a0eba96:

    # Sonya "Но удобный"
    Sonya "Pero es cómodo"

# game/characters_events_idles/sonya_events.rpy:24
translate spanish sonya_scene1_morning_kitchen_0f37c26d:

    # gg "Я заметил"
    gg "Lo noté"

# game/characters_events_idles/sonya_events.rpy:26
translate spanish sonya_scene1_morning_kitchen_93b6fb71:

    # Sonya "Ты уже успел пройтись по деревне?"
    Sonya "¿Ya has dado una vuelta por el pueblo?"

# game/characters_events_idles/sonya_events.rpy:28
translate spanish sonya_scene1_morning_kitchen_0839a090:

    # Sonya "Или пока только дом вспоминаешь?"
    Sonya "¿O solo estás recordando la casa por ahora?"

# game/characters_events_idles/sonya_events.rpy:30
translate spanish sonya_scene1_morning_kitchen_12aa0f18:

    # gg "Немного посмотрел"
    gg "He mirado un poco"

# game/characters_events_idles/sonya_events.rpy:32
translate spanish sonya_scene1_morning_kitchen_c33e58bc:

    # gg "Тут . . . Хорошие люди"
    gg "Aquí... buena gente"

# game/characters_events_idles/sonya_events.rpy:34
translate spanish sonya_scene1_morning_kitchen_c8772e87:

    # Sonya "Да"
    Sonya "Sí"

# game/characters_events_idles/sonya_events.rpy:36
translate spanish sonya_scene1_morning_kitchen_ed137d91:

    # Sonya "Ты к этому быстро привыкаешь"
    Sonya "Te acostumbras rápido a esto"

# game/characters_events_idles/sonya_events.rpy:48
translate spanish sonya_scene1_morning_kitchen_e45ac0f2:

    # Sonya "Если вдруг проголодаешься — бери что хочешь"
    Sonya "Si de repente te da hambre, toma lo que quieras"

# game/characters_events_idles/sonya_events.rpy:50
translate spanish sonya_scene1_morning_kitchen_947178ba:

    # Sonya "У нас обычно никто особо не спрашивает"
    Sonya "Aquí normalmente nadie pregunta demasiado"

# game/characters_events_idles/sonya_events.rpy:56
translate spanish sonya_scene1_morning_kitchen_04c6c53d:

    # gg "Спасибо"
    gg "Gracias"

# game/characters_events_idles/sonya_events.rpy:60
translate spanish sonya_scene1_morning_kitchen_77469d65:

    # Sonya "А вообще"
    Sonya "Pero en general"

# game/characters_events_idles/sonya_events.rpy:62
translate spanish sonya_scene1_morning_kitchen_ebb5bb0f:

    # Sonya "Как тебе здесь?"
    Sonya "¿Qué te parece aquí?"

# game/characters_events_idles/sonya_events.rpy:66
translate spanish sonya_scene1_morning_kitchen_77102205:

    # Sonya "В смысле . . . жить вместе"
    Sonya "Quiero decir... vivir juntos"

# game/characters_events_idles/sonya_events.rpy:70
translate spanish sonya_scene1_morning_kitchen_dcf6ae5e:

    # gg "Непривычно"
    gg "Poco habitual"

# game/characters_events_idles/sonya_events.rpy:72
translate spanish sonya_scene1_morning_kitchen_0dd94278:

    # gg "Но нормально"
    gg "Pero está bien"

# game/characters_events_idles/sonya_events.rpy:74
translate spanish sonya_scene1_morning_kitchen_c8772e87_1:

    # Sonya "Да"
    Sonya "Sí"

# game/characters_events_idles/sonya_events.rpy:76
translate spanish sonya_scene1_morning_kitchen_8aa7b1fd:

    # Sonya "Мы тоже не сразу привыкли"
    Sonya "A nosotros tampoco nos acostumbramos de inmediato"

# game/characters_events_idles/sonya_events.rpy:78
translate spanish sonya_scene1_morning_kitchen_270848f3:

    # Sonya "Когда людей в доме становится больше"
    Sonya "Cuando hay más gente en la casa"

# game/characters_events_idles/sonya_events.rpy:80
translate spanish sonya_scene1_morning_kitchen_816d8504:

    # Sonya "Всё немного меняется"
    Sonya "Todo cambia un poco"

# game/characters_events_idles/sonya_events.rpy:99
translate spanish sonya_scene1_morning_kitchen_7b099c93:

    # gg_chat "Мае — завтрак"
    gg_chat "Para Mae — desayuno"

# game/characters_events_idles/sonya_events.rpy:100
translate spanish sonya_scene1_morning_kitchen_fcffc8ef:

    # gg_chat "Если не успею — купи, пожалуйста, продукты"
    gg_chat "Si no llego, compra comida, por favor"

# game/characters_events_idles/sonya_events.rpy:109
translate spanish sonya_scene1_morning_kitchen_7158ba01:

    # gg "Ладно, я пойду"
    gg "Vale, me voy"

# game/characters_events_idles/sonya_events.rpy:111
translate spanish sonya_scene1_morning_kitchen_fbb535a1:

    # gg "Не буду мешать"
    gg "No molestaré"

# game/characters_events_idles/sonya_events.rpy:113
translate spanish sonya_scene1_morning_kitchen_98963b02:

    # Sonya "Да ты и не мешаешь"
    Sonya "Pero si no molestas"

# game/characters_events_idles/sonya_events.rpy:117
translate spanish sonya_scene1_morning_kitchen_d24f6aaf:

    # Sonya "Но . . . хорошо"
    Sonya "Pero... está bien"

# game/characters_events_idles/sonya_events.rpy:133
translate spanish sonya_scene2_day_girlroom_68c12557:

    # gg "Сонь"
    gg "Sonia"

# game/characters_events_idles/sonya_events.rpy:137
translate spanish sonya_scene2_day_girlroom_d3ca52ed:

    # gg "Ты не знаешь, где у вас аптечка?"
    gg "¿No sabes dónde está el botiquín?"

# game/characters_events_idles/sonya_events.rpy:139
translate spanish sonya_scene2_day_girlroom_fb949c9e:

    # Sonya "Аптечка?"
    Sonya "¿Botiquín?"

# game/characters_events_idles/sonya_events.rpy:141
translate spanish sonya_scene2_day_girlroom_695184c3:

    # Sonya "А что случилось?"
    Sonya "¿Qué ha pasado?"

# game/characters_events_idles/sonya_events.rpy:143
translate spanish sonya_scene2_day_girlroom_55820831:

    # gg "Да так"
    gg "Bah, una tontería"

# game/characters_events_idles/sonya_events.rpy:145
translate spanish sonya_scene2_day_girlroom_41aa37fb:

    # gg "Поцарапался.{w} Ерунда"
    gg "Me hice un rasguño.{w} Una tontería"

# game/characters_events_idles/sonya_events.rpy:149
translate spanish sonya_scene2_day_girlroom_06e5075f:

    # Sonya "Подожди"
    Sonya "Espera"

# game/characters_events_idles/sonya_events.rpy:151
translate spanish sonya_scene2_day_girlroom_b43c4c5e:

    # Sonya "Сейчас все сделаем"
    Sonya "Ahora lo arreglamos"

# game/characters_events_idles/sonya_events.rpy:155
translate spanish sonya_scene2_day_girlroom_7cc8260f:

    # Sonya "А ты почти без вещей приехал"
    Sonya "Y tú llegaste casi sin cosas"

# game/characters_events_idles/sonya_events.rpy:157
translate spanish sonya_scene2_day_girlroom_b1f32e8a:

    # Sonya "Так и планировал"
    Sonya "Lo tenía planeado así"

# game/characters_events_idles/sonya_events.rpy:158
translate spanish sonya_scene2_day_girlroom_06e860df:

    # Sonya "Или просто не успел собрать?"
    Sonya "¿O simplemente no tuviste tiempo de recoger?"

# game/characters_events_idles/sonya_events.rpy:164
translate spanish sonya_scene2_day_girlroom_cc881b3b:

    # gg "Скорее второе"
    gg "Más bien lo segundo"

# game/characters_events_idles/sonya_events.rpy:166
translate spanish sonya_scene2_day_girlroom_72e0315a:

    # gg "Решил не тащить за собой старое"
    gg "Decidí no cargar con lo viejo"

# game/characters_events_idles/sonya_events.rpy:169
translate spanish sonya_scene2_day_girlroom_fef188e6:

    # gg "Посмотреть, как будет"
    gg "Ver cómo va"

# game/characters_events_idles/sonya_events.rpy:171
translate spanish sonya_scene2_day_girlroom_4b248478:

    # Sonya "Будто новая жизнь"
    Sonya "Como una vida nueva"

# game/characters_events_idles/sonya_events.rpy:173
translate spanish sonya_scene2_day_girlroom_84c6a1f8:

    # Sonya "Ты получается больше утренний человек?"
    Sonya "¿Resulta que eres más de mañanas?"

# game/characters_events_idles/sonya_events.rpy:175
translate spanish sonya_scene2_day_girlroom_e550b517:

    # Sonya "Или нет?"
    Sonya "¿O no?"

# game/characters_events_idles/sonya_events.rpy:177
translate spanish sonya_scene2_day_girlroom_254f159a:

    # gg "Раньше — скорее вечерний"
    gg "Antes, más bien de noche"

# game/characters_events_idles/sonya_events.rpy:179
translate spanish sonya_scene2_day_girlroom_bf5f3aef:

    # gg "А здесь почему-то весь день на ногах"
    gg "Pero aquí, por alguna razón, estoy todo el día en pie"

# game/characters_events_idles/sonya_events.rpy:181
translate spanish sonya_scene2_day_girlroom_633d56a5:

    # gg "Сам удивляюсь"
    gg "Yo mismo me sorprendo"

# game/characters_events_idles/sonya_events.rpy:183
translate spanish sonya_scene2_day_girlroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "¿En serio?"

# game/characters_events_idles/sonya_events.rpy:185
translate spanish sonya_scene2_day_girlroom_7e52f22d:

    # Sonya "Значит, деревня на тебя хорошо действует"
    Sonya "Entonces el pueblo te sienta bien"

# game/characters_events_idles/sonya_events.rpy:187
translate spanish sonya_scene2_day_girlroom_d0a33041:

    # Sonya "И часто ты так . . ."
    Sonya "¿Y a menudo te...?"

# game/characters_events_idles/sonya_events.rpy:189
translate spanish sonya_scene2_day_girlroom_25b95c9d:

    # Sonya "Царапаешься?"
    Sonya "¿Rasguñas?"

# game/characters_events_idles/sonya_events.rpy:191
translate spanish sonya_scene2_day_girlroom_8f76c3f1:

    # gg "Не особо"
    gg "No mucho"

# game/characters_events_idles/sonya_events.rpy:193
translate spanish sonya_scene2_day_girlroom_2171a9af:

    # gg "Просто ещё не привык к местной фауне"
    gg "Simplemente aún no estoy acostumbrado a la fauna local"

# game/characters_events_idles/sonya_events.rpy:195
translate spanish sonya_scene2_day_girlroom_09b9d111:

    # Sonya "А . . ."
    Sonya "Ah..."

# game/characters_events_idles/sonya_events.rpy:196
translate spanish sonya_scene2_day_girlroom_521ff667:

    # Sonya "Тогда понятно"
    Sonya "Entonces entiendo"

# game/characters_events_idles/sonya_events.rpy:203
translate spanish sonya_scene2_day_girlroom_6b068d33:

    # gg "Ты так аккуратно всё делаешь . . ."
    gg "Haces todo con tanto cuidado..."

# game/characters_events_idles/sonya_events.rpy:205
translate spanish sonya_scene2_day_girlroom_bbcf86fd:

    # gg "Это привычка?"
    gg "¿Es costumbre?"

# game/characters_events_idles/sonya_events.rpy:207
translate spanish sonya_scene2_day_girlroom_a174002e:

    # Sonya "Ага"
    Sonya "Ajá"

# game/characters_events_idles/sonya_events.rpy:208
translate spanish sonya_scene2_day_girlroom_5e6a7fb2:

    # Sonya "Мне так спокойнее"
    Sonya "Así estoy más tranquila"

# game/characters_events_idles/sonya_events.rpy:210
translate spanish sonya_scene2_day_girlroom_ea7be3c1:

    # Sonya "Когда всё сделано как надо"
    Sonya "Cuando todo está hecho como debe ser"

# game/characters_events_idles/sonya_events.rpy:212
translate spanish sonya_scene2_day_girlroom_d9f6fc3a:

    # Sonya "Готово"
    Sonya "Listo"

# game/characters_events_idles/sonya_events.rpy:216
translate spanish sonya_scene2_day_girlroom_04c6c53d:

    # gg "Спасибо"
    gg "Gracias"

# game/characters_events_idles/sonya_events.rpy:218
translate spanish sonya_scene2_day_girlroom_1c0e0b38:

    # Sonya "А у тебя . . ."
    Sonya "Y tú..."

# game/characters_events_idles/sonya_events.rpy:220
translate spanish sonya_scene2_day_girlroom_041495e8:

    # Sonya "Там, в городе . . ."
    Sonya "Allá, en la ciudad..."

# game/characters_events_idles/sonya_events.rpy:222
translate spanish sonya_scene2_day_girlroom_ec4c11a0:

    # Sonya "Кто-нибудь остался?"
    Sonya "¿Quedó alguien?"

# game/characters_events_idles/sonya_events.rpy:224
translate spanish sonya_scene2_day_girlroom_d26255df:

    # gg "Был один человек"
    gg "Había una persona"

# game/characters_events_idles/sonya_events.rpy:226
translate spanish sonya_scene2_day_girlroom_5319b6ee:

    # gg "Мы давно разошлись"
    gg "Nos separamos hace tiempo"

# game/characters_events_idles/sonya_events.rpy:228
translate spanish sonya_scene2_day_girlroom_48254a12:

    # gg "Сейчас . . .{w} скорее нет, чем да"
    gg "Ahora...{w} más bien no que sí"

# game/characters_events_idles/sonya_events.rpy:230
translate spanish sonya_scene2_day_girlroom_93bf8783:

    # Sonya "Понятно"
    Sonya "Entiendo"

# game/characters_events_idles/sonya_events.rpy:232
translate spanish sonya_scene2_day_girlroom_bfbf3b82:

    # Sonya "Я просто спросила"
    Sonya "Solo preguntaba"

# game/characters_events_idles/sonya_events.rpy:238
translate spanish sonya_scene2_day_girlroom_bde02200:

    # Sonya "Тогда я наверно . . ."
    Sonya "Entonces, supongo que..."

# game/characters_events_idles/sonya_events.rpy:240
translate spanish sonya_scene2_day_girlroom_230ea232:

    # Sonya "Буду дальше убираться, пыль быстро собирается"
    Sonya "Seguiré limpiando, el polvo se acumula rápido"

# game/characters_events_idles/sonya_events.rpy:243
translate spanish sonya_scene2_day_girlroom_944c14eb:

    # gg "Спасибо еще раз"
    gg "Gracias de nuevo"

# game/characters_events_idles/sonya_events.rpy:245
translate spanish sonya_scene2_day_girlroom_3735a72e:

    # Sonya "Угу"
    Sonya "Ajá"

# game/characters_events_idles/sonya_events.rpy:247
translate spanish sonya_scene2_day_girlroom_ccc766ff:

    # Sonya "Если что аптечка всегда здесь"
    Sonya "Por si acaso, el botiquín siempre está aquí"

# game/characters_events_idles/sonya_events.rpy:273
translate spanish sonya_scene3_day_bathroom_03e250ee:

    # gg "Эмм Соня, я тут"
    gg "Emm, Sonia, estoy aquí"

# game/characters_events_idles/sonya_events.rpy:281
translate spanish sonya_scene3_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "Oh"

# game/characters_events_idles/sonya_events.rpy:294
translate spanish sonya_scene3_day_bathroom_b3aa243a:

    # Sonya "Прости"
    Sonya "Perdón"

# game/characters_events_idles/sonya_events.rpy:296
translate spanish sonya_scene3_day_bathroom_ea2e53f8:

    # Sonya "Я думала, ванная свободна"
    Sonya "Creí que el baño estaba libre"

# game/characters_events_idles/sonya_events.rpy:298
translate spanish sonya_scene3_day_bathroom_7f3525bd:

    # Sonya "Это моя ошибка"
    Sonya "Es mi error"

# game/characters_events_idles/sonya_events.rpy:300
translate spanish sonya_scene3_day_bathroom_b8f5eb09:

    # gg "Всё нормально"
    gg "Todo está bien"

# game/characters_events_idles/sonya_events.rpy:302
translate spanish sonya_scene3_day_bathroom_623f3607:

    # gg "Ничего страшного"
    gg "No pasa nada"

# game/characters_events_idles/sonya_events.rpy:304
translate spanish sonya_scene3_day_bathroom_7fce0f16:

    # Sonya "{size=*1.3}Нет"
    Sonya "{size=*1.3}No"

# game/characters_events_idles/sonya_events.rpy:306
translate spanish sonya_scene3_day_bathroom_c2e17951:

    # Sonya "Я просто сделаю вид"
    Sonya "Simplemente fingiré"

# game/characters_events_idles/sonya_events.rpy:308
translate spanish sonya_scene3_day_bathroom_1a86b367:

    # Sonya "Что этого не было"
    Sonya "Que esto no pasó"

# game/characters_events_idles/sonya_events.rpy:325
translate spanish sonya_scene3_day_bathroom_475b14a6:

    # Sonya "Я оставила тебе чай на кухне"
    Sonya "Te dejé té en la cocina"

# game/characters_events_idles/sonya_events.rpy:327
translate spanish sonya_scene3_day_bathroom_c0c28f24:

    # Sonya "Горячий аккуратнее"
    Sonya "Cuidado, está caliente"

# game/characters_events_idles/sonya_events.rpy:330
translate spanish sonya_scene3_day_bathroom_04c6c53d:

    # gg "Спасибо"
    gg "Gracias"

# game/characters_events_idles/sonya_events.rpy:351
translate spanish sonya_scene4_morning_bathroom_db34cd4c:

    # gg "Эм . . ."
    gg "Em..."

# game/characters_events_idles/sonya_events.rpy:353
translate spanish sonya_scene4_morning_bathroom_f18372c4:

    # Sonya "Ой . . ." with hpunch
    Sonya "Oh..." with hpunch

# game/characters_events_idles/sonya_events.rpy:354
translate spanish sonya_scene4_morning_bathroom_d5441823:

    # gg "Наверно, я зайду попозже"
    gg "Probablemente volveré más tarde"

# game/characters_events_idles/sonya_events.rpy:356
translate spanish sonya_scene4_morning_bathroom_b9dc4392:

    # Sonya "Стой"
    Sonya "Espera"

# game/characters_events_idles/sonya_events.rpy:358
translate spanish sonya_scene4_morning_bathroom_e21251db:

    # Sonya "Не стесняйся. Чисти зубы, я уже заканчиваю"
    Sonya "No te cortes. Lávate los dientes, ya termino"

# game/characters_events_idles/sonya_events.rpy:360
translate spanish sonya_scene4_morning_bathroom_0d97ff86:

    # gg_chat "Ого . . ."
    gg_chat "Vaya..."

# game/characters_events_idles/sonya_events.rpy:364
translate spanish sonya_scene4_morning_bathroom_7f534b36:

    # Sonya "Тут раньше жили только мы с Маей"
    Sonya "Aquí antes solo vivíamos Maya y yo"

# game/characters_events_idles/sonya_events.rpy:366
translate spanish sonya_scene4_morning_bathroom_8e74c8b9:

    # Sonya "Девушки"
    Sonya "Chicas"

# game/characters_events_idles/sonya_events.rpy:368
translate spanish sonya_scene4_morning_bathroom_822105aa:

    # Sonya "Я привыкла ходить"
    Sonya "Me acostumbré a andar"

# game/characters_events_idles/sonya_events.rpy:370
translate spanish sonya_scene4_morning_bathroom_759d9a83:

    # Sonya "Так"
    Sonya "Así"

# game/characters_events_idles/sonya_events.rpy:373
translate spanish sonya_scene4_morning_bathroom_893810bd:

    # Sonya "Никого это не смущало . . ."
    Sonya "A nadie le molestaba..."

# game/characters_events_idles/sonya_events.rpy:375
translate spanish sonya_scene4_morning_bathroom_2d618e7e:

    # gg "Да где-то я уже такое видел"
    gg "Sí, algo así ya lo he visto en alguna parte"

# game/characters_events_idles/sonya_events.rpy:377
translate spanish sonya_scene4_morning_bathroom_26a90d56:

    # Sonya "Ты смотришь"
    Sonya "Tú miras"

# game/characters_events_idles/sonya_events.rpy:379
translate spanish sonya_scene4_morning_bathroom_62a5f760:

    # Sonya "Даже не пытаешься отвернуться"
    Sonya "Ni siquiera intentas apartar la vista"

# game/characters_events_idles/sonya_events.rpy:382
translate spanish sonya_scene4_morning_bathroom_1c65dff9:

    # Sonya "И знаешь . . ."
    Sonya "Y sabes..."

# game/characters_events_idles/sonya_events.rpy:384
translate spanish sonya_scene4_morning_bathroom_7516d68e:

    # Sonya "Мне это нравится . . ."
    Sonya "Me gusta..."

# game/characters_events_idles/sonya_events.rpy:388
translate spanish sonya_scene4_morning_bathroom_6911a69b:

    # Sonya "Всё"
    Sonya "Basta"

# game/characters_events_idles/sonya_events.rpy:390
translate spanish sonya_scene4_morning_bathroom_bc7d5f86:

    # Sonya "Хватит тебе утренней зарядки для глаз"
    Sonya "Suficiente gimnasia matutina para tus ojos"

# game/characters_events_idles/sonya_events.rpy:395
translate spanish sonya_scene4_morning_bathroom_9bf5f0cd:

    # Sonya "Но всё же . . ."
    Sonya "Pero aún así..."

# game/characters_events_idles/sonya_events.rpy:397
translate spanish sonya_scene4_morning_bathroom_3780446f:

    # extend " Как ты можешь смотреть"
    extend " ¿Cómo puedes mirar"

# game/characters_events_idles/sonya_events.rpy:401
translate spanish sonya_scene4_morning_bathroom_1f146f5f:

    # Sonya "И не трогать?"
    Sonya "Y no tocar?"

# game/characters_events_idles/sonya_events.rpy:416
translate spanish sonya_scene5_night_girlroom_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/characters_events_idles/sonya_events.rpy:418
translate spanish sonya_scene5_night_girlroom_f0ccb195:

    # Sonya "[povname] . . ."
    Sonya "[povname]..."

# game/characters_events_idles/sonya_events.rpy:422
translate spanish sonya_scene5_night_girlroom_f0ccb195_1:

    # Sonya "[povname] . . ."
    Sonya "[povname]..."

# game/characters_events_idles/sonya_events.rpy:425
translate spanish sonya_scene5_night_girlroom_6c32fa14:

    # gg "А что . . ."
    gg "¿Y qué...?"

# game/characters_events_idles/sonya_events.rpy:427
translate spanish sonya_scene5_night_girlroom_b3aa243a:

    # Sonya "Прости"
    Sonya "Perdón"

# game/characters_events_idles/sonya_events.rpy:428
translate spanish sonya_scene5_night_girlroom_4aff93e9:

    # Sonya "Я не хотела тебя резко будить"
    Sonya "No quise despertarte de golpe"

# game/characters_events_idles/sonya_events.rpy:431
translate spanish sonya_scene5_night_girlroom_cbd4343b:

    # Sonya "Просто . . . не могу заснуть"
    Sonya "Es que... no puedo dormir"

# game/characters_events_idles/sonya_events.rpy:433
translate spanish sonya_scene5_night_girlroom_873c4360:

    # Sonya "Ты спишь так спокойно"
    Sonya "Tú duermes tan tranquilo"

# game/characters_events_idles/sonya_events.rpy:435
translate spanish sonya_scene5_night_girlroom_988f1304:

    # Sonya "Посидишь со мной немного?"
    Sonya "¿Te quedarás un rato conmigo?"

# game/characters_events_idles/sonya_events.rpy:437
translate spanish sonya_scene5_night_girlroom_2970a146:

    # Sonya "Пока не отпустит"
    Sonya "Hasta que se me pase"

# game/characters_events_idles/sonya_events.rpy:439
translate spanish sonya_scene5_night_girlroom_a9b332b7:

    # gg "Ты устала?"
    gg "¿Estás cansada?"

# game/characters_events_idles/sonya_events.rpy:441
translate spanish sonya_scene5_night_girlroom_0fb040eb:

    # Sonya "Нет,{w} не совсем"
    Sonya "No,{w} en realidad no"

# game/characters_events_idles/sonya_events.rpy:443
translate spanish sonya_scene5_night_girlroom_5527f93e:

    # Sonya "Просто думала"
    Sonya "Solo estaba pensando"

# game/characters_events_idles/sonya_events.rpy:446
translate spanish sonya_scene5_night_girlroom_72ba6d47:

    # gg "О чём?"
    gg "¿En qué?"

# game/characters_events_idles/sonya_events.rpy:448
translate spanish sonya_scene5_night_girlroom_69179d28:

    # Sonya "Да не важно"
    Sonya "No importa"

# game/characters_events_idles/sonya_events.rpy:452
translate spanish sonya_scene5_night_girlroom_589ad1ec:

    # gg "Ты всё время так?"
    gg "¿Siempre estás así?"

# game/characters_events_idles/sonya_events.rpy:453
translate spanish sonya_scene5_night_girlroom_6f30ec91:

    # gg "Или бывает, что расслабляешься?"
    gg "¿O a veces logras relajarte?"

# game/characters_events_idles/sonya_events.rpy:455
translate spanish sonya_scene5_night_girlroom_fda29abb:

    # Sonya "Раньше было легче"
    Sonya "Antes era más fácil"

# game/characters_events_idles/sonya_events.rpy:457
translate spanish sonya_scene5_night_girlroom_1684e2b6:

    # Sonya "Просто я"
    Sonya "Es que yo"

# game/characters_events_idles/sonya_events.rpy:459
translate spanish sonya_scene5_night_girlroom_09ea6a66:

    # Sonya "Привыкла держать всё под контролем"
    Sonya "Estoy acostumbrada a mantener todo bajo control"

# game/characters_events_idles/sonya_events.rpy:462
translate spanish sonya_scene5_night_girlroom_27fc4b94:

    # Sonya "Ладно . . ."
    Sonya "Vale..."

# game/characters_events_idles/sonya_events.rpy:465
translate spanish sonya_scene5_night_girlroom_04a163be:

    # Sonya "Вот видишь"
    Sonya "Ya ves"

# game/characters_events_idles/sonya_events.rpy:467
translate spanish sonya_scene5_night_girlroom_1825b5d8:

    # Sonya "Даже это нормально не могу"
    Sonya "Ni siquiera esto puedo hacerlo con normalidad"

# game/characters_events_idles/sonya_events.rpy:473
translate spanish sonya_scene5_night_girlroom_4706c7d6:

    # Sonya "Давай просто полежим"
    Sonya "Vamos a acostarnos"

# game/characters_events_idles/sonya_events.rpy:475
translate spanish sonya_scene5_night_girlroom_dd04d853:

    # Sonya "Я не хочу думать сейчас"
    Sonya "No quiero pensar ahora"

# game/characters_events_idles/sonya_events.rpy:493
translate spanish sonya_scene5_night_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "Gracias..."

# game/characters_events_idles/sonya_events.rpy:495
translate spanish sonya_scene5_night_girlroom_7edcc3c4:

    # Sonya "Я давно так нормально не спала"
    Sonya "Hacía mucho que no dormía tan bien"

# game/characters_events_idles/sonya_events.rpy:503
translate spanish sonya_scene5_night_girlroom_a9d8faa5:

    # Sonya "Если Мая увидит нас, будет много вопросов"
    Sonya "Si Maya nos ve, habrá muchas preguntas"

# game/characters_events_idles/sonya_events.rpy:505
translate spanish sonya_scene5_night_girlroom_2c86168e:

    # Sonya "Я сделаю тебе завтрак"
    Sonya "Te haré el desayuno"

# game/characters_events_idles/sonya_events.rpy:507
translate spanish sonya_scene5_night_girlroom_9663ea36:

    # Sonya "Он будет вкусным, не переживай"
    Sonya "Estará bueno, no te preocupes"

# game/characters_events_idles/sonya_events.rpy:525
translate spanish sonya_scene6_evening_myroom_1d152ede:

    # gg "Привет!"
    gg "¡Hola!"

# game/characters_events_idles/sonya_events.rpy:527
translate spanish sonya_scene6_evening_myroom_4979c711:

    # Sonya "Эй, ты аниме смотришь?"
    Sonya "Oye, ¿tú ves anime?"

# game/characters_events_idles/sonya_events.rpy:529
translate spanish sonya_scene6_evening_myroom_8dbdedb7:

    # Sonya "Тут только началось"
    Sonya "Acaba de empezar"

# game/characters_events_idles/sonya_events.rpy:531
translate spanish sonya_scene6_evening_myroom_a94af5bd:

    # gg "Ага, почему бы и нет"
    gg "Ajá, por qué no"

# game/characters_events_idles/sonya_events.rpy:538
translate spanish sonya_scene6_evening_myroom_4fa070d4:

    # gg "Забавно . . ."
    gg "Qué curioso..."

# game/characters_events_idles/sonya_events.rpy:540
translate spanish sonya_scene6_evening_myroom_2e5cd401:

    # extend "Теперь этот диван - моя кровать"
    extend " Ahora este sofá es mi cama"

# game/characters_events_idles/sonya_events.rpy:542
translate spanish sonya_scene6_evening_myroom_a3f8d8b5:

    # gg "Я привык на нём фильмы смотреть, а теперь ещё и сплю здесь"
    gg "Estaba acostumbrado a ver películas en él, y ahora hasta duermo aquí"

# game/characters_events_idles/sonya_events.rpy:543
translate spanish sonya_scene6_evening_myroom_8d9b5058:

    # Sonya "Вообще - то"
    Sonya "De hecho"

# game/characters_events_idles/sonya_events.rpy:547
translate spanish sonya_scene6_evening_myroom_8bf7cd77:

    # extend " раньше это была моя кровать"
    extend " antes era mi cama"

# game/characters_events_idles/sonya_events.rpy:549
translate spanish sonya_scene6_evening_myroom_4b9b63e3:

    # Sonya "До ухода Линды"
    Sonya "Hasta que Linda se fue"

# game/characters_events_idles/sonya_events.rpy:551
translate spanish sonya_scene6_evening_myroom_2c51288e:

    # Sonya "А она тогда жила в моей комнатe"
    Sonya "Y ella vivía entonces en mi habitación"

# game/characters_events_idles/sonya_events.rpy:553
translate spanish sonya_scene6_evening_myroom_3467de90:

    # gg "Серьёзно?"
    gg "¿En serio?"

# game/characters_events_idles/sonya_events.rpy:555
translate spanish sonya_scene6_evening_myroom_80955fa4:

    # Sonya "Да, но потом мы сделали ремонт, чтобы всё было по - нашему"
    Sonya "Sí, pero luego hicimos reformas para que todo fuera a nuestro gusto"

# game/characters_events_idles/sonya_events.rpy:557
translate spanish sonya_scene6_evening_myroom_3d5a6534:

    # gg "Красиво получилось . . . {w}и дом где провел детство все еще чувствуется"
    gg "Quedó bonito... {w}y aún se siente la casa donde pasé la infancia"

# game/characters_events_idles/sonya_events.rpy:562
translate spanish sonya_scene6_evening_myroom_0bab6ed7:

    # "Ты мог бы идти один. Я бы справилась"
    "Podrías ir solo. Yo me las arreglaría"

# game/characters_events_idles/sonya_events.rpy:564
translate spanish sonya_scene6_evening_myroom_e09cf293:

    # "Ты слишком спокоен. Обычно люди стараются понравиться"
    "Estás demasiado tranquilo. La gente suele intentar caer bien"

# game/characters_events_idles/sonya_events.rpy:566
translate spanish sonya_scene6_evening_myroom_93462049:

    # "А я не хочу «стараться». Хочу, чтобы ты узнала меня настоящего"
    "Pero yo no quiero \"intentarlo\". Quiero que conozcas al verdadero yo"

# game/characters_events_idles/sonya_events.rpy:568
translate spanish sonya_scene6_evening_myroom_25dcefcc:

    # "Знаешь, у меня есть и более интересные дела"
    "Sabes, tengo cosas más interesantes que hacer"

# game/characters_events_idles/sonya_events.rpy:570
translate spanish sonya_scene6_evening_myroom_fda89b59:

    # "Тогда почему ты всё ещё здесь?"
    "Entonces, ¿por qué sigues aquí?"

# game/characters_events_idles/sonya_events.rpy:573
translate spanish sonya_scene6_evening_myroom_7f029619:

    # Sonya "Вот смотри . . ."
    Sonya "Mira..."

# game/characters_events_idles/sonya_events.rpy:575
translate spanish sonya_scene6_evening_myroom_6f549ff9:

    # extend " она играет „недоступную“"
    extend " ella está haciendo la \"inaccesible\""

# game/characters_events_idles/sonya_events.rpy:577
translate spanish sonya_scene6_evening_myroom_beb1c184:

    # Sonya "Хотя видно, что сохнет по нему . . ."
    Sonya "Aunque se ve que se muere por él..."

# game/characters_events_idles/sonya_events.rpy:580
translate spanish sonya_scene6_evening_myroom_766aa28c:

    # gg "Может, в этом и драма?"
    gg "¿Tal vez esa sea la gracia?"

# game/characters_events_idles/sonya_events.rpy:582
translate spanish sonya_scene6_evening_myroom_ae35e350:

    # Sonya "Драма в том, что тянет резину"
    Sonya "La gracia es que alarga el chicle"

# game/characters_events_idles/sonya_events.rpy:584
translate spanish sonya_scene6_evening_myroom_70feb79f:

    # Sonya "Зачем, если всё ясно?"
    Sonya "¿Para qué, si todo está claro?"

# game/characters_events_idles/sonya_events.rpy:585
translate spanish sonya_scene6_evening_myroom_b291874f:

    # Sonya "{sc}Это раздражает{/sc}" with hpunch
    Sonya "{sc}Es irritante{/sc}" with hpunch

# game/characters_events_idles/sonya_events.rpy:587
translate spanish sonya_scene6_evening_myroom_6ef8cdd4:

    # gg "Ты бы решила быстрее?"
    gg "¿Tú lo resolverías más rápido?"

# game/characters_events_idles/sonya_events.rpy:589
translate spanish sonya_scene6_evening_myroom_2db4fbf2:

    # Sonya "Намного быстрее . . ."
    Sonya "Mucho más rápido..."

# game/characters_events_idles/sonya_events.rpy:591
translate spanish sonya_scene6_evening_myroom_c5704027:

    # Sonya "Скучное аниме"
    Sonya "Aburrido este anime"

# game/characters_events_idles/sonya_events.rpy:593
translate spanish sonya_scene6_evening_myroom_9be82b23:

    # Sonya "Я не могу сидеть спокойно"
    Sonya "No puedo quedarme quieta"

# game/characters_events_idles/sonya_events.rpy:595
translate spanish sonya_scene6_evening_myroom_13513f79:

    # gg "Тогда ложись, может, так будет легче"
    gg "Pues túmbate, tal vez así sea más fácil"

# game/characters_events_idles/sonya_events.rpy:597
translate spanish sonya_scene6_evening_myroom_0d9cdeae:

    # Sonya "Лечь говоришь?"
    Sonya "¿Túmbarte dices?"

# game/characters_events_idles/sonya_events.rpy:605
translate spanish sonya_scene6_evening_myroom_448d2ea3:

    # Sonya "Да так спокойнее . . ."
    Sonya "Sí, así más tranquila..."

# game/characters_events_idles/sonya_events.rpy:610
translate spanish sonya_scene6_evening_myroom_75e70e12:

    # Sonya "{sc}Ах . . .{/sc}"
    Sonya "{sc}Ah...{/sc}"

# game/characters_events_idles/sonya_events.rpy:613
translate spanish sonya_scene6_evening_myroom_376482db:

    # Sonya "Вот так . . ."
    Sonya "Así..."

# game/characters_events_idles/sonya_events.rpy:614
translate spanish sonya_scene6_evening_myroom_28a0cb64:

    # Sonya "Наконец - то"
    Sonya "Por fin"

# game/characters_events_idles/sonya_events.rpy:616
translate spanish sonya_scene6_evening_myroom_2157c7a2:

    # Sonya "Не бойся, мне нравится"
    Sonya "No tengas miedo, me gusta"

# game/characters_events_idles/sonya_events.rpy:619
translate spanish sonya_scene6_evening_myroom_e0c310ab:

    # Sonya "В ванной ты только смотрел"
    Sonya "En el baño solo mirabas"

# game/characters_events_idles/sonya_events.rpy:621
translate spanish sonya_scene6_evening_myroom_23073e11:

    # Sonya "Тут я тебе помогу"
    Sonya "Aquí te voy a ayudar"

# game/characters_events_idles/sonya_events.rpy:623
translate spanish sonya_scene6_evening_myroom_77e32f3e:

    # Sonya "Я знаю, что ты хочешь"
    Sonya "Yo sé lo que quieres"

# game/characters_events_idles/sonya_events.rpy:625
translate spanish sonya_scene6_evening_myroom_314984e9:

    # Sonya "Просто помогаю"
    Sonya "Solo estoy ayudando"

# game/characters_events_idles/sonya_events.rpy:629
translate spanish sonya_scene6_evening_myroom_70da84e8:

    # Sonya "Мне приятно . . . {w}даже больше, чем я ожидала"
    Sonya "Me gusta... {w}incluso más de lo que esperaba"

# game/characters_events_idles/sonya_events.rpy:630
translate spanish sonya_scene6_evening_myroom_42733475:

    # gg "У тебя прекрасная грудь . . . {w}мягкая и тёплая"
    gg "Tienes unos pechos preciosos... {w}suaves y calentitos"

# game/characters_events_idles/sonya_events.rpy:631
translate spanish sonya_scene6_evening_myroom_ae3a5ec7:

    # gg "Идеальная"
    gg "Perfectos"

# game/characters_events_idles/sonya_events.rpy:632
translate spanish sonya_scene6_evening_myroom_ec947a50:

    # Sonya "Хитрый . . ."
    Sonya "Astuto..."

# game/characters_events_idles/sonya_events.rpy:633
translate spanish sonya_scene6_evening_myroom_9e059832:

    # Sonya "Знаешь ведь, что я краснею от таких слов"
    Sonya "Sabes que me hago roja con esas palabras"

# game/characters_events_idles/sonya_events.rpy:635
translate spanish sonya_scene6_evening_myroom_9a2913c4:

    # Sonya "Но продолжай"
    Sonya "Pero sigue"

# game/characters_events_idles/sonya_events.rpy:644
translate spanish sonya_scene6_evening_myroom_394ba447:

    # Maya "А что это вы тут . . ."
    Maya "Pero qué hacéis aquí..."

# game/characters_events_idles/sonya_events.rpy:646
translate spanish sonya_scene6_evening_myroom_f2d7a854:

    # Maya "В обнимку сидите?"
    Maya "¿Sentados abrazados?"

# game/characters_events_idles/sonya_events.rpy:648
translate spanish sonya_scene6_evening_myroom_a3e76380:

    # Sonya "Аниме смотрим. {w}Но он скучный"
    Sonya "Vemos anime. {w}Pero es aburrido"

# game/characters_events_idles/sonya_events.rpy:649
translate spanish sonya_scene6_evening_myroom_28afd6ea:

    # gg "Да, просто аниме"
    gg "Sí, solo anime"

# game/characters_events_idles/sonya_events.rpy:651
translate spanish sonya_scene6_evening_myroom_aa558823:

    # Maya "Не думайте что я этого не видела . . ."
    Maya "No creáis que no he visto eso..."

# game/characters_events_idles/sonya_events.rpy:654
translate spanish sonya_scene6_evening_myroom_eba4c233:

    # Sonya "Спасибо за вечер"
    Sonya "Gracias por la velada"

# game/characters_events_idles/sonya_events.rpy:656
translate spanish sonya_scene6_evening_myroom_e7128efe:

    # Sonya "Было . . . {w} приятно"
    Sonya "Ha sido... {w} agradable"

# game/characters_events_idles/sonya_events.rpy:660
translate spanish sonya_scene6_evening_myroom_222b7c49:

    # Sonya "Давай оставим аниме на завтра"
    Sonya "Dejemos el anime para mañana"

# game/characters_events_idles/sonya_events.rpy:661
translate spanish sonya_scene6_evening_myroom_be1b9cb9:

    # Sonya "Закончим на этом, а то я и сама не остановлюсь"
    Sonya "Terminemos aquí, que si no yo tampoco me paro"

# game/characters_events_idles/sonya_events.rpy:663
translate spanish sonya_scene6_evening_myroom_b989363c:

    # gg ". . ."
    gg "..."

# game/characters_events_idles/sonya_events.rpy:678
translate spanish sonya_scene7_evening_girlroom_0262890b:

    # Sonya "Зайдёшь ко мне?"
    Sonya "¿Vendrás a mi cuarto?"

# game/characters_events_idles/sonya_events.rpy:680
translate spanish sonya_scene7_evening_girlroom_cf65688b:

    # Sonya "Просто . . . {w}хочу поговорить "
    Sonya "Es que... {w}quiero hablar"

# game/characters_events_idles/sonya_events.rpy:682
translate spanish sonya_scene7_evening_girlroom_0609085f:

    # gg "Конечно"
    gg "Claro"

# game/characters_events_idles/sonya_events.rpy:684
translate spanish sonya_scene7_evening_girlroom_fe1b6c78:

    # gg "Ты какая-то задумчивая"
    gg "Estás algo pensativa"

# game/characters_events_idles/sonya_events.rpy:686
translate spanish sonya_scene7_evening_girlroom_24fe6265:

    # Sonya "Да . . ."
    Sonya "Sí..."

# game/characters_events_idles/sonya_events.rpy:688
translate spanish sonya_scene7_evening_girlroom_546a584b:

    # Sonya "Просто не могу всё выкинуть из головы"
    Sonya "Es que no puedo sacármelo de la cabeza"

# game/characters_events_idles/sonya_events.rpy:690
translate spanish sonya_scene7_evening_girlroom_7ff0eaf1:

    # Sonya "Всё как-то закрутилось слишком быстро"
    Sonya "Todo se ha liado demasiado rápido"

# game/characters_events_idles/sonya_events.rpy:692
translate spanish sonya_scene7_evening_girlroom_fb1f6848:

    # gg "В каком смысле?"
    gg "¿En qué sentido?"

# game/characters_events_idles/sonya_events.rpy:694
translate spanish sonya_scene7_evening_girlroom_b7dadb54:

    # Sonya "Ну . . . {w}обычно я держусь спокойно"
    Sonya "Pues... {w}normalmente me mantengo serena"

# game/characters_events_idles/sonya_events.rpy:696
translate spanish sonya_scene7_evening_girlroom_8a221fed:

    # Sonya "Всё у меня под контролем"
    Sonya "Todo lo tengo bajo control"

# game/characters_events_idles/sonya_events.rpy:698
translate spanish sonya_scene7_evening_girlroom_afb359d5:

    # Sonya "Но рядом с тобой . . . {w}всё иначе"
    Sonya "Pero a tu lado... {w}todo es diferente"

# game/characters_events_idles/sonya_events.rpy:700
translate spanish sonya_scene7_evening_girlroom_486c8325:

    # gg "Иначе - это плохо?"
    gg "¿Diferente es malo?"

# game/characters_events_idles/sonya_events.rpy:702
translate spanish sonya_scene7_evening_girlroom_6f2ad814:

    # Sonya "Иногда кажется, что я делаю глупости"
    Sonya "A veces parece que hago tonterías"

# game/characters_events_idles/sonya_events.rpy:704
translate spanish sonya_scene7_evening_girlroom_b81ca64b:

    # Sonya "Такие . . . {w}нелепые"
    Sonya "Unas... {w}ridículas"

# game/characters_events_idles/sonya_events.rpy:706
translate spanish sonya_scene7_evening_girlroom_716ea2d0:

    # Sonya "Будто я снова подросток"
    Sonya "Como si fuera adolescente otra vez"

# game/characters_events_idles/sonya_events.rpy:708
translate spanish sonya_scene7_evening_girlroom_c3165439:

    # gg " . . ."
    gg "..."

# game/characters_events_idles/sonya_events.rpy:710
translate spanish sonya_scene7_evening_girlroom_43cc3ee5:

    # Sonya "Я не уверена в своём поведении"
    Sonya "No estoy segura de mi comportamiento"

# game/characters_events_idles/sonya_events.rpy:711
translate spanish sonya_scene7_evening_girlroom_bf81f51b:

    # Sonya "Может, я слишком тороплюсь"
    Sonya "Tal vez me apresuro demasiado"

# game/characters_events_idles/sonya_events.rpy:713
translate spanish sonya_scene7_evening_girlroom_7263e949:

    # Sonya "Может, выгляжу смешно"
    Sonya "Tal vez parezca ridícula"

# game/characters_events_idles/sonya_events.rpy:715
translate spanish sonya_scene7_evening_girlroom_5c74b5ea:

    # gg "Мне так не кажется"
    gg "A mí no me lo parece"

# game/characters_events_idles/sonya_events.rpy:717
translate spanish sonya_scene7_evening_girlroom_9d42851b:

    # Sonya "А если вдруг?"
    Sonya "¿Y si lo fuera?"

# game/characters_events_idles/sonya_events.rpy:718
translate spanish sonya_scene7_evening_girlroom_6fb3c26c:

    # Sonya "Если я правда не такая, какой должна быть?"
    Sonya "¿Qué pasa si realmente no soy quien debería ser?"

# game/characters_events_idles/sonya_events.rpy:720
translate spanish sonya_scene7_evening_girlroom_5c8cc88c:

    # Sonya "Ты всё равно примешь меня?"
    Sonya "¿Aún me aceptarás?"

# game/characters_events_idles/sonya_events.rpy:727
translate spanish sonya_scene7_evening_girlroom_ca1ff0ec:

    # gg "Мне нравишься настоящая ты"
    gg "Me gusta tu verdadero yo"

# game/characters_events_idles/sonya_events.rpy:730
translate spanish sonya_scene7_evening_girlroom_495fe1ef:

    # gg "Мне не нужно, чтобы ты была какой-то другой"
    gg "No necesito que seas diferente"

# game/characters_events_idles/sonya_events.rpy:746
translate spanish sonya_scene7_evening_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "Gracias..."

# game/characters_events_idles/sonya_events.rpy:747
translate spanish sonya_scene7_evening_girlroom_860f4d16:

    # Sonya "Это именно то что я хотела"
    Sonya "Esto es exactamente lo que quería"

# game/characters_events_idles/sonya_events.rpy:753
translate spanish sonya_scene7_evening_girlroom_489479bc:

    # Sonya "{sc}Да . . . Так . . .{/sc}"
    Sonya "{sc}Sí... Así...{/sc}"

# game/characters_events_idles/sonya_events.rpy:759
translate spanish sonya_scene7_evening_girlroom_2d94ee37:

    # Sonya "На диване ты меня трогал"
    Sonya "En el sofá me tocaste"

# game/characters_events_idles/sonya_events.rpy:760
translate spanish sonya_scene7_evening_girlroom_fc982615:

    # Sonya "Теперь - моя очередь"
    Sonya "Ahora es mi turno"

# game/characters_events_idles/sonya_events.rpy:767
translate spanish sonya_scene7_evening_girlroom_7b973257:

    # Sonya "Смотри на меня"
    Sonya "Mírame"

# game/characters_events_idles/sonya_events.rpy:775
translate spanish sonya_scene7_evening_girlroom_1b8740c5:

    # Sonya "Всё - ты теперь мой!"
    Sonya "Eso es todo, ¡ahora eres mía!"

# game/characters_events_idles/sonya_events.rpy:783
translate spanish sonya_scene7_evening_girlroom_2da445da:

    # Sonya "Подожди тут"
    Sonya "Espera aquí"

# game/characters_events_idles/sonya_events.rpy:785
translate spanish sonya_scene7_evening_girlroom_250fe814:

    # Sonya "Я быстро"
    Sonya "Soy rápida"

# game/characters_events_idles/sonya_events.rpy:791
translate spanish sonya_scene7_evening_girlroom_dadabf98:

    # gg_chat "Это случилось так быстро . . . "
    gg_chat "Sucedió tan rápido..."

# game/characters_events_idles/sonya_events.rpy:798
translate spanish sonya_scene7_evening_girlroom_e844ad84:

    # Sonya "Останься"
    Sonya "Quédate"

# game/characters_events_idles/sonya_events.rpy:800
translate spanish sonya_scene7_evening_girlroom_1d2efc6a:

    # Sonya "Посиди со мной"
    Sonya "Siéntate conmigo"

# game/characters_events_idles/sonya_events.rpy:802
translate spanish sonya_scene7_evening_girlroom_b435d332:

    # Sonya "И посмотрим, куда это нас приведёт."
    Sonya "Y veamos a dónde nos lleva esto."

# game/characters_events_idles/sonya_events.rpy:805
translate spanish sonya_scene7_evening_girlroom_ca91d43d:

    # gg_chat "Было тепло"
    gg_chat "Hacía calor"

# game/characters_events_idles/sonya_events.rpy:806
translate spanish sonya_scene7_evening_girlroom_899d5485:

    # gg_chat "Я хотел остаться рядом"
    gg_chat "Quería estar cerca"

translate spanish strings:

    # game/characters_events_idles/sonya_events.rpy:516
    old "Утро"
    new "Mañana"

    # game/characters_events_idles/sonya_events.rpy:608
    old "Играешь со мной?"
    new "¿Estás jugando conmigo?"

    # game/characters_events_idles/sonya_events.rpy:618
    old "Мне так хорошо"
    new "me siento tan bien"

    # game/characters_events_idles/sonya_events.rpy:725
    old "Такой ты и нужна"
    new "Así es como te necesitan"

    # game/characters_events_idles/sonya_events.rpy:734
    old "Поцеловать"
    new "Beso"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/sonya_events.rpy:20
translate spanish sonya_scene1_morning_kitchen_c92bc08a:

    # Sonya "Там диван, конечно, старый"
    Sonya "El sofá de allí, claro, es viejo"

# game/characters_events_idles/sonya_events.rpy:50
translate spanish sonya_scene1_morning_kitchen_12302e27:

    # Sonya "У нас, обычно, никто особо не спрашивает"
    Sonya "Aquí normalmente nadie pregunta demasiado"

# game/characters_events_idles/sonya_events.rpy:161
translate spanish sonya_scene2_day_girlroom_9c553288:

    # Sonya "Так и планировал . . ."
    Sonya "Lo tenía planeado así..."

# game/characters_events_idles/sonya_events.rpy:177
translate spanish sonya_scene2_day_girlroom_c5761118:

    # Sonya "Ты, получается, больше утренний человек?"
    Sonya "¿Resulta que eres más de mañanas?"

# game/characters_events_idles/sonya_events.rpy:335
translate spanish sonya_scene3_day_bathroom_21f8234f:

    # Sonya "Горячий, аккуратнее"
    Sonya "Cuidado, está caliente"

# game/characters_events_idles/sonya_events.rpy:383
translate spanish sonya_scene4_morning_bathroom_0d2b005c:

    # gg "Да, где-то я уже такое видел"
    gg "Sí, algo así ya lo he visto en alguna parte"

# game/characters_events_idles/sonya_events.rpy:385
translate spanish sonya_scene4_morning_bathroom_11b14ed3:

    # Sonya "Ты смотришь . . ."
    Sonya "Tú miras..."

# game/characters_events_idles/sonya_events.rpy:486
translate spanish sonya_scene5_night_girlroom_44967887:

    # Sonya "Я не хочу ни о чем думать . . ."
    Sonya "No quiero pensar en nada..."


# game/characters_events_idles/sonya_events.rpy:835
translate spanish sonya_scene8_morning_kitchen_a482bb49:

    # gg "Утречка"
    gg "Buenos días"

# game/characters_events_idles/sonya_events.rpy:837
translate spanish sonya_scene8_morning_kitchen_ce42d6cf:

    # Sonya "Доброе утро . . ."
    Sonya "Buenos días . . ."

# game/characters_events_idles/sonya_events.rpy:839
translate spanish sonya_scene8_morning_kitchen_72c13c11:

    # Sonya "Я . . . почти закончила готовить, садись"
    Sonya "Yo . . . casi he terminado de cocinar, siéntate"

# game/characters_events_idles/sonya_events.rpy:842
translate spanish sonya_scene8_morning_kitchen_bb1eb7c8:

    # gg "Ты рано встала"
    gg "Te levantaste temprano"

# game/characters_events_idles/sonya_events.rpy:844
translate spanish sonya_scene8_morning_kitchen_42ef4d92:

    # Sonya "Не спалось"
    Sonya "No pude dormir"

# game/characters_events_idles/sonya_events.rpy:846
translate spanish sonya_scene8_morning_kitchen_a756dcde:

    # Sonya "Подумала . . ."
    Sonya "Pensé . . ."

# game/characters_events_idles/sonya_events.rpy:848
translate spanish sonya_scene8_morning_kitchen_381d05fd:

    # Sonya "Раз ты всё равно проснёшься . . ."
    Sonya "Como te vas a despertar de todos modos . . ."

# game/characters_events_idles/sonya_events.rpy:850
translate spanish sonya_scene8_morning_kitchen_13f1fe10:

    # Sonya "Будет хорошо, заранее приготовить тебе"
    Sonya "Será bueno prepararte algo por adelantado"

# game/characters_events_idles/sonya_events.rpy:861
translate spanish sonya_scene8_morning_kitchen_c3201521:

    # Sonya "Можно?"
    Sonya "¿Está bien?"

# game/characters_events_idles/sonya_events.rpy:865
translate spanish sonya_scene8_morning_kitchen_0609085f:

    # gg "Конечно"
    gg "Claro"

# game/characters_events_idles/sonya_events.rpy:870
translate spanish sonya_scene8_morning_kitchen_f49db0d9:

    # gg "Очень вкусно"
    gg "Está muy rico"

# game/characters_events_idles/sonya_events.rpy:872
translate spanish sonya_scene8_morning_kitchen_6f15bff0:

    # Sonya "Я рада"
    Sonya "Me alegra"

# game/characters_events_idles/sonya_events.rpy:874
translate spanish sonya_scene8_morning_kitchen_8bd5d020:

    # Sonya "Мне важно, чтобы тебе было хорошо"
    Sonya "Es importante para mí que estés bien"

# game/characters_events_idles/sonya_events.rpy:882
translate spanish sonya_scene8_morning_kitchen_41dbce33:

    # Sonya "Я всю ночь думала . . ."
    Sonya "Estuve pensando toda la noche . . ."

# game/characters_events_idles/sonya_events.rpy:885
translate spanish sonya_scene8_morning_kitchen_f519c6fc:

    # Sonya "Раньше я беспокоилась"
    Sonya "Antes me preocupaba"

# game/characters_events_idles/sonya_events.rpy:887
translate spanish sonya_scene8_morning_kitchen_b0e09a72:

    # Sonya "А сегодня . . ."
    Sonya "Pero hoy . . ."

# game/characters_events_idles/sonya_events.rpy:889
translate spanish sonya_scene8_morning_kitchen_814991c8:

    # Sonya "Мне спокойно"
    Sonya "Me siento tranquila"

# game/characters_events_idles/sonya_events.rpy:898
translate spanish sonya_scene8_morning_kitchen_d0794f94:

    # Sonya "Если ты не против . . ."
    Sonya "Si no te molesta . . ."

# game/characters_events_idles/sonya_events.rpy:900
translate spanish sonya_scene8_morning_kitchen_9c748c84:

    # Sonya "Я могу . . ."
    Sonya "Puedo . . ."

# game/characters_events_idles/sonya_events.rpy:904
translate spanish sonya_scene8_morning_kitchen_a877578e:

    # Sonya "Быть чуть ближе"
    Sonya "Estar un poco más cerca"

# game/characters_events_idles/sonya_events.rpy:926
translate spanish sonya_scene8_morning_kitchen_1b7d05a8:

    # Sonya "Чувствовать, как ты становишься твёрже . . ."
    Sonya "Sentir como te vas poniendo más firme . . ."

# game/characters_events_idles/sonya_events.rpy:927
translate spanish sonya_scene8_morning_kitchen_b85aacb1:

    # Sonya "От моего прикосновения . . . {w}это так . . ."
    Sonya "Por mi toque . . . {w}es tan . . ."

# game/characters_events_idles/sonya_events.rpy:928
translate spanish sonya_scene8_morning_kitchen_9213f2a8:

    # Sonya ". . . Заводит. {w}Сильнее, чем я думала"
    Sonya ". . . Me excita. {w}Más de lo que pensaba"

# game/characters_events_idles/sonya_events.rpy:929
translate spanish sonya_scene8_morning_kitchen_9bc062d5:

    # Sonya "Смотри на меня . . . только на меня . . ."
    Sonya "Mírame . . . solo a mí . . ."

# game/characters_events_idles/sonya_events.rpy:940
translate spanish sonya_scene8_morning_kitchen_55a277bb:

    # Sonya "Я . . . не знаю, как правильно это сказать . . ."
    Sonya "Yo . . . no sé cómo decirlo correctamente . . ."

# game/characters_events_idles/sonya_events.rpy:942
translate spanish sonya_scene8_morning_kitchen_beb08d03:

    # Sonya "Но мне хорошо, когда ты рядом"
    Sonya "Pero me siento bien cuando estás cerca"

# game/characters_events_idles/sonya_events.rpy:961
translate spanish sonya_scene9_night_myroom_9a8b0be2:

    # gg "Привет"
    gg "Hola"

# game/characters_events_idles/sonya_events.rpy:963
translate spanish sonya_scene9_night_myroom_b3a2b8a1:

    # Sonya "Привет ты ещё не ложишься?"
    Sonya "Hola, ¿aún no te vas a acostar?"

# game/characters_events_idles/sonya_events.rpy:965
translate spanish sonya_scene9_night_myroom_bb3c3085:

    # Sonya "Тогда пойдём вместе в ванную?"
    Sonya "¿Entonces vamos juntos al baño?"

# game/characters_events_idles/sonya_events.rpy:967
translate spanish sonya_scene9_night_myroom_9afefc8e:

    # Sonya "Я хочу голову помыть . . ."
    Sonya "Quiero lavarme el cabello . . ."

# game/characters_events_idles/sonya_events.rpy:969
translate spanish sonya_scene9_night_myroom_b4639877:

    # Sonya "И тебе тоже"
    Sonya "Y a ti también"

# game/characters_events_idles/sonya_events.rpy:971
translate spanish sonya_scene9_night_myroom_66416cc5:

    # gg "Ну пойдем"
    gg "Vamos entonces"

# game/characters_events_idles/sonya_events.rpy:981
translate spanish sonya_scene9_night_myroom_c5d3f2b1:

    # Sonya "Ты тоже раздевайся давай"
    Sonya "Quítate la ropa también, vamos"

# game/characters_events_idles/sonya_events.rpy:987
translate spanish sonya_scene9_night_myroom_ebd2cc14:

    # Sonya "Подожди . . ."
    Sonya "Espera . . ."

# game/characters_events_idles/sonya_events.rpy:989
translate spanish sonya_scene9_night_myroom_abb56970:

    # Sonya "У тебя молния заела"
    Sonya "Tienes la cremallera atorada"

# game/characters_events_idles/sonya_events.rpy:996
translate spanish sonya_scene9_night_myroom_3672b0c0:

    # Sonya "Быстро ты . . ."
    Sonya "Qué rápido eres . . ."

# game/characters_events_idles/sonya_events.rpy:998
translate spanish sonya_scene9_night_myroom_ba83a14c:

    # Sonya "Давай садись"
    Sonya "Siéntate, vamos"

# game/characters_events_idles/sonya_events.rpy:1000
translate spanish sonya_scene9_night_myroom_674bc70f:

    # Sonya "Стой . . . не двигайся"
    Sonya "Espera . . . no te muevas"

# game/characters_events_idles/sonya_events.rpy:1002
translate spanish sonya_scene9_night_myroom_dc365125:

    # Sonya "Я хочу сама"
    Sonya "Quiero hacerlo yo misma"

# game/characters_events_idles/sonya_events.rpy:1006
translate spanish sonya_scene9_night_myroom_9c274529:

    # gg "У меня отличный вид"
    gg "Tengo una excelente vista"

# game/characters_events_idles/sonya_events.rpy:1008
translate spanish sonya_scene9_night_myroom_4af82ab0:

    # Sonya "Я знаю"
    Sonya "Lo sé"

# game/characters_events_idles/sonya_events.rpy:1010
translate spanish sonya_scene9_night_myroom_d339691d:

    # Sonya "Мне просто приятно, что ты смотришь"
    Sonya "Me gusta que me mires"

# game/characters_events_idles/sonya_events.rpy:1012
translate spanish sonya_scene9_night_myroom_98944675:

    # Sonya "Теперь ты меня"
    Sonya "Ahora me tienes"

# game/characters_events_idles/sonya_events.rpy:1016
translate spanish sonya_scene9_night_myroom_06da4938:

    # Sonya "Ты точно будешь пахнуть как я"
    Sonya "Seguro que olerás a mí"

# game/characters_events_idles/sonya_events.rpy:1018
translate spanish sonya_scene9_night_myroom_aa254d79:

    # Sonya "Ты такой тёплый сейчас . . . мне это нравится"
    Sonya "Estás tan cálido ahora . . . me gusta eso"

# game/characters_events_idles/sonya_events.rpy:1020
translate spanish sonya_scene9_night_myroom_908db179:

    # Sonya "Пойдём спать вместе"
    Sonya "Vamos a dormir juntos"

# game/characters_events_idles/sonya_events.rpy:1022
translate spanish sonya_scene9_night_myroom_e190b45e:

    # Sonya "Я не хочу сегодня одна"
    Sonya "No quiero estar sola hoy"

# game/characters_events_idles/sonya_events.rpy:1024
translate spanish sonya_scene9_night_myroom_dd09f522:

    # Sonya "Но на сегодня приключений хватит . . . а то я завтра вообще не проснусь"
    Sonya "Pero ya basta de aventuras por hoy . . . si no, no me despertaré mañana"

# game/characters_events_idles/sonya_events.rpy:1031
translate spanish sonya_scene9_night_myroom_654cb5b3:

    # Sonya "Спокойной ночи"
    Sonya "Buenas noches"

# game/characters_events_idles/sonya_events.rpy:1032
translate spanish sonya_scene9_night_myroom_5e65cbb1:

    # Sonya "{bt=a3-p2.0-s3.0}Любимый"
    Sonya "{bt=a3-p2.0-s3.0}Cariño"

# game/characters_events_idles/sonya_events.rpy:1038
translate spanish sonya_scene9_night_myroom_7f924e87:

    # gg "Спокойной"
    gg "Buenas"

# game/characters_events_idles/sonya_events.rpy:1039
translate spanish sonya_scene9_night_myroom_02749544:

    # gg "Я правда рад, что я с тобой"
    gg "Realmente me alegra estar contigo"


