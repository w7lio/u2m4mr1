﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/maya_idles.rpy:7
translate spanish maya_Idle_day_myroom_scene_5a17c289:

    # gg "А я думал, этот предатель спит только у Сони"
    gg "Y yo que pensaba que este traidor solo dormía en casa de Sonya"

# game/characters_events_idles/maya_idles.rpy:9
translate spanish maya_Idle_day_myroom_scene_67e33434:

    # Maya "Он выбирает по настроению"
    Maya "Él elige según su estado de ánimo"

# game/characters_events_idles/maya_idles.rpy:10
translate spanish maya_Idle_day_myroom_scene_d5b84977:

    # Maya "Сегодня, видимо, у меня нужная температура коленей"
    Maya "Hoy, al parecer, mis rodillas tienen la temperatura adecuada"

# game/characters_events_idles/maya_idles.rpy:11
translate spanish maya_Idle_day_myroom_scene_60432ccb:

    # gg "Или просто знаешь, чем подкупить"
    gg "O simplemente sabes cómo sobornarlo"

# game/characters_events_idles/maya_idles.rpy:13
translate spanish maya_Idle_day_myroom_scene_e3e70aea:

    # Maya "Конечно"
    Maya "Claro"

# game/characters_events_idles/maya_idles.rpy:14
translate spanish maya_Idle_day_myroom_scene_d43eb27c:

    # Maya "Я его нашла - я и лицензированный поставщик любви и корма"
    Maya "Yo lo encontré, así que soy la proveedora autorizada de amor y comida"

# game/characters_events_idles/maya_idles.rpy:15
translate spanish maya_Idle_day_myroom_scene_567c8898:

    # gg "Нашла?"
    gg "¿Lo encontraste?"

# game/characters_events_idles/maya_idles.rpy:17
translate spanish maya_Idle_day_myroom_scene_a785c258:

    # Maya "Год назад. Под дождём, под машиной сидел"
    Maya "Hace un año. Bajo la lluvia, sentado bajo un coche"

# game/characters_events_idles/maya_idles.rpy:18
translate spanish maya_Idle_day_myroom_scene_81fc3249:

    # Maya "Маленький, грязный, дрожал, а я шла домой с кофе"
    Maya "Pequeño, sucio, temblando, y yo volvía a casa con un café"

# game/characters_events_idles/maya_idles.rpy:19
translate spanish maya_Idle_day_myroom_scene_f0aa2ab7:

    # Maya "И подумала: “Ладно, кофе подождёт”"
    Maya "Y pensé: 'Vale, el café puede esperar'"

# game/characters_events_idles/maya_idles.rpy:21
translate spanish maya_Idle_day_myroom_scene_8924b2a5:

    # Maya "С тех пор он решил, что я его персональный обогреватель"
    Maya "Desde entonces decidió que soy su calefactor personal"

# game/characters_events_idles/maya_idles.rpy:23
translate spanish maya_Idle_day_myroom_scene_38f294e2:

    # gg "Повезло ему"
    gg "Qué suerte tiene"

# game/characters_events_idles/maya_idles.rpy:25
translate spanish maya_Idle_day_myroom_scene_1538c3c1:

    # Maya "Ага. Только не говори Соне, что я так сказала"
    Maya "Sí. Solo no le digas a Sonya que lo dije"

# game/characters_events_idles/maya_idles.rpy:26
translate spanish maya_Idle_day_myroom_scene_d9ab69f9:

    # Maya "Она делает вид, что ей всё равно, но я видела, как она однажды сушила ему лапы феном"
    Maya "Ella finge que no le importa, pero la vi una vez secándole las patas con un secador"

# game/characters_events_idles/maya_idles.rpy:27
translate spanish maya_Idle_day_myroom_scene_5e0ad0a7:

    # gg "Правда? Не ожидал"
    gg "¿En serio? No me lo esperaba"

# game/characters_events_idles/maya_idles.rpy:28
translate spanish maya_Idle_day_myroom_scene_e31c6d2d:

    # Maya "Ну, она просто не из тех, кто сюсюкает. Но и не выгонит"
    Maya "Bueno, ella no es de las que hacen mimitos. Pero tampoco lo echaría"

# game/characters_events_idles/maya_idles.rpy:29
translate spanish maya_Idle_day_myroom_scene_5e1c1537:

    # Maya "Иногда подкармливает, когда думает, что я не вижу"
    Maya "A veces le da comida extra cuando cree que no la veo"

# game/characters_events_idles/maya_idles.rpy:30
translate spanish maya_Idle_day_myroom_scene_dd7932db:

    # Maya "У нас, знаешь, баланс: я - шум, она - порядок, а Барсик - нейтральная территория"
    Maya "Tenemos, ya sabes, un equilibrio: yo soy el ruido, ella es el orden, y Barsik es territorio neutral"

# game/aracters_events_idles/maya_idles.rpy:31
translate spanish maya_Idle_day_myroom_scene_ff61f178:

    # gg "И кто из вас лидер?"
    gg "¿Y quién de ustedes es el líder?"

# game/characters_events_idles/maya_idles.rpy:33
translate spanish maya_Idle_day_myroom_scene_4579d2be:

    # Maya "Он. Сто процентов"
    Maya "Él. Cien por ciento"

# game/characters_events_idles/maya_idles.rpy:34
translate spanish maya_Idle_day_myroom_scene_73c39706:

    # Maya "Ему всё равно, кто орёт, кто убирает - он всё равно получает своё место и миску"
    Maya "A él no le importa quién grita, quién limpia, igual consigue su sitio y su plato"

# game/characters_events_idles/maya_idles.rpy:36
translate spanish maya_Idle_day_myroom_scene_c39583ae:

    # Maya "Видишь? {w}Даже в доме с нами двумя кто-то умеет быть по-настоящему счастливым"
    Maya "¿Ves? {w}Incluso en una casa con nosotras dos, alguien sabe ser realmente feliz"

# game/characters_events_idles/maya_idles.rpy:38
translate spanish maya_Idle_day_myroom_scene_04531df3:

    # gg "Может, секрет в том, чтобы просто мурчать и не спорить"
    gg "Quizás el secreto es simplemente ronronear y no discutir"

# game/characters_events_idles/maya_idles.rpy:39
translate spanish maya_Idle_day_myroom_scene_25a0e3ac:

    # Maya "Или в том, чтобы спать на тёплом и не думать"
    Maya "O es dormir en un sitio calentito y no pensar"

# game/characters_events_idles/maya_idles.rpy:54
translate spanish maya_Idle_morning_myroom_scene_323bf253:

    # gg "Уже читаешь? . . ."
    gg "¿Ya estás leyendo?..."

# game/characters_events_idles/maya_idles.rpy:55
translate spanish maya_Idle_morning_myroom_scene_92e4f307:

    # Maya "Ага. Утро тихое, редкость"
    Maya "Sí. Mañana tranquila, una rareza"

# game/characters_events_idles/maya_idles.rpy:56
translate spanish maya_Idle_morning_myroom_scene_43a1c1b0:

    # Maya "Грех не пользоваться, пока никто не шумит и не ищет кружку"
    Maya "Es un pecado no aprovechar mientras nadie hace ruido ni busca una taza"

# game/characters_events_idles/maya_idles.rpy:57
translate spanish maya_Idle_morning_myroom_scene_7ac1c8ed:

    # gg "Что на этот раз?"
    gg "¿Qué lees esta vez?"

# game/characters_events_idles/maya_idles.rpy:59
translate spanish maya_Idle_morning_myroom_scene_6a78f6bb:

    # Maya "Манга"
    Maya "Manga"

# game/characters_events_idles/maya_idles.rpy:60
translate spanish maya_Idle_morning_myroom_scene_932f7db6:

    # Maya "После Линдиных книг захотелось чего-то полегче"
    Maya "Después de los libros de Linda, apetecía algo más ligero"

# game/characters_events_idles/maya_idles.rpy:62
translate spanish maya_Idle_morning_myroom_scene_cffdb9b8:

    # Maya "Она могла читать про философию даже за ужином"
    Maya "Ella podía leer sobre filosofía incluso durante la cena"

# game/characters_events_idles/maya_idles.rpy:63
translate spanish maya_Idle_morning_myroom_scene_3d9df54a:

    # Maya "Я же за ужином максимум комментирую философию людей в интернете"
    Maya "Yo, durante la cena, como mucho comento la filosofía de la gente en internet"

# game/characters_events_idles/maya_idles.rpy:65
translate spanish maya_Idle_morning_myroom_scene_c6ff46fa:

    # Maya "Хотя по этой манге не скажешь"
    Maya "Aunque con este manga no lo dirías"

# game/characters_events_idles/maya_idles.rpy:66
translate spanish maya_Idle_morning_myroom_scene_5ff05dc4:

    # Maya "Автор явно страдал, но красиво"
    Maya "El autor claramente sufrió, pero de una manera hermosa"

# game/characters_events_idles/maya_idles.rpy:67
translate spanish maya_Idle_morning_myroom_scene_f96de996:

    # gg "К картинкам и эмоциям?"
    gg "¿A las imágenes y las emociones?"

# game/characters_events_idles/maya_idles.rpy:69
translate spanish maya_Idle_morning_myroom_scene_b2396673:

    # Maya "К историям, где герои хотя бы честные"
    Maya "A las historias donde los protagonistas son al menos honestos"

# game/characters_events_idles/maya_idles.rpy:71
translate spanish maya_Idle_morning_myroom_scene_6e6a997d:

    # Maya "Иногда читаю японское или корейское"
    Maya "A veces leo japonés o coreano"

# game/characters_events_idles/maya_idles.rpy:72
translate spanish maya_Idle_morning_myroom_scene_3aeeaab4:

    # Maya "У них всё немного грустно, но по-тёплому"
    Maya "Todo es un poco triste con ellos, pero de una manera cálida"

# game/characters_events_idles/maya_idles.rpy:73
translate spanish maya_Idle_morning_myroom_scene_d16d1737:

    # Maya "В отличие от наших драм, где все страдают просто из принципа"
    Maya "A diferencia de nuestros dramas, donde todo el mundo sufre solo por principio"

# game/characters_events_idles/maya_idles.rpy:74
translate spanish maya_Idle_morning_myroom_scene_0bb250f6:

    # gg "Под настроение, значит"
    gg "Según el estado de ánimo, entonces"

# game/characters_events_idles/maya_idles.rpy:76
translate spanish maya_Idle_morning_myroom_scene_bc0bb57f:

    # Maya "Угу. Когда настроение “оставьте меня в покое, но с уютом”"
    Maya "Ajá. Cuando el estado de ánimo es 'déjenme en paz, pero con comodidad'"

# game/characters_events_idles/maya_idles.rpy:77
translate spanish maya_Idle_morning_myroom_scene_c92c399c:

    # gg "Ты давно здесь?"
    gg "¿Llevas mucho tiempo aquí?"

# game/characters_events_idles/maya_idles.rpy:79
translate spanish maya_Idle_morning_myroom_scene_8b0e76c6:

    # Maya "Год, может чуть больше"
    Maya "Un año, quizá un poco más"

# game/characters_events_idles/maya_idles.rpy:80
translate spanish maya_Idle_morning_myroom_scene_924b98a2:

    # Maya "После универа приехала в посёлок работать. Захотелось тишины и воздуха"
    Maya "Después de la universidad vine al pueblo a trabajar. Quería silencio y aire fresco"

# game/characters_events_idles/maya_idles.rpy:82
translate spanish maya_Idle_morning_myroom_scene_f611f1fe:

    # Maya "Искала жильё - наткнулась на объявление: “Сдам комнату. Дом с садом”"
    Maya "Buscaba alojamiento y me encontré con un anuncio: 'Alquilo habitación. Casa con jardín'"

# game/characters_events_idles/maya_idles.rpy:83
translate spanish maya_Idle_morning_myroom_scene_12f76597:

    # Maya "Открывает дверь Линда и спрашивает: “Ты громкая?”"
    Maya "Linda abre la puerta y pregunta: '¿Eres ruidosa?'"

# game/characters_events_idles/maya_idles.rpy:84
translate spanish maya_Idle_morning_myroom_scene_5517b596:

    # Maya "Я ответила: “Только когда думаю.” Она засмеялась и сказала: “Тогда уживайся”"
    Maya "Yo respondí: 'Solo cuando pienso.' Ella se rió y dijo: 'Entonces, aclámate'"

# game/characters_events_idles/maya_idles.rpy:85
translate spanish maya_Idle_morning_myroom_scene_20b975de:

    # gg "И Соня уже тут была?"
    gg "¿Y Sonya ya estaba aquí?"

# game/characters_events_idles/maya_idles.rpy:87
translate spanish maya_Idle_morning_myroom_scene_37745fdb:

    # Maya "Да. Мы познакомились на кухне, где я чуть не спалила чайник"
    Maya "Sí. Nos conocimos en la cocina, donde casi quemo la tetera"

# game/characters_events_idles/maya_idles.rpy:88
translate spanish maya_Idle_morning_myroom_scene_4e7209b5:

    # Maya "С тех пор она - порядок, я - импровизация"
    Maya "Desde entonces ella es el orden, yo soy la improvisación"

# game/characters_events_idles/maya_idles.rpy:89
translate spanish maya_Idle_morning_myroom_scene_f337d502:

    # Maya "Иногда даже чай кипит от ужаса"
    Maya "A veces hasta el té hierve del susto"

# game/characters_events_idles/maya_idles.rpy:90
translate spanish maya_Idle_morning_myroom_scene_b1814b27:

    # Maya "Линда звала нас “шум и тишина”"
    Maya "Linda nos llamaba 'el ruido y el silencio'"

# game/characters_events_idles/maya_idles.rpy:91
translate spanish maya_Idle_morning_myroom_scene_ab4dac88:

    # Maya "Хотя, скорее, “тишина и источник хаоса”"
    Maya "Aunque más bien, 'el silencio y la fuente del caos'"

# game/characters_events_idles/maya_idles.rpy:92
translate spanish maya_Idle_morning_myroom_scene_f2159d17:

    # gg "А теперь ещё и я"
    gg "Y ahora yo también"

# game/characters_events_idles/maya_idles.rpy:94
translate spanish maya_Idle_morning_myroom_scene_ecb2ad9f:

    # Maya "Теперь да. Баланс окончательно нарушен, но зато весело"
    Maya "Ahora sí. El equilibrio está completamente roto, pero es divertido"

# game/characters_events_idles/maya_idles.rpy:96
translate spanish maya_Idle_morning_myroom_scene_cea1d0c9:

    # Maya "Вон, слышишь? Она уже с шести на ногах"
    Maya "Mira, ¿oyes? Ella ya está en pie desde las seis"

# game/characters_events_idles/maya_idles.rpy:97
translate spanish maya_Idle_morning_myroom_scene_deefee09:

    # Maya "Я так пробовала - уснула прямо с кружкой в руке"
    Maya "Lo intenté una vez, me quedé dormida con la taza en la mano"

# game/characters_events_idles/maya_idles.rpy:98
translate spanish maya_Idle_morning_myroom_scene_bd135488:

    # Maya "Зато хоть кто-то следит, чтобы дом не просыпался в хаосе. Я - больше за безделие"
    Maya "Pero al menos alguien se asegura de que la casa no se despierte en el caos. Yo soy más de la holgazanería"

# game/characters_events_idles/maya_idles.rpy:113
translate spanish maya_Idle_evening_bathroom_scene_d8fba7e0:

    # gg "Ко сну готовишься?"
    gg "¿Preparándote para dormir?"

# game/characters_events_idles/maya_idles.rpy:114
translate spanish maya_Idle_evening_bathroom_scene_768e9905:

    # Maya "Ага. Осталось немного. Главное, чтобы никто не отвлекал"
    Maya "Sí. Ya queda poco. Lo principal es que nadie me distraiga"

# game/characters_events_idles/maya_idles.rpy:115
translate spanish maya_Idle_evening_bathroom_scene_c84b09d3:

    # Maya "А то всё придётся начинать заново — тут процесс деликатный"
    Maya "O si no, habrá que empezar de nuevo, es un proceso delicado"

# game/characters_events_idles/maya_idles.rpy:116
translate spanish maya_Idle_evening_bathroom_scene_ff89b4d4:

    # gg "Надеюсь, ты не про стирку опять"
    gg "Espero que no sea lo de lavar la ropa otra vez"

# game/characters_events_idles/maya_idles.rpy:118
translate spanish maya_Idle_evening_bathroom_scene_63a219ac:

    # Maya "А что, если и про неё? Не все вещи выдерживают жёсткий режим"
    Maya "¿Y si lo es? No todas las prendas aguantan un ciclo intenso"

# game/characters_events_idles/maya_idles.rpy:119
translate spanish maya_Idle_evening_bathroom_scene_16a58674:

    # gg "В прошлый раз ты, кажется, не всё достирала"
    gg "La última vez, creo que no terminaste de lavarlo todo"

# game/characters_events_idles/maya_idles.rpy:121
translate spanish maya_Idle_evening_bathroom_scene_6782c239:

    # Maya "Ха. Ну, издержки ручной работы. Зато результат запомнился, верно?"
    Maya "Ja. Bueno, los inconvenientes del trabajo manual. Pero el resultado fue memorable, ¿verdad?"

# game/characters_events_idles/maya_idles.rpy:122
translate spanish maya_Idle_evening_bathroom_scene_d25c24db:

    # gg "Даже слишком"
    gg "Incluso demasiado"

# game/characters_events_idles/maya_idles.rpy:124
translate spanish maya_Idle_evening_bathroom_scene_a5bb0cfc:

    # Maya "Значит, не зря старалась"
    Maya "Entonces, no me esforcé en vano"

# game/characters_events_idles/maya_idles.rpy:126
translate spanish maya_Idle_evening_bathroom_scene_91354786:

    # Maya "Правда, немного смущалась. Такое со мной редко бывает"
    Maya "La verdad, me dio un poco de vergüenza. Eso no me pasa a menudo"

# game/characters_events_idles/maya_idles.rpy:127
translate spanish maya_Idle_evening_bathroom_scene_2b597177:

    # gg "Удивительно. Я думал, ты вообще не из тех, кто смущается"
    gg "Qué sorpresa. Pensaba que no eras del tipo que se avergüenza"

# game/characters_events_idles/maya_idles.rpy:129
translate spanish maya_Idle_evening_bathroom_scene_aa3db339:

    # Maya "Все когда-то ошибаются. Но не переживай, в следующий раз я компенсирую моральный ущерб"
    Maya "Todo el mundo se equivoca alguna vez. Pero no te preocupes, la próxima vez compensaré el daño moral"

# game/characters_events_idles/maya_idles.rpy:130
translate spanish maya_Idle_evening_bathroom_scene_ed2cbd06:

    # gg "Это угроза или обещание?"
    gg "¿Es una amenaza o una promesa?"

# game/characters_events_idles/maya_idles.rpy:132
translate spanish maya_Idle_evening_bathroom_scene_0f1383f3:

    # Maya "Назови это приглашением на повторный эксперимент"
    Maya "Llámala una invitación para repetir el experimento"

# game/characters_events_idles/maya_idles.rpy:147
translate spanish maya_Idle_morning_kitchen_scene_ff259315:

    # gg "Это так теперь готовят яищницу?"
    gg "¿Así es como se hacen ahora los huevos revueltos?"

# game/characters_events_idles/maya_idles.rpy:148
translate spanish maya_Idle_morning_kitchen_scene_2a72a3a2:

    # Maya "Умник. Не все рождаются с магией кулинарии, ладно?"
    Maya "Listillo. No todo el mundo nace con la magia de la cocina, ¿vale?"

# game/characters_events_idles/maya_idles.rpy:149
translate spanish maya_Idle_morning_kitchen_scene_5c70bf26:

    # Maya "Обычно Соня этим занимается"
    Maya "Normalmente Sonya se encarga de esto"

# game/characters_events_idles/maya_idles.rpy:151
translate spanish maya_Idle_morning_kitchen_scene_602f32f7:

    # Maya "Вот, видишь? Сковородка меня ненавидит"
    Maya "¿Ves? La sartén me odia"

# game/characters_events_idles/maya_idles.rpy:152
translate spanish maya_Idle_morning_kitchen_scene_6441a501:

    # gg "Ага, ты с ней просто не разговариваешь достаточно вежливо"
    gg "Sí, es que no le hablas con suficiente educación"

# game/characters_events_idles/maya_idles.rpy:154
translate spanish maya_Idle_morning_kitchen_scene_92534113:

    # Maya "Серьёзно? Может, ей ещё комплимент сказать?"
    Maya "¿En serio? ¿Quizás también debería hacerle un cumplido?"

# game/characters_events_idles/maya_idles.rpy:155
translate spanish maya_Idle_morning_kitchen_scene_9a46a58c:

    # gg "Можешь попробовать. Я подстрахую, если начнёт мстить"
    gg "Podrías intentarlo. Te respaldaré si empieza a vengarse"

# game/characters_events_idles/maya_idles.rpy:157
translate spanish maya_Idle_morning_kitchen_scene_f6d334fe:

    # Maya "Вот именно поэтому я по утрам не встаю"
    Maya "Por eso mismo no me levanto por las mañanas"

# game/characters_events_idles/maya_idles.rpy:159
translate spanish maya_Idle_morning_kitchen_scene_b8a73fc6:

    # Maya "Мир в это время суток явно против меня"
    Maya "El mundo claramente está en mi contra a esta hora del día"

# game/characters_events_idles/maya_idles.rpy:160
translate spanish maya_Idle_morning_kitchen_scene_92828b86:

    # gg "А я думал, это просто твой ритуал - проспать завтрак и появиться к обеду"
    gg "Y yo que pensaba que era solo tu ritual: dormir durante el desayuno y aparecer para el almuerzo"

# game/characters_events_idles/maya_idles.rpy:162
translate spanish maya_Idle_morning_kitchen_scene_2d194bcc:

    # Maya "Был"
    Maya "Lo era"

# game/characters_events_idles/maya_idles.rpy:163
translate spanish maya_Idle_morning_kitchen_scene_06f3f849:

    # Maya "Но с твоим появлением режим сбился"
    Maya "Pero con tu llegada el ritmo se desbarató"

# game/characters_events_idles/maya_idles.rpy:165
translate spanish maya_Idle_morning_kitchen_scene_c5cd9bdc:

    # Maya "Знаешь . . . {w}странно, когда в доме появился кто-то третий"
    Maya "Sabes... {w}es raro cuando aparece una tercera persona en la casa"

# game/characters_events_idles/maya_idles.rpy:167
translate spanish maya_Idle_morning_kitchen_scene_2d60322d:

    # gg "“Странно” - в хорошем смысле?"
    gg "'Raro', ¿en el buen sentido?"

# game/characters_events_idles/maya_idles.rpy:169
translate spanish maya_Idle_morning_kitchen_scene_0392e6e1:

    # Maya "Скорее . . . непривычно"
    Maya "Más bien... poco habitual"

# game/characters_events_idles/maya_idles.rpy:170
translate spanish maya_Idle_morning_kitchen_scene_09dca06f:

    # Maya "Мы с Соней как будто уже притёрлись. У неё - тишина, у меня - беспорядок"
    Maya "Sonya y yo ya nos habíamos adaptado la una a la otra. Con ella reina la calma, conmigo, el caos"

# game/characters_events_idles/maya_idles.rpy:171
translate spanish maya_Idle_morning_kitchen_scene_f70c520e:

    # Maya "А теперь добавился ты. И вроде ничего не изменилось, но стало . . . другое"
    Maya "Y ahora te sumaste tú. Y aunque en apariencia nada ha cambiado, se siente... diferente"

# game/characters_events_idles/maya_idles.rpy:173
translate spanish maya_Idle_morning_kitchen_scene_ac44cc52:

    # gg "Надеюсь, не хуже"
    gg "Espero que no sea a peor"

# game/characters_events_idles/maya_idles.rpy:174
translate spanish maya_Idle_morning_kitchen_scene_7331e581:

    # Maya "Пока нет"
    Maya "De momento, no"

# game/characters_events_idles/maya_idles.rpy:175
translate spanish maya_Idle_morning_kitchen_scene_a84e22a5:

    # Maya "Иногда даже спокойнее . . . а иногда бесишь"
    Maya "A veces incluso es más tranquilo... y a veces me sacas de quicio"

# game/characters_events_idles/maya_idles.rpy:190
translate spanish maya_Idle_day_kitchen_scene_1cdbaa35:

    # gg "Не верится"
    gg "No me lo creo"

# game/characters_events_idles/maya_idles.rpy:191
translate spanish maya_Idle_day_kitchen_scene_286ac20b:

    # gg "Ты с чаем? Где же твоя коллекция вредных газировок?"
    gg "¿Estás tomando té? ¿Dónde está tu colección de refrescos dañinos?"

# game/characters_events_idles/maya_idles.rpy:193
translate spanish maya_Idle_day_kitchen_scene_158529f9:

    # Maya "Иногда организм хочет чай и все"
    Maya "A veces el cuerpo quiere té y ya está"

# game/characters_events_idles/maya_idles.rpy:194
translate spanish maya_Idle_day_kitchen_scene_61e5a4a1:

    # Maya "И не хочу, чтобы Соня опять читала лекцию о “здоровом балансе”"
    Maya "Y no quiero que Sonya vuelva a darme un sermón sobre el \"equilibrio saludable\""

# game/characters_events_idles/maya_idles.rpy:195
translate spanish maya_Idle_day_kitchen_scene_0a361203:

    # gg "О, значит, это не просто чай - это акт самопожертвования"
    gg "Oh, entonces no es solo té, es un acto de autosacrificio"

# game/characters_events_idles/maya_idles.rpy:197
translate spanish maya_Idle_day_kitchen_scene_d1dbd3ae:

    # Maya "Ага. Пью и страдаю"
    Maya "Ajá. Bebo y sufro"

# game/characters_events_idles/maya_idles.rpy:199
translate spanish maya_Idle_day_kitchen_scene_8b4629d0:

    # Maya "Ладно, раз уж ты сам подошёл - что планируешь делать?"
    Maya "Bueno, ya que te acercaste, ¿qué planeas hacer?"

# game/characters_events_idles/maya_idles.rpy:200
translate spanish maya_Idle_day_kitchen_scene_51392b4e:

    # gg "В смысле?"
    gg "¿A qué te refieres?"

# game/characters_events_idles/maya_idles.rpy:202
translate spanish maya_Idle_day_kitchen_scene_e2d10f18:

    # Maya "Ну, в целом"
    Maya "Bueno, en general"

# game/characters_events_idles/maya_idles.rpy:203
translate spanish maya_Idle_day_kitchen_scene_3b447692:

    # Maya "Сидеть, отдыхать, страдать или притворяться, что у тебя есть план?"
    Maya "¿Sentarse, descansar, sufrir o fingir que tienes un plan?"

# game/characters_events_idles/maya_idles.rpy:204
translate spanish maya_Idle_day_kitchen_scene_ba096a56:

    # gg "План есть - не иметь плана. Хотя, если честно, я просто устал от города"
    gg "El plan es no tener plan. Aunque, para ser honesto, solo estoy cansado de la ciudad"

# game/characters_events_idles/maya_idles.rpy:205
translate spanish maya_Idle_day_kitchen_scene_a341feee:

    # gg "Хотел отдохнуть, помочь бабушке с домом . . . {w}ну, а теперь, похоже, пора искать работу"
    gg "Quería descansar, ayudar a mi abuela con la casa... {w}bueno, y ahora parece que es hora de buscar trabajo"

# game/characters_events_idles/maya_idles.rpy:207
translate spanish maya_Idle_day_kitchen_scene_226b1041:

    # Maya "Добро пожаловать в реальность"
    Maya "Bienvenido a la realidad"

# game/characters_events_idles/maya_idles.rpy:208
translate spanish maya_Idle_day_kitchen_scene_a886fda9:

    # Maya "И где ищут работу люди, которые сбежали от людей?"
    Maya "¿Y dónde buscan trabajo las personas que huyeron de la gente?"

# game/characters_events_idles/maya_idles.rpy:210
translate spanish maya_Idle_day_kitchen_scene_a73a3597:

    # gg "Пока не знаю. Может, в посёлке что-то найду"
    gg "Todavía no lo sé. Tal vez encuentre algo en el pueblo"

# game/characters_events_idles/maya_idles.rpy:211
translate spanish maya_Idle_day_kitchen_scene_a04c7319:

    # gg "Мне и ритм нравится - медленный, настоящий"
    gg "A mí también me gusta el ritmo: lento, auténtico"

# game/characters_events_idles/maya_idles.rpy:212
translate spanish maya_Idle_day_kitchen_scene_4dc705a2:

    # Maya "Настоящий?"
    Maya "¿Auténtico?"

# game/characters_events_idles/maya_idles.rpy:213
translate spanish maya_Idle_day_kitchen_scene_57978980:

    # Maya "Это пока ты не застрянешь тут зимой"
    Maya "Eso es hasta que te quedes atrapado aquí en invierno"

# game/characters_events_idles/maya_idles.rpy:214
translate spanish maya_Idle_day_kitchen_scene_25de1f66:

    # gg "Зато не метро и не толпы"
    gg "Pero al menos no hay metro ni multitudes"

# game/characters_events_idles/maya_idles.rpy:216
translate spanish maya_Idle_day_kitchen_scene_f04c48a5:

    # Maya "Ну да. Только мы и Барсик, который судя по всему - местный депутат"
    Maya "Pues sí. Solo nosotros y Barsik, que por lo visto es el diputado local"

# game/characters_events_idles/maya_idles.rpy:217
translate spanish maya_Idle_day_kitchen_scene_9b820f0a:

    # gg "Главное, чтобы не требовал отчёта о проделанной работе"
    gg "Lo principal es que no exija un informe del trabajo realizado"

# game/characters_events_idles/maya_idles.rpy:219
translate spanish maya_Idle_day_kitchen_scene_67b66e53:

    # Maya "Ага. Хотя Соня могла бы - она бы тебе график расписала"
    Maya "Ajá. Aunque Sonya sí podría; ella te haría un horario"

# game/characters_events_idles/maya_idles.rpy:220
translate spanish maya_Idle_day_kitchen_scene_d9d4e1ed:

    # gg "Я замечал. У неё всё как по часам"
    gg "Lo he notado. Ella hace todo como un reloj"

# game/characters_events_idles/maya_idles.rpy:222
translate spanish maya_Idle_day_kitchen_scene_8841e92a:

    # Maya "Потому что кто-то в этом доме должен компенсировать мой хаос"
    Maya "Porque alguien en esta casa tiene que compensar mi caos"

# game/characters_events_idles/maya_idles.rpy:224
translate spanish maya_Idle_day_kitchen_scene_962fec54:

    # Maya "Так что, если решишь остаться надолго, готовься привыкать к контрастам"
    Maya "Así que, si decides quedarte mucho tiempo, prepárate para acostumbrarte a los contrastes"

# game/characters_events_idles/maya_idles.rpy:225
translate spanish maya_Idle_day_kitchen_scene_5401d48b:

    # gg "Мне кажется, я уже начинаю"
    gg "Creo que ya estoy empezando"

# game/characters_events_idles/maya_idles.rpy:226
translate spanish maya_Idle_day_kitchen_scene_a207aba8:

    # Maya "Осторожнее"
    Maya "Ten cuidado"

# game/characters_events_idles/maya_idles.rpy:227
translate spanish maya_Idle_day_kitchen_scene_2fbe2d88:

    # Maya "Это затягивает"
    Maya "Es adictivo"

# game/characters_events_idles/maya_idles.rpy:241
translate spanish maya_Idle_morning_mayaroom_scene_f8fe1494:

    # gg ". . ."
    gg "..."

# game/characters_events_idles/maya_idles.rpy:242
translate spanish maya_Idle_morning_mayaroom_scene_7e0bd9fb:

    # gg "Так сладко спит"
    gg "Duerme tan plácidamente"

# game/characters_events_idles/maya_idles.rpy:253
translate spanish maya_Idle_day_mayaroom_scene_94873986:

    # gg "Серьёзный вид"
    gg "Mirada seria"

# game/characters_events_idles/maya_idles.rpy:254
translate spanish maya_Idle_day_mayaroom_scene_80d9437f:

    # gg "Ты что, музыку миксуешь?"
    gg "¿Estás mezclando música?"

# game/characters_events_idles/maya_idles.rpy:256
translate spanish maya_Idle_day_mayaroom_scene_f4b03c23:

    # Maya "Ха, мечтай. Работаю"
    Maya "Ja, sueña. Estoy trabajando"

# game/characters_events_idles/maya_idles.rpy:257
translate spanish maya_Idle_day_mayaroom_scene_f8277c64:

    # gg "Звучит опасно. А я думал, ты против дисциплины"
    gg "Suena peligroso. Y yo que pensaba que estabas en contra de la disciplina"

# game/characters_events_idles/maya_idles.rpy:259
translate spanish maya_Idle_day_mayaroom_scene_7888996f:

    # Maya "Я против бессмысленной дисциплины"
    Maya "Estoy en contra de la disciplina sin sentido"

# game/characters_events_idles/maya_idles.rpy:260
translate spanish maya_Idle_day_mayaroom_scene_927b0fd4:

    # Maya "Но если платят - можно и притвориться взрослой"
    Maya "Pero si pagan, puedo fingir que soy adulta"

# game/characters_events_idles/maya_idles.rpy:261
translate spanish maya_Idle_day_mayaroom_scene_d96b72a5:

    # gg "И что за работа?"
    gg "¿Y en qué consiste el trabajo?"

# game/characters_events_idles/maya_idles.rpy:263
translate spanish maya_Idle_day_mayaroom_scene_c6edbdd9:

    # Maya "Связано с проектами. Неинтересно"
    Maya "Está relacionado con proyectos. Nada interesante"

# game/characters_events_idles/maya_idles.rpy:264
translate spanish maya_Idle_day_mayaroom_scene_3908c185:

    # Maya "Раньше приходилось ездить в офис, а теперь могу делать всё из дома"
    Maya "Antes tenía que ir a la oficina, pero ahora puedo hacer todo desde casa"

# game/characters_events_idles/maya_idles.rpy:266
translate spanish maya_Idle_day_mayaroom_scene_0fc56267:

    # Maya "Так что не мешай моей продуктивности"
    Maya "Así que no interfieras con mi productividad"

# game/characters_events_idles/maya_idles.rpy:267
translate spanish maya_Idle_day_mayaroom_scene_77dec125:

    # gg "Не мешаю"
    gg "No interfiero"

# game/characters_events_idles/maya_idles.rpy:268
translate spanish maya_Idle_day_mayaroom_scene_585ed193:

    # gg "Просто проверяю, не заснула ли ты с открытым документом"
    gg "Solo me aseguro de que no te hayas quedado dormida con el documento abierto"

# game/characters_events_idles/maya_idles.rpy:270
translate spanish maya_Idle_day_mayaroom_scene_e95f31f8:

    # Maya "Ещё нет"
    Maya "Aún no"

# game/characters_events_idles/maya_idles.rpy:271
translate spanish maya_Idle_day_mayaroom_scene_4d0580f6:

    # Maya "Но если будешь стоять и таращиться, это ускорит процесс"
    Maya "Pero si te quedas ahí mirando fijamente, acelerarás el proceso"

# game/characters_events_idles/maya_idles.rpy:274
translate spanish maya_Idle_day_mayaroom_scene_d2135720:

    # Maya "И да, на будущее . . ."
    Maya "Y sí, para el futuro..."

# game/characters_events_idles/maya_idles.rpy:275
translate spanish maya_Idle_day_mayaroom_scene_8af163bc:

    # Maya "Стучи, когда входишь"
    Maya "Llama a la puerta cuando entres"

# game/characters_events_idles/maya_idles.rpy:276
translate spanish maya_Idle_day_mayaroom_scene_9797f5b6:

    # gg "А ты дверь закрывай, если хочешь секретности"
    gg "Y tú cierra la puerta si quieres privacidad"

# game/characters_events_idles/maya_idles.rpy:278
translate spanish maya_Idle_day_mayaroom_scene_7d229fff:

    # Maya "Закрытая дверь - это скучно"
    Maya "Una puerta cerrada es aburrida"

# game/characters_events_idles/maya_idles.rpy:279
translate spanish maya_Idle_day_mayaroom_scene_6d90d8fb:

    # Maya "Мне нравится знать, что кто-то может ввалиться в самый неподходящий момент. Добавляет адреналина"
    Maya "Me gusta saber que alguien podría irrumpir en el momento más inoportuno. Añade adrenalina"

# game/characters_events_idles/maya_idles.rpy:280
translate spanish maya_Idle_day_mayaroom_scene_5348c7b0:

    # gg "Опасное хобби"
    gg "Un pasatiempo peligroso"

# game/characters_events_idles/maya_idles.rpy:295
translate spanish maya_Idle_evening_mayaroom_scene_c74a33fe:

    # gg "Опять зависла?"
    gg "¿Otra vez en tu mundo?"

# game/characters_events_idles/maya_idles.rpy:297
translate spanish maya_Idle_evening_mayaroom_scene_66aa8fb0:

    # Maya "Называется “отдыхаю”"
    Maya "Se llama \"descansar\""

# game/characters_events_idles/maya_idles.rpy:298
translate spanish maya_Idle_evening_mayaroom_scene_29fea123:

    # Maya "Иногда даже без музыки"
    Maya "A veces incluso sin música"

# game/characters_events_idles/maya_idles.rpy:299
translate spanish maya_Idle_evening_mayaroom_scene_bbc28184:

    # gg "Опасный эксперимент"
    gg "Un experimento peligroso"

# game/characters_events_idles/maya_idles.rpy:300
translate spanish maya_Idle_evening_mayaroom_scene_cc606e86:

    # Maya "Ага. Учёные уже фиксируют первые побочные эффекты - мысли начали возвращаться"
    Maya "Ajá. Los científicos ya están registrando los primeros efectos secundarios: los pensamientos han comenzado a regresar"

# game/characters_events_idles/maya_idles.rpy:301
translate spanish maya_Idle_evening_mayaroom_scene_a4eb2f4d:

    # gg "О чём думаешь?"
    gg "¿En qué estás pensando?"

# game/characters_events_idles/maya_idles.rpy:303
translate spanish maya_Idle_evening_mayaroom_scene_f963639a:

    # Maya "Ни о чём особенном. Просто день какой-то неспокойный"
    Maya "En nada especial. Simplemente ha sido un día agitado"

# game/characters_events_idles/maya_idles.rpy:305
translate spanish maya_Idle_evening_mayaroom_scene_9622db09:

    # Maya "Иногда мне кажется, что этот дом дышит"
    Maya "A veces me parece que esta casa respira"

# game/characters_events_idles/maya_idles.rpy:306
translate spanish maya_Idle_evening_mayaroom_scene_0a637ee0:

    # Maya "Когда все расходятся по комнатам, он будто вздыхает - типа “наконец-то”"
    Maya "Cuando todos se retiran a sus habitaciones, parece suspirar, como diciendo \"por fin\""

# game/characters_events_idles/maya_idles.rpy:307
translate spanish maya_Idle_evening_mayaroom_scene_c4190f3c:

    # gg "Может, он просто устал от нас"
    gg "Tal vez simplemente esté cansado de nosotros"

# game/characters_events_idles/maya_idles.rpy:309
translate spanish maya_Idle_evening_mayaroom_scene_9a1cfc06:

    # Maya "Или от тебя"
    Maya "O de ti"

# game/characters_events_idles/maya_idles.rpy:310
translate spanish maya_Idle_evening_mayaroom_scene_9ca1630b:

    # Maya "Ты ж теперь главный источник событий"
    Maya "Tú ahora eres la principal fuente de eventos"

# game/characters_events_idles/maya_idles.rpy:311
translate spanish maya_Idle_evening_mayaroom_scene_4618c7f3:

    # gg "Ну спасибо"
    gg "Bueno, gracias"

# game/characters_events_idles/maya_idles.rpy:312
translate spanish maya_Idle_evening_mayaroom_scene_9314e70f:

    # gg "Хоть не шумовой загрязнитель"
    gg "Al menos no soy un contaminante acústico"

# game/characters_events_idles/maya_idles.rpy:314
translate spanish maya_Idle_evening_mayaroom_scene_1c9556b7:

    # Maya "Не переживай, ты в двух шагах de este título"
    Maya "No te preocupes, estás a dos pasos de ese título"

# game/characters_events_idles/maya_idles.rpy:317
translate spanish maya_Idle_evening_mayaroom_scene_3ece4663:

    # gg "Ладно, не мешаю твоему “отдыханию”"
    gg "Está bien, no interrumpiré tu \"descanso\""

# game/characters_events_idles/maya_idles.rpy:318
translate spanish maya_Idle_evening_mayaroom_scene_c8d80171:

    # Maya "Уже поздно. Ты в моём поле общения, это необратимо"
    Maya "Ya es tarde. Estás en mi campo de comunicación, es irreversible"

# game/characters_events_idles/maya_idles.rpy:319
translate spanish maya_Idle_evening_mayaroom_scene_52424bb1:

    # gg "Тогда я официально заражён"
    gg "Entonces estoy oficialmente infectado"

# game/characters_events_idles/maya_idles.rpy:333
translate spanish maya_Idle_night_mayaroom_scene_f715f6b4:

    # gg "Спит без задних ног . . ."
    gg "Duerme a pierna suelta..."

# game/characters_events_idles/maya_idles.rpy:334
translate spanish maya_Idle_night_mayaroom_scene_fd8d0a8c:

    # gg "Хоть будильник под ухом взрывай — не проснётся"
    gg "Podrías hacer explotar un despertador junto a su oreja y no se despertaría"

# game/characters_events_idles/maya_idles.rpy:345
translate spanish maya_Idle_evening_myroom_scene_f6ddbad8:

    # gg "Засыпаешь?"
    gg "¿Te estás quedando dormida?"

# game/characters_events_idles/maya_idles.rpy:347
translate spanish maya_Idle_evening_myroom_scene_60b26d3f:

    # Maya "Нет. Просто отдыхаю в позе ленивой медитации"
    Maya "No. Solo estoy descansando en pose de meditación perezosa"

# game/characters_events_idles/maya_idles.rpy:348
translate spanish maya_Idle_evening_myroom_scene_5197b7fb:

    # gg "Выглядит как битва с подушкой на выживание"
    gg "Parece una batalla a muerte con la almohada"

# game/characters_events_idles/maya_idles.rpy:350
translate spanish maya_Idle_evening_myroom_scene_ef00b824:

    # Maya "Ха. Не завидуй"
    Maya "Ja. No envidies"

# game/characters_events_idles/maya_idles.rpy:352
translate spanish maya_Idle_evening_myroom_scene_87bfdb57:

    # gg "Соня говорила что спала раньше на этом диване. Он удобный"
    gg "Sonya dijo que antes dormía en este sofá. Es cómodo"

# game/characters_events_idles/maya_idles.rpy:353
translate spanish maya_Idle_evening_myroom_scene_b9e42dcf:

    # Maya "Ага. Она любила здесь засыпать под телевизор"
    Maya "Ajá. A ella le encantaba quedarse dormida aquí con la televisión puesta"

# game/characters_events_idles/maya_idles.rpy:354
translate spanish maya_Idle_evening_myroom_scene_01c1b004:

    # Maya "Говорила, что этот гул помогает думать"
    Maya "Ella decía que ese zumbido ayuda a pensar"

# game/characters_events_idles/maya_idles.rpy:357
translate spanish maya_Idle_evening_myroom_scene_69ea4813:

    # Maya "А теперь вот ты"
    Maya "Y ahora aquí estás tú"

# game/characters_events_idles/maya_idles.rpy:358
translate spanish maya_Idle_evening_myroom_scene_1c914aec:

    # Maya "И диван как будто сменил хозяина"
    Maya "Y el sofá parece haber cambiado de dueño"

# game/characters_events_idles/maya_idles.rpy:359
translate spanish maya_Idle_evening_myroom_scene_c99ae1d2:

    # gg "Ничего, я постараюсь не испортить его репутацию"
    gg "Está bien, intentaré no arruinar su reputación"

# game/characters_events_idles/maya_idles.rpy:360
translate spanish maya_Idle_evening_myroom_scene_4ed4ce95:

    # Maya "Да уж, будь добр"
    Maya "Sí, por favor sé amable"

# game/characters_events_idles/maya_idles.rpy:361
translate spanish maya_Idle_evening_myroom_scene_a777aa23:

    # Maya "У него длинная история, он видел больше ссор и сериалов, чем мы оба вместе"
    Maya "Tiene una larga historia, ha visto más discusiones y series que los dos juntos"

# game/characters_events_idles/maya_idles.rpy:362
translate spanish maya_Idle_evening_myroom_scene_3f329134:

    # gg "Кстати, а вы вообще платите Линде за жильё? Или это всё “по знакомству”?"
    gg "Por cierto, ¿ustedes le pagan a Linda por el alquiler? ¿O es todo \"por conocidos\"?"

# game/characters_events_idles/maya_idles.rpy:364
translate spanish maya_Idle_evening_myroom_scene_ac2bb573:

    # Maya "Платим . . . {w}Ну как “платим” - скорее благодарим"
    Maya "Pagamos... {w}Bueno, cómo \"pagamos\"... más bien le damos las gracias"

# game/characters_events_idles/maya_idles.rpy:365
translate spanish maya_Idle_evening_myroom_scene_b48308d4:

    # Maya "Сумма символическая, Линда больше из принципа берёт, чем из необходимости"
    Maya "La cantidad es simbólica, Linda cobra más por principio que por necesidad"

# game/characters_events_idles/maya_idles.rpy:366
translate spanish maya_Idle_evening_myroom_scene_361a0566:

    # Maya "Её это, кажется, успокаивает: типа дом не стоит пустой и приносит пользу"
    Maya "Eso parece calmarla: es como si la casa no estuviera vacía y diera utilidad"

# game/characters_events_idles/maya_idles.rpy:367
translate spanish maya_Idle_evening_myroom_scene_e9782332:

    # gg "Узнаю свою бабушку"
    gg "Reconozco a mi abuela"

# game/characters_events_idles/maya_idles.rpy:369
translate spanish maya_Idle_evening_myroom_scene_5822e6c1:

    # Maya "Ага. Только вот было бы ещё хорошо, если бы она хотя бы предупредила, что внучок вот-вот приедет"
    Maya "Ajá. Solo que habría estado bien que al menos avisara que su nieto estaba por llegar"

# game/characters_events_idles/maya_idles.rpy:370
translate spanish maya_Idle_evening_myroom_scene_3f1ab8b6:

    # Maya "Я чуть не упала тогда, когда ты появился в дверях"
    Maya "Casi me caigo cuando apareciste en la puerta"

# game/characters_events_idles/maya_idles.rpy:371
translate spanish maya_Idle_evening_myroom_scene_1bd89a55:

    # Maya "Уже чего только не думала"
    Maya "Ya me estaba imaginando de todo"

# game/characters_events_idles/maya_idles.rpy:372
translate spanish maya_Idle_evening_myroom_scene_5d3dcdb5:

    # gg "Извини, я тоже не ожидал, что в доме будут люди"
    gg "Lo siento, tampoco esperaba que hubiera gente en la casa"

# game/characters_events_idles/maya_idles.rpy:373
translate spanish maya_Idle_evening_myroom_scene_43ff1f8d:

    # Maya "Вот и замечательно"
    Maya "Genial"

# game/characters_events_idles/maya_idles.rpy:374
translate spanish maya_Idle_evening_myroom_scene_6c224d29:

    # Maya "Никто ничего не ожидал - поэтому всё как обычно"
    Maya "Nadie esperaba nada, así que todo sigue como siempre"

# game/characters_events_idles/maya_idles.rpy:377
translate spanish maya_Idle_evening_myroom_scene_cbdc658c:

    # Maya "Знаешь, может, это и к лучшему"
    Maya "Sabes, tal vez sea para mejor"

# game/characters_events_idles/maya_idles.rpy:378
translate spanish maya_Idle_evening_myroom_scene_10ae6709:

    # gg "Я стараюсь как лучше"
    gg "Hago lo mejor que puedo"

# game/characters_events_idles/maya_idles.rpy:379
translate spanish maya_Idle_evening_myroom_scene_2738bbdd:

    # Maya "Ладно, ты уже часть декора"
    Maya "Vale, ya eres parte de la decoración"

# game/characters_events_idles/maya_idles.rpy:380
translate spanish maya_Idle_evening_myroom_scene_a3e55433:

    # Maya "Даже телевизор теперь включается по тебе"
    Maya "Incluso la tele ahora se enciende cuando apareces tú"

# game/characters_events_idles/maya_idles.rpy:381
translate spanish maya_Idle_evening_myroom_scene_51392b4e:

    # gg "В смысле?"
    gg "¿Qué?"

# game/characters_events_idles/maya_idles.rpy:382
translate spanish maya_Idle_evening_myroom_scene_6214a218:

    # Maya "Стоит тебе появиться - сразу что-то происходит. Иногда полезное, иногда нет"
    Maya "Basta con que aparezcas para que pase algo. A veces algo bueno, a veces no"

# game/characters_events_idles/maya_idles.rpy:383
translate spanish maya_Idle_evening_myroom_scene_a17c73ec:

    # Maya "Но скучно с тобой не бывает"
    Maya "Pero contigo nunca es aburrido"

# game/characters_events_idles/maya_idles.rpy:385
translate spanish maya_Idle_evening_myroom_scene_3edde83f:

    # Maya "Всё, вечер окончен"
    Maya "Eso es todo, la velada ha terminado"

# game/characters_events_idles/maya_idles.rpy:386
translate spanish maya_Idle_evening_myroom_scene_2082f32a:

    # Maya "Телевизор устал смотреть на нас"
    Maya "La tele se cansó de mirarnos"

# game/characters_events_idles/maya_idles.rpy:387
translate spanish maya_Idle_evening_myroom_scene_3c45ded0:

    # gg "Тогда спокойной ночи"
    gg "Entonces, buenas noches"

# game/characters_events_idles/maya_idles.rpy:388
translate spanish maya_Idle_evening_myroom_scene_9adb5a5c:

    # Maya "Ага. И не растяни диван - он к тебе уже привязался"
    Maya "Ajá. Y no estires el sofá, ya se ha encariñado contigo"

translate spanish strings:

    # game/characters_events_idles/maya_idles.rpy:5
    old "Барсик у тебя?"
    new "¿Tienes Barsik?"

    # game/characters_events_idles/maya_idles.rpy:43
    old "Позже зайду"
    new "Pasaré más tarde"

    # game/characters_events_idles/maya_idles.rpy:52
    old "С книжкой с утра?"
    new "¿Con un libro, mañana?"

    # game/characters_events_idles/maya_idles.rpy:102
    old "Не мешаю"
    new "Yo no interfiero"

    # game/characters_events_idles/maya_idles.rpy:111
    old "Ко сну готовишься?"
    new "¿Estás preparándote para ir a dormir?"

    # game/characters_events_idles/maya_idles.rpy:136
    old "Не буду мешать"
    new "No interferiré"

    # game/characters_events_idles/maya_idles.rpy:145
    old "Новый рецепт?"
    new "¿Nueva receta?"

    # game/characters_events_idles/maya_idles.rpy:188
    old "Газировка кончилась?"
    new "¿Se acabó el refresco?"

    # game/characters_events_idles/maya_idles.rpy:231
    old "Пойду"
    new "Yo iré"

    # game/characters_events_idles/maya_idles.rpy:240
    old "Не беспокоить"
    new "No molestar"

    # game/characters_events_idles/maya_idles.rpy:251
    old "Музыку миксуешь?"
    new "¿Mezclas música?"

    # game/characters_events_idles/maya_idles.rpy:284
    old "Уйти"
    new "Irme"

    # game/characters_events_idles/maya_idles.rpy:293
    old "Опять зависла?"
    new "¿Absorta otra vez?"

    # game/characters_events_idles/maya_idles.rpy:343
    old "Засыпаешь?"
    new "¿Te estás quedando dormida?"

