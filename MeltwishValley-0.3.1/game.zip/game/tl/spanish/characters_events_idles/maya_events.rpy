﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/maya_events.rpy:24
translate spanish maya_scene1_evening_myroom_ef5d982a:

    # Maya "Да ты издеваешься"
    Maya "Me estás tomando el pelo"

# game/characters_events_idles/maya_events.rpy:37
translate spanish maya_scene1_evening_myroom_905d33c0:

    # Maya "Где они блин"
    Maya "¿Dónde diablos están?"

# game/characters_events_idles/maya_events.rpy:50
translate spanish maya_scene1_evening_myroom_bd666787:

    # Maya "Тьфу"
    Maya "Puaj"

# game/characters_events_idles/maya_events.rpy:56
translate spanish maya_scene1_evening_myroom_481be515:

    # Maya "Чё смотришь?"
    Maya "¿Qué estás mirando?"

# game/characters_events_idles/maya_events.rpy:57
translate spanish maya_scene1_evening_myroom_2ca818a6:

    # gg "Проверь плюс и минус"
    gg "Comprueba el más y el menos"

# game/characters_events_idles/maya_events.rpy:58
translate spanish maya_scene1_evening_myroom_4bbab9f1:

    # Maya "Проверяла"
    Maya "Lo comprobé"

# game/characters_events_idles/maya_events.rpy:94
translate spanish maya_scene2_day_mayaroom_5bb53a51:

    # Maya "Кто там?"
    Maya "¿Quién está ahí?"

# game/characters_events_idles/maya_events.rpy:96
translate spanish maya_scene2_day_mayaroom_14a18d19:

    # gg "Это я. Можно зайти по делу?"
    gg "Soy yo. ¿Puedo venir por negocios?"

# game/characters_events_idles/maya_events.rpy:97
translate spanish maya_scene2_day_mayaroom_1c4734b1:

    # Maya "Входи"
    Maya "Adelante"

# game/characters_events_idles/maya_events.rpy:105
translate spanish maya_scene2_day_mayaroom_ab7fedad:

    # gg "Музыку слушаешь?"
    gg "¿Escuchas música?"

# game/characters_events_idles/maya_events.rpy:107
translate spanish maya_scene2_day_mayaroom_3884c669:

    # Maya "Нет, для соседей включила"
    Maya "No, lo encendí para los vecinos."

# game/characters_events_idles/maya_events.rpy:111
translate spanish maya_scene2_day_mayaroom_837eef0f:

    # gg "Я решил, что останусь тут"
    gg "Decidí que me quedaré aquí."

# game/characters_events_idles/maya_events.rpy:113
translate spanish maya_scene2_day_mayaroom_95020588:

    # gg "Буду жить здесь"
    gg "Viviré aquí"

# game/characters_events_idles/maya_events.rpy:115
translate spanish maya_scene2_day_mayaroom_bca52f7e:

    # Maya "Ну"
    Maya "Bien"

# game/characters_events_idles/maya_events.rpy:117
translate spanish maya_scene2_day_mayaroom_705e10f4:

    # Maya "Соболезную"
    Maya "Mi más sentido pésame"

# game/characters_events_idles/maya_events.rpy:125
translate spanish maya_scene2_day_mayaroom_27c60573:

    # Maya "Эй"
    Maya "Ey"

# game/characters_events_idles/maya_events.rpy:127
translate spanish maya_scene2_day_mayaroom_40785e40:

    # Maya "Дальше не надо"
    Maya "No se necesita más"

# game/characters_events_idles/maya_events.rpy:129
translate spanish maya_scene2_day_mayaroom_5f49e73a:

    # gg "Я просто хотел"
    gg "Solo quería"

# game/characters_events_idles/maya_events.rpy:131
translate spanish maya_scene2_day_mayaroom_16e0a365:

    # Maya "Я всё услышала"
    Maya "Escuché todo"

# game/characters_events_idles/maya_events.rpy:133
translate spanish maya_scene2_day_mayaroom_c48134de:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "No me importa que vivas aquí"

# game/characters_events_idles/maya_events.rpy:135
translate spanish maya_scene2_day_mayaroom_df1954ea:

    # Maya "Честно"
    Maya "Honestamente"

# game/characters_events_idles/maya_events.rpy:139
translate spanish maya_scene2_day_mayaroom_df3a4321:

    # Maya "Но давай без этого"
    Maya "Pero dejemos eso"

# game/characters_events_idles/maya_events.rpy:141
translate spanish maya_scene2_day_mayaroom_e6c85abf:

    # gg "Без чего?"
    gg "¿Sin qué?"

# game/characters_events_idles/maya_events.rpy:143
translate spanish maya_scene2_day_mayaroom_d4ddd213:

    # Maya "Без контроля"
    Maya "Sin control"

# game/characters_events_idles/maya_events.rpy:145
translate spanish maya_scene2_day_mayaroom_bc54c15e:

    # Maya "Без «я помогу»"
    Maya "Sin \"te ayudaré\""

# game/characters_events_idles/maya_events.rpy:147
translate spanish maya_scene2_day_mayaroom_7a220c2f:

    # gg "Я не про контроль"
    gg "No estoy hablando de control"

# game/characters_events_idles/maya_events.rpy:148
translate spanish maya_scene2_day_mayaroom_dabe88df:

    # gg "Если по дому что-то"
    gg "Si hay algo alrededor de la casa"

# game/characters_events_idles/maya_events.rpy:152
translate spanish maya_scene2_day_mayaroom_723b85d3:

    # Maya "Мне не нужна опека"
    Maya "No necesito tutela"

# game/characters_events_idles/maya_events.rpy:154
translate spanish maya_scene2_day_mayaroom_cad2c7d3:

    # gg "Я не это имел в виду"
    gg "Eso no es lo que quise decir"

# game/characters_events_idles/maya_events.rpy:156
translate spanish maya_scene2_day_mayaroom_e9decfdb:

    # Maya "А звучит именно так"
    Maya "Y eso es exactamente lo que suena"

# game/characters_events_idles/maya_events.rpy:158
translate spanish maya_scene2_day_mayaroom_c48134de_1:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "No me importa que vivas aquí"

# game/characters_events_idles/maya_events.rpy:160
translate spanish maya_scene2_day_mayaroom_3e5d6dd4:

    # Maya "Просто"
    Maya "Simplemente"

# game/characters_events_idles/maya_events.rpy:162
translate spanish maya_scene2_day_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "No interfieras"

# game/characters_events_idles/maya_events.rpy:164
translate spanish maya_scene2_day_mayaroom_9727ea24:

    # Maya "В личное"
    Maya "En lo personal"

# game/characters_events_idles/maya_events.rpy:166
translate spanish maya_scene2_day_mayaroom_44696bee:

    # gg "Я понял"
    gg "Entiendo"

# game/characters_events_idles/maya_events.rpy:168
translate spanish maya_scene2_day_mayaroom_97fa7b2b:

    # Maya "И дверь закрывай"
    Maya "Y cierra la puerta"

# game/characters_events_idles/maya_events.rpy:170
translate spanish maya_scene2_day_mayaroom_367b11d8:

    # Maya "Я не фанат"
    Maya "No soy un fan"

# game/characters_events_idles/maya_events.rpy:171
translate spanish maya_scene2_day_mayaroom_5e882c77:

    # Maya "Открытых пространств"
    Maya "De espacios abiertos"

# game/characters_events_idles/maya_events.rpy:198
translate spanish maya_scene3_evening_kitchen_9a8b0be2:

    # gg "Привет"
    gg "Hola"

# game/characters_events_idles/maya_events.rpy:211
translate spanish maya_scene3_evening_kitchen_a356674e:

    # gg "Тебе еще кофе принести?"
    gg "¿Debería traerte más café?"

# game/characters_events_idles/maya_events.rpy:213
translate spanish maya_scene3_evening_kitchen_9a5dd35b:

    # Maya "Нет"
    Maya "No"

# game/characters_events_idles/maya_events.rpy:225
translate spanish maya_scene3_evening_kitchen_00c41c60:

    # Maya "Не . . ."
    Maya "No..."

# game/characters_events_idles/maya_events.rpy:227
translate spanish maya_scene3_evening_kitchen_059eb6da:

    # gg "Что?"
    gg "¿Qué?"

# game/characters_events_idles/maya_events.rpy:229
translate spanish maya_scene3_evening_kitchen_5c02f51f:

    # Maya "Ты вообще"
    Maya "¿Estás en absoluto?"

# game/characters_events_idles/maya_events.rpy:231
translate spanish maya_scene3_evening_kitchen_c954c369:

    # Maya "Ты зачем так близко?"
    Maya "¿Por qué estás tan cerca?"

# game/characters_events_idles/maya_events.rpy:233
translate spanish maya_scene3_evening_kitchen_7de3a2ef:

    # gg "Я просто"
    gg "Yo solo"

# game/characters_events_idles/maya_events.rpy:235
translate spanish maya_scene3_evening_kitchen_25f0ffea:

    # Maya "Я сказала, не надо"
    Maya "Dije que no es necesario"

# game/characters_events_idles/maya_events.rpy:237
translate spanish maya_scene3_evening_kitchen_91d73b20:

    # Maya "И не звала"
    Maya "Y no llamé"

# game/characters_events_idles/maya_events.rpy:241
translate spanish maya_scene3_evening_kitchen_e10a0eab:

    # Maya "Мне нужно было просто кофе"
    Maya "Solo necesitaba café"

# game/characters_events_idles/maya_events.rpy:243
translate spanish maya_scene3_evening_kitchen_a41fbef3:

    # gg "Подожди"
    gg "Espera"

# game/characters_events_idles/maya_events.rpy:245
translate spanish maya_scene3_evening_kitchen_c8225194:

    # Maya "Не сейчас"
    Maya "Ahora no"

# game/characters_events_idles/maya_events.rpy:252
translate spanish maya_scene3_evening_kitchen_0d9a221f:

    # gg_chat "Как бы мне с ней поговорить"
    gg_chat "¿Cómo puedo hablar con ella?"

# game/characters_events_idles/maya_events.rpy:263
translate spanish maya_scene4_morning_mayaroom_d3734f64:

    # Maya "Да что ж"
    Maya "Oh bueno"

# game/characters_events_idles/maya_events.rpy:265
translate spanish maya_scene4_morning_mayaroom_fa8ea266:

    # Maya "Ну давай же"
    Maya "Vamos entonces"

# game/characters_events_idles/maya_events.rpy:271
translate spanish maya_scene4_morning_mayaroom_d944481b:

    # gg "Опять воюешь с техникой?"
    gg "¿Estás peleando con la tecnología otra vez?"

# game/characters_events_idles/maya_events.rpy:273
translate spanish maya_scene4_morning_mayaroom_b6f44dea:

    # Maya "Все работало час назад"
    Maya "Todo funcionaba hace una hora."

# game/characters_events_idles/maya_events.rpy:275
translate spanish maya_scene4_morning_mayaroom_743f87c9:

    # gg "На вид, пауза — у меня была похожая проблема"
    gg "Parece una pausa. Tuve un problema similar."

# game/characters_events_idles/maya_events.rpy:277
translate spanish maya_scene4_morning_mayaroom_5b9f31c5:

    # Maya "Конечно. У нашего местного игромана, разумеется, был подобный опыт"
    Maya "Ciertamente. Nuestro adicto al juego local, por supuesto, tuvo una experiencia similar."

# game/characters_events_idles/maya_events.rpy:279
translate spanish maya_scene4_morning_mayaroom_d67e684e:

    # gg "Это решается проще, чем кажется"
    gg "Esto es más fácil de solucionar de lo que parece"

# game/characters_events_idles/maya_events.rpy:281
translate spanish maya_scene4_morning_mayaroom_6ac6687a:

    # Maya "Я разберусь"
    Maya "Lo resolveré"

# game/characters_events_idles/maya_events.rpy:285
translate spanish maya_scene4_morning_mayaroom_ef21c62b:

    # Maya "Ладно поскольку ты уже встал тут в позу спасителя"
    Maya "Bien, ya que ya has adoptado la postura del salvador aquí."

# game/characters_events_idles/maya_events.rpy:287
translate spanish maya_scene4_morning_mayaroom_e4eef199:

    # Maya "Смотри"
    Maya "Mira"

# game/characters_events_idles/maya_events.rpy:289
translate spanish maya_scene4_morning_mayaroom_b05b1e64:

    # Maya "Но если сломаешь новый купишь"
    Maya "Pero si lo rompes, compra uno nuevo."

# game/characters_events_idles/maya_events.rpy:291
translate spanish maya_scene4_morning_mayaroom_2406a76f:

    # gg_chat "Так посмотрим"
    gg_chat "Así que veamos"

# game/characters_events_idles/maya_events.rpy:293
translate spanish maya_scene4_morning_mayaroom_3eccec99:

    # Maya "Только давай без «я же говорил»"
    Maya "Simplemente no digas \"te lo dije\""

# game/characters_events_idles/maya_events.rpy:295
translate spanish maya_scene4_morning_mayaroom_edca7a30:

    # gg "Хорошо Не собирался"
    gg "Está bien, no era mi intención"

# game/characters_events_idles/maya_events.rpy:300
translate spanish maya_scene4_morning_mayaroom_33712776:

    # Maya "Главное делай вид, что понимаешь"
    Maya "Lo principal es fingir que entiendes."

# game/characters_events_idles/maya_events.rpy:306
translate spanish maya_scene4_morning_mayaroom_726d3183:

    # Maya "Ты что сделал?"
    Maya "¿Qué hiciste?"

# game/characters_events_idles/maya_events.rpy:309
translate spanish maya_scene4_morning_mayaroom_5de5e399:

    # Maya "Показывай"
    Maya "Muéstrame"

# game/characters_events_idles/maya_events.rpy:311
translate spanish maya_scene4_morning_mayaroom_4572bfad:

    # Maya "Я уже готовлюсь к разочарованию"
    Maya "Ya me estoy preparando para la decepción."

# game/characters_events_idles/maya_events.rpy:313
translate spanish maya_scene4_morning_mayaroom_6c571b22:

    # gg "Пока ничего критичного"
    gg "Nada crítico todavía"

# game/characters_events_idles/maya_events.rpy:315
translate spanish maya_scene4_morning_mayaroom_eab0c0bf:

    # Maya "Угу"
    Maya "Sí"

# game/characters_events_idles/maya_events.rpy:319
translate spanish maya_scene4_morning_mayaroom_4506bcc5:

    # Maya "Эй!"
    Maya "¡Ey!"

# game/characters_events_idles/maya_events.rpy:321
translate spanish maya_scene4_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "¡Para!"

# game/characters_events_idles/maya_events.rpy:323
translate spanish maya_scene4_morning_mayaroom_5144b708:

    # gg "Что"
    gg "Qué"

# game/characters_events_idles/maya_events.rpy:325
translate spanish maya_scene4_morning_mayaroom_cfa517d6:

    # Maya "Не надо ко мне лезть"
    Maya "No te me acerques"

# game/characters_events_idles/maya_events.rpy:327
translate spanish maya_scene4_morning_mayaroom_1400ea9e:

    # gg "Ты сама"
    gg "Tú misma"

# game/characters_events_idles/maya_events.rpy:329
translate spanish maya_scene4_morning_mayaroom_fd37247c:

    # Maya "Цыц"
    Maya "Tsyts"

# game/characters_events_idles/maya_events.rpy:333
translate spanish maya_scene4_morning_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "Olvídalo"

# game/characters_events_idles/maya_events.rpy:337
translate spanish maya_scene4_morning_mayaroom_d09026b0:

    # Maya "Уже не важно"
    Maya "Ya no importa"

# game/characters_events_idles/maya_events.rpy:339
translate spanish maya_scene4_morning_mayaroom_98444aa5:

    # Maya "Я разберусь потом"
    Maya "Lo resolveré más tarde"

# game/characters_events_idles/maya_events.rpy:341
translate spanish maya_scene4_morning_mayaroom_d2acc454:

    # gg "Я же просто"
    gg "Es que solo..."

# game/characters_events_idles/maya_events.rpy:343
translate spanish maya_scene4_morning_mayaroom_e0da4bdd:

    # Maya "Я сказала потом"
    Maya "Dije más tarde"

# game/characters_events_idles/maya_events.rpy:349
translate spanish maya_scene4_morning_mayaroom_d821f777:

    # gg_chat "Нужно дать ей время"
    gg_chat "Necesitamos darle tiempo"

# game/characters_events_idles/maya_events.rpy:360
translate spanish maya_scene5_night_mayaroom_63a0d7ed:

    # gg "Я зайду"
    gg "Pasaré"

# game/characters_events_idles/maya_events.rpy:364
translate spanish maya_scene5_night_mayaroom_6c5edc69:

    # gg "Слушай . . ."
    gg "Escucha..."

# game/characters_events_idles/maya_events.rpy:366
translate spanish maya_scene5_night_mayaroom_68ee26d9:

    # gg "Я хочу понять"
    gg "Quiero entender"

# game/characters_events_idles/maya_events.rpy:368
translate spanish maya_scene5_night_mayaroom_bc1e3bb5:

    # gg "Ты всё время"
    gg "Todo el tiempo"

# game/characters_events_idles/maya_events.rpy:369
translate spanish maya_scene5_night_mayaroom_024d1c74:

    # gg "Отталкиваешь"
    gg "Te alejas"

# game/characters_events_idles/maya_events.rpy:370
translate spanish maya_scene5_night_mayaroom_8f03bb39:

    # gg "Резко"
    gg "Bruscamente"

# game/characters_events_idles/maya_events.rpy:372
translate spanish maya_scene5_night_mayaroom_e92f63ca:

    # gg "Я не всегда понимаю"
    gg "No siempre entiendo"

# game/characters_events_idles/maya_events.rpy:373
translate spanish maya_scene5_night_mayaroom_fc49f049:

    # gg "Где именно граница"
    gg "¿Dónde está exactamente la frontera?"

# game/characters_events_idles/maya_events.rpy:375
translate spanish maya_scene5_night_mayaroom_6d2d9756:

    # Maya "Да нигде"
    Maya "En ningún lugar"

# game/characters_events_idles/maya_events.rpy:377
translate spanish maya_scene5_night_mayaroom_5c27dae4:

    # Maya "Хочешь границы -"
    Maya "¿Quieres límites?"

# game/characters_events_idles/maya_events.rpy:378
translate spanish maya_scene5_night_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "No interfieras"

# game/characters_events_idles/maya_events.rpy:379
translate spanish maya_scene5_night_mayaroom_71b4348e:

    # gg "Я не . . .{nw=0.3}"
    gg "No...{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:381
translate spanish maya_scene5_night_mayaroom_3a7c36e6:

    # Maya "Не надо"
    Maya "No hay necesidad"

# game/characters_events_idles/maya_events.rpy:383
translate spanish maya_scene5_night_mayaroom_11f3acdb:

    # Maya "Не делай вид"
    Maya "No pretendas"

# game/characters_events_idles/maya_events.rpy:384
translate spanish maya_scene5_night_mayaroom_e9a71e8d:

    # Maya "Что ты тут ни при чём"
    Maya "Que no tienes nada que ver con eso"

# game/characters_events_idles/maya_events.rpy:386
translate spanish maya_scene5_night_mayaroom_734313d9:

    # gg "Я не пытаюсь давить"
    gg "No estoy tratando de presionar"

# game/characters_events_idles/maya_events.rpy:387
translate spanish maya_scene5_night_mayaroom_e3709e94:

    # gg "Я просто . . .{nw=0.3}"
    gg "Es que solo...{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:389
translate spanish maya_scene5_night_mayaroom_76c878d4:

    # Maya "Ты всегда «просто»"
    Maya "Siempre eres 'solo'"

# game/characters_events_idles/maya_events.rpy:391
translate spanish maya_scene5_night_mayaroom_7125aff8:

    # Maya "Просто заходишь"
    Maya "Solo entras"

# game/characters_events_idles/maya_events.rpy:392
translate spanish maya_scene5_night_mayaroom_8803de0c:

    # Maya "Просто начинаешь разговор"
    Maya "Solo inicias una conversación"

# game/characters_events_idles/maya_events.rpy:394
translate spanish maya_scene5_night_mayaroom_30ca9380:

    # Maya "Просто помогаешь"
    Maya "Solo estás ayudando"

# game/characters_events_idles/maya_events.rpy:396
translate spanish maya_scene5_night_mayaroom_a04f159c:

    # Maya "{sc}Это бесит{/sc}"
    Maya "{sc}Esto es molesto{/sc}"

# game/characters_events_idles/maya_events.rpy:398
translate spanish maya_scene5_night_mayaroom_3a8f909d:

    # Maya "Всё"
    Maya "Todo"

# game/characters_events_idles/maya_events.rpy:400
translate spanish maya_scene5_night_mayaroom_4d5d0603:

    # Maya "Разговор окончен"
    Maya "La conversación ha terminado"

# game/characters_events_idles/maya_events.rpy:404
translate spanish maya_scene5_night_mayaroom_37d7c2ce:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Прости"
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Lo siento"

# game/characters_events_idles/maya_events.rpy:410
translate spanish maya_scene5_night_mayaroom_2336b49e:

    # Maya "Хотя нет"
    Maya "Aunque no"

# game/characters_events_idles/maya_events.rpy:412
translate spanish maya_scene5_night_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "Olvídalo"

# game/characters_events_idles/maya_events.rpy:426
translate spanish maya_scene5_night_mayaroom_74fb972d:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Я . . ."
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Yo..."

# game/characters_events_idles/maya_events.rpy:428
translate spanish maya_scene5_night_mayaroom_922caaa0:

    # Maya "Не это имела в виду"
    Maya "Eso no es lo que quise decir"

# game/characters_events_idles/maya_events.rpy:430
translate spanish maya_scene5_night_mayaroom_3a8f909d_1:

    # Maya "Всё"
    Maya "Todo"

# game/characters_events_idles/maya_events.rpy:432
translate spanish maya_scene5_night_mayaroom_00c0f420:

    # Maya "Иди"
    Maya "Vete"

# game/characters_events_idles/maya_events.rpy:435
translate spanish maya_scene5_night_mayaroom_d0668ccb:

    # Maya "Я сказала — иди{nw=2}"
    Maya "Dije que vayas{nw=2}"

# game/characters_events_idles/maya_events.rpy:463
translate spanish maya_scene6_evening_myroom_8846d5d4:

    # Maya "Ты сидишь будто"
    Maya "Te sientas como si"

# game/characters_events_idles/maya_events.rpy:465
translate spanish maya_scene6_evening_myroom_c3936052:

    # Maya "Ничего не было"
    Maya "No hubiera pasado nada"

# game/characters_events_idles/maya_events.rpy:467
translate spanish maya_scene6_evening_myroom_ba188167:

    # gg "Я не делаю вид"
    gg "No estoy fingiendo"

# game/characters_events_idles/maya_events.rpy:469
translate spanish maya_scene6_evening_myroom_4dd50b6c:

    # Maya "Ладно, не важно"
    Maya "Vale, no importa"

# game/characters_events_idles/maya_events.rpy:471
translate spanish maya_scene6_evening_myroom_7eaa97d1:

    # Maya "Залипай дальше"
    Maya "Sigue absorto"

# game/characters_events_idles/maya_events.rpy:479
translate spanish maya_scene6_evening_myroom_3c725bc9:

    # Maya "Слушай"
    Maya "Escucha"

# game/characters_events_idles/maya_events.rpy:480
translate spanish maya_scene6_evening_myroom_250ec1e3:

    # Maya "А ты сейчас сильно занят?"
    Maya "¿Estás muy ocupado ahora?"

# game/characters_events_idles/maya_events.rpy:482
translate spanish maya_scene6_evening_myroom_5ea33f12:

    # gg "Если честно — нет"
    gg "Siendo honesto, no"

# game/characters_events_idles/maya_events.rpy:486
translate spanish maya_scene6_evening_myroom_f9cfb58e:

    # Maya "Я просто спросила"
    Maya "Solo preguntaba"

# game/characters_events_idles/maya_events.rpy:488
translate spanish maya_scene6_evening_myroom_70c7e32f:

    # gg "А я просто отвечаю"
    gg "Y solo estoy respondiendo"

# game/characters_events_idles/maya_events.rpy:489
translate spanish maya_scene6_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya "..."

# game/characters_events_idles/maya_events.rpy:491
translate spanish maya_scene6_evening_myroom_a2fcb33c:

    # Maya "Поможешь мне кое с чем"
    Maya "¿Me ayudas con algo?"

# game/characters_events_idles/maya_events.rpy:493
translate spanish maya_scene6_evening_myroom_19d648ec:

    # Maya "Это быстро"
    Maya "Es rápido"

# game/characters_events_idles/maya_events.rpy:497
translate spanish maya_scene6_evening_myroom_9619af02:

    # gg "С чем?"
    gg "¿Con qué?"

# game/characters_events_idles/maya_events.rpy:499
translate spanish maya_scene6_evening_myroom_0b3abc75:

    # Maya "Потом увидишь"
    Maya "Ya verás"

# game/characters_events_idles/maya_events.rpy:510
translate spanish maya_scene6_evening_myroom_5529e2cd:

    # Maya "Только без лишней заботы"
    Maya "Pero sin exagerar"

# game/characters_events_idles/maya_events.rpy:512
translate spanish maya_scene6_evening_myroom_52df9211:

    # gg "Как скажешь"
    gg "Como digas"

# game/characters_events_idles/maya_events.rpy:514
translate spanish maya_scene6_evening_myroom_3226a25c:

    # Maya "Посмотрим на что ты способен"
    Maya "Veamos de qué eres capaz"

# game/characters_events_idles/maya_events.rpy:516
translate spanish maya_scene6_evening_myroom_bca52f7e:

    # Maya "Ну"
    Maya "Bueno"

# game/characters_events_idles/maya_events.rpy:518
translate spanish maya_scene6_evening_myroom_1771af09:

    # Maya "Вот"
    Maya "Toma"

# game/characters_events_idles/maya_events.rpy:520
translate spanish maya_scene6_evening_myroom_ba718844:

    # Maya "Что застыл"
    Maya "¿Por qué te quedas helado?"

# game/characters_events_idles/maya_events.rpy:522
translate spanish maya_scene6_evening_myroom_806872f9:

    # gg "О и давно у тебя это?"
    gg "Oh, ¿y hace cuánto tienes esto?"

# game/characters_events_idles/maya_events.rpy:524
translate spanish maya_scene6_evening_myroom_7d6ca25f:

    # Maya "Очень"
    Maya "Mucho"

# game/characters_events_idles/maya_events.rpy:525
translate spanish maya_scene6_evening_myroom_40562848:

    # Maya "Ещё когда я делала вид"
    Maya "Desde cuando fingía"

# game/characters_events_idles/maya_events.rpy:527
translate spanish maya_scene6_evening_myroom_0b5a891a:

    # Maya "Что у меня есть дисциплина"
    Maya "Que tenía disciplina"

# game/characters_events_idles/maya_events.rpy:529
translate spanish maya_scene6_evening_myroom_51392b4e:

    # gg "В смысле?"
    gg "¿Cómo?"

# game/characters_events_idles/maya_events.rpy:531
translate spanish maya_scene6_evening_myroom_4a4b36f7:

    # Maya "Спорт"
    Maya "Deporte"

# game/characters_events_idles/maya_events.rpy:533
translate spanish maya_scene6_evening_myroom_bec9192a:

    # Maya "Секции, график, «надо»"
    Maya "Clases, horarios, 'deber'"

# game/characters_events_idles/maya_events.rpy:535
translate spanish maya_scene6_evening_myroom_201efa03:

    # Maya "Потом одна удачная травма"
    Maya "Luego una lesión oportuna"

# game/characters_events_idles/maya_events.rpy:537
translate spanish maya_scene6_evening_myroom_c633060c:

    # Maya "И всё"
    Maya "Y se acabó"

# game/characters_events_idles/maya_events.rpy:539
translate spanish maya_scene6_evening_myroom_46291e24:

    # Maya "Цирк закрылся"
    Maya "El circo se cerró"

# game/characters_events_idles/maya_events.rpy:541
translate spanish maya_scene6_evening_myroom_d39d8973:

    # gg "И ты бросила?"
    gg "¿Y lo dejaste?"

# game/characters_events_idles/maya_events.rpy:543
translate spanish maya_scene6_evening_myroom_9d7ad38f:

    # Maya "Я бы назвала это"
    Maya "Yo lo llamaría"

# game/characters_events_idles/maya_events.rpy:545
translate spanish maya_scene6_evening_myroom_ceee3b55:

    # Maya "«Энергосберегающий режим»"
    Maya "\"Modo de ahorro de energía\""

# game/characters_events_idles/maya_events.rpy:549
translate spanish maya_scene6_evening_myroom_9a044748:

    # gg "Теперь понятно почему ты так реагируешь"
    gg "Ahora entiendo por qué reaccionas así"

# game/characters_events_idles/maya_events.rpy:551
translate spanish maya_scene6_evening_myroom_5a3ffd6f:

    # Maya "Я просто не люблю"
    Maya "Simplemente no me gusta"

# game/characters_events_idles/maya_events.rpy:552
translate spanish maya_scene6_evening_myroom_2b6fd943:

    # Maya "Когда кто-то начинает"
    Maya "Cuando alguien empieza"

# game/characters_events_idles/maya_events.rpy:554
translate spanish maya_scene6_evening_myroom_8f57b276:

    # Maya "Объяснять мне как жить"
    Maya "A decirme cómo vivir"

# game/characters_events_idles/maya_events.rpy:557
translate spanish maya_scene6_evening_myroom_55d8d51b:

    # Maya "Вообщем нужно нанести крем и забинтовать"
    Maya "En fin, hay que aplicar crema y vendar"

# game/characters_events_idles/maya_events.rpy:559
translate spanish maya_scene6_evening_myroom_a23c1350:

    # gg "А к Соне почему не пошла?"
    gg "¿Y por qué no fuiste a Sonya?"

# game/characters_events_idles/maya_events.rpy:561
translate spanish maya_scene6_evening_myroom_17ee92c5:

    # Maya "По той же причине, а еще"
    Maya "Por la misma razón, y además"

# game/characters_events_idles/maya_events.rpy:562
translate spanish maya_scene6_evening_myroom_6a81a1e1:

    # Maya "Это всегда превращается"
    Maya "Siempre se convierte"

# game/characters_events_idles/maya_events.rpy:564
translate spanish maya_scene6_evening_myroom_f5a6f373:

    # Maya "В «давай я»"
    Maya "En un 'déjame a mí'"

# game/characters_events_idles/maya_events.rpy:566
translate spanish maya_scene6_evening_myroom_5d26e27b:

    # Maya "Она начинает суетиться"
    Maya "Ella se pone nerviosa"

# game/characters_events_idles/maya_events.rpy:567
translate spanish maya_scene6_evening_myroom_c1824ee1:

    # Maya "Делать больше, чем надо"
    Maya "A hacer más de lo necesario"

# game/characters_events_idles/maya_events.rpy:569
translate spanish maya_scene6_evening_myroom_9ad0074f:

    # Maya "А потом я виноватой себя чувствую"
    Maya "Y luego me siento culpable"

# game/characters_events_idles/maya_events.rpy:571
translate spanish maya_scene6_evening_myroom_ae8589c0:

    # gg "Кажется это называется забота"
    gg "Creo que a eso se le llama cuidado"

# game/characters_events_idles/maya_events.rpy:573
translate spanish maya_scene6_evening_myroom_a240282b:

    # Maya "Тогда давай посмотрим на твою заботу"
    Maya "Entonces veamos tu cuidado"

# game/characters_events_idles/maya_events.rpy:575
translate spanish maya_scene6_evening_myroom_29c79ddd:

    # Maya "Надеюсь только без драм"
    Maya "Espero que sin dramas"

# game/characters_events_idles/maya_events.rpy:577
translate spanish maya_scene6_evening_myroom_63c1dadc:

    # gg "Не собирался"
    gg "No era mi intención"

# game/characters_events_idles/maya_events.rpy:582
translate spanish maya_scene6_evening_myroom_41f1b09f:

    # gg "Можно?"
    gg "¿Puedo?"

# game/characters_events_idles/maya_events.rpy:590
translate spanish maya_scene6_evening_myroom_43813c59:

    # Maya "Не бойся"
    Maya "No tengas miedo"

# game/characters_events_idles/maya_events.rpy:591
translate spanish maya_scene6_evening_myroom_d139c2b0:

    # Maya "Я не из хрусталя"
    Maya "No soy de cristal"

# game/characters_events_idles/maya_events.rpy:594
translate spanish maya_scene6_evening_myroom_590f3ec6:

    # Maya "Ты всегда такой спокойный?"
    Maya "¿Siempre estás tan tranquilo?"

# game/characters_events_idles/maya_events.rpy:595
translate spanish maya_scene6_evening_myroom_79f7b16f:

    # gg "Не всегда"
    gg "No siempre"

# game/characters_events_idles/maya_events.rpy:597
translate spanish maya_scene6_evening_myroom_481c4421:

    # gg "Просто сейчас{w} нет смысла психовать"
    gg "Es que ahora mismo{w} no tiene sentido volverse loco"

# game/characters_events_idles/maya_events.rpy:599
translate spanish maya_scene6_evening_myroom_d38be043:

    # Maya "Понятно"
    Maya "Entiendo"

# game/characters_events_idles/maya_events.rpy:600
translate spanish maya_scene6_evening_myroom_41f6003e:

    # Maya "Экономишь нервы"
    Maya "Ahorras nervios"

# game/characters_events_idles/maya_events.rpy:601
translate spanish maya_scene6_evening_myroom_9ea43bc7:

    # Maya "Умно"
    Maya "Inteligente"

# game/characters_events_idles/maya_events.rpy:603
translate spanish maya_scene6_evening_myroom_b413e8d5:

    # gg "Можно сказать и так"
    gg "Se puede decir así"

# game/characters_events_idles/maya_events.rpy:606
translate spanish maya_scene6_evening_myroom_ea2de26b:

    # Maya "Теперь бинтуй"
    Maya "Ahora vendas"

# game/characters_events_idles/maya_events.rpy:614
translate spanish maya_scene6_evening_myroom_69d52a38:

    # Maya "Левее"
    Maya "Más a la izquierda"

# game/characters_events_idles/maya_events.rpy:618
translate spanish maya_scene6_evening_myroom_a9d70df9:

    # Maya "Нет{w} стой"
    Maya "No{w} espera"

# game/characters_events_idles/maya_events.rpy:620
translate spanish maya_scene6_evening_myroom_4b3bbffe:

    # Maya "Вот так"
    Maya "Así"

# game/characters_events_idles/maya_events.rpy:624
translate spanish maya_scene6_evening_myroom_9ee64c2c:

    # Maya "Ты вообще смотришь, что делаешь?"
    Maya "¿Acaso miras lo que estás haciendo?"

# game/characters_events_idles/maya_events.rpy:626
translate spanish maya_scene6_evening_myroom_d39f0951:

    # gg "Мая"
    gg "Maya"

# game/characters_events_idles/maya_events.rpy:628
translate spanish maya_scene6_evening_myroom_4e31a75d:

    # Maya "Нет, серьёзно"
    Maya "No, en serio"

# game/characters_events_idles/maya_events.rpy:629
translate spanish maya_scene6_evening_myroom_6049c785:

    # Maya "Ты сейчас наугад это бинтуешь"
    Maya "Ahora lo estás vendando al azar"

# game/characters_events_idles/maya_events.rpy:631
translate spanish maya_scene6_evening_myroom_7e1fd344:

    # Maya "Или делаешь вид"
    Maya "O estás fingiendo"

# game/characters_events_idles/maya_events.rpy:632
translate spanish maya_scene6_evening_myroom_84eb66b2:

    # Maya "Что уверен"
    Maya "Que estás seguro"

# game/characters_events_idles/maya_events.rpy:637
translate spanish maya_scene6_evening_myroom_d39f0951_1:

    # gg "Мая"
    gg "Maya"

# game/characters_events_idles/maya_events.rpy:639
translate spanish maya_scene6_evening_myroom_9db87034:

    # gg "Если тебе так проще - я выйду"
    gg "Si te es más fácil, me iré"

# game/characters_events_idles/maya_events.rpy:641
translate spanish maya_scene6_evening_myroom_eb8fc374:

    # Maya "Подожди"
    Maya "Espera"

# game/characters_events_idles/maya_events.rpy:647
translate spanish maya_scene6_evening_myroom_43dc5209:

    # Maya "Я . . .{w} не это имела в виду"
    Maya "Yo...{w} no me refería a eso"

# game/characters_events_idles/maya_events.rpy:649
translate spanish maya_scene6_evening_myroom_e89a435e:

    # Maya "Просто . . ."
    Maya "Es que..."

# game/characters_events_idles/maya_events.rpy:651
translate spanish maya_scene6_evening_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "No te vayas"

# game/characters_events_idles/maya_events.rpy:661
translate spanish maya_scene6_evening_myroom_0e9018a1:

    # gg "Иии"
    gg "Y..."

# game/characters_events_idles/maya_events.rpy:663
translate spanish maya_scene6_evening_myroom_15ebc100:

    # gg "Операция закончена"
    gg "Operación terminada"

# game/characters_events_idles/maya_events.rpy:667
translate spanish maya_scene6_evening_myroom_1ceba70d:

    # Maya "Спасибо"
    Maya "Gracias"

# game/characters_events_idles/maya_events.rpy:680
translate spanish maya_scene6_evening_myroom_6fdd6424:

    # Maya "Не привыкай"
    Maya "No te acostumbres"

# game/characters_events_idles/maya_events.rpy:683
translate spanish maya_scene6_evening_myroom_63c1dadc_1:

    # gg "Не собирался"
    gg "No era mi intención"

# game/characters_events_idles/maya_events.rpy:705
translate spanish maya_scene7_night_mayaroom_fec75b67:

    # gg "Ты до сих пор за ноутом?"
    gg "¿Todavía estás con el portátil?"

# game/characters_events_idles/maya_events.rpy:706
translate spanish maya_scene7_night_mayaroom_762dfc55:

    # gg "Уже за полночь"
    gg "Ya es pasada la medianoche"

# game/characters_events_idles/maya_events.rpy:708
translate spanish maya_scene7_night_mayaroom_0d6d9e7f:

    # Maya "И что?"
    Maya "¿Y qué?"

# game/characters_events_idles/maya_events.rpy:709
translate spanish maya_scene7_night_mayaroom_f874de68:

    # Maya "У меня дела в отличие от некоторых"
    Maya "Yo tengo cosas que hacer, a diferencia de algunos"

# game/characters_events_idles/maya_events.rpy:711
translate spanish maya_scene7_night_mayaroom_6b992d2b:

    # gg "Уже ночь"
    gg "Ya es de noche"

# game/characters_events_idles/maya_events.rpy:713
translate spanish maya_scene7_night_mayaroom_730b6969:

    # gg "А переписка это работа?"
    gg "¿Y chatear es trabajo?"

# game/characters_events_idles/maya_events.rpy:716
translate spanish maya_scene7_night_mayaroom_ca9eb87e:

    # Maya "Да мои дела"
    Maya "Sí, mis asuntos"

# game/characters_events_idles/maya_events.rpy:718
translate spanish maya_scene7_night_mayaroom_e1a35225:

    # Maya "Вечно лезешь туда, куда не зовут"
    Maya "Siempre te metes donde no te llaman"

# game/characters_events_idles/maya_events.rpy:720
translate spanish maya_scene7_night_mayaroom_54c856a0:

    # gg "А дверь открытая{w}, значит ждала"
    gg "Y la puerta está abierta{w}, eso significa que esperabas"

# game/characters_events_idles/maya_events.rpy:722
translate spanish maya_scene7_night_mayaroom_5ebc71c5:

    # Maya "Ждала?"
    Maya "¿Esperaba?"

# game/characters_events_idles/maya_events.rpy:724
translate spanish maya_scene7_night_mayaroom_ab53ee69:

    # Maya "Только если дурака, чтобы под руку мешался"
    Maya "Solo si esperaba a un tonto que se interpusiera"

# game/characters_events_idles/maya_events.rpy:725
translate spanish maya_scene7_night_mayaroom_e04cd055:

    # gg_chat "На вид она слишком устала для настоящей злости"
    gg_chat "Parece demasiado cansada para estar realmente enfadada"

# game/characters_events_idles/maya_events.rpy:730
translate spanish maya_scene7_night_mayaroom_8876fd31:

    # Maya "ЭЭ"
    Maya "¡EH!"

# game/characters_events_idles/maya_events.rpy:733
translate spanish maya_scene7_night_mayaroom_588c8161:

    # Maya "Не смей! Это моё!" with hpunch
    Maya "¡No te atrevas! ¡Esto es mío!" with hpunch

# game/characters_events_idles/maya_events.rpy:735
translate spanish maya_scene7_night_mayaroom_30b1c14e:

    # gg "Да я и не собирался читать"
    gg "Ni siquiera iba a leerlo"

# game/characters_events_idles/maya_events.rpy:736
translate spanish maya_scene7_night_mayaroom_4d7029b4:

    # gg "Просто . . . {w}ты могла бы не прятать"
    gg "Es que...{w} no tenías que esconderlo"

# game/characters_events_idles/maya_events.rpy:738
translate spanish maya_scene7_night_mayaroom_43898c08:

    # Maya "Потому что . . ."
    Maya "Porque..."

# game/characters_events_idles/maya_events.rpy:740
translate spanish maya_scene7_night_mayaroom_7673a52d:

    # Maya "C тобой я . . ."
    Maya "Contigo yo..."

# game/characters_events_idles/maya_events.rpy:747
translate spanish maya_scene7_night_mayaroom_d57c47f7:

    # Maya ". . . "
    Maya "..."

# game/characters_events_idles/maya_events.rpy:748
translate spanish maya_scene7_night_mayaroom_8b57d927:

    # Maya ". . . {w}Я не своя . . ."
    Maya "...{w}No soy yo misma..."

# game/characters_events_idles/maya_events.rpy:749
translate spanish maya_scene7_night_mayaroom_6f9409ff:

    # Maya "Я всё время о тебе думаю"
    Maya "Pienso en ti todo el tiempo"

# game/characters_events_idles/maya_events.rpy:754
translate spanish maya_scene7_night_mayaroom_df75b7f4:

    # Maya "С тобой я только и делаю, что тупею!"
    Maya "¡Contigo lo único que hago es volverme tonta!"

# game/characters_events_idles/maya_events.rpy:756
translate spanish maya_scene7_night_mayaroom_578ec278:

    # Maya "Вот и всё"
    Maya "Eso es todo"

# game/characters_events_idles/maya_events.rpy:761
translate spanish maya_scene7_night_mayaroom_b56e467a:

    # gg "Ты прячешься за словами, но глаза выдают всё"
    gg "Te escondes tras palabras, pero tus ojos lo delatan todo"

# game/characters_events_idles/maya_events.rpy:769
translate spanish maya_scene7_night_mayaroom_b0f630ba:

    # Maya "{size=*0.8}. . . Дурак . . .{/size}"
    Maya "{size=*0.8}... Tonto...{/size}"

# game/characters_events_idles/maya_events.rpy:770
translate spanish maya_scene7_night_mayaroom_8e74b6e2:

    # Maya "Если кому-то скажешь - я тебя прибью" with hpunch
    Maya "Si se lo dices a alguien, te mataré" with hpunch

# game/characters_events_idles/maya_events.rpy:774
translate spanish maya_scene7_night_mayaroom_03506582:

    # gg "Угрожаешь после такого? {w}Смелая"
    gg "¿Amenazas después de eso? {w}Valiente"

# game/characters_events_idles/maya_events.rpy:777
translate spanish maya_scene7_night_mayaroom_991c3acc:

    # gg "Никому {w}только между нами"
    gg "A nadie {w}solo entre nosotros"

# game/characters_events_idles/maya_events.rpy:792
translate spanish maya_scene8_morning_mayaroom_3ccef67b:

    # gg_chat "Она выглядит . . . спокойно {w}Никакой злости {w} даже странно"
    gg_chat "Se ve... tranquila {w}Sin enfado {w} incluso extraño"

# game/characters_events_idles/maya_events.rpy:794
translate spanish maya_scene8_morning_mayaroom_8e119e79:

    # Maya "Ты чё . . . {w}уже встал?.."
    Maya "¿Qué... {w}ya te levantaste?..."

# game/characters_events_idles/maya_events.rpy:796
translate spanish maya_scene8_morning_mayaroom_fb3f31cf:

    # gg "Эм . . . да. Я не хотел мешать. Просто заглянул"
    gg "Mm... sí. No quería molestar. Solo pasaba por aquí"

# game/characters_events_idles/maya_events.rpy:798
translate spanish maya_scene8_morning_mayaroom_0a978bde:

    # Maya "Не уходи . . ."
    Maya "No te vayas..."

# game/characters_events_idles/maya_events.rpy:800
translate spanish maya_scene8_morning_mayaroom_3a0bea4a:

    # Maya "Сядь"
    Maya "Siéntate"

# game/characters_events_idles/maya_events.rpy:805
translate spanish maya_scene8_morning_mayaroom_970fe7c6:

    # Maya "Спала ужасно . . ."
    Maya "Dormí fatal..."

# game/characters_events_idles/maya_events.rpy:807
translate spanish maya_scene8_morning_mayaroom_4ada6f49:

    # Maya "Всё крутилось в голове"
    Maya "Todo me daba vueltas en la cabeza"

# game/characters_events_idles/maya_events.rpy:808
translate spanish maya_scene8_morning_mayaroom_ee85048c:

    # Maya "Не выспалась"
    Maya "No dormí suficiente"

# game/characters_events_idles/maya_events.rpy:810
translate spanish maya_scene8_morning_mayaroom_30004a57:

    # gg "А у тебя будто энергии с утра через край"
    gg "Y tú pareces desbordar energía por la mañana"

# game/characters_events_idles/maya_events.rpy:812
translate spanish maya_scene8_morning_mayaroom_c4e0d6af:

    # Maya "Очень смешно . . . "
    Maya "Muy gracioso..."

# game/characters_events_idles/maya_events.rpy:814
translate spanish maya_scene8_morning_mayaroom_c574ca14:

    # Maya "Я лентяйка {w}просто иногда притворяюсь"
    Maya "Soy una perezosa {w}solo que a veces finjo"

# game/characters_events_idles/maya_events.rpy:816
translate spanish maya_scene8_morning_mayaroom_42c46aa1:

    # Maya "Ляг"
    Maya "Acuéstate"

# game/characters_events_idles/maya_events.rpy:817
translate spanish maya_scene8_morning_mayaroom_9e620d29:

    # Maya "Просто . . . {w}чтоб теплее было"
    Maya "Solo... {w}para que haga más calor"

# game/characters_events_idles/maya_events.rpy:821
translate spanish maya_scene8_morning_mayaroom_d012bf21:

    # gg "Ты не заболела случайно?"
    gg "¿No estarás enferma por casualidad?"

# game/characters_events_idles/maya_events.rpy:824
translate spanish maya_scene8_morning_mayaroom_06609c2f:

    # Maya "Убью, если кому-то расскажешь"
    Maya "Te mato si se lo cuentas a alguien"

# game/characters_events_idles/maya_events.rpy:827
translate spanish maya_scene8_morning_mayaroom_aed6c2f3:

    # gg_chat "Может это мой шанс . . ."
    gg_chat "Tal vez sea mi oportunidad..."

# game/characters_events_idles/maya_events.rpy:833
translate spanish maya_scene8_morning_mayaroom_7f5f7cbf:

    # Maya "Дурак . . ."
    Maya "Tonto..."

# game/characters_events_idles/maya_events.rpy:837
translate spanish maya_scene8_morning_mayaroom_f7f3b708:

    # gg_chat "Слишком спокойно . . ."
    gg_chat "Demasiado tranquila..."

# game/characters_events_idles/maya_events.rpy:838
translate spanish maya_scene8_morning_mayaroom_fc2580e2:

    # gg_chat "Значит, самое время тихо уйти"
    gg_chat "Entonces, es el momento de irme en silencio"

# game/characters_events_idles/maya_events.rpy:841
translate spanish maya_scene8_morning_mayaroom_4b32219f:

    # gg_chat "Никогда бы не подумал, что первый поцелуй с ней будет таким"
    gg_chat "Nunca pensé que el primer beso con ella sería así"

# game/characters_events_idles/maya_events.rpy:845
translate spanish maya_scene8_morning_mayaroom_31bdebc7:

    # gg_chat "Вот бы всегда так . . ."
    gg_chat "Ojalá fuera siempre así..."

# game/characters_events_idles/maya_events.rpy:846
translate spanish maya_scene8_morning_mayaroom_7d3e081f:

    # gg_chat "Но, зная её, лучше не задерживаться"
    gg_chat "Pero, conociéndola, mejor no quedarme"

# game/characters_events_idles/maya_events.rpy:851
translate spanish maya_scene8_morning_mayaroom_f57b1e37:

    # gg_chat "Мягкость её груди всё ещё чувствовалась . . ."
    gg_chat "Todavía podía sentir la suavidad de sus pechos..."

# game/characters_events_idles/maya_events.rpy:852
translate spanish maya_scene8_morning_mayaroom_ba3923be:

    # gg_chat "И отпускать не хотелось"
    gg_chat "Y no quería soltarla"

# game/characters_events_idles/maya_events.rpy:872
translate spanish maya_scene9_day_kitchen_b483553f:

    # Maya "О ты тут, помоги посыпать соль"
    Maya "Oh, estás aquí, ayúdame a echar la sal"

# game/characters_events_idles/maya_events.rpy:874
translate spanish maya_scene9_day_kitchen_564e6225:

    # gg "Окей"
    gg "Vale"

# game/characters_events_idles/maya_events.rpy:877
translate spanish maya_scene9_day_kitchen_7d928982:

    # Maya "И аккуратней, а то пересолишь"
    Maya "Y con cuidado, que si no la sobre-salas"

# game/characters_events_idles/maya_events.rpy:887
translate spanish maya_scene9_day_kitchen_29721060:

    # Maya "Так . . . {w}вот теперь оно прилипло к сковородке"
    Maya "Así... {w}ahora se ha pegado a la sartén"

# game/characters_events_idles/maya_events.rpy:888
translate spanish maya_scene9_day_kitchen_11cbabe0:

    # Maya "Прям не оторвать"
    Maya "No hay manera de despegarlo"

# game/characters_events_idles/maya_events.rpy:889
translate spanish maya_scene9_day_kitchen_927dfd8a:

    # gg "Тогда надо поддеть снизу, чтобы не пригорело"
    gg "Entonces hay que levantarlo desde abajo, para que no se queme"

# game/characters_events_idles/maya_events.rpy:892
translate spanish maya_scene9_day_kitchen_b2073f58:

    # Maya "Главное - не давить слишком резко"
    Maya "Lo principal es no presionar demasiado bruscamente"

# game/characters_events_idles/maya_events.rpy:893
translate spanish maya_scene9_day_kitchen_e7cb36e7:

    # Maya "Иначе желток лопнет"
    Maya "Si no, la yema se romperá"

# game/characters_events_idles/maya_events.rpy:894
translate spanish maya_scene9_day_kitchen_23aa5a43:

    # gg "Но если аккуратно, всё останется целым"
    gg "Pero si es con cuidado, todo quedará intacto"

# game/characters_events_idles/maya_events.rpy:895
translate spanish maya_scene9_day_kitchen_0c33c9a7:

    # Maya "Угу . . . {w}мягче перемешивай"
    Maya "Ajá... {w}remueve más suavemente"

# game/characters_events_idles/maya_events.rpy:896
translate spanish maya_scene9_day_kitchen_7c4d7305:

    # Maya "Тогда всё прожарится равномерно"
    Maya "Así todo se cocinará uniformemente"

# game/characters_events_idles/maya_events.rpy:899
translate spanish maya_scene9_day_kitchen_b067ff5d:

    # Maya "Всё, почти готово . . ."
    Maya "Listo, casi terminado..."

# game/characters_events_idles/maya_events.rpy:900
translate spanish maya_scene9_day_kitchen_5805bb78:

    # Maya "Ещё чуть-чуть, и можно снимать с огня"
    Maya "Un poquito más y se puede retirar del fuego"

# game/characters_events_idles/maya_events.rpy:901
translate spanish maya_scene9_day_kitchen_c61ed5a8:

    # gg "Думаю, будет очень вкусно"
    gg "Creo que quedará muy sabroso"

# game/characters_events_idles/maya_events.rpy:905
translate spanish maya_scene9_day_kitchen_152dc2f3:

    # Maya "Всё {w}a то сейчас пережарим"
    Maya "Listo {w}que si no ahora se nos pasa"

# game/characters_events_idles/maya_events.rpy:907
translate spanish maya_scene9_day_kitchen_d98d84da:

    # Maya "Дальше сам себе готовь"
    Maya "A partir de ahora cocínate tú solo"

# game/characters_events_idles/maya_events.rpy:909
translate spanish maya_scene9_day_kitchen_c00c68f7:

    # gg_chat "Она подыгрывала"
    gg_chat "Ella estaba siguiendo el juego"

# game/characters_events_idles/maya_events.rpy:910
translate spanish maya_scene9_day_kitchen_8e86ab7e:

    # gg_chat "Но в конце всё равно сбежала . . ."
    gg_chat "Pero al final se escapó igualmente..."

# game/characters_events_idles/maya_events.rpy:928
translate spanish maya_scene10_evening_myroom_b792031e:

    # Maya "Я дома"
    Maya "Estoy en casa"

# game/characters_events_idles/maya_events.rpy:930
translate spanish maya_scene10_evening_myroom_4c632d43:

    # Maya "О, ты тут"
    Maya "Oh, estás aquí"

# game/characters_events_idles/maya_events.rpy:932
translate spanish maya_scene10_evening_myroom_e37dbd39:

    # gg "Привет. Как работа?"
    gg "Hola. ¿Cómo fue el trabajo?"

# game/characters_events_idles/maya_events.rpy:934
translate spanish maya_scene10_evening_myroom_92ca482a:

    # Maya "Словно вечность. Эта долбаные люди"
    Maya "Como una eternidad. Esa maldita gente"

# game/characters_events_idles/maya_events.rpy:936
translate spanish maya_scene10_evening_myroom_d1b85968:

    # gg "Хочешь чай? Или просто вырубиться?"
    gg "¿Quieres té? ¿O simplemente desconectar?"

# game/characters_events_idles/maya_events.rpy:938
translate spanish maya_scene10_evening_myroom_a28c5657:

    # Maya "Чай?{w} Ты решил внезапно заботиться?"
    Maya "¿Té?{w} ¿Has decidido de repente preocuparte?"

# game/characters_events_idles/maya_events.rpy:940
translate spanish maya_scene10_evening_myroom_ffaaaddc:

    # Maya "Ладно . . . да, пожалуй. И два сахара"
    Maya "Vale... sí, por favor. Y dos azúcares"

# game/characters_events_idles/maya_events.rpy:944
translate spanish maya_scene10_evening_myroom_fc470a50:

    # Maya "Уфф устала"
    Maya "Uff, estoy cansada"

# game/characters_events_idles/maya_events.rpy:946
translate spanish maya_scene10_evening_myroom_d751ae58:

    # gg "Может, поговорим?"
    gg "¿Quizás hablemos?"

# game/characters_events_idles/maya_events.rpy:948
translate spanish maya_scene10_evening_myroom_dd61a1d4:

    # Maya "О чём?"
    Maya "¿Sobre qué?"

# game/characters_events_idles/maya_events.rpy:950
translate spanish maya_scene10_evening_myroom_cb7be281:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Уволь"
    Maya "¿Sobre cómo volví a dejar la limpieza?{w} {bt=a3-p2.0-s3.0}Olvídalo"

# game/characters_events_idles/maya_events.rpy:952
translate spanish maya_scene10_evening_myroom_49e84409:

    # gg "Необязательно. Можно просто помолчать"
    gg "No es necesario. Podemos simplemente callarnos"

# game/characters_events_idles/maya_events.rpy:954
translate spanish maya_scene10_evening_myroom_963962a9:

    # Maya "Ты странный. Сидишь тут . . . как будто ждёшь чего-то"
    Maya "Eres raro. Sentado aquí... como si esperaras algo"

# game/characters_events_idles/maya_events.rpy:958
translate spanish maya_scene10_evening_myroom_31f86790:

    # gg "Может, и жду"
    gg "Tal vez sí esté esperando"

# game/characters_events_idles/maya_events.rpy:960
translate spanish maya_scene10_evening_myroom_7f342626:

    # Maya "Ты же знаешь, что я . . . колючая"
    Maya "Sabes que soy... espinosa"

# game/characters_events_idles/maya_events.rpy:962
translate spanish maya_scene10_evening_myroom_27989031:

    # gg "Знаю"
    gg "Lo sé"

# game/characters_events_idles/maya_events.rpy:964
translate spanish maya_scene10_evening_myroom_91a19161:

    # Maya "И что я всё испорчу"
    Maya "Y que lo arruinaré todo"

# game/characters_events_idles/maya_events.rpy:966
translate spanish maya_scene10_evening_myroom_d6704538:

    # Maya "Обязательно ляпну какую-нибудь чушь"
    Maya "Seguro que soltaré alguna tontería"

# game/characters_events_idles/maya_events.rpy:968
translate spanish maya_scene10_evening_myroom_489ce109:

    # gg "{bt=a3-p2.0-s3.0}{size=*0.8}Привык уже"
    gg "{bt=a3-p2.0-s3.0}{size=*0.8}Ya me he acostumbrado"

# game/characters_events_idles/maya_events.rpy:974
translate spanish maya_scene10_evening_myroom_c0ac8816:

    # Maya "Ну конечно. Самое время для этого"
    Maya "Pues claro. El momento perfecto para esto"

# game/characters_events_idles/maya_events.rpy:976
translate spanish maya_scene10_evening_myroom_ec57c0d1:

    # gg "Май . . ."
    gg "Maya..."

# game/characters_events_idles/maya_events.rpy:978
translate spanish maya_scene10_evening_myroom_16a831f4:

    # Maya "Заткнись"
    Maya "Cállate"

# game/characters_events_idles/maya_events.rpy:980
translate spanish maya_scene10_evening_myroom_71044ba9:

    # Maya "Просто . . . заткнись"
    Maya "Simplemente... cállate"

# game/characters_events_idles/maya_events.rpy:990
translate spanish maya_scene10_evening_myroom_742929c8:

    # Maya "Тише . . . Осторожно. Я не . . .{w} Я не готова ко всему сразу"
    Maya "Tranquilo... Con cuidado. No...{w} No estoy preparada para todo de una vez"

# game/characters_events_idles/maya_events.rpy:996
translate spanish maya_scene10_evening_myroom_66b26945:

    # Maya "Ох . . . боже . . ."
    Maya "Oh... Dios..."

# game/aracters_events_idles/maya_events.rpy:1008
translate spanish maya_scene10_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya "..."

# game/characters_events_idles/maya_events.rpy:1010
translate spanish maya_scene10_evening_myroom_71253d69:

    # Maya "Вот это да . . ."
    Maya "Vaya..."

# game/characters_events_idles/maya_events.rpy:1012
translate spanish maya_scene10_evening_myroom_22f5a5a6:

    # Maya "Ты это . . . там всё время носил?"
    Maya "¿Tú esto... lo llevabas ahí todo el tiempo?"

# game/characters_events_idles/maya_events.rpy:1018
translate spanish maya_scene10_evening_myroom_c014a37d:

    # Maya "Нет . . ."
    Maya "No..."

# game/characters_events_idles/maya_events.rpy:1020
translate spanish maya_scene10_evening_myroom_2d2f095f:

    # Maya "Нет, стоп"
    Maya "No, para"

# game/characters_events_idles/maya_events.rpy:1022
translate spanish maya_scene10_evening_myroom_6b00b07b:

    # Maya "Стоп, блядь"
    Maya "Para, joder"

# game/characters_events_idles/maya_events.rpy:1024
translate spanish maya_scene10_evening_myroom_f3f9fdab:

    # gg "Майя?"
    gg "¿Maya?"

# game/characters_events_idles/maya_events.rpy:1026
translate spanish maya_scene10_evening_myroom_b9eafd1f:

    # Maya "Выйди. Пожалуйста.{w} Просто . . . выйди"
    Maya "Sal. Por favor.{w} Simplemente... sal"

# game/characters_events_idles/maya_events.rpy:1028
translate spanish maya_scene10_evening_myroom_92d5f1bf:

    # gg "Я . . .{w} Я не хотел . . ."
    gg "Yo...{w} No quería..."

# game/characters_events_idles/maya_events.rpy:1030
translate spanish maya_scene10_evening_myroom_e6bbb658:

    # Maya "{sc}{size=*1.2}Я ЗНАЮ{/size}{/sc}, что не хотел!"
    Maya "{sc}{size=*1.2}¡LO SÉ{/size}{/sc} que no querías!"

# game/characters_events_idles/maya_events.rpy:1032
translate spanish maya_scene10_evening_myroom_9ef6f711:

    # Maya "Именно поэтому — ВЫЙДИ!"
    Maya "¡Por eso mismo — SAL!"

# game/characters_events_idles/maya_events.rpy:1034
translate spanish maya_scene10_evening_myroom_85e3ca37:

    # Maya "Не сейчас . . .{w} Я не могу{w} Это слишком . . . реально"
    Maya "Ahora no...{w} No puedo{w} Esto es demasiado... real"

# game/characters_events_idles/maya_events.rpy:1036
translate spanish maya_scene10_evening_myroom_a4abe766:

    # gg "Хорошо. Я . . .{w} Я ушёл"
    gg "Vale. Yo...{w} Me voy"

# game/characters_events_idles/maya_events.rpy:1040
translate spanish maya_scene10_evening_myroom_8454737d:

    # Maya "{size=*0.8}Чёрт . . . Чёрт . . . Чёрт . . ."
    Maya "{size=*0.8}Mierda... Mierda... Mierda..."

# game/characters_events_idles/maya_events.rpy:1041
translate spanish maya_scene10_evening_myroom_c2f04aea:

    # Maya "{size=*0.8}Он такой . . . большой . . ."
    Maya "{size=*0.8}Es tan... grande..."

# game/characters_events_idles/maya_events.rpy:1043
translate spanish maya_scene10_evening_myroom_828ad43f:

    # Maya "{size=*0.8}И мне . . ."
    Maya "{size=*0.8}Y a mí..."

# game/characters_events_idles/maya_events.rpy:1044
translate spanish maya_scene10_evening_myroom_b4c5d69e:

    # Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Понравилось"
    Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Me gustó"

# game/characters_events_idles/maya_events.rpy:1061
translate spanish maya_scene11_morning_bathroom_bd1a48b9:

    # gg "Ты с утра за стиркой"
    gg "Estás lavando ropa desde la mañana"

# game/characters_events_idles/maya_events.rpy:1062
translate spanish maya_scene11_morning_bathroom_17ad5908:

    # gg "Это что то мифическое"
    gg "Eso es algo mítico"

# game/characters_events_idles/maya_events.rpy:1064
translate spanish maya_scene11_morning_bathroom_2998d6f9:

    # Maya "Миф"
    Maya "Mito"

# game/characters_events_idles/maya_events.rpy:1066
translate spanish maya_scene11_morning_bathroom_fa12fc4b:

    # Maya "Это если бы ты сам что-то постирал"
    Maya "Eso sería si tú mismo lavaras algo"

# game/characters_events_idles/maya_events.rpy:1071
translate spanish maya_scene11_morning_bathroom_10404fc0:

    # gg "Я хотя бы свои вещи складываю"
    gg "Yo al menos doblo mis cosas"

# game/characters_events_idles/maya_events.rpy:1073
translate spanish maya_scene11_morning_bathroom_cfff324a:

    # gg "А твои валялись по всей комнате"
    gg "Y las tuyas estaban tiradas por toda la habitación"

# game/characters_events_idles/maya_events.rpy:1075
translate spanish maya_scene11_morning_bathroom_67c05e6d:

    # Maya "И кто же их собрал? Не ты"
    Maya "¿Y quién las recogió? Tú no"

# game/characters_events_idles/maya_events.rpy:1077
translate spanish maya_scene11_morning_bathroom_b4e5e9ee:

    # gg "Ещё чуть-чуть, и я подумаю, что ты скрытая трудяга"
    gg "Un poquito más y pensaré que eres una trabajadora oculta"

# game/characters_events_idles/maya_events.rpy:1079
translate spanish maya_scene11_morning_bathroom_4907bae2:

    # Maya "Чего говоришь!"
    Maya "¡Qué dices!"

# game/characters_events_idles/maya_events.rpy:1081
translate spanish maya_scene11_morning_bathroom_eaaef249:

    # Maya "Думаешь я настолько лентяйка?"
    Maya "¿Crees que soy tan perezosa?"

# game/characters_events_idles/maya_events.rpy:1083
translate spanish maya_scene11_morning_bathroom_062411d1:

    # gg "Думаю"
    gg "Creo que sí"

# game/characters_events_idles/maya_events.rpy:1088
translate spanish maya_scene11_morning_bathroom_b708dc2c:

    # gg "Ты кое что забыла поставить на стирку"
    gg "Te has olvidado de poner algo a lavar"

# game/characters_events_idles/maya_events.rpy:1096
translate spanish maya_scene11_morning_bathroom_8c8070f2:

    # Maya "Ах так?"
    Maya "¿Ah, sí?"

# game/characters_events_idles/maya_events.rpy:1098
translate spanish maya_scene11_morning_bathroom_cb35be97:

    # Maya "Тогда стираем всё"
    Maya "Entonces lavamos todo"

# game/characters_events_idles/maya_events.rpy:1104
translate spanish maya_scene11_morning_bathroom_cf4d3425:

    # Maya "Ага . . ."
    Maya "Ajá..."

# game/characters_events_idles/maya_events.rpy:1106
translate spanish maya_scene11_morning_bathroom_fa661e9f:

    # Maya "Похоже ЭТО нужно будет стирать деликатно"
    Maya "Parece que ESTO habrá que lavarlo con delicadeza"

# game/characters_events_idles/maya_events.rpy:1108
translate spanish maya_scene11_morning_bathroom_9cd0adf2:

    # Maya "Думаю мы можем продолжить на чем закончили?"
    Maya "¿Creo que podemos continuar donde lo dejamos?"

# game/characters_events_idles/maya_events.rpy:1112
translate spanish maya_scene11_morning_bathroom_84b09d0d:

    # Maya "Стиралка работает . . . {w}но тут жарче, чем должно быть"
    Maya "La lavadora funciona... {w}pero aquí hace más calor de lo que debería"

# game/characters_events_idles/maya_events.rpy:1113
translate spanish maya_scene11_morning_bathroom_6df3a5e2:

    # gg "Главное - достирай до конца"
    gg "Lo principal es llegar hasta el final"

# game/characters_events_idles/maya_events.rpy:1114
translate spanish maya_scene11_morning_bathroom_d0b88dcb:

    # gg "Если оставишь придется домывать . . ."
    gg "Si lo dejas, tendrás que terminarlo..."

# game/characters_events_idles/maya_events.rpy:1119
translate spanish maya_scene11_morning_bathroom_0467b855:

    # Maya "Так я думаю стиралка сама справится"
    Maya "Pues yo creo que la lavadora puede sola"

# game/characters_events_idles/maya_events.rpy:1122
translate spanish maya_scene11_morning_bathroom_542d4b95:

    # Maya "А ты . . . {w}сам достирай свое"
    Maya "Y tú... {w}termina lo tuyo tú mismo"

# game/characters_events_idles/maya_events.rpy:1123
translate spanish maya_scene11_morning_bathroom_83b51400:

    # Maya "Белье . . ."
    Maya "La ropa..."

# game/characters_events_idles/maya_events.rpy:1129
translate spanish maya_scene11_morning_bathroom_eb975221:

    # gg_chat "Она ушла . . ."
    gg_chat "Se ha ido..."

# game/characters_events_idles/maya_events.rpy:1130
translate spanish maya_scene11_morning_bathroom_3188cfc5:

    # gg_chat "В следующий раз ее нельзя отпускать . . ."
    gg_chat "La próxima vez no hay que dejarla ir..."

# game/characters_events_idles/maya_events.rpy:1147
translate spanish maya_scene12_evening_myroom_bb653a62:

    # Maya "Ха, так вот где ты спрятался"
    Maya "Ja, así que aquí es donde te escondías"

# game/characters_events_idles/maya_events.rpy:1149
translate spanish maya_scene12_evening_myroom_4ca35500:

    # Maya "И что ты смотришь?"
    Maya "¿Y qué estás viendo?"

# game/characters_events_idles/maya_events.rpy:1151
translate spanish maya_scene12_evening_myroom_7e8ca4c6:

    # gg "Подожди я в матче"
    gg "Espera, estoy en el partido"

# game/characters_events_idles/maya_events.rpy:1152
translate spanish maya_scene12_evening_myroom_5ed608a5:

    # gg "Если отвлекусь - проиграю"
    gg "Si me distraigo, perderé"

# game/characters_events_idles/maya_events.rpy:1154
translate spanish maya_scene12_evening_myroom_8f98104b:

    # Maya "И это, по-твоему, веселье?"
    Maya "¿Y esto, según tú, es divertido?"

# game/characters_events_idles/maya_events.rpy:1156
translate spanish maya_scene12_evening_myroom_336dd03a:

    # gg "Когда сам играешь намного веселее . . ."
    gg "Cuando juegas tú, es mucho más divertido..."

# game/characters_events_idles/maya_events.rpy:1158
translate spanish maya_scene12_evening_myroom_3a2af852:

    # Maya "А по мне, как будто трата времени"
    Maya "A mí me parece una pérdida de tiempo"

# game/characters_events_idles/maya_events.rpy:1160
translate spanish maya_scene12_evening_myroom_814660f9:

    # gg "Эй!" with hpunch
    gg "¡Oye!" with hpunch

# game/characters_events_idles/maya_events.rpy:1161
translate spanish maya_scene12_evening_myroom_a589a29a:

    # gg "Я ничего не вижу!"
    gg "¡No veo nada!"

# game/characters_events_idles/maya_events.rpy:1162
translate spanish maya_scene12_evening_myroom_6d7f26d1:

    # Maya "Ну и что?"
    Maya "¿Y qué?"

# game/characters_events_idles/maya_events.rpy:1164
translate spanish maya_scene12_evening_myroom_8bb854aa:

    # Maya "Почему перестал играть?"
    Maya "¿Por qué dejaste de jugar?"

# game/characters_events_idles/maya_events.rpy:1166
translate spanish maya_scene12_evening_myroom_9c0bce5d:

    # gg "Я же сказал"
    gg "Ya te lo dije"

# game/characters_events_idles/maya_events.rpy:1168
translate spanish maya_scene12_evening_myroom_4430c970:

    # gg "Теперь только тебя и вижу"
    gg "Ahora solo te veo a ti"

# game/characters_events_idles/maya_events.rpy:1170
translate spanish maya_scene12_evening_myroom_e1ca96ab:

    # Maya "Вот и отлично!"
    Maya "¡Pues perfecto!"

# game/characters_events_idles/maya_events.rpy:1172
translate spanish maya_scene12_evening_myroom_e638502a:

    # Maya "Я теперь главный игрок"
    Maya "Ahora soy la jugadora principal"

# game/characters_events_idles/maya_events.rpy:1174
translate spanish maya_scene12_evening_myroom_1751458f:

    # gg "Ты щас мне рейтинг сольешь"
    gg "Ahora vas a arruinar mi puntuación"

# game/characters_events_idles/maya_events.rpy:1176
translate spanish maya_scene12_evening_myroom_ce7e136c:

    # Maya "Да ну, я просто проверяю"
    Maya "Bah, solo estoy probando"

# game/characters_events_idles/maya_events.rpy:1178
translate spanish maya_scene12_evening_myroom_81a51f30:

    # Maya "Как тут . . . прыгает!"
    Maya "¡Cómo salta aquí...!"

# game/characters_events_idles/maya_events.rpy:1180
translate spanish maya_scene12_evening_myroom_c46a67aa:

    # Maya "Ой, а это что делает?"
    Maya "Oh, ¿y esto qué hace?"

# game/characters_events_idles/maya_events.rpy:1181
translate spanish maya_scene12_evening_myroom_9260e289:

    # gg "Стой, не так"
    gg "Espera, no así"

# game/characters_events_idles/maya_events.rpy:1183
translate spanish maya_scene12_evening_myroom_16a342c4:

    # gg "Вот эта - стрелять, эта - использовать"
    gg "Esta es para disparar, esta para usar"

# game/characters_events_idles/maya_events.rpy:1185
translate spanish maya_scene12_evening_myroom_c634457f:

    # gg "Держи крепче, смотри в экран"
    gg "Sujétalo bien, mira la pantalla"

# game/characters_events_idles/maya_events.rpy:1188
translate spanish maya_scene12_evening_myroom_b18fd1da:

    # Maya "Мм . . ."
    Maya "Mm..."

# game/characters_events_idles/maya_events.rpy:1189
translate spanish maya_scene12_evening_myroom_3f637927:

    # Maya "Тут у тебя геймпад немного неудобный . . ."
    Maya "Tu mando aquí es un poco incómodo..."

# game/characters_events_idles/maya_events.rpy:1190
translate spanish maya_scene12_evening_myroom_8351e9a2:

    # gg "Нет . . . {w}я про . . ."
    gg "No... {w}me refiero a..."

# game/characters_events_idles/maya_events.rpy:1193
translate spanish maya_scene12_evening_myroom_c16d1061:

    # gg "Целься и стреляй"
    gg "Apunta y dispara"

# game/characters_events_idles/maya_events.rpy:1197
translate spanish maya_scene12_evening_myroom_cbd60b88:

    # Maya "А! Я попала по нему!"
    Maya "¡Ah! ¡Le di!"

# game/characters_events_idles/maya_events.rpy:1198
translate spanish maya_scene12_evening_myroom_15447830:

    # Maya "Но всё равно проиграла . . ."
    Maya "Pero igual perdí..."

# game/characters_events_idles/maya_events.rpy:1199
translate spanish maya_scene12_evening_myroom_9b0188df:

    # gg "Нужно время, чтобы научиться"
    gg "Se necesita tiempo para aprender"

# game/characters_events_idles/maya_events.rpy:1201
translate spanish maya_scene12_evening_myroom_3a4b5fe2:

    # Maya "Время?"
    Maya "¿Tiempo?"

# game/characters_events_idles/maya_events.rpy:1202
translate spanish maya_scene12_evening_myroom_7be2116f:

    # Maya "У меня терпения не хватит"
    Maya "No tengo suficiente paciencia"

# game/characters_events_idles/maya_events.rpy:1207
translate spanish maya_scene12_evening_myroom_502ea205:

    # Maya "Я лучше найду другой способ с тобой поиграть"
    Maya "Prefiero encontrar otra forma de jugar contigo"

# game/characters_events_idles/maya_events.rpy:1209
translate spanish maya_scene12_evening_myroom_d76b3a67:

    # gg "Похоже, тебе важнее сбить меня с толку . . ."
    gg "Parece que prefieres confundirme..."

# game/characters_events_idles/maya_events.rpy:1212
translate spanish maya_scene12_evening_myroom_9a170cb1:

    # Maya "Экран-то видишь ещё?"
    Maya "¿Aún ves la pantalla?"

# game/characters_events_idles/maya_events.rpy:1214
translate spanish maya_scene12_evening_myroom_7c6d2d03:

    # Maya "А это"
    Maya "Y esto,"

# game/characters_events_idles/maya_events.rpy:1216
translate spanish maya_scene12_evening_myroom_b1427dbd:

    # Maya "Не интереснее?"
    Maya "¿no es más interesante?"

# game/characters_events_idles/maya_events.rpy:1219
translate spanish maya_scene12_evening_myroom_2fd00100:

    # gg "Интереснее, но я хочу выиграть"
    gg "Lo es, pero quiero ganar"

# game/characters_events_idles/maya_events.rpy:1222
translate spanish maya_scene12_evening_myroom_161fdfc3:

    # Maya "Ну-ну"
    Maya "Vamos, vamos"

# game/characters_events_idles/maya_events.rpy:1223
translate spanish maya_scene12_evening_myroom_270d46ae:

    # Maya "Тогда держи удар"
    Maya "Entonces aguanta el golpe"

# game/characters_events_idles/maya_events.rpy:1227
translate spanish maya_scene12_evening_myroom_38cb6e8b:

    # Maya "Геймер"
    Maya "Gamer"

# game/characters_events_idles/maya_events.rpy:1229
translate spanish maya_scene12_evening_myroom_a093b46d:

    # gg_chat "Она решила так играть? . . ."
    gg_chat "¿Decidió jugar así...?"

# game/characters_events_idles/maya_events.rpy:1233
translate spanish maya_scene12_evening_myroom_5f58be75:

    # Maya "Давай, продолжай выигрывать"
    Maya "Vamos, sigue ganando"

# game/characters_events_idles/maya_events.rpy:1234
translate spanish maya_scene12_evening_myroom_6c6c4f14:

    # Maya "Интересно, надолго ли тебя хватит"
    Maya "Me pregunto cuánto aguantarás"

# game/characters_events_idles/maya_events.rpy:1235
translate spanish maya_scene12_evening_myroom_cc2a1c48:

    # gg "Мая . . ."
    gg "Maya..."

# game/characters_events_idles/maya_events.rpy:1236
translate spanish maya_scene12_evening_myroom_a757aa6b:

    # gg "Ты . . ."
    gg "Tú..."

# game/characters_events_idles/maya_events.rpy:1237
translate spanish maya_scene12_evening_myroom_2ca54e92:

    # Maya "Тише, я разбираюсь с управлением"
    Maya "Tranquilo, estoy aprendiendo los controles"

# game/characters_events_idles/maya_events.rpy:1243
translate spanish maya_scene12_evening_myroom_60a36ddd:

    # Maya "Ну что?"
    Maya "¿Y bien?"

# game/characters_events_idles/maya_events.rpy:1244
translate spanish maya_scene12_evening_myroom_6ab6d9ce:

    # Maya "Поражение засчитано?"
    Maya "¿Derrota contabilizada?"

# game/characters_events_idles/maya_events.rpy:1245
translate spanish maya_scene12_evening_myroom_c6558b58:

    # gg "Это вообще нечестная игра"
    gg "Esto no es un juego justo para nada"

# game/characters_events_idles/maya_events.rpy:1247
translate spanish maya_scene12_evening_myroom_c6b0e67a:

    # Maya "Нечестные победы самые сладкие"
    Maya "Las victorias injustas son las más dulces"

# game/characters_events_idles/maya_events.rpy:1248
translate spanish maya_scene12_evening_myroom_6e151f9e:

    # Maya "Теперь ты мой должник"
    Maya "Ahora estás en deuda conmigo"

translate spanish strings:

    # game/characters_events_idles/maya_events.rpy:742
    old "Договаривай"
    new "Negociar"

    # game/characters_events_idles/maya_events.rpy:752
    old ". . ."
    new "..."

    # game/characters_events_idles/maya_events.rpy:772
    old "Угрожаешь?"
    new "¿Estás amenazando?"

    # game/characters_events_idles/maya_events.rpy:775
    old "Никому"
    new "Nadie"

    # game/characters_events_idles/maya_events.rpy:829
    old "Тихо поцеловать её"
    new "Bésala en silencio"

    # game/characters_events_idles/maya_events.rpy:842
    old "Уткнуться в ее грудь"
    new "Entiérrate en su pecho"

# TODO: Translation updated at 2026-01-26 03:23

# game/characters_events_idles/maya_events.rpy:248
translate spanish maya_scene3_evening_kitchen_2c2f92cd:

    # Maya "Зачем так близко?"
    Maya "¿Por qué tan cerca?"

# game/characters_events_idles/maya_events.rpy:314
translate spanish maya_scene4_morning_mayaroom_0d36d4ee:

    # gg "Хорошо, не собирался"
    gg "Vale, no era mi intención"

# game/characters_events_idles/maya_events.rpy:402
translate spanish maya_scene5_night_mayaroom_979f77d5:

    # Maya "{size=*1.3}Не надо"
    Maya "{size=*1.3}No hace falta"

# game/characters_events_idles/maya_events.rpy:410
translate spanish maya_scene5_night_mayaroom_8fb3b4e0:

    # Maya "{size=*1.3}Ты всегда «просто»"
    Maya "{size=*1.3}Siempre eres 'solo'"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/maya_events.rpy:42
translate spanish maya_scene1_evening_myroom_82e75b03:

    # Maya "Где они, блин"
    Maya "¿Dónde están, joder?"

# game/characters_events_idles/maya_events.rpy:182
translate spanish maya_scene2_day_mayaroom_64552e65:

    # Maya "В мои дела"
    Maya "En mis asuntos"

# game/characters_events_idles/maya_events.rpy:293
translate spanish maya_scene4_morning_mayaroom_aea30766:

    # gg "Погоди, у меня была похожая проблема"
    gg "Espera, tuve un problema similar"

# game/characters_events_idles/maya_events.rpy:304
translate spanish maya_scene4_morning_mayaroom_c677d050:

    # Maya "Ладно, поскольку ты уже встал тут в позу спасителя"
    Maya "Vale, ya que te has puesto en plan salvador"

# game/characters_events_idles/maya_events.rpy:308
translate spanish maya_scene4_morning_mayaroom_c7e3f4c3:

    # Maya "Но если сломаешь, новый купишь"
    Maya "Pero si lo rompes, compras uno nuevo"

# game/characters_events_idles/maya_events.rpy:398
translate spanish maya_scene5_night_mayaroom_24e10eb1:

    # Maya "Хочешь границы"
    Maya "¿Quieres límites?"

# game/characters_events_idles/maya_events.rpy:521
translate spanish maya_scene6_evening_myroom_8447de22:

    # Maya "Увидишь"
    Maya "Ya verás"

# game/characters_events_idles/maya_events.rpy:580
translate spanish maya_scene6_evening_myroom_8974d68b:

    # Maya "В общем, нужно нанести крем и забинтовать"
    Maya "En fin, hay que aplicar crema y vendar"

# game/characters_events_idles/maya_events.rpy:594
translate spanish maya_scene6_evening_myroom_94783c90:

    # gg "Кажется, это называется забота"
    gg "Creo que a eso se le llama cuidado"

# game/characters_events_idles/maya_events.rpy:620
translate spanish maya_scene6_evening_myroom_b0f0812d:

    # gg "Просто сейчас . . .{w} нет смысла психовать"
    gg "Es que ahora mismo...{w} no tiene sentido volverse loco"

# game/characters_events_idles/maya_events.rpy:662
translate spanish maya_scene6_evening_myroom_98eb68ec:

    # gg "Если тебе так проще — я выйду"
    gg "Si te es más fácil, me iré"

# game/characters_events_idles/maya_events.rpy:957
translate spanish maya_scene10_evening_myroom_e458abf1:

    # Maya "Словно вечность. Эти долбаные люди"
    Maya "Como una eternidad. Esas malditas personas"

# game/characters_events_idles/maya_events.rpy:967
translate spanish maya_scene10_evening_myroom_39f98df4:

    # Maya "Уфф, устала"
    Maya "Uf, estoy cansada"

# game/characters_events_idles/maya_events.rpy:973
translate spanish maya_scene10_evening_myroom_b1651980:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Отстань"
    Maya "¿Sobre cómo volví a dejar la limpieza?{w} {bt=a3-p2.0-s3.0}Déjame en paz"

# game/characters_events_idles/maya_events.rpy:975
translate spanish maya_scene10_evening_myroom_cd61d42f:

    # gg "Да ладно тебе, можно просто помолчать"
    gg "Vamos, podemos simplemente callarnos"

# game/characters_events_idles/maya_events.rpy:1300
translate spanish maya_scene13_morning_girlroom_4a56a987:

    # gg_chat "Так, Cоня просила заказать новый шнур и заодно батарейки"
    gg_chat "Entonces, Sonya me pidió que pidiera un nuevo cable y algunas pilas"

# game/characters_events_idles/maya_events.rpy:1312
translate spanish maya_scene13_morning_girlroom_f5a72472:

    # gg "Ты чего?"
    gg "¿Qué pasa?"

# game/characters_events_idles/maya_events.rpy:1314
translate spanish maya_scene13_morning_girlroom_d958422f:

    # Maya "Ничего. Делай своё дело"
    Maya "Nada. Haz lo tuyo"

# game/characters_events_idles/maya_events.rpy:1318
translate spanish maya_scene13_morning_girlroom_6b37e39c:

    # Maya "Не отвлекайся"
    Maya "No te distraigas"

# game/characters_events_idles/maya_events.rpy:1324
translate spanish maya_scene13_morning_girlroom_36d1af18:

    # gg "Мая одну секунду . . ."
    gg "Un segundo, Maya . . ."

# game/characters_events_idles/maya_events.rpy:1325
translate spanish maya_scene13_morning_girlroom_df56cad2:

    # Maya "Я же сказала, делай свое дело"
    Maya "Te dije que hagas lo tuyo"

# game/characters_events_idles/maya_events.rpy:1328
translate spanish maya_scene13_morning_girlroom_3fa97e8a:

    # gg "Готово"
    gg "Listo"

# game/characters_events_idles/maya_events.rpy:1351
translate spanish maya_scene13_morning_girlroom_d5360aaa:

    # Maya "Ну как тебе такое спокойное утро?"
    Maya "¿Qué te parece esta tranquila mañana?"

# game/characters_events_idles/maya_events.rpy:1353
translate spanish maya_scene13_morning_girlroom_337e1de0:

    # gg "Замечательно"
    gg "Maravilloso"

# game/characters_events_idles/maya_events.rpy:1382
translate spanish maya_scene14_afternoon_myroom_72791318:

    # Sonya "Эй . . . [povname] можешь помочь с коробками?"
    Sonya "Oye . . . [povname], ¿puedes ayudarme con las cajas?"

# game/characters_events_idles/maya_events.rpy:1384
translate spanish maya_scene14_afternoon_myroom_dce97add:

    # Maya "Ой. Тебя зовут"
    Maya "Oh, te están llamando"

# game/characters_events_idles/maya_events.rpy:1386
translate spanish maya_scene14_afternoon_myroom_650d8ae1:

    # Maya "Беги. Не заставляй даму ждать"
    Maya "Corre. No hagas esperar a la dama"

# game/characters_events_idles/maya_events.rpy:1397
translate spanish maya_scene14_afternoon_myroom_134f9600:

    # Maya "Слушай . . ."
    Maya "Escucha . . ."

# game/characters_events_idles/maya_events.rpy:1399
translate spanish maya_scene14_afternoon_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "No te vayas"

# game/characters_events_idles/maya_events.rpy:1401
translate spanish maya_scene14_afternoon_myroom_6e0b7c57:

    # gg "Это из-за Сони?"
    gg "¿Es por Sonya?"

# game/characters_events_idles/maya_events.rpy:1403
translate spanish maya_scene14_afternoon_myroom_b380699d:

    # Maya "Ты правда думаешь, что я буду это обсуждать?"
    Maya "¿De verdad crees que voy a discutir esto?"

# game/characters_events_idles/maya_events.rpy:1406
translate spanish maya_scene14_afternoon_myroom_0ea54924:

    # Maya "Мне не нравится, как легко ты вскакиваешь"
    Maya "No me gusta lo fácil que te levantas"

# game/characters_events_idles/maya_events.rpy:1408
translate spanish maya_scene14_afternoon_myroom_e1764fab:

    # Maya "Как будто меня тут нет"
    Maya "Como si yo no estuviera aquí"

# game/characters_events_idles/maya_events.rpy:1410
translate spanish maya_scene14_afternoon_myroom_1d844383:

    # Maya "Пять минут"
    Maya "Cinco minutos"

# game/characters_events_idles/maya_events.rpy:1415
translate spanish maya_scene14_afternoon_myroom_cab2c2bb:

    # Maya "Пять"
    Maya "Cinco"

# game/characters_events_idles/maya_events.rpy:1417
translate spanish maya_scene14_afternoon_myroom_b4e47535:

    # Maya "И потом делай что хочешь"
    Maya "Y luego haz lo que quieras"

# game/characters_events_idles/maya_events.rpy:1419
translate spanish maya_scene14_afternoon_myroom_9b6c39fb:

    # Maya "Только не думай, что это признание"
    Maya "Solo no pienses que esto es una declaración"

# game/characters_events_idles/maya_events.rpy:1426
translate spanish maya_scene14_afternoon_myroom_93de4523:

    # Maya "Чeрт . . . каждый раз будто в первый"
    Maya "Maldita sea . . . cada vez es como la primera"

# game/characters_events_idles/maya_events.rpy:1433
translate spanish maya_scene14_afternoon_myroom_3179047f:

    # Maya "Неужели всё это . . . мне?"
    Maya "¿Todo esto . . . es para mí?"

# game/characters_events_idles/maya_events.rpy:1439
translate spanish maya_scene14_afternoon_myroom_8135a08f:

    # Maya "Такой . . . наглый"
    Maya "Tan . . . atrevido"

# game/characters_events_idles/maya_events.rpy:1441
translate spanish maya_scene14_afternoon_myroom_b3c83659:

    # Maya "И такой тeплый . . ."
    Maya "Y tan cálido . . ."

# game/characters_events_idles/maya_events.rpy:1449
translate spanish maya_scene14_afternoon_myroom_6a11d281:

    # Maya "Держись . . ."
    Maya "Aguanta . . ."

# game/characters_events_idles/maya_events.rpy:1455
translate spanish maya_scene14_afternoon_myroom_53e2be3e:

    # Maya ". . . Всe"
    Maya ". . . Todo"

# game/characters_events_idles/maya_events.rpy:1459
translate spanish maya_scene14_afternoon_myroom_1f177920:

    # Maya "Моe"
    Maya "Mío"

# game/characters_events_idles/maya_events.rpy:1463
translate spanish maya_scene14_afternoon_myroom_9f7300e6:

    # Maya "Все"
    Maya "Todo"

# game/characters_events_idles/maya_events.rpy:1465
translate spanish maya_scene14_afternoon_myroom_00c0f420:

    # Maya "Иди"
    Maya "Ve"

# game/characters_events_idles/maya_events.rpy:1467
translate spanish maya_scene14_afternoon_myroom_0efb861b:

    # gg "Ты уверена?"
    gg "¿Estás segura?"

# game/characters_events_idles/maya_events.rpy:1469
translate spanish maya_scene14_afternoon_myroom_362d3834:

    # Maya "Ага"
    Maya "Ajá"

# game/characters_events_idles/maya_events.rpy:1471
translate spanish maya_scene14_afternoon_myroom_31d3f8e7:

    # Maya "Только не пропадай"
    Maya "Solo no desaparezcas"

# game/characters_events_idles/maya_events.rpy:1473
translate spanish maya_scene14_afternoon_myroom_baa7f0c3:

    # Maya "Ты всё равно вернешься"
    Maya "De todas formas, volverás"

