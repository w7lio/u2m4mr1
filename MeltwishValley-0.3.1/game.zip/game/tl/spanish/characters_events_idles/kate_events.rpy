﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/kate_events.rpy:8
translate spanish kate_day_myroom_66ca7b58:

    # Kate "О, живой человек"
    Kate "Oh, un ser humano vivo"

# game/characters_events_idles/kate_events.rpy:9
translate spanish kate_day_myroom_b8813bdd:

    # Kate "Я уже начала думать, что вы тут все в спячке"
    Kate "Ya estoy empezando a pensar que todos están hibernando aquí."

# game/characters_events_idles/kate_events.rpy:10
translate spanish kate_day_myroom_930c1443:

    # gg "Просто тихий день"
    gg "Sólo un día tranquilo"

# game/characters_events_idles/kate_events.rpy:11
translate spanish kate_day_myroom_53322b78:

    # gg "Мая опять заставила ждать?"
    gg "¿Hizo esperar a Maya otra vez?"

# game/characters_events_idles/kate_events.rpy:13
translate spanish kate_day_myroom_995097d0:

    # Kate "Конечно. Я даже не удивляюсь"
    Kate "Por supuesto. Ni siquiera me sorprende."

# game/aracters_events_idles/kate_events.rpy:15
translate spanish kate_day_myroom_10cad415:

    # Kate "Знаешь"
    Kate "Sabes"

# game/characters_events_idles/kate_events.rpy:17
translate spanish kate_day_myroom_c22e07fd:

    # Kate "Я тут недавно проезжала мимо старого бассейна, который возле рощи"
    Kate "Hace poco pasé por delante de la antigua piscina, que está cerca del bosque."

# game/characters_events_idles/kate_events.rpy:19
translate spanish kate_day_myroom_6a0c7cc1:

    # gg "Того, что сейчас с облупленной плиткой и заросшей дорожкой?"
    gg "¿El que ahora tiene las baldosas desconchadas y el camino cubierto de maleza?"

# game/characters_events_idles/kate_events.rpy:20
translate spanish kate_day_myroom_28bfe61b:

    # Kate "Ага. Ты его знаешь?"
    Kate "Sí. ¿Lo conoces?"

# game/characters_events_idles/kate_events.rpy:21
translate spanish kate_day_myroom_70967ed9:

    # gg "Осталось воспоминание"
    gg "Queda un recuerdo"

# game/characters_events_idles/kate_events.rpy:22
translate spanish kate_day_myroom_f3840668:

    # gg "В детстве бабушка туда водила меня, интересно что же с ним случилось"
    gg "Mi abuela me llevó allí cuando era niña, me pregunto qué pasó."

# game/characters_events_idles/kate_events.rpy:24
translate spanish kate_day_myroom_7d5745ab:

    # Kate "Я случилась"
    Kate "Yo fui lo que sucedió."

# game/characters_events_idles/kate_events.rpy:26
translate spanish kate_day_myroom_1c84b7f9:

    # Kate "Это был бассейн моего деда"
    Kate "Esta era la piscina de mi abuelo."

# game/characters_events_idles/kate_events.rpy:27
translate spanish kate_day_myroom_d7e25aaf:

    # Kate "Когда он умер, всё просто оставили. Я была маленькой"
    Kate "Cuando murió, todo se abandonó. Yo era pequeña."

# game/characters_events_idles/kate_events.rpy:29
translate spanish kate_day_myroom_f2aff5b8:

    # Kate "Тогда я часто туда ходила"
    Kate "Entonces iba allí a menudo"

# game/characters_events_idles/kate_events.rpy:30
translate spanish kate_day_myroom_678d9c75:

    # Kate "Не знаю почему . . . {w}просто сидела, слушала, как эхо по плитке гуляет"
    Kate "No sé por qué. . . {w}simplemente me sentaba y escuchaba el eco que recorría las baldosas"

# game/characters_events_idles/kate_events.rpy:32
translate spanish kate_day_myroom_a3778e4f:

    # gg "Я помню, там вода была — чистая, голубая"
    gg "Recuerdo que el agua allí era clara y azul."

# game/characters_events_idles/kate_events.rpy:34
translate spanish kate_day_myroom_43319b98:

    # Kate "Да. А сейчас трещины пошли"
    Kate "Sí. Y ahora hay grietas."

# game/characters_events_idles/kate_events.rpy:36
translate spanish kate_day_myroom_1917ed73:

    # Kate "И трава пробилась через бетон"
    Kate "Y la hierba atravesó el cemento"

# game/characters_events_idles/kate_events.rpy:37
translate spanish kate_day_myroom_3128d351:

    # Kate "Но место до сих пор . . . родное, понимаешь?"
    Kate "Pero el lugar sigue ahí. . . querido, ¿entiendes?"

# game/characters_events_idles/kate_events.rpy:39
translate spanish kate_day_myroom_fe5606ef:

    # gg "Можно было бы восстановить"
    gg "Se podría restaurar."

# game/characters_events_idles/kate_events.rpy:41
translate spanish kate_day_myroom_cd6d5961:

    # Kate "Ха, говоришь, как будто это просто"
    Kate "Ja, lo dices como si fuera fácil."

# game/characters_events_idles/kate_events.rpy:42
translate spanish kate_day_myroom_5397ef5f:

    # gg "Ну . . . {w}если там не обрушено дно — это реально"
    gg "Bueno . . . {w}si el fondo no se ha derrumbado, es posible."

# game/characters_events_idles/kate_events.rpy:43
translate spanish kate_day_myroom_4ad2a7d6:

    # gg " Я могу помочь, если хочешь"
    gg "Puedo ayudarte si quieres"

# game/characters_events_idles/kate_events.rpy:45
translate spanish kate_day_myroom_2d06e21d:

    # Kate "Ты это серьёзно?"
    Kate "¿Hablas en serio?"

# game/characters_events_idles/kate_events.rpy:46
translate spanish kate_day_myroom_9b243b4f:

    # gg "Почему нет. Место стоящее"
    gg "Por qué no. Es un lugar que vale la pena."

# game/characters_events_idles/kate_events.rpy:47
translate spanish kate_day_myroom_7abebe15:

    # gg "И . . . {w} как будто жалко, что всё так осталось"
    gg "Y . . . {w}es una pena que todo siga así."

# game/characters_events_idles/kate_events.rpy:49
translate spanish kate_day_myroom_ba8f7539:

    # Kate "Подожди, подожди!"
    Kate "¡Espera, espera!"

# game/characters_events_idles/kate_events.rpy:50
translate spanish kate_day_myroom_1b5ecaea:

    # Kate "То есть, если я найду цемент, кисти, старый насос — ты реально поможешь это оживить?"
    Kate "Es decir, si encuentro cemento, pinceles, una bomba vieja, ¿realmente puedes ayudar a revivirla?"

# game/characters_events_idles/kate_events.rpy:52
translate spanish kate_day_myroom_29e07d4d:

    # gg "Похоже, я только что подписался на летний ремонт"
    gg "Parece que acabo de comprometerme con una renovación de verano."

# game/characters_events_idles/kate_events.rpy:54
translate spanish kate_day_myroom_23062701:

    # Kate "Господи, ты не понимаешь!"
    Kate "¡Señor, no lo entiendes!"

# game/characters_events_idles/kate_events.rpy:55
translate spanish kate_day_myroom_0f27478e:

    # Kate "Там же можно сделать всё заново!"
    Kate "¡Se puede rehacer todo allí!"

# game/characters_events_idles/kate_events.rpy:58
translate spanish kate_day_myroom_f8a1991c:

    # Kate "Подсветку включить, бортики покрасить . . ."
    Kate "Poner luces, pintar los bordes. . ."

# game/characters_events_idles/kate_events.rpy:59
translate spanish kate_day_myroom_9fa28628:

    # Kate "Я даже помню, где лежала старая лестница!"
    Kate "¡Incluso recuerdo dónde estaba la vieja escalera!"

# game/characters_events_idles/kate_events.rpy:61
translate spanish kate_day_myroom_01599462:

    # Kate "Можем даже вывеску повесить — “Бассейн №1 Возрождён при участии безумцев”!"
    Kate "¡Incluso podemos colgar un cartel: 'Piscina número 1: ¡Revivida con la participación de locos!'"

# game/characters_events_idles/kate_events.rpy:63
translate spanish kate_day_myroom_65417f70:

    # gg "Безумцев?"
    gg "¿Locos?"

# game/characters_events_idles/kate_events.rpy:65
translate spanish kate_day_myroom_37a114e4:

    # Kate "Ну, а кто ещё решит копаться в полузаброшенном дворе ради детской мечты?"
    Kate "Bueno, ¿quién más decidirá cavar en un jardín medio abandonado por el bien de un sueño de infancia?"

# game/characters_events_idles/kate_events.rpy:68
translate spanish kate_day_myroom_fb47222b:

    # Kate "Если получится . . . я, наверное, наконец перестану чувствовать, что всё хорошее осталось “там”, в прошлом"
    Kate "Si lo logramos. . . probablemente finalmente dejaré de sentir que todo lo bueno se quedó 'allí', en el pasado."

# game/characters_events_idles/kate_events.rpy:69
translate spanish kate_day_myroom_9e4c9fbd:

    # gg "Значит, начнём с настоящего"
    gg "Entonces comencemos con el presente."

# game/characters_events_idles/kate_events.rpy:71
translate spanish kate_day_myroom_2d334a18:

    # Kate "Серьёзно!?"
    Kate "¿¡En serio!?"

# game/characters_events_idles/kate_events.rpy:72
translate spanish kate_day_myroom_756e6836:

    # Kate "Спасибо. Ты первый, кто не сказал “забей”"
    Kate "Gracias. Eres el primero que no dijo 'olvídalo'."

# game/characters_events_idles/kate_events.rpy:73
translate spanish kate_day_myroom_651bc331:

    # gg "Я не умею “забивать”"
    gg "No sé 'olvidar'."

# game/characters_events_idles/kate_events.rpy:79
translate spanish kate_day_myroom_7ace6d42:

    # Maya "Кейт! Я готова!"
    Maya "¡Kate! ¡Estoy lista!"

# game/characters_events_idles/kate_events.rpy:81
translate spanish kate_day_myroom_d05a36ed:

    # Kate "Опять вовремя"
    Kate "A tiempo otra vez"

# game/characters_events_idles/kate_events.rpy:83
translate spanish kate_day_myroom_be210218:

    # Kate "Тогда Увидимся у бассейна [povname], строитель мечтаний"
    Kate "Luego nos vemos en la piscina [povname], constructor de sueños"

