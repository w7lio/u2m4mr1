﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/sonya_idles.rpy:7
translate spanish sonya_Idle_morning_bathroom_scene_26477ebd:

    # Sonya "О, кто-то перестал стучаться?"
    Sonya "Oh, ¿alguien dejó de llamar?"

# game/characters_events_idles/sonya_idles.rpy:8
translate spanish sonya_Idle_morning_bathroom_scene_e490c24b:

    # gg "А смысл, если дверь открыта . . ."
    gg "¿Qué sentido tiene si la puerta está abierta...?"

# game/characters_events_idles/sonya_idles.rpy:10
translate spanish sonya_Idle_morning_bathroom_scene_2e0a6a8c:

    # Sonya "Смелый стал с утра . . ."
    Sonya "Valiente desde por la mañana..."

# game/characters_events_idles/sonya_idles.rpy:12
translate spanish sonya_Idle_morning_bathroom_scene_f7e61e71:

    # gg "Просто решил не терять привычку к риску"
    gg "Simplemente decidí no perder la costumbre de arriesgarme"

# game/characters_events_idles/sonya_idles.rpy:13
translate spanish sonya_Idle_morning_bathroom_scene_31735247:

    # gg_chat "Она даже в такие моменты выглядит так, будто специально проверяет, насколько далеко можно зайти"
    gg_chat "Incluso en momentos así parece que está probando deliberadamente hasta dónde puede llegar"

# game/characters_events_idles/sonya_idles.rpy:15
translate spanish sonya_Idle_morning_bathroom_scene_43fc63bc:

    # Sonya "Хочешь полюбоваться видом?"
    Sonya "¿Quieres disfrutar de la vista?"

# game/characters_events_idles/sonya_idles.rpy:17
translate spanish sonya_Idle_morning_bathroom_scene_274bd888:

    # Sonya "Я не против"
    Sonya "No me importa"

# game/characters_events_idles/sonya_idles.rpy:18
translate spanish sonya_Idle_morning_bathroom_scene_e8a5a241:

    # gg "С таким предложением даже утренний кофе станет лишним"
    gg "Con una propuesta así, hasta el café matutino sobra"

# game/characters_events_idles/sonya_idles.rpy:20
translate spanish sonya_Idle_morning_bathroom_scene_14ae5b75:

    # Sonya "Ну хоть кто-то ценит мой вклад в твое утро"
    Sonya "Bueno, al menos alguien valora mi contribución a tu mañana"

# game/characters_events_idles/sonya_idles.rpy:22
translate spanish sonya_Idle_morning_bathroom_scene_daf8e8db:

    # gg "Смотря, что ты предложишь взамен"
    gg "Depende de lo que ofrezcas a cambio"

# game/characters_events_idles/sonya_idles.rpy:24
translate spanish sonya_Idle_morning_bathroom_scene_2ff9a6da:

    # Sonya "Знаешь, я бы тоже не отказалась провести утро поинтереснее"
    Sonya "Sabes, a mí tampoco me importaría pasar una mañana más interesante"

# game/characters_events_idles/sonya_idles.rpy:26
translate spanish sonya_Idle_morning_bathroom_scene_e6700bf3:

    # Sonya "Особенно с тобой"
    Sonya "Especialmente contigo"

# game/characters_events_idles/sonya_idles.rpy:27
translate spanish sonya_Idle_morning_bathroom_scene_9a24ffbd:

    # gg "Звучит как приглашение"
    gg "Suena a invitación"

# game/characters_events_idles/sonya_idles.rpy:29
translate spanish sonya_Idle_morning_bathroom_scene_818d5283:

    # Sonya "Да это оно. Но, увы, у меня дела"
    Sonya "Sí, lo es. Pero ay, tengo cosas que hacer"

# game/characters_events_idles/sonya_idles.rpy:30
translate spanish sonya_Idle_morning_bathroom_scene_82d60fb2:

    # gg "Ты знаешь это нечестно"
    gg "Sabes que no es justo"

# game/characters_events_idles/sonya_idles.rpy:32
translate spanish sonya_Idle_morning_bathroom_scene_0d7eca0c:

    # Sonya "Я просто оставляю десерт на потом"
    Sonya "Solo estoy guardando el postre para después"

# game/characters_events_idles/sonya_idles.rpy:34
translate spanish sonya_Idle_morning_bathroom_scene_0d86f13a:

    # Sonya "Ну что ж, герой, ванная вся твоя"
    Sonya "Bueno, héroe, el baño es todo tuyo"

# game/characters_events_idles/sonya_idles.rpy:35
translate spanish sonya_Idle_morning_bathroom_scene_3e148853:

    # Sonya "Главное, когда будешь мыться не забудь, кто тебя вдохновил"
    Sonya "Lo principal, cuando te duches no olvides quién te inspiró"

# game/characters_events_idles/sonya_idles.rpy:50
translate spanish sonya_Idle_evening_bathroom_scene_247f83e8:

    # gg "Не думал, что можно так красиво мыться под душем"
    gg "No pensé que fuera posible ducharse tan bellamente"

# game/characters_events_idles/sonya_idles.rpy:51
translate spanish sonya_Idle_evening_bathroom_scene_361d1da4:

    # Sonya "Я знала, что ты заглянешь"
    Sonya "Sabía que te asomarías"

# game/characters_events_idles/sonya_idles.rpy:52
translate spanish sonya_Idle_evening_bathroom_scene_dd689906:

    # Sonya "У тебя шаги узнаются ещё до двери"
    Sonya "Tus pasos se reconocen incluso antes de la puerta"

# game/characters_events_idles/sonya_idles.rpy:54
translate spanish sonya_Idle_evening_bathroom_scene_69f260a8:

    # gg "Хотел убедиться, что ты не уплыла в параллельную реальность"
    gg "Quería asegurarme de que no te hayas ido flotando a una realidad paralela"

# game/characters_events_idles/sonya_idles.rpy:55
translate spanish sonya_Idle_evening_bathroom_scene_81769a4a:

    # Sonya "Ещё нет. Хотя, если бы там было потеплее — можно было бы и остаться"
    Sonya "Aún no. Aunque si hiciera más calor allí, me podría quedar"

# game/characters_events_idles/sonya_idles.rpy:57
translate spanish sonya_Idle_evening_bathroom_scene_1517ae3e:

    # Sonya "Знаешь, если бы я захотела — могла бы тебя соблазнить прямо сейчас"
    Sonya "Sabes, si quisiera, podría seducirte ahora mismo"

# game/characters_events_idles/sonya_idles.rpy:58
translate spanish sonya_Idle_evening_bathroom_scene_1371ca10:

    # Sonya "Только чтобы забрать себе"
    Sonya "Solo para quedarme contigo"

# game/characters_events_idles/sonya_idles.rpy:60
translate spanish sonya_Idle_evening_bathroom_scene_21c8c83c:

    # Sonya "Но ты ведь тогда точно не ушёл бы, да?"
    Sonya "Pero entonces definitivamente no te irías, ¿verdad?"

# game/characters_events_idles/sonya_idles.rpy:61
translate spanish sonya_Idle_evening_bathroom_scene_e75862b1:

    # gg "Вряд ли бы смог"
    gg "Difícilmente podría"

# game/characters_events_idles/sonya_idles.rpy:64
translate spanish sonya_Idle_evening_bathroom_scene_6b3e3f56:

    # Sonya "Вот именно, поэтому уходи"
    Sonya "Exactamente, por eso vete"

# game/characters_events_idles/sonya_idles.rpy:65
translate spanish sonya_Idle_evening_bathroom_scene_0c771583:

    # Sonya "Пока Мая не заглянула и не устроила мне лекцию на тему “личных границ”"
    Sonya "Antes de que Maya aparezca y me dé una conferencia sobre \"límites personales\""

# game/characters_events_idles/sonya_idles.rpy:67
translate spanish sonya_Idle_evening_bathroom_scene_7782c9fd:

    # gg "Значит, спасаю нас обоих"
    gg "Así que salvo a los dos"

# game/characters_events_idles/sonya_idles.rpy:68
translate spanish sonya_Idle_evening_bathroom_scene_61bc67e7:

    # Sonya "Спасай. Но не надолго"
    Sonya "Sálvanos. Pero no por mucho tiempo"

# game/characters_events_idles/sonya_idles.rpy:69
translate spanish sonya_Idle_evening_bathroom_scene_b8d4595f:

    # gg_chat "Её слова звучали полушуткой, но от этого не становилось легче"
    gg_chat "Sus palabras sonaban a media broma, pero no por eso era más fácil"

# game/characters_events_idles/sonya_idles.rpy:70
translate spanish sonya_Idle_evening_bathroom_scene_0892a9fc:

    # gg_chat "В каждой улыбке Сони теперь пряталось что-то большее, чем просто игра"
    gg_chat "En cada sonrisa de Sonia ahora se escondía algo más que un simple juego"

# game/characters_events_idles/sonya_idles.rpy:85
translate spanish sonya_Idle_morning_girlroom_scene_5a6cf65f:

    # gg "Доброе утро. Ты уже с рассветом на работе?"
    gg "Buenos días. ¿Ya estás trabajando al amanecer?"

# game/characters_events_idles/sonya_idles.rpy:87
translate spanish sonya_Idle_morning_girlroom_scene_782b60a4:

    # Sonya "Почти. У меня тут урожай созрел, не могу бросить"
    Sonya "Casi. Tengo una cosecha aquí, no puedo dejarla"

# game/characters_events_idles/sonya_idles.rpy:88
translate spanish sonya_Idle_morning_girlroom_scene_a3c52931:

    # gg "А я думал, ты в такие игры не играешь"
    gg "Y yo que pensaba que no jugabas a esos juegos"

# game/characters_events_idles/sonya_idles.rpy:90
translate spanish sonya_Idle_morning_girlroom_scene_bbda1d39:

    # Sonya "А зря, это лучшая медитация"
    Sonya "Y en vano, es la mejor meditación"

# game/characters_events_idles/sonya_idles.rpy:91
translate spanish sonya_Idle_morning_girlroom_scene_afc574c1:

    # Sonya "Никакой спешки, просто строишь, выращиваешь, приручаешь кошек"
    Sonya "Sin prisa, solo construyes, cultivas, domesticas gatos"

# game/characters_events_idles/sonya_idles.rpy:93
translate spanish sonya_Idle_morning_girlroom_scene_2c50640e:

    # Sonya "Вот, видишь? Мой котик"
    Sonya "¿Ves? Mi gatito"

# game/characters_events_idles/sonya_idles.rpy:94
translate spanish sonya_Idle_morning_girlroom_scene_4c464678:

    # Sonya "Зовут Барсик"
    Sonya "Se llama Barsik"

# game/characters_events_idles/sonya_idles.rpy:95
translate spanish sonya_Idle_morning_girlroom_scene_cabe3537:

    # gg "Конечно. Даже тут он с тобой"
    gg "Claro. Incluso aquí está contigo"

# game/characters_events_idles/sonya_idles.rpy:96
translate spanish sonya_Idle_morning_girlroom_scene_d4be7bb4:

    # Sonya "Да не совсем того цвета, хотя бы не ворует еду"
    Sonya "Sí, no es exactamente del mismo color, al menos no roba comida"

# game/characters_events_idles/sonya_idles.rpy:97
translate spanish sonya_Idle_morning_girlroom_scene_725c6cbd:

    # Sonya "И на клавиатуру не ложится"
    Sonya "Y no se sienta en el teclado"

# game/characters_events_idles/sonya_idles.rpy:98
translate spanish sonya_Idle_morning_girlroom_scene_fbf5b42b:

    # Sonya "Я построила ему дом. Маленький, но уютный"
    Sonya "Le construí una casa. Pequeña pero acogedora"

# game/characters_events_idles/sonya_idles.rpy:100
translate spanish sonya_Idle_morning_girlroom_scene_cfe34a6f:

    # gg "Как и в жизни"
    gg "Como en la vida"

# game/characters_events_idles/sonya_idles.rpy:101
translate spanish sonya_Idle_morning_girlroom_scene_de0ba10f:

    # Sonya "Возможно. Я люблю, когда всё на своих местах. Даже в пикселях"
    Sonya "Quizás. Me gusta cuando todo está en su sitio. Incluso en píxeles"

# game/characters_events_idles/sonya_idles.rpy:102
translate spanish sonya_Idle_morning_girlroom_scene_c16cc569:

    # gg "А с монстрами что делаешь?"
    gg "¿Y qué haces con los monstruos?"

# game/characters_events_idles/sonya_idles.rpy:104
translate spanish sonya_Idle_morning_girlroom_scene_c08d01fe:

    # Sonya "Ну избегаю. Я не про битвы, я про порядок"
    Sonya "Bueno, los evito. No hablo de batallas, hablo de orden"

# game/characters_events_idles/sonya_idles.rpy:105
translate spanish sonya_Idle_morning_girlroom_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "Me gusta cuando todo está bajo control"

# game/characters_events_idles/sonya_idles.rpy:107
translate spanish sonya_Idle_morning_girlroom_scene_740206dd:

    # gg "Даже кот в игре слушается. Везёт тебе"
    gg "Incluso el gato en el juego obedece. Tienes suerte"

# game/characters_events_idles/sonya_idles.rpy:108
translate spanish sonya_Idle_morning_girlroom_scene_fb402d59:

    # Sonya "А ты попробуй приручи кого-нибудь - узнаешь, что это целая наука"
    Sonya "Y tú intenta domesticar a alguien, verás que es toda una ciencia"

# game/characters_events_idles/sonya_idles.rpy:109
translate spanish sonya_Idle_morning_girlroom_scene_1b49be1f:

    # gg "Думаешь, справлюсь?"
    gg "¿Crees que puedo?"

# game/characters_events_idles/sonya_idles.rpy:111
translate spanish sonya_Idle_morning_girlroom_scene_228ee7fd:

    # Sonya "Сомневаюсь"
    Sonya "Lo dudo"

# game/characters_events_idles/sonya_idles.rpy:112
translate spanish sonya_Idle_morning_girlroom_scene_e99c47d3:

    # Sonya "Ты не тот тип, кто строит. Скорее тот, кто случайно всё ломает"
    Sonya "No eres del tipo que construye. Más bien del que lo rompe todo por accidente"

# game/characters_events_idles/sonya_idles.rpy:113
translate spanish sonya_Idle_morning_girlroom_scene_382eac3e:

    # gg "Эй, я в детстве играл. Даже базу под землёй сделал"
    gg "Oye, yo jugaba de niño. Incluso hice una base subterránea"

# game/characters_events_idles/sonya_idles.rpy:115
translate spanish sonya_Idle_morning_girlroom_scene_0d62bf92:

    # Sonya "Ага, и подорвал через пять минут?"
    Sonya "Ajá, ¿y la volaste a los cinco minutos?"

# game/characters_events_idles/sonya_idles.rpy:116
translate spanish sonya_Idle_morning_girlroom_scene_81cf123c:

    # gg "Через десять. Но всё по плану"
    gg "A los diez. Pero todo según el plan"

# game/characters_events_idles/sonya_idles.rpy:118
translate spanish sonya_Idle_morning_girlroom_scene_24c0b733:

    # Sonya "Тогда аккуратнее с моим миром"
    Sonya "Entonces cuidado con mi mundo"

# game/characters_events_idles/sonya_idles.rpy:119
translate spanish sonya_Idle_morning_girlroom_scene_3938ea91:

    # Sonya "Тут всё с любовью и без взрывчатки"
    Sonya "Aquí todo está hecho con amor y sin explosivos"

# game/characters_events_idles/sonya_idles.rpy:120
translate spanish sonya_Idle_morning_girlroom_scene_5664d0ac:

    # gg "Учту. Буду только наблюдать"
    gg "Lo tendré en cuenta. Solo miraré"

# game/characters_events_idles/sonya_idles.rpy:121
translate spanish sonya_Idle_morning_girlroom_scene_af4f45a5:

    # Sonya "Если хочешь, потом покажу тебе свой сад"
    Sonya "Si quieres, luego te enseño mi jardín"

# game/characters_events_idles/sonya_idles.rpy:122
translate spanish sonya_Idle_morning_girlroom_scene_91498926:

    # Sonya "Там столько цветов и пчелок"
    Sonya "Hay tantas flores y abejitas"

# game/characters_events_idles/sonya_idles.rpy:123
translate spanish sonya_Idle_morning_girlroom_scene_89b49bad:

    # gg "Звучит как место, где тебе действительно спокойно"
    gg "Suena como un lugar donde estás realmente tranquila"

# game/characters_events_idles/sonya_idles.rpy:124
translate spanish sonya_Idle_morning_girlroom_scene_4a30e5b0:

    # Sonya "Наверное да, думаю нам стоит поиграть в будущем вместе!"
    Sonya "Probablemente sí, ¡creo que deberíamos jugar juntos en el futuro!"

# game/characters_events_idles/sonya_idles.rpy:125
translate spanish sonya_Idle_morning_girlroom_scene_c8df07f1:

    # gg "Обязательно . . ."
    gg "Sin falta..."

# game/characters_events_idles/sonya_idles.rpy:139
translate spanish sonya_Idle_day_girlroom_scene_a20a3fae:

    # gg "Привет как дела?"
    gg "¿Hola, cómo estás?"

# game/characters_events_idles/sonya_idles.rpy:141
translate spanish sonya_Idle_day_girlroom_scene_9dc60813:

    # Sonya "Эти таблицы просто издеваются надо мной . . ."
    Sonya "Estas tablas se están burlando de mí..."

# game/characters_events_idles/sonya_idles.rpy:142
translate spanish sonya_Idle_day_girlroom_scene_92df120a:

    # Sonya "Хоть бросай всё и иди пасти коров"
    Sonya "Me dan ganas de dejarlo todo e ir a pastorear vacas"

# game/characters_events_idles/sonya_idles.rpy:144
translate spanish sonya_Idle_day_girlroom_scene_e2f61865:

    # gg "Похоже, у тебя с ними война"
    gg "Parece que estás en guerra con ellas"

# game/characters_events_idles/sonya_idles.rpy:146
translate spanish sonya_Idle_day_girlroom_scene_053f0179:

    # Sonya "Война, да. И я проигрываю с первого дня"
    Sonya "Guerra, sí. Y llevo perdiendo desde el primer día"

# game/characters_events_idles/sonya_idles.rpy:147
translate spanish sonya_Idle_day_girlroom_scene_d3cbfb79:

    # Sonya "Не знаю, почему все эти цифры так упрямо меня не слушаются"
    Sonya "No sé por qué todos estos números se niegan tan tercamente a obedecerme"

# game/characters_events_idles/sonya_idles.rpy:150
translate spanish sonya_Idle_day_girlroom_scene_8d39ea32:

    # Sonya "Знаешь, я ведь здесь выросла"
    Sonya "Sabes, yo crecí aquí"

# game/characters_events_idles/sonya_idles.rpy:151
translate spanish sonya_Idle_day_girlroom_scene_65c67f0f:

    # Sonya "Ну, не прямо в этом доме, но в этом посёлке"
    Sonya "Bueno, no en esta casa exactamente, pero en este pueblo"

# game/characters_events_idles/sonya_idles.rpy:152
translate spanish sonya_Idle_day_girlroom_scene_4c34bce3:

    # gg "Правда?"
    gg "¿En serio?"

# game/characters_events_idles/sonya_idles.rpy:154
translate spanish sonya_Idle_day_girlroom_scene_70dec560:

    # Sonya "Да. Тогда всё казалось больше - и улицы, и дома, и даже небо"
    Sonya "Sí. Entonces todo parecía más grande: las calles, las casas, incluso el cielo"

# game/characters_events_idles/sonya_idles.rpy:155
translate spanish sonya_Idle_day_girlroom_scene_d0fea2c7:

    # Sonya "Потом я уехала, думала, найду место получше, что-то новое"
    Sonya "Luego me fui, pensé que encontraría un lugar mejor, algo nuevo"

# game/characters_events_idles/sonya_idles.rpy:157
translate spanish sonya_Idle_day_girlroom_scene_4acb46e4:

    # Sonya "А в итоге вернулась туда, где мне и было хорошо с самого начала"
    Sonya "Y al final volví a donde ya me sentía bien desde el principio"

# game/characters_events_idles/sonya_idles.rpy:158
translate spanish sonya_Idle_day_girlroom_scene_e5c60ec3:

    # gg "А как ты познакомилась с Линдой?"
    gg "¿Y cómo conociste a Linda?"

# game/characters_events_idles/sonya_idles.rpy:160
translate spanish sonya_Idle_day_girlroom_scene_b9747f5f:

    # Sonya "О, это было случайно"
    Sonya "Oh, fue por casualidad"

# game/characters_events_idles/sonya_idles.rpy:161
translate spanish sonya_Idle_day_girlroom_scene_4203728c:

    # Sonya "Я тогда снимала комнату в соседнем доме, а она как-то увидела, что я таскаю тяжелые коробки и просто подошла помочь"
    Sonya "Yo alquilaba una habitación en la casa de al lado entonces, y ella me vio cargando cajas pesadas y simplemente se acercó a ayudar"

# game/characters_events_idles/sonya_idles.rpy:163
translate spanish sonya_Idle_day_girlroom_scene_6c6eaa0a:

    # Sonya "С тех пор мы начали общаться"
    Sonya "Desde entonces empezamos a hablar"

# game/characters_events_idles/sonya_idles.rpy:164
translate spanish sonya_Idle_day_girlroom_scene_a7d57230:

    # Sonya "Она часто звала меня на чай, а потом сказала, что у неё всё равно пустует комната - и я переехала"
    Sonya "A menudo me invitaba a tomar té, y luego dijo que de todos modos tenía una habitación vacía, así que me mudé"

# game/characters_events_idles/sonya_idles.rpy:166
translate spanish sonya_Idle_day_girlroom_scene_d72f25aa:

    # gg "То есть Линда тебя приютила?"
    gg "¿O sea que Linda te acogió?"

# game/characters_events_idles/sonya_idles.rpy:168
translate spanish sonya_Idle_day_girlroom_scene_181e70fe:

    # Sonya "Можно и так сказать"
    Sonya "Se puede decir así"

# game/characters_events_idles/sonya_idles.rpy:169
translate spanish sonya_Idle_day_girlroom_scene_c5827422:

    # Sonya "Она никогда не делала из этого что-то большое, просто . . . {w}была рядом"
    Sonya "Ella nunca le dio mucha importancia, simplemente... {w}estaba ahí"

# game/characters_events_idles/sonya_idles.rpy:170
translate spanish sonya_Idle_day_girlroom_scene_967e2aa8:

    # Sonya "Знаешь, таких людей немного"
    Sonya "Sabes, hay pocas personas así"

# game/characters_events_idles/sonya_idles.rpy:172
translate spanish sonya_Idle_day_girlroom_scene_6ab10a33:

    # Sonya "А теперь вот я за ее столом"
    Sonya "Y ahora aquí estoy en su mesa"

# game/characters_events_idles/sonya_idles.rpy:173
translate spanish sonya_Idle_day_girlroom_scene_75e4a1ee:

    # Sonya "Иногда кажется, что она всё ещё где-то рядом, наблюдает и тихо подсказывает, что делать"
    Sonya "A veces parece que todavía está cerca, observando y susurrándome qué hacer"

# game/characters_events_idles/sonya_idles.rpy:174
translate spanish sonya_Idle_day_girlroom_scene_842a9d6c:

    # gg "Может, поэтому тебе так важно всё довести до идеала"
    gg "Quizás por eso es tan importante para ti llevar todo a la perfección"

# game/characters_events_idles/sonya_idles.rpy:176
translate spanish sonya_Idle_day_girlroom_scene_e1ccf1c4:

    # Sonya "Возможно. Только вот с таблицами идеала точно не получится"
    Sonya "Quizás. Solo que con las tablas no saldrá nada ideal"

# game/characters_events_idles/sonya_idles.rpy:178
translate spanish sonya_Idle_day_girlroom_scene_cb6d8969:

    # Sonya "Спасибо, что подошёл"
    Sonya "Gracias por acercarte"

# game/characters_events_idles/sonya_idles.rpy:179
translate spanish sonya_Idle_day_girlroom_scene_45ba29af:

    # Sonya "Без тебя я бы и дальше злилась на эти несчастные ячейки"
    Sonya "Sin ti seguiría enfadada con estas pobres celdas"

# game/characters_events_idles/sonya_idles.rpy:180
translate spanish sonya_Idle_day_girlroom_scene_c55fced7:

    # gg "Рад помочь"
    gg "Me alegra ayudar"

# game/characters_events_idles/sonya_idles.rpy:181
translate spanish sonya_Idle_day_girlroom_scene_c59d3a8e:

    # gg "Иногда лучший способ справиться с работой - просто отвлечься"
    gg "A veces la mejor forma de lidiar con el trabajo es simplemente distraerse"

# game/characters_events_idles/sonya_idles.rpy:183
translate spanish sonya_Idle_day_girlroom_scene_dc01f949:

    # Sonya "Ты прав. А можешь мне чаек сделать пожалуйста . . ."
    Sonya "Tienes razón. ¿Puedes hacerme un té, por favor...?"

# game/characters_events_idles/sonya_idles.rpy:184
translate spanish sonya_Idle_day_girlroom_scene_307a264f:

    # gg "Да конечно"
    gg "Sí, claro"

# game/characters_events_idles/sonya_idles.rpy:186
translate spanish sonya_Idle_day_girlroom_scene_b0fc80b8:

    # Sonya "Спасибо огромное"
    Sonya "Muchísimas gracias"

# game/characters_events_idles/sonya_idles.rpy:187
translate spanish sonya_Idle_day_girlroom_scene_11813a95:

    # gg_chat "В ней было что-то от Линды - то же спокойствие и мягкость, только моложе, живее"
    gg_chat "Había algo de Linda en ella: la misma calma y suavidad, solo que más joven, más viva"

# game/characters_events_idles/sonya_idles.rpy:188
translate spanish sonya_Idle_day_girlroom_scene_660cc2e9:

    # gg_chat "И, пожалуй, даже теплее"
    gg_chat "Y quizás incluso más cálida"

# game/characters_events_idles/sonya_idles.rpy:203
translate spanish sonya_Idle_evening_girlroom_scene_42feeaf6:

    # gg "Можно присесть?"
    gg "¿Puedo sentarme?"

# game/characters_events_idles/sonya_idles.rpy:205
translate spanish sonya_Idle_evening_girlroom_scene_8460369c:

    # Sonya "Можно . . . {w}но с тебя - плата"
    Sonya "Puedes... {w}pero hay un precio"

# game/characters_events_idles/sonya_idles.rpy:206
translate spanish sonya_Idle_evening_girlroom_scene_a599bb6d:

    # gg "Какая?"
    gg "¿Cuál?"

# game/characters_events_idles/sonya_idles.rpy:208
translate spanish sonya_Idle_evening_girlroom_scene_81b816f5:

    # Sonya "Остаться до конца вечера"
    Sonya "Quedarte hasta el final de la noche"

# game/characters_events_idles/sonya_idles.rpy:209
translate spanish sonya_Idle_evening_girlroom_scene_e27a7e82:

    # Sonya "И не сбежать"
    Sonya "Y no escapar"

# game/characters_events_idles/sonya_idles.rpy:210
translate spanish sonya_Idle_evening_girlroom_scene_7f2d6628:

    # gg "Если ты обещаешь не гнать - я и до утра не уйду"
    gg "Si prometes no echarme, no me iré ni hasta la mañana"

# game/characters_events_idles/sonya_idles.rpy:212
translate spanish sonya_Idle_evening_girlroom_scene_1cdd78f4:

    # Sonya "Тогда, может, и расскажу что-нибудь . . . {w}личное"
    Sonya "Entonces quizás te cuente algo... {w}personal"

# game/characters_events_idles/sonya_idles.rpy:215
translate spanish sonya_Idle_evening_girlroom_scene_9eb3b8ed:

    # Sonya "Забавно, получилось"
    Sonya "Qué curioso, funcionó"

# game/characters_events_idles/sonya_idles.rpy:216
translate spanish sonya_Idle_evening_girlroom_scene_8bb9cddd:

    # Sonya "Мы с Маей обе любим тишину, но по-разному"
    Sonya "Maya y yo ambas amamos el silencio, pero de formas diferentes"

# game/characters_events_idles/sonya_idles.rpy:217
translate spanish sonya_Idle_evening_girlroom_scene_fb1f6848:

    # gg "В каком смысле?"
    gg "¿En qué sentido?"

# game/characters_events_idles/sonya_idles.rpy:219
translate spanish sonya_Idle_evening_girlroom_scene_a5d3ae91:

    # Sonya "Она включает музыку, чтобы заглушить всё вокруг"
    Sonya "Ella pone música para ahogar todo lo de alrededor"

# game/characters_events_idles/sonya_idles.rpy:220
translate spanish sonya_Idle_evening_girlroom_scene_b0cd0795:

    # Sonya "А я наоборот - выключаю, чтобы услышать хоть что-то своё"
    Sonya "Y yo al contrario, la apago para oír al menos algo propio"

# game/characters_events_idles/sonya_idles.rpy:221
translate spanish sonya_Idle_evening_girlroom_scene_7162f44d:

    # gg "Тогда у тебя получается лучше"
    gg "Entonces a ti te sale mejor"

# game/characters_events_idles/sonya_idles.rpy:223
translate spanish sonya_Idle_evening_girlroom_scene_b5b15ec8:

    # Sonya "Ну не знаю"
    Sonya "Bueno, no sé"

# game/characters_events_idles/sonya_idles.rpy:224
translate spanish sonya_Idle_evening_girlroom_scene_03522836:

    # Sonya "Просто по-другому"
    Sonya "Simplemente diferente"

# game/characters_events_idles/sonya_idles.rpy:238
translate spanish sonya_Idle_night_girlroom_scene_559d1944:

    # gg "Улыбается во сне . . ."
    gg "Sonríe mientras duerme..."

# game/characters_events_idles/sonya_idles.rpy:239
translate spanish sonya_Idle_night_girlroom_scene_5651af4c:

    # gg "Интересно, что ей снится, раз выглядит такой довольной"
    gg "Me pregunto qué estará soñando, pues parece tan satisfecha"

# game/characters_events_idles/sonya_idles.rpy:251
translate spanish sonya_Idle_morning_kitchen_scene_0b8a14be:

    # gg "Доброе утро, командир чистоты"
    gg "Buenos días, comandante de la limpieza"

# game/characters_events_idles/sonya_idles.rpy:252
translate spanish sonya_Idle_morning_kitchen_scene_ed136649:

    # Sonya "Кто-то же должен следить, чтобы кухня не превратилась в поле боя"
    Sonya "Alguien tiene que vigilar que la cocina no se convierta en un campo de batalla"

# game/characters_events_idles/sonya_idles.rpy:254
translate spanish sonya_Idle_morning_kitchen_scene_d094394a:

    # gg "А вдруг Мая проснётся и решит помочь?"
    gg "¿Y si Maya se despierta y decide ayudar?"

# game/characters_events_idles/sonya_idles.rpy:256
translate spanish sonya_Idle_morning_kitchen_scene_c681883f:

    # Sonya "Тогда я просто вымою всё заново"
    Sonya "Entonces simplemente lo lavaré todo otra vez"

# game/characters_events_idles/sonya_idles.rpy:258
translate spanish sonya_Idle_morning_kitchen_scene_f2c9c474:

    # gg "Значит, тебе нравится, когда всё блестит"
    gg "Así que te gusta cuando todo brilla"

# game/characters_events_idles/sonya_idles.rpy:260
translate spanish sonya_Idle_morning_kitchen_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "Me gusta cuando todo está bajo control"

# game/characters_events_idles/sonya_idles.rpy:261
translate spanish sonya_Idle_morning_kitchen_scene_86bbbfde:

    # gg "Даже люди?"
    gg "¿Incluso la gente?"

# game/characters_events_idles/sonya_idles.rpy:264
translate spanish sonya_Idle_morning_kitchen_scene_655f980e:

    # Sonya "С людьми сложнее"
    Sonya "Con la gente es más complicado"

# game/characters_events_idles/sonya_idles.rpy:265
translate spanish sonya_Idle_morning_kitchen_scene_6ae7acf8:

    # Sonya "Они, в отличие от кухни, редко слушаются"
    Sonya "Ellos, a diferencia de la cocina, rara vez obedecen"

# game/characters_events_idles/sonya_idles.rpy:266
translate spanish sonya_Idle_morning_kitchen_scene_efabb06d:

    # gg "Может, им просто не хватает твоего руководства"
    gg "Quizás simplemente les falta tu dirección"

# game/characters_events_idles/sonya_idles.rpy:268
translate spanish sonya_Idle_morning_kitchen_scene_59bb1b63:

    # Sonya "Осторожнее с комплиментами, а то решу, что ты тоже хочешь быть чистеньким"
    Sonya "Cuidado con los cumplidos, o pensaré que tú también quieres estar limpito"

# game/characters_events_idles/sonya_idles.rpy:269
translate spanish sonya_Idle_morning_kitchen_scene_19086387:

    # gg "Обещаю быть примерным"
    gg "Prometo ser ejemplar"

# game/characters_events_idles/sonya_idles.rpy:270
translate spanish sonya_Idle_morning_kitchen_scene_de5751f7:

    # gg "Хотя недолго"
    gg "Aunque no por mucho tiempo"

# game/characters_events_idles/sonya_idles.rpy:285
translate spanish sonya_Idle_evening_kitchen_scene_74d26ab6:

    # gg "Пахнет так, будто кто-то очень старается"
    gg "Huele como si alguien se estuviera esforzando mucho"

# game/characters_events_idles/sonya_idles.rpy:287
translate spanish sonya_Idle_evening_kitchen_scene_38676ac8:

    # Sonya "А я и стараюсь"
    Sonya "Y yo lo estoy intentando"

# game/characters_events_idles/sonya_idles.rpy:288
translate spanish sonya_Idle_evening_kitchen_scene_adfdb6f3:

    # Sonya "Без рецепта между прочем, просто . . . {w}хочется, чтобы получилось как дома"
    Sonya "Sin receta, por cierto, simplemente... {w}quiero que salga como en casa"

# game/characters_events_idles/sonya_idles.rpy:289
translate spanish sonya_Idle_evening_kitchen_scene_c3970015:

    # gg "Ты часто так готовишь?"
    gg "¿Sueles cocinar así?"

# game/characters_events_idles/sonya_idles.rpy:291
translate spanish sonya_Idle_evening_kitchen_scene_2d72af39:

    # Sonya "Почти каждый день. С детства так привыкла"
    Sonya "Casi cada día. Así me acostumbré desde pequeña"

# game/characters_events_idles/sonya_idles.rpy:292
translate spanish sonya_Idle_evening_kitchen_scene_1cbd5882:

    # Sonya "Мне нравилось видеть, как люди садятся за стол и вдруг становятся добрее"
    Sonya "Me gustaba ver cómo la gente se sentaba a la mesa y de repente se volvía más amable"

# game/characters_events_idles/sonya_idles.rpy:294
translate spanish sonya_Idle_evening_kitchen_scene_33b06e3d:

    # Sonya "Еда делает людей мягче"
    Sonya "La comida suaviza a la gente"

# game/characters_events_idles/sonya_idles.rpy:295
translate spanish sonya_Idle_evening_kitchen_scene_4347abfd:

    # Sonya "Даже тех, кто обычно каменные"
    Sonya "Incluso a los que suelen ser de piedra"

# game/characters_events_idles/sonya_idles.rpy:297
translate spanish sonya_Idle_evening_kitchen_scene_3116970e:

    # gg "Может, потому что через неё ты делишься теплом"
    gg "Quizás porque a través de ella compartes calor"

# game/characters_events_idles/sonya_idles.rpy:298
translate spanish sonya_Idle_evening_kitchen_scene_158f9e29:

    # Sonya "Наверное"
    Sonya "Supongo"

# game/characters_events_idles/sonya_idles.rpy:299
translate spanish sonya_Idle_evening_kitchen_scene_2af7df75:

    # Sonya "Готовить - это ведь не просто накормить"
    Sonya "Cocinar no es simplemente alimentar"

# game/characters_events_idles/sonya_idles.rpy:300
translate spanish sonya_Idle_evening_kitchen_scene_668b4e51:

    # Sonya "Это сказать: “ты можешь остаться”"
    Sonya "Es decir: \"puedes quedarte\""

# game/characters_events_idles/sonya_idles.rpy:302
translate spanish sonya_Idle_evening_kitchen_scene_8f974346:

    # Sonya "Помню, в детстве всё время помогала на кухне"
    Sonya "Recuerdo que de pequeña ayudaba siempre en la cocina"

# game/characters_events_idles/sonya_idles.rpy:303
translate spanish sonya_Idle_evening_kitchen_scene_970899ee:

    # Sonya "Мама только улыбалась - говорила, что из меня выйдет не повар, а “дом в человеческом виде”"
    Sonya "Mamá solo sonreía, decía que de mí no saldría una cocinera, sino \"una casa con forma humana\""

# game/characters_events_idles/sonya_idles.rpy:305
translate spanish sonya_Idle_evening_kitchen_scene_22f1390f:

    # gg "Звучит будто про тебя"
    gg "Suena como si fuera sobre ti"

# game/characters_events_idles/sonya_idles.rpy:307
translate spanish sonya_Idle_evening_kitchen_scene_36c5520f:

    # Sonya "Ну вот, ужин готов"
    Sonya "Bueno, ya está la cena"

# game/characters_events_idles/sonya_idles.rpy:308
translate spanish sonya_Idle_evening_kitchen_scene_03998218:

    # Sonya "Без изысков, но с душой"
    Sonya "Sin lujos, pero con alma"

# game/characters_events_idles/sonya_idles.rpy:310
translate spanish sonya_Idle_evening_kitchen_scene_44b18404:

    # gg "Это вкуснее, чем изысканно"
    gg "Eso es más sabroso que exquisito"

# game/characters_events_idles/sonya_idles.rpy:311
translate spanish sonya_Idle_evening_kitchen_scene_16a4231c:

    # Sonya "Вот и хорошо"
    Sonya "Me alegra"

# game/characters_events_idles/sonya_idles.rpy:312
translate spanish sonya_Idle_evening_kitchen_scene_2c2fc2a4:

    # Sonya "Значит, не зря старалась"
    Sonya "Así que no me esforcé en vano"

# game/characters_events_idles/sonya_idles.rpy:314
translate spanish sonya_Idle_evening_kitchen_scene_c6bde83f:

    # Sonya "Знаешь, мне нравится кормить людей"
    Sonya "Sabes, me gusta alimentar a la gente"

# game/characters_events_idles/sonya_idles.rpy:315
translate spanish sonya_Idle_evening_kitchen_scene_d763faf1:

    # Sonya "Это самое простое, но честное, что я умею делать"
    Sonya "Es lo más simple pero honesto que sé hacer"

# game/characters_events_idles/sonya_idles.rpy:317
translate spanish sonya_Idle_evening_kitchen_scene_2b0e2ee7:

    # Sonya "Когда кто - то ест то, что ты приготовил, - он словно доверяет тебе"
    Sonya "Cuando alguien come lo que has preparado, es como si confiara en ti"

# game/characters_events_idles/sonya_idles.rpy:332
translate spanish sonya_Idle_day_kitchen_scene_ad913161:

    # gg "Всё ещё ждёшь, пока чайник закипит?"
    gg "¿Sigues esperando a que hierva la tetera?"

# game/characters_events_idles/sonya_idles.rpy:334
translate spanish sonya_Idle_day_kitchen_scene_7f0755b3:

    # Sonya "Этот чайник кипит только если чувствует внимание. И настроение"
    Sonya "Esta tetera solo hierve si siente atención. Y buen humor"

# game/characters_events_idles/sonya_idles.rpy:336
translate spanish sonya_Idle_day_kitchen_scene_f15d06fa:

    # gg "У него характер как у людей здесь"
    gg "Tiene carácter, como la gente de aquí"

# game/characters_events_idles/sonya_idles.rpy:337
translate spanish sonya_Idle_day_kitchen_scene_da15dc83:

    # Sonya "Точно. Кстати чтобы узнать получше людей здесь"
    Sonya "Exacto. Por cierto, para conocer mejor a la gente de aquí"

# game/characters_events_idles/sonya_idles.rpy:340
translate spanish sonya_Idle_day_kitchen_scene_d5290e36:

    # Sonya "Тут есть пара мест для прогулок"
    Sonya "Aquí hay un par de sitios para pasear"

# game/characters_events_idles/sonya_idles.rpy:341
translate spanish sonya_Idle_day_kitchen_scene_9f4c3048:

    # Sonya "Парк — небольшой, но с лавками, где можно застрять на час"
    Sonya "El parque es pequeño, pero con bancos donde puedes quedarte una hora"

# game/characters_events_idles/sonya_idles.rpy:343
translate spanish sonya_Idle_day_kitchen_scene_5b433dab:

    # gg "И всё?"
    gg "¿Y eso es todo?"

# game/characters_events_idles/sonya_idles.rpy:345
translate spanish sonya_Idle_day_kitchen_scene_35184686:

    # Sonya "Ещё озеро. Маленькое, но красивое, особенно вечером"
    Sonya "También está el lago. Pequeño pero bonito, especialmente por la tarde"

# game/characters_events_idles/sonya_idles.rpy:346
translate spanish sonya_Idle_day_kitchen_scene_f7d54fda:

    # Sonya "Только вода бодрит так, что потом спать не хочется"
    Sonya "Solo que el agua es tan fresca que luego no dan ganas de dormir"

# game/characters_events_idles/sonya_idles.rpy:348
translate spanish sonya_Idle_day_kitchen_scene_95b73bc9:

    # Sonya "По субботам базар. Там продают всё — от мёда до слухов"
    Sonya "Los sábados hay mercado. Allí venden de todo, desde miel hasta rumores"

# game/characters_events_idles/sonya_idles.rpy:349
translate spanish sonya_Idle_day_kitchen_scene_957c11d8:

    # gg "А многоэтажка — это правда?"
    gg "¿Y lo del edificio de varias plantas es verdad?"

# game/characters_events_idles/sonya_idles.rpy:351
translate spanish sonya_Idle_day_kitchen_scene_13cd2649:

    # Sonya "Правда. Наш “город в одном доме”"
    Sonya "Verdad. Nuestro \"pueblo en una sola casa\""

# game/characters_events_idles/sonya_idles.rpy:352
translate spanish sonya_Idle_day_kitchen_scene_c3a65cd2:

    # Sonya "Там почта, офис и девушка, которая считает себя айтишником"
    Sonya "Allí están correos, la oficina y una chica que se cree informática"

# game/characters_events_idles/sonya_idles.rpy:354
translate spanish sonya_Idle_day_kitchen_scene_ed9dc13a:

    # Sonya "Вот и всё веселье. Но если смотреть внимательно — здесь больше жизни, чем кажется"
    Sonya "Esa es toda la diversión. Pero si miras con atención, aquí hay más vida de lo que parece"

# game/characters_events_idles/sonya_idles.rpy:369
translate spanish sonya_Idle_morning_myroom_scene_3520e1f4:

    # Sonya "Ой . . . не разбудила?"
    Sonya "Oh... ¿te he despertado?"

# game/characters_events_idles/sonya_idles.rpy:370
translate spanish sonya_Idle_morning_myroom_scene_672ee57f:

    # gg "Нет, просто не привык, что по утрам кто-то сражается с пылью"
    gg "No, simplemente no estoy acostumbrado a que alguien luche contra el polvo por las mañanas"

# game/characters_events_idles/sonya_idles.rpy:372
translate spanish sonya_Idle_morning_myroom_scene_7bcfcbe4:

    # Sonya "У каждого своё утро"
    Sonya "Cada cual tiene su mañana"

# game/characters_events_idles/sonya_idles.rpy:373
translate spanish sonya_Idle_morning_myroom_scene_125e44ff:

    # Sonya "Моё - с уборки"
    Sonya "La mía, con la limpieza"

# game/characters_events_idles/sonya_idles.rpy:375
translate spanish sonya_Idle_morning_myroom_scene_00768c69:

    # gg "Не думал, что ты одна из тех, кто так любит уборку"
    gg "No pensaba que fueras de las que tanto les gusta limpiar"

# game/characters_events_idles/sonya_idles.rpy:377
translate spanish sonya_Idle_morning_myroom_scene_05d695dc:

    # Sonya "Не люблю. {w}Просто, если не я, никто не сделает"
    Sonya "No me gusta. {w}Es que si no lo hago yo, nadie lo hará"

# game/characters_events_idles/sonya_idles.rpy:378
translate spanish sonya_Idle_morning_myroom_scene_8b5d8733:

    # Sonya "Когда я сюда приехала, дом был знаешь . . . {w}какой-то пустой"
    Sonya "Cuando llegué aquí, la casa estaba ya sabes... {w}como vacía"

# game/characters_events_idles/sonya_idles.rpy:379
translate spanish sonya_Idle_morning_myroom_scene_6e4588f3:

    # Sonya "Линда тогда часто уезжала, а Мая только въехала"
    Sonya "Linda entonces se iba a menudo, y Maya acababa de mudarse"

# game/characters_events_idles/sonya_idles.rpy:380
translate spanish sonya_Idle_morning_myroom_scene_b07f6cab:

    # Sonya "Всё было вверх дном"
    Sonya "Todo estaba patas arriba"

# game/characters_events_idles/sonya_idles.rpy:381
translate spanish sonya_Idle_morning_myroom_scene_c3dd8e50:

    # Sonya "Я осталась - просто чтобы стало немного тише"
    Sonya "Me quedé, simplemente para que hubiera un poco más de calma"

# game/characters_events_idles/sonya_idles.rpy:382
translate spanish sonya_Idle_morning_myroom_scene_58c3d544:

    # gg "И осталась до сих пор?"
    gg "¿Y te has quedado hasta ahora?"

# game/characters_events_idles/sonya_idles.rpy:384
translate spanish sonya_Idle_morning_myroom_scene_1e7a7a2e:

    # Sonya "Ага. Потом привыкла"
    Sonya "Ajá. Luego me acostumbré"

# game/characters_events_idles/sonya_idles.rpy:385
translate spanish sonya_Idle_morning_myroom_scene_ce824a84:

    # Sonya "Линда как-то сказала, что дом любит, когда в нём кто-то есть"
    Sonya "Linda dijo una vez que a la casa le gusta cuando hay alguien en ella"

# game/characters_events_idles/sonya_idles.rpy:387
translate spanish sonya_Idle_morning_myroom_scene_80a846d0:

    # Sonya "Может, я просто не смогла уехать"
    Sonya "Quizás simplemente no pude irme"

# game/characters_events_idles/sonya_idles.rpy:389
translate spanish sonya_Idle_morning_myroom_scene_db2e4457:

    # gg "А Мая? Вы ведь такие разные"
    gg "¿Y Maya? Es que sois tan diferentes"

# game/characters_events_idles/sonya_idles.rpy:391
translate spanish sonya_Idle_morning_myroom_scene_55479aec:

    # Sonya "Очень"
    Sonya "Mucho"

# game/characters_events_idles/sonya_idles.rpy:393
translate spanish sonya_Idle_morning_myroom_scene_e017f5bc:

    # Sonya "Я - про порядок, она - про хаос. Но в этом и суть"
    Sonya "Yo soy del orden, ella del caos. Pero en eso está la gracia"

# game/characters_events_idles/sonya_idles.rpy:396
translate spanish sonya_Idle_morning_myroom_scene_ef1d94c6:

    # Sonya "Знаешь, иногда кажется, что мы друг друга уравновешиваем"
    Sonya "Sabes, a veces parece que nos equilibramos la una a la otra"

# game/characters_events_idles/sonya_idles.rpy:397
translate spanish sonya_Idle_morning_myroom_scene_77666d07:

    # Sonya "Я заставляю её остановиться, а она - меня жить чуть громче"
    Sonya "Yo la obligo a parar, y ella a mí a vivir un poco más fuerte"

# game/characters_events_idles/sonya_idles.rpy:398
translate spanish sonya_Idle_morning_myroom_scene_686dcb6d:

    # gg "Похоже, вы нашли баланс"
    gg "Parece que habéis encontrado un equilibrio"

# game/characters_events_idles/sonya_idles.rpy:400
translate spanish sonya_Idle_morning_myroom_scene_8d1d6292:

    # Sonya "Баланс - вещь хрупкая"
    Sonya "El equilibrio es algo frágil"

# game/characters_events_idles/sonya_idles.rpy:402
translate spanish sonya_Idle_morning_myroom_scene_6e252d73:

    # Sonya "Но, кажется, с тобой он только крепче стал"
    Sonya "Pero, parece que contigo solo se ha hecho más fuerte"

# game/characters_events_idles/sonya_idles.rpy:404
translate spanish sonya_Idle_morning_myroom_scene_2e6e7590:

    # Sonya "В смысле . . . просто в доме стало уютнее"
    Sonya "Quiero decir... simplemente la casa se ha vuelto más acogedora"

# game/characters_events_idles/sonya_idles.rpy:406
translate spanish sonya_Idle_morning_myroom_scene_6bf72907:

    # Sonya "Вот и всё"
    Sonya "Y eso es todo"

# game/characters_events_idles/sonya_idles.rpy:407
translate spanish sonya_Idle_morning_myroom_scene_98ba9030:

    # gg "Конечно. Только уют"
    gg "Claro. Solo el confort"

# game/characters_events_idles/sonya_idles.rpy:408
translate spanish sonya_Idle_morning_myroom_scene_af3920fa:

    # Sonya "Вот именно. Только уют"
    Sonya "Exactamente. Solo el confort"

# game/characters_events_idles/sonya_idles.rpy:422
translate spanish sonya_Idle_day_myroom_scene_de06330f:

    # gg "Привет за цветами ухаживаешь?"
    gg "Hola, ¿cuidando las plantas?"

# game/characters_events_idles/sonya_idles.rpy:424
translate spanish sonya_Idle_day_myroom_scene_c76f7e91:

    # Sonya "Знаешь, за цветами нужно постоянно следить"
    Sonya "Sabes, a las plantas hay que vigilarlas constantemente"

# game/characters_events_idles/sonya_idles.rpy:426
translate spanish sonya_Idle_day_myroom_scene_95b1f24a:

    # Sonya "Не слишком много воды, не слишком мало. . . иначе начинают вянуть"
    Sonya "Ni demasiada agua, ni muy poca... o se empiezan a marchitar"

# game/characters_events_idles/sonya_idles.rpy:427
translate spanish sonya_Idle_day_myroom_scene_ae18780a:

    # gg "Значит, всё дело в балансе"
    gg "Así que todo es cuestión de equilibrio"

# game/characters_events_idles/sonya_idles.rpy:429
translate spanish sonya_Idle_day_myroom_scene_0e80b509:

    # Sonya "Внимание и время - вот что им действительно нужно"
    Sonya "Atención y tiempo, eso es lo que realmente necesitan"

# game/characters_events_idles/sonya_idles.rpy:430
translate spanish sonya_Idle_day_myroom_scene_37400bc6:

    # Sonya "Не полил день - и всё, сразу обижаются"
    Sonya "No riegas un día, y listo, enseguida se ofenden"

# game/characters_events_idles/sonya_idles.rpy:432
translate spanish sonya_Idle_day_myroom_scene_b6abea2a:

    # Sonya "У каждого из них свой характер"
    Sonya "Cada una tiene su propio carácter"

# game/characters_events_idles/sonya_idles.rpy:434
translate spanish sonya_Idle_day_myroom_scene_2c042e81:

    # Sonya "Один тянется к свету, другой прячется в тень"
    Sonya "Una se estira hacia la luz, otra se esconde en la sombra"

# game/characters_events_idles/sonya_idles.rpy:435
translate spanish sonya_Idle_day_myroom_scene_bffbba77:

    # Sonya "Есть те, кто растёт быстро, а есть, кому нужно просто больше терпения"
    Sonya "Hay quienes crecen rápido, y hay quienes simplemente necesitan más paciencia"

# game/characters_events_idles/sonya_idles.rpy:436
translate spanish sonya_Idle_day_myroom_scene_97f84296:

    # gg "Звучит как целая наука"
    gg "Suena a toda una ciencia"

# game/characters_events_idles/sonya_idles.rpy:438
translate spanish sonya_Idle_day_myroom_scene_bc327c51:

    # Sonya "Может, и так. Только всё приходится чувствовать"
    Sonya "Puede que sí. Solo que hay que sentirlo todo"

# game/characters_events_idles/sonya_idles.rpy:440
translate spanish sonya_Idle_day_myroom_scene_16d43fdb:

    # Sonya "Иногда они долго не цветут, и кажется, что всё зря"
    Sonya "A veces no florecen durante mucho tiempo, y parece que todo es en vano"

# game/characters_events_idles/sonya_idles.rpy:441
translate spanish sonya_Idle_day_myroom_scene_df3dcafe:

    # Sonya "А потом вдруг - один день, и раскрывается бутон"
    Sonya "Y luego de repente, un día, el capullo se abre"

# game/characters_events_idles/sonya_idles.rpy:443
translate spanish sonya_Idle_day_myroom_scene_3ee4994e:

    # Sonya "Линда всегда говорила, что цветы живут там, где им хорошо"
    Sonya "Linda siempre decía que las plantas viven donde se sienten bien"

# game/characters_events_idles/sonya_idles.rpy:444
translate spanish sonya_Idle_day_myroom_scene_bfd85b59:

    # Sonya "Не потому что солнце ярче, а потому что рядом кто-то заботится"
    Sonya "No porque el sol brille más, sino porque hay alguien cerca que las cuida"

# game/characters_events_idles/sonya_idles.rpy:445
translate spanish sonya_Idle_day_myroom_scene_d2c9efc2:

    # gg "Наверное, это правда"
    gg "Supongo que es verdad"

# game/characters_events_idles/sonya_idles.rpy:447
translate spanish sonya_Idle_day_myroom_scene_21a29e18:

    # Sonya "Думаю, да"
    Sonya "Creo que sí"

# game/characters_events_idles/sonya_idles.rpy:448
translate spanish sonya_Idle_day_myroom_scene_ea189aa5:

    # Sonya "Просто не все замечают, как это важно"
    Sonya "Es solo que no todo el mundo se da cuenta de lo importante que es"

# game/characters_events_idles/sonya_idles.rpy:449
translate spanish sonya_Idle_day_myroom_scene_98f80f6a:

    # Sonya "Иногда достаточно совсем немного - тепла, слова, присутствия"
    Sonya "A veces basta con muy poco: calor, una palabra, presencia"

# game/characters_events_idles/sonya_idles.rpy:451
translate spanish sonya_Idle_day_myroom_scene_c2d87ad5:

    # Sonya "Главное - не перекормить заботой"
    Sonya "Lo principal es no sobrealimentar con cuidados"

# game/characters_events_idles/sonya_idles.rpy:466
translate spanish sonya_Idle_evening_myroom_scene_21cb43a6:

    # Sonya "Так, у нас есть романтика, комедия, и . . . хоррор"
    Sonya "Bueno, tenemos romance, comedia, y... terror"

# game/characters_events_idles/sonya_idles.rpy:468
translate spanish sonya_Idle_evening_myroom_scene_fd380690:

    # gg "Хоррор? Ты же потом не заснёшь"
    gg "¿Terror? Luego no te dormirás"

# game/characters_events_idles/sonya_idles.rpy:470
translate spanish sonya_Idle_evening_myroom_scene_f65cd8c3:

    # Sonya "Ну тогда разбужу тебя и будем болтать до утра . . ."
    Sonya "Bueno, entonces te despertaré y charlaremos hasta la mañana..."

# game/characters_events_idles/sonya_idles.rpy:471
translate spanish sonya_Idle_evening_myroom_scene_0f687ebc:

    # Sonya "Вместе страдать от бессонницы"
    Sonya "Sufriremos juntos de insomnio"

# game/characters_events_idles/sonya_idles.rpy:472
translate spanish sonya_Idle_evening_myroom_scene_4fc2999c:

    # gg "Ну если ты вдруг случайно начнёшь засыпать - я тебе не дам"
    gg "Bueno, si de repente empiezas a dormirte por accidente, no te dejaré"

# game/characters_events_idles/sonya_idles.rpy:474
translate spanish sonya_Idle_evening_myroom_scene_d472f3eb:

    # Sonya "Просто люблю, когда немного страшно"
    Sonya "Es que me gusta cuando da un poco de miedo"

# game/characters_events_idles/sonya_idles.rpy:475
translate spanish sonya_Idle_evening_myroom_scene_53e63a45:

    # Sonya "В таких фильмах хоть что-то происходит по-настоящему"
    Sonya "En esas películas al menos algo ocurre de verdad"

# game/characters_events_idles/sonya_idles.rpy:477
translate spanish sonya_Idle_evening_myroom_scene_80cdfb7b:

    # gg "А ты не боишься?"
    gg "¿Y no tienes miedo?"

# game/characters_events_idles/sonya_idles.rpy:479
translate spanish sonya_Idle_evening_myroom_scene_562977d2:

    # Sonya "Боюсь. {w}Но мне нравится, когда страшно только снаружи, а внутри спокойно"
    Sonya "Sí, miedo. {w}Pero me gusta cuando da miedo solo por fuera, pero por dentro hay calma"

# game/characters_events_idles/sonya_idles.rpy:481
translate spanish sonya_Idle_evening_myroom_scene_ca77da12:

    # Sonya "Хотя, если вдруг будет слишком жутко - я, может, чуть-чуть прижмусь. Для науки"
    Sonya "Aunque, si de repente da demasiado miedo, quizás me acurruque un poquito. Por ciencia"

# game/characters_events_idles/sonya_idles.rpy:482
translate spanish sonya_Idle_evening_myroom_scene_c7a5bb2e:

    # gg "Чисто научный эксперимент?"
    gg "¿Un experimento puramente científico?"

# game/characters_events_idles/sonya_idles.rpy:483
translate spanish sonya_Idle_evening_myroom_scene_96d1eac0:

    # Sonya "Конечно. Проверим, снижается ли уровень паники при тесном контакте"
    Sonya "Claro. Comprobaremos si el nivel de pánico disminuye con el contacto cercano"

# game/characters_events_idles/sonya_idles.rpy:487
translate spanish sonya_Idle_evening_myroom_scene_0a9cd91f:

    # Sonya "Вот видишь, уже началось"
    Sonya "Ya ves, ya ha empezado"

# game/characters_events_idles/sonya_idles.rpy:488
translate spanish sonya_Idle_evening_myroom_scene_4b16a16b:

    # gg "И как результаты эксперимента?"
    gg "¿Y cómo van los resultados del experimento?"

# game/characters_events_idles/sonya_idles.rpy:490
translate spanish sonya_Idle_evening_myroom_scene_1d60fbd7:

    # Sonya "Пока эффект положительный"
    Sonya "De momento el efecto es positivo"

# game/characters_events_idles/sonya_idles.rpy:491
translate spanish sonya_Idle_evening_myroom_scene_c404867c:

    # Sonya "Но для точности нужно дождаться кульминации"
    Sonya "Pero para mayor precisión hay que esperar al clímax"

# game/characters_events_idles/sonya_idles.rpy:492
translate spanish sonya_Idle_evening_myroom_scene_24bf4b87:

    # Sonya "В такие вечера даже страх кажется уютным"
    Sonya "En esas noches hasta el miedo parece acogedor"

# game/characters_events_idles/sonya_idles.rpy:493
translate spanish sonya_Idle_evening_myroom_scene_741f04d1:

    # gg "Только если есть кому его разделить"
    gg "Solo si hay alguien con quien compartirlo"

# game/characters_events_idles/sonya_idles.rpy:494
translate spanish sonya_Idle_evening_myroom_scene_cf08afaa:

    # Sonya "Думаю, у нас с этим всё в порядке"
    Sonya "Creo que en eso nosotros estamos bien"

translate spanish strings:

    # game/characters_events_idles/sonya_idles.rpy:5
    old "Доброе утро"
    new "Buen día"

    # game/characters_events_idles/sonya_idles.rpy:48
    old "Потрясающе выглядишь"
    new "Te ves increíble"

    # game/characters_events_idles/sonya_idles.rpy:74
    old "Мне пора"
    new "Tengo que irme"

    # game/characters_events_idles/sonya_idles.rpy:138
    old "Привет"
    new "Hola"

    # game/characters_events_idles/sonya_idles.rpy:192
    old "Не мешать"
    new "No interfieras"

    # game/characters_events_idles/sonya_idles.rpy:201
    old "Присесть рядом"
    new "Siéntate a mi lado"

    # game/characters_events_idles/sonya_idles.rpy:237
    old "Не тревожить"
    new "No molestar"

    # game/characters_events_idles/sonya_idles.rpy:249
    old "С добрым утром"
    new "Buen día"

    # game/characters_events_idles/sonya_idles.rpy:274
    old "Позже загляну"
    new "Pasaré luego"

    # game/characters_events_idles/sonya_idles.rpy:283
    old "Вкусно пахнет"
    new "Huele delicioso"

    # game/characters_events_idles/sonya_idles.rpy:330
    old "Ждешь чайник?"
    new "¿Esperando a la tetera?"

    # game/characters_events_idles/sonya_idles.rpy:367
    old "Опять с тряпкой?"
    new "¿Otra vez con el trapo?"

    # game/characters_events_idles/sonya_idles.rpy:464
    old "Что смотрим?"
    new "¿Qué estamos viendo?"

