﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/mc_events.rpy:84
translate spanish gg_intro_57d9b303:

    # gg "Чёрт . . . конец месяца"
    gg "Mierda... fin de mes"

# game/characters_events_idles/mc_events.rpy:86
translate spanish gg_intro_fc2b37ea:

    # gg "Скоро платить по долгам . . ."
    gg "Pronto toca pagar deudas..."

# game/characters_events_idles/mc_events.rpy:88
translate spanish gg_intro_a14d12e5:

    # gg "Ладно . . . хоть сегодня выходной"
    gg "Vale... al menos hoy es día libre"

# game/characters_events_idles/mc_events.rpy:89
translate spanish gg_intro_76bd858b:

    # gg "Хоть что-то"
    gg "Algo es algo"

# game/characters_events_idles/mc_events.rpy:91
translate spanish gg_intro_808930b3:

    # gg "Может, хоть пару часов отдохну. . . {w}просто расслаблюсь"
    gg "Tal vez descanse un par de horas... {w}simplemente me relaje"

# game/characters_events_idles/mc_events.rpy:98
translate spanish gg_intro_df03d227:

    # gg "Ну хоть здесь кто-то есть . . ."
    gg "Bueno, al menos hay alguien aquí..."

# game/characters_events_idles/mc_events.rpy:102
translate spanish gg_intro_9b1348ec:

    # gg "Найс, я их разнес"
    gg "Bien, los destrozo"

# game/characters_events_idles/mc_events.rpy:104
translate spanish gg_intro_f004ad75:

    # gg "Ладно . . . бывает"
    gg "Vale... sucede"

# game/characters_events_idles/mc_events.rpy:105
translate spanish gg_intro_3aef7ac5:

    # gg "Следующая будет норм"
    gg "La próxima irá bien"

# game/characters_events_idles/mc_events.rpy:107
translate spanish gg_intro_f6ebf694:

    # gg "бляя . . ."
    gg "Joder..."

# game/characters_events_idles/mc_events.rpy:111
translate spanish gg_intro_e7a753f9:

    # gg "вот суки"
    gg "Pero qué putas"

# game/characters_events_idles/mc_events.rpy:112
translate spanish gg_intro_3a97b002:

    # gg "Окей ладно супер последняя на победу"
    gg "Vale, vale, una última para ganar"

# game/characters_events_idles/mc_events.rpy:114
translate spanish gg_intro_94d70a59:

    # gg "{sc}{size=*1.5}СУКА!{/size}{/sc}" with vpunch
    gg "{sc}{size=*1.5}¡PUTA!{/size}{/sc}" with vpunch

# game/characters_events_idles/mc_events.rpy:118
translate spanish gg_intro_08de7acc:

    # gg "Да пошло оно всё . . ."
    gg "Que le den a todo..."

# game/characters_events_idles/mc_events.rpy:119
translate spanish gg_intro_62b01796:

    # gg "Какая же трата времени"
    gg "Qué pérdida de tiempo"

# game/characters_events_idles/mc_events.rpy:122
translate spanish gg_intro_55fbce1e:

    # gg "Выходной . . . единственный день . . ."
    gg "Día libre... el único día..."

# game/characters_events_idles/mc_events.rpy:123
translate spanish gg_intro_f0abf492:

    # gg "И я просто убил его на эту грёбаную игру"
    gg "Y lo he malgastado en este maldito juego"

# game/characters_events_idles/mc_events.rpy:125
translate spanish gg_intro_d924704e:

    # gg "Экран это единственное с чем я общаюсь последнее время"
    gg "La pantalla es lo único con lo que interactúo últimamente"

# game/characters_events_idles/mc_events.rpy:131
translate spanish gg_intro_59ed329a:

    # gg "Я живу здесь . . . но эта квартира"
    gg "Vivo aquí... pero este piso..."

# game/characters_events_idles/mc_events.rpy:132
translate spanish gg_intro_0d6c2d2c:

    # gg "Просто точка между работой и снова работой"
    gg "Es solo un punto entre el trabajo y otra vez el trabajo"

# game/characters_events_idles/mc_events.rpy:140
translate spanish gg_intro_7ce95d1c:

    # gg "Только там . . ."
    gg "Solo allí..."

# game/characters_events_idles/mc_events.rpy:142
translate spanish gg_intro_fa2b02fe:

    # gg "Я чувствовал себя живым"
    gg "Me sentía vivo"

# game/characters_events_idles/mc_events.rpy:144
translate spanish gg_intro_5a38b375:

    # gg "Я . . . устал так жить"
    gg "Estoy... cansado de vivir así"

# game/characters_events_idles/mc_events.rpy:164
translate spanish gg_intro_eb77ecfa:

    # gg "Да иду я, иду . . ."
    gg "Sí, ya voy, ya voy..."

# game/characters_events_idles/mc_events.rpy:168
translate spanish gg_intro_565267c5:

    # gg "Кто там?"
    gg "¿Quién es?"

# game/characters_events_idles/mc_events.rpy:173
translate spanish gg_intro_60b12a13:

    # gg "Ты кто?"
    gg "¿Quién eres tú?"

# game/characters_events_idles/mc_events.rpy:175
translate spanish gg_intro_e00854e1:

    # PostMan "Я почтальон"
    PostMan "Soy el cartero"

# game/characters_events_idles/mc_events.rpy:176
translate spanish gg_intro_0715dd94:

    # gg "Почтальоны теперь так одеваются?"
    gg "¿Los carteros se visten así ahora?"

# game/characters_events_idles/mc_events.rpy:178
translate spanish gg_intro_0d42e0ef:

    # PostMan "Вот смотри для тебя нарисовали"
    PostMan "Mira, hay un dibujo para ti"

# game/characters_events_idles/mc_events.rpy:180
translate spanish gg_intro_e75db202:

    # PostMan "А я одеваюсь как хочу"
    PostMan "Y yo me visto como quiero"

# game/characters_events_idles/mc_events.rpy:181
translate spanish gg_intro_615e77bc:

    # gg "Так а посылка?"
    gg "¿Y el paquete?"

# game/characters_events_idles/mc_events.rpy:183
translate spanish gg_intro_096cd512:

    # PostMan "А! сейчас"
    PostMan "¡Ah! Ahora"

# game/characters_events_idles/mc_events.rpy:185
translate spanish gg_intro_0d3968a6:

    # PostMan "Вот, ты же [povname] правильно?"
    PostMan "Toma, tú eres [povname], ¿verdad?"

# game/characters_events_idles/mc_events.rpy:187
translate spanish gg_intro_df24437b:

    # gg "Да, спасибо"
    gg "Sí, gracias"

# game/characters_events_idles/mc_events.rpy:189
translate spanish gg_intro_d7f65fd8:

    # PostMan "Доставка уже оплачена, так что до свидания"
    PostMan "El envío ya está pagado, así que adiós"

# game/characters_events_idles/mc_events.rpy:196
translate spanish gg_intro_94ec24eb:

    # gg_chat "Эта квартира слишком дорого мне обходится"
    gg_chat "Este piso me está costando demasiado caro"

# game/characters_events_idles/mc_events.rpy:200
translate spanish gg_intro_083c370e:

    # gg_chat "Эти долги меня скоро сьедят"
    gg_chat "Estas deudas me van a consumir pronto"

# game/characters_events_idles/mc_events.rpy:203
translate spanish gg_intro_a7a8221e:

    # gg_chat "Что? {w}Линда?"
    gg_chat "¿Qué? {w}¿Linda?"

# game/characters_events_idles/mc_events.rpy:208
translate spanish gg_intro_98898eb6:

    # gg_chat "От бабушки . . ."
    gg_chat "De la abuela..."

# game/characters_events_idles/mc_events.rpy:210
translate spanish gg_intro_3341868c:

    # gg_chat "Давно не видел её . . ."
    gg_chat "Hace mucho que no la veo..."

# game/characters_events_idles/mc_events.rpy:211
translate spanish gg_intro_6f756f5d:

    # gg_chat "Зачем она мне это?"
    gg_chat "¿Para qué me manda esto?"

# game/characters_events_idles/mc_events.rpy:212
translate spanish gg_intro_9f5ccf2a:

    # "Дорогой мой, [povname]"
    "Mi querido, [povname]"

# game/characters_events_idles/mc_events.rpy:213
translate spanish gg_intro_7d8221c5:

    # "Пишу тебе это письмо с особым волнением — не потому, что что-то случилось"
    "Te escribo esta carta con especial ilusión, no porque haya pasado algo"

# game/characters_events_idles/mc_events.rpy:214
translate spanish gg_intro_bb3819ba:

    # "А потому, что скоро мне предстоит небольшое, но долгое путешествие"
    "sino porque pronto emprenderé un viaje corto, pero largo"

# game/characters_events_idles/mc_events.rpy:215
translate spanish gg_intro_a901876a:

    # "С тех пор, как ты уехал, тут многое стало тише, спокойнее"
    "Desde que te fuiste, aquí todo se ha vuelto más tranquilo y silencioso"

# game/characters_events_idles/mc_events.rpy:216
translate spanish gg_intro_8aaddaf9:

    # "Но рядом всё ещё живут хорошие люди — кто-то поможет, если нужно, кто-то просто заглянет поболтать"
    "Pero aún hay buena gente cerca, alguien que ayudará si es necesario, alguien que pasará a charlar"

# game/characters_events_idles/mc_events.rpy:217
translate spanish gg_intro_8049e805:

    # "Дом, в котором ты вырос летом, скоро останется без хозяйки . . ."
    "La casa donde pasaste los veranos de niño pronto se quedará sin su dueña..."

# game/characters_events_idles/mc_events.rpy:218
translate spanish gg_intro_7713047b:

    # "И мне очень бы не хотелось, чтобы он начал ветшать"
    "Y no me gustaría nada que empezara a deteriorarse"

# game/characters_events_idles/mc_events.rpy:220
translate spanish gg_intro_ce9ad3bf:

    # "Я уезжаю на несколько лет — не волнуйся, здоровье моё в порядке, просто пришло время пожить немного иначе"
    "Me voy por unos años. No te preocupes, mi salud está bien, simplemente ha llegado el momento de vivir de forma un poco distinta"

# game/characters_events_idles/mc_events.rpy:221
translate spanish gg_intro_56cba277:

    # "Пока меня не будет, хочу тебя попросить заглядывать в дом"
    "Mientras esté fuera, quiero pedirte que te pases por la casa"

# game/characters_events_idles/mc_events.rpy:222
translate spanish gg_intro_9768b114:

    # "Пусть не пустеет, пусть скрипят половицы, пусть греется чайник"
    "Que no se quede vacía, que crujan las tablas del suelo, que hierva la tetera"

# game/characters_events_idles/mc_events.rpy:223
translate spanish gg_intro_040e7339:

    # "Он живой, наш дом — если забросить, начнёт хандрить"
    "Está vivo, nuestra casa. Si la abandonas, se pondrá triste"

# game/characters_events_idles/mc_events.rpy:224
translate spanish gg_intro_581165e6:

    # gg "Она всегда так говорила . . . {w}будто дом — живой"
    gg "Siempre decía eso... {w}como si la casa estuviera viva"

# game/characters_events_idles/mc_events.rpy:226
translate spanish gg_intro_82ffc349:

    # "И ещё . . . цветы"
    "Y otra cosa... las flores"

# game/characters_events_idles/mc_events.rpy:227
translate spanish gg_intro_3c7f2026:

    # "Мои две любимые. Они остались"
    "Mis dos favoritas. Se quedan"

# game/characters_events_idles/mc_events.rpy:228
translate spanish gg_intro_a2adc801:

    # "Одна крепкая, корнями в землю, упрямая, немного колючая, зато как зацветёт — всем на удивление"
    "Una es fuerte, arraigada, testaruda, un poco espinosa, pero cuando florece, sorprende a todos"

# game/characters_events_idles/mc_events.rpy:229
translate spanish gg_intro_d1748522:

    # "Вторая — лёгкая, солнечная, смеётся даже в дождь, растёт, куда глянет, и всё ей в радость"
    "La otra es ligera, soleada, ríe incluso bajo la lluvia, crece hacia donde mira y todo le da alegría"

# game/characters_events_idles/mc_events.rpy:231
translate spanish gg_intro_5cd83b3b:

    # gg_chat "Причем здесь цветы вообще . . ."
    gg_chat "Y qué tienen que ver las flores con esto..."

# game/characters_events_idles/mc_events.rpy:232
translate spanish gg_intro_d87a1c8d:

    # "Уход у них разный, но суть одна — внимание"
    "Su cuidado es diferente, pero la esencia es la misma: atención"

# game/characters_events_idles/mc_events.rpy:233
translate spanish gg_intro_0733c9df:

    # "Ты справишься — у тебя ведь моё упрямство и моё сердце"
    "Tú puedes con ello, tienes mi terquedad y mi corazón"

# game/characters_events_idles/mc_events.rpy:234
translate spanish gg_intro_3406a366:

    # "Очень хочу, чтобы ты оказался там пораньше — дом ждёт тебя"
    "Me encantaría que llegaras pronto; la casa te espera"

# game/characters_events_idles/mc_events.rpy:235
translate spanish gg_intro_bfcc2649:

    # "С любовью"
    "Con amor,"

# game/characters_events_idles/mc_events.rpy:236
translate spanish gg_intro_3f6a1326:

    # "Твоя бабушка Линда"
    "Tu abuela Linda"

# game/characters_events_idles/mc_events.rpy:238
translate spanish gg_intro_22bce088:

    # gg_chat "Бабушка была всегда рядом, её дом был моим домом"
    gg_chat "La abuela siempre estuvo ahí, su casa era mi hogar"

# game/characters_events_idles/mc_events.rpy:240
translate spanish gg_intro_4164e503:

    # gg_chat "Зачем она меня просит присматривать за домом?"
    gg_chat "¿Por qué me pide que cuide la casa?"

# game/characters_events_idles/mc_events.rpy:242
translate spanish gg_intro_ad05e118:

    # gg_chat "Просто взять и уехать?"
    gg_chat "¿Simplemente largarme de aquí?"

# game/characters_events_idles/mc_events.rpy:244
translate spanish gg_intro_0ae1f5e0:

    # gg_chat "Будто у меня тут ничего нет"
    gg_chat "Como si no tuviera nada aquí"

# game/characters_events_idles/mc_events.rpy:246
translate spanish gg_intro_e3e17f69:

    # gg_chat "У меня своих проблем по горло"
    gg_chat "Ya tengo bastantes problemas propios"

# game/characters_events_idles/mc_events.rpy:248
translate spanish gg_intro_4810f11e:

    # gg_chat "Чёрт я опаздываю"
    gg_chat "Mierda, llego tarde"

# game/characters_events_idles/mc_events.rpy:250
translate spanish gg_intro_3aa5e105:

    # gg_chat "Потом поем"
    gg_chat "Comeré luego"

# game/characters_events_idles/mc_events.rpy:254
translate spanish gg_intro_4a0266b9:

    # gg_chat "Я отвечу бабушка попозже"
    gg_chat "Le responderé a la abuela más tarde"

# game/characters_events_idles/mc_events.rpy:261
translate spanish gg_intro_9cdabec6:

    # gg_chat "Серьёзно? . . ."
    gg_chat "¿En serio?..."

# game/characters_events_idles/mc_events.rpy:265
translate spanish gg_intro_7331a474:

    # gg_chat "Блять . . ."
    gg_chat "Joder..."

# game/characters_events_idles/mc_events.rpy:266
translate spanish gg_intro_db310e96:

    # gg_chat "Как всегда"
    gg_chat "Como siempre"

# game/characters_events_idles/mc_events.rpy:270
translate spanish gg_intro_4b9afd3e:

    # gg "Я пришел"
    gg "Ya llegué"

# game/characters_events_idles/mc_events.rpy:272
translate spanish gg_intro_80d3fcff:

    # Assistant "Опоздал. Как всегда"
    Assistant "Llegas tarde. Como siempre"

# game/characters_events_idles/mc_events.rpy:274
translate spanish gg_intro_d3b968fb:

    # Assistant "И напомню: если продолжишь {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "Y te recuerdo: si esto continúa {w}hablar de una reducción de sueldo será solo cuestión de tiempo"

# game/characters_events_idles/mc_events.rpy:276
translate spanish gg_intro_0bd28ad3:

    # gg_chat "Да, конечно"
    gg_chat "Sí, claro"

# game/characters_events_idles/mc_events.rpy:285
translate spanish gg_intro_603b869e:

    # Director "Это срочно"
    Director "Esto es urgente"

# game/characters_events_idles/mc_events.rpy:287
translate spanish gg_intro_eac333f5:

    # Director "За Петрова сделаешь"
    Director "Harás el trabajo de Petrov"

# game/characters_events_idles/mc_events.rpy:289
translate spanish gg_intro_2ccd9b60:

    # gg "Это не мои задачи"
    gg "Esas no son mis tareas"

# game/characters_events_idles/mc_events.rpy:290
translate spanish gg_intro_df8035b4:

    # gg "Почему я должен работать за другого"
    gg "¿Por qué debo trabajar por otro?"

# game/characters_events_idles/mc_events.rpy:292
translate spanish gg_intro_e2eb6337:

    # Director "Мне плевать"
    Director "Me da igual"

# game/characters_events_idles/mc_events.rpy:294
translate spanish gg_intro_66f2f5ce:

    # Director "Сделаешь всё до конца недели"
    Director "Lo tendrás todo listo para el fin de semana"

# game/characters_events_idles/mc_events.rpy:297
translate spanish gg_intro_b7d7b4b2:

    # Director "Не успеешь — сам знаешь последствия"
    Director "Si no lo terminas, ya conoces las consecuencias"

# game/characters_events_idles/mc_events.rpy:303
translate spanish gg_intro_3d5010f4:

    # gg_chat "Им всегда плевать"
    gg_chat "A ellos siempre les da igual"

# game/characters_events_idles/mc_events.rpy:304
translate spanish gg_intro_1670588b:

    # gg_chat "Я здесь просто расходник"
    gg_chat "Aquí solo soy un recurso consumible"

# game/characters_events_idles/mc_events.rpy:308
translate spanish gg_intro_3c056c18:

    # gg_chat "Сколько ни делай — конца нет"
    gg_chat "Da igual cuánto haga, nunca termina"

# game/characters_events_idles/mc_events.rpy:321
translate spanish gg_intro_577e1c14:

    # Director "Секретарша сказала"
    Director "La secretaria dijo"

# game/characters_events_idles/mc_events.rpy:324
translate spanish gg_intro_e2282b24:

    # Director "Что ты опоздал"
    Director "que llegaste tarde"

# game/characters_events_idles/mc_events.rpy:326
translate spanish gg_intro_009afbde:

    # Director "Если не сдашь это в срок"
    Director "Si no entregas esto a tiempo,"

# game/characters_events_idles/mc_events.rpy:327
translate spanish gg_intro_e8f982f1:

    # Director "Можешь искать новую работу"
    Director "puedes empezar a buscar otro trabajo"

# game/characters_events_idles/mc_events.rpy:329
translate spanish gg_intro_5d67e1da:

    # Director "Понял?"
    Director "¿Entendido?"

# game/characters_events_idles/mc_events.rpy:330
translate spanish gg_intro_ef555dd8:

    # gg_chat "Вот сука"
    gg_chat "Vaya putada"

# game/characters_events_idles/mc_events.rpy:332
translate spanish gg_intro_e967e307:

    # gg "Да"
    gg "Sí"

# game/characters_events_idles/mc_events.rpy:340
translate spanish gg_intro_aba5df1c:

    # gg_chat "Им всё равно — значит, и мне тоже"
    gg_chat "A ellos no les importa, así que a mí tampoco"

# game/characters_events_idles/mc_events.rpy:342
translate spanish gg_intro_59df236a:

    # gg_chat "С меня довольно"
    gg_chat "Ya es suficiente"

# game/characters_events_idles/mc_events.rpy:344
translate spanish gg_intro_c0a84961:

    # gg_chat "Не поспешил ли я?"
    gg_chat "¿Me estaré precipitando?"

# game/characters_events_idles/mc_events.rpy:346
translate spanish gg_intro_a632776e:

    # gg_chat "Хватит"
    gg_chat "Basta"

# game/characters_events_idles/mc_events.rpy:355
translate spanish gg_intro_14d66a18:

    # Director "Ты вообще, что делаешь"
    Director "¿Qué estás haciendo?"

# game/characters_events_idles/mc_events.rpy:357
translate spanish gg_intro_dfc9c282:

    # gg "Я увольняюсь"
    gg "Renuncio"

# game/characters_events_idles/mc_events.rpy:359
translate spanish gg_intro_8543ef20:

    # Director "Как ты смеешь??"
    Director "¿Cómo te atreves?"

# game/characters_events_idles/mc_events.rpy:371
translate spanish gg_intro_1a1334a8:

    # Assistant "Ой"
    Assistant "Oh"

# game/characters_events_idles/mc_events.rpy:373
translate spanish gg_intro_11803396:

    # Assistant "Ты что делаешь!?"
    Assistant "¿¡Qué estás haciendo!?"

# game/characters_events_idles/mc_events.rpy:374
translate spanish gg_intro_b31c2e41:

    # gg "Счастливо оставаться"
    gg "Que les vaya bien"

# game/characters_events_idles/mc_events.rpy:376
translate spanish gg_intro_96fd98eb:

    # gg_chat "Наконец-то"
    gg_chat "Por fin"

# game/characters_events_idles/mc_events.rpy:378
translate spanish gg_intro_e446a106:

    # gg_chat "Моя привычная жизнь закончилась"
    gg_chat "Mi vida de siempre ha terminado"

# game/characters_events_idles/mc_events.rpy:382
translate spanish gg_intro_724c298c:

    # gg_chat "На улице столько парочек гуляет"
    gg_chat "Hay tantas parejas paseando por la calle"

# game/characters_events_idles/mc_events.rpy:383
translate spanish gg_intro_acc56f85:

    # gg_chat "Жизнь будто проходит мимо"
    gg_chat "La vida parece pasar de largo"

# game/characters_events_idles/mc_events.rpy:397
translate spanish gg_intro_a57d47f4:

    # gg_chat "Я даже не заметил"
    gg_chat "Ni siquiera me di cuenta"

# game/characters_events_idles/mc_events.rpy:399
translate spanish gg_intro_1ba141ba:

    # gg_chat "Только у моего родного дома был такой ключ"
    gg_chat "Solo mi hogar tenía una llave así"

# game/characters_events_idles/mc_events.rpy:401
translate spanish gg_intro_cfb8599b:

    # gg_chat "Это шанс"
    gg_chat "Es una oportunidad"

# game/characters_events_idles/mc_events.rpy:402
translate spanish gg_intro_3ce8ccb4:

    # gg_chat "На новую жизнь"
    gg_chat "Para una nueva vida"

# game/characters_events_idles/mc_events.rpy:404
translate spanish gg_intro_4db85a28:

    # gg_chat "Это все мне больше не нужно"
    gg_chat "Ya no necesito todo esto"

# game/characters_events_idles/mc_events.rpy:414
translate spanish gg_intro_c3f38f42:

    # gg_chat "Пора начать сначала"
    gg_chat "Es hora de empezar de nuevo"

# game/characters_events_idles/mc_events.rpy:422
translate spanish gg_intro_07728fd6:

    # gg_chat "После города — будто другой мир"
    gg_chat "Después de la ciudad es como otro mundo"

# game/characters_events_idles/mc_events.rpy:424
translate spanish gg_intro_fe890fb1:

    # gg_chat "Даже к этому я отвык . . ."
    gg_chat "Hasta de esto me he desacostumbrado..."

# game/characters_events_idles/mc_events.rpy:428
translate spanish gg_intro_cac1bf85:

    # gg_chat "Мне здесь придётся многому научиться"
    gg_chat "Tengo mucho que aprender aquí"

# game/characters_events_idles/mc_events.rpy:431
translate spanish gg_intro_a05332c8:

    # gg_chat "Я даже позабыл где дом . . ."
    gg_chat "Incluso olvidé dónde está mi hogar..."

# game/characters_events_idles/mc_events.rpy:433
translate spanish gg_intro_a4a7b296:

    # gg_chat "Все кого я вижу со мной здороваются"
    gg_chat "Todos los que veo me saludan"

# game/characters_events_idles/mc_events.rpy:434
translate spanish gg_intro_720fce13:

    # gg_chat "Будто я тут не чужой"
    gg_chat "Es como si no fuera un extraño aquí"

# game/characters_events_idles/mc_events.rpy:435
translate spanish gg_intro_094d1de6:

    # UnknownGirl "Эй парень, постой-ка!"
    UnknownGirl "¡Eh, chico, espera!"

# game/characters_events_idles/mc_events.rpy:437
translate spanish gg_intro_050bbcbc:

    # gg "Здравствуйте"
    gg "Hola"

# game/characters_events_idles/mc_events.rpy:439
translate spanish gg_intro_0e31fcad:

    # UnknownGirl "Давно тут новых лиц не видели"
    UnknownGirl "Hace tiempo que no vemos caras nuevas por aquí"

# game/characters_events_idles/mc_events.rpy:441
translate spanish gg_intro_0ea7d489:

    # gg "Да только приехал"
    gg "Sí, acabo de llegar"

# game/characters_events_idles/mc_events.rpy:443
translate spanish gg_intro_a55c0f0a:

    # UnknownGirl "У нас тут новым людям всегда рады"
    UnknownGirl "Aquí siempre damos la bienvenida a los nuevos"

# game/characters_events_idles/mc_events.rpy:445
translate spanish gg_intro_096f2b23:

    # UnknownGirl "Только вот"
    UnknownGirl "Pero es que..."

# game/characters_events_idles/mc_events.rpy:446
translate spanish gg_intro_83909d33:

    # UnknownGirl "Настоящих мужчин не хватает"
    UnknownGirl "No hay suficientes hombres de verdad"

# game/characters_events_idles/mc_events.rpy:448
translate spanish gg_intro_8ffcdc07:

    # gg_chat "Что она вообще имеет в виду?"
    gg_chat "¿Qué quiere decir ella?"

# game/characters_events_idles/mc_events.rpy:450
translate spanish gg_intro_f312c19f:

    # UnknownGirl "Ладно, не пугайся. Шучу"
    UnknownGirl "Está bien, no te asustes. Es broma"

# game/characters_events_idles/mc_events.rpy:452
translate spanish gg_intro_af75b79f:

    # UnknownGirl "Если что то нужно будет спрашивай помощь у любого"
    UnknownGirl "Si necesitas algo, pide ayuda a cualquiera"

# game/characters_events_idles/mc_events.rpy:454
translate spanish gg_intro_f35a0bb9:

    # UnknownGirl "Удачи тебе"
    UnknownGirl "Buena suerte"

# game/characters_events_idles/mc_events.rpy:456
translate spanish gg_intro_6a134ac2:

    # gg "Хорошо и вам отличного дня"
    gg "Igualmente, que tenga un buen día"

# game/characters_events_idles/mc_events.rpy:458
translate spanish gg_intro_b0f731c4:

    # gg_chat "Какая необычно добрая девушка"
    gg_chat "Qué chica tan inusualmente amable"

# game/characters_events_idles/mc_events.rpy:459
translate spanish gg_intro_b08ae0cc:

    # gg_chat "Бабушка похоже говорила правду о людях здесь"
    gg_chat "La abuela parecía decir la verdad sobre la gente de aquí"

# game/characters_events_idles/mc_events.rpy:463
translate spanish gg_intro_b07cdeca:

    # gg_chat "А если там уже не так, как я помню?"
    gg_chat "¿Y si ya no es lo mismo que recuerdo?"

# game/characters_events_idles/mc_events.rpy:465
translate spanish gg_intro_2c26269d:

    # gg_chat "Но назад пути нет"
    gg_chat "Pero no hay vuelta atrás"

# game/characters_events_idles/mc_events.rpy:474
translate spanish gg_intro_9b8edceb:

    # gg_chat "Да дом поменялся"
    gg_chat "Sí, la casa ha cambiado"

# game/characters_events_idles/mc_events.rpy:482
translate spanish gg_intro_766d518e:

    # gg_chat "Кто-то есть?"
    gg_chat "¿Hay alguien?"

# game/characters_events_idles/mc_events.rpy:492
translate spanish gg_intro_b989363c:

    # gg ". . ."
    gg "..."

# game/characters_events_idles/mc_events.rpy:498
translate spanish gg_intro_7ad2e1b7:

    # Sonya "АААА!"
    Sonya "¡AAAAA!"

# game/characters_events_idles/mc_events.rpy:500
translate spanish gg_intro_684edc0b:

    # Sonya "МАЯ!"
    Sonya "¡MAYA!"

# game/characters_events_idles/mc_events.rpy:502
translate spanish gg_intro_1124aafa:

    # Sonya "МАЯ, ТУТ КТО-ТО ЕСТЬ!!"
    Sonya "¡MAYA, HAY ALGUIEN AQUÍ!"

# game/characters_events_idles/mc_events.rpy:506
translate spanish gg_intro_cba5cc13:

    # gg_chat "Что это сейчас было? . . ."
    gg_chat "¿Qué fue eso ahora?..."

# game/characters_events_idles/mc_events.rpy:508
translate spanish gg_intro_74014e3a:

    # gg_chat "Я . . ."
    gg_chat "Yo..."

# game/characters_events_idles/mc_events.rpy:510
translate spanish gg_intro_8b3408ac:

    # gg_chat "Я ничего не понял"
    gg_chat "No entendí nada"

# game/characters_events_idles/mc_events.rpy:515
translate spanish gg_intro_18e79df2:

    # Maya "Ты кто такой?"
    Maya "¿Quién eres?"

# game/characters_events_idles/mc_events.rpy:517
translate spanish gg_intro_35cf3bf6:

    # Maya "Убирайся отсюда. Сейчас же"
    Maya "Sal de aquí. ¡Ahora mismo!"

# game/characters_events_idles/mc_events.rpy:519
translate spanish gg_intro_be5ef2a9:

    # gg "Стой подожди"
    gg "Espera, espera"

# game/characters_events_idles/mc_events.rpy:521
translate spanish gg_intro_8750b79b:

    # gg "Я внук хозяйки дома"
    gg "Soy el nieto de la dueña de la casa"

# game/characters_events_idles/mc_events.rpy:523
translate spanish gg_intro_eba62b3e:

    # gg "Это дом моей бабушки"
    gg "Esta es la casa de mi abuela"

# game/characters_events_idles/mc_events.rpy:525
translate spanish gg_intro_d179509d:

    # Maya "Внук?"
    Maya "¿Nieto?"

# game/characters_events_idles/mc_events.rpy:527
translate spanish gg_intro_cb51aa26:

    # Maya "Что то я такого внука никогда здесь не видела"
    Maya "Nunca había visto un nieto así aquí"

# game/characters_events_idles/mc_events.rpy:529
translate spanish gg_intro_fde7546c:

    # Maya "Думаешь я совсем тупая"
    Maya "¿Crees que soy completamente estúpida?"

# game/characters_events_idles/mc_events.rpy:531
translate spanish gg_intro_a41fbef3:

    # gg "Подожди"
    gg "Espera"

# game/characters_events_idles/mc_events.rpy:533
translate spanish gg_intro_0df5d29f:

    # gg "Я не знал, что здесь кто-то живёт"
    gg "No sabía que alguien vivía aquí"

# game/characters_events_idles/mc_events.rpy:535
translate spanish gg_intro_4b24971a:

    # Maya "Конечно не знал"
    Maya "Por supuesto que no lo sabías"

# game/characters_events_idles/mc_events.rpy:537
translate spanish gg_intro_4af9c6fc:

    # Maya "А в чужие дома ты тоже «случайно» заходишь?"
    Maya "¿Entras también “accidentalmente” en casas de otras personas?"

# game/characters_events_idles/mc_events.rpy:543
translate spanish gg_intro_2a307bc4:

    # gg "Вот"
    gg "Toma"

# game/characters_events_idles/mc_events.rpy:545
translate spanish gg_intro_c9e9dab5:

    # gg "Это письмо от моей бабушки"
    gg "Esta carta es de mi abuela"

# game/characters_events_idles/mc_events.rpy:547
translate spanish gg_intro_4a769d1b:

    # gg "Она попросила меня присмотреть за домом"
    gg "Ella me pidió que cuidara la casa"

# game/characters_events_idles/mc_events.rpy:549
translate spanish gg_intro_ee0d1154:

    # Maya "И ты думаешь, я просто поверю этой бумажке?"
    Maya "¿Y crees que simplemente creeré en este trozo de papel?"

# game/characters_events_idles/mc_events.rpy:551
translate spanish gg_intro_6d39543d:

    # gg "Я никуда не спешу"
    gg "No tengo prisa"

# game/characters_events_idles/mc_events.rpy:563
translate spanish gg_intro_8ea26f73:

    # Maya "Дорогой"
    Maya "Querido"

# game/characters_events_idles/mc_events.rpy:565
translate spanish gg_intro_9a149321:

    # Maya "[povname]"
    Maya "[povname]"

# game/characters_events_idles/mc_events.rpy:569
translate spanish gg_intro_6e311c65:

    # Maya "Скоро останется без хозяйки"
    Maya "Pronto se quedará sin dueña"

# game/characters_events_idles/mc_events.rpy:571
translate spanish gg_intro_2d481ec2:

    # Maya "Уезжаю на несколько лет"
    Maya "Me voy por unos años"

# game/characters_events_idles/mc_events.rpy:573
translate spanish gg_intro_cada9fb7:

    # Maya "Мои цветы две любимые. Они остались"
    Maya "Mis dos flores favoritas. Se quedan"

# game/characters_events_idles/mc_events.rpy:575
translate spanish gg_intro_4e84a3f6:

    # Maya "Дом ждёт тебя"
    Maya "El hogar te está esperando"

# game/characters_events_idles/mc_events.rpy:577
translate spanish gg_intro_a2cdc4ac:

    # Maya "Твоя бабушка Линда"
    Maya "Tu abuela Linda"

# game/characters_events_idles/mc_events.rpy:582
translate spanish gg_intro_dfc10494:

    # Maya "Боже ладно"
    Maya "Vale, por el amor de Dios"

# game/characters_events_idles/mc_events.rpy:583
translate spanish gg_intro_c4340902:

    # Maya "Похоже, на правду"
    Maya "Parece que es verdad"

# game/characters_events_idles/mc_events.rpy:585
translate spanish gg_intro_329e21f7:

    # Maya "Но это ничего не меняет"
    Maya "Pero no cambia nada"

# game/characters_events_idles/mc_events.rpy:587
translate spanish gg_intro_dd6c3bfe:

    # Maya "Ту здесь чужой"
    Maya "Eres un extraño aquí"

# game/characters_events_idles/mc_events.rpy:589
translate spanish gg_intro_69801038:

    # gg "Вообще-то это мой дом"
    gg "En realidad esta es mi casa"

# game/characters_events_idles/mc_events.rpy:591
translate spanish gg_intro_9a295059:

    # Maya "Это ты мы с Соней решим!"
    Maya "¡Eso lo decidiremos Sonya y yo!"

# game/characters_events_idles/mc_events.rpy:593
translate spanish gg_intro_9839e4df:

    # Maya "{sc}СОНЯ{/sc}" with hpunch
    Maya "{sc}SONYA{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:595
translate spanish gg_intro_2551f6f7:

    # Maya "Всё нормально, он не опасный"
    Maya "Está bien, él no es peligroso"

# game/characters_events_idles/mc_events.rpy:597
translate spanish gg_intro_d6a7eefb:

    # gg "Я так и сказал"
    gg "Eso es lo que dije"

# game/characters_events_idles/mc_events.rpy:599
translate spanish gg_intro_f3cf760b:

    # Maya "Слушай если ты хоть что-то сделаешь"
    Maya "Escucha, si haces algo"

# game/characters_events_idles/mc_events.rpy:601
translate spanish gg_intro_d58555f3:

    # Maya "Я тебя мигом выгоню. Понял?"
    Maya "Te echaré al instante. ¿Comprendido?"

# game/characters_events_idles/mc_events.rpy:603
translate spanish gg_intro_d96e5a49:

    # gg "Понял"
    gg "Comprendido"

# game/characters_events_idles/mc_events.rpy:605
translate spanish gg_intro_a59664de:

    # Maya "Жди на кухне я передам письмо соне"
    Maya "Espera en la cocina, le daré la carta a Sonya"

# game/characters_events_idles/mc_events.rpy:612
translate spanish gg_intro_0ac91294:

    # gg_chat "Вот это встреча"
    gg_chat "Vaya encuentro"

# game/characters_events_idles/mc_events.rpy:616
translate spanish gg_intro_baac99bc:

    # gg_chat "Я не ожидал такого"
    gg_chat "No esperaba esto"

# game/characters_events_idles/mc_events.rpy:618
translate spanish gg_intro_feaa3808:

    # gg_chat "Почему бабушка ничего не сказала?"
    gg_chat "¿Por qué la abuela no dijo nada?"

# game/characters_events_idles/mc_events.rpy:627
translate spanish gg_intro_a070649e:

    # Sonya "Эм . . . привет"
    Sonya "Eh... hola"

# game/characters_events_idles/mc_events.rpy:629
translate spanish gg_intro_6a2024b3:

    # Sonya "Я . . . я Соня"
    Sonya "Yo... soy Sonya"

# game/characters_events_idles/mc_events.rpy:631
translate spanish gg_intro_12083d44:

    # Sonya "Я надеюсь ты не обиделся на Маю"
    Sonya "Espero que no te hayas molestado con Maya"

# game/characters_events_idles/mc_events.rpy:633
translate spanish gg_intro_dfe04d57:

    # gg "Нет. Всё нормально"
    gg "No, todo está bien"

# game/characters_events_idles/mc_events.rpy:635
translate spanish gg_intro_85f8708a:

    # gg "Я [povname]"
    gg "Soy [povname]"

# game/characters_events_idles/mc_events.rpy:637
translate spanish gg_intro_78b27818:

    # Sonya "Мая сказала, что ты внук Линды"
    Sonya "Maya dijo que eres el nieto de Linda"

# game/characters_events_idles/mc_events.rpy:638
translate spanish gg_intro_b5f632a7:

    # Sonya "Так . . . неожиданно получилось"
    Sonya "Ha sido... inesperado"

# game/characters_events_idles/mc_events.rpy:643
translate spanish gg_intro_053ce261:

    # Sonya "И если честно"
    Sonya "Y para ser sincera..."

# game/characters_events_idles/mc_events.rpy:645
translate spanish gg_intro_4bf5a43d:

    # Sonya "Я сначала очень испугалась"
    Sonya "Al principio me asusté mucho"

# game/characters_events_idles/mc_events.rpy:649
translate spanish gg_intro_87cb5bde:

    # gg "Извини"
    gg "Lo siento"

# game/characters_events_idles/mc_events.rpy:651
translate spanish gg_intro_1dc14df3:

    # gg "Я правда не хотел тебя пугать, стоило постучать"
    gg "Realmente no quise asustarte, debería haber tocado a la puerta"

# game/characters_events_idles/mc_events.rpy:655
translate spanish gg_intro_2d8b9c21:

    # Sonya "Нет-нет всё нормально"
    Sonya "No, no, todo está bien"

# game/characters_events_idles/mc_events.rpy:657
translate spanish gg_intro_9587b334:

    # Sonya "Просто не ожидали гостей"
    Sonya "Simplemente no esperábamos invitados"

# game/characters_events_idles/mc_events.rpy:661
translate spanish gg_intro_9a863e77:

    # Sonya "Я прочла письмо линды"
    Sonya "Leí la carta de Linda"

# game/characters_events_idles/mc_events.rpy:663
translate spanish gg_intro_c7d51db6:

    # Sonya "Там про цветы было"
    Sonya "Había algo sobre flores"

# game/characters_events_idles/mc_events.rpy:665
translate spanish gg_intro_c9e9d0a0:

    # Sonya "Это она так нас описывает"
    Sonya "Así es como nos describe"

# game/characters_events_idles/mc_events.rpy:669
translate spanish gg_intro_7b39b9b5:

    # Sonya "Мы с Маей живём здесь вместе"
    Sonya "Maya y yo vivimos aquí juntas"

# game/characters_events_idles/mc_events.rpy:671
translate spanish gg_intro_c3003883:

    # Sonya "Линда сначала просто сдавала нам комнаты"
    Sonya "Al principio, Linda simplemente nos alquilaba habitaciones"

# game/characters_events_idles/mc_events.rpy:673
translate spanish gg_intro_eb14c7b5:

    # Sonya "А потом, когда уехала, сказала, что дом остаётся на нас"
    Sonya "Y luego, cuando se fue, dijo que la casa quedaba a nuestro cuidado"

# game/characters_events_idles/mc_events.rpy:675
translate spanish gg_intro_6dcfd261:

    # gg "То есть вы тут уже давно?"
    gg "¿Entonces lleváis aquí mucho tiempo?"

# game/characters_events_idles/mc_events.rpy:677
translate spanish gg_intro_c8772e87:

    # Sonya "Да"
    Sonya "Sí"

# game/characters_events_idles/mc_events.rpy:679
translate spanish gg_intro_5e85de7c:

    # Sonya "Мы привыкли. Даже кота завели"
    Sonya "Estamos acostumbradas. Incluso tenemos un gato"

# game/characters_events_idles/mc_events.rpy:681
translate spanish gg_intro_0879bf60:

    # Sonya "Для нас это уже дом"
    Sonya "Este ya es nuestro hogar"

# game/characters_events_idles/mc_events.rpy:683
translate spanish gg_intro_dad9ef91:

    # Sonya "Линда иногда о тебе говорила"
    Sonya "Linda a veces hablaba de ti"

# game/characters_events_idles/mc_events.rpy:685
translate spanish gg_intro_a3493fdc:

    # Sonya "Говорила, что ты хороший, по крайнее мерее в дестве"
    Sonya "Decía que eras bueno, al menos de niño"

# game/characters_events_idles/mc_events.rpy:687
translate spanish gg_intro_0782f2e3:

    # gg "Надеюсь, она не слишком приукрашивала"
    gg "Espero que no lo haya embellecido demasiado"

# game/characters_events_idles/mc_events.rpy:689
translate spanish gg_intro_3e3d596e:

    # gg "Сейчас я сам не знаю, кем стал"
    gg "Ahora no sé en quién me he convertido"

# game/characters_events_idles/mc_events.rpy:691
translate spanish gg_intro_b8032679:

    # Sonya "А ты . . ."
    Sonya "Y tú..."

# game/characters_events_idles/mc_events.rpy:693
translate spanish gg_intro_7ad63786:

    # Sonya "Ты надолго?"
    Sonya "¿Te quedarás mucho tiempo?"

# game/characters_events_idles/mc_events.rpy:695
translate spanish gg_intro_c2f6d189:

    # Sonya "Ну какой у тебя дальше план?"
    Sonya "Entonces, ¿qué planes tienes?"

# game/characters_events_idles/mc_events.rpy:697
translate spanish gg_intro_9f30eca5:

    # gg "Я пока не знаю"
    gg "Todavía no lo sé"

# game/characters_events_idles/mc_events.rpy:699
translate spanish gg_intro_51f05bc9:

    # gg "Мне нужно время"
    gg "Necesito tiempo"

# game/characters_events_idles/mc_events.rpy:701
translate spanish gg_intro_301f9bbb:

    # gg_chat "Хотя здесь приятно"
    gg_chat "Aunque aquí es agradable"

# game/characters_events_idles/mc_events.rpy:704
translate spanish gg_intro_a1c2b87a:

    # gg_chat "И как-то спокойно"
    gg_chat "Y de algún modo tranquilo"

# game/characters_events_idles/mc_events.rpy:706
translate spanish gg_intro_1043df55:

    # Sonya "Уже поздно"
    Sonya "Ya es tarde"

# game/characters_events_idles/mc_events.rpy:708
translate spanish gg_intro_f1483558:

    # Sonya "Мы можем поговорить ещё потом"
    Sonya "Podemos hablar más tarde"

# game/characters_events_idles/mc_events.rpy:710
translate spanish gg_intro_701fa6da:

    # Sonya "Ты можешь лечь в зале"
    Sonya "Puedes dormir en la sala"

# game/characters_events_idles/mc_events.rpy:712
translate spanish gg_intro_7adf858b:

    # Sonya "Других мест спальных у нас нету"
    Sonya "No tenemos otros lugares para dormir"

# game/characters_events_idles/mc_events.rpy:714
translate spanish gg_intro_e6ef238c:

    # gg "Да хорошо"
    gg "Sí, está bien"

# game/characters_events_idles/mc_events.rpy:716
translate spanish gg_intro_18a3c2d6:

    # gg "Спасибо за теплый прием"
    gg "Gracias por la cálida bienvenida"

# game/characters_events_idles/mc_events.rpy:718
translate spanish gg_intro_2857877c:

    # Sonya "Я положу все необходимое на диван"
    Sonya "Pondré todo lo que necesitas en el sofá"

# game/characters_events_idles/mc_events.rpy:720
translate spanish gg_intro_f96b8f09:

    # gg_chat "Похоже, пока я могу здесь остаться"
    gg_chat "Parece que puedo quedarme aquí por ahora"

# game/characters_events_idles/mc_events.rpy:724
translate spanish gg_intro_19e97f44:

    # gg_chat "Я так устал за этот день"
    gg_chat "Estoy muy cansado después de este día"

# game/characters_events_idles/mc_events.rpy:725
translate spanish gg_intro_6f0f1d5a:

    # gg_chat "Пора отдыхать"
    gg_chat "Es hora de descansar"

# game/characters_events_idles/mc_events.rpy:737
translate spanish gg_first_morning_8051fd9f:

    # gg_chat "Утро"
    gg_chat "Mañana"

# game/characters_events_idles/mc_events.rpy:739
translate spanish gg_first_morning_c535b2eb:

    # gg_chat "Давно я так не просыпался"
    gg_chat "Hacía mucho que no me despertaba así"

# game/characters_events_idles/mc_events.rpy:741
translate spanish gg_first_morning_654f0c17:

    # gg_chat "Никакой работы"
    gg_chat "Sin trabajo"

# game/characters_events_idles/mc_events.rpy:743
translate spanish gg_first_morning_81883fea:

    # gg_chat "Никакого давления"
    gg_chat "Sin presión"

# game/characters_events_idles/mc_events.rpy:745
translate spanish gg_first_morning_90c39e25:

    # gg_chat "Природа"
    gg_chat "Naturaleza"

# game/characters_events_idles/mc_events.rpy:747
translate spanish gg_first_morning_dbabb2ca:

    # gg_chat "Здесь я свободен"
    gg_chat "Aquí soy libre"

# game/characters_events_idles/mc_events.rpy:749
translate spanish gg_first_morning_663fb966:

    # gg_chat "В городе я жил как белка в колесе"
    gg_chat "En la ciudad viví como una ardilla en una rueda"

# game/characters_events_idles/mc_events.rpy:751
translate spanish gg_first_morning_bb031547:

    # gg_chat "Не жизнь, а выживание"
    gg_chat "No era vida, sino supervivencia"

# game/characters_events_idles/mc_events.rpy:753
translate spanish gg_first_morning_49963596:

    # gg_chat "Мне не хватало этого в городе"
    gg_chat "Me faltaba esto en la ciudad"

# game/characters_events_idles/mc_events.rpy:754
translate spanish gg_first_morning_0af076a7:

    # gg_chat "Кажется я останусь"
    gg_chat "Creo que me quedaré"

# game/characters_events_idles/mc_events.rpy:756
translate spanish gg_first_morning_82a7ff6e:

    # gg_chat "Дорогой бабушке . . ."
    gg_chat "Querida abuela..."

# game/characters_events_idles/mc_events.rpy:757
translate spanish gg_first_morning_4f068f55:

    # gg_chat "Спасибо похоже, я нашёл то, чего мне не хватало"
    gg_chat "Gracias, parece que encontré lo que me faltaba"

# game/characters_events_idles/mc_events.rpy:759
translate spanish gg_first_morning_88a92574:

    # gg_chat "Моя жизнь меняется"
    gg_chat "Mi vida está cambiando"

# game/characters_events_idles/mc_events.rpy:761
translate spanish gg_first_morning_d67d6049:

    # gg_chat "Посмотрим, что из этого выйдет"
    gg_chat "A ver qué sale de esto"

# game/characters_events_idles/mc_events.rpy:780
translate spanish gg_first_morning_kitchen_b418e893:

    # gg_chat "Можно просто сидеть"
    gg_chat "Se puede simplemente sentarse"

# game/characters_events_idles/mc_events.rpy:781
translate spanish gg_first_morning_kitchen_820306b2:

    # gg_chat "Никуда не спешить"
    gg_chat "Sin prisa a ningún lado"

# game/characters_events_idles/mc_events.rpy:787
translate spanish gg_first_morning_kitchen_47966b2a:

    # gg_chat "Обычно меня раздражает мытье посуды. А тут даже приятно"
    gg_chat "Suele irritarme lavar los platos. Pero aquí incluso es agradable"

# game/characters_events_idles/mc_events.rpy:789
translate spanish gg_first_morning_kitchen_2119fa08:

    # gg_chat "Нужно будет всё здесь изучить"
    gg_chat "Tendré que estudiar todo aquí"

# game/characters_events_idles/mc_events.rpy:791
translate spanish gg_first_morning_kitchen_52906127:

    # gg_chat "Хочу понять, как здесь живут"
    gg_chat "Quiero entender cómo viven aquí"

# game/characters_events_idles/mc_events.rpy:792
translate spanish gg_first_morning_kitchen_1b6b16db:

    # gg_chat "Как всё устроено"
    gg_chat "Cómo funciona todo"

# game/characters_events_idles/mc_events.rpy:795
translate spanish gg_first_morning_kitchen_681dfe7b:

    # gg_chat "Это теперь мой новый дом"
    gg_chat "Este es ahora mi nuevo hogar"

# game/characters_events_idles/mc_events.rpy:810
translate spanish gg_first_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "¡Oh!"

# game/characters_events_idles/mc_events.rpy:812
translate spanish gg_first_day_bathroom_7b463844:

    # Sonya "Прости, я не думала, что ты сейчас зайдешь"
    Sonya "Lo siento, no pensé que entrarías ahora"

# game/characters_events_idles/mc_events.rpy:813
translate spanish gg_first_day_bathroom_32835352:

    # Sonya "Я хотела прибраться"
    Sonya "Quería limpiar un poco"

# game/characters_events_idles/mc_events.rpy:817
translate spanish gg_first_day_bathroom_826d81cb:

    # Sonya "Я не мешаю тебе?"
    Sonya "¿Te estoy molestando?"

# game/characters_events_idles/mc_events.rpy:819
translate spanish gg_first_day_bathroom_c012b14a:

    # Sonya "Я сейчас закончу"
    Sonya "Ahora termino"

# game/characters_events_idles/mc_events.rpy:821
translate spanish gg_first_day_bathroom_1c4c4c5a:

    # gg "Нет, всё нормально"
    gg "No, está bien"

# game/characters_events_idles/mc_events.rpy:822
translate spanish gg_first_day_bathroom_bf898b26:

    # gg "Я подожду"
    gg "Esperaré"

# game/characters_events_idles/mc_events.rpy:824
translate spanish gg_first_day_bathroom_1452bdd4:

    # gg "Если тебе нужна помощь — скажи"
    gg "Si necesitas ayuda, solo dilo"

# game/characters_events_idles/mc_events.rpy:826
translate spanish gg_first_day_bathroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "¿De verdad?"

# game/characters_events_idles/mc_events.rpy:828
translate spanish gg_first_day_bathroom_6e75581c:

    # Sonya "Ты не обязан, я просто"
    Sonya "No tienes por qué, yo solo..."

# game/characters_events_idles/mc_events.rpy:830
translate spanish gg_first_day_bathroom_bad9a3a7:

    # Sonya "Ну, если тебе не сложно"
    Sonya "Bueno, si no te es molestia"

# game/characters_events_idles/mc_events.rpy:832
translate spanish gg_first_day_bathroom_506ec94d:

    # Sonya "Можешь тогда разложить вещи для стирки"
    Sonya "Entonces puedes separar la ropa para lavar"

# game/characters_events_idles/mc_events.rpy:834
translate spanish gg_first_day_bathroom_1b360134:

    # Sonya "Потом сложи что уже высохло"
    Sonya "Luego dobla la que ya esté seca"

# game/characters_events_idles/mc_events.rpy:836
translate spanish gg_first_day_bathroom_cc2e9c27:

    # Sonya "Отнесу я сама"
    Sonya "Yo misma la llevaré"

# game/characters_events_idles/mc_events.rpy:856
translate spanish gg_first_day_bathroom_fb297fd7:

    # gg_chat "Как будто мы тут давно живём"
    gg_chat "Es como si lleváramos viviendo aquí mucho tiempo"

# game/characters_events_idles/mc_events.rpy:858
translate spanish gg_first_day_bathroom_adfa1b84:

    # Sonya "Мне чуть чуть осталось"
    Sonya "Me queda un poquito"

# game/characters_events_idles/mc_events.rpy:860
translate spanish gg_first_day_bathroom_dc9b9999:

    # Sonya "Обычно в доме только я убираюсь"
    Sonya "Normalmente soy la única que limpia la casa"

# game/characters_events_idles/mc_events.rpy:864
translate spanish gg_first_day_bathroom_09b9d111:

    # Sonya "А . . ."
    Sonya "Ah..."

# game/characters_events_idles/mc_events.rpy:865
translate spanish gg_first_day_bathroom_a741acc1:

    # Sonya "Ты наверное хочешь в душ"
    Sonya "Probablemente quieras ducharte"

# game/characters_events_idles/mc_events.rpy:869
translate spanish gg_first_day_bathroom_9f7316a6:

    # Sonya "Полотенца сейчас у меня в комнате"
    Sonya "Las toallas están ahora en mi habitación"

# game/characters_events_idles/mc_events.rpy:871
translate spanish gg_first_day_bathroom_352fa084:

    # Sonya "Мы можем сходить туда, если хочешь"
    Sonya "Podemos ir allí si quieres"

# game/characters_events_idles/mc_events.rpy:873
translate spanish gg_first_day_bathroom_264ee174:

    # gg "Пойдем"
    gg "Vamos"

# game/characters_events_idles/mc_events.rpy:879
translate spanish gg_first_day_bathroom_a3853f22:

    # gg_chat "Как сильно поменялись комнаты"
    gg_chat "Cómo han cambiado las habitaciones"

# game/characters_events_idles/mc_events.rpy:883
translate spanish gg_first_day_bathroom_1d2f5a17:

    # Sonya "Вот"
    Sonya "Aquí"

# game/characters_events_idles/mc_events.rpy:885
translate spanish gg_first_day_bathroom_33def544:

    # Sonya "Если что, там ещё есть"
    Sonya "Por si acaso, hay más"

# game/characters_events_idles/mc_events.rpy:887
translate spanish gg_first_day_bathroom_5c20aef6:

    # Sonya "Э ну приятного купания"
    Sonya "Eh, bueno, que disfrutes el baño"

# game/characters_events_idles/mc_events.rpy:889
translate spanish gg_first_day_bathroom_3eec94f5:

    # gg "А да спасибо"
    gg "Ah, sí, gracias"

# game/characters_events_idles/mc_events.rpy:892
translate spanish gg_first_day_bathroom_b774dd45:

    # gg_chat "Оказывается, для уюта нужно совсем немного"
    gg_chat "Resulta que para la comodidad se necesita muy poco"

# game/characters_events_idles/mc_events.rpy:905
translate spanish gg_first_morning_mayaroom_ff197092:

    # Maya "Барси!"
    Maya "¡Barsi!"

# game/characters_events_idles/mc_events.rpy:907
translate spanish gg_first_morning_mayaroom_de472ed4:

    # Maya "Барсик!"
    Maya "¡Barsik!"

# game/characters_events_idles/mc_events.rpy:910
translate spanish gg_first_morning_mayaroom_a4a7667e:

    # gg_chat "Что-то случилось?"
    gg_chat "¿Pasó algo?"

# game/characters_events_idles/mc_events.rpy:914
translate spanish gg_first_morning_mayaroom_6f63b0d7:

    # gg_chat "Лучше ей не мешать . . ."
    gg_chat "Mejor no molestarla..."

# game/characters_events_idles/mc_events.rpy:920
translate spanish gg_first_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "Alto"

# game/characters_events_idles/mc_events.rpy:922
translate spanish gg_first_morning_mayaroom_857efa08:

    # Maya "Ты кота не видел?"
    Maya "¿No has visto al gato?"

# game/characters_events_idles/mc_events.rpy:924
translate spanish gg_first_morning_mayaroom_270e2f8c:

    # gg "Нет"
    gg "No"

# game/characters_events_idles/mc_events.rpy:926
translate spanish gg_first_morning_mayaroom_def6171d:

    # gg "Но могу помочь"
    gg "Pero puedo ayudar"

# game/characters_events_idles/mc_events.rpy:928
translate spanish gg_first_morning_mayaroom_359a75af:

    # Maya "Твоя помощь мне не нужна"
    Maya "No necesito tu ayuda"

# game/characters_events_idles/mc_events.rpy:930
translate spanish gg_first_morning_mayaroom_785a8355:

    # Maya "Хотя если будешь молчать — помогай"
    Maya "Aunque si vas a estar callado, ayuda"

# game/characters_events_idles/mc_events.rpy:932
translate spanish gg_first_morning_mayaroom_929a1d4f:

    # gg_chat "Это так на помощь соглашаются"
    gg_chat "Así es como aceptan ayuda"

# game/characters_events_idles/mc_events.rpy:937
translate spanish gg_first_morning_mayaroom_bb6b3842:

    # Maya "Ты где барсииик"
    Maya "¿Dónde estás, Barsiiik?"

# game/characters_events_idles/mc_events.rpy:946
translate spanish gg_first_morning_mayaroom_32a24542:

    # gg_chat "Нашёлся"
    gg_chat "Encontrado"

# game/characters_events_idles/mc_events.rpy:950
translate spanish gg_first_morning_mayaroom_954eaf61:

    # gg_chat "Главное не разбудить"
    gg_chat "Lo principal es no despertarlo"

# game/characters_events_idles/mc_events.rpy:952
translate spanish gg_first_morning_mayaroom_79aa0dff:

    # Maya "Всё хорошо"
    Maya "Todo está bien"

# game/characters_events_idles/mc_events.rpy:954
translate spanish gg_first_morning_mayaroom_831f5c17:

    # Maya "Я здесь барсик"
    Maya "Estoy aquí, Barsik"

# game/characters_events_idles/mc_events.rpy:958
translate spanish gg_first_morning_mayaroom_f0949f54:

    # Maya "Ты меня напугал"
    Maya "Me asustaste"

# game/characters_events_idles/mc_events.rpy:959
translate spanish gg_first_morning_mayaroom_a8d4beb2:

    # Maya "Глупый"
    Maya "Tonto"

# game/characters_events_idles/mc_events.rpy:962
translate spanish gg_first_morning_mayaroom_ddc18c67:

    # gg_chat "Она не совсем такая, какой кажется"
    gg_chat "Ella no es exactamente lo que parece"

# game/characters_events_idles/mc_events.rpy:974
translate spanish kate_day_kitchen_60e92ce9:

    # Kate "Так, где у вас тут кофе прячут?"
    Kate "A ver, ¿dónde esconden el café aquí?"

# game/characters_events_idles/mc_events.rpy:975
translate spanish kate_day_kitchen_077e1944:

    # gg "Ты кто вообще?"
    gg "¿Y tú quién eres?"

# game/characters_events_idles/mc_events.rpy:977
translate spanish kate_day_kitchen_67f355f0:

    # Kate "О Привет"
    Kate "Oh, hola"

# game/characters_events_idles/mc_events.rpy:980
translate spanish kate_day_kitchen_d81632e3:

    # Kate "Я Кейт"
    Kate "Soy Kate"

# game/characters_events_idles/mc_events.rpy:982
translate spanish kate_day_kitchen_1e97df81:

    # Kate "Не пугайся, я не вор"
    Kate "No te asustes, no soy una ladrona"

# game/characters_events_idles/mc_events.rpy:983
translate spanish kate_day_kitchen_b0950cd9:

    # Kate "Просто кофе мне жизненно необходим"
    Kate "Es solo que el café me es vital"

# game/characters_events_idles/mc_events.rpy:985
translate spanish kate_day_kitchen_e063e635:

    # gg "Меня [povname] зовут"
    gg "Me llamo [povname]"

# game/characters_events_idles/mc_events.rpy:986
translate spanish kate_day_kitchen_f0d355f9:

    # gg "Растворимый прям тут"
    gg "El soluble está justo aquí"

# game/characters_events_idles/mc_events.rpy:988
translate spanish kate_day_kitchen_f2fdab56:

    # Kate "О, спаситель!"
    Kate "¡Oh, salvador!"

# game/characters_events_idles/mc_events.rpy:990
translate spanish kate_day_kitchen_fe62b24d:

    # Kate "Значит, ты и есть тот самый парень, который тут появился недавно?"
    Kate "Entonces, ¿eres ese chico que apareció aquí hace poco?"

# game/characters_events_idles/mc_events.rpy:992
translate spanish kate_day_kitchen_ce5edae1:

    # gg "Судя по слухам — да, я"
    gg "Según los rumores, sí, soy yo"

# game/characters_events_idles/mc_events.rpy:994
translate spanish kate_day_kitchen_0d1fc413:

    # Kate "Мая рассказывала"
    Kate "Maya me contó"

# game/characters_events_idles/mc_events.rpy:996
translate spanish kate_day_kitchen_7c8bce00:

    # Kate "Живёт с Соней давно, а потом появился ты"
    Kate "Lleva viviendo con Sonya mucho tiempo, y luego apareciste tú"

# game/characters_events_idles/mc_events.rpy:997
translate spanish kate_day_kitchen_34985df3:

    # Kate "Интересная компания"
    Kate "Un grupo interesante"

# game/characters_events_idles/mc_events.rpy:999
translate spanish kate_day_kitchen_2e63aac8:

    # gg "“Интересная” — мягко сказано"
    gg "\"Interesante\" es decirlo suavemente"

# game/characters_events_idles/mc_events.rpy:1001
translate spanish kate_day_kitchen_cbdc207c:

    # Kate "Серьёзно? Это растворимый?"
    Kate "¿En serio? ¿Es soluble?"

# game/characters_events_idles/mc_events.rpy:1003
translate spanish kate_day_kitchen_8937f276:

    # gg "Ага"
    gg "Sí"

# game/characters_events_idles/mc_events.rpy:1005
translate spanish kate_day_kitchen_5746fae5:

    # Kate "А ведь вкусно"
    Kate "Pero está rico"

# game/characters_events_idles/mc_events.rpy:1006
translate spanish kate_day_kitchen_796538ef:

    # Kate "Обычно от растворимого хочется заплакать"
    Kate "Normalmente el soluble da ganas de llorar"

# game/characters_events_idles/mc_events.rpy:1008
translate spanish kate_day_kitchen_3e92b413:

    # gg "Значит, я талантливый бариста"
    gg "Entonces soy un barista con talento"

# game/characters_events_idles/mc_events.rpy:1009
translate spanish kate_day_kitchen_961ab98b:

    # Kate "Или тебе повезло"
    Kate "O tienes suerte"

# game/characters_events_idles/mc_events.rpy:1011
translate spanish kate_day_kitchen_394c86a9:

    # Kate "Ну что, рассказывай, кто ты такой"
    Kate "Bueno, cuéntame, ¿quién eres?"

# game/characters_events_idles/mc_events.rpy:1013
translate spanish kate_day_kitchen_517a6831:

    # gg "Обычно начинают с “как дела?”"
    gg "Normalmente empiezan con \"¿cómo estás?\""

# game/characters_events_idles/mc_events.rpy:1015
translate spanish kate_day_kitchen_bb3d7bf1:

    # Kate "Это скучно"
    Kate "Eso es aburrido"

# game/characters_events_idles/mc_events.rpy:1017
translate spanish kate_day_kitchen_01155acc:

    # Kate "Я сразу к сути. Ты кто: сосед, ухажёр, постоялец или просто [povname]"
    Kate "Voy al grano. ¿Quién eres? ¿Vecino, pretendiente, huésped o simplemente [povname]?"

# game/characters_events_idles/mc_events.rpy:1019
translate spanish kate_day_kitchen_4333516e:

    # gg "Пусть будет просто [povname]"
    gg "Que sea simplemente [povname]"

# game/characters_events_idles/mc_events.rpy:1021
translate spanish kate_day_kitchen_95199003:

    # Kate "Значит, загадочный. Ладно, оставим интригу"
    Kate "Así que misterioso. Vale, mantengamos la intriga"

# game/characters_events_idles/mc_events.rpy:1024
translate spanish kate_day_kitchen_eb2b6424:

    # Kate "Тут уютно"
    Kate "Es acogedor aquí"

# game/characters_events_idles/mc_events.rpy:1025
translate spanish kate_day_kitchen_ad0e7b9c:

    # Kate "Не думала, что Мая вообще когда-то научится жить без хаоса"
    Kate "Nunca pensé que Maya llegaría a aprender a vivir sin caos"

# game/characters_events_idles/mc_events.rpy:1029
translate spanish kate_day_kitchen_1e4f23c6:

    # Maya "Кейт! Ты тут"
    Maya "¡Kate! Estás aquí"

# game/characters_events_idles/mc_events.rpy:1030
translate spanish kate_day_kitchen_ecdba904:

    # Maya "Я же сказала подожди меня!"
    Maya "¡Te dije que me esperaras!"

# game/characters_events_idles/mc_events.rpy:1032
translate spanish kate_day_kitchen_b6371751:

    # Maya "Ага, ты уже познакомилась с этим балбесом"
    Maya "Ajá, ya conociste a este tonto"

# game/characters_events_idles/mc_events.rpy:1034
translate spanish kate_day_kitchen_9c22616a:

    # Kate "Да! И кофе у него отличный, между прочим"
    Kate "¡Sí! Y su café es excelente, por cierto"

# game/characters_events_idles/mc_events.rpy:1036
translate spanish kate_day_kitchen_08bc7129:

    # Maya "Хвалить не вздумай, зазнается. Нам пора"
    Maya "Ni se te ocurra alabarlo, se volverá presumido. Tenemos que irnos"

# game/characters_events_idles/mc_events.rpy:1038
translate spanish kate_day_kitchen_8ab29297:

    # Kate "Спасибо за кофе, бариста"
    Kate "Gracias por el café, barista"

# game/characters_events_idles/mc_events.rpy:1039
translate spanish kate_day_kitchen_11705c38:

    # Kate "Ладно. Ещё увидимся"
    Kate "Vale. Nos vemos"

translate spanish strings:

    # game/characters_events_idles/mc_events.rpy:361
    old "Послать нахуй"
    new "Que te jodan"

    # game/characters_events_idles/mc_events.rpy:363
    old "Молча уйти"
    new "Irme en silencio"

# TODO: Translation updated at 2026-01-26 03:23

# game/characters_events_idles/mc_events.rpy:295
translate spanish gg_intro_4402cfd9:

    # gg_chat "Я отвечу попозже, бабушка"
    gg_chat "Te responderé más tarde, abuela"

# game/characters_events_idles/mc_events.rpy:668
translate spanish gg_intro_0997da9e:

    # Maya "Это мы с Соней решим!"
    Maya "¡Eso lo decidiremos Sonya y yo!"

# game/characters_events_idles/mc_events.rpy:670
translate spanish gg_intro_6619e154:

    # Maya "{sc}{size=*1.5}СОНЯ{/sc}" with hpunch
    Maya "{sc}{size=*1.5}SONYA{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:805
translate spanish gg_intro_fadd240e:

    # "Ночью можно отдохнуть — нажми на кровать, чтобы начать новый день"
    "Por la noche puedes descansar: pulsa en la cama para empezar un nuevo día"

# game/characters_events_idles/mc_events.rpy:895
translate spanish gg_first_day_bathroom_6c8604ba:

    # Sonya "Я не думала, что ты сейчас зайдешь"
    Sonya "Lo siento, no pensé que entrarías ahora"

# game/characters_events_idles/mc_events.rpy:896
translate spanish gg_first_day_bathroom_15c3e23b:

    # Sonya "Хотела прибраться"
    Sonya "Quería limpiar un poco"

# game/characters_events_idles/mc_events.rpy:900
translate spanish gg_first_day_bathroom_94ef9943:

    # Sonya "Ты хотел в душ?"
    Sonya "¿Querías ducharte?"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/mc_events.rpy:287
translate spanish gg_intro_21dc756d:

    # gg_chat "Чёрт, я опаздываю"
    gg_chat "Mierda, llego tarde"

# game/characters_events_idles/mc_events.rpy:295
translate spanish gg_intro_01ac9e1d:

    # gg_chat "Я отвечу попозже, бабушка"
    gg_chat "Te responderé más tarde, abuela"

# game/characters_events_idles/mc_events.rpy:325
translate spanish gg_intro_d5122bca:

    # Assistant "И напомню: если продолжишь, {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "Y te recuerdo: si esto continúa, {w}hablar de una reducción de sueldo será solo cuestión de tiempo"

# game/characters_events_idles/mc_events.rpy:361
translate spanish gg_intro_4e8253d3:

    # gg_chat "Сколько ни работай, этому нет конца"
    gg_chat "Da igual cuánto trabajes, esto no tiene fin"

# game/characters_events_idles/mc_events.rpy:393
translate spanish gg_intro_eb3e3aa2:

    # gg_chat "Да пошло оно все"
    gg_chat "Que le den a todo"

# game/characters_events_idles/mc_events.rpy:409
translate spanish gg_intro_187f7fc4:

    # Director "Ты вообще что делаешь"
    Director "¿Qué estás haciendo?"

# game/characters_events_idles/mc_events.rpy:500
translate spanish gg_intro_bb6264b0:

    # gg_chat "Все, кого я вижу, со мной здороваются"
    gg_chat "Todos los que veo me saludan"

# game/characters_events_idles/mc_events.rpy:520
translate spanish gg_intro_2c4c4cb8:

    # UnknownGirl "Если что-то нужно будет, спрашивай помощь у любого"
    UnknownGirl "Si necesitas algo, pide ayuda a cualquiera"

# game/characters_events_idles/mc_events.rpy:524
translate spanish gg_intro_f654fdee:

    # gg "Хорошо и Вам отличного дня"
    gg "Muy bien, y que tenga un excelente día"

# game/characters_events_idles/mc_events.rpy:527
translate spanish gg_intro_87051a07:

    # gg_chat "Бабушка, похоже, говорила правду о людях здесь"
    gg_chat "Parece que la abuela decía la verdad sobre la gente de aquí"

# game/characters_events_idles/mc_events.rpy:546
translate spanish gg_intro_95240a3b:

    # gg_chat "Да, дом поменялся"
    gg_chat "Sí, la casa ha cambiado"

# game/characters_events_idles/mc_events.rpy:556
translate spanish gg_intro_e94b0047:

    # gg_chat "Здесь кто-то есть?"
    gg_chat "¿Hay alguien aquí?"

# game/characters_events_idles/mc_events.rpy:596
translate spanish gg_intro_eee07a35:

    # gg "Стой, подожди"
    gg "Espera, espera"

# game/characters_events_idles/mc_events.rpy:604
translate spanish gg_intro_ca7cead7:

    # Maya "Что-то я такого внука никогда здесь не видела"
    Maya "Nunca he visto un nieto así aquí"

# game/characters_events_idles/mc_events.rpy:650
translate spanish gg_intro_f08474d4:

    # Maya "Мои цветочки любимые. Они остались"
    Maya "Mis florecitas favoritas. Se quedan"

# game/characters_events_idles/mc_events.rpy:659
translate spanish gg_intro_90f291ff:

    # Maya "Боже, ладно"
    Maya "Dios, vale"

# game/characters_events_idles/mc_events.rpy:660
translate spanish gg_intro_7b0b2a04:

    # Maya "Похоже на правду"
    Maya "Parece verdad"

# game/characters_events_idles/mc_events.rpy:676
translate spanish gg_intro_1b04d04b:

    # Maya "Слушай, если ты хоть что-то сделаешь"
    Maya "Escucha, si haces algo,"

# game/characters_events_idles/mc_events.rpy:734
translate spanish gg_intro_5834166b:

    # Sonya "Нет-нет, всё нормально"
    Sonya "No, no, todo está bien"

# game/characters_events_idles/mc_events.rpy:740
translate spanish gg_intro_05ceb2ee:

    # Sonya "Я прочла письмо Линды"
    Sonya "Leí la carta de Linda"

# game/characters_events_idles/mc_events.rpy:744
translate spanish gg_intro_c73d3bb7:

    # Sonya "Она всегда нас так называла"
    Sonya "Ella siempre nos llamaba así"

# game/characters_events_idles/mc_events.rpy:760
translate spanish gg_intro_d2363caa:

    # Sonya "Это место для нас стало родным"
    Sonya "Este lugar se ha vuelto nuestro hogar"

# game/characters_events_idles/mc_events.rpy:764
translate spanish gg_intro_79c61e5f:

    # Sonya "Говорила, что ты хороший, по крайней мере в детстве"
    Sonya "Decía que eras bueno, al menos de niño"

# game/characters_events_idles/mc_events.rpy:774
translate spanish gg_intro_7f8fcf55:

    # Sonya "Ну, какой у тебя дальше план?"
    Sonya "Bueno, ¿cuáles son tus planes ahora?"

# game/characters_events_idles/mc_events.rpy:787
translate spanish gg_intro_d7903980:

    # Sonya "Если захочешь мы еще поговорим"
    Sonya "Si quieres, hablaremos más tarde"

# game/characters_events_idles/mc_events.rpy:789
translate spanish gg_intro_7d278239:

    # Sonya "А пока ты можешь лечь в зале"
    Sonya "Mientras tanto, puedes acostarte en la sala"

# game/characters_events_idles/mc_events.rpy:793
translate spanish gg_intro_41b7f3b0:

    # gg "Да, хорошо"
    gg "Sí, está bien"

# game/characters_events_idles/mc_events.rpy:835
translate spanish gg_first_morning_5b301338:

    # gg_chat "Эх, как же мне не хватало свободы"
    gg_chat "Ay, cómo echaba de menos la libertad"

# game/characters_events_idles/mc_events.rpy:836
translate spanish gg_first_morning_146ca63e:

    # gg_chat "Кажется, я останусь"
    gg_chat "Creo que me quedaré"

# game/characters_events_idles/mc_events.rpy:839
translate spanish gg_first_morning_9cc6e0e8:

    # gg_chat "Спасибо, похоже, я нашёл то, чего мне не хватало"
    gg_chat "Gracias, parece que encontré lo que me faltaba"

# game/characters_events_idles/mc_events.rpy:917
translate spanish gg_first_day_bathroom_c3b33eb8:

    # Sonya "Потом сложи, что уже высохло"
    Sonya "Luego dobla lo que ya esté seco"

# game/characters_events_idles/mc_events.rpy:970
translate spanish gg_first_day_bathroom_887d1e72:

    # Sonya "Ээ... нуу приятного купания"
    Sonya "Eh... pues, que disfrutes el baño"

# game/characters_events_idles/mc_events.rpy:972
translate spanish gg_first_day_bathroom_997383a9:

    # gg "А, да, спасибо"
    gg "Ah, sí, gracias"

# game/characters_events_idles/mc_events.rpy:1018
translate spanish gg_first_morning_mayaroom_123ee93a:

    # Maya "Хотя, если будешь молчать — помогай"
    Maya "Aunque si vas a estar callado, ayuda"

