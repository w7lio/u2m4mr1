﻿# TODO: Translation updated at 2026-01-21 13:15

# game/core/kinetic_text_tags.rpy:1
translate french 6c0c3176:

    # "Kinetic Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    "Balises de texte cinétiques Module Ren'Py 2021 Daniel Westfall <SoDaRa2595@gmail.com>"

# game/core/kinetic_text_tags.rpy:1
translate french 8689f4cd:

    # "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"
    "http://twitter.com/sodara9 J'apprécierais qu'on me fasse crédit si vous finissez par l'utiliser ! :D Ça me ferait vraiment plaisir de savoir que j'ai aidé certaines personnes ! J'espère vraiment que cela pourra aider la communauté à créer des moyens vraiment intéressants de pimenter leur dialogue ! http://opensource.org/licenses/mit-license.php Github : https://github.com/SoDaRa/Kinetic-Text-Tags itch.io : https://wattson.itch.io/kinetic-text-tags Message sur le forum : https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"

