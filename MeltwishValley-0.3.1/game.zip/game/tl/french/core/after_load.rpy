﻿# TODO: Translation updated at 2026-01-21 13:15

translate french strings:

    # game/core/after_load.rpy:9
    old "Спокойный и наблюдательный, он приехал в посёлок, чтобы сбежать от прошлого и найти себя заново. Не всегда уверен, но с каждым новым знакомством делает шаг ближе к тому, кем хочет стать"
    new "Calme et observateur, il est venu au village pour échapper au passé et se retrouver. Pas toujours sûr, mais à chaque nouvelle connaissance, il se rapproche de celui qu'il veut devenir."

    # game/core/after_load.rpy:9
    old "Союзник"
    new "Allié"

    # game/core/after_load.rpy:9
    old "Вс."
    new "Dim"

    # game/core/after_load.rpy:9
    old "Кухня"
    new "Cuisine"

    # game/core/after_load.rpy:9
    old "Утро Кухня"
    new "Cuisine Matinée"

    # game/core/after_load.rpy:9
    old "Ждем тебя в следующем патче"
    new "Nous vous attendons dans le prochain patch"

    # game/core/after_load.rpy:9
    old "Вы прошли все сюжетные события этого персонажа в текущем патче"
    new "Vous avez terminé tous les événements de l'histoire pour ce personnage dans le patch actuel."

    # game/core/after_load.rpy:9
    old "Мая"
    new "Maya"

    # game/core/after_load.rpy:9
    old "Дерзкая, ироничная и ленивая, кажется отстранённой, но чувствует глубже, чем показывает. Скрывает мягкость за сарказмом, пока не решит открыть себя по-настоящему. Не терпит слабости — особенно в себе"
    new "Impétueuse, ironique et paresseuse, elle semble distante, mais elle se sent plus profondément qu'elle ne le montre. Cache la douceur derrière le sarcasme jusqu'à ce qu'il décide de vraiment se révéler. Ne tolère pas la faiblesse - surtout en lui-même"

    # game/core/after_load.rpy:9
    old "Вт."
    new "Mar"

    # game/core/after_load.rpy:9
    old "Ср."
    new "Mer"

    # game/core/after_load.rpy:9
    old "Вечер"
    new "Soir"

    # game/core/after_load.rpy:9
    old "Зал"
    new "Salle"

    # game/core/after_load.rpy:9
    old "Вечер Зал"
    new "Salle Soirée"

    # game/core/after_load.rpy:9
    old "Пт."
    new "Ven"

    # game/core/after_load.rpy:9
    old "Сб."
    new "Sam"

    # game/core/after_load.rpy:9
    old "День"
    new "Jour"

    # game/core/after_load.rpy:9
    old "Ее комната"
    new "Sa chambre"

    # game/core/after_load.rpy:9
    old "День Ее комната"
    new "Jour Sa chambre"

    # game/core/after_load.rpy:9
    old "Пн."
    new "Lun"

    # game/core/after_load.rpy:9
    old "Чт."
    new "Jeu"

    # game/core/after_load.rpy:9
    old "Вечер кухня"
    new "Cuisine Soirée"

    # game/core/after_load.rpy:9
    old "День ее комната"
    new "Le Jour dans sa chambre"

    # game/core/after_load.rpy:9
    old "Ночь"
    new "Nuit"

    # game/core/after_load.rpy:9
    old "Ночь ее комната"
    new "Sa chambre (nuit)"

    # game/core/after_load.rpy:9
    old "Вечер зал"
    new "Salon Soirée"

    # game/core/after_load.rpy:9
    old "Утро ее комната"
    new "Sa chambre Matinée"

    # game/core/after_load.rpy:9
    old "День кухня"
    new "Cuisine Journée"

    # game/core/after_load.rpy:9
    old "Ванная"
    new "Salle de bain"

    # game/core/after_load.rpy:9
    old "Утро ванная"
    new "Salle de bain Matinée"

    # game/core/after_load.rpy:9
    old "Соня"
    new "Sonya"

    # game/core/after_load.rpy:9
    old "Тёплая и заботливая, но собранная и точная, как часы. Любит музыку, игры и порядок, иногда стесняется — но именно она делает шаг первой"
    new "Chaleureux et attentionné, mais recueilli et précis, comme une horloge. Elle aime la musique, les jeux et l'ordre, parfois elle est timide - mais c'est elle qui fait le premier pas"

    # game/core/after_load.rpy:9
    old "День Ванная"
    new "Salle de bain Journée"

    # game/core/after_load.rpy:9
    old "Утро Ванная"
    new "Salle de bain Matinée"

    # game/core/after_load.rpy:9
    old "Стоит подождать"
    new "Ça vaut le coup d'attendre"

    # game/core/after_load.rpy:9
    old "Думаю стоит подождать"
    new "je pense que ça vaut la peine d'attendre"

    # game/core/after_load.rpy:9
    old "Вечер Ее комната"
    new "Sa chambre Soirée"

    # game/core/after_load.rpy:9
    old "Кейт"
    new "Kate"

    # game/core/after_load.rpy:9
    old "Яркая и энергичная, Кейт не умеет сидеть на месте — она живёт движением и смехом. Кажется лёгкой и беззаботной, но за её улыбкой прячется страх остаться одной"
    new "Lumineuse et énergique, Kate ne sait pas rester assise - elle vit de mouvement et de rire. Elle semble légère et insouciante, mais derrière son sourire se cache la peur d'être seule"

    # game/core/after_load.rpy:9
    old "Утро Зал"
    new "Salon Matinée"

# TODO: Translation updated at 2026-01-26 03:22

# game/core/after_load.rpy:4
translate french after_load_f281aeec:

    # "Привет. Игра потерпела большой реворк, получила новое интро и сцены"
    "Bonjour. Le jeu a subi une refonte majeure, a reçu une nouvelle intro et de nouvelles scènes"

# game/core/after_load.rpy:5
translate french after_load_92feb703:

    # "Старые сейвы работать не будут(("
    "Les anciennes sauvegardes ne fonctionneront pas (("

# game/core/after_load.rpy:6
translate french after_load_dc6483bb:

    # "Пожалуйста начните игру заново"
    "Veuillez recommencer le jeu"

# TODO: Translation updated at 2026-01-27 02:10

# game/core/after_load.rpy:4
translate french after_load_75a05417:

    # "Привет. Игра претерпела большие изменения, получила новое интро и сцены"
    "Bonjour. Le jeu a subi de gros changements, a reçu une nouvelle intro et de nouvelles scènes"

# game/core/after_load.rpy:6
translate french after_load_c7ff0b32:

    # "Пожалуйста, начните игру заново"
    "Veuillez recommencer le jeu"

# TODO: Translation updated at 2026-01-27 22:55

translate french strings:

    # game/core/after_load.rpy:13
    old "День Зал"
    new "Journée du matin"

