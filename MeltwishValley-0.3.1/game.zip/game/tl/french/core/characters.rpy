﻿# TODO: Translation updated at 2026-01-21 13:15

translate french strings:

    # game/core/characters.rpy:28
    old "Почтальон"
    new "Facteur"

    # game/core/characters.rpy:32
    old "Секретарь"
    new "Secrétaire"

    # game/core/characters.rpy:36
    old "Директор"
    new "Directeur"

    # game/core/characters.rpy:40
    old "Незнакомая девушка"
    new "Fille étrangère"

# TODO: Translation updated at 2026-01-26 03:22

translate french strings:

    # game/core/characters.rpy:40
    old "Незнакомка"
    new "Étranger"

