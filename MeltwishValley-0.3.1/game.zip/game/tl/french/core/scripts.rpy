﻿# TODO: Translation updated at 2026-01-21 13:15

# game/core/scripts.rpy:52
translate french next_time_button_9cf59ffc:

    # "Пора спать"
    "Il est temps de dormir"

# game/core/scripts.rpy:97
translate french sleep_until_morning_caa36b56:

    # "Думаю еще не время ложиться спать"
    "Je ne pense pas qu'il soit encore temps d'aller au lit"

