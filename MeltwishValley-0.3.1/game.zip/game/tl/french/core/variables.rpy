﻿# TODO: Translation updated at 2026-01-21 13:15

translate french strings:

    # game/core/variables.rpy:88
    old "Понедельник"
    new "Lundi"

    # game/core/variables.rpy:88
    old "Вторник"
    new "Mardi"

    # game/core/variables.rpy:88
    old "Среда"
    new "Mercredi"

    # game/core/variables.rpy:88
    old "Четверг"
    new "Jeudi"

    # game/core/variables.rpy:88
    old "Пятница"
    new "Vendredi"

    # game/core/variables.rpy:88
    old "Суббота"
    new "Samedi"

    # game/core/variables.rpy:88
    old "Воскресенье"
    new "Dimanche"

    # game/core/variables.rpy:121
    old "Моя комната"
    new "Ma chambre"

# TODO: Translation updated at 2026-02-13 11:40

translate french strings:

    # game/core/variables.rpy:422
    old "Ночь Зал"
    new "Salle de Nuit"

# TODO: Translation updated at 2026-02-16 03:29

translate french strings:

    # game/core/variables.rpy:427
    old "Комната Сони"
    new "Chambre de Sonya"

# game/core/variables.rpy:427
    old "Утро комната Сони"
    new "Matin, chambre de Sonya"

# game/core/variables.rpy:427
    old "День зал"
    new "Salle du jour"

