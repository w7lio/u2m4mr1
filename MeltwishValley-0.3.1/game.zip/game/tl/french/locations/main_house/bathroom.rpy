﻿# TODO: Translation updated at 2026-01-21 13:15

# game/locations/main_house/bathroom.rpy:18
translate french bathroom_3da38f85:

    # gg "Я думаю я не так сильно знаком с Маей"
    ### Don't appear
    gg "Je suppose que je ne connais pas beaucoup Maya"

# game/locations/main_house/bathroom.rpy:23
translate french bathroom_1dae98de:

    # gg "Я думаю я не так сильно знаком с Соней"
    ### Don't appear
    gg "Je suppose que je ne connais pas beaucoup Sonya"

# TODO: Translation updated at 2026-01-26 03:22

# game/locations/main_house/bathroom.rpy:19
translate french bathroom_8df379f4:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Маей"
    gg "Je suppose que je ne connais pas encore assez bien Maya"

# game/locations/main_house/bathroom.rpy:25
translate french bathroom_675eb9d2:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Соней"
    gg "Je suppose que je ne connais pas encore assez bien Sonya"

