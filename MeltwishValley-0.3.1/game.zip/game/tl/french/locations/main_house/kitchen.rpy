﻿# TODO: Translation updated at 2026-01-21 13:15

# game/locations/main_house/kitchen.rpy:24
translate french kitchen_e44eab80:

    # "Привет, перед началом игры давай быстро разберемся с управлением"
    "Bonjour, avant de commencer le jeu, comprenons rapidement les commandes"

# game/locations/main_house/kitchen.rpy:25
translate french kitchen_e9ff8856:

    # "Что бы перейти в другую комнату тебе нужно навестись мышкой в правую часть экрана"
    "Pour aller dans une autre pièce, vous devez pointer votre souris sur le côté droit de l'écran"

# game/locations/main_house/kitchen.rpy:28
translate french kitchen_22e95808:

    # "После выбери комнату в которую хочешь попасть"
    "Sélectionnez ensuite la pièce dans laquelle vous souhaitez vous rendre"

# game/locations/main_house/kitchen.rpy:29
translate french kitchen_c3e67100:

    # "На иконках комнат будут отображены девушки которые сейчас там находятся"
    "Les icônes de la salle afficheront les filles qui s'y trouvent actuellement"

# game/locations/main_house/kitchen.rpy:30
translate french kitchen_ffc31834:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой ключевое действие"
    "Une {color=#fffb27ff}étoile{/color} apparaîtra à côté de l'icône si une action clé est effectuée avec la fille."

# game/locations/main_house/kitchen.rpy:31
translate french kitchen_4c3bfaea:

    # "Попробуйте перейти в комнату Маи"
    "Essayez d'aller dans la chambre de Maya"

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/kitchen.rpy:30
translate french kitchen_b2963125:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой доступно ключевое действие"
    "Une {color=#fffb27ff}étoile{/color} apparaîtra à côté de l'icône si une action clé est disponible avec la fille."

# game/locations/main_house/kitchen.rpy:31
translate french kitchen_b1f7eb9e:

    # "Попробуй перейти в комнату Маи"
    "Essayez d'aller dans la chambre de Mai"

