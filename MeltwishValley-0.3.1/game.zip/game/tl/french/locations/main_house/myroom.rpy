﻿# TODO: Translation updated at 2026-01-21 13:15

# game/locations/main_house/myroom.rpy:22
translate french myroom_c1835e38:

    # "Что бы лечь спать нажмите ночью на кровать"
    "Pour aller au lit, appuyez sur le lit la nuit"

# game/locations/main_house/myroom.rpy:27
translate french myroom_edb2c466:

    # "Теперь вы можешь управлять временем суток"
    "Vous pouvez désormais contrôler l'heure de la journée"

# game/locations/main_house/myroom.rpy:28
translate french myroom_1cd5975b:

    # "Нажмите на значок в правом верхнем углу, чтобы изменить время"
    "Cliquez sur l'icône dans le coin supérieur droit pour modifier l'heure"

# game/locations/main_house/myroom.rpy:30
translate french myroom_2f1c23a7:

    # "В левом нижнем углу отображаются текущее время суток, день недели и счётчик дней"
    "L'heure actuelle, le jour de la semaine et le compteur journalier sont affichés dans le coin inférieur gauche."

# game/locations/main_house/myroom.rpy:33
translate french myroom_4dcc1b35:

    # "Теперь вам доступна книга персонажей"
    "Le livre de personnages est désormais disponible pour vous"

# game/locations/main_house/myroom.rpy:36
translate french myroom_f5a7354e:

    # "В ней вы можете посмотреть описание каждой девушки и текущий уровень отношений"
    "Vous pouvez y voir une description de chaque fille et le niveau actuel de la relation."

# game/locations/main_house/myroom.rpy:37
translate french myroom_b927df5c:

    # "Здесь же доступны подсказки к следующему событию и возможность закрепить активный квест"
    "Des astuces pour le prochain événement et la possibilité d'épingler une quête active sont également disponibles ici."

# TODO: Translation updated at 2026-01-26 03:22

# game/locations/main_house/myroom.rpy:27
translate french myroom_71fb3107:

    # "Теперь вы можете управлять временем суток"
    "Vous pouvez désormais contrôler l'heure de la journée"

# game/locations/main_house/myroom.rpy:28
translate french myroom_a6aee4e7:

    # "Нажмите на значок в правом верхнем углу, чтобы сменить время"
    "Cliquez sur l'icône dans le coin supérieur droit pour modifier l'heure"

# game/locations/main_house/myroom.rpy:33
translate french myroom_b9554520:

    # "Также вам доступна книга персонажей"
    "Un livre de personnages est également à votre disposition"

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/myroom.rpy:27
translate french myroom_ac4e4f25:

    # "Теперь ты можешь управлять временем суток"
    "Vous pouvez désormais contrôler l'heure de la journée"

# game/locations/main_house/myroom.rpy:28
translate french myroom_6784fea3:

    # "Нажми на значок в правом верхнем углу, чтобы сменить время"
    "Cliquez sur l'icône dans le coin supérieur droit pour changer l'heure"

# game/locations/main_house/myroom.rpy:33
translate french myroom_b3480ee4:

    # "Также тебе доступна книга персонажей"
    "Un livre de personnages est également à votre disposition"

# game/locations/main_house/myroom.rpy:36
translate french myroom_030a80cc:

    # "В ней ты можешь посмотреть описание каждой девушки и текущий уровень отношений"
    "Vous pouvez y voir une description de chaque fille et le niveau actuel de la relation."

