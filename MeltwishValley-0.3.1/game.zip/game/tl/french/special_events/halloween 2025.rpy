﻿# TODO: Translation updated at 2026-01-21 13:15

# game/special_events/halloween 2025.rpy:30
translate french halloween_prestart_6dc15a83_1:

    # gg "Хм . . ."
    gg "Hum. . ."

# game/special_events/halloween 2025.rpy:31
translate french halloween_prestart_3173d374_1:

    # gg "А что это еще такое?"
    gg "Qu'est-ce que c'est d'autre ?"

# game/special_events/halloween 2025.rpy:32
translate french halloween_prestart_9d6bd7cd_1:

    # gg "Эта тыква будто манит меня дотронуться до нее"
    gg "Cette citrouille semble m'inviter à la toucher."

# game/special_events/halloween 2025.rpy:34
translate french halloween_prestart_6b235c12_1:

    # gg "Вроде ничего не случилось"
    gg "On dirait que rien ne s'est passé"

# game/special_events/halloween 2025.rpy:35
translate french halloween_prestart_99b702cc_1:

    # gg "Просто обычная тыква"
    gg "Juste une citrouille ordinaire"

# game/special_events/halloween 2025.rpy:36
translate french halloween_prestart_882ef6af_1:

    # gg "Так не интересно"
    gg "Donc pas intéressant"

# game/special_events/halloween 2025.rpy:40
translate french halloween_prestart_2eb26325_1:

    # gg "Ай!" with hpunch
    gg "Aïe !" with hpunch

# game/special_events/halloween 2025.rpy:41
translate french halloween_prestart_b858f49b_1:

    # gg "Почему так щипет"
    gg "Pourquoi ça pique autant ?"

# game/special_events/halloween 2025.rpy:42
translate french halloween_prestart_eb8d9b68_1:

    # gg "Что то мне не хорошо"
    gg "Quelque chose ne va pas pour moi"

# game/special_events/halloween 2025.rpy:43
translate french halloween_prestart_462beaf3_1:

    # gg "Пойду отдохну"
    gg "je vais aller me reposer"

# game/special_events/halloween 2025.rpy:55
translate french halloween_start_941a30ef_1:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/special_events/halloween 2025.rpy:57
translate french halloween_start_2768572c_1:

    # Sonya "Знаешь, что я поняла?"
    Sonya "Sais-tu ce que j'ai réalisé ?"

# game/special_events/halloween 2025.rpy:58
translate french halloween_start_b99b94d3_1:

    # gg "Что пора поспать?"
    gg "Est-il temps de dormir ?"

# game/special_events/halloween 2025.rpy:60
translate french halloween_start_73751dc8_1:

    # Sonya "Что пора украшать дом"
    Sonya "Il est temps de décorer la maison"

# game/special_events/halloween 2025.rpy:62
translate french halloween_start_2efbd354_1:

    # gg "Украшать?"
    gg "Décorer ?"

# game/special_events/halloween 2025.rpy:64
translate french halloween_start_baa9dc02_1:

    # Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    Sonya "On a Halloween dans 2 jours, mais l'ambiance est nulle"

# game/special_events/halloween 2025.rpy:66
translate french halloween_start_d64dca0a_1:

    # Sonya "Я хочу, чтобы всё выглядело"
    Sonya "Je veux que tout y ressemble"

# game/special_events/halloween 2025.rpy:68
translate french halloween_start_c1524153_1:

    # Sonya "Хотя бы немного празднично"
    Sonya "Au moins un peu festif"

# game/special_events/halloween 2025.rpy:70
translate french halloween_start_c4c69fc7_1:

    # Maya "Украшать?{w} Пора бы да"
    Maya "Décorer ?{w} Il était temps"

# game/special_events/halloween 2025.rpy:72
translate french halloween_start_f5a85bf6_1:

    # Maya "Можно повесить гирлянды и поставить свечи!"
    Maya "Tu peux accrocher des guirlandes et allumer des bougies !"

# game/special_events/halloween 2025.rpy:74
translate french halloween_start_88ab11a7_1:

    # Sonya "Вот. Поддержка есть"
    Sonya "Ici. Il y a du soutien"

# game/special_events/halloween 2025.rpy:76
translate french halloween_start_f2b19d78_1:

    # gg "Видимо у меня нет выбора"
    gg "Apparemment, je n'ai pas le choix"

# game/special_events/halloween 2025.rpy:78
translate french halloween_start_bc7a61df_1:

    # Maya "Ты просто устал, тебе нужно отвлечься"
    Maya "Tu es juste fatigué, tu as besoin d'une distraction"

# game/special_events/halloween 2025.rpy:80
translate french halloween_start_06d0d58b_1:

    # Sonya "Вот именно"
    Sonya "C'est ça"

# game/special_events/halloween 2025.rpy:82
translate french halloween_start_041234b8_1:

    # Sonya "Украшение дома - лучший антистресс"
    Sonya "La décoration de la maison est le meilleur anti-stress"

# game/special_events/halloween 2025.rpy:84
translate french halloween_start_c578bb24_1:

    # Maya "Тогда решено"
    Maya "Alors c'est décidé"

# game/special_events/halloween 2025.rpy:85
translate french halloween_start_6e15e900_1:

    # Maya "Начнём с гостиной"
    Maya "Commençons par le salon"

# game/special_events/halloween 2025.rpy:87
translate french halloween_start_d298f1fa_1:

    # Maya "Я за уют, но без перебора"
    Maya "Je suis pour le confort, mais sans exagérer"

# game/special_events/halloween 2025.rpy:89
translate french halloween_start_2a522c28_1:

    # Sonya "Надо позвать Кейт"
    Sonya "Nous devons appeler Kate"

# game/special_events/halloween 2025.rpy:90
translate french halloween_start_20197ce8_1:

    # Sonya "Без неё всё равно не обойдётся"
    Sonya "Ça ne marchera toujours pas sans elle"

# game/special_events/halloween 2025.rpy:92
translate french halloween_start_bcecc811_1:

    # Maya "Я напишу ей"
    Maya "je vais lui écrire"

# game/special_events/halloween 2025.rpy:93
translate french halloween_start_81baf5ad_1:

    # Maya "Если не занята, придёт"
    Maya "Si elle n'est pas occupée, elle viendra"

# game/special_events/halloween 2025.rpy:95
translate french halloween_start_4a4b3e1e_1:

    # Sonya "Пойдем поможешь мне"
    Sonya "Viens m'aider"

# game/special_events/halloween 2025.rpy:97
translate french halloween_start_082fbdc3_1:

    # Sonya "У нас в кладовке чего только нету"
    Sonya "Nous avons tout dans notre garde-manger"

# game/special_events/halloween 2025.rpy:99
translate french halloween_start_569f8605_1:

    # Sonya "Осторожно, она тяжёлая"
    Sonya "Attention, c'est lourd"

# game/special_events/halloween 2025.rpy:103
translate french halloween_start_08a41431_1:

    # gg "Не волнуйся, я пока справляюсь"
    gg "Ne t'inquiète pas, je me débrouille pour l'instant"

# game/special_events/halloween 2025.rpy:105
translate french halloween_start_2ee9b67e_1:

    # Maya "Написала, сказала, что уже бежит"
    Maya "Elle a écrit et dit qu'elle courait déjà"

# game/special_events/halloween 2025.rpy:107
translate french halloween_start_56e25c3d_1:

    # Sonya "Это хорошо"
    Sonya "C'est bien"

# game/special_events/halloween 2025.rpy:109
translate french halloween_start_cc205380_1:

    # Maya "О, смотри, старая паутина!"
    Maya "Oh regarde, une vieille toile d'araignée !"

# game/special_events/halloween 2025.rpy:111
translate french halloween_start_6d122aa8_1:

    # Sonya "Это не декор, не трогай!"
    Sonya "Ce n’est pas de la décoration, n’y touches pas !"

# game/special_events/halloween 2025.rpy:113
translate french halloween_start_1c832081_1:

    # Maya "Ты же знаешь я боюсь пауков!"
    Maya "Tu sais que j'ai peur des araignées !"

# game/special_events/halloween 2025.rpy:114
translate french halloween_start_e8c9fd97_1:

    # gg "Ха ха"
    gg "Ha ha"

# game/special_events/halloween 2025.rpy:119
translate french halloween_start_5c8cb7fa_1:

    # Kate "Я пришла"
    Kate "Je suis là"

# game/special_events/halloween 2025.rpy:120
translate french halloween_start_5cba982d_1:

    # Kate "Где вы, мои маленькие смертные?"
    Kate "Où êtes-vous, mes petits mortels ?"

# game/special_events/halloween 2025.rpy:121
translate french halloween_start_66671892_1:

    # Maya "Привет!"
    Maya "Bonjour!"

# game/special_events/halloween 2025.rpy:123
translate french halloween_start_41cac97b_1:

    # Kate "О, вы уже начали без меня?{w} Это предательство"
    Kate "Oh, as-tu déjà commencé sans moi ?{w} C'est une trahison"

# game/special_events/halloween 2025.rpy:125
translate french halloween_start_3f833e29_1:

    # Maya "Мы только подготовились"
    Maya "Nous nous préparons juste"

# game/special_events/halloween 2025.rpy:127
translate french halloween_start_10a24600_1:

    # Sonya "Отлично, теперь можем начинать по-настоящему"
    Sonya "Super, maintenant nous pouvons commencer pour de vrai"

# game/special_events/halloween 2025.rpy:129
translate french halloween_start_59716300_1:

    # Maya "Всё, распределяем задачи?"
    Maya "Ça y est, répartissons les tâches ?"

# game/special_events/halloween 2025.rpy:131
translate french halloween_start_c6287aa3_1:

    # Kate "Так эту куклу повесим вон там, над теликом"
    Kate "Alors accrochons cette poupée là-bas, au-dessus de la télé."

# game/special_events/halloween 2025.rpy:132
translate french halloween_start_ddd8aded_1:

    # Kate "Еще нужны паутины, гирлянда из флажков, черепа . . ."
    Kate "Nous avons également besoin de toiles d'araignées, d'une guirlande de drapeaux et de crânes. . ."

# game/special_events/halloween 2025.rpy:134
translate french halloween_start_c1c2f306_1:

    # Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    Maya "Alors on peut se passer de décorations effrayantes dans ma chambre ?"

# game/special_events/halloween 2025.rpy:136
translate french halloween_start_344d78c3_1:

    # gg "Ну это же Хэллоуин, а чем ты?"
    gg "Eh bien, c'est Halloween, qu'est-ce que tu fais ?"

# game/special_events/halloween 2025.rpy:138
translate french halloween_start_7e9f8506_1:

    # Sonya "Мая просто трусишка"
    Sonya "Maya est juste une lâche"

# game/special_events/halloween 2025.rpy:140
translate french halloween_start_423eeb13_1:

    # Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "HÉ!! Je pense juste que c'est stupide !"

# game/special_events/halloween 2025.rpy:141
translate french halloween_start_1c4935b1_1:

    # Maya "Можно сделать дом тёплым, как осень!"
    Maya "Vous pouvez rendre votre maison chaleureuse comme l’automne !"

# game/special_events/halloween 2025.rpy:142
translate french halloween_start_5acb8aac_1:

    # Maya "Листья и природу . . . И без жути . . ."
    Maya "Feuilles et nature. . . Et sans horreur. . ."

# game/special_events/halloween 2025.rpy:144
translate french halloween_start_9d95e4f7_1:

    # Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    Kate "Et je veux que ce soit si grave que les enfants du voisin crient de peur s'ils osent frapper à notre porte"

# game/special_events/halloween 2025.rpy:146
translate french halloween_start_97fa9b09_1:

    # Sonya "Звучит как цель"
    Sonya "Cela ressemble à un objectif"

# game/special_events/halloween 2025.rpy:148
translate french halloween_start_7a0152d7_1:

    # Maya "Надеюсь, что все пройдет без происшествий"
    Maya "J'espère que tout se passera sans incident"

# game/special_events/halloween 2025.rpy:150
translate french halloween_start_cd410fe4_1:

    # gg "Ну что же, давайте постараемся"
    gg "Eh bien, essayons"

# game/special_events/halloween 2025.rpy:158
translate french halloween_start_e7148dd7_1:

    # Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    Maya "Tu sais, c'est pas si mal, c'est même très sympa et douillet"

# game/special_events/halloween 2025.rpy:160
translate french halloween_start_4203fcb3_1:

    # Kate "ДА! Вышло супер, мы такие молодцы"
    Kate "OUI! Ça s'est bien passé, nous sommes tellement géniaux"

# game/special_events/halloween 2025.rpy:162
translate french halloween_start_3c177eb8_1:

    # Sonya "Давайте дальше украсим кухню!"
    Sonya "Décorons ensuite la cuisine !"

# game/special_events/halloween 2025.rpy:163
translate french halloween_start_3fc97c96_1:

    # Sonya "[povname] хватай коробки с украшениями!"
    Sonya "[povname] récupérez les boîtes de décoration !"

# game/special_events/halloween 2025.rpy:172
translate french halloween_start_c18a0daf_1:

    # Maya "Ну почему я должна ее вешать?"
    Maya "Pourquoi devrais-je le raccrocher ?"

# game/special_events/halloween 2025.rpy:174
translate french halloween_start_538416e3_1:

    # Kate "Потому что ты самая высокая, это же логично!"
    Kate "Parce que tu es le plus grand, c’est logique !"

# game/special_events/halloween 2025.rpy:176
translate french halloween_start_fac78089_1:

    # Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    Maya "Eww. Je n'ai pas peur des araignées, elles sont tellement méchantes qu'elles me rendent malade"

# game/special_events/halloween 2025.rpy:178
translate french halloween_start_196b4d6a_1:

    # gg "Тыкву тоже поставь на полку"
    gg "Mettez aussi la citrouille sur l'étagère"

# game/special_events/halloween 2025.rpy:187
translate french halloween_start_3ee05b57_1:

    # Maya "АААААААААА!" with hpunch
    Maya "AAAAAAAAAAAAAAAAAA !" with hpunch

# game/special_events/halloween 2025.rpy:191
translate french halloween_start_7410244b_1:

    # gg "Все, я убрал, не бойся, он же не настоящий"
    gg "Ça y est, je l'ai enlevé, n'aie pas peur, il n'est pas réel"

# game/special_events/halloween 2025.rpy:193
translate french halloween_start_1ceba70d_1:

    # Maya "Спасибо"
    Maya "Merci"

# game/special_events/halloween 2025.rpy:195
translate french halloween_start_5375f0ad_1:

    # gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    gg "Trop souvent, tu tombes dans mes bras, mais n’est-ce pas quelque chose que tu fais exprès ?"

# game/special_events/halloween 2025.rpy:197
translate french halloween_start_ccd7999c_1:

    # Maya "Еще чего!"
    Maya "Quoi d'autre!"

# game/special_events/halloween 2025.rpy:198
translate french halloween_start_c938832e_1:

    # Maya "Ты просто мешаешься на пути, вот и все!"
    Maya "Vous ne faites que gêner, c'est tout !"

# game/special_events/halloween 2025.rpy:199
translate french halloween_start_5807bf69_1:

    # Kate "Не поранились? Голубки"
    Kate "N'es-tu pas blessé ? Ma colombe"

# game/special_events/halloween 2025.rpy:201
translate french halloween_start_180bf5f1_1:

    # Maya "Все с паутиной мы закончили"
    Maya "Nous en avons fini avec le Web"

# game/special_events/halloween 2025.rpy:202
translate french halloween_start_62eaed17_1:

    # Maya "Пойду возьму яблочного сидра"
    Maya "Je vais chercher du cidre de pomme"

# game/special_events/halloween 2025.rpy:208
translate french halloween_start_6a9d122d_1:

    # Sonya "Еще 5 минут и кексы готовы"
    Sonya "Encore 5 minutes et les cupcakes sont prêts"

# game/special_events/halloween 2025.rpy:210
translate french halloween_start_92462f90_1:

    # Kate "Пахнет потрясающе"
    Kate "Ça sent incroyable"

# game/special_events/halloween 2025.rpy:212
translate french halloween_start_ada25b4b_1:

    # Maya "Всё, теперь осталось только подождать"
    Maya "Voilà, il ne vous reste plus qu'à attendre"

# game/special_events/halloween 2025.rpy:213
translate french halloween_start_4ac68531_1:

    # Maya "Потом будем украшать"
    Maya "Ensuite nous décorerons"

# game/special_events/halloween 2025.rpy:215
translate french halloween_start_7d203e0d_1:

    # Kate "Эй а кем вы будете в ночь Хэллоуина?"
    Kate "Hé, qui seras-tu le soir d'Halloween ?"

# game/special_events/halloween 2025.rpy:217
translate french halloween_start_3e0fd7f3_1:

    # Sonya "Я уже думала об этом!"
    Sonya "J'y ai déjà pensé !"

# game/special_events/halloween 2025.rpy:218
translate french halloween_start_21be6b25_1:

    # Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    Sonya "Mm, Kate, un costume de démone te conviendrait"

# game/special_events/halloween 2025.rpy:220
translate french halloween_start_8fc9e335_1:

    # Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    Maya "Au fait, oui, même si tu ressembles à un ange, tu es aussi rusé qu'un brownie"

# game/special_events/halloween 2025.rpy:222
translate french halloween_start_6485ec70_1:

    # Kate "Эй!! Неплохая идея"
    Kate "Hé!! Cest pas une mauvaise idée"

# game/special_events/halloween 2025.rpy:226
translate french halloween_start_9ea771a0_1:

    # Kate "Королева демонов Уахахахаха!"
    Kate "Reine Démon Wahahahaha !"

# game/special_events/halloween 2025.rpy:227
translate french halloween_start_dfa5392d_1:

    # Kate "Все должны пасть к моим ногам!"
    Kate "Tout le monde doit tomber à mes pieds !"

# game/special_events/halloween 2025.rpy:229
translate french halloween_start_d1a70744_1:

    # Sonya "Все, ей больше не наливать!"
    Sonya "Ça y est, ne la versez plus !"

# game/special_events/halloween 2025.rpy:231
translate french halloween_start_67a78ead_1:

    # gg "Не знал что Кейт так быстро выносит с алкоголя"
    gg "Je ne savais pas que Kate se remettait si vite de l'alcool"

# game/special_events/halloween 2025.rpy:233
translate french halloween_start_89e99062_1:

    # Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    Maya "Je voudrais un costume de sorcière ou une sorte de dryade magique. . ."

# game/special_events/halloween 2025.rpy:235
translate french halloween_start_ccfee06e_1:

    # Kate "Думаю тебе пойдет"
    Kate "je pense que ça te conviendra"

# game/special_events/halloween 2025.rpy:237
translate french halloween_start_8e96eaa2_1:

    # Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    Sonya "Et l'autre jour j'ai commandé au lieu de 1 paquet de bandages, jusqu'à 6, on dirait que c'est un signe pour faire un costume de maman ?"

# game/special_events/halloween 2025.rpy:239
translate french halloween_start_2aa5e0fb_1:

    # Maya "Ты как раз самая старшая"
    Maya "Tu es juste le plus vieux"

# game/special_events/halloween 2025.rpy:241
translate french halloween_start_38bc2712_1:

    # Sonya "Ах ты!"
    Sonya "Ah toi !"

# game/special_events/halloween 2025.rpy:243
translate french halloween_start_5d38e441_1:

    # Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "Attends, et le blaireau ? Il a aussi besoin d'un costume !"

# game/special_events/halloween 2025.rpy:244
translate french halloween_start_fb608953_1:

    # Maya "Например дракончика или мистер тыковка . . ."
    Maya "Par exemple, petit dragon ou M. Citrouille. . ."

# game/special_events/halloween 2025.rpy:246
translate french halloween_start_7fd69d94_1:

    # Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    Sonya "Essayez de l'attraper et de l'habiller, M. Barsik n'y arrivera pas !"

# game/special_events/halloween 2025.rpy:248
translate french halloween_start_70adb582_1:

    # Maya "Что ты . . . {w}Он любит переодевашки"
    Maya "Qu'est-ce que tu. . . {w}Il adore se déguiser"

# game/special_events/halloween 2025.rpy:251
translate french halloween_start_c0036cba_1:

    # Sonya "Вот и кексы готовы"
    Sonya "Maintenant les cupcakes sont prêts"

# game/special_events/halloween 2025.rpy:253
translate french halloween_start_ae45c746_1:

    # gg "С кухней готово, что дальше?"
    gg "La cuisine est prête, et ensuite ?"

# game/special_events/halloween 2025.rpy:254
translate french halloween_start_354f0704_1:

    # Sonya "Предлагаю разделиться"
    Sonya "Je suggère que nous nous séparions"

# game/special_events/halloween 2025.rpy:255
translate french halloween_start_07a07420_1:

    # Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "Maya et moi allons décorer nos chambres, Kate, veux-tu décorer le bain"

# game/special_events/halloween 2025.rpy:256
translate french halloween_start_4e86ac78_1:

    # Sonya "[povname], будешь помогать нам?"
    Sonya "[povname], pouvez-vous nous aider ?"

# game/special_events/halloween 2025.rpy:257
translate french halloween_start_564e6225_1:

    # gg "Окей"
    gg "D'ACCORD"

# game/special_events/halloween 2025.rpy:271
translate french halloween_prepare_mayaroom_7afc2c47_1:

    # gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "Vous avez ici le repaire d'une sorcière qui prépare des potions à partir d'herbes"

# game/special_events/halloween 2025.rpy:272
translate french halloween_prepare_mayaroom_63c64e7b_1:

    # gg "Мм. . . пахнет приятно"
    gg "Mm. . . ça sent bon"

# game/special_events/halloween 2025.rpy:274
translate french halloween_prepare_mayaroom_1ca099b7_1:

    # Maya "Хватит нюхать женскую комнату!"
    Maya "Arrêtez de renifler les toilettes des dames !"

# game/special_events/halloween 2025.rpy:276
translate french halloween_prepare_mayaroom_eded9518_1:

    # Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "Vous n'êtes là que pour exécuter mes ordres."

# game/special_events/halloween 2025.rpy:277
translate french halloween_prepare_mayaroom_799aa249_1:

    # Maya "Поставь эти тыквы в тот угол!"
    Maya "Mettez ces citrouilles dans ce coin !"

# game/special_events/halloween 2025.rpy:279
translate french halloween_prepare_mayaroom_292858b8_1:

    # gg "А где пожалуйста?"
    gg "Où s'il vous plaît ?"

# game/special_events/halloween 2025.rpy:281
translate french halloween_prepare_mayaroom_ad71fbb0_1:

    # Maya "Пожалуйста, не беси меня"
    Maya "S'il te plaît, ne m'énerve pas"

# game/special_events/halloween 2025.rpy:283
translate french halloween_prepare_mayaroom_63b60e81_1:

    # gg "Ох"
    gg "Oh"

# game/special_events/halloween 2025.rpy:285
translate french halloween_prepare_mayaroom_977c102e_1:

    # Maya "Мм. . . нет!"
    Maya "Mm. . . Non!"

# game/special_events/halloween 2025.rpy:287
translate french halloween_prepare_mayaroom_9cb8ca98_1:

    # Maya "Выглядит недостаточно хорошо!"
    Maya "Ça n'a pas l'air assez bien !"

# game/special_events/halloween 2025.rpy:289
translate french halloween_prepare_mayaroom_3b7bbda5_1:

    # Maya "Давай лучше в тот угол!"
    Maya "Allons dans ce coin-là !"

# game/special_events/halloween 2025.rpy:291
translate french halloween_prepare_mayaroom_f714e642_1:

    # gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    gg "Décidons d'abord où exactement, pour que je ne porte pas ces citrouilles cent fois"

# game/special_events/halloween 2025.rpy:293
translate french halloween_prepare_mayaroom_a2933c08_1:

    # Maya "Говорю же туда неси!"
    Maya "Je vous le dis, emmenez-le là-bas !"

# game/special_events/halloween 2025.rpy:295
translate french halloween_prepare_mayaroom_4c580716_1:

    # gg "Точно?"
    gg "Exactement?"

# game/special_events/halloween 2025.rpy:296
translate french halloween_prepare_mayaroom_fccb4de7_1:

    # gg "Я больше двигать не буду, подумай хорошо"
    gg "Je ne bougerai plus, réfléchis bien"

# game/special_events/halloween 2025.rpy:298
translate french halloween_prepare_mayaroom_4aa933c6_1:

    # Maya "Хотя как сейчас тоже неплохо . . ."
    Maya "Même si, dans l’état actuel des choses, ce n’est pas mal non plus. . ."

# game/special_events/halloween 2025.rpy:300
translate french halloween_prepare_mayaroom_b2b57087_1:

    # Maya "Все ты свободен!"
    Maya "Vous êtes tous libres !"

# game/special_events/halloween 2025.rpy:302
translate french halloween_prepare_mayaroom_04c6c53d_1:

    # gg "Спасибо"
    gg "Merci"

# game/special_events/halloween 2025.rpy:303
translate french halloween_prepare_mayaroom_dad56d9b_1:

    # Maya "Если что еще позову"
    Maya "Si quoi que ce soit d'autre, j'appellerai"

# game/special_events/halloween 2025.rpy:305
translate french halloween_prepare_mayaroom_6a8ac153_1:

    # Maya "Все Давай, давай, живее!!"
    Maya "Tout le monde Allez, allez, allez !!"

# game/special_events/halloween 2025.rpy:321
translate french halloween_prepare_sonyaroom_b708d644_1:

    # Sonya "Ой" with hpunch
    Sonya "Oh" with hpunch

# game/special_events/halloween 2025.rpy:323
translate french halloween_prepare_sonyaroom_4b100306_1:

    # Sonya "Добро пожаловать в мою обитель!"
    Sonya "Bienvenue dans ma demeure !"

# game/special_events/halloween 2025.rpy:325
translate french halloween_prepare_sonyaroom_7fb491df_1:

    # gg "У тебя в стиле майнкрафта все, очень милая комната"
    gg "Tout est dans le style Minecraft, très belle pièce"

# game/special_events/halloween 2025.rpy:327
translate french halloween_prepare_sonyaroom_9dc8d94c_1:

    # Sonya "Да, у меня много игрушек осталось"
    Sonya "Oui, il me reste beaucoup de jouets"

# game/special_events/halloween 2025.rpy:328
translate french halloween_prepare_sonyaroom_1174b034_1:

    # gg "Чем то тебе помочь?"
    gg "Comment puis-je t'aider?"

# game/special_events/halloween 2025.rpy:330
translate french halloween_prepare_sonyaroom_36233e2b_1:

    # Sonya "О можешь пожалуйста разложить остальные блоки"
    Sonya "Oh, peux-tu s'il te plaît disposer le reste des blocs ?"

# game/special_events/halloween 2025.rpy:332
translate french halloween_prepare_sonyaroom_51e25d01_1:

    # gg "Хорошо давай"
    gg "Ok allez"

# game/special_events/halloween 2025.rpy:336
translate french halloween_prepare_sonyaroom_5b80a77c_1:

    # Sonya "Так это сюда"
    Sonya "Alors c'est ici"

# game/special_events/halloween 2025.rpy:342
translate french halloween_prepare_sonyaroom_5e22d509_1:

    # Sonya "О забыла я же еще кексов поставила"
    Sonya "Oh, j'oubliais, j'ai aussi sorti des cupcakes"

# game/special_events/halloween 2025.rpy:354
translate french halloween_prepare_bathroom_5d6a2459_1:

    # gg "Тук-Тук, к вам можно?"
    gg "Toc-Toc, puis-je venir à toi ?"

# game/special_events/halloween 2025.rpy:356
translate french halloween_prepare_bathroom_f77e9ebe_1:

    # Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "Oh, tu arrive juste à temps, j'étais sur le point de t'appeler, je veux accrocher un fantôme au-dessus de la salle de bain"

# game/special_events/halloween 2025.rpy:357
translate french halloween_prepare_bathroom_65af0236_1:

    # Kate "Но не достаю, вот"
    Kate "Mais je n'y arrive pas, le voici"

# game/special_events/halloween 2025.rpy:359
translate french halloween_prepare_bathroom_b38aeb93_1:

    # Kate "Вот, видишь?"
    Kate "Ici, vous voyez ?"

# game/special_events/halloween 2025.rpy:361
translate french halloween_prepare_bathroom_e0f0e638_1:

    # Kate "Хм . . . а если я встану на бортики ванной?"
    Kate "Hum. . . Et si je me tiens sur les côtés de la baignoire ?"

# game/special_events/halloween 2025.rpy:363
translate french halloween_prepare_bathroom_e11f6927_1:

    # gg "Стой, это не безопасно"
    gg "Attends, ce n'est pas sûr"

# game/special_events/halloween 2025.rpy:372
translate french halloween_prepare_bathroom_01550c8f_1:

    # Kate "ААй!" with hpunch
    Kate "Aay !" with hpunch

# game/special_events/halloween 2025.rpy:373
translate french halloween_prepare_bathroom_af26ae75_1:

    # Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    Kate "Oh, je suis trop ivre, c'est tellement bien que tu sois là, merci"

# game/special_events/halloween 2025.rpy:375
translate french halloween_prepare_bathroom_78e2854b_1:

    # gg "Я так испугался за тебя"
    gg "J'avais tellement peur pour toi"

# game/special_events/halloween 2025.rpy:376
translate french halloween_prepare_bathroom_766703c6_1:

    # gg "За тобой глаз, да глаз, будь аккуратнее"
    gg "Il y a un oeil sur toi, oui un oeil sur toi, fais attention"

# game/special_events/halloween 2025.rpy:378
translate french halloween_prepare_bathroom_ef29b55b_1:

    # Kate "Хорошо, я обещаю . . ."
    Kate "D'accord, je le promets. . ."

# game/special_events/halloween 2025.rpy:380
translate french halloween_prepare_bathroom_61bd7d2f_1:

    # Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    Kate "Peut-être que tu me laisseras déjà partir ? je n'y retournerai pas"

# game/special_events/halloween 2025.rpy:382
translate french halloween_prepare_bathroom_77a74e82_1:

    # gg "Ты такая легкая"
    gg "Tu es si léger"

# game/special_events/halloween 2025.rpy:384
translate french halloween_prepare_bathroom_a0e2f8bb_1:

    # Kate "Спасибо"
    Kate "Merci"

# game/special_events/halloween 2025.rpy:400
translate french halloween_prepare_myroom_5692ba1f_1:

    # gg "Эх устал я помогать всем девочкам, и так спать хотел"
    gg "Eh, j'en avais marre d'aider toutes les filles, et je voulais juste dormir"

# game/special_events/halloween 2025.rpy:402
translate french halloween_prepare_myroom_6e92de75_1:

    # gg "Думаю посплю часик"
    gg "Je pense que je vais dormir une heure"

# game/special_events/halloween 2025.rpy:420
translate french halloween_sonya_dream_8c6442c7_1:

    # gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "Je me réveille avec un bruit étrange, comme si quelqu'un avait passé un ongle sur du bois."

# game/special_events/halloween 2025.rpy:421
translate french halloween_sonya_dream_a05b8801_1:

    # gg_chat "Это на кухне?"
    gg_chat "Est-ce dans la cuisine ?"

# game/special_events/halloween 2025.rpy:423
translate french halloween_sonya_dream_514bb7b5_1:

    # gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "Je sors à la cuisine en me frottant les yeux."

# game/special_events/halloween 2025.rpy:424
translate french halloween_sonya_dream_045482c0_1:

    # gg_chat "На столе - что-то, чего там не было"
    gg_chat "Il y a quelque chose sur la table qui n'était pas là"

# game/special_events/halloween 2025.rpy:425
translate french halloween_sonya_dream_e953cb07_1:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg_chat "Boîte.{w} Bois sombre, coins recouverts de métal rouge sang"

# game/special_events/halloween 2025.rpy:426
translate french halloween_sonya_dream_76809b89_1:

    # gg "Что за чёрт . . ."
    gg "Que diable. . ."

# game/special_events/halloween 2025.rpy:427
translate french halloween_sonya_dream_b5f93453_1:

    # gg_chat "Она не выглядит новой"
    gg_chat "Elle n'a pas l'air neuve"

# game/special_events/halloween 2025.rpy:428
translate french halloween_sonya_dream_5ac4f621_1:

    # gg_chat "Скорее наоборот - как будто ей сотни лет"
    gg_chat "Bien au contraire - comme si elle avait des centaines d'années"

# game/special_events/halloween 2025.rpy:433
translate french halloween_sonya_dream_a96a7298_1:

    # gg "Просто кто-то оставил{w} Мая? Соня?"
    gg "Quelqu'un vient-il de quitter le {w} mai ? Sonya ?"

# game/special_events/halloween 2025.rpy:434
translate french halloween_sonya_dream_f60dffa6_1:

    # gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "C'est stupide, mais je touche toujours le couvercle"

# game/special_events/halloween 2025.rpy:435
translate french halloween_sonya_dream_7aa1f899_1:

    # gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    gg_chat "Chaleur.{w} Comme s'il y avait du cuir sous vos doigts, pas du bois"

# game/special_events/halloween 2025.rpy:438
translate french halloween_sonya_dream_d4c068d1_1:

    # gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg_chat "Il y a une pièce de monnaie à l'intérieur. Vieux, usé, un œil y a été arraché et les bords sont inégaux, comme si quelqu'un l'avait mâché."

# game/special_events/halloween 2025.rpy:439
translate french halloween_sonya_dream_891135f2_1:

    # gg "И всё? . . ."
    gg "C'est tout ? . . ."

# game/special_events/halloween 2025.rpy:441
translate french halloween_sonya_dream_5bbdc303_1:

    # gg "Ладно, пока возьму себе"
    gg "D'accord, je vais le prendre pour l'instant"

# game/special_events/halloween 2025.rpy:442
translate french halloween_sonya_dream_63ba62de_1:

    # gg_chat "Я поворачиваю её в пальцах"
    gg_chat "Je le tourne entre mes doigts"

# game/special_events/halloween 2025.rpy:443
translate french halloween_sonya_dream_60e7c398_1:

    # gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    gg_chat "Étrange lourdeur, comme si la pièce n'était pas faite de métal, mais de quelque chose de vivant"

# game/special_events/halloween 2025.rpy:447
translate french halloween_sonya_dream_b51c492c_1:

    # gg "Где же все?"
    gg "Où est tout le monde ?"

# game/special_events/halloween 2025.rpy:452
translate french halloween_sonya_dream_867b75aa_1:

    # gg "Чёрт. что за бред телевизор сам включился . . ."
    gg "Merde. Qu'est-ce que cette télé allume toute seule ? . ."

# game/special_events/halloween 2025.rpy:487
translate french halloween_sonya_dream_cfa5487f_1:

    # gg "Что за бред"
    gg "Quelle absurdité"

# game/special_events/halloween 2025.rpy:488
translate french halloween_sonya_dream_6ca44626_1:

    # gg "Нужно проверить остальные комнаты"
    gg "Il faut vérifier les autres pièces"

# game/special_events/halloween 2025.rpy:491
translate french halloween_sonya_dream_3109e8d5_1:

    # gg "Соня?"
    gg "Sonya ?"

# game/special_events/halloween 2025.rpy:493
translate french halloween_sonya_dream_af6b4c99_1:

    # gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    gg "Hé . . . il est tard, tu me fais peur, honnêtement"

# game/special_events/halloween 2025.rpy:496
translate french halloween_sonya_dream_f09531f9_1:

    # gg "Просто показалось . . ."
    gg "Cela semblait être le cas. . ."

# game/special_events/halloween 2025.rpy:497
translate french halloween_sonya_dream_6fecd311_1:

    # gg "Просто тень . . ."
    gg "Juste une ombre. . ."

# game/special_events/halloween 2025.rpy:504
translate french halloween_sonya_dream_b989363c_1:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:506
translate french halloween_sonya_dream_e5e215bc_1:

    # Sonya "Как ты посмел меня разбудить!" with hpunch
    Sonya "Comment oses-tu me réveiller !" with hpunch

# game/special_events/halloween 2025.rpy:508
translate french halloween_sonya_dream_cbf79f81_1:

    # gg "Соня, ты . . . {w}ты издеваешься? . . ."
    gg "Sonya, tu... . . {w}Vous vous moquez de moi ? . . ."

# game/special_events/halloween 2025.rpy:510
translate french halloween_sonya_dream_ea23c51e_1:

    # gg "Это ты? Что это за грёбаные игры? . . ."
    gg "C'est toi ? C'est quoi ces jeux ? . . ."

# game/special_events/halloween 2025.rpy:512
translate french halloween_sonya_dream_c5bc9963_1:

    # Sonya "Имя звучит знакомо"
    Sonya "Le nom semble familier"

# game/special_events/halloween 2025.rpy:513
translate french halloween_sonya_dream_4db18375_1:

    # Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    Sonya "Mais celui que tu as appelé est mort avec cette maison"

# game/special_events/halloween 2025.rpy:514
translate french halloween_sonya_dream_f5284849_1:

    # gg "Прекрати . . ."
    gg "Arrêtez-le. . ."

# game/special_events/halloween 2025.rpy:516
translate french halloween_sonya_dream_bf221ec2_1:

    # Sonya "Дом теперь мой.{w} Я - его хозяин"
    Sonya "La maison m'appartient désormais.{w} J'en suis le propriétaire"

# game/special_events/halloween 2025.rpy:518
translate french halloween_sonya_dream_2c4ebaa2_1:

    # Sonya "Боишься?"
    Sonya "As-tu peur ?"

# game/special_events/halloween 2025.rpy:519
translate french halloween_sonya_dream_0063da0b_1:

    # gg "Да . . ."
    gg "Oui. . ."

# game/special_events/halloween 2025.rpy:521
translate french halloween_sonya_dream_b67571be_1:

    # Sonya "Хорошо"
    Sonya "Bien"

# game/special_events/halloween 2025.rpy:523
translate french halloween_sonya_dream_14d503b0_1:

    # Sonya "Страх делает кровь живой"
    Sonya "La peur rend le sang vivant"

# game/special_events/halloween 2025.rpy:531
translate french halloween_sonya_dream_ab894d3a_1:

    # Sonya "Ты принёс монету?"
    Sonya "Avez-vous apporté une pièce de monnaie ?"

# game/special_events/halloween 2025.rpy:535
translate french halloween_sonya_dream_c3bf29e7_1:

    # gg "Что? . . ."
    gg "Quoi? . . ."

# game/special_events/halloween 2025.rpy:537
translate french halloween_sonya_dream_52cb176c_1:

    # Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "Un cadeau scellé. Tu l'as ouvert"

# game/special_events/halloween 2025.rpy:538
translate french halloween_sonya_dream_e3369996_1:

    # Sonya "Ты впустил меня"
    Sonya "Tu m'as laissé entrer"

# game/special_events/halloween 2025.rpy:540
translate french halloween_sonya_dream_1f166693_1:

    # Sonya "Я не Соня"
    Sonya "je ne suis pas Sonya"

# game/special_events/halloween 2025.rpy:544
translate french halloween_sonya_dream_86fe7642_1:

    # Sonya "Я та, что носила её лицо"
    Sonya "C'est moi qui ai porté son visage"

# game/special_events/halloween 2025.rpy:545
translate french halloween_sonya_dream_625b9f75_1:

    # Sonya "И теперь ты мой"
    Sonya "Et maintenant tu es à moi"

# game/special_events/halloween 2025.rpy:547
translate french halloween_sonya_dream_0ac9332f_1:

    # Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    Sonya "Tout ce que tu avais peur de perdre. . . je l'ai déjà pris"

# game/special_events/halloween 2025.rpy:549
translate french halloween_sonya_dream_64ed8507_1:

    # Sonya "А теперь - перестань сопротивляться"
    Sonya "Maintenant arrête de résister"

# game/special_events/halloween 2025.rpy:553
translate french halloween_sonya_dream_3d7ee945_1:

    # Sonya "Я выжму тебя досуха"
    Sonya "Je vais te sécher"

# game/special_events/halloween 2025.rpy:588
translate french halloween_maya_dream_032be6f2_1:

    # gg "Чёрт . . . {w}нет, нет, снова это . . ."
    gg "Merde . . . {w}non, non, encore ça. . ."

# game/special_events/halloween 2025.rpy:590
translate french halloween_maya_dream_ff7388e6_1:

    # Maya "Эй, спокойно"
    Maya "Hé, calme-toi"

# game/special_events/halloween 2025.rpy:592
translate french halloween_maya_dream_92686e55_1:

    # Maya "Ты в безопасности"
    Maya "Tu esen sécurité"

# game/special_events/halloween 2025.rpy:593
translate french halloween_maya_dream_edf9349e_1:

    # gg "Где я? . . ."
    gg "Où suis-je ? . . ."

# game/special_events/halloween 2025.rpy:594
translate french halloween_maya_dream_de23ff68_1:

    # gg "Что . . . что это за место?"
    gg "Quoi . . . quel genre d'endroit est-ce ?"

# game/special_events/halloween 2025.rpy:596
translate french halloween_maya_dream_75c561e6_1:

    # Maya "Мой дом"
    Maya "Ma maison"

# game/special_events/halloween 2025.rpy:598
translate french halloween_maya_dream_912b1ea9_1:

    # gg "Почему . . . я . . . здесь? . . ."
    gg "Pourquoi . . . JE . . . Ici? . . ."

# game/special_events/halloween 2025.rpy:600
translate french halloween_maya_dream_05fc8512_1:

    # Maya "Потому что ты боялся"
    Maya "Parce que tu avais peur"

# game/special_events/halloween 2025.rpy:601
translate french halloween_maya_dream_657245c6_1:

    # Maya "И кто-то должен был тебя остановить"
    Maya "Et quelqu'un aurait dû t'arrêter"

# game/special_events/halloween 2025.rpy:603
translate french halloween_maya_dream_dcba1503_1:

    # gg "Нет . . .{w} не приближайся"
    gg "Non . . .{w} ne t'approche pas"

# game/special_events/halloween 2025.rpy:604
translate french halloween_maya_dream_e91592a1_1:

    # gg "Я видел, как это начинается"
    gg "Je l'ai vu commencer"

# game/special_events/halloween 2025.rpy:605
translate french halloween_maya_dream_d9b24014_1:

    # gg "Сначала свет, потом . . ."
    gg "D’abord la lumière, puis. . ."

# game/special_events/halloween 2025.rpy:608
translate french halloween_maya_dream_23c69478_1:

    # Maya "Никто не собирается тебя пугать"
    Maya "Personne ne te fera peur"

# game/special_events/halloween 2025.rpy:609
translate french halloween_maya_dream_fb15da85_1:

    # gg "Это сон?"
    gg "Est-ce un rêve ?"

# game/special_events/halloween 2025.rpy:611
translate french halloween_maya_dream_ef47f8b8_1:

    # Maya "Возможно"
    Maya "Peut être"

# game/special_events/halloween 2025.rpy:612
translate french halloween_maya_dream_11e09330_1:

    # Maya "Но в этом сне тебе можно не убегать"
    Maya "Mais dans ce rêve tu n'es pas obligé de t'enfuir"

# game/special_events/halloween 2025.rpy:614
translate french halloween_maya_dream_e96ceee2_1:

    # Maya "Сядь.{w} Попробуй просто дышать"
    Maya "Assieds toi.{w} Essayes simplement de respirer"

# game/special_events/halloween 2025.rpy:615
translate french halloween_maya_dream_f1385d77_1:

    # gg "Я . . .{w} не могу"
    gg "JE . . .{w} Je ne peux pas"

# game/special_events/halloween 2025.rpy:617
translate french halloween_maya_dream_38874e86_1:

    # Maya "Можешь{w}, начни только тихо"
    Maya "Tu peux {w}, commences simplement tranquillement"

# game/special_events/halloween 2025.rpy:619
translate french halloween_maya_dream_4a1eadac_1:

    # Maya "Ты думал, я кто-то другой, да?"
    Maya "Tu pensais que j'étais quelqu'un d'autre, n'est-ce pas ?"

# game/special_events/halloween 2025.rpy:621
translate french halloween_maya_dream_8d83da3f_1:

    # gg "После всего . . ."
    gg "Après tout. . ."

# game/special_events/halloween 2025.rpy:622
translate french halloween_maya_dream_9aa85be5_1:

    # gg "Я и не знаю, кому верить"
    gg "Je ne sais pas qui croire"

# game/special_events/halloween 2025.rpy:623
translate french halloween_maya_dream_95a67e98_1:

    # Maya "Тогда не верь"
    Maya "Alors n'y crois pas"

# game/special_events/halloween 2025.rpy:624
translate french halloween_maya_dream_cf12428b_1:

    # Maya "Просто смотри"
    Maya "Il suffit de regarder"

# game/special_events/halloween 2025.rpy:628
translate french halloween_maya_dream_5da82532_1:

    # gg "Чувствуешь?{w} Здесь нет боли"
    gg "Le sentes-tu?{w} Il n'y a aucune douleur ici"

# game/special_events/halloween 2025.rpy:630
translate french halloween_maya_dream_df19ec31_1:

    # Maya "Ты дрожишь"
    Maya "Tu trembles"

# game/special_events/halloween 2025.rpy:631
translate french halloween_maya_dream_b989363c_2:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:634
translate french halloween_maya_dream_718947a3_1:

    # Maya "Бедный"
    Maya "Mon pauvre"

# game/special_events/halloween 2025.rpy:636
translate french halloween_maya_dream_20c45a93_1:

    # Maya "Я давно не видела людей"
    Maya "Je n'ai pas vu personne depuis longtemps"

# game/special_events/halloween 2025.rpy:638
translate french halloween_maya_dream_0f6f1ec4_1:

    # Maya "Вот, видишь?{w} Уже лучше"
    Maya "Voir? {w} C'est mieux"

# game/special_events/halloween 2025.rpy:639
translate french halloween_maya_dream_1db499d0_1:

    # gg "Не знаю, что это.{w} Но уже лучше"
    gg "Je ne sais pas ce que c'est.{w} Mais c'est mieux"

# game/special_events/halloween 2025.rpy:641
translate french halloween_maya_dream_927ad5b3_1:

    # Maya "Сейчас кое что тебя поставит на ноги"
    Maya "Maintenant, quelque chose va te remettre sur pied"

# game/special_events/halloween 2025.rpy:644
translate french halloween_maya_dream_9add8ae1_1:

    # Maya "Здесь только травы"
    Maya "Il n'y a que des herbes ici"

# game/special_events/halloween 2025.rpy:645
translate french halloween_maya_dream_338034af_1:

    # Maya "Лаванда, мята, немного корицы.{w} Попей"
    Maya "Lavande, menthe, un peu de cannelle.{w} Bois"

# game/special_events/halloween 2025.rpy:647
translate french halloween_maya_dream_8f20081e_1:

    # gg "Что это?"
    gg "Qu'est-ce que c'est?"

# game/special_events/halloween 2025.rpy:648
translate french halloween_maya_dream_3fdb7032_1:

    # Maya "Это магия"
    Maya "C'est magique"

# game/special_events/halloween 2025.rpy:650
translate french halloween_maya_dream_7c4cba20_1:

    # Maya "Лечебное зелье, с небольшим побочным эфектом"
    Maya "Potion de guérison avec effets secondaires mineurs"

# game/special_events/halloween 2025.rpy:652
translate french halloween_maya_dream_59e469a3_1:

    # gg "Каким еще эфектом"
    gg "Quel autre effet"

# game/special_events/halloween 2025.rpy:655
translate french halloween_maya_dream_809b7a3a_1:

    # Maya "Просто отдохни.{w} Не думай об этом"
    Maya "Reposes-toi.{w} N'y penses pas"

# game/special_events/halloween 2025.rpy:657
translate french halloween_maya_dream_ae92cf27_1:

    # gg "А если я снова усну?"
    gg "Et si je me rendors à nouveau ?"

# game/special_events/halloween 2025.rpy:659
translate french halloween_maya_dream_c1fe7b6b_1:

    # Maya "Тогда пусть этот сон, будет приятным"
    Maya "Alors laisse ce rêve être agréable"

# game/special_events/halloween 2025.rpy:683
translate french halloween_maya_dream_b989363c_3:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:684
translate french halloween_maya_dream_5174a63c_1:

    # gg "Приснится же такое . . ."
    gg "Je rêverai de quelque chose comme ça. . ."

# game/special_events/halloween 2025.rpy:686
translate french halloween_maya_dream_13dee7c8_1:

    # "Тыква хранит воспоминания"
    "La citrouille garde des souvenirs"

# game/special_events/halloween 2025.rpy:687
translate french halloween_maya_dream_bb8e42de_1:

    # "Коснись её, чтобы вновь увидеть сцену"
    "Touchez-le pour revoir la scène"

translate french strings:

    # game/special_events/halloween 2025.rpy:8
    old "Сначала"
    new "D'abord"

    # game/special_events/halloween 2025.rpy:10
    old "Сон с Соней"
    new "Coucher avec Sonya"

    # game/special_events/halloween 2025.rpy:14
    old "Сон с Маей"
    new "Coucher avec Maya"

# TODO: Translation updated at 2026-01-26 03:22

# game/special_events/halloween 2025.rpy:28
translate french halloween_prestart_6dc15a83:

    # gg "Хм . . ."
    gg "Hum. . ."

# game/special_events/halloween 2025.rpy:29
translate french halloween_prestart_3173d374:

    # gg "А что это еще такое?"
    gg "Qu'est-ce que c'est encore ?"

# game/special_events/halloween 2025.rpy:30
translate french halloween_prestart_9d6bd7cd:

    # gg "Эта тыква будто манит меня дотронуться до нее"
    gg "Cette citrouille semble m'inviter à la toucher."

# game/special_events/halloween 2025.rpy:32
translate french halloween_prestart_6b235c12:

    # gg "Вроде ничего не случилось"
    gg "On dirait que rien ne s'est passé."

# game/special_events/halloween 2025.rpy:33
translate french halloween_prestart_99b702cc:

    # gg "Просто обычная тыква"
    gg "Juste une citrouille ordinaire"

# game/special_events/halloween 2025.rpy:34
translate french halloween_prestart_882ef6af:

    # gg "Так не интересно"
    gg "Pas très amusant"

# game/special_events/halloween 2025.rpy:38
translate french halloween_prestart_2eb26325:

    # gg "Ай!" with hpunch
    gg "Aïe !" with hpunch

# game/special_events/halloween 2025.rpy:39
translate french halloween_prestart_b858f49b:

    # gg "Почему так щипет"
    gg "Pourquoi ça pique comme ça"

# game/special_events/halloween 2025.rpy:40
translate french halloween_prestart_eb8d9b68:

    # gg "Что то мне не хорошо"
    gg "Je ne me sens pas très bien"

# game/special_events/halloween 2025.rpy:41
translate french halloween_prestart_462beaf3:

    # gg "Пойду отдохну"
    gg "Je vais aller me reposer"

# game/special_events/halloween 2025.rpy:50
translate french halloween_start_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/special_events/halloween 2025.rpy:52
translate french halloween_start_2768572c:

    # Sonya "Знаешь, что я поняла?"
    Sonya "Tu sais ce que je viens de comprendre ?"

# game/special_events/halloween 2025.rpy:53
translate french halloween_start_b99b94d3:

    # gg "Что пора поспать?"
    gg "Qu'il est temps d'aller dormir ?"

# game/special_events/halloween 2025.rpy:55
translate french halloween_start_73751dc8:

    # Sonya "Что пора украшать дом"
    Sonya "Qu'il est temps de décorer la maison"

# game/special_events/halloween 2025.rpy:57
translate french halloween_start_2efbd354:

    # gg "Украшать?"
    gg "Décorer ?"

# game/special_events/halloween 2025.rpy:59
translate french halloween_start_baa9dc02:

    # Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    Sonya "On a Halloween dans deux jours, et zéro ambiance"

# game/special_events/halloween 2025.rpy:61
translate french halloween_start_d64dca0a:

    # Sonya "Я хочу, чтобы всё выглядело"
    Sonya "Je veux que tout ait l'air"

# game/special_events/halloween 2025.rpy:63
translate french halloween_start_c1524153:

    # Sonya "Хотя бы немного празднично"
    Sonya "Au moins un peu festif"

# game/special_events/halloween 2025.rpy:65
translate french halloween_start_c4c69fc7:

    # Maya "Украшать?{w} Пора бы да"
    Maya "Décorer ?{w} Il était temps"

# game/special_events/halloween 2025.rpy:67
translate french halloween_start_f5a85bf6:

    # Maya "Можно повесить гирлянды и поставить свечи!"
    Maya "On peut accrocher des guirlandes et mettre des bougies !"

# game/special_events/halloween 2025.rpy:69
translate french halloween_start_88ab11a7:

    # Sonya "Вот. Поддержка есть"
    Sonya "Voilà. Du soutien."

# game/special_events/halloween 2025.rpy:71
translate french halloween_start_f2b19d78:

    # gg "Видимо у меня нет выбора"
    gg "Apparemment, je n'ai pas le choix"

# game/special_events/halloween 2025.rpy:73
translate french halloween_start_bc7a61df:

    # Maya "Ты просто устал, тебе нужно отвлечься"
    Maya "Tu es juste fatigué, tu as besoin de te distraire"

# game/special_events/halloween 2025.rpy:75
translate french halloween_start_06d0d58b:

    # Sonya "Вот именно"
    Sonya "C'est ça"

# game/special_events/halloween 2025.rpy:77
translate french halloween_start_041234b8:

    # Sonya "Украшение дома - лучший антистресс"
    Sonya "Décorer la maison, c'est le meilleur anti-stress"

# game/special_events/halloween 2025.rpy:79
translate french halloween_start_c578bb24:

    # Maya "Тогда решено"
    Maya "Alors c'est décidé"

# game/special_events/halloween 2025.rpy:80
translate french halloween_start_6e15e900:

    # Maya "Начнём с гостиной"
    Maya "Commençons par le salon"

# game/special_events/halloween 2025.rpy:82
translate french halloween_start_d298f1fa:

    # Maya "Я за уют, но без перебора"
    Maya "Je suis pour le cosy, mais sans exagérer"

# game/special_events/halloween 2025.rpy:84
translate french halloween_start_2a522c28:

    # Sonya "Надо позвать Кейт"
    Sonya "Il faut appeler Kate"

# game/special_events/halloween 2025.rpy:85
translate french halloween_start_20197ce8:

    # Sonya "Без неё всё равно не обойдётся"
    Sonya "On ne pourra pas se passer d'elle"

# game/special_events/halloween 2025.rpy:87
translate french halloween_start_bcecc811:

    # Maya "Я напишу ей"
    Maya "Je vais lui écrire"

# game/special_events/halloween 2025.rpy:88
translate french halloween_start_81baf5ad:

    # Maya "Если не занята, придёт"
    Maya "Si elle n'est pas occupée, elle viendra"

# game/special_events/halloween 2025.rpy:90
translate french halloween_start_4a4b3e1e:

    # Sonya "Пойдем поможешь мне"
    Sonya "Viens m'aider"

# game/special_events/halloween 2025.rpy:92
translate french halloween_start_082fbdc3:

    # Sonya "У нас в кладовке чего только нету"
    Sonya "Dans notre placard, on a vraiment de tout"

# game/special_events/halloween 2025.rpy:94
translate french halloween_start_569f8605:

    # Sonya "Осторожно, она тяжёлая"
    Sonya "Attention, c'est lourd"

# game/special_events/halloween 2025.rpy:98
translate french halloween_start_08a41431:

    # gg "Не волнуйся, я пока справляюсь"
    gg "Ne t'inquiète pas, je me débrouille pour l'instant"

# game/special_events/halloween 2025.rpy:100
translate french halloween_start_2ee9b67e:

    # Maya "Написала, сказала, что уже бежит"
    Maya "Je lui ai écrit, elle dit qu'elle arrive en courant"

# game/special_events/halloween 2025.rpy:102
translate french halloween_start_56e25c3d:

    # Sonya "Это хорошо"
    Sonya "C'est bien"

# game/special_events/halloween 2025.rpy:104
translate french halloween_start_cc205380:

    # Maya "О, смотри, старая паутина!"
    Maya "Oh, regarde, une vieille toile d'araignée !"

# game/special_events/halloween 2025.rpy:106
translate french halloween_start_6d122aa8:

    # Sonya "Это не декор, не трогай!"
    Sonya "C'est pas une décoration, n'y touche pas !"

# game/special_events/halloween 2025.rpy:108
translate french halloween_start_1c832081:

    # Maya "Ты же знаешь я боюсь пауков!"
    Maya "Tu sais que j'ai peur des araignées !"

# game/special_events/halloween 2025.rpy:109
translate french halloween_start_e8c9fd97:

    # gg "Ха ха"
    gg "Ha ha"

# game/special_events/halloween 2025.rpy:114
translate french halloween_start_5c8cb7fa:

    # Kate "Я пришла"
    Kate "Je suis venue"

# game/special_events/halloween 2025.rpy:115
translate french halloween_start_5cba982d:

    # Kate "Где вы, мои маленькие смертные?"
    Kate "Où êtes-vous, mes petits mortels ?"

# game/special_events/halloween 2025.rpy:116
translate french halloween_start_66671892:

    # Maya "Привет!"
    Maya "Salut !"

# game/special_events/halloween 2025.rpy:118
translate french halloween_start_41cac97b:

    # Kate "О, вы уже начали без меня?{w} Это предательство"
    Kate "Oh, vous avez déjà commencé sans moi ?{w} C'est une trahison"

# game/special_events/halloween 2025.rpy:120
translate french halloween_start_3f833e29:

    # Maya "Мы только подготовились"
    Maya "On vient juste de se préparer"

# game/special_events/halloween 2025.rpy:122
translate french halloween_start_10a24600:

    # Sonya "Отлично, теперь можем начинать по-настоящему"
    Sonya "Parfait, maintenant on peut vraiment commencer"

# game/special_events/halloween 2025.rpy:124
translate french halloween_start_59716300:

    # Maya "Всё, распределяем задачи?"
    Maya "Bon, on répartit les tâches ?"

# game/special_events/halloween 2025.rpy:126
translate french halloween_start_c6287aa3:

    # Kate "Так эту куклу повесим вон там, над теликом"
    Kate "Bon, on accroche cette poupée là-bas, au-dessus de la télé"

# game/special_events/halloween 2025.rpy:127
translate french halloween_start_ddd8aded:

    # Kate "Еще нужны паутины, гирлянда из флажков, черепа . . ."
    Kate "Il faut aussi des toiles d'araignée, une guirlande de fanions, des crânes..."

# game/special_events/halloween 2025.rpy:129
translate french halloween_start_c1c2f306:

    # Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    Maya "Alors dans ma chambre, on se passe des décorations flippantes ?"

# game/special_events/halloween 2025.rpy:131
translate french halloween_start_344d78c3:

    # gg "Ну это же Хэллоуин, а чем ты?"
    gg "Mais c'est Halloween, et toi tu fais quoi ?"

# game/special_events/halloween 2025.rpy:133
translate french halloween_start_7e9f8506:

    # Sonya "Мая просто трусишка"
    Sonya "Maya est juste une petite trouillarde"

# game/special_events/halloween 2025.rpy:135
translate french halloween_start_423eeb13:

    # Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "HÉ !! Je trouve juste ça stupide !"

# game/special_events/halloween 2025.rpy:136
translate french halloween_start_1c4935b1:

    # Maya "Можно сделать дом тёплым, как осень!"
    Maya "On peut rendre la maison chaleureuse, comme en automne !"

# game/special_events/halloween 2025.rpy:137
translate french halloween_start_5acb8aac:

    # Maya "Листья и природу . . . И без жути . . ."
    Maya "Des feuilles, de la nature... Et sans trucs qui font peur..."

# game/special_events/halloween 2025.rpy:139
translate french halloween_start_9d95e4f7:

    # Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    Kate "Et moi, je veux que ce soit tellement flippant que les gamins du voisinage hurlent de peur s'ils osent frapper à notre porte"

# game/special_events/halloween 2025.rpy:141
translate french halloween_start_97fa9b09:

    # Sonya "Звучит как цель"
    Sonya "Ça ressemble à un objectif"

# game/special_events/halloween 2025.rpy:143
translate french halloween_start_7a0152d7:

    # Maya "Надеюсь, что все пройдет без происшествий"
    Maya "J'espère que tout va se passer sans incident"

# game/special_events/halloween 2025.rpy:145
translate french halloween_start_cd410fe4:

    # gg "Ну что же, давайте постараемся"
    gg "Bon, on va faire de notre mieux"

# game/special_events/halloween 2025.rpy:153
translate french halloween_start_e7148dd7:

    # Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    Maya "Hé, vous savez, c'est pas si mal finalement, même très mignon et cosy"

# game/special_events/halloween 2025.rpy:155
translate french halloween_start_4203fcb3:

    # Kate "ДА! Вышло супер, мы такие молодцы"
    Kate "OUAIS ! C'est super réussi, on a trop assuré !"

# game/special_events/halloween 2025.rpy:157
translate french halloween_start_3c177eb8:

    # Sonya "Давайте дальше украсим кухню!"
    Sonya "Maintenant, décorons la cuisine !"

# game/special_events/halloween 2025.rpy:158
translate french halloween_start_3fc97c96:

    # Sonya "[povname] хватай коробки с украшениями!"
    Sonya "[povname], attrape les cartons de décorations !"

# game/special_events/halloween 2025.rpy:167
translate french halloween_start_c18a0daf:

    # Maya "Ну почему я должна ее вешать?"
    Maya "Et pourquoi c'est moi qui dois l'accrocher ?"

# game/special_events/halloween 2025.rpy:169
translate french halloween_start_538416e3:

    # Kate "Потому что ты самая высокая, это же логично!"
    Kate "Parce que t'es la plus grande, c'est logique !"

# game/special_events/halloween 2025.rpy:171
translate french halloween_start_fac78089:

    # Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    Maya "Beurk. J'ai pas peur des araignées, c'est juste qu'elles sont dégoûtantes, ça me donne la nausée"

# game/special_events/halloween 2025.rpy:173
translate french halloween_start_196b4d6a:

    # gg "Тыкву тоже поставь на полку"
    gg "Mets la citrouille sur l'étagère aussi"

# game/special_events/halloween 2025.rpy:182
translate french halloween_start_3ee05b57:

    # Maya "АААААААААА!" with hpunch
    Maya "АААААААААА!" with hpunch

# game/special_events/halloween 2025.rpy:186
translate french halloween_start_7410244b:

    # gg "Все, я убрал, не бойся, он же не настоящий"
    gg "Voilà, je l'ai enlevée, n'aie pas peur, elle n'est pas réelle"

# game/special_events/halloween 2025.rpy:188
translate french halloween_start_1ceba70d:

    # Maya "Спасибо"
    Maya "Merci"

# game/special_events/halloween 2025.rpy:190
translate french halloween_start_5375f0ad:

    # gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    gg "Trop souvent, tu finis dans mes bras, c'est pas un peu fait exprès ?"

# game/special_events/halloween 2025.rpy:192
translate french halloween_start_ccd7999c:

    # Maya "Еще чего!"
    Maya "Qu'est-ce que tu racontes !"

# game/special_events/halloween 2025.rpy:193
translate french halloween_start_c938832e:

    # Maya "Ты просто мешаешься на пути, вот и все!"
    Maya "Tu fais juste obstacle, c'est tout !"

# game/special_events/halloween 2025.rpy:194
translate french halloween_start_5807bf69:

    # Kate "Не поранились? Голубки"
    Kate "Vous ne vous êtes pas fait mal ? Mes tourtereaux"

# game/special_events/halloween 2025.rpy:196
translate french halloween_start_180bf5f1:

    # Maya "Все с паутиной мы закончили"
    Maya "On en a fini avec les toiles d'araignée"

# game/special_events/halloween 2025.rpy:197
translate french halloween_start_62eaed17:

    # Maya "Пойду возьму яблочного сидра"
    Maya "Je vais chercher du cidre de pomme"

# game/special_events/halloween 2025.rpy:203
translate french halloween_start_6a9d122d:

    # Sonya "Еще 5 минут и кексы готовы"
    Sonya "Encore cinq minutes et les cupcakes sont prêts"

# game/special_events/halloween 2025.rpy:205
translate french halloween_start_92462f90:

    # Kate "Пахнет потрясающе"
    Kate "Ça sent incroyablement bon"

# game/special_events/halloween 2025.rpy:207
translate french halloween_start_ada25b4b:

    # Maya "Всё, теперь осталось только подождать"
    Maya "Voilà, maintenant on n'a plus qu'à attendre"

# game/special_events/halloween 2025.rpy:208
translate french halloween_start_4ac68531:

    # Maya "Потом будем украшать"
    Maya "Ensuite on décorera"

# game/special_events/halloween 2025.rpy:210
translate french halloween_start_7d203e0d:

    # Kate "Эй а кем вы будете в ночь Хэллоуина?"
    Kate "Hé, et vous serez déguisés en quoi pour Halloween ?"

# game/special_events/halloween 2025.rpy:212
translate french halloween_start_3e0fd7f3:

    # Sonya "Я уже думала об этом!"
    Sonya "J'y ai déjà pensé !"

# game/special_events/halloween 2025.rpy:213
translate french halloween_start_21be6b25:

    # Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    Sonya "Mm, Kate, un costume de démone irait bien avec toi"

# game/special_events/halloween 2025.rpy:215
translate french halloween_start_8fc9e335:

    # Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    Maya "D'ailleurs, ouais, même si t'as l'air d'un petit ange, t'es aussi rusée qu'un lutin"

# game/special_events/halloween 2025.rpy:217
translate french halloween_start_6485ec70:

    # Kate "Эй!! Неплохая идея"
    Kate "Hé !! Pas une mauvaise idée"

# game/special_events/halloween 2025.rpy:221
translate french halloween_start_9ea771a0:

    # Kate "Королева демонов Уахахахаха!"
    Kate "Reine des démons, wahahahaha !"

# game/special_events/halloween 2025.rpy:222
translate french halloween_start_dfa5392d:

    # Kate "Все должны пасть к моим ногам!"
    Kate "Tout le monde doit tomber à mes pieds !"

# game/special_events/halloween 2025.rpy:224
translate french halloween_start_d1a70744:

    # Sonya "Все, ей больше не наливать!"
    Sonya "Ça y est, ne lui en versez plus !"

# game/special_events/halloween 2025.rpy:226
translate french halloween_start_67a78ead:

    # gg "Не знал что Кейт так быстро выносит с алкоголя"
    gg "Je ne savais pas que Kate se saoulait si vite"

# game/special_events/halloween 2025.rpy:228
translate french halloween_start_89e99062:

    # Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    Maya "Je voudrais un costume de sorcière ou une sorte de dryade magique. . ."

# game/special_events/halloween 2025.rpy:230
translate french halloween_start_ccfee06e:

    # Kate "Думаю тебе пойдет"
    Kate "Je pense que ça te conviendra"

# game/special_events/halloween 2025.rpy:232
translate french halloween_start_8e96eaa2:

    # Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    Sonya "Et l'autre jour, j'ai commandé, au lieu d'un paquet de bandages, pas moins de six. On dirait que c'est un signe pour faire un costume de momie ?"

# game/special_events/halloween 2025.rpy:234
translate french halloween_start_2aa5e0fb:

    # Maya "Ты как раз самая старшая"
    Maya "Tu es justement la plus vieille"

# game/special_events/halloween 2025.rpy:236
translate french halloween_start_38bc2712:

    # Sonya "Ах ты!"
    Sonya "Ah toi !"

# game/special_events/halloween 2025.rpy:238
translate french halloween_start_5d38e441:

    # Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "Attends, et Barsik ? Il a aussi besoin d'un costume !"

# game/special_events/halloween 2025.rpy:239
translate french halloween_start_fb608953:

    # Maya "Например дракончика или мистер тыковка . . ."
    Maya "Par exemple, petit dragon ou M. Citrouille. . ."

# game/special_events/halloween 2025.rpy:241
translate french halloween_start_7fd69d94:

    # Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    Sonya "Essaie de l'attraper et de l'habiller, M. Barsik ne se laissera pas faire !"

# game/special_events/halloween 2025.rpy:243
translate french halloween_start_70adb582:

    # Maya "Что ты . . . {w}Он любит переодевашки"
    Maya "Qu'est-ce que tu. . . {w}Il adore se déguiser"

# game/special_events/halloween 2025.rpy:246
translate french halloween_start_c0036cba:

    # Sonya "Вот и кексы готовы"
    Sonya "Voilà, les cupcakes sont prêts"

# game/special_events/halloween 2025.rpy:248
translate french halloween_start_ae45c746:

    # gg "С кухней готово, что дальше?"
    gg "La cuisine est prête, et ensuite ?"

# game/special_events/halloween 2025.rpy:249
translate french halloween_start_354f0704:

    # Sonya "Предлагаю разделиться"
    Sonya "Je propose qu'on se sépare"

# game/special_events/halloween 2025.rpy:250
translate french halloween_start_07a07420:

    # Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "Maya et moi, on va décorer nos chambres. Kate, tu t'occupes de la salle de bain ?"

# game/special_events/halloween 2025.rpy:251
translate french halloween_start_4e86ac78:

    # Sonya "[povname], будешь помогать нам?"
    Sonya "[povname], tu veux bien nous aider ?"

# game/special_events/halloween 2025.rpy:252
translate french halloween_start_564e6225:

    # gg "Окей"
    gg "D'accord"

# game/special_events/halloween 2025.rpy:263
translate french halloween_prepare_mayaroom_7afc2c47:

    # gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "Tu as là un vrai repaire de sorcière qui prépare des potions avec des herbes"

# game/special_events/halloween 2025.rpy:264
translate french halloween_prepare_mayaroom_63c64e7b:

    # gg "Мм. . . пахнет приятно"
    gg "Mm. . . ça sent bon"

# game/special_events/halloween 2025.rpy:266
translate french halloween_prepare_mayaroom_1ca099b7:

    # Maya "Хватит нюхать женскую комнату!"
    Maya "Arrête de renifler ma chambre !"

# game/special_events/halloween 2025.rpy:268
translate french halloween_prepare_mayaroom_eded9518:

    # Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "Tu n'es là que pour exécuter mes ordres"

# game/special_events/halloween 2025.rpy:269
translate french halloween_prepare_mayaroom_799aa249:

    # Maya "Поставь эти тыквы в тот угол!"
    Maya "Mets ces citrouilles dans ce coin !"

# game/special_events/halloween 2025.rpy:271
translate french halloween_prepare_mayaroom_292858b8:

    # gg "А где пожалуйста?"
    gg "Où, s'il te plaît ?"

# game/special_events/halloween 2025.rpy:273
translate french halloween_prepare_mayaroom_ad71fbb0:

    # Maya "Пожалуйста, не беси меня"
    Maya "S'il te plaît, ne m'énerve pas"

# game/special_events/halloween 2025.rpy:275
translate french halloween_prepare_mayaroom_63b60e81:

    # gg "Ох"
    gg "Oh"

# game/special_events/halloween 2025.rpy:277
translate french halloween_prepare_mayaroom_977c102e:

    # Maya "Мм. . . нет!"
    Maya "Mm. . . Non !"

# game/special_events/halloween 2025.rpy:279
translate french halloween_prepare_mayaroom_9cb8ca98:

    # Maya "Выглядит недостаточно хорошо!"
    Maya "Ça n'a pas l'air assez bien !"

# game/special_events/halloween 2025.rpy:281
translate french halloween_prepare_mayaroom_3b7bbda5:

    # Maya "Давай лучше в тот угол!"
    Maya "Allons dans ce coin-là !"

# game/special_events/halloween 2025.rpy:283
translate french halloween_prepare_mayaroom_f714e642:

    # gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    gg "Décidons d'abord où exactement, pour que je ne porte pas ces citrouilles cent fois"

# game/special_events/halloween 2025.rpy:285
translate french halloween_prepare_mayaroom_a2933c08:

    # Maya "Говорю же туда неси!"
    Maya "Je te dis, porte-les là-bas !"

# game/special_events/halloween 2025.rpy:287
translate french halloween_prepare_mayaroom_4c580716:

    # gg "Точно?"
    gg "C'est sûr ?"

# game/special_events/halloween 2025.rpy:288
translate french halloween_prepare_mayaroom_fccb4de7:

    # gg "Я больше двигать не буду, подумай хорошо"
    gg "Je ne bougerai plus, réfléchis bien"

# game/special_events/halloween 2025.rpy:290
translate french halloween_prepare_mayaroom_4aa933c6:

    # Maya "Хотя как сейчас тоже неплохо . . ."
    Maya "Quoique, comme c'est maintenant, c'est pas mal non plus. . ."

# game/special_events/halloween 2025.rpy:292
translate french halloween_prepare_mayaroom_b2b57087:

    # Maya "Все ты свободен!"
    Maya "Voilà, tu es libre !"

# game/special_events/halloween 2025.rpy:294
translate french halloween_prepare_mayaroom_04c6c53d:

    # gg "Спасибо"
    gg "Merci"

# game/special_events/halloween 2025.rpy:295
translate french halloween_prepare_mayaroom_dad56d9b:

    # Maya "Если что еще позову"
    Maya "Si j'ai encore besoin, je t'appellerai"

# game/special_events/halloween 2025.rpy:297
translate french halloween_prepare_mayaroom_6a8ac153:

    # Maya "Все Давай, давай, живее!!"
    Maya "Allez, dépêche-toi !!"

# game/special_events/halloween 2025.rpy:310
translate french halloween_prepare_sonyaroom_b708d644:

    # Sonya "Ой" with hpunch
    Sonya "Oh" with hpunch

# game/special_events/halloween 2025.rpy:312
translate french halloween_prepare_sonyaroom_4b100306:

    # Sonya "Добро пожаловать в мою обитель!"
    Sonya "Bienvenue dans ma demeure !"

# game/special_events/halloween 2025.rpy:314
translate french halloween_prepare_sonyaroom_7fb491df:

    # gg "У тебя в стиле майнкрафта все, очень милая комната"
    gg "Tout est dans le style Minecraft, très belle pièce"

# game/special_events/halloween 2025.rpy:316
translate french halloween_prepare_sonyaroom_9dc8d94c:

    # Sonya "Да, у меня много игрушек осталось"
    Sonya "Oui, il me reste beaucoup de jouets"

# game/special_events/halloween 2025.rpy:317
translate french halloween_prepare_sonyaroom_1174b034:

    # gg "Чем то тебе помочь?"
    gg "Comment puis-je t'aider ?"

# game/special_events/halloween 2025.rpy:319
translate french halloween_prepare_sonyaroom_36233e2b:

    # Sonya "О можешь пожалуйста разложить остальные блоки"
    Sonya "Oh, peux-tu s'il te plaît disposer le reste des blocs ?"

# game/special_events/halloween 2025.rpy:321
translate french halloween_prepare_sonyaroom_51e25d01:

    # gg "Хорошо давай"
    gg "D'accord, je m'en occupe"

# game/special_events/halloween 2025.rpy:325
translate french halloween_prepare_sonyaroom_5b80a77c:

    # Sonya "Так это сюда"
    Sonya "Alors c'est ici"

# game/special_events/halloween 2025.rpy:331
translate french halloween_prepare_sonyaroom_5e22d509:

    # Sonya "О забыла я же еще кексов поставила"
    Sonya "Oh, j'oubliais, j'ai aussi sorti des cupcakes"

# game/special_events/halloween 2025.rpy:340
translate french halloween_prepare_bathroom_5d6a2459:

    # gg "Тук-Тук, к вам можно?"
    gg "Toc-toc, je peux entrer ?"

# game/special_events/halloween 2025.rpy:342
translate french halloween_prepare_bathroom_f77e9ebe:

    # Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "Oh, tu arrives juste à temps, j'étais sur le point de t'appeler, je veux accrocher un fantôme au-dessus de la salle de bain"

# game/special_events/halloween 2025.rpy:343
translate french halloween_prepare_bathroom_65af0236:

    # Kate "Но не достаю, вот"
    Kate "Mais je n'y arrive pas, le voici"

# game/special_events/halloween 2025.rpy:345
translate french halloween_prepare_bathroom_b38aeb93:

    # Kate "Вот, видишь?"
    Kate "Là, tu vois ?"

# game/special_events/halloween 2025.rpy:347
translate french halloween_prepare_bathroom_e0f0e638:

    # Kate "Хм . . . а если я встану на бортики ванной?"
    Kate "Hum. . . Et si je me tiens sur les bords de la baignoire ?"

# game/special_events/halloween 2025.rpy:349
translate french halloween_prepare_bathroom_e11f6927:

    # gg "Стой, это не безопасно"
    gg "Attends, ce n'est pas sûr"

# game/special_events/halloween 2025.rpy:358
translate french halloween_prepare_bathroom_01550c8f:

    # Kate "ААй!" with hpunch
    Kate "Aïe !" with hpunch

# game/special_events/halloween 2025.rpy:359
translate french halloween_prepare_bathroom_af26ae75:

    # Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    Kate "Oh, je suis trop ivre, quelle chance que tu sois là, merci"

# game/special_events/halloween 2025.rpy:361
translate french halloween_prepare_bathroom_78e2854b:

    # gg "Я так испугался за тебя"
    gg "J'avais tellement peur pour toi"

# game/special_events/halloween 2025.rpy:362
translate french halloween_prepare_bathroom_766703c6:

    # gg "За тобой глаз, да глаз, будь аккуратнее"
    gg "Il faut avoir l'œil sur toi, fais attention"

# game/special_events/halloween 2025.rpy:364
translate french halloween_prepare_bathroom_ef29b55b:

    # Kate "Хорошо, я обещаю . . ."
    Kate "D'accord, je le promets. . ."

# game/special_events/halloween 2025.rpy:366
translate french halloween_prepare_bathroom_61bd7d2f:

    # Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    Kate "Tu peux me lâcher maintenant ? Je n'y retournerai plus"

# game/special_events/halloween 2025.rpy:368
translate french halloween_prepare_bathroom_77a74e82:

    # gg "Ты такая легкая"
    gg "Tu es si légère"

# game/special_events/halloween 2025.rpy:370
translate french halloween_prepare_bathroom_a0e2f8bb:

    # Kate "Спасибо"
    Kate "Merci"

# game/special_events/halloween 2025.rpy:383
translate french halloween_prepare_myroom_5692ba1f:

    # gg "Эх устал я помогать всем девочкам, и так спать хотел"
    gg "Eh, je suis fatigué d'avoir aidé toutes les filles, et je voulais juste dormir"

# game/special_events/halloween 2025.rpy:385
translate french halloween_prepare_myroom_6e92de75:

    # gg "Думаю посплю часик"
    gg "Je pense que je vais dormir une heure"

# game/special_events/halloween 2025.rpy:400
translate french halloween_sonya_dream_8c6442c7:

    # gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "Je me réveille avec un bruit étrange, comme si quelqu'un avait passé un ongle sur du bois."

# game/special_events/halloween 2025.rpy:401
translate french halloween_sonya_dream_a05b8801:

    # gg_chat "Это на кухне?"
    gg_chat "Est-ce dans la cuisine ?"

# game/special_events/halloween 2025.rpy:403
translate french halloween_sonya_dream_514bb7b5:

    # gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "Je me dirige vers la cuisine en me frottant les yeux."

# game/special_events/halloween 2025.rpy:404
translate french halloween_sonya_dream_045482c0:

    # gg_chat "На столе - что-то, чего там не было"
    gg_chat "Il y a quelque chose sur la table qui n'était pas là"

# game/special_events/halloween 2025.rpy:405
translate french halloween_sonya_dream_e953cb07:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg_chat "Boîte.{w} Bois sombre, coins recouverts de métal rouge sang"

# game/special_events/halloween 2025.rpy:406
translate french halloween_sonya_dream_76809b89:

    # gg "Что за чёрт . . ."
    gg "Que diable. . ."

# game/special_events/halloween 2025.rpy:407
translate french halloween_sonya_dream_b5f93453:

    # gg_chat "Она не выглядит новой"
    gg_chat "Elle n'a pas l'air neuve"

# game/special_events/halloween 2025.rpy:408
translate french halloween_sonya_dream_5ac4f621:

    # gg_chat "Скорее наоборот - как будто ей сотни лет"
    gg_chat "Bien au contraire - comme si elle avait des centaines d'années"

# game/special_events/halloween 2025.rpy:413
translate french halloween_sonya_dream_a96a7298:

    # gg "Просто кто-то оставил{w} Мая? Соня?"
    gg "Quelqu'un l'a laissée ? Maya ? Sonya ?"

# game/special_events/halloween 2025.rpy:414
translate french halloween_sonya_dream_f60dffa6:

    # gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "C'est stupide, mais je touche quand même le couvercle"

# game/special_events/halloween 2025.rpy:415
translate french halloween_sonya_dream_7aa1f899:

    # gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    gg_chat "Chaleur.{w} Comme s'il y avait du cuir sous mes doigts, pas du bois"

# game/special_events/halloween 2025.rpy:418
translate french halloween_sonya_dream_d4c068d1:

    # gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg_chat "Il y a une pièce de monnaie à l'intérieur. Vieille, usée, un œil y est gravé, et les bords sont irréguliers, comme si quelqu'un l'avait mâchonnée."

# game/special_events/halloween 2025.rpy:419
translate french halloween_sonya_dream_891135f2:

    # gg "И всё? . . ."
    gg "C'est tout ? . . ."

# game/special_events/halloween 2025.rpy:421
translate french halloween_sonya_dream_5bbdc303:

    # gg "Ладно, пока возьму себе"
    gg "D'accord, je vais la prendre pour l'instant"

# game/special_events/halloween 2025.rpy:422
translate french halloween_sonya_dream_63ba62de:

    # gg_chat "Я поворачиваю её в пальцах"
    gg_chat "Je la tourne entre mes doigts"

# game/special_events/halloween 2025.rpy:423
translate french halloween_sonya_dream_60e7c398:

    # gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    gg_chat "Étrange lourdeur, comme si la pièce n'était pas faite de métal, mais de quelque chose de vivant"

# game/special_events/halloween 2025.rpy:427
translate french halloween_sonya_dream_b51c492c:

    # gg "Где же все?"
    gg "Où est tout le monde ?"

# game/special_events/halloween 2025.rpy:432
translate french halloween_sonya_dream_867b75aa:

    # gg "Чёрт. что за бред телевизор сам включился . . ."
    gg "Merde. Quelle absurdité, la télé s'est allumée toute seule. . ."

# game/special_events/halloween 2025.rpy:467
translate french halloween_sonya_dream_cfa5487f:

    # gg "Что за бред"
    gg "Quelle absurdité"

# game/special_events/halloween 2025.rpy:468
translate french halloween_sonya_dream_6ca44626:

    # gg "Нужно проверить остальные комнаты"
    gg "Il faut vérifier les autres pièces"

# game/special_events/halloween 2025.rpy:471
translate french halloween_sonya_dream_3109e8d5:

    # gg "Соня?"
    gg "Sonya ?"

# game/special_events/halloween 2025.rpy:473
translate french halloween_sonya_dream_af6b4c99:

    # gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    gg "Hé. . . il est tard, tu me fais peur, honnêtement"

# game/special_events/halloween 2025.rpy:476
translate french halloween_sonya_dream_f09531f9:

    # gg "Просто показалось . . ."
    gg "Je l'ai imaginé. . ."

# game/special_events/halloween 2025.rpy:477
translate french halloween_sonya_dream_6fecd311:

    # gg "Просто тень . . ."
    gg "Juste une ombre. . ."

# game/special_events/halloween 2025.rpy:484
translate french halloween_sonya_dream_b989363c:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:486
translate french halloween_sonya_dream_e5e215bc:

    # Sonya "Как ты посмел меня разбудить!" with hpunch
    Sonya "Comment oses-tu me réveiller !" with hpunch

# game/special_events/halloween 2025.rpy:488
translate french halloween_sonya_dream_cbf79f81:

    # gg "Соня, ты . . . {w}ты издеваешься? . . ."
    gg "Sonya, tu. . . {w}tu te moques de moi ? . . ."

# game/special_events/halloween 2025.rpy:490
translate french halloween_sonya_dream_ea23c51e:

    # gg "Это ты? Что это за грёбаные игры? . . ."
    gg "C'est toi ? C'est quoi ces putains de jeux ? . . ."

# game/special_events/halloween 2025.rpy:492
translate french halloween_sonya_dream_c5bc9963:

    # Sonya "Имя звучит знакомо"
    Sonya "Le nom semble familier"

# game/special_events/halloween 2025.rpy:493
translate french halloween_sonya_dream_4db18375:

    # Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    Sonya "Mais celle que tu as appelée est morte avec cette maison"

# game/special_events/halloween 2025.rpy:494
translate french halloween_sonya_dream_f5284849:

    # gg "Прекрати . . ."
    gg "Arrête. . ."

# game/special_events/halloween 2025.rpy:496
translate french halloween_sonya_dream_bf221ec2:

    # Sonya "Дом теперь мой.{w} Я - его хозяин"
    Sonya "La maison m'appartient désormais.{w} J'en suis le propriétaire"

# game/special_events/halloween 2025.rpy:498
translate french halloween_sonya_dream_2c4ebaa2:

    # Sonya "Боишься?"
    Sonya "Tu as peur ?"

# game/special_events/halloween 2025.rpy:499
translate french halloween_sonya_dream_0063da0b:

    # gg "Да . . ."
    gg "Oui. . ."

# game/special_events/halloween 2025.rpy:501
translate french halloween_sonya_dream_b67571be:

    # Sonya "Хорошо"
    Sonya "Bien"

# game/special_events/halloween 2025.rpy:503
translate french halloween_sonya_dream_14d503b0:

    # Sonya "Страх делает кровь живой"
    Sonya "La peur rend le sang vivant"

# game/special_events/halloween 2025.rpy:511
translate french halloween_sonya_dream_ab894d3a:

    # Sonya "Ты принёс монету?"
    Sonya "Tu as apporté la pièce ?"

# game/special_events/halloween 2025.rpy:515
translate french halloween_sonya_dream_c3bf29e7:

    # gg "Что? . . ."
    gg "Quoi ? . . ."

# game/special_events/halloween 2025.rpy:517
translate french halloween_sonya_dream_52cb176c:

    # Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "Un don qui était scellé. Tu l'as ouvert"

# game/special_events/halloween 2025.rpy:518
translate french halloween_sonya_dream_e3369996:

    # Sonya "Ты впустил меня"
    Sonya "Tu m'as laissé entrer"

# game/special_events/halloween 2025.rpy:520
translate french halloween_sonya_dream_1f166693:

    # Sonya "Я не Соня"
    Sonya "Je ne suis pas Sonya"

# game/special_events/halloween 2025.rpy:524
translate french halloween_sonya_dream_86fe7642:

    # Sonya "Я та, что носила её лицо"
    Sonya "C'est moi qui ai porté son visage"

# game/special_events/halloween 2025.rpy:525
translate french halloween_sonya_dream_625b9f75:

    # Sonya "И теперь ты мой"
    Sonya "Et maintenant tu es à moi"

# game/special_events/halloween 2025.rpy:527
translate french halloween_sonya_dream_0ac9332f:

    # Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    Sonya "Tout ce que tu avais peur de perdre. . . je l'ai déjà pris"

# game/special_events/halloween 2025.rpy:529
translate french halloween_sonya_dream_64ed8507:

    # Sonya "А теперь - перестань сопротивляться"
    Sonya "Maintenant arrête de résister"

# game/special_events/halloween 2025.rpy:533
translate french halloween_sonya_dream_9d9be648:

    # Sonya "Да . . . вот оно. Жар под кожей. Сок, который ты копил для кого-то другого. Теперь он мой"
    Sonya "Oui. . . voilà. La chaleur sous la peau. Le jus que tu gardais pour quelqu'un d'autre. Maintenant il est à moi"

# game/special_events/halloween 2025.rpy:534
translate french halloween_sonya_dream_709e3011:

    # Sonya "Я чувствую . . . как твоя суть отделяется от костей. Как светится . . . и течёт ко мне"
    Sonya "Je sens. . . comment ton essence se sépare de tes os. Comment elle brille. . . et coule vers moi"

# game/special_events/halloween 2025.rpy:535
translate french halloween_sonya_dream_5e3f412d:

    # Sonya "Скоро . . . скоро ты станешь пустым. Лёгким. И будешь спать"
    Sonya "Bientôt. . . bientôt tu seras vide. Léger. Et tu dormiras"

# game/special_events/halloween 2025.rpy:540
translate french halloween_sonya_dream_8f2a3a2a:

    # Sonya "Сейчас. Отдай мне последнюю искру. Тот всполох, что зовут экстазом… я приму его как дань"
    Sonya "Maintenant. Donne-moi ta dernière étincelle. Ce flash qu'on appelle l'extase... je l'accepterai comme un hommage"

# game/special_events/halloween 2025.rpy:543
translate french halloween_sonya_dream_279834b2:

    # Sonya "ДА! Вот . . . пылающая монета твоей души . . . я беру её!"
    Sonya "OUI ! Voilà. . . la pièce enflammée de ton âme. . . je la prends !"

# game/special_events/halloween 2025.rpy:546
translate french halloween_sonya_dream_feb25de8:

    # Sonya "Спи. В твоих снах будет песок. И глаза в темноте . . . мои глаза"
    Sonya "Dors. Il y aura du sable dans tes rêves. Et des yeux dans le noir. . . mes yeux"

# game/special_events/halloween 2025.rpy:549
translate french halloween_sonya_dream_dbd299d0:

    # Sonya "Может быть, я позову снова . . . когда проголодаюсь"
    Sonya "Peut-être que je t'appellerai à nouveau. . . quand j'aurai faim"

# game/special_events/halloween 2025.rpy:574
translate french halloween_maya_dream_032be6f2:

    # gg "Чёрт . . . {w}нет, нет, снова это . . ."
    gg "Merde . . . {w}non, non, encore ça. . ."

# game/special_events/halloween 2025.rpy:576
translate french halloween_maya_dream_ff7388e6:

    # Maya "Эй, спокойно"
    Maya "Hé, calme-toi"

# game/special_events/halloween 2025.rpy:578
translate french halloween_maya_dream_92686e55:

    # Maya "Ты в безопасности"
    Maya "Tu es en sécurité"

# game/special_events/halloween 2025.rpy:579
translate french halloween_maya_dream_edf9349e:

    # gg "Где я? . . ."
    gg "Où suis-je ? . . ."

# game/special_events/halloween 2025.rpy:580
translate french halloween_maya_dream_de23ff68:

    # gg "Что . . . что это за место?"
    gg "Quoi . . . quel genre d'endroit est-ce ?"

# game/special_events/halloween 2025.rpy:582
translate french halloween_maya_dream_75c561e6:

    # Maya "Мой дом"
    Maya "Ma maison"

# game/special_events/halloween 2025.rpy:584
translate french halloween_maya_dream_912b1ea9:

    # gg "Почему . . . я . . . здесь? . . ."
    gg "Pourquoi... je... suis ici ?..."

# game/special_events/halloween 2025.rpy:586
translate french halloween_maya_dream_05fc8512:

    # Maya "Потому что ты боялся"
    Maya "Parce que tu avais peur"

# game/special_events/halloween 2025.rpy:587
translate french halloween_maya_dream_657245c6:

    # Maya "И кто-то должен был тебя остановить"
    Maya "Et quelqu'un devait t'arrêter"

# game/special_events/halloween 2025.rpy:589
translate french halloween_maya_dream_dcba1503:

    # gg "Нет . . .{w} не приближайся"
    gg "Non... {w} ne t'approche pas"

# game/special_events/halloween 2025.rpy:590
translate french halloween_maya_dream_e91592a1:

    # gg "Я видел, как это начинается"
    gg "J'ai vu comment ça commence"

# game/special_events/halloween 2025.rpy:591
translate french halloween_maya_dream_d9b24014:

    # gg "Сначала свет, потом . . ."
    gg "D'abord la lumière, ensuite..."

# game/special_events/halloween 2025.rpy:594
translate french halloween_maya_dream_23c69478:

    # Maya "Никто не собирается тебя пугать"
    Maya "Personne ne va t'effrayer"

# game/special_events/halloween 2025.rpy:595
translate french halloween_maya_dream_fb15da85:

    # gg "Это сон?"
    gg "C'est un rêve ?"

# game/special_events/halloween 2025.rpy:597
translate french halloween_maya_dream_ef47f8b8:

    # Maya "Возможно"
    Maya "Peut-être"

# game/special_events/halloween 2025.rpy:598
translate french halloween_maya_dream_11e09330:

    # Maya "Но в этом сне тебе можно не убегать"
    Maya "Mais dans ce rêve, tu n'as pas besoin de fuir"

# game/special_events/halloween 2025.rpy:600
translate french halloween_maya_dream_e96ceee2:

    # Maya "Сядь.{w} Попробуй просто дышать"
    Maya "Assieds-toi.{w} Essaie juste de respirer"

# game/special_events/halloween 2025.rpy:601
translate french halloween_maya_dream_f1385d77:

    # gg "Я . . .{w} не могу"
    gg "Je... {w} je ne peux pas"

# game/special_events/halloween 2025.rpy:603
translate french halloween_maya_dream_38874e86:

    # Maya "Можешь{w}, начни только тихо"
    Maya "Tu peux{w}, commence doucement"

# game/special_events/halloween 2025.rpy:605
translate french halloween_maya_dream_4a1eadac:

    # Maya "Ты думал, я кто-то другой, да?"
    Maya "Tu pensais que j'étais quelqu'un d'autre, hein ?"

# game/special_events/halloween 2025.rpy:607
translate french halloween_maya_dream_8d83da3f:

    # gg "После всего . . ."
    gg "Après tout..."

# game/special_events/halloween 2025.rpy:608
translate french halloween_maya_dream_9aa85be5:

    # gg "Я и не знаю, кому верить"
    gg "Je ne sais plus qui croire"

# game/special_events/halloween 2025.rpy:609
translate french halloween_maya_dream_95a67e98:

    # Maya "Тогда не верь"
    Maya "Alors ne crois pas"

# game/special_events/halloween 2025.rpy:610
translate french halloween_maya_dream_cf12428b:

    # Maya "Просто смотри"
    Maya "Regarde juste"

# game/special_events/halloween 2025.rpy:614
translate french halloween_maya_dream_5da82532:

    # gg "Чувствуешь?{w} Здесь нет боли"
    gg "Tu sens ?{w} Il n'y a pas de douleur ici"

# game/special_events/halloween 2025.rpy:616
translate french halloween_maya_dream_df19ec31:

    # Maya "Ты дрожишь"
    Maya "Tu trembles"

# game/special_events/halloween 2025.rpy:617
translate french halloween_maya_dream_b989363c:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:620
translate french halloween_maya_dream_718947a3:

    # Maya "Бедный"
    Maya "Pauvre de toi"

# game/special_events/halloween 2025.rpy:622
translate french halloween_maya_dream_20c45a93:

    # Maya "Я давно не видела людей"
    Maya "Ça fait longtemps que je n'ai pas vu d'humains"

# game/special_events/halloween 2025.rpy:624
translate french halloween_maya_dream_0f6f1ec4:

    # Maya "Вот, видишь?{w} Уже лучше"
    Maya "Voilà, tu vois ?{w} Déjà mieux"

# game/special_events/halloween 2025.rpy:625
translate french halloween_maya_dream_1db499d0:

    # gg "Не знаю, что это.{w} Но уже лучше"
    gg "Je ne sais pas ce que c'est.{w} Mais c'est déjà mieux"

# game/special_events/halloween 2025.rpy:627
translate french halloween_maya_dream_927ad5b3:

    # Maya "Сейчас кое что тебя поставит на ноги"
    Maya "Maintenant, quelque chose va te remettre sur pied"

# game/special_events/halloween 2025.rpy:630
translate french halloween_maya_dream_9add8ae1:

    # Maya "Здесь только травы"
    Maya "Il n'y a que des herbes ici"

# game/special_events/halloween 2025.rpy:631
translate french halloween_maya_dream_338034af:

    # Maya "Лаванда, мята, немного корицы.{w} Попей"
    Maya "Lavande, menthe, un peu de cannelle.{w} Bois"

# game/special_events/halloween 2025.rpy:633
translate french halloween_maya_dream_8f20081e:

    # gg "Что это?"
    gg "Qu'est-ce que c'est ?"

# game/special_events/halloween 2025.rpy:634
translate french halloween_maya_dream_3fdb7032:

    # Maya "Это магия"
    Maya "C'est de la magie"

# game/special_events/halloween 2025.rpy:636
translate french halloween_maya_dream_7c4cba20:

    # Maya "Лечебное зелье, с небольшим побочным эфектом"
    Maya "Une potion curative, avec un petit effet secondaire"

# game/special_events/halloween 2025.rpy:638
translate french halloween_maya_dream_59e469a3:

    # gg "Каким еще эфектом"
    gg "Quel genre d'effet secondaire ?"

# game/special_events/halloween 2025.rpy:641
translate french halloween_maya_dream_809b7a3a:

    # Maya "Просто отдохни.{w} Не думай об этом"
    Maya "Repose-toi simplement.{w} N'y pense pas"

# game/special_events/halloween 2025.rpy:643
translate french halloween_maya_dream_ae92cf27:

    # gg "А если я снова усну?"
    gg "Et si je me rendors ?"

# game/special_events/halloween 2025.rpy:645
translate french halloween_maya_dream_c1fe7b6b:

    # Maya "Тогда пусть этот сон, будет приятным"
    Maya "Alors que ce rêve soit agréable"

# game/special_events/halloween 2025.rpy:650
translate french halloween_maya_dream_6274b812:

    # Maya "Да . . . вот так . . . Ты так нуждаешься в этом. Я знала"
    Maya "Oui... comme ça... Tu en as tellement besoin. Je le savais"

# game/special_events/halloween 2025.rpy:651
translate french halloween_maya_dream_c101e994:

    # gg "Майя . . . Я . . ."
    gg "Maya... Je..."

# game/special_events/halloween 2025.rpy:652
translate french halloween_maya_dream_5e852895:

    # Maya "Какая прекрасная . . . реакция. Всё для меня?"
    Maya "Quelle belle... réaction. Tout pour moi ?"

# game/special_events/halloween 2025.rpy:653
translate french halloween_maya_dream_cab511be:

    # Maya "О-ох . . . Да . . . Вот так"
    Maya "O-oh... Oui... Comme ça"

# game/special_events/halloween 2025.rpy:654
translate french halloween_maya_dream_87be51c0:

    # Maya "Да-да-да! Вот здесь! Чувствую, как ты пульсируешь!"
    Maya "Oui, oui, oui ! Juste là ! Je te sens palpiter !"

# game/special_events/halloween 2025.rpy:656
translate french halloween_maya_dream_aafdbf4d:

    # Maya "Aaa-ох . . ."
    Maya "Aaa-ah..."

# game/special_events/halloween 2025.rpy:659
translate french halloween_maya_dream_162eda56:

    # Maya "Идеально . . . Ты был идеален . . . Запомни это . . . Запомни меня . . ."
    Maya "Parfait... Tu étais parfait... Souviens-t'en... Souviens-toi de moi..."

# game/special_events/halloween 2025.rpy:687
translate french halloween_kate_dream_2a6a4db2:

    # gg "Кейт? . . ."
    gg "Kate ?..."

# game/special_events/halloween 2025.rpy:692
translate french halloween_kate_dream_3c8f411e:

    # gg "Что . . . что происходит?"
    gg "Quoi... qu'est-ce qui se passe ?"

# game/special_events/halloween 2025.rpy:696
translate french halloween_kate_dream_6b307304:

    # Kate "{sc}{size=*1.2}Ты"
    Kate "{sc}{size=*1.2}Toi"

# game/special_events/halloween 2025.rpy:698
translate french halloween_kate_dream_21111df8:

    # Kate "Вторгся в середину ритуала"
    Kate "Tu t'es introduit au milieu d'un rituel"

# game/special_events/halloween 2025.rpy:699
translate french halloween_kate_dream_2caa82ea:

    # Kate "Твоё присутствие нарушило поток"
    Kate "Ta présence a perturbé le flux"

# game/special_events/halloween 2025.rpy:701
translate french halloween_kate_dream_bc58cb35:

    # gg "Гх . . . {w}Прости, я не знал . . ."
    gg "Grh... {w}Désolé, je ne savais pas..."

# game/special_events/halloween 2025.rpy:703
translate french halloween_kate_dream_91b43246:

    # Kate "Ты не просто услышал. Ты почувствовал зов"
    Kate "Tu n'as pas simplement entendu. Tu as senti l'appel"

# game/special_events/halloween 2025.rpy:705
translate french halloween_kate_dream_211858ba:

    # Kate "Иначе ты бы не вошёл"
    Kate "Sinon tu ne serais pas entré"

# game/special_events/halloween 2025.rpy:707
translate french halloween_kate_dream_0f5b8117:

    # Kate "Люди носят маски каждый день"
    Kate "Les gens portent des masques tous les jours"

# game/special_events/halloween 2025.rpy:708
translate french halloween_kate_dream_4fc89b6e:

    # Kate "Они молятся свету, а в темноте становятся теми, кем боятся быть"
    Kate "Ils prient la lumière, et dans l'obscurité, ils deviennent ce qu'ils craignent d'être"

# game/special_events/halloween 2025.rpy:710
translate french halloween_kate_dream_fd7485b5:

    # gg "Кейт, пожалуйста . . . остановись"
    gg "Kate, s'il te plaît... arrête"

# game/special_events/halloween 2025.rpy:712
translate french halloween_kate_dream_21bb7ba7:

    # Kate "Это имя лишь оболочка, которую я носила"
    Kate "Ce nom n'est qu'une enveloppe que j'ai portée"

# game/special_events/halloween 2025.rpy:713
translate french halloween_kate_dream_54373c98:

    # Kate "Сейчас я — та, кто принимает исповедь. А исповедь требует . . . отдачи"
    Kate "Maintenant, je suis celle qui reçoit la confession. Et la confession exige... un don"

# game/special_events/halloween 2025.rpy:715
translate french halloween_kate_dream_6aceb243:

    # Kate "Ты боишься. Это хорошо. Страх очищает"
    Kate "Tu as peur. C'est bien. La peur purifie"

# game/special_events/halloween 2025.rpy:716
translate french halloween_kate_dream_6993148d:

    # Kate "Но за страхом . . . всегда прячется желание"
    Kate "Mais derrière la peur... se cache toujours le désir"

# game/special_events/halloween 2025.rpy:718
translate french halloween_kate_dream_5f463a3c:

    # Kate "Мой ритуал требует энергии. Чистой, незамутнённой лицемерием"
    Kate "Mon rituel nécessite de l'énergie. Pure, non entachée d'hypocrisie"

# game/special_events/halloween 2025.rpy:720
translate french halloween_kate_dream_e52aea01:

    # Kate "Твой страх — это начало. Но чтобы завершить круг . . . нужно"
    Kate "Ta peur est le commencement. Mais pour compléter le cercle... il faut"

# game/special_events/halloween 2025.rpy:722
translate french halloween_kate_dream_6c364d34:

    # Kate "Нечто большее"
    Kate "Quelque chose de plus"

# game/special_events/halloween 2025.rpy:725
translate french halloween_kate_dream_4729db36:

    # gg "Что ты хочешь? . . . "
    gg "Que veux-tu ?..."

# game/special_events/halloween 2025.rpy:727
translate french halloween_kate_dream_14ab3952:

    # Kate "Я хочу ту часть себя, которая не боится тьмы"
    Kate "Je veux la part de toi qui ne craint pas les ténèbres"

# game/special_events/halloween 2025.rpy:729
translate french halloween_kate_dream_d9bfbc43:

    # Kate "Которая жаждет её"
    Kate "Qui les désire"

# game/special_events/halloween 2025.rpy:730
translate french halloween_kate_dream_2a999a14:

    # Kate "Это не сердце. Это — пустота, которую ты пытался заполнить ложью"
    Kate "Ce n'est pas le cœur. C'est le vide que tu as essayé de combler avec des mensonges"

# game/special_events/halloween 2025.rpy:732
translate french halloween_kate_dream_62c66a6e:

    # Kate "Позволь мне заполнить её истиной"
    Kate "Laisse-moi le remplir avec la vérité"

# game/special_events/halloween 2025.rpy:733
translate french halloween_kate_dream_6f6518cc:

    # gg "Гхк . . ."
    gg "Grkh..."

# game/special_events/halloween 2025.rpy:734
translate french halloween_kate_dream_a32c9003:

    # gg "Я не могу подвинуться"
    gg "Je ne peux pas bouger"

# game/special_events/halloween 2025.rpy:736
translate french halloween_kate_dream_12b2e70f:

    # Kate "Не сопротивляйся. Это тоже часть ритуала"
    Kate "Ne résiste pas. Cela fait aussi partie du rituel"

# game/special_events/halloween 2025.rpy:738
translate french halloween_kate_dream_fd3fd304:

    # Kate "Ты отдаёшь — я принимаю. Так было всегда"
    Kate "Tu donnes - je reçois. Ça a toujours été ainsi"

# game/special_events/halloween 2025.rpy:740
translate french halloween_kate_dream_7cee1ec3:

    # Kate "Видишь? Твоё тело уже понимает. Оно помнит правила"
    Kate "Tu vois ? Ton corps comprend déjà. Il se souvient des règles"

# game/special_events/halloween 2025.rpy:753
translate french halloween_kate_dream_e36daadf:

    # Kate "Это дрожь . . . пробуждения"
    Kate "Ce frémissement... de l'éveil"

# game/special_events/halloween 2025.rpy:761
translate french halloween_kate_dream_18a21981:

    # Kate "Тише. Не мешай"
    Kate "Silence. Ne dérange pas"

# game/special_events/halloween 2025.rpy:762
translate french halloween_kate_dream_64b1ddea:

    # Kate "Я только знакомлюсь с тем, что моё"
    Kate "Je fais seulement connaissance avec ce qui est mien"

# game/special_events/halloween 2025.rpy:764
translate french halloween_kate_dream_fa83af8e:

    # Kate "Ты . . . для этого . . .{w} и пришёл . . ."
    Kate "Toi... pour ça...{w} tu es venu..."

# game/special_events/halloween 2025.rpy:765
translate french halloween_kate_dream_475590f4:

    # Kate "Чтоб тебя . . . размяли . . .{w} взяли в руки . . ."
    Kate "Pour que tu sois... malaxé...{w} pris en main..."

# game/special_events/halloween 2025.rpy:767
translate french halloween_kate_dream_020e238d:

    # gg "Агхх . ."
    gg "Arghh..."

# game/special_events/halloween 2025.rpy:768
translate french halloween_kate_dream_0c86ca7b:

    # Kate "Да!"
    Kate "Oui !"

# game/special_events/halloween 2025.rpy:769
translate french halloween_kate_dream_d0b4a1d1:

    # Kate "Вот так"
    Kate "Comme ça"

# game/special_events/halloween 2025.rpy:770
translate french halloween_kate_dream_854a0208:

    # Kate "Рвись! Кончай!{w} Отдавай это мне"
    Kate "Éclate ! Jouis !{w} Donne-le-moi"

# game/special_events/halloween 2025.rpy:772
translate french halloween_kate_dream_4402c96f:

    # Kate "Ахахаха ха ха"
    Kate "Ahahaha ha ha"

# game/special_events/halloween 2025.rpy:774
translate french halloween_kate_dream_c8fc9712:

    # Kate "Видишь? Даже твой пик — в моей власти"
    Kate "Tu vois ? Même ton pic est en mon pouvoir"

# game/special_events/halloween 2025.rpy:775
translate french halloween_kate_dream_ab9b9a56:

    # Kate "Я решаю когда и как"
    Kate "Je décide quand et comment"

# game/special_events/halloween 2025.rpy:777
translate french halloween_kate_dream_d8951333:

    # Kate "А теперь хватит игр"
    Kate "Et maintenant, assez joué"

# game/special_events/halloween 2025.rpy:786
translate french halloween_kate_dream_088e1fcf:

    # Kate "Всё, время нежностей кончилось"
    Kate "Voilà, le temps des tendresses est fini"

# game/special_events/halloween 2025.rpy:789
translate french halloween_kate_dream_d84a2e22:

    # Kate "Молчи и терпи. Это плата за твой глупый интерес"
    Kate "Tais-toi et endure. C'est le prix de ton intérêt stupide"

# game/special_events/halloween 2025.rpy:791
translate french halloween_kate_dream_959b5201:

    # Kate "А-ах . . . Так . . . Глубоко . . ."
    Kate "A-ah... Si... Profondément..."

# game/special_events/halloween 2025.rpy:794
translate french halloween_kate_dream_ad7fd02e:

    # Kate "Да . . . Вот так"
    Kate "Oui... Comme ça"

# game/special_events/halloween 2025.rpy:795
translate french halloween_kate_dream_e0d93040:

    # Kate "Отдай мне это.{w} Всю свою подавленную тьму.{w} Всю свою скрытую жажду"
    Kate "Donne-le-moi.{w} Toutes tes ténèbres refoulées.{w} Toute ta soif cachée"

# game/special_events/halloween 2025.rpy:796
translate french halloween_kate_dream_3f099ced:

    # gg "Я . . . я не могу . . ."
    gg "Je... je ne peux pas..."

# game/special_events/halloween 2025.rpy:797
translate french halloween_kate_dream_0e94451f:

    # Kate "Можешь. И ты сделаешь.{w} Сейчас"
    Kate "Tu peux. Et tu le feras.{w} Maintenant"

# game/special_events/halloween 2025.rpy:800
translate french halloween_kate_dream_866aa006:

    # Kate "А-ах . . ."
    Kate "A-ah..."

# game/special_events/halloween 2025.rpy:802
translate french halloween_kate_dream_25c1049a:

    # Kate "Ха.."
    Kate "Ha.."

# game/special_events/halloween 2025.rpy:804
translate french halloween_kate_dream_c4c58437:

    # Kate "Ритуал завершён. Ты отдал достаточно . . . чтобы я продолжила свой путь"
    Kate "Le rituel est achevé. Tu as donné assez... pour que je continue mon chemin"

# game/special_events/halloween 2025.rpy:806
translate french halloween_kate_dream_c5ab54b2:

    # Kate "Ты проснёшься пустым.{w} Безнадёжно пустым. И, может быть, снова выползешь ко мне . . ."
    Kate "Tu te réveilleras vide.{w} Désespérément vide. Et peut-être que tu ramperas vers moi à nouveau..."

# game/special_events/halloween 2025.rpy:807
translate french halloween_kate_dream_0eb6bd42:

    # Kate "Чтобы снова украсть немного этой полноты"
    Kate "Pour voler à nouveau un peu de cette plénitude"

# game/special_events/halloween 2025.rpy:809
translate french halloween_kate_dream_2f7f297c:

    # Kate "Хотя бы на мгновение"
    Kate "Au moins pour un instant"

# game/special_events/halloween 2025.rpy:832
translate french halloween_kate_dream_b989363c:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:833
translate french halloween_kate_dream_5174a63c:

    # gg "Приснится же такое . . ."
    gg "Faire un rêve pareil..."

# game/special_events/halloween 2025.rpy:835
translate french halloween_kate_dream_13dee7c8:

    # "Тыква хранит воспоминания"
    "La citrouille garde les souvenirs"

# game/special_events/halloween 2025.rpy:836
translate french halloween_kate_dream_bb8e42de:

    # "Коснись её, чтобы вновь увидеть сцену"
    "Touche-la pour revoir la scène"

translate french strings:

    # game/special_events/halloween 2025.rpy:15
    old "Сон с Кейт"
    new "Rêve avec Kate"

# TODO: Translation updated at 2026-01-27 02:10

# game/special_events/halloween 2025.rpy:727
translate french halloween_kate_dream_195da2d7:

    # Kate "Я хочу ту часть тебя, которая не боится тьмы"
    Kate "Je veux la partie de toi qui ne craint pas les ténèbres"

