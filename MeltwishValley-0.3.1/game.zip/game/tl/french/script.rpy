﻿# TODO: Translation updated at 2026-01-21 13:15

# game/script.rpy:25
translate french start_fe40380a:

    # "Вы уже играли в нашу игру раньше?"
    "Avez-vous déjà joué à notre jeu ?"

# game/script.rpy:26
translate french start_dc363420:

    # "Интро содержит важные сюжетные события и знакомство с миром игры"
    "L'intro contient des événements importants de l'intrigue et une introduction au monde du jeu."

# game/script.rpy:27
translate french start_96a117ce:

    # "Если пропустить его при первом прохождении, вы рискуете упустить значительную часть истории и контента"
    "Si vous l'ignorez lors de votre première partie, vous risquez de passer à côté d'une partie importante de l'histoire et du contenu."

translate french strings:

    # game/script.rpy:15
    old "И как же вас зовут"
    new "Et quel est ton nom ?"

    # game/script.rpy:17
    old "Дэн"
    new "Dan"

    # game/script.rpy:29
    old "Начать игру"
    new "Commencer le jeu"

    # game/script.rpy:31
    old "Пропустить интро"
    new "Passer l'introduction"

