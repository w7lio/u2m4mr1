﻿# TODO: Translation updated at 2026-01-21 13:15

translate french strings:

    # game/screens.rpy:427
    old "Назад"
    new "Retour"

    # game/screens.rpy:429
    old "Пропуск"
    new "Passer"

    # game/screens.rpy:430
    old "Авто"
    new "Auto"

    # game/screens.rpy:431
    old "Сохранить"
    new "Sauvegarder"

    # game/screens.rpy:432
    old "Б.Сохр"
    new "Sauv. rapide"

    # game/screens.rpy:433
    old "Б.Загр"
    new "Charg. rapide"

    # game/screens.rpy:434
    old "Настройки"
    new "Paramètres"

    # game/screens.rpy:583
    old "НОВАЯ ИГРА"
    new "NOUVELLE PARTIE"

    # game/screens.rpy:584
    old "ЗАГРУЗИТЬ"
    new "CHARGER"

    # game/screens.rpy:585
    old "НАСТРОЙКИ"
    new "PARAMÈTRES"

    # game/screens.rpy:586
    old "О ИГРЕ"
    new "À PROPOS DU JEU"

    # game/screens.rpy:593
    old "ИСТОРИЯ"
    new "HISTOIRE"

    # game/screens.rpy:594
    old "СОХРАНИТЬ"
    new "SAUVEGARDER"

    # game/screens.rpy:599
    old "ЗАВЕРШИТЬ ПОВТОР"
    new "FIN DE LA RÉPÉTITION"

    # game/screens.rpy:601
    old "МЕНЮ"
    new "MENU"

    # game/screens.rpy:606
    old "ВЫХОД"
    new "SORTIE"

    # game/screens.rpy:758
    old "Вернуться"
    new "Retour"

    # game/screens.rpy:912
    old "Версия [config.version!t]\n"
    new "Version [config.version!t]\n"

    # game/screens.rpy:951
    old "{} страница"
    new "{} page"

    # game/screens.rpy:951
    old "Автосохранения"
    new "Sauvegarde automatique"

    # game/screens.rpy:951
    old "Быстрые сохранения"
    new "Sauvegardes rapides"

    # game/screens.rpy:999
    old "{#file_time}%A, %d %B %Y, %H:%M"
    new "{#file_time}%A, %d %B %Y, %H :%M"

    # game/screens.rpy:999
    old "Пустой слот"
    new "Emplacement vide"

    # game/screens.rpy:1020
    old "<"
    new "<"

    # game/screens.rpy:1024
    old "{#auto_page}А"
    new "{#auto_page}Un"

    # game/screens.rpy:1027
    old "{#quick_page}Б"
    new "{#quick_page}B"

    # game/screens.rpy:1033
    old ">"
    new ">"

    # game/screens.rpy:1105
    old "Всего текста"
    new "Tout le texte"

    # game/screens.rpy:1106
    old "После выборов"
    new "Après les choix"

    # game/screens.rpy:1112
    old "Режим экрана"
    new "Mode d'affichage"

    # game/screens.rpy:1113
    old "Оконный"
    new "Fenêtre"

    # game/screens.rpy:1114
    old "Полный"
    new "Complet"

    # game/screens.rpy:1118
    old "Язык"
    new "Langue"

    # game/screens.rpy:1151
    old "Скорость текста"
    new "Vitesse du texte"

    # game/screens.rpy:1155
    old "Скорость авточтения"
    new "Vitesse de lecture automatique"

    # game/screens.rpy:1159
    old "Прозрачность окна"
    new "Transparence de la fenêtre"

    # game/screens.rpy:1165
    old "Громкость музыки"
    new "Volume de la musique"

    # game/screens.rpy:1172
    old "Громкость звуков"
    new "Volume sonore"

    # game/screens.rpy:1178
    old "Тест"
    new "Test"

    # game/screens.rpy:1182
    old "Громкость голоса"
    new "Volume de la voix"

    # game/screens.rpy:1193
    old "Без звука"
    new "Pas de son"

    # game/screens.rpy:1378
    old "История диалогов пуста."
    new "L'historique des dialogues est vide."

    # game/screens.rpy:1621
    old "Ты правда хочешь выйти"
    new "Veux-tu vraiment sortir"

    # game/screens.rpy:1628
    old "Да"
    new "Oui"

    # game/screens.rpy:1632
    old "Нет"
    new "Non"

    # game/screens.rpy:1686
    old "Пропускаю"
    new "je saute"

    # game/screens.rpy:1997
    old "Меню"
    new "Menu"

    # game/screens.rpy:2362
    old "д"
    new "d"

    # game/screens.rpy:2488
    old "Персонажи"
    new "Personnages"

    # game/screens.rpy:2608
    old "Подсказка"
    new "Indice"

    # game/screens.rpy:2627
    old "Отслеживать квест"
    new "Quête de suivi"

    # game/screens.rpy:2636
    old "Перестать отслеживать"
    new "Arrêter le suivi"

    # game/screens.rpy:2657
    old "Продвигайтесь по сюжету"
    new "Progresser dans l'histoire"

# TODO: Translation updated at 2026-01-27 02:10

translate french strings:

    # game/screens.rpy:574
    old "ИГРАЙ РАНЬШЕ ДРУГИХ"
    new "JEU EN AVANT-PREMIÈRE"

# TODO: Translation updated at 2026-01-27 02:18

translate french strings:

    # game/screens.rpy:602
    old "Бесплатные девлоги"
    new "Devlogs gratuits"

