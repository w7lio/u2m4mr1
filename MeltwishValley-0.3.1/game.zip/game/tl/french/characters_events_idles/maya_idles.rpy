﻿# TODO: Translation updated at 2026-01-21 13:15

# game/characters_events_idles/maya_idles.rpy:7
translate french maya_Idle_day_myroom_scene_5a17c289:

    # gg "А я думал, этот предатель спит только у Сони"
    gg "Je pensais que ce traître ne dormait que chez Sonya"

# game/characters_events_idles/maya_idles.rpy:9
translate french maya_Idle_day_myroom_scene_67e33434:

    # Maya "Он выбирает по настроению"
    Maya "Il choisit selon son humeur"

# game/characters_events_idles/maya_idles.rpy:10
translate french maya_Idle_day_myroom_scene_d5b84977:

    # Maya "Сегодня, видимо, у меня нужная температура коленей"
    Maya "Aujourd'hui, apparemment, mes genoux ont la bonne température"

# game/characters_events_idles/maya_idles.rpy:11
translate french maya_Idle_day_myroom_scene_60432ccb:

    # gg "Или просто знаешь, чем подкупить"
    gg "Ou tu sais juste comment soudoyer"

# game/characters_events_idles/maya_idles.rpy:13
translate french maya_Idle_day_myroom_scene_e3e70aea:

    # Maya "Конечно"
    Maya "Certainement"

# game/characters_events_idles/maya_idles.rpy:14
translate french maya_Idle_day_myroom_scene_d43eb27c:

    # Maya "Я его нашла - я и лицензированный поставщик любви и корма"
    Maya "Je l'ai trouvé - moi et un fournisseur agréé d'amour et de nourriture"

# game/characters_events_idles/maya_idles.rpy:15
translate french maya_Idle_day_myroom_scene_567c8898:

    # gg "Нашла?"
    gg "Où l'as-tu trouvé ?"

# game/characters_events_idles/maya_idles.rpy:17
translate french maya_Idle_day_myroom_scene_a785c258:

    # Maya "Год назад. Под дождём, под машиной сидел"
    Maya "Il y a un an. Sous la pluie, assis sous la voiture"

# game/characters_events_idles/maya_idles.rpy:18
translate french maya_Idle_day_myroom_scene_81fc3249:

    # Maya "Маленький, грязный, дрожал, а я шла домой с кофе"
    Maya "Petit, sale, tremblant, et je rentrais chez moi avec du café"

# game/characters_events_idles/maya_idles.rpy:19
translate french maya_Idle_day_myroom_scene_f0aa2ab7:

    # Maya "И подумала: “Ладно, кофе подождёт”"
    Maya "Et j'ai pensé : \"D'accord, le café peut attendre.\""

# game/characters_events_idles/maya_idles.rpy:21
translate french maya_Idle_day_myroom_scene_8924b2a5:

    # Maya "С тех пор он решил, что я его персональный обогреватель"
    Maya "Depuis, il a décidé que j'étais son radiateur personnel"

# game/characters_events_idles/maya_idles.rpy:23
translate french maya_Idle_day_myroom_scene_38f294e2:

    # gg "Повезло ему"
    gg "Il a de la chance"

# game/characters_events_idles/maya_idles.rpy:25
translate french maya_Idle_day_myroom_scene_1538c3c1:

    # Maya "Ага. Только не говори Соне, что я так сказала"
    Maya "Ouais. Ne dis pas à Sonya que je l'ai dit"

# game/characters_events_idles/maya_idles.rpy:26
translate french maya_Idle_day_myroom_scene_d9ab69f9:

    # Maya "Она делает вид, что ей всё равно, но я видела, как она однажды сушила ему лапы феном"
    Maya "Elle fait semblant de s’en moquer, mais je l’ai vue un jour lui sécher les pattes au sèche-cheveux"

# game/characters_events_idles/maya_idles.rpy:27
translate french maya_Idle_day_myroom_scene_5e0ad0a7:

    # gg "Правда? Не ожидал"
    gg "Est-ce vrai ? Je ne m'y attendais pas"

# game/characters_events_idles/maya_idles.rpy:28
translate french maya_Idle_day_myroom_scene_e31c6d2d:

    # Maya "Ну, она просто не из тех, кто сюсюкает. Но и не выгонит"
    Maya "Eh bien, elle n'est tout simplement pas du genre à zozoter. Mais elle ne le mettra pas dehors non plus"

# game/characters_events_idles/maya_idles.rpy:29
translate french maya_Idle_day_myroom_scene_5e1c1537:

    # Maya "Иногда подкармливает, когда думает, что я не вижу"
    Maya "Parfois, elle le nourrit quand elle pense que je ne peux pas voir"

# game/characters_events_idles/maya_idles.rpy:30
translate french maya_Idle_day_myroom_scene_dd7932db:

    # Maya "У нас, знаешь, баланс: я - шум, она - порядок, а Барсик - нейтральная территория"
    Maya "Tu sais, nous avons un équilibre : je suis le bruit, elle est l'ordre, et Barsik est le territoire neutre"

# game/characters_events_idles/maya_idles.rpy:31
translate french maya_Idle_day_myroom_scene_ff61f178:

    # gg "И кто из вас лидер?"
    gg "Et lequel d’entre vous est le leader ?"

# game/characters_events_idles/maya_idles.rpy:33
translate french maya_Idle_day_myroom_scene_4579d2be:

    # Maya "Он. Сто процентов"
    Maya "Lui. À cent pour cent"

# game/characters_events_idles/maya_idles.rpy:34
translate french maya_Idle_day_myroom_scene_73c39706:

    # Maya "Ему всё равно, кто орёт, кто убирает - он всё равно получает своё место и миску"
    Maya "Il ne se soucie pas de savoir qui crie ou qui nettoie : il a toujours sa place et son bol."

# game/characters_events_idles/maya_idles.rpy:36
translate french maya_Idle_day_myroom_scene_c39583ae:

    # Maya "Видишь? {w}Даже в доме с нами двумя кто-то умеет быть по-настоящему счастливым"
    Maya "Tu comprends ? {w}Même dans une maison où nous sommes toutes les deux, quelqu'un sait être vraiment heureux"

# game/characters_events_idles/maya_idles.rpy:38
translate french maya_Idle_day_myroom_scene_04531df3:

    # gg "Может, секрет в том, чтобы просто мурчать и не спорить"
    gg "Peut-être que le secret consiste simplement à ronronner et à ne pas discuter."

# game/characters_events_idles/maya_idles.rpy:39
translate french maya_Idle_day_myroom_scene_25a0e3ac:

    # Maya "Или в том, чтобы спать на тёплом и не думать"
    Maya "Ou est-ce de dormir au chaud et de ne pas penser"

# game/characters_events_idles/maya_idles.rpy:54
translate french maya_Idle_morning_myroom_scene_323bf253:

    # gg "Уже читаешь? . . ."
    gg "Tu lis déjà ? . . ."

# game/characters_events_idles/maya_idles.rpy:55
translate french maya_Idle_morning_myroom_scene_92e4f307:

    # Maya "Ага. Утро тихое, редкость"
    Maya "Ouais. Les matins calmes sont rares"

# game/characters_events_idles/maya_idles.rpy:56
translate french maya_Idle_morning_myroom_scene_43a1c1b0:

    # Maya "Грех не пользоваться, пока никто не шумит и не ищет кружку"
    Maya "C’est un péché de ne pas l’utiliser alors que personne ne fait de bruit ou ne cherche une tasse."

# game/characters_events_idles/maya_idles.rpy:57
translate french maya_Idle_morning_myroom_scene_7ac1c8ed:

    # gg "Что на этот раз?"
    gg "Que lis-tu à cette heure ?"

# game/characters_events_idles/maya_idles.rpy:59
translate french maya_Idle_morning_myroom_scene_6a78f6bb:

    # Maya "Манга"
    Maya "Un mangas"

# game/characters_events_idles/maya_idles.rpy:60
translate french maya_Idle_morning_myroom_scene_932f7db6:

    # Maya "После Линдиных книг захотелось чего-то полегче"
    Maya "Après les livres de Linda, je voulais quelque chose de plus léger"

# game/characters_events_idles/maya_idles.rpy:62
translate french maya_Idle_morning_myroom_scene_cffdb9b8:

    # Maya "Она могла читать про философию даже за ужином"
    Maya "Elle pouvait lire sur la philosophie même au dîner"

# game/characters_events_idles/maya_idles.rpy:63
translate french maya_Idle_morning_myroom_scene_3d9df54a:

    # Maya "Я же за ужином максимум комментирую философию людей в интернете"
    Maya "Pendant le dîner, je commente tout au plus la philosophie des internautes."

# game/characters_events_idles/maya_idles.rpy:65
translate french maya_Idle_morning_myroom_scene_c6ff46fa:

    # Maya "Хотя по этой манге не скажешь"
    Maya "Même si on ne peut pas le dire à partir de ce manga"

# game/characters_events_idles/maya_idles.rpy:66
translate french maya_Idle_morning_myroom_scene_5ff05dc4:

    # Maya "Автор явно страдал, но красиво"
    Maya "L'auteur a clairement souffert, mais magnifiquement"

# game/characters_events_idles/maya_idles.rpy:67
translate french maya_Idle_morning_myroom_scene_f96de996:

    # gg "К картинкам и эмоциям?"
    gg "Aux images et aux émotions ?"

# game/characters_events_idles/maya_idles.rpy:69
translate french maya_Idle_morning_myroom_scene_b2396673:

    # Maya "К историям, где герои хотя бы честные"
    Maya "Aux histoires où les héros sont au moins honnêtes"

# game/characters_events_idles/maya_idles.rpy:71
translate french maya_Idle_morning_myroom_scene_6e6a997d:

    # Maya "Иногда читаю японское или корейское"
    Maya "Parfois je lis du japonais ou du coréen"

# game/characters_events_idles/maya_idles.rpy:72
translate french maya_Idle_morning_myroom_scene_3aeeaab4:

    # Maya "У них всё немного грустно, но по-тёплому"
    Maya "Tout est un peu triste chez eux, mais de manière chaleureuse"

# game/characters_events_idles/maya_idles.rpy:73
translate french maya_Idle_morning_myroom_scene_d16d1737:

    # Maya "В отличие от наших драм, где все страдают просто из принципа"
    Maya "Contrairement à nos drames, où tout le monde souffre simplement par principe"

# game/characters_events_idles/maya_idles.rpy:74
translate french maya_Idle_morning_myroom_scene_0bb250f6:

    # gg "Под настроение, значит"
    gg "Ça dépend de l’humeur, alors"

# game/characters_events_idles/maya_idles.rpy:76
translate french maya_Idle_morning_myroom_scene_bc0bb57f:

    # Maya "Угу. Когда настроение “оставьте меня в покое, но с уютом”"
    Maya "Oui. Quand l’ambiance est « laisse-moi tranquille, mais avec du réconfort »"

# game/characters_events_idles/maya_idles.rpy:77
translate french maya_Idle_morning_myroom_scene_c92c399c:

    # gg "Ты давно здесь?"
    gg "Depuis combien de temps es-tu ici ?"

# game/characters_events_idles/maya_idles.rpy:79
translate french maya_Idle_morning_myroom_scene_8b0e76c6:

    # Maya "Год, может чуть больше"
    Maya "Un an, peut-être un peu plus"

# game/characters_events_idles/maya_idles.rpy:80
translate french maya_Idle_morning_myroom_scene_924b98a2:

    # Maya "После универа приехала в посёлок работать. Захотелось тишины и воздуха"
    Maya "Après l'université, je suis venu au village pour travailler. Je voulais du silence et de l'air"

# game/characters_events_idles/maya_idles.rpy:82
translate french maya_Idle_morning_myroom_scene_f611f1fe:

    # Maya "Искала жильё - наткнулась на объявление: “Сдам комнату. Дом с садом”"
    Maya "Je cherchais un logement et suis tombé sur une annonce : \"Chambre à louer. Maison avec jardin\"."

# game/characters_events_idles/maya_idles.rpy:83
translate french maya_Idle_morning_myroom_scene_12f76597:

    # Maya "Открывает дверь Линда и спрашивает: “Ты громкая?”"
    Maya "Linda ouvre la porte et demande : « Êtes-vous bruyant ?"

# game/characters_events_idles/maya_idles.rpy:84
translate french maya_Idle_morning_myroom_scene_5517b596:

    # Maya "Я ответила: “Только когда думаю.” Она засмеялась и сказала: “Тогда уживайся”"
    Maya "J'ai répondu : \"Seulement quand je réfléchis.\" Elle a ri et a dit : « Alors, vas-y."

# game/characters_events_idles/maya_idles.rpy:85
translate french maya_Idle_morning_myroom_scene_20b975de:

    # gg "И Соня уже тут была?"
    gg "Et Sonya était déjà là ?"

# game/characters_events_idles/maya_idles.rpy:87
translate french maya_Idle_morning_myroom_scene_37745fdb:

    # Maya "Да. Мы познакомились на кухне, где я чуть не спалила чайник"
    Maya "Oui. On s'est rencontré dans la cuisine, où j'ai failli brûler la bouilloire"

# game/characters_events_idles/maya_idles.rpy:88
translate french maya_Idle_morning_myroom_scene_4e7209b5:

    # Maya "С тех пор она - порядок, я - импровизация"
    Maya "Depuis elle est à l'ordre, j'improvise"

# game/characters_events_idles/maya_idles.rpy:89
translate french maya_Idle_morning_myroom_scene_f337d502:

    # Maya "Иногда даже чай кипит от ужаса"
    Maya "Parfois même le thé bout d'horreur"

# game/characters_events_idles/maya_idles.rpy:90
translate french maya_Idle_morning_myroom_scene_b1814b27:

    # Maya "Линда звала нас “шум и тишина”"
    Maya "Linda nous a appelé « bruit et silence »"

# game/characters_events_idles/maya_idles.rpy:91
translate french maya_Idle_morning_myroom_scene_ab4dac88:

    # Maya "Хотя, скорее, “тишина и источник хаоса”"
    Maya "Bien que plutôt « le silence et la source du chaos »"

# game/characters_events_idles/maya_idles.rpy:92
translate french maya_Idle_morning_myroom_scene_f2159d17:

    # gg "А теперь ещё и я"
    gg "Et maintenant moi aussi"

# game/characters_events_idles/maya_idles.rpy:94
translate french maya_Idle_morning_myroom_scene_ecb2ad9f:

    # Maya "Теперь да. Баланс окончательно нарушен, но зато весело"
    Maya "Maintenant oui. L'équilibre est complètement bouleversé, mais c'est amusant"

# game/characters_events_idles/maya_idles.rpy:96
translate french maya_Idle_morning_myroom_scene_cea1d0c9:

    # Maya "Вон, слышишь? Она уже с шести на ногах"
    Maya "Écoute, tu entends ? Elle est debout depuis l'âge de six ans"

# game/characters_events_idles/maya_idles.rpy:97
translate french maya_Idle_morning_myroom_scene_deefee09:

    # Maya "Я так пробовала - уснула прямо с кружкой в руке"
    Maya "J'ai essayé ça - je me suis endormi avec une tasse à la main"

# game/characters_events_idles/maya_idles.rpy:98
translate french maya_Idle_morning_myroom_scene_bd135488:

    # Maya "Зато хоть кто-то следит, чтобы дом не просыпался в хаосе. Я - больше за безделие"
    Maya "Mais au moins quelqu’un veille à ce que la maison ne se réveille pas dans le chaos. je suis plutôt pour le farniente"

# game/characters_events_idles/maya_idles.rpy:113
translate french maya_Idle_evening_bathroom_scene_d8fba7e0:

    # gg "Ко сну готовишься?"
    gg "Est-ce que tu te prépares à aller au lit ?"

# game/characters_events_idles/maya_idles.rpy:114
translate french maya_Idle_evening_bathroom_scene_768e9905:

    # Maya "Ага. Осталось немного. Главное, чтобы никто не отвлекал"
    Maya "Ouais. Il ne reste plus grand chose. L'essentiel est que personne ne distrait"

# game/characters_events_idles/maya_idles.rpy:115
translate french maya_Idle_evening_bathroom_scene_c84b09d3:

    # Maya "А то всё придётся начинать заново — тут процесс деликатный"
    Maya "Sinon, il faudra tout recommencer, c'est un processus délicat"

# game/characters_events_idles/maya_idles.rpy:116
translate french maya_Idle_evening_bathroom_scene_ff89b4d4:

    # gg "Надеюсь, ты не про стирку опять"
    gg "J'espère que tu ne parles plus de lessive"

# game/characters_events_idles/maya_idles.rpy:118
translate french maya_Idle_evening_bathroom_scene_63a219ac:

    # Maya "А что, если и про неё? Не все вещи выдерживают жёсткий режим"
    Maya "Et si c'était à propos d'elle ? Tout ne peut pas résister à des conditions difficiles"

# game/characters_events_idles/maya_idles.rpy:119
translate french maya_Idle_evening_bathroom_scene_16a58674:

    # gg "В прошлый раз ты, кажется, не всё достирала"
    gg "La dernière fois, on dirait que tu n'as pas tout fini"

# game/characters_events_idles/maya_idles.rpy:121
translate french maya_Idle_evening_bathroom_scene_6782c239:

    # Maya "Ха. Ну, издержки ручной работы. Зато результат запомнился, верно?"
    Maya "Ha. Eh bien, les coûts du travail manuel. Mais le résultat était mémorable, non ?"

# game/characters_events_idles/maya_idles.rpy:122
translate french maya_Idle_evening_bathroom_scene_d25c24db:

    # gg "Даже слишком"
    gg "Même trop"

# game/characters_events_idles/maya_idles.rpy:124
translate french maya_Idle_evening_bathroom_scene_a5bb0cfc:

    # Maya "Значит, не зря старалась"
    Maya "Ce n'est donc pas en vain que j'ai essayé"

# game/characters_events_idles/maya_idles.rpy:126
translate french maya_Idle_evening_bathroom_scene_91354786:

    # Maya "Правда, немного смущалась. Такое со мной редко бывает"
    Maya "C'est vrai, j'étais un peu gêné. Cela m'arrive rarement"

# game/characters_events_idles/maya_idles.rpy:127
translate french maya_Idle_evening_bathroom_scene_2b597177:

    # gg "Удивительно. Я думал, ты вообще не из тех, кто смущается"
    gg "Merveilleux. Je pensais que tu n'étais pas du tout du genre à être gêné"

# game/characters_events_idles/maya_idles.rpy:129
translate french maya_Idle_evening_bathroom_scene_aa3db339:

    # Maya "Все когда-то ошибаются. Но не переживай, в следующий раз я компенсирую моральный ущерб"
    Maya "Tout le monde fait des erreurs parfois. Mais ne t'inquiète pas, la prochaine fois je compenserai le préjudice moral"

# game/characters_events_idles/maya_idles.rpy:130
translate french maya_Idle_evening_bathroom_scene_ed2cbd06:

    # gg "Это угроза или обещание?"
    gg "Est-ce une menace ou une promesse ?"

# game/characters_events_idles/maya_idles.rpy:132
translate french maya_Idle_evening_bathroom_scene_0f1383f3:

    # Maya "Назови это приглашением на повторный эксперимент"
    Maya "Appeles ça une invitation à réessayer"

# game/characters_events_idles/maya_idles.rpy:147
translate french maya_Idle_morning_kitchen_scene_ff259315:

    # gg "Это так теперь готовят яищницу?"
    gg "C'est comme ça qu'on cuisine les œufs brouillés maintenant ?"

# game/characters_events_idles/maya_idles.rpy:148
translate french maya_Idle_morning_kitchen_scene_2a72a3a2:

    # Maya "Умник. Не все рождаются с магией кулинарии, ладно?"
    Maya "Un gars intelligent. Tout le monde n'est pas né avec la magie de la cuisine, d'accord ?"

# game/characters_events_idles/maya_idles.rpy:149
translate french maya_Idle_morning_kitchen_scene_5c70bf26:

    # Maya "Обычно Соня этим занимается"
    Maya "Sonya fait habituellement ça"

# game/characters_events_idles/maya_idles.rpy:151
translate french maya_Idle_morning_kitchen_scene_602f32f7:

    # Maya "Вот, видишь? Сковородка меня ненавидит"
    Maya "Ici, toi vois ? La poêle à frire me déteste"

# game/characters_events_idles/maya_idles.rpy:152
translate french maya_Idle_morning_kitchen_scene_6441a501:

    # gg "Ага, ты с ней просто не разговариваешь достаточно вежливо"
    gg "Ouais, tu ne lui parles pas assez poliment."

# game/characters_events_idles/maya_idles.rpy:154
translate french maya_Idle_morning_kitchen_scene_92534113:

    # Maya "Серьёзно? Может, ей ещё комплимент сказать?"
    Maya "Sérieusement? Peut-être devrais-je lui faire un autre compliment ?"

# game/characters_events_idles/maya_idles.rpy:155
translate french maya_Idle_morning_kitchen_scene_9a46a58c:

    # gg "Можешь попробовать. Я подстрахую, если начнёт мстить"
    gg "Tu peux essayer. Je te soutiendrai s'il commence à se venger"

# game/characters_events_idles/maya_idles.rpy:157
translate french maya_Idle_morning_kitchen_scene_f6d334fe:

    # Maya "Вот именно поэтому я по утрам не встаю"
    Maya "C'est pour ça que je ne me lève pas le matin"

# game/characters_events_idles/maya_idles.rpy:159
translate french maya_Idle_morning_kitchen_scene_b8a73fc6:

    # Maya "Мир в это время суток явно против меня"
    Maya "Le monde est clairement contre moi à cette heure de la journée"

# game/characters_events_idles/maya_idles.rpy:160
translate french maya_Idle_morning_kitchen_scene_92828b86:

    # gg "А я думал, это просто твой ритуал - проспать завтрак и появиться к обеду"
    gg "Je pensais que c'était juste ton rituel de dormir pendant le petit-déjeuner et de te présenter pour le déjeuner"

# game/characters_events_idles/maya_idles.rpy:162
translate french maya_Idle_morning_kitchen_scene_2d194bcc:

    # Maya "Был"
    Maya "Était"

# game/characters_events_idles/maya_idles.rpy:163
translate french maya_Idle_morning_kitchen_scene_06f3f849:

    # Maya "Но с твоим появлением режим сбился"
    Maya "Mais avec ton apparition le régime s'est égaré"

# game/characters_events_idles/maya_idles.rpy:165
translate french maya_Idle_morning_kitchen_scene_c5cd9bdc:

    # Maya "Знаешь . . . {w}странно, когда в доме появился кто-то третий"
    Maya "Tu sais . . . {w}c'est étrange quand quelqu'un d'autre apparaît dans la maison"

# game/characters_events_idles/maya_idles.rpy:167
translate french maya_Idle_morning_kitchen_scene_2d60322d:

    # gg "“Странно” - в хорошем смысле?"
    gg "« Bizarre » – dans le bon sens ?"

# game/characters_events_idles/maya_idles.rpy:169
translate french maya_Idle_morning_kitchen_scene_0392e6e1:

    # Maya "Скорее . . . непривычно."
    Maya "Plus vite. . . inhabituel."

# game/characters_events_idles/maya_idles.rpy:170
translate french maya_Idle_morning_kitchen_scene_09dca06f:

    # Maya "Мы с Соней как будто уже притёрлись. У неё - тишина, у меня - беспорядок"
    Maya "Sonya et moi semblions déjà nous y être habitués. Elle a le silence, j'ai le chaos"

# game/characters_events_idles/maya_idles.rpy:171
translate french maya_Idle_morning_kitchen_scene_f70c520e:

    # Maya "А теперь добавился ты. И вроде ничего не изменилось, но стало . . . другое"
    Maya "Et maintenant, tu as été ajouté. Et il semblait que rien n’avait changé, mais c’est pourtant le cas. . . autre"

# game/characters_events_idles/maya_idles.rpy:173
translate french maya_Idle_morning_kitchen_scene_ac44cc52:

    # gg "Надеюсь, не хуже"
    gg "j'espère que ce n'est pas pire"

# game/characters_events_idles/maya_idles.rpy:174
translate french maya_Idle_morning_kitchen_scene_7331e581:

    # Maya "Пока нет"
    Maya "Pas encore"

# game/characters_events_idles/maya_idles.rpy:175
translate french maya_Idle_morning_kitchen_scene_a84e22a5:

    # Maya "Иногда даже спокойнее . . . а иногда бесишь"
    Maya "Parfois, c'est encore plus calme. . . et parfois tu es furieux"

# game/characters_events_idles/maya_idles.rpy:190
translate french maya_Idle_day_kitchen_scene_1cdbaa35:

    # gg "Не верится"
    gg "Je ne peux pas le croire"

# game/characters_events_idles/maya_idles.rpy:191
translate french maya_Idle_day_kitchen_scene_286ac20b:

    # gg "Ты с чаем? Где же твоя коллекция вредных газировок?"
    gg "Tu es avec du thé ? Où est ta collection de sodas nocifs ?"

# game/characters_events_idles/maya_idles.rpy:193
translate french maya_Idle_day_kitchen_scene_158529f9:

    # Maya "Иногда организм хочет чай и все"
    Maya "Parfois, le corps veut du thé et c'est tout"

# game/characters_events_idles/maya_idles.rpy:194
translate french maya_Idle_day_kitchen_scene_61e5a4a1:

    # Maya "И не хочу, чтобы Соня опять читала лекцию о “здоровом балансе”"
    Maya "Et je ne veux pas que Sonya donne à nouveau une conférence sur « l’équilibre sain »."

# game/characters_events_idles/maya_idles.rpy:195
translate french maya_Idle_day_kitchen_scene_0a361203:

    # gg "О, значит, это не просто чай - это акт самопожертвования"
    gg "Oh, donc ce n'est pas seulement du thé, c'est un acte d'abnégation"

# game/characters_events_idles/maya_idles.rpy:197
translate french maya_Idle_day_kitchen_scene_d1dbd3ae:

    # Maya "Ага. Пью и страдаю"
    Maya "Ouais. Je bois et je souffre"

# game/characters_events_idles/maya_idles.rpy:199
translate french maya_Idle_day_kitchen_scene_8b4629d0:

    # Maya "Ладно, раз уж ты сам подошёл - что планируешь делать?"
    Maya "Bon, puisque tu es déjà venu, que comptes-tu faire ?"

# game/characters_events_idles/maya_idles.rpy:200
translate french maya_Idle_day_kitchen_scene_51392b4e:

    # gg "В смысле?"
    gg "En termes de?"

# game/characters_events_idles/maya_idles.rpy:202
translate french maya_Idle_day_kitchen_scene_e2d10f18:

    # Maya "Ну, в целом"
    Maya "Eh bien, en général"

# game/characters_events_idles/maya_idles.rpy:203
translate french maya_Idle_day_kitchen_scene_3b447692:

    # Maya "Сидеть, отдыхать, страдать или притворяться, что у тебя есть план?"
    Maya "S'asseoir, se détendre, souffrir ou faire semblant d'avoir un plan ?"

# game/characters_events_idles/maya_idles.rpy:204
translate french maya_Idle_day_kitchen_scene_ba096a56:

    # gg "План есть - не иметь плана. Хотя, если честно, я просто устал от города"
    gg "Il y a un plan – il ne faut pas avoir de plan. Même si, pour être honnête, je suis juste fatigué de la ville"

# game/characters_events_idles/maya_idles.rpy:205
translate french maya_Idle_day_kitchen_scene_a341feee:

    # gg "Хотел отдохнуть, помочь бабушке с домом . . . {w}ну, а теперь, похоже, пора искать работу"
    gg "Je voulais me détendre, aider ma grand-mère à la maison. . . {w}Eh bien, il semble maintenant qu'il soit temps de chercher un emploi"

# game/characters_events_idles/maya_idles.rpy:207
translate french maya_Idle_day_kitchen_scene_226b1041:

    # Maya "Добро пожаловать в реальность"
    Maya "Bienvenue dans la réalité"

# game/characters_events_idles/maya_idles.rpy:208
translate french maya_Idle_day_kitchen_scene_a886fda9:

    # Maya "И где ищут работу люди, которые сбежали от людей?"
    Maya "Et où les gens qui ont fui les gens cherchent-ils du travail ?"

# game/characters_events_idles/maya_idles.rpy:210
translate french maya_Idle_day_kitchen_scene_a73a3597:

    # gg "Пока не знаю. Может, в посёлке что-то найду"
    gg "Je ne sais pas encore. Peut-être que je trouverai quelque chose dans le village"

# game/characters_events_idles/maya_idles.rpy:211
translate french maya_Idle_day_kitchen_scene_a04c7319:

    # gg "Мне и ритм нравится - медленный, настоящий"
    gg "J'aime aussi le rythme - lent, réel"

# game/characters_events_idles/maya_idles.rpy:212
translate french maya_Idle_day_kitchen_scene_4dc705a2:

    # Maya "Настоящий?"
    Maya "Réel?"

# game/characters_events_idles/maya_idles.rpy:213
translate french maya_Idle_day_kitchen_scene_57978980:

    # Maya "Это пока ты не застрянешь тут зимой"
    Maya "Jusqu'à ce que tu sois coincé ici en hiver."

# game/characters_events_idles/maya_idles.rpy:214
translate french maya_Idle_day_kitchen_scene_25de1f66:

    # gg "Зато не метро и не толпы"
    gg "Mais pas le métro et pas la foule"

# game/characters_events_idles/maya_idles.rpy:216
translate french maya_Idle_day_kitchen_scene_f04c48a5:

    # Maya "Ну да. Только мы и Барсик, который судя по всему - местный депутат"
    Maya "Eh bien, oui. Juste nous et Barsik, qui est apparemment un député local"

# game/characters_events_idles/maya_idles.rpy:217
translate french maya_Idle_day_kitchen_scene_9b820f0a:

    # gg "Главное, чтобы не требовал отчёта о проделанной работе"
    gg "L'essentiel est de ne pas exiger de rapport sur le travail effectué"

# game/characters_events_idles/maya_idles.rpy:219
translate french maya_Idle_day_kitchen_scene_67b66e53:

    # Maya "Ага. Хотя Соня могла бы - она бы тебе график расписала"
    Maya "Ouais. Bien que Sonya puisse - elle rédigerait un emploi du temps pour toi"

# game/characters_events_idles/maya_idles.rpy:220
translate french maya_Idle_day_kitchen_scene_d9d4e1ed:

    # gg "Я замечал. У неё всё как по часам"
    gg "J'ai remarqué. Elle fait tout comme sur des roulettes"

# game/characters_events_idles/maya_idles.rpy:222
translate french maya_Idle_day_kitchen_scene_8841e92a:

    # Maya "Потому что кто-то в этом доме должен компенсировать мой хаос"
    Maya "Parce que quelqu'un dans cette maison doit compenser mon chaos"

# game/characters_events_idles/maya_idles.rpy:224
translate french maya_Idle_day_kitchen_scene_962fec54:

    # Maya "Так что, если решишь остаться надолго, готовься привыкать к контрастам"
    Maya "Alors, si tu décides de rester longtemps, prépares-toi à t'habituer aux contrastes."

# game/characters_events_idles/maya_idles.rpy:225
translate french maya_Idle_day_kitchen_scene_5401d48b:

    # gg "Мне кажется, я уже начинаю"
    gg "Je pense que je commence déjà"

# game/characters_events_idles/maya_idles.rpy:226
translate french maya_Idle_day_kitchen_scene_a207aba8:

    # Maya "Осторожнее"
    Maya "Sois prudent"

# game/characters_events_idles/maya_idles.rpy:227
translate french maya_Idle_day_kitchen_scene_2fbe2d88:

    # Maya "Это затягивает"
    Maya "C'est addictif"

# game/characters_events_idles/maya_idles.rpy:241
translate french maya_Idle_morning_mayaroom_scene_f8fe1494:

    # gg ". . . "
    gg ". . ."

# game/characters_events_idles/maya_idles.rpy:242
translate french maya_Idle_morning_mayaroom_scene_7e0bd9fb:

    # gg "Так сладко спит"
    gg "Elle dort si paisiblement"

# game/characters_events_idles/maya_idles.rpy:253
translate french maya_Idle_day_mayaroom_scene_94873986:

    # gg "Серьёзный вид"
    gg "Regard sérieux"

# game/characters_events_idles/maya_idles.rpy:254
translate french maya_Idle_day_mayaroom_scene_80d9437f:

    # gg "Ты что, музыку миксуешь?"
    gg "Est-ce que tu mixes de la musique ?"

# game/characters_events_idles/maya_idles.rpy:256
translate french maya_Idle_day_mayaroom_scene_f4b03c23:

    # Maya "Ха, мечтай. Работаю"
    Maya "Ha, rêve. Je bosse"

# game/characters_events_idles/maya_idles.rpy:257
translate french maya_Idle_day_mayaroom_scene_f8277c64:

    # gg "Звучит опасно. А я думал, ты против дисциплины"
    gg "Cela semble dangereux. Je pensais que tu étais contre la discipline"

# game/characters_events_idles/maya_idles.rpy:259
translate french maya_Idle_day_mayaroom_scene_7888996f:

    # Maya "Я против бессмысленной дисциплины"
    Maya "Je suis contre la discipline inutile"

# game/characters_events_idles/maya_idles.rpy:260
translate french maya_Idle_day_mayaroom_scene_927b0fd4:

    # Maya "Но если платят - можно и притвориться взрослой"
    Maya "Mais s'ils paient, je peux bien faire semblant d’être adulte"

# game/characters_events_idles/maya_idles.rpy:261
translate french maya_Idle_day_mayaroom_scene_d96b72a5:

    # gg "И что за работа?"
    gg "Et quel genre de travail ?"

# game/characters_events_idles/maya_idles.rpy:263
translate french maya_Idle_day_mayaroom_scene_c6edbdd9:

    # Maya "Связано с проектами. Неинтересно"
    Maya "Lié aux projets. Pas intéressant"

# game/characters_events_idles/maya_idles.rpy:264
translate french maya_Idle_day_mayaroom_scene_3908c185:

    # Maya "Раньше приходилось ездить в офис, а теперь могу делать всё из дома"
    Maya "Avant, je devais aller au bureau, mais maintenant je peux tout faire depuis chez moi"

# game/characters_events_idles/maya_idles.rpy:266
translate french maya_Idle_day_mayaroom_scene_0fc56267:

    # Maya "Так что не мешай моей продуктивности"
    Maya "Alors n'interféres pas avec ma productivité"

# game/characters_events_idles/maya_idles.rpy:267
translate french maya_Idle_day_mayaroom_scene_77dec125:

    # gg "Не мешаю"
    gg "je n'interviens pas"

# game/characters_events_idles/maya_idles.rpy:268
translate french maya_Idle_day_mayaroom_scene_585ed193:

    # gg "Просто проверяю, не заснула ли ты с открытым документом"
    gg "Je vérifie juste si tu ne t'es pas endormie avec le document ouvert"

# game/characters_events_idles/maya_idles.rpy:270
translate french maya_Idle_day_mayaroom_scene_e95f31f8:

    # Maya "Ещё нет"
    Maya "Pas encore"

# game/characters_events_idles/maya_idles.rpy:271
translate french maya_Idle_day_mayaroom_scene_4d0580f6:

    # Maya "Но если будешь стоять и таращиться, это ускорит процесс"
    Maya "Mais si tu restes debout et regardes, cela accélérera le processus"

# game/characters_events_idles/maya_idles.rpy:274
translate french maya_Idle_day_mayaroom_scene_d2135720:

    # Maya "И да, на будущее . . ."
    Maya "Et oui, pour l'avenir. . ."

# game/characters_events_idles/maya_idles.rpy:275
translate french maya_Idle_day_mayaroom_scene_8af163bc:

    # Maya "Стучи, когда входишь"
    Maya "Frappes en entrant"

# game/characters_events_idles/maya_idles.rpy:276
translate french maya_Idle_day_mayaroom_scene_9797f5b6:

    # gg "А ты дверь закрывай, если хочешь секретности"
    gg "Et tu fermes la porte si tu veux le secret"

# game/characters_events_idles/maya_idles.rpy:278
translate french maya_Idle_day_mayaroom_scene_7d229fff:

    # Maya "Закрытая дверь - это скучно"
    Maya "Une porte fermée, c'est ennuyeux"

# game/characters_events_idles/maya_idles.rpy:279
translate french maya_Idle_day_mayaroom_scene_6d90d8fb:

    # Maya "Мне нравится знать, что кто-то может ввалиться в самый неподходящий момент. Добавляет адреналина"
    Maya "J’aime savoir que quelqu’un pourrait faire irruption au moment le plus inopportun. Ajoute de l'adrénaline"

# game/characters_events_idles/maya_idles.rpy:280
translate french maya_Idle_day_mayaroom_scene_5348c7b0:

    # gg "Опасное хобби"
    gg "Passe-temps dangereux"

# game/characters_events_idles/maya_idles.rpy:295
translate french maya_Idle_evening_mayaroom_scene_c74a33fe:

    # gg "Опять зависла?"
    gg "Congeler à nouveau ?"

# game/characters_events_idles/maya_idles.rpy:297
translate french maya_Idle_evening_mayaroom_scene_66aa8fb0:

    # Maya "Называется “отдыхаю”"
    Maya "Ça s'appelle \"repos\""

# game/characters_events_idles/maya_idles.rpy:298
translate french maya_Idle_evening_mayaroom_scene_29fea123:

    # Maya "Иногда даже без музыки"
    Maya "Parfois même sans musique"

# game/characters_events_idles/maya_idles.rpy:299
translate french maya_Idle_evening_mayaroom_scene_bbc28184:

    # gg "Опасный эксперимент"
    gg "Expérience dangereuse"

# game/characters_events_idles/maya_idles.rpy:300
translate french maya_Idle_evening_mayaroom_scene_cc606e86:

    # Maya "Ага. Учёные уже фиксируют первые побочные эффекты - мысли начали возвращаться"
    Maya "Ouais. Les scientifiques enregistrent déjà les premiers effets secondaires - les réflexions ont commencé à revenir"

# game/characters_events_idles/maya_idles.rpy:301
translate french maya_Idle_evening_mayaroom_scene_a4eb2f4d:

    # gg "О чём думаешь?"
    gg "A quoi penses-tu ?"

# game/characters_events_idles/maya_idles.rpy:303
translate french maya_Idle_evening_mayaroom_scene_f963639a:

    # Maya "Ни о чём особенном. Просто день какой-то неспокойный"
    Maya "Rien de spécial. C'est juste une journée agitée"

# game/characters_events_idles/maya_idles.rpy:305
translate french maya_Idle_evening_mayaroom_scene_9622db09:

    # Maya "Иногда мне кажется, что этот дом дышит"
    Maya "Parfois il me semble que cette maison respire"

# game/characters_events_idles/maya_idles.rpy:306
translate french maya_Idle_evening_mayaroom_scene_0a637ee0:

    # Maya "Когда все расходятся по комнатам, он будто вздыхает - типа “наконец-то”"
    Maya "Quand tout le monde va dans sa chambre, il semble soupirer - comme \"enfin\""

# game/characters_events_idles/maya_idles.rpy:307
translate french maya_Idle_evening_mayaroom_scene_c4190f3c:

    # gg "Может, он просто устал от нас"
    gg "Peut-être qu'il est juste fatigué de nous"

# game/characters_events_idles/maya_idles.rpy:309
translate french maya_Idle_evening_mayaroom_scene_9a1cfc06:

    # Maya "Или от тебя"
    Maya "Ou de toi"

# game/characters_events_idles/maya_idles.rpy:310
translate french maya_Idle_evening_mayaroom_scene_9ca1630b:

    # Maya "Ты ж теперь главный источник событий"
    Maya "Tu es désormais la principale source d'événements"

# game/characters_events_idles/maya_idles.rpy:311
translate french maya_Idle_evening_mayaroom_scene_4618c7f3:

    # gg "Ну спасибо"
    gg "Eh bien, merci"

# game/characters_events_idles/maya_idles.rpy:312
translate french maya_Idle_evening_mayaroom_scene_9314e70f:

    # gg "Хоть не шумовой загрязнитель"
    gg "Du moins, pas un pollueur sonore"

# game/characters_events_idles/maya_idles.rpy:314
translate french maya_Idle_evening_mayaroom_scene_1c9556b7:

    # Maya "Не переживай, ты в двух шагах от этого звания"
    Maya "Ne t'inquiétez pas, tu es à deux pas de ce titre"

# game/characters_events_idles/maya_idles.rpy:317
translate french maya_Idle_evening_mayaroom_scene_3ece4663:

    # gg "Ладно, не мешаю твоему “отдыханию”"
    gg "D'accord, je n'interférerai pas avec ton \"repos\""

# game/characters_events_idles/maya_idles.rpy:318
translate french maya_Idle_evening_mayaroom_scene_c8d80171:

    # Maya "Уже поздно. Ты в моём поле общения, это необратимо"
    Maya "Il est déjà tard. Tu es dans mon domaine de communication, c'est irréversible"

# game/characters_events_idles/maya_idles.rpy:319
translate french maya_Idle_evening_mayaroom_scene_52424bb1:

    # gg "Тогда я официально заражён"
    gg "Alors je suis officiellement infecté"

# game/characters_events_idles/maya_idles.rpy:333
translate french maya_Idle_night_mayaroom_scene_f715f6b4:

    # gg "Спит без задних ног . . ."
    gg "Elle dort profondément. . ."

# game/characters_events_idles/maya_idles.rpy:334
translate french maya_Idle_night_mayaroom_scene_fd8d0a8c:

    # gg "Хоть будильник под ухом взрывай — не проснётся"
    gg "Même si tu fais exploser un réveil sous son oreille, tu ne la réveilleras pas"

# game/characters_events_idles/maya_idles.rpy:345
translate french maya_Idle_evening_myroom_scene_f6ddbad8:

    # gg "Засыпаешь?"
    gg "Est-ce que tu t'endors ?"

# game/characters_events_idles/maya_idles.rpy:347
translate french maya_Idle_evening_myroom_scene_60b26d3f:

    # Maya "Нет. Просто отдыхаю в позе ленивой медитации"
    Maya "Non. Je me détends simplement dans une pose de méditation paresseuse."

# game/characters_events_idles/maya_idles.rpy:348
translate french maya_Idle_evening_myroom_scene_5197b7fb:

    # gg "Выглядит как битва с подушкой на выживание"
    gg "On dirait une bataille d'oreillers de survie"

# game/characters_events_idles/maya_idles.rpy:350
translate french maya_Idle_evening_myroom_scene_ef00b824:

    # Maya "Ха. Не завидуй"
    Maya "Ha. Ne sois pas jaloux"

# game/characters_events_idles/maya_idles.rpy:352
translate french maya_Idle_evening_myroom_scene_87bfdb57:

    # gg "Соня говорила что спала раньше на этом диване. Он удобный"
    gg "Sonya a dit qu'elle avait déjà dormi sur ce canapé. C'est confortable"

# game/characters_events_idles/maya_idles.rpy:353
translate french maya_Idle_evening_myroom_scene_b9e42dcf:

    # Maya "Ага. Она любила здесь засыпать под телевизор"
    Maya "Ouais. Elle adorait s'endormir en regardant la télé ici"

# game/characters_events_idles/maya_idles.rpy:354
translate french maya_Idle_evening_myroom_scene_01c1b004:

    # Maya "Говорила, что этот гул помогает думать"
    Maya "Elle a dit que ce bourdonnement l'aide à réfléchir"

# game/characters_events_idles/maya_idles.rpy:357
translate french maya_Idle_evening_myroom_scene_69ea4813:

    # Maya "А теперь вот ты"
    Maya "Et maintenant tu es là"

# game/characters_events_idles/maya_idles.rpy:358
translate french maya_Idle_evening_myroom_scene_1c914aec:

    # Maya "И диван как будто сменил хозяина"
    Maya "Et le canapé semblait changer de propriétaire"

# game/characters_events_idles/maya_idles.rpy:359
translate french maya_Idle_evening_myroom_scene_c99ae1d2:

    # gg "Ничего, я постараюсь не испортить его репутацию"
    gg "C'est bon, je vais essayer de ne pas ruiner sa réputation"

# game/characters_events_idles/maya_idles.rpy:360
translate french maya_Idle_evening_myroom_scene_4ed4ce95:

    # Maya "Да уж, будь добр"
    Maya "Oui, s'il te plaît, sois gentil"

# game/characters_events_idles/maya_idles.rpy:361
translate french maya_Idle_evening_myroom_scene_a777aa23:

    # Maya "У него длинная история, он видел больше ссор и сериалов, чем мы оба вместе"
    Maya "Il a une longue histoire, il a vu plus de combats et de séries TV que nous deux ensemble"

# game/characters_events_idles/maya_idles.rpy:362
translate french maya_Idle_evening_myroom_scene_3f329134:

    # gg "Кстати, а вы вообще платите Линде за жильё? Или это всё “по знакомству”?"
    gg "Au fait, payez-vous même le loyer de Linda ? Ou est-ce uniquement une « connaissance » ?"

# game/characters_events_idles/maya_idles.rpy:364
translate french maya_Idle_evening_myroom_scene_ac2bb573:

    # Maya "Платим . . . {w}Ну как “платим” - скорее благодарим"
    Maya "Nous payons. . . {w}Eh bien, comment pouvons-nous \"payer\" ? Merci plutôt"

# game/characters_events_idles/maya_idles.rpy:365
translate french maya_Idle_evening_myroom_scene_b48308d4:

    # Maya "Сумма символическая, Линда больше из принципа берёт, чем из необходимости"
    Maya "Le montant est symbolique, Linda prend plus par principe que par nécessité."

# game/characters_events_idles/maya_idles.rpy:366
translate french maya_Idle_evening_myroom_scene_361a0566:

    # Maya "Её это, кажется, успокаивает: типа дом не стоит пустой и приносит пользу"
    Maya "Cela semble la calmer : comme si la maison ne restait pas vide et était utile"

# game/characters_events_idles/maya_idles.rpy:367
translate french maya_Idle_evening_myroom_scene_e9782332:

    # gg "Узнаю свою бабушку"
    gg "Je reconnais ma grand-mère"

# game/characters_events_idles/maya_idles.rpy:369
translate french maya_Idle_evening_myroom_scene_5822e6c1:

    # Maya "Ага. Только вот было бы ещё хорошо, если бы она хотя бы предупредила, что внучок вот-вот приедет"
    Maya "Ouais. Mais ce serait bien si elle prévenait au moins que son petit-fils était sur le point d'arriver."

# game/characters_events_idles/maya_idles.rpy:370
translate french maya_Idle_evening_myroom_scene_3f1ab8b6:

    # Maya "Я чуть не упала тогда, когда ты появился в дверях"
    Maya "J'ai failli tomber quand tu es apparu à la porte"

# game/characters_events_idles/maya_idles.rpy:371
translate french maya_Idle_evening_myroom_scene_1bd89a55:

    # Maya "Уже чего только не думала"
    Maya "Je n'ai déjà pensé à rien"

# game/characters_events_idles/maya_idles.rpy:372
translate french maya_Idle_evening_myroom_scene_5d3dcdb5:

    # gg "Извини, я тоже не ожидал, что в доме будут люди"
    gg "Désolé, je ne m'attendais pas non plus à ce qu'il y ait du monde dans la maison"

# game/characters_events_idles/maya_idles.rpy:373
translate french maya_Idle_evening_myroom_scene_43ff1f8d:

    # Maya "Вот и замечательно"
    Maya "C'est super"

# game/characters_events_idles/maya_idles.rpy:374
translate french maya_Idle_evening_myroom_scene_6c224d29:

    # Maya "Никто ничего не ожидал - поэтому всё как обычно"
    Maya "Personne ne s'attendait à rien - donc tout est comme d'habitude"

# game/characters_events_idles/maya_idles.rpy:377
translate french maya_Idle_evening_myroom_scene_cbdc658c:

    # Maya "Знаешь, может, это и к лучшему"
    Maya "Tu sais, c'est peut-être pour le mieux"

# game/characters_events_idles/maya_idles.rpy:378
translate french maya_Idle_evening_myroom_scene_10ae6709:

    # gg "Я стараюсь как лучше"
    gg "Je fais de mon mieux"

# game/characters_events_idles/maya_idles.rpy:379
translate french maya_Idle_evening_myroom_scene_2738bbdd:

    # Maya "Ладно, ты уже часть декора"
    Maya "D'accord, tu fais déjà partie du décor."

# game/characters_events_idles/maya_idles.rpy:380
translate french maya_Idle_evening_myroom_scene_a3e55433:

    # Maya "Даже телевизор теперь включается по тебе"
    Maya "Même la télé s'allume maintenant pour toi"

# game/characters_events_idles/maya_idles.rpy:381
translate french maya_Idle_evening_myroom_scene_51392b4e:

    # gg "В смысле?"
    gg "En termes de?"

# game/characters_events_idles/maya_idles.rpy:382
translate french maya_Idle_evening_myroom_scene_6214a218:

    # Maya "Стоит тебе появиться - сразу что-то происходит. Иногда полезное, иногда нет"
    Maya "Dès ton apparition, quelque chose se passe immédiatement. Parfois utile, parfois pas"

# game/characters_events_idles/maya_idles.rpy:383
translate french maya_Idle_evening_myroom_scene_a17c73ec:

    # Maya "Но скучно с тобой не бывает"
    Maya "Mais ce n'est jamais ennuyeux avec toi"

# game/characters_events_idles/maya_idles.rpy:385
translate french maya_Idle_evening_myroom_scene_3edde83f:

    # Maya "Всё, вечер окончен"
    Maya "Ça y est, la soirée est finie"

# game/characters_events_idles/maya_idles.rpy:386
translate french maya_Idle_evening_myroom_scene_2082f32a:

    # Maya "Телевизор устал смотреть на нас"
    Maya "La télé en a marre de nous regarder"

# game/characters_events_idles/maya_idles.rpy:387
translate french maya_Idle_evening_myroom_scene_3c45ded0:

    # gg "Тогда спокойной ночи"
    gg "Alors bonne nuit"

# game/characters_events_idles/maya_idles.rpy:388
translate french maya_Idle_evening_myroom_scene_9adb5a5c:

    # Maya "Ага. И не растяни диван - он к тебе уже привязался"
    Maya "Ouais. Et n'étire pas le canapé - il est déjà attaché à toi"

translate french strings:

    # game/characters_events_idles/maya_idles.rpy:5
    old "Барсик у тебя?"
    new "Tu as Barsik ?"

    # game/characters_events_idles/maya_idles.rpy:43
    old "Позже зайду"
    new "je viendrai plus tard"

    # game/characters_events_idles/maya_idles.rpy:52
    old "С книжкой с утра?"
    new "Avec un livre le matin ?"

    # game/characters_events_idles/maya_idles.rpy:102
    old "Не мешаю"
    new "je n'interviens pas"

    # game/characters_events_idles/maya_idles.rpy:111
    old "Ко сну готовишься?"
    new "Est-ce que tu te prépares à aller au lit ?"

    # game/characters_events_idles/maya_idles.rpy:136
    old "Не буду мешать"
    new "je n'interviendrai pas"

    # game/characters_events_idles/maya_idles.rpy:145
    old "Новый рецепт?"
    new "Nouvelle recette ?"

    # game/characters_events_idles/maya_idles.rpy:188
    old "Газировка кончилась?"
    new "Tu manques de soda ?"

    # game/characters_events_idles/maya_idles.rpy:231
    old "Пойду"
    new "S'en aller"

    # game/characters_events_idles/maya_idles.rpy:240
    old "Не беспокоить"
    new "Ne pas déranger"

    # game/characters_events_idles/maya_idles.rpy:251
    old "Музыку миксуешь?"
    new "Mixes-tu de la musique ?"

    # game/characters_events_idles/maya_idles.rpy:284
    old "Уйти"
    new "Partir"

    # game/characters_events_idles/maya_idles.rpy:293
    old "Опять зависла?"
    new "Congeler à nouveau ?"

    # game/characters_events_idles/maya_idles.rpy:343
    old "Засыпаешь?"
    new "Est-ce que tu t'endors ?"

