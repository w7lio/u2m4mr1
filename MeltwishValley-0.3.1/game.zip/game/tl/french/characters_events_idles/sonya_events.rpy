﻿# TODO: Translation updated at 2026-01-21 13:15

# game/characters_events_idles/sonya_events.rpy:6
translate french sonya_scene1_morning_kitchen_a756dbc0:

    # gg "Утречко"
    gg "Coucou !"

# game/characters_events_idles/sonya_events.rpy:12
translate french sonya_scene1_morning_kitchen_2641e2c9:

    # Sonya "Доброе утро"
    Sonya "Bonjour"

# game/characters_events_idles/sonya_events.rpy:14
translate french sonya_scene1_morning_kitchen_50dcebad:

    # Sonya "Как тебе спалось?"
    Sonya "Comment as-tu dormi ?"

# game/characters_events_idles/sonya_events.rpy:16
translate french sonya_scene1_morning_kitchen_9fdea20a:

    # gg "Нормально"
    gg "Bien"

# game/characters_events_idles/sonya_events.rpy:18
translate french sonya_scene1_morning_kitchen_c923e04f:

    # gg "Тихо"
    gg "Calme"

# game/characters_events_idles/sonya_events.rpy:20
translate french sonya_scene1_morning_kitchen_367f1af9:

    # Sonya "Там диван конечно старый"
    Sonya "Le canapé là-bas est certainement vieux"

# game/characters_events_idles/sonya_events.rpy:22
translate french sonya_scene1_morning_kitchen_0a0eba96:

    # Sonya "Но удобный"
    Sonya "Mais pratique"

# game/characters_events_idles/sonya_events.rpy:24
translate french sonya_scene1_morning_kitchen_0f37c26d:

    # gg "Я заметил"
    gg "j'ai remarqué"

# game/characters_events_idles/sonya_events.rpy:26
translate french sonya_scene1_morning_kitchen_93b6fb71:

    # Sonya "Ты уже успел пройтись по деревне?"
    Sonya "As-tu déjà parcouru le village ?"

# game/characters_events_idles/sonya_events.rpy:28
translate french sonya_scene1_morning_kitchen_0839a090:

    # Sonya "Или пока только дом вспоминаешь?"
    Sonya "Ou tu te souviens juste de chez toi ?"

# game/characters_events_idles/sonya_events.rpy:30
translate french sonya_scene1_morning_kitchen_12aa0f18:

    # gg "Немного посмотрел"
    gg "J'ai regardé un peu"

# game/characters_events_idles/sonya_events.rpy:32
translate french sonya_scene1_morning_kitchen_c33e58bc:

    # gg "Тут . . . Хорошие люди"
    gg "Ici . . . li y a de bonnes personnes"

# game/characters_events_idles/sonya_events.rpy:34
translate french sonya_scene1_morning_kitchen_c8772e87:

    # Sonya "Да"
    Sonya "Oui"

# game/characters_events_idles/sonya_events.rpy:36
translate french sonya_scene1_morning_kitchen_ed137d91:

    # Sonya "Ты к этому быстро привыкаешь"
    Sonya "On s'y habitue vite"

# game/characters_events_idles/sonya_events.rpy:48
translate french sonya_scene1_morning_kitchen_e45ac0f2:

    # Sonya "Если вдруг проголодаешься — бери что хочешь"
    Sonya "Si tu as soudainement faim, prends ce que tu veux"

# game/characters_events_idles/sonya_events.rpy:50
translate french sonya_scene1_morning_kitchen_947178ba:

    # Sonya "У нас обычно никто особо не спрашивает"
    Sonya "Habituellement, personne ne nous demande grand-chose"

# game/characters_events_idles/sonya_events.rpy:56
translate french sonya_scene1_morning_kitchen_04c6c53d:

    # gg "Спасибо"
    gg "Merci"

# game/characters_events_idles/sonya_events.rpy:60
translate french sonya_scene1_morning_kitchen_77469d65:

    # Sonya "А вообще"
    Sonya "En général"

# game/characters_events_idles/sonya_events.rpy:62
translate french sonya_scene1_morning_kitchen_ebb5bb0f:

    # Sonya "Как тебе здесь?"
    Sonya "Comment aimes-tu cet endroit ?"

# game/characters_events_idles/sonya_events.rpy:66
translate french sonya_scene1_morning_kitchen_77102205:

    # Sonya "В смысле . . . жить вместе"
    Sonya "En termes de . . . vivre ensemble"

# game/characters_events_idles/sonya_events.rpy:70
translate french sonya_scene1_morning_kitchen_dcf6ae5e:

    # gg "Непривычно"
    gg "Inhabituel"

# game/characters_events_idles/sonya_events.rpy:72
translate french sonya_scene1_morning_kitchen_0dd94278:

    # gg "Но нормально"
    gg "Mais c'est ok"

# game/characters_events_idles/sonya_events.rpy:74
translate french sonya_scene1_morning_kitchen_c8772e87_1:

    # Sonya "Да"
    Sonya "Oui"

# game/characters_events_idles/sonya_events.rpy:76
translate french sonya_scene1_morning_kitchen_8aa7b1fd:

    # Sonya "Мы тоже не сразу привыкли"
    Sonya "Il nous a fallu un certain temps pour nous y habituer."

# game/characters_events_idles/sonya_events.rpy:78
translate french sonya_scene1_morning_kitchen_270848f3:

    # Sonya "Когда людей в доме становится больше"
    Sonya "Quand il y a plus de monde dans la maison"

# game/characters_events_idles/sonya_events.rpy:80
translate french sonya_scene1_morning_kitchen_816d8504:

    # Sonya "Всё немного меняется"
    Sonya "Les choses changent un peu"

# game/characters_events_idles/sonya_events.rpy:99
translate french sonya_scene1_morning_kitchen_7b099c93:

    # gg_chat "Мае — завтрак"
    gg_chat "Maya - petit-déjeuner"

# game/characters_events_idles/sonya_events.rpy:100
translate french sonya_scene1_morning_kitchen_fcffc8ef:

    # gg_chat "Если не успею — купи, пожалуйста, продукты"
    gg_chat "Si je n'ai pas le temps, s'il te plaît, fais mes courses"

# game/characters_events_idles/sonya_events.rpy:109
translate french sonya_scene1_morning_kitchen_7158ba01:

    # gg "Ладно, я пойду"
    gg "D'accord, j'y vais"

# game/characters_events_idles/sonya_events.rpy:111
translate french sonya_scene1_morning_kitchen_fbb535a1:

    # gg "Не буду мешать"
    gg "Je ne vais pas déranger"

# game/characters_events_idles/sonya_events.rpy:113
translate french sonya_scene1_morning_kitchen_98963b02:

    # Sonya "Да ты и не мешаешь"
    Sonya "Mais tu ne déranges même pas"

# game/characters_events_idles/sonya_events.rpy:117
translate french sonya_scene1_morning_kitchen_d24f6aaf:

    # Sonya "Но . . . хорошо"
    Sonya "Mais . . . Bien"

# game/characters_events_idles/sonya_events.rpy:133
translate french sonya_scene2_day_girlroom_68c12557:

    # gg "Сонь"
    gg "Sonya"

# game/characters_events_idles/sonya_events.rpy:137
translate french sonya_scene2_day_girlroom_d3ca52ed:

    # gg "Ты не знаешь, где у вас аптечка?"
    gg "Tu ne sais pas où se trouve votre trousse de premiers secours ?"

# game/characters_events_idles/sonya_events.rpy:139
translate french sonya_scene2_day_girlroom_fb949c9e:

    # Sonya "Аптечка?"
    Sonya "Trousse de secours?"

# game/characters_events_idles/sonya_events.rpy:141
translate french sonya_scene2_day_girlroom_695184c3:

    # Sonya "А что случилось?"
    Sonya "Qu'est-ce qui s'est passé?"

# game/characters_events_idles/sonya_events.rpy:143
translate french sonya_scene2_day_girlroom_55820831:

    # gg "Да так"
    gg "Juste comme ça"

# game/characters_events_idles/sonya_events.rpy:145
translate french sonya_scene2_day_girlroom_41aa37fb:

    # gg "Поцарапался.{w} Ерунда"
    gg "Je me suis fait une petite égratignure.{w} Ce n’est rien"

# game/characters_events_idles/sonya_events.rpy:149
translate french sonya_scene2_day_girlroom_06e5075f:

    # Sonya "Подожди"
    Sonya "Attends"

# game/characters_events_idles/sonya_events.rpy:151
translate french sonya_scene2_day_girlroom_b43c4c5e:

    # Sonya "Сейчас все сделаем"
    Sonya "On va tout arranger maintenant"

# game/characters_events_idles/sonya_events.rpy:155
translate french sonya_scene2_day_girlroom_7cc8260f:

    # Sonya "А ты почти без вещей приехал"
    Sonya "Et tu es presque arrivé les mains vides"

# game/characters_events_idles/sonya_events.rpy:157
translate french sonya_scene2_day_girlroom_b1f32e8a:

    # Sonya "Так и планировал"
    Sonya "C'est ce que j'avais prévu"

# game/characters_events_idles/sonya_events.rpy:158
translate french sonya_scene2_day_girlroom_06e860df:

    # Sonya "Или просто не успел собрать?"
    Sonya "Ou vous n’avez tout simplement pas eu le temps de le récupérer ?"

# game/characters_events_idles/sonya_events.rpy:164
translate french sonya_scene2_day_girlroom_cc881b3b:

    # gg "Скорее второе"
    gg "Plus probablement la deuxième proposition"

# game/characters_events_idles/sonya_events.rpy:166
translate french sonya_scene2_day_girlroom_72e0315a:

    # gg "Решил не тащить за собой старое"
    gg "J’ai décidé de ne pas emmener le vieux bazar avec moi"

# game/characters_events_idles/sonya_events.rpy:169
translate french sonya_scene2_day_girlroom_fef188e6:

    # gg "Посмотреть, как будет"
    gg "Regardes comment ça se passe"

# game/characters_events_idles/sonya_events.rpy:171
translate french sonya_scene2_day_girlroom_4b248478:

    # Sonya "Будто новая жизнь"
    Sonya "Comme une nouvelle vie"

# game/characters_events_idles/sonya_events.rpy:173
translate french sonya_scene2_day_girlroom_84c6a1f8:

    # Sonya "Ты получается больше утренний человек?"
    Sonya "Es-tu plutôt du genre matinal ?"

# game/characters_events_idles/sonya_events.rpy:175
translate french sonya_scene2_day_girlroom_e550b517:

    # Sonya "Или нет?"
    Sonya "Ou l'inverse ?"

# game/characters_events_idles/sonya_events.rpy:177
translate french sonya_scene2_day_girlroom_254f159a:

    # gg "Раньше — скорее вечерний"
    gg "Avant - plutôt le soir"

# game/characters_events_idles/sonya_events.rpy:179
translate french sonya_scene2_day_girlroom_bf5f3aef:

    # gg "А здесь почему-то весь день на ногах"
    gg "Et ici, pour une raison quelconque, je suis debout toute la journée"

# game/characters_events_idles/sonya_events.rpy:181
translate french sonya_scene2_day_girlroom_633d56a5:

    # gg "Сам удивляюсь"
    gg "je suis moi-même surpris"

# game/characters_events_idles/sonya_events.rpy:183
translate french sonya_scene2_day_girlroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "Est-ce vrai ?"

# game/characters_events_idles/sonya_events.rpy:185
translate french sonya_scene2_day_girlroom_7e52f22d:

    # Sonya "Значит, деревня на тебя хорошо действует"
    Sonya "Donc le village a un bon effet sur toi"

# game/characters_events_idles/sonya_events.rpy:187
translate french sonya_scene2_day_girlroom_d0a33041:

    # Sonya "И часто ты так . . ."
    Sonya "Et c’est souvent le cas. . ."

# game/characters_events_idles/sonya_events.rpy:189
translate french sonya_scene2_day_girlroom_25b95c9d:

    # Sonya "Царапаешься?"
    Sonya "Tu t’es égratigné ?"

# game/characters_events_idles/sonya_events.rpy:191
translate french sonya_scene2_day_girlroom_8f76c3f1:

    # gg "Не особо"
    gg "Pas vraiment"

# game/characters_events_idles/sonya_events.rpy:193
translate french sonya_scene2_day_girlroom_2171a9af:

    # gg "Просто ещё не привык к местной фауне"
    gg "Je ne suis tout simplement pas encore habitué à la faune locale"

# game/characters_events_idles/sonya_events.rpy:195
translate french sonya_scene2_day_girlroom_09b9d111:

    # Sonya "А . . ."
    Sonya "AH . . ."

# game/characters_events_idles/sonya_events.rpy:196
translate french sonya_scene2_day_girlroom_521ff667:

    # Sonya "Тогда понятно"
    Sonya "Alors c'est clair"

# game/characters_events_idles/sonya_events.rpy:203
translate french sonya_scene2_day_girlroom_6b068d33:

    # gg "Ты так аккуратно всё делаешь . . ."
    gg "Tu fais tout avec beaucoup de soin. . ."

# game/characters_events_idles/sonya_events.rpy:205
translate french sonya_scene2_day_girlroom_bbcf86fd:

    # gg "Это привычка?"
    gg "Est-ce une habitude ?"

# game/characters_events_idles/sonya_events.rpy:207
translate french sonya_scene2_day_girlroom_a174002e:

    # Sonya "Ага"
    Sonya "Ouais"

# game/characters_events_idles/sonya_events.rpy:208
translate french sonya_scene2_day_girlroom_5e6a7fb2:

    # Sonya "Мне так спокойнее"
    Sonya "Je me sens plus calme de cette façon"

# game/characters_events_idles/sonya_events.rpy:210
translate french sonya_scene2_day_girlroom_ea7be3c1:

    # Sonya "Когда всё сделано как надо"
    Sonya "Quand tout est bien fait"

# game/characters_events_idles/sonya_events.rpy:212
translate french sonya_scene2_day_girlroom_d9f6fc3a:

    # Sonya "Готово"
    Sonya "Prêt"

# game/characters_events_idles/sonya_events.rpy:216
translate french sonya_scene2_day_girlroom_04c6c53d:

    # gg "Спасибо"
    gg "Merci"

# game/characters_events_idles/sonya_events.rpy:218
translate french sonya_scene2_day_girlroom_1c0e0b38:

    # Sonya "А у тебя . . ."
    Sonya "Et toi . . ."

# game/characters_events_idles/sonya_events.rpy:220
translate french sonya_scene2_day_girlroom_041495e8:

    # Sonya "Там, в городе . . ."
    Sonya "Là, en ville. . ."

# game/characters_events_idles/sonya_events.rpy:222
translate french sonya_scene2_day_girlroom_ec4c11a0:

    # Sonya "Кто-нибудь остался?"
    Sonya "Il reste quelqu'un ?"

# game/characters_events_idles/sonya_events.rpy:224
translate french sonya_scene2_day_girlroom_d26255df:

    # gg "Был один человек"
    gg "Il y avait une personne"

# game/characters_events_idles/sonya_events.rpy:226
translate french sonya_scene2_day_girlroom_5319b6ee:

    # gg "Мы давно разошлись"
    gg "Nous nous sommes séparés il y a longtemps"

# game/characters_events_idles/sonya_events.rpy:228
translate french sonya_scene2_day_girlroom_48254a12:

    # gg "Сейчас . . .{w} скорее нет, чем да"
    gg "Maintenant . . .{w} plutôt non que oui"

# game/characters_events_idles/sonya_events.rpy:230
translate french sonya_scene2_day_girlroom_93bf8783:

    # Sonya "Понятно"
    Sonya "Il est clair"

# game/characters_events_idles/sonya_events.rpy:232
translate french sonya_scene2_day_girlroom_bfbf3b82:

    # Sonya "Я просто спросила"
    Sonya "je viens de demander"

# game/characters_events_idles/sonya_events.rpy:238
translate french sonya_scene2_day_girlroom_bde02200:

    # Sonya "Тогда я наверно . . ."
    Sonya "Alors je suppose. . ."

# game/characters_events_idles/sonya_events.rpy:240
translate french sonya_scene2_day_girlroom_230ea232:

    # Sonya "Буду дальше убираться, пыль быстро собирается"
    Sonya "Je vais continuer à nettoyer, la poussière s'accumule rapidement"

# game/characters_events_idles/sonya_events.rpy:243
translate french sonya_scene2_day_girlroom_944c14eb:

    # gg "Спасибо еще раз"
    gg "Merci encore"

# game/characters_events_idles/sonya_events.rpy:245
translate french sonya_scene2_day_girlroom_3735a72e:

    # Sonya "Угу"
    Sonya "Oui"

# game/characters_events_idles/sonya_events.rpy:247
translate french sonya_scene2_day_girlroom_ccc766ff:

    # Sonya "Если что аптечка всегда здесь"
    Sonya "Au cas où, la trousse de premiers secours est toujours là"

# game/characters_events_idles/sonya_events.rpy:273
translate french sonya_scene3_day_bathroom_03e250ee:

    # gg "Эмм Соня, я тут"
    gg "Euh Sonya, je suis là"

# game/characters_events_idles/sonya_events.rpy:281
translate french sonya_scene3_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "Oh"

# game/characters_events_idles/sonya_events.rpy:294
translate french sonya_scene3_day_bathroom_b3aa243a:

    # Sonya "Прости"
    Sonya "Je suis désolé"

# game/characters_events_idles/sonya_events.rpy:296
translate french sonya_scene3_day_bathroom_ea2e53f8:

    # Sonya "Я думала, ванная свободна"
    Sonya "Je pensais que la salle de bain était libre"

# game/characters_events_idles/sonya_events.rpy:298
translate french sonya_scene3_day_bathroom_7f3525bd:

    # Sonya "Это моя ошибка"
    Sonya "C'est de ma faute"

# game/characters_events_idles/sonya_events.rpy:300
translate french sonya_scene3_day_bathroom_b8f5eb09:

    # gg "Всё нормально"
    gg "Tout va bien"

# game/characters_events_idles/sonya_events.rpy:302
translate french sonya_scene3_day_bathroom_623f3607:

    # gg "Ничего страшного"
    gg "C'est bon"

# game/characters_events_idles/sonya_events.rpy:304
translate french sonya_scene3_day_bathroom_7fce0f16:

    # Sonya "{size=*1.3}Нет"
    Sonya "{size=*1.3}Non"

# game/characters_events_idles/sonya_events.rpy:306
translate french sonya_scene3_day_bathroom_c2e17951:

    # Sonya "Я просто сделаю вид"
    Sonya "je vais juste faire semblant"

# game/characters_events_idles/sonya_events.rpy:308
translate french sonya_scene3_day_bathroom_1a86b367:

    # Sonya "Что этого не было"
    Sonya "Que ça n'est pas arrivé"

# game/characters_events_idles/sonya_events.rpy:325
translate french sonya_scene3_day_bathroom_475b14a6:

    # Sonya "Я оставила тебе чай на кухне"
    Sonya "Je t'ai laissé du thé dans la cuisine"

# game/characters_events_idles/sonya_events.rpy:327
translate french sonya_scene3_day_bathroom_c0c28f24:

    # Sonya "Горячий аккуратнее"
    Sonya "Chaud, fais attention"

# game/characters_events_idles/sonya_events.rpy:330
translate french sonya_scene3_day_bathroom_04c6c53d:

    # gg "Спасибо"
    gg "Merci"

# game/characters_events_idles/sonya_events.rpy:351
translate french sonya_scene4_morning_bathroom_db34cd4c:

    # gg "Эм . . ."
    gg "Euh. . ."

# game/characters_events_idles/sonya_events.rpy:353
translate french sonya_scene4_morning_bathroom_f18372c4:

    # Sonya "Ой . . ." with hpunch
    Sonya "Oh . . ." with hpunch

# game/characters_events_idles/sonya_events.rpy:354
translate french sonya_scene4_morning_bathroom_d5441823:

    # gg "Наверно, я зайду попозже"
    gg "Je reviendrai probablement plus tard"

# game/characters_events_idles/sonya_events.rpy:356
translate french sonya_scene4_morning_bathroom_b9dc4392:

    # Sonya "Стой"
    Sonya "Attends"

# game/characters_events_idles/sonya_events.rpy:358
translate french sonya_scene4_morning_bathroom_e21251db:

    # Sonya "Не стесняйся. Чисти зубы, я уже заканчиваю"
    Sonya "Ne sois pas timide. Brosse-toi les dents, j'ai déjà fini"

# game/characters_events_idles/sonya_events.rpy:360
translate french sonya_scene4_morning_bathroom_0d97ff86:

    # gg_chat "Ого . . ."
    gg_chat "Ouah . . ."

# game/characters_events_idles/sonya_events.rpy:364
translate french sonya_scene4_morning_bathroom_7f534b36:

    # Sonya "Тут раньше жили только мы с Маей"
    Sonya "Seules Maya et moi vivions ici auparavant."

# game/characters_events_idles/sonya_events.rpy:366
translate french sonya_scene4_morning_bathroom_8e74c8b9:

    # Sonya "Девушки"
    Sonya "Entre filles"

# game/characters_events_idles/sonya_events.rpy:368
translate french sonya_scene4_morning_bathroom_822105aa:

    # Sonya "Я привыкла ходить"
    Sonya "j'ai l'habitude de marcher comme ça"

# game/characters_events_idles/sonya_events.rpy:370
translate french sonya_scene4_morning_bathroom_759d9a83:

    # Sonya "Так"
    Sonya "Donc"

# game/characters_events_idles/sonya_events.rpy:373
translate french sonya_scene4_morning_bathroom_893810bd:

    # Sonya "Никого это не смущало . . ."
    Sonya "Cela n'a dérangé personne. . ."

# game/characters_events_idles/sonya_events.rpy:375
translate french sonya_scene4_morning_bathroom_2d618e7e:

    # gg "Да где-то я уже такое видел"
    gg "Oui, j'ai déjà vu ça en arrivant"

# game/characters_events_idles/sonya_events.rpy:377
translate french sonya_scene4_morning_bathroom_26a90d56:

    # Sonya "Ты смотришь"
    Sonya "Tu es curieux"

# game/characters_events_idles/sonya_events.rpy:379
translate french sonya_scene4_morning_bathroom_62a5f760:

    # Sonya "Даже не пытаешься отвернуться"
    Sonya "Tu n'essayes même pas de détourner le regard"

# game/characters_events_idles/sonya_events.rpy:382
translate french sonya_scene4_morning_bathroom_1c65dff9:

    # Sonya "И знаешь . . ."
    Sonya "Et tu sais. . ."

# game/characters_events_idles/sonya_events.rpy:384
translate french sonya_scene4_morning_bathroom_7516d68e:

    # Sonya "Мне это нравится . . ."
    Sonya "J'aime ça . . ."

# game/characters_events_idles/sonya_events.rpy:388
translate french sonya_scene4_morning_bathroom_6911a69b:

    # Sonya "Всё"
    Sonya "C'est tout"

# game/characters_events_idles/sonya_events.rpy:390
translate french sonya_scene4_morning_bathroom_bc7d5f86:

    # Sonya "Хватит тебе утренней зарядки для глаз"
    Sonya "Assez d'exercice matinal pour tes yeux"

# game/characters_events_idles/sonya_events.rpy:395
translate french sonya_scene4_morning_bathroom_9bf5f0cd:

    # Sonya "Но всё же . . ."
    Sonya "Mais quand même. . ."

# game/characters_events_idles/sonya_events.rpy:397
translate french sonya_scene4_morning_bathroom_3780446f:

    # extend " Как ты можешь смотреть"
    extend " Comment peux-tu regarder"

# game/characters_events_idles/sonya_events.rpy:401
translate french sonya_scene4_morning_bathroom_1f146f5f:

    # Sonya "И не трогать?"
    Sonya "Et ne pas toucher ?"

# game/characters_events_idles/sonya_events.rpy:416
translate french sonya_scene5_night_girlroom_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/characters_events_idles/sonya_events.rpy:418
translate french sonya_scene5_night_girlroom_f0ccb195:

    # Sonya "[povname] . . ."
    Sonya "[povname] . . ."

# game/characters_events_idles/sonya_events.rpy:422
translate french sonya_scene5_night_girlroom_f0ccb195_1:

    # Sonya "[povname] . . ."
    Sonya "[povname] . . ."

# game/characters_events_idles/sonya_events.rpy:425
translate french sonya_scene5_night_girlroom_6c32fa14:

    # gg "А что . . ."
    gg "Qu'est-ce qui se passe. . ."

# game/characters_events_idles/sonya_events.rpy:427
translate french sonya_scene5_night_girlroom_b3aa243a:

    # Sonya "Прости"
    Sonya "Je suis désolée"

# game/characters_events_idles/sonya_events.rpy:428
translate french sonya_scene5_night_girlroom_4aff93e9:

    # Sonya "Я не хотела тебя резко будить"
    Sonya "Je ne voulais pas te réveiller brusquement"

# game/characters_events_idles/sonya_events.rpy:431
translate french sonya_scene5_night_girlroom_cbd4343b:

    # Sonya "Просто . . . не могу заснуть"
    Sonya "Juste . . . je n'arrive pas à dormir"

# game/characters_events_idles/sonya_events.rpy:433
translate french sonya_scene5_night_girlroom_873c4360:

    # Sonya "Ты спишь так спокойно"
    Sonya "Tu dors si paisiblement"

# game/characters_events_idles/sonya_events.rpy:435
translate french sonya_scene5_night_girlroom_988f1304:

    # Sonya "Посидишь со мной немного?"
    Sonya "Veux-tu t'asseoir avec moi pendant un moment ?"

# game/characters_events_idles/sonya_events.rpy:437
translate french sonya_scene5_night_girlroom_2970a146:

    # Sonya "Пока не отпустит"
    Sonya "Jusqu'à ce que je lâche prise"

# game/characters_events_idles/sonya_events.rpy:439
translate french sonya_scene5_night_girlroom_a9b332b7:

    # gg "Ты устала?"
    gg "tu es fatiguée ?"

# game/characters_events_idles/sonya_events.rpy:441
translate french sonya_scene5_night_girlroom_0fb040eb:

    # Sonya "Нет,{w} не совсем"
    Sonya "Non, {w} pas vraiment"

# game/characters_events_idles/sonya_events.rpy:443
translate french sonya_scene5_night_girlroom_5527f93e:

    # Sonya "Просто думала"
    Sonya "je pensais juste"

# game/characters_events_idles/sonya_events.rpy:446
translate french sonya_scene5_night_girlroom_72ba6d47:

    # gg "О чём?"
    gg "À propos de quoi?"

# game/characters_events_idles/sonya_events.rpy:448
translate french sonya_scene5_night_girlroom_69179d28:

    # Sonya "Да не важно"
    Sonya "Cela n'a pas d'importance"

# game/characters_events_idles/sonya_events.rpy:452
translate french sonya_scene5_night_girlroom_589ad1ec:

    # gg "Ты всё время так?"
    gg "Es-tu comme ça tout le temps ?"

# game/characters_events_idles/sonya_events.rpy:453
translate french sonya_scene5_night_girlroom_6f30ec91:

    # gg "Или бывает, что расслабляешься?"
    gg "Ou est-ce qu'il t'arrive de te détendre ?"

# game/characters_events_idles/sonya_events.rpy:455
translate french sonya_scene5_night_girlroom_fda29abb:

    # Sonya "Раньше было легче"
    Sonya "C'était plus facile avant"

# game/characters_events_idles/sonya_events.rpy:457
translate french sonya_scene5_night_girlroom_1684e2b6:

    # Sonya "Просто я"
    Sonya "Juste moi"

# game/characters_events_idles/sonya_events.rpy:459
translate french sonya_scene5_night_girlroom_09ea6a66:

    # Sonya "Привыкла держать всё под контролем"
    Sonya "J'ai l'habitude de tout garder sous contrôle"

# game/characters_events_idles/sonya_events.rpy:462
translate french sonya_scene5_night_girlroom_27fc4b94:

    # Sonya "Ладно . . ."
    Sonya "Bon . . ."

# game/characters_events_idles/sonya_events.rpy:465
translate french sonya_scene5_night_girlroom_04a163be:

    # Sonya "Вот видишь"
    Sonya "Tu vois"

# game/characters_events_idles/sonya_events.rpy:467
translate french sonya_scene5_night_girlroom_1825b5d8:

    # Sonya "Даже это нормально не могу"
    Sonya "Je ne peux même pas faire ça normalement"

# game/characters_events_idles/sonya_events.rpy:473
translate french sonya_scene5_night_girlroom_4706c7d6:

    # Sonya "Давай просто полежим"
    Sonya "Allongons-nous simplement"

# game/characters_events_idles/sonya_events.rpy:475
translate french sonya_scene5_night_girlroom_dd04d853:

    # Sonya "Я не хочу думать сейчас"
    Sonya "Je ne veux pas penser maintenant"

# game/characters_events_idles/sonya_events.rpy:493
translate french sonya_scene5_night_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "Merci . . ."

# game/characters_events_idles/sonya_events.rpy:495
translate french sonya_scene5_night_girlroom_7edcc3c4:

    # Sonya "Я давно так нормально не спала"
    Sonya "Je n'ai pas aussi bien dormi depuis longtemps"

# game/characters_events_idles/sonya_events.rpy:503
translate french sonya_scene5_night_girlroom_a9d8faa5:

    # Sonya "Если Мая увидит нас, будет много вопросов"
    Sonya "Si Maya nous voit, elle aura beaucoup de questions"

# game/characters_events_idles/sonya_events.rpy:505
translate french sonya_scene5_night_girlroom_2c86168e:

    # Sonya "Я сделаю тебе завтрак"
    Sonya "je vais te préparer le petit déjeuner"

# game/characters_events_idles/sonya_events.rpy:507
translate french sonya_scene5_night_girlroom_9663ea36:

    # Sonya "Он будет вкусным, не переживай"
    Sonya "Ce sera délicieux, ne t'inquiète pas"

# game/characters_events_idles/sonya_events.rpy:525
translate french sonya_scene6_evening_myroom_1d152ede:

    # gg "Привет!"
    gg "Bonjour!"

# game/characters_events_idles/sonya_events.rpy:527
translate french sonya_scene6_evening_myroom_4979c711:

    # Sonya "Эй, ты аниме смотришь?"
    Sonya "Hé, tu regardes des anime ?"

# game/characters_events_idles/sonya_events.rpy:529
translate french sonya_scene6_evening_myroom_8dbdedb7:

    # Sonya "Тут только началось"
    Sonya "Ça vient juste de commencer"

# game/characters_events_idles/sonya_events.rpy:531
translate french sonya_scene6_evening_myroom_a94af5bd:

    # gg "Ага, почему бы и нет"
    gg "Ouais, pourquoi pas"

# game/characters_events_idles/sonya_events.rpy:538
translate french sonya_scene6_evening_myroom_4fa070d4:

    # gg "Забавно . . ."
    gg "C'est drôle. . ."

# game/characters_events_idles/sonya_events.rpy:540
translate french sonya_scene6_evening_myroom_2e5cd401:

    # extend "Теперь этот диван - моя кровать"
    extend "Maintenant, ce canapé est mon lit"

# game/characters_events_idles/sonya_events.rpy:542
translate french sonya_scene6_evening_myroom_a3f8d8b5:

    # gg "Я привык на нём фильмы смотреть, а теперь ещё и сплю здесь"
    gg "J'ai l'habitude de regarder des films dessus, et maintenant je dors aussi ici"

# game/characters_events_idles/sonya_events.rpy:543
translate french sonya_scene6_evening_myroom_8d9b5058:

    # Sonya "Вообще - то"
    Sonya "En fait"

# game/characters_events_idles/sonya_events.rpy:547
translate french sonya_scene6_evening_myroom_8bf7cd77:

    # extend " раньше это была моя кровать"
    extend " c'était mon lit"

# game/characters_events_idles/sonya_events.rpy:549
translate french sonya_scene6_evening_myroom_4b9b63e3:

    # Sonya "До ухода Линды"
    Sonya "Avant que Linda ne parte"

# game/characters_events_idles/sonya_events.rpy:551
translate french sonya_scene6_evening_myroom_2c51288e:

    # Sonya "А она тогда жила в моей комнатe"
    Sonya "Et puis elle a vécu dans ma chambre"

# game/characters_events_idles/sonya_events.rpy:553
translate french sonya_scene6_evening_myroom_3467de90:

    # gg "Серьёзно?"
    gg "Sérieusement?"

# game/characters_events_idles/sonya_events.rpy:555
translate french sonya_scene6_evening_myroom_80955fa4:

    # Sonya "Да, но потом мы сделали ремонт, чтобы всё было по - нашему"
    Sonya "Oui, mais ensuite nous avons fait des rénovations pour que tout soit à notre façon"

# game/characters_events_idles/sonya_events.rpy:557
translate french sonya_scene6_evening_myroom_3d5a6534:

    # gg "Красиво получилось . . . {w}и дом где провел детство все еще чувствуется"
    gg "Cela s’est avéré magnifique. . . {w}et la maison où vous avez passé votre enfance se ressent encore"

# game/characters_events_idles/sonya_events.rpy:562
translate french sonya_scene6_evening_myroom_0bab6ed7:

    # "Ты мог бы идти один. Я бы справилась"
    "Tu pourrais y aller seul. Je pourrais le gérer"

# game/characters_events_idles/sonya_events.rpy:564
translate french sonya_scene6_evening_myroom_e09cf293:

    # "Ты слишком спокоен. Обычно люди стараются понравиться"
    "Tu es trop calme. Les gens essaient généralement de plaire"

# game/characters_events_idles/sonya_events.rpy:566
translate french sonya_scene6_evening_myroom_93462049:

    # "А я не хочу «стараться». Хочу, чтобы ты узнала меня настоящего"
    "Mais je ne veux pas « essayer ». Je veux que tu connaisses le vrai moi"

# game/characters_events_idles/sonya_events.rpy:568
translate french sonya_scene6_evening_myroom_25dcefcc:

    # "Знаешь, у меня есть и более интересные дела"
    "Tu sais, j'ai des choses plus intéressantes à faire"

# game/characters_events_idles/sonya_events.rpy:570
translate french sonya_scene6_evening_myroom_fda89b59:

    # "Тогда почему ты всё ещё здесь?"
    "Alors pourquoi es-tu toujours là ?"

# game/characters_events_idles/sonya_events.rpy:573
translate french sonya_scene6_evening_myroom_7f029619:

    # Sonya "Вот смотри . . ."
    Sonya "Regardes ici. . ."

# game/characters_events_idles/sonya_events.rpy:575
translate french sonya_scene6_evening_myroom_6f549ff9:

    # extend " она играет „недоступную“"
    extend " elle joue \"inaccessible\""

# game/characters_events_idles/sonya_events.rpy:577
translate french sonya_scene6_evening_myroom_beb1c184:

    # Sonya "Хотя видно, что сохнет по нему . . ."
    Sonya "Bien qu'on voit qu’elle en pince pour lui. . ."

# game/characters_events_idles/sonya_events.rpy:580
translate french sonya_scene6_evening_myroom_766aa28c:

    # gg "Может, в этом и драма?"
    gg "C'est peut-être ça le drame ?"

# game/characters_events_idles/sonya_events.rpy:582
translate french sonya_scene6_evening_myroom_ae35e350:

    # Sonya "Драма в том, что тянет резину"
    Sonya "Le drame s'éternise"

# game/characters_events_idles/sonya_events.rpy:584
translate french sonya_scene6_evening_myroom_70feb79f:

    # Sonya "Зачем, если всё ясно?"
    Sonya "Pourquoi, si tout est clair ?"

# game/characters_events_idles/sonya_events.rpy:585
translate french sonya_scene6_evening_myroom_b291874f:

    # Sonya "{sc}Это раздражает{/sc}" with hpunch
    Sonya "{sc}C'est agaçant{/sc}" with hpunch

# game/characters_events_idles/sonya_events.rpy:587
translate french sonya_scene6_evening_myroom_6ef8cdd4:

    # gg "Ты бы решила быстрее?"
    gg "Tu te serais décidée plus rapidement ?"

# game/characters_events_idles/sonya_events.rpy:589
translate french sonya_scene6_evening_myroom_2db4fbf2:

    # Sonya "Намного быстрее . . ."
    Sonya "Beaucoup plus rapidement. . ."

# game/characters_events_idles/sonya_events.rpy:591
translate french sonya_scene6_evening_myroom_c5704027:

    # Sonya "Скучное аниме"
    Sonya "Quel animé ennuyeux"

# game/characters_events_idles/sonya_events.rpy:593
translate french sonya_scene6_evening_myroom_9be82b23:

    # Sonya "Я не могу сидеть спокойно"
    Sonya "Je ne peux pas rester assise"

# game/characters_events_idles/sonya_events.rpy:595
translate french sonya_scene6_evening_myroom_13513f79:

    # gg "Тогда ложись, может, так будет легче"
    gg "Alors allonge-toi, peut-être que ce sera plus facile"

# game/characters_events_idles/sonya_events.rpy:597
translate french sonya_scene6_evening_myroom_0d9cdeae:

    # Sonya "Лечь говоришь?"
    Sonya "Tu parles de s'allonger ?"

# game/characters_events_idles/sonya_events.rpy:605
translate french sonya_scene6_evening_myroom_448d2ea3:

    # Sonya "Да так спокойнее . . ."
    Sonya "C'est tellement plus calme. . ."

# game/characters_events_idles/sonya_events.rpy:610
translate french sonya_scene6_evening_myroom_75e70e12:

    # Sonya "{sc}Ах . . .{/sc}"
    Sonya "{sc}Ah. . .{/sc}"

# game/characters_events_idles/sonya_events.rpy:613
translate french sonya_scene6_evening_myroom_376482db:

    # Sonya "Вот так . . ."
    Sonya "Comme ça . . ."

# game/characters_events_idles/sonya_events.rpy:614
translate french sonya_scene6_evening_myroom_28a0cb64:

    # Sonya "Наконец - то"
    Sonya "Enfin"

# game/characters_events_idles/sonya_events.rpy:616
translate french sonya_scene6_evening_myroom_2157c7a2:

    # Sonya "Не бойся, мне нравится"
    Sonya "N'aie pas peur, j'aime ça"

# game/characters_events_idles/sonya_events.rpy:619
translate french sonya_scene6_evening_myroom_e0c310ab:

    # Sonya "В ванной ты только смотрел"
    Sonya "Dans la salle de bain tu viens de regarder"

# game/characters_events_idles/sonya_events.rpy:621
translate french sonya_scene6_evening_myroom_23073e11:

    # Sonya "Тут я тебе помогу"
    Sonya "Ici, je vais t'aider"

# game/characters_events_idles/sonya_events.rpy:623
translate french sonya_scene6_evening_myroom_77e32f3e:

    # Sonya "Я знаю, что ты хочешь"
    Sonya "Je sais ce que tu veux"

# game/characters_events_idles/sonya_events.rpy:625
translate french sonya_scene6_evening_myroom_314984e9:

    # Sonya "Просто помогаю"
    Sonya "j'aide juste"

# game/characters_events_idles/sonya_events.rpy:629
translate french sonya_scene6_evening_myroom_70da84e8:

    # Sonya "Мне приятно . . . {w}даже больше, чем я ожидала"
    Sonya "Je suis contente. . . {w}encore plus que ce à quoi je m'attendais"

# game/characters_events_idles/sonya_events.rpy:630
translate french sonya_scene6_evening_myroom_42733475:

    # gg "У тебя прекрасная грудь . . . {w}мягкая и тёплая"
    gg "Tu as des seins magnifiques. . . {w}doux et chaud"

# game/characters_events_idles/sonya_events.rpy:631
translate french sonya_scene6_evening_myroom_ae3a5ec7:

    # gg "Идеальная"
    gg "Parfait"

# game/characters_events_idles/sonya_events.rpy:632
translate french sonya_scene6_evening_myroom_ec947a50:

    # Sonya "Хитрый . . ."
    Sonya "Rusé . . ."

# game/characters_events_idles/sonya_events.rpy:633
translate french sonya_scene6_evening_myroom_9e059832:

    # Sonya "Знаешь ведь, что я краснею от таких слов"
    Sonya "Tu sais que je rougis devant de tels mots"

# game/characters_events_idles/sonya_events.rpy:635
translate french sonya_scene6_evening_myroom_9a2913c4:

    # Sonya "Но продолжай"
    Sonya "Mais continue"

# game/characters_events_idles/sonya_events.rpy:644
translate french sonya_scene6_evening_myroom_394ba447:

    # Maya "А что это вы тут . . ."
    Maya "Pourquoi es-tu ici ? . ."

# game/characters_events_idles/sonya_events.rpy:646
translate french sonya_scene6_evening_myroom_f2d7a854:

    # Maya "В обнимку сидите?"
    Maya "Vous étiez blottis l'un contre l'autre ?"

# game/characters_events_idles/sonya_events.rpy:648
translate french sonya_scene6_evening_myroom_a3e76380:

    # Sonya "Аниме смотрим. {w}Но он скучный"
    Sonya "Nous regardons des animes. {w}Mais il est ennuyeux"

# game/characters_events_idles/sonya_events.rpy:649
translate french sonya_scene6_evening_myroom_28afd6ea:

    # gg "Да, просто аниме"
    gg "Oui, juste des animés"

# game/characters_events_idles/sonya_events.rpy:651
translate french sonya_scene6_evening_myroom_aa558823:

    # Maya "Не думайте что я этого не видела . . ."
    Maya "Ne pensez pas que je n'ai pas vu ça. . ."

# game/characters_events_idles/sonya_events.rpy:654
translate french sonya_scene6_evening_myroom_eba4c233:

    # Sonya "Спасибо за вечер"
    Sonya "Merci pour la soirée"

# game/characters_events_idles/sonya_events.rpy:656
translate french sonya_scene6_evening_myroom_e7128efe:

    # Sonya "Было . . . {w} приятно"
    Sonya "C'était . . . {w} sympa"

# game/characters_events_idles/sonya_events.rpy:660
translate french sonya_scene6_evening_myroom_222b7c49:

    # Sonya "Давай оставим аниме на завтра"
    Sonya "Laissons l'animé pour demain"

# game/characters_events_idles/sonya_events.rpy:661
translate french sonya_scene6_evening_myroom_be1b9cb9:

    # Sonya "Закончим на этом, а то я и сама не остановлюсь"
    Sonya "Finissons-en, sinon je ne m'arrêterai pas."

# game/characters_events_idles/sonya_events.rpy:663
translate french sonya_scene6_evening_myroom_b989363c:

    # gg ". . ."
    gg ". . ."

# game/characters_events_idles/sonya_events.rpy:678
translate french sonya_scene7_evening_girlroom_0262890b:

    # Sonya "Зайдёшь ко мне?"
    Sonya "Veux-tu venir avec moi ?"

# game/characters_events_idles/sonya_events.rpy:680
translate french sonya_scene7_evening_girlroom_cf65688b:

    # Sonya "Просто . . . {w}хочу поговорить "
    Sonya "Juste . . . {w}Je veux parler"

# game/characters_events_idles/sonya_events.rpy:682
translate french sonya_scene7_evening_girlroom_0609085f:

    # gg "Конечно"
    gg "Certainement"

# game/characters_events_idles/sonya_events.rpy:684
translate french sonya_scene7_evening_girlroom_fe1b6c78:

    # gg "Ты какая-то задумчивая"
    gg "Tu es plutôt réfléchi"

# game/characters_events_idles/sonya_events.rpy:686
translate french sonya_scene7_evening_girlroom_24fe6265:

    # Sonya "Да . . ."
    Sonya "Oui. . ."

# game/characters_events_idles/sonya_events.rpy:688
translate french sonya_scene7_evening_girlroom_546a584b:

    # Sonya "Просто не могу всё выкинуть из головы"
    Sonya "Je n'arrive tout simplement pas à tout sortir de ma tête"

# game/characters_events_idles/sonya_events.rpy:690
translate french sonya_scene7_evening_girlroom_7ff0eaf1:

    # Sonya "Всё как-то закрутилось слишком быстро"
    Sonya "D'une manière ou d'une autre, tout a commencé à tourner trop vite"

# game/characters_events_idles/sonya_events.rpy:692
translate french sonya_scene7_evening_girlroom_fb1f6848:

    # gg "В каком смысле?"
    gg "Dans quel sens ?"

# game/characters_events_idles/sonya_events.rpy:694
translate french sonya_scene7_evening_girlroom_b7dadb54:

    # Sonya "Ну . . . {w}обычно я держусь спокойно"
    Sonya "Bien . . . {w}Je reste généralement calme"

# game/characters_events_idles/sonya_events.rpy:696
translate french sonya_scene7_evening_girlroom_8a221fed:

    # Sonya "Всё у меня под контролем"
    Sonya "J'ai tout sous contrôle"

# game/characters_events_idles/sonya_events.rpy:698
translate french sonya_scene7_evening_girlroom_afb359d5:

    # Sonya "Но рядом с тобой . . . {w}всё иначе"
    Sonya "Mais à côté de toi. . . {w}tout est différent"

# game/characters_events_idles/sonya_events.rpy:700
translate french sonya_scene7_evening_girlroom_486c8325:

    # gg "Иначе - это плохо?"
    gg "Sinon, est-ce que c'est mauvais ?"

# game/characters_events_idles/sonya_events.rpy:702
translate french sonya_scene7_evening_girlroom_6f2ad814:

    # Sonya "Иногда кажется, что я делаю глупости"
    Sonya "Parfois, j'ai l'impression de faire des choses stupides"

# game/characters_events_idles/sonya_events.rpy:704
translate french sonya_scene7_evening_girlroom_b81ca64b:

    # Sonya "Такие . . . {w}нелепые"
    Sonya "Tellement. . . {w}ridicule"

# game/characters_events_idles/sonya_events.rpy:706
translate french sonya_scene7_evening_girlroom_716ea2d0:

    # Sonya "Будто я снова подросток"
    Sonya "C'est comme si j'étais à nouveau une adolescente"

# game/characters_events_idles/sonya_events.rpy:708
translate french sonya_scene7_evening_girlroom_c3165439:

    # gg " . . ."
    gg ". . ."

# game/characters_events_idles/sonya_events.rpy:710
translate french sonya_scene7_evening_girlroom_43cc3ee5:

    # Sonya "Я не уверена в своём поведении"
    Sonya "Je n'ai pas confiance en mon comportement"

# game/characters_events_idles/sonya_events.rpy:711
translate french sonya_scene7_evening_girlroom_bf81f51b:

    # Sonya "Может, я слишком тороплюсь"
    Sonya "Peut-être que je suis trop pressée"

# game/characters_events_idles/sonya_events.rpy:713
translate french sonya_scene7_evening_girlroom_7263e949:

    # Sonya "Может, выгляжу смешно"
    Sonya "Peut-être que j'ai l'air drôle"

# game/characters_events_idles/sonya_events.rpy:715
translate french sonya_scene7_evening_girlroom_5c74b5ea:

    # gg "Мне так не кажется"
    gg "Je ne pense pas"

# game/characters_events_idles/sonya_events.rpy:717
translate french sonya_scene7_evening_girlroom_9d42851b:

    # Sonya "А если вдруг?"
    Sonya "Et si tout à coup ?"

# game/characters_events_idles/sonya_events.rpy:718
translate french sonya_scene7_evening_girlroom_6fb3c26c:

    # Sonya "Если я правда не такая, какой должна быть?"
    Sonya "Et si je ne suis vraiment pas celle que je devrais être ?"

# game/characters_events_idles/sonya_events.rpy:720
translate french sonya_scene7_evening_girlroom_5c8cc88c:

    # Sonya "Ты всё равно примешь меня?"
    Sonya "M'accepteras-tu toujours ?"

# game/characters_events_idles/sonya_events.rpy:727
translate french sonya_scene7_evening_girlroom_ca1ff0ec:

    # gg "Мне нравишься настоящая ты"
    gg "J'aime le vrai toi"

# game/characters_events_idles/sonya_events.rpy:730
translate french sonya_scene7_evening_girlroom_495fe1ef:

    # gg "Мне не нужно, чтобы ты была какой-то другой"
    gg "Je n'ai pas besoin que tu sois autre chose"

# game/characters_events_idles/sonya_events.rpy:746
translate french sonya_scene7_evening_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "Merci . . ."

# game/characters_events_idles/sonya_events.rpy:747
translate french sonya_scene7_evening_girlroom_860f4d16:

    # Sonya "Это именно то что я хотела"
    Sonya "C'est exactement ce que je voulais"

# game/characters_events_idles/sonya_events.rpy:753
translate french sonya_scene7_evening_girlroom_489479bc:

    # Sonya "{sc}Да . . . Так . . .{/sc}"
    Sonya "{sc}Oui. . . Donc . . .{/sc}"

# game/characters_events_idles/sonya_events.rpy:759
translate french sonya_scene7_evening_girlroom_2d94ee37:

    # Sonya "На диване ты меня трогал"
    Sonya "Sur le canapé tu m'as touchée"

# game/characters_events_idles/sonya_events.rpy:760
translate french sonya_scene7_evening_girlroom_fc982615:

    # Sonya "Теперь - моя очередь"
    Sonya "Maintenant c'est mon tour"

# game/characters_events_idles/sonya_events.rpy:767
translate french sonya_scene7_evening_girlroom_7b973257:

    # Sonya "Смотри на меня"
    Sonya "Regardes-moi"

# game/characters_events_idles/sonya_events.rpy:775
translate french sonya_scene7_evening_girlroom_1b8740c5:

    # Sonya "Всё - ты теперь мой!"
    Sonya "C'est tout, tu es à moi maintenant !"

# game/characters_events_idles/sonya_events.rpy:783
translate french sonya_scene7_evening_girlroom_2da445da:

    # Sonya "Подожди тут"
    Sonya "Attends ici"

# game/characters_events_idles/sonya_events.rpy:785
translate french sonya_scene7_evening_girlroom_250fe814:

    # Sonya "Я быстро"
    Sonya "je fait vite"

# game/characters_events_idles/sonya_events.rpy:791
translate french sonya_scene7_evening_girlroom_dadabf98:

    # gg_chat "Это случилось так быстро . . . "
    gg_chat "C'est arrivé si vite. . ."

# game/characters_events_idles/sonya_events.rpy:798
translate french sonya_scene7_evening_girlroom_e844ad84:

    # Sonya "Останься"
    Sonya "Restes"

# game/characters_events_idles/sonya_events.rpy:800
translate french sonya_scene7_evening_girlroom_1d2efc6a:

    # Sonya "Посиди со мной"
    Sonya "Assieds-toi avec moi"

# game/characters_events_idles/sonya_events.rpy:802
translate french sonya_scene7_evening_girlroom_b435d332:

    # Sonya "И посмотрим, куда это нас приведёт."
    Sonya "Et voyons où cela nous mène."

# game/characters_events_idles/sonya_events.rpy:805
translate french sonya_scene7_evening_girlroom_ca91d43d:

    # gg_chat "Было тепло"
    gg_chat "Il faisait chaud"

# game/characters_events_idles/sonya_events.rpy:806
translate french sonya_scene7_evening_girlroom_899d5485:

    # gg_chat "Я хотел остаться рядом"
    gg_chat "Je voulais rester proche"

translate french strings:

    # game/characters_events_idles/sonya_events.rpy:516
    old "Утро"
    new "Matin"

    # game/characters_events_idles/sonya_events.rpy:608
    old "Играешь со мной?"
    new "Est-ce que tu joues avec moi ?"

    # game/characters_events_idles/sonya_events.rpy:618
    old "Мне так хорошо"
    new "Je me sens si bien"

    # game/characters_events_idles/sonya_events.rpy:725
    old "Такой ты и нужна"
    new "C’est comme ça que tu es, et c’est très bien."

    # game/characters_events_idles/sonya_events.rpy:734
    old "Поцеловать"
    new "Baiser"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/sonya_events.rpy:20
translate french sonya_scene1_morning_kitchen_c92bc08a:

    # Sonya "Там диван, конечно, старый"
    Sonya "Il y a bien sûr un vieux canapé là-bas."

# game/characters_events_idles/sonya_events.rpy:50
translate french sonya_scene1_morning_kitchen_12302e27:

    # Sonya "У нас, обычно, никто особо не спрашивает"
    Sonya "Habituellement, personne ne nous demande grand-chose"

# game/characters_events_idles/sonya_events.rpy:161
translate french sonya_scene2_day_girlroom_9c553288:

    # Sonya "Так и планировал . . ."
    Sonya "C'est ce que j'avais prévu. . ."

# game/characters_events_idles/sonya_events.rpy:177
translate french sonya_scene2_day_girlroom_c5761118:

    # Sonya "Ты, получается, больше утренний человек?"
    Sonya "Êtes-vous plutôt du genre matinal ?"

# game/characters_events_idles/sonya_events.rpy:335
translate french sonya_scene3_day_bathroom_21f8234f:

    # Sonya "Горячий, аккуратнее"
    Sonya "Chaud, fais attention"

# game/characters_events_idles/sonya_events.rpy:383
translate french sonya_scene4_morning_bathroom_0d2b005c:

    # gg "Да, где-то я уже такое видел"
    gg "Oui, j'ai déjà vu ça quelque part"

# game/characters_events_idles/sonya_events.rpy:385
translate french sonya_scene4_morning_bathroom_11b14ed3:

    # Sonya "Ты смотришь . . ."
    Sonya "Vous cherchez. . ."

# game/characters_events_idles/sonya_events.rpy:486
translate french sonya_scene5_night_girlroom_44967887:

    # Sonya "Я не хочу ни о чем думать . . ."
    Sonya "Je ne veux penser à rien. . ."

# game/characters_events_idles/sonya_events.rpy:835
translate french sonya_scene8_morning_kitchen_a482bb49:

    # gg "Утречка"
    gg "Bonjour"

# game/characters_events_idles/sonya_events.rpy:837
translate french sonya_scene8_morning_kitchen_ce42d6cf:

    # Sonya "Доброе утро . . ."
    Sonya "Bonjour . . ."

# game/characters_events_idles/sonya_events.rpy:839
translate french sonya_scene8_morning_kitchen_72c13c11:

    # Sonya "Я . . . почти закончила готовить, садись"
    Sonya "Je . . . presque fini de cuisiner, assieds-toi"

# game/characters_events_idles/sonya_events.rpy:842
translate french sonya_scene8_morning_kitchen_bb1eb7c8:

    # gg "Ты рано встала"
    gg "Tu t'es levée tôt"

# game/characters_events_idles/sonya_events.rpy:844
translate french sonya_scene8_morning_kitchen_42ef4d92:

    # Sonya "Не спалось"
    Sonya "Je n'ai pas pu dormir"

# game/characters_events_idles/sonya_events.rpy:846
translate french sonya_scene8_morning_kitchen_a756dcde:

    # Sonya "Подумала . . ."
    Sonya "J'ai réfléchi . . ."

# game/characters_events_idles/sonya_events.rpy:848
translate french sonya_scene8_morning_kitchen_381d05fd:

    # Sonya "Раз ты всё равно проснёшься . . ."
    Sonya "Puisque tu vas de toute façon te réveiller . . ."

# game/characters_events_idles/sonya_events.rpy:850
translate french sonya_scene8_morning_kitchen_13f1fe10:

    # Sonya "Будет хорошо, заранее приготовить тебе"
    Sonya "Ça va être bien de préparer quelque chose pour toi à l'avance"

# game/characters_events_idles/sonya_events.rpy:861
translate french sonya_scene8_morning_kitchen_c3201521:

    # Sonya "Можно?"
    Sonya "C'est bon?"

# game/characters_events_idles/sonya_events.rpy:865
translate french sonya_scene8_morning_kitchen_0609085f:

    # gg "Конечно"
    gg "Bien sûr"

# game/characters_events_idles/sonya_events.rpy:870
translate french sonya_scene8_morning_kitchen_f49db0d9:

    # gg "Очень вкусно"
    gg "C'est très bon"

# game/characters_events_idles/sonya_events.rpy:872
translate french sonya_scene8_morning_kitchen_6f15bff0:

    # Sonya "Я рада"
    Sonya "Je suis contente"

# game/characters_events_idles/sonya_events.rpy:874
translate french sonya_scene8_morning_kitchen_8bd5d020:

    # Sonya "Мне важно, чтобы тебе было хорошо"
    Sonya "Il est important pour moi que tu sois bien"

# game/characters_events_idles/sonya_events.rpy:882
translate french sonya_scene8_morning_kitchen_41dbce33:

    # Sonya "Я всю ночь думала . . ."
    Sonya "J'ai réfléchi toute la nuit . . ."

# game/characters_events_idles/sonya_events.rpy:885
translate french sonya_scene8_morning_kitchen_f519c6fc:

    # Sonya "Раньше я беспокоилась"
    Sonya "Avant, je m'inquiétais"

# game/characters_events_idles/sonya_events.rpy:887
translate french sonya_scene8_morning_kitchen_b0e09a72:

    # Sonya "А сегодня . . ."
    Sonya "Mais aujourd'hui . . ."

# game/characters_events_idles/sonya_events.rpy:889
translate french sonya_scene8_morning_kitchen_814991c8:

    # Sonya "Мне спокойно"
    Sonya "Je me sens tranquille"

# game/characters_events_idles/sonya_events.rpy:898
translate french sonya_scene8_morning_kitchen_d0794f94:

    # Sonya "Если ты не против . . ."
    Sonya "Si ça ne te dérange pas . . ."

# game/characters_events_idles/sonya_events.rpy:900
translate french sonya_scene8_morning_kitchen_9c748c84:

    # Sonya "Я могу . . ."
    Sonya "Je peux . . ."

# game/characters_events_idles/sonya_events.rpy:904
translate french sonya_scene8_morning_kitchen_a877578e:

    # Sonya "Быть чуть ближе"
    Sonya "Être un peu plus proche"

# game/characters_events_idles/sonya_events.rpy:926
translate french sonya_scene8_morning_kitchen_1b7d05a8:

    # Sonya "Чувствовать, как ты становишься твёрже . . ."
    Sonya "Sentir comment tu deviens plus dur . . ."

# game/characters_events_idles/sonya_events.rpy:927
translate french sonya_scene8_morning_kitchen_b85aacb1:

    # Sonya "От моего прикосновения . . . {w}это так . . ."
    Sonya "De mon toucher . . . {w}c'est comme ça . . ."

# game/characters_events_idles/sonya_events.rpy:928
translate french sonya_scene8_morning_kitchen_9213f2a8:

    # Sonya ". . . Заводит. {w}Сильнее, чем я думала"
    Sonya ". . . Ça m'excite. {w}Plus que je ne pensais"

# game/characters_events_idles/sonya_events.rpy:929
translate french sonya_scene8_morning_kitchen_9bc062d5:

    # Sonya "Смотри на меня . . . только на меня . . ."
    Sonya "Regarde-moi . . . seulement moi . . ."

# game/characters_events_idles/sonya_events.rpy:940
translate french sonya_scene8_morning_kitchen_55a277bb:

    # Sonya "Я . . . не знаю, как правильно это сказать . . ."
    Sonya "Je . . . ne sais pas comment le dire correctement . . ."

# game/characters_events_idles/sonya_events.rpy:942
translate french sonya_scene8_morning_kitchen_beb08d03:

    # Sonya "Но мне хорошо, когда ты рядом"
    Sonya "Mais je me sens bien quand tu es près de moi"

# game/characters_events_idles/sonya_events.rpy:961
translate french sonya_scene9_night_myroom_9a8b0be2:

    # gg "Привет"
    gg "Salut"

# game/characters_events_idles/sonya_events.rpy:963
translate french sonya_scene9_night_myroom_b3a2b8a1:

    # Sonya "Привет ты ещё не ложишься?"
    Sonya "Salut, tu ne vas pas encore te coucher ?"

# game/characters_events_idles/sonya_events.rpy:965
translate french sonya_scene9_night_myroom_bb3c3085:

    # Sonya "Тогда пойдём вместе в ванную?"
    Sonya "Alors, on va ensemble à la salle de bain ?"

# game/characters_events_idles/sonya_events.rpy:967
translate french sonya_scene9_night_myroom_9afefc8e:

    # Sonya "Я хочу голову помыть . . ."
    Sonya "Je veux me laver les cheveux . . ."

# game/characters_events_idles/sonya_events.rpy:969
translate french sonya_scene9_night_myroom_b4639877:

    # Sonya "И тебе тоже"
    Sonya "Et toi aussi"

# game/characters_events_idles/sonya_events.rpy:971
translate french sonya_scene9_night_myroom_66416cc5:

    # gg "Ну пойдем"
    gg "Alors, allons-y"

# game/characters_events_idles/sonya_events.rpy:981
translate french sonya_scene9_night_myroom_c5d3f2b1:

    # Sonya "Ты тоже раздевайся давай"
    Sonya "Enlève-toi aussi, allons-y"

# game/characters_events_idles/sonya_events.rpy:987
translate french sonya_scene9_night_myroom_ebd2cc14:

    # Sonya "Подожди . . ."
    Sonya "Attends . . ."

# game/characters_events_idles/sonya_events.rpy:989
translate french sonya_scene9_night_myroom_abb56970:

    # Sonya "У тебя молния заела"
    Sonya "Ta fermeture éclair est bloquée"

# game/characters_events_idles/sonya_events.rpy:996
translate french sonya_scene9_night_myroom_3672b0c0:

    # Sonya "Быстро ты . . ."
    Sonya "Tu es rapide . . ."

# game/characters_events_idles/sonya_events.rpy:998
translate french sonya_scene9_night_myroom_ba83a14c:

    # Sonya "Давай садись"
    Sonya "Assieds-toi, allons"

# game/characters_events_idles/sonya_events.rpy:1000
translate french sonya_scene9_night_myroom_674bc70f:

    # Sonya "Стой . . . не двигайся"
    Sonya "Attends . . . ne bouge pas"

# game/characters_events_idles/sonya_events.rpy:1002
translate french sonya_scene9_night_myroom_dc365125:

    # Sonya "Я хочу сама"
    Sonya "Je veux le faire moi-même"

# game/characters_events_idles/sonya_events.rpy:1006
translate french sonya_scene9_night_myroom_9c274529:

    # gg "У меня отличный вид"
    gg "J'ai une excellente vue"

# game/characters_events_idles/sonya_events.rpy:1008
translate french sonya_scene9_night_myroom_4af82ab0:

    # Sonya "Я знаю"
    Sonya "Je sais"

# game/characters_events_idles/sonya_events.rpy:1010
translate french sonya_scene9_night_myroom_d339691d:

    # Sonya "Мне просто приятно, что ты смотришь"
    Sonya "Ça me plaît que tu regardes"

# game/characters_events_idles/sonya_events.rpy:1012
translate french sonya_scene9_night_myroom_98944675:

    # Sonya "Теперь ты меня"
    Sonya "Maintenant tu m'as"

# game/characters_events_idles/sonya_events.rpy:1016
translate french sonya_scene9_night_myroom_06da4938:

    # Sonya "Ты точно будешь пахнуть как я"
    Sonya "Tu vas certainement sentir comme moi"

# game/characters_events_idles/sonya_events.rpy:1018
translate french sonya_scene9_night_myroom_aa254d79:

    # Sonya "Ты такой тёплый сейчас . . . мне это нравится"
    Sonya "Tu es tellement chaud maintenant . . . J'aime ça"

# game/characters_events_idles/sonya_events.rpy:1020
translate french sonya_scene9_night_myroom_908db179:

    # Sonya "Пойдём спать вместе"
    Sonya "Allons dormir ensemble"

# game/characters_events_idles/sonya_events.rpy:1022
translate french sonya_scene9_night_myroom_e190b45e:

    # Sonya "Я не хочу сегодня одна"
    Sonya "Je ne veux pas être seule ce soir"

# game/characters_events_idles/sonya_events.rpy:1024
translate french sonya_scene9_night_myroom_dd09f522:

    # Sonya "Но на сегодня приключений хватит . . . а то я завтра вообще не проснусь"
    Sonya "Mais ça suffit pour aujourd'hui . . . sinon je ne vais même pas me réveiller demain"

# game/characters_events_idles/sonya_events.rpy:1031
translate french sonya_scene9_night_myroom_654cb5b3:

    # Sonya "Спокойной ночи"
    Sonya "Bonne nuit"

# game/characters_events_idles/sonya_events.rpy:1032
translate french sonya_scene9_night_myroom_5e65cbb1:

    # Sonya "{bt=a3-p2.0-s3.0}Любимый"
    Sonya "{bt=a3-p2.0-s3.0}Chéri"

# game/characters_events_idles/sonya_events.rpy:1038
translate french sonya_scene9_night_myroom_7f924e87:

    # gg "Спокойной"
    gg "Bonne"

# game/characters_events_idles/sonya_events.rpy:1039
translate french sonya_scene9_night_myroom_02749544:

    # gg "Я правда рад, что я с тобой"
    gg "Je suis vraiment heureux d'être avec toi"

