﻿# TODO: Translation updated at 2026-01-21 13:15

# game/characters_events_idles/sonya_idles.rpy:7
translate french sonya_Idle_morning_bathroom_scene_26477ebd:

    # Sonya "О, кто-то перестал стучаться?"
    Sonya "Oh, est-ce que quelqu'un a arrêté de frapper ?"

# game/characters_events_idles/sonya_idles.rpy:8
translate french sonya_Idle_morning_bathroom_scene_e490c24b:

    # gg "А смысл, если дверь открыта . . ."
    gg "A quoi ça sert si la porte est ouverte ? . ."

# game/characters_events_idles/sonya_idles.rpy:10
translate french sonya_Idle_morning_bathroom_scene_2e0a6a8c:

    # Sonya "Смелый стал с утра . . ."
    Sonya "Devenu audacieux le matin. . ."

# game/characters_events_idles/sonya_idles.rpy:12
translate french sonya_Idle_morning_bathroom_scene_f7e61e71:

    # gg "Просто решил не терять привычку к риску"
    gg "J'ai juste décidé de ne pas perdre l'habitude du risque"

# game/characters_events_idles/sonya_idles.rpy:13
translate french sonya_Idle_morning_bathroom_scene_31735247:

    # gg_chat "Она даже в такие моменты выглядит так, будто специально проверяет, насколько далеко можно зайти"
    gg_chat "Même dans de tels moments, elle a l'air de tester spécifiquement jusqu'où elle peut aller."

# game/characters_events_idles/sonya_idles.rpy:15
translate french sonya_Idle_morning_bathroom_scene_43fc63bc:

    # Sonya "Хочешь полюбоваться видом?"
    Sonya "Veux-tu admirer la vue?"

# game/characters_events_idles/sonya_idles.rpy:17
translate french sonya_Idle_morning_bathroom_scene_274bd888:

    # Sonya "Я не против"
    Sonya "Cela ne me dérange pas"

# game/characters_events_idles/sonya_idles.rpy:18
translate french sonya_Idle_morning_bathroom_scene_e8a5a241:

    # gg "С таким предложением даже утренний кофе станет лишним"
    gg "Avec cette offre, même le café du matin deviendra inutile"

# game/characters_events_idles/sonya_idles.rpy:20
translate french sonya_Idle_morning_bathroom_scene_14ae5b75:

    # Sonya "Ну хоть кто-то ценит мой вклад в твое утро"
    Sonya "Eh bien, au moins quelqu'un apprécie ma contribution à votre matinée"

# game/characters_events_idles/sonya_idles.rpy:22
translate french sonya_Idle_morning_bathroom_scene_daf8e8db:

    # gg "Смотря, что ты предложишь взамен"
    gg "Cela dépend de ce que tu proposes en retour."

# game/characters_events_idles/sonya_idles.rpy:24
translate french sonya_Idle_morning_bathroom_scene_2ff9a6da:

    # Sonya "Знаешь, я бы тоже не отказалась провести утро поинтереснее"
    Sonya "Tu sais, cela ne me dérangerait pas non plus d’avoir une matinée plus intéressante."

# game/characters_events_idles/sonya_idles.rpy:26
translate french sonya_Idle_morning_bathroom_scene_e6700bf3:

    # Sonya "Особенно с тобой"
    Sonya "Surtout avec toi"

# game/characters_events_idles/sonya_idles.rpy:27
translate french sonya_Idle_morning_bathroom_scene_9a24ffbd:

    # gg "Звучит как приглашение"
    gg "On dirait une invitation"

# game/characters_events_idles/sonya_idles.rpy:29
translate french sonya_Idle_morning_bathroom_scene_818d5283:

    # Sonya "Да это оно. Но, увы, у меня дела"
    Sonya "Oui c'est ça. Mais hélas, j'ai des choses à faire"

# game/characters_events_idles/sonya_idles.rpy:30
translate french sonya_Idle_morning_bathroom_scene_82d60fb2:

    # gg "Ты знаешь это нечестно"
    gg "Tu sais que ce n'est pas juste"

# game/characters_events_idles/sonya_idles.rpy:32
translate french sonya_Idle_morning_bathroom_scene_0d7eca0c:

    # Sonya "Я просто оставляю десерт на потом"
    Sonya "je garde juste le dessert pour plus tard"

# game/characters_events_idles/sonya_idles.rpy:34
translate french sonya_Idle_morning_bathroom_scene_0d86f13a:

    # Sonya "Ну что ж, герой, ванная вся твоя"
    Sonya "Eh bien, héros, la salle de bain est à toi."

# game/characters_events_idles/sonya_idles.rpy:35
translate french sonya_Idle_morning_bathroom_scene_3e148853:

    # Sonya "Главное, когда будешь мыться не забудь, кто тебя вдохновил"
    Sonya "L’essentiel est que lorsque tu te laves, n’oublie pas qui t’a inspiré"

# game/characters_events_idles/sonya_idles.rpy:50
translate french sonya_Idle_evening_bathroom_scene_247f83e8:

    # gg "Не думал, что можно так красиво мыться под душем"
    gg "Je ne pensais pas qu'il était possible de prendre une douche aussi joliment"

# game/characters_events_idles/sonya_idles.rpy:51
translate french sonya_Idle_evening_bathroom_scene_361d1da4:

    # Sonya "Я знала, что ты заглянешь"
    Sonya "Je savais que tu passerais par ici"

# game/characters_events_idles/sonya_idles.rpy:52
translate french sonya_Idle_evening_bathroom_scene_dd689906:

    # Sonya "У тебя шаги узнаются ещё до двери"
    Sonya "Tes pas sont reconnus avant même la porte"

# game/characters_events_idles/sonya_idles.rpy:54
translate french sonya_Idle_evening_bathroom_scene_69f260a8:

    # gg "Хотел убедиться, что ты не уплыла в параллельную реальность"
    gg "Je voulais m'assurer que tu ne t'envoles pas dans une réalité parallèle."

# game/characters_events_idles/sonya_idles.rpy:55
translate french sonya_Idle_evening_bathroom_scene_81769a4a:

    # Sonya "Ещё нет. Хотя, если бы там было потеплее — можно было бы и остаться"
    Sonya "Pas encore. Mais s'il avait fait plus chaud là-bas, nous aurions pu rester"

# game/characters_events_idles/sonya_idles.rpy:57
translate french sonya_Idle_evening_bathroom_scene_1517ae3e:

    # Sonya "Знаешь, если бы я захотела — могла бы тебя соблазнить прямо сейчас"
    Sonya "Tu sais, si je le voulais, je pourrais te séduire maintenant"

# game/characters_events_idles/sonya_idles.rpy:58
translate french sonya_Idle_evening_bathroom_scene_1371ca10:

    # Sonya "Только чтобы забрать себе"
    Sonya "Juste pour le prendre pour toi"

# game/characters_events_idles/sonya_idles.rpy:60
translate french sonya_Idle_evening_bathroom_scene_21c8c83c:

    # Sonya "Но ты ведь тогда точно не ушёл бы, да?"
    Sonya "Mais tu ne serais certainement pas parti à ce moment-là, n’est-ce pas ?"

# game/characters_events_idles/sonya_idles.rpy:61
translate french sonya_Idle_evening_bathroom_scene_e75862b1:

    # gg "Вряд ли бы смог"
    gg "Je doute que je pourrais"

# game/characters_events_idles/sonya_idles.rpy:64
translate french sonya_Idle_evening_bathroom_scene_6b3e3f56:

    # Sonya "Вот именно, поэтому уходи"
    Sonya "C'est tout, alors va-t'en"

# game/characters_events_idles/sonya_idles.rpy:65
translate french sonya_Idle_evening_bathroom_scene_0c771583:

    # Sonya "Пока Мая не заглянула и не устроила мне лекцию на тему “личных границ”"
    Sonya "Jusqu'à ce que Maya vienne me donner une conférence sur le thème des « limites personnelles »."

# game/characters_events_idles/sonya_idles.rpy:67
translate french sonya_Idle_evening_bathroom_scene_7782c9fd:

    # gg "Значит, спасаю нас обоих"
    gg "Alors je nous sauve tous les deux"

# game/characters_events_idles/sonya_idles.rpy:68
translate french sonya_Idle_evening_bathroom_scene_61bc67e7:

    # Sonya "Спасай. Но не надолго"
    Sonya "Sauve-moi. Mais pas pour longtemps"

# game/characters_events_idles/sonya_idles.rpy:69
translate french sonya_Idle_evening_bathroom_scene_b8d4595f:

    # gg_chat "Её слова звучали полушуткой, но от этого не становилось легче"
    gg_chat "Ses mots ressemblaient à une demi-blague, mais cela ne rendait pas les choses plus faciles."

# game/characters_events_idles/sonya_idles.rpy:70
translate french sonya_Idle_evening_bathroom_scene_0892a9fc:

    # gg_chat "В каждой улыбке Сони теперь пряталось что-то большее, чем просто игра"
    gg_chat "Chaque sourire de Sonya contenait désormais quelque chose de plus qu'un simple jeu"

# game/characters_events_idles/sonya_idles.rpy:85
translate french sonya_Idle_morning_girlroom_scene_5a6cf65f:

    # gg "Доброе утро. Ты уже с рассветом на работе?"
    gg "Bonjour. Es-tu déjà au travail à l'aube ?"

# game/characters_events_idles/sonya_idles.rpy:87
translate french sonya_Idle_morning_girlroom_scene_782b60a4:

    # Sonya "Почти. У меня тут урожай созрел, не могу бросить"
    Sonya "Presque. Ma récolte est mûre ici, je ne peux pas arrêter"

# game/characters_events_idles/sonya_idles.rpy:88
translate french sonya_Idle_morning_girlroom_scene_a3c52931:

    # gg "А я думал, ты в такие игры не играешь"
    gg "Je pensais que tu ne jouais pas à de tels jeux"

# game/characters_events_idles/sonya_idles.rpy:90
translate french sonya_Idle_morning_girlroom_scene_bbda1d39:

    # Sonya "А зря, это лучшая медитация"
    Sonya "Mais en vain, c'est la meilleure méditation"

# game/characters_events_idles/sonya_idles.rpy:91
translate french sonya_Idle_morning_girlroom_scene_afc574c1:

    # Sonya "Никакой спешки, просто строишь, выращиваешь, приручаешь кошек"
    Sonya "Pas de précipitation, construisez, élevez et apprivoisez des chats"

# game/characters_events_idles/sonya_idles.rpy:93
translate french sonya_Idle_morning_girlroom_scene_2c50640e:

    # Sonya "Вот, видишь? Мой котик"
    Sonya "Ici, tu vois ? Mon chat"

# game/characters_events_idles/sonya_idles.rpy:94
translate french sonya_Idle_morning_girlroom_scene_4c464678:

    # Sonya "Зовут Барсик"
    Sonya "Le nom est Barsik."

# game/characters_events_idles/sonya_idles.rpy:95
translate french sonya_Idle_morning_girlroom_scene_cabe3537:

    # gg "Конечно. Даже тут он с тобой"
    gg "Certainement. Même ici, il est avec toi"

# game/characters_events_idles/sonya_idles.rpy:96
translate french sonya_Idle_morning_girlroom_scene_d4be7bb4:

    # Sonya "Да не совсем того цвета, хотя бы не ворует еду"
    Sonya "Oui, pas tout à fait la même couleur, au moins il ne vole pas de nourriture"

# game/characters_events_idles/sonya_idles.rpy:97
translate french sonya_Idle_morning_girlroom_scene_725c6cbd:

    # Sonya "И на клавиатуру не ложится"
    Sonya "Et ça ne rentre pas sur le clavier"

# game/characters_events_idles/sonya_idles.rpy:98
translate french sonya_Idle_morning_girlroom_scene_fbf5b42b:

    # Sonya "Я построила ему дом. Маленький, но уютный"
    Sonya "Je lui ai construit une maison. Petit mais confortable"

# game/characters_events_idles/sonya_idles.rpy:100
translate french sonya_Idle_morning_girlroom_scene_cfe34a6f:

    # gg "Как и в жизни"
    gg "Comme dans la vie"

# game/characters_events_idles/sonya_idles.rpy:101
translate french sonya_Idle_morning_girlroom_scene_de0ba10f:

    # Sonya "Возможно. Я люблю, когда всё на своих местах. Даже в пикселях"
    Sonya "Peut être. J'aime quand tout est à sa place. Même en pixels"

# game/characters_events_idles/sonya_idles.rpy:102
translate french sonya_Idle_morning_girlroom_scene_c16cc569:

    # gg "А с монстрами что делаешь?"
    gg "Que fais-tu des monstres ?"

# game/characters_events_idles/sonya_idles.rpy:104
translate french sonya_Idle_morning_girlroom_scene_c08d01fe:

    # Sonya "Ну избегаю. Я не про битвы, я про порядок"
    Sonya "Eh bien, je l'évite. Je ne parle pas de batailles, je parle d'ordre"

# game/characters_events_idles/sonya_idles.rpy:105
translate french sonya_Idle_morning_girlroom_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "J'aime quand tout est sous contrôle"

# game/characters_events_idles/sonya_idles.rpy:107
translate french sonya_Idle_morning_girlroom_scene_740206dd:

    # gg "Даже кот в игре слушается. Везёт тебе"
    gg "Même le chat écoute dans le jeu. Tu as de la chance"

# game/characters_events_idles/sonya_idles.rpy:108
translate french sonya_Idle_morning_girlroom_scene_fb402d59:

    # Sonya "А ты попробуй приручи кого-нибудь - узнаешь, что это целая наука"
    Sonya "Et si tu essayes d'apprivoiser quelqu'un, tu découvriras que c'est toute une science"

# game/characters_events_idles/sonya_idles.rpy:109
translate french sonya_Idle_morning_girlroom_scene_1b49be1f:

    # gg "Думаешь, справлюсь?"
    gg "Penses-tu que je peux le gérer ?"

# game/characters_events_idles/sonya_idles.rpy:111
translate french sonya_Idle_morning_girlroom_scene_228ee7fd:

    # Sonya "Сомневаюсь"
    Sonya "je doute"

# game/characters_events_idles/sonya_idles.rpy:112
translate french sonya_Idle_morning_girlroom_scene_e99c47d3:

    # Sonya "Ты не тот тип, кто строит. Скорее тот, кто случайно всё ломает"
    Sonya "Tu n'es pas du genre à construire. Plutôt celui qui casse tout accidentellement"

# game/characters_events_idles/sonya_idles.rpy:113
translate french sonya_Idle_morning_girlroom_scene_382eac3e:

    # gg "Эй, я в детстве играл. Даже базу под землёй сделал"
    gg "Hé, je jouais quand j'étais enfant. J'ai même fait une base sous terre"

# game/characters_events_idles/sonya_idles.rpy:115
translate french sonya_Idle_morning_girlroom_scene_0d62bf92:

    # Sonya "Ага, и подорвал через пять минут?"
    Sonya "Ouais, et tu l'as fait exploser cinq minutes plus tard ?"

# game/characters_events_idles/sonya_idles.rpy:116
translate french sonya_Idle_morning_girlroom_scene_81cf123c:

    # gg "Через десять. Но всё по плану"
    gg "Dans dix. Mais tout se passe comme prévu"

# game/characters_events_idles/sonya_idles.rpy:118
translate french sonya_Idle_morning_girlroom_scene_24c0b733:

    # Sonya "Тогда аккуратнее с моим миром"
    Sonya "Alors fais attention à mon monde"

# game/characters_events_idles/sonya_idles.rpy:119
translate french sonya_Idle_morning_girlroom_scene_3938ea91:

    # Sonya "Тут всё с любовью и без взрывчатки"
    Sonya "Ici, tout est fait avec amour et sans explosifs."

# game/characters_events_idles/sonya_idles.rpy:120
translate french sonya_Idle_morning_girlroom_scene_5664d0ac:

    # gg "Учту. Буду только наблюдать"
    gg "J'en tiendrai compte. je vais juste regarder"

# game/characters_events_idles/sonya_idles.rpy:121
translate french sonya_Idle_morning_girlroom_scene_af4f45a5:

    # Sonya "Если хочешь, потом покажу тебе свой сад"
    Sonya "Si tu veux, je te montrerai mon jardin plus tard."

# game/characters_events_idles/sonya_idles.rpy:122
translate french sonya_Idle_morning_girlroom_scene_91498926:

    # Sonya "Там столько цветов и пчелок"
    Sonya "Il y a tellement de fleurs et d'abeilles"

# game/characters_events_idles/sonya_idles.rpy:123
translate french sonya_Idle_morning_girlroom_scene_89b49bad:

    # gg "Звучит как место, где тебе действительно спокойно"
    gg "On dirait un endroit où l'on est vraiment en paix."

# game/characters_events_idles/sonya_idles.rpy:124
translate french sonya_Idle_morning_girlroom_scene_4a30e5b0:

    # Sonya "Наверное да, думаю нам стоит поиграть в будущем вместе!"
    Sonya "Probablement oui, je pense que nous devrions jouer ensemble à l'avenir !"

# game/characters_events_idles/sonya_idles.rpy:125
translate french sonya_Idle_morning_girlroom_scene_c8df07f1:

    # gg "Обязательно . . ."
    gg "Nécessairement. . ."

# game/characters_events_idles/sonya_idles.rpy:139
translate french sonya_Idle_day_girlroom_scene_a20a3fae:

    # gg "Привет как дела?"
    gg "Salut comment vas-tu?"

# game/characters_events_idles/sonya_idles.rpy:141
translate french sonya_Idle_day_girlroom_scene_9dc60813:

    # Sonya "Эти таблицы просто издеваются надо мной . . ."
    Sonya "Ces tableaux me rendent folle. . ."

# game/characters_events_idles/sonya_idles.rpy:142
translate french sonya_Idle_day_girlroom_scene_92df120a:

    # Sonya "Хоть бросай всё и иди пасти коров"
    Sonya "Ça me donne envie de tout laisser tomber et d’aller garder les vaches."

# game/characters_events_idles/sonya_idles.rpy:144
translate french sonya_Idle_day_girlroom_scene_e2f61865:

    # gg "Похоже, у тебя с ними война"
    gg "On dirait que tu es en guerre contre eux"

# game/characters_events_idles/sonya_idles.rpy:146
translate french sonya_Idle_day_girlroom_scene_053f0179:

    # Sonya "Война, да. И я проигрываю с первого дня"
    Sonya "La guerre, oui. Et je perds depuis le premier jour"

# game/characters_events_idles/sonya_idles.rpy:147
translate french sonya_Idle_day_girlroom_scene_d3cbfb79:

    # Sonya "Не знаю, почему все эти цифры так упрямо меня не слушаются"
    Sonya "Je ne sais pas pourquoi tous ces chiffres ne m'écoutent pas avec autant d'entêtement"

# game/characters_events_idles/sonya_idles.rpy:150
translate french sonya_Idle_day_girlroom_scene_8d39ea32:

    # Sonya "Знаешь, я ведь здесь выросла"
    Sonya "Tu sais, j'ai grandi ici"

# game/characters_events_idles/sonya_idles.rpy:151
translate french sonya_Idle_day_girlroom_scene_65c67f0f:

    # Sonya "Ну, не прямо в этом доме, но в этом посёлке"
    Sonya "Eh bien, pas dans cette maison, mais dans ce village"

# game/characters_events_idles/sonya_idles.rpy:152
translate french sonya_Idle_day_girlroom_scene_4c34bce3:

    # gg "Правда?"
    gg "Est-ce vrai ?"

# game/characters_events_idles/sonya_idles.rpy:154
translate french sonya_Idle_day_girlroom_scene_70dec560:

    # Sonya "Да. Тогда всё казалось больше - и улицы, и дома, и даже небо"
    Sonya "Oui. Alors tout semblait plus grand : les rues, les maisons et même le ciel."

# game/characters_events_idles/sonya_idles.rpy:155
translate french sonya_Idle_day_girlroom_scene_d0fea2c7:

    # Sonya "Потом я уехала, думала, найду место получше, что-то новое"
    Sonya "Puis je suis parti, je pensais trouver un meilleur endroit, quelque chose de nouveau"

# game/characters_events_idles/sonya_idles.rpy:157
translate french sonya_Idle_day_girlroom_scene_4acb46e4:

    # Sonya "А в итоге вернулась туда, где мне и было хорошо с самого начала"
    Sonya "Et à la fin je suis revenu là où je me sentais bien dès le début"

# game/characters_events_idles/sonya_idles.rpy:158
translate french sonya_Idle_day_girlroom_scene_e5c60ec3:

    # gg "А как ты познакомилась с Линдой?"
    gg "Comment as-tu rencontré Linda ?"

# game/characters_events_idles/sonya_idles.rpy:160
translate french sonya_Idle_day_girlroom_scene_b9747f5f:

    # Sonya "О, это было случайно"
    Sonya "Oh, c'était un accident"

# game/characters_events_idles/sonya_idles.rpy:161
translate french sonya_Idle_day_girlroom_scene_4203728c:

    # Sonya "Я тогда снимала комнату в соседнем доме, а она как-то увидела, что я таскаю тяжелые коробки и просто подошла помочь"
    Sonya "Je louais une chambre dans une maison voisine à l'époque, et elle m'a vu porter de lourds cartons et est venue m'aider."

# game/characters_events_idles/sonya_idles.rpy:163
translate french sonya_Idle_day_girlroom_scene_6c6eaa0a:

    # Sonya "С тех пор мы начали общаться"
    Sonya "Depuis, nous avons commencé à parler"

# game/characters_events_idles/sonya_idles.rpy:164
translate french sonya_Idle_day_girlroom_scene_a7d57230:

    # Sonya "Она часто звала меня на чай, а потом сказала, что у неё всё равно пустует комната - и я переехала"
    Sonya "Elle m'appelait souvent pour prendre le thé, puis elle me disait que sa chambre était vide de toute façon - alors j'ai déménagé"

# game/characters_events_idles/sonya_idles.rpy:166
translate french sonya_Idle_day_girlroom_scene_d72f25aa:

    # gg "То есть Линда тебя приютила?"
    gg "Alors Linda t'a accueilli ?"

# game/characters_events_idles/sonya_idles.rpy:168
translate french sonya_Idle_day_girlroom_scene_181e70fe:

    # Sonya "Можно и так сказать"
    Sonya "Tu peux dire ça"

# game/characters_events_idles/sonya_idles.rpy:169
translate french sonya_Idle_day_girlroom_scene_c5827422:

    # Sonya "Она никогда не делала из этого что-то большое, просто . . . {w}была рядом"
    Sonya "Elle n’en a jamais fait toute une histoire, juste… . . {w}était à proximité"

# game/characters_events_idles/sonya_idles.rpy:170
translate french sonya_Idle_day_girlroom_scene_967e2aa8:

    # Sonya "Знаешь, таких людей немного"
    Sonya "Tu sais, il y a peu de telles personnes"

# game/characters_events_idles/sonya_idles.rpy:172
translate french sonya_Idle_day_girlroom_scene_6ab10a33:

    # Sonya "А теперь вот я за ее столом"
    Sonya "Et maintenant me voici à sa table"

# game/characters_events_idles/sonya_idles.rpy:173
translate french sonya_Idle_day_girlroom_scene_75e4a1ee:

    # Sonya "Иногда кажется, что она всё ещё где-то рядом, наблюдает и тихо подсказывает, что делать"
    Sonya "Parfois, il semble qu'elle soit toujours quelque part à proximité, l'observant et lui disant tranquillement quoi faire."

# game/characters_events_idles/sonya_idles.rpy:174
translate french sonya_Idle_day_girlroom_scene_842a9d6c:

    # gg "Может, поэтому тебе так важно всё довести до идеала"
    gg "C'est peut-être pour ça qu'il est si important pour toi de tout amener à la perfection"

# game/characters_events_idles/sonya_idles.rpy:176
translate french sonya_Idle_day_girlroom_scene_e1ccf1c4:

    # Sonya "Возможно. Только вот с таблицами идеала точно не получится"
    Sonya "Peut-être. Mais avec ces tableaux, ce ne sera jamais parfait"

# game/characters_events_idles/sonya_idles.rpy:178
translate french sonya_Idle_day_girlroom_scene_cb6d8969:

    # Sonya "Спасибо, что подошёл"
    Sonya "Merci d'être venu"

# game/characters_events_idles/sonya_idles.rpy:179
translate french sonya_Idle_day_girlroom_scene_45ba29af:

    # Sonya "Без тебя я бы и дальше злилась на эти несчастные ячейки"
    Sonya "Sans toi, je serais encore en colère contre ces pauvres cases."

# game/characters_events_idles/sonya_idles.rpy:180
translate french sonya_Idle_day_girlroom_scene_c55fced7:

    # gg "Рад помочь"
    gg "Heureux de t'aider"

# game/characters_events_idles/sonya_idles.rpy:181
translate french sonya_Idle_day_girlroom_scene_c59d3a8e:

    # gg "Иногда лучший способ справиться с работой - просто отвлечься"
    gg "Parfois, la meilleure façon de terminer son travail est simplement de se distraire."

# game/characters_events_idles/sonya_idles.rpy:183
translate french sonya_Idle_day_girlroom_scene_dc01f949:

    # Sonya "Ты прав. А можешь мне чаек сделать пожалуйста . . ."
    Sonya "Tu as raison. Tu peux me préparer du thé s'il te plaît ? . ."

# game/characters_events_idles/sonya_idles.rpy:184
translate french sonya_Idle_day_girlroom_scene_307a264f:

    # gg "Да конечно"
    gg "Oui bien sûr"

# game/characters_events_idles/sonya_idles.rpy:186
translate french sonya_Idle_day_girlroom_scene_b0fc80b8:

    # Sonya "Спасибо огромное"
    Sonya "Merci beaucoup"

# game/characters_events_idles/sonya_idles.rpy:187
translate french sonya_Idle_day_girlroom_scene_11813a95:

    # gg_chat "В ней было что-то от Линды - то же спокойствие и мягкость, только моложе, живее"
    gg_chat "Il y avait quelque chose de Linda en elle - le même calme et la même douceur, mais plus jeune, plus vif."

# game/characters_events_idles/sonya_idles.rpy:188
translate french sonya_Idle_day_girlroom_scene_660cc2e9:

    # gg_chat "И, пожалуй, даже теплее"
    gg_chat "Et peut-être encore plus chaud"

# game/characters_events_idles/sonya_idles.rpy:203
translate french sonya_Idle_evening_girlroom_scene_42feeaf6:

    # gg "Можно присесть?"
    gg "Puis-je m'asseoir ?"

# game/characters_events_idles/sonya_idles.rpy:205
translate french sonya_Idle_evening_girlroom_scene_8460369c:

    # Sonya "Можно . . . {w}но с тебя - плата"
    Sonya "Tu peux . . . {w}mais tu dois payer"

# game/characters_events_idles/sonya_idles.rpy:206
translate french sonya_Idle_evening_girlroom_scene_a599bb6d:

    # gg "Какая?"
    gg "Comment ?"

# game/characters_events_idles/sonya_idles.rpy:208
translate french sonya_Idle_evening_girlroom_scene_81b816f5:

    # Sonya "Остаться до конца вечера"
    Sonya "Restes jusqu'à la fin de la soirée"

# game/characters_events_idles/sonya_idles.rpy:209
translate french sonya_Idle_evening_girlroom_scene_e27a7e82:

    # Sonya "И не сбежать"
    Sonya "Et ne t'enfuis pas"

# game/characters_events_idles/sonya_idles.rpy:210
translate french sonya_Idle_evening_girlroom_scene_7f2d6628:

    # gg "Если ты обещаешь не гнать - я и до утра не уйду"
    gg "Si tu promets de ne pas me chasser, je ne partirai que demain matin"

# game/characters_events_idles/sonya_idles.rpy:212
translate french sonya_Idle_evening_girlroom_scene_1cdd78f4:

    # Sonya "Тогда, может, и расскажу что-нибудь . . . {w}личное"
    Sonya "Alors peut-être que je vais te dire quelque chose. . . {w}de personnel"

# game/characters_events_idles/sonya_idles.rpy:215
translate french sonya_Idle_evening_girlroom_scene_9eb3b8ed:

    # Sonya "Забавно, получилось"
    Sonya "C'est drôle, ça a marché"

# game/characters_events_idles/sonya_idles.rpy:216
translate french sonya_Idle_evening_girlroom_scene_8bb9cddd:

    # Sonya "Мы с Маей обе любим тишину, но по-разному"
    Sonya "Maya et moi aimons toutes les deux le silence, mais de différentes manières."

# game/characters_events_idles/sonya_idles.rpy:217
translate french sonya_Idle_evening_girlroom_scene_fb1f6848:

    # gg "В каком смысле?"
    gg "Dans quel sens ?"

# game/characters_events_idles/sonya_idles.rpy:219
translate french sonya_Idle_evening_girlroom_scene_a5d3ae91:

    # Sonya "Она включает музыку, чтобы заглушить всё вокруг"
    Sonya "Elle met de la musique pour noyer tout ce qui l'entoure"

# game/characters_events_idles/sonya_idles.rpy:220
translate french sonya_Idle_evening_girlroom_scene_b0cd0795:

    # Sonya "А я наоборот - выключаю, чтобы услышать хоть что-то своё"
    Sonya "Au contraire, je l'éteins pour entendre au moins quelque chose de moi-même."

# game/characters_events_idles/sonya_idles.rpy:221
translate french sonya_Idle_evening_girlroom_scene_7162f44d:

    # gg "Тогда у тебя получается лучше"
    gg "Alors tu peux faire mieux"

# game/characters_events_idles/sonya_idles.rpy:223
translate french sonya_Idle_evening_girlroom_scene_b5b15ec8:

    # Sonya "Ну не знаю"
    Sonya "Eh bien, je ne sais pas"

# game/characters_events_idles/sonya_idles.rpy:224
translate french sonya_Idle_evening_girlroom_scene_03522836:

    # Sonya "Просто по-другому"
    Sonya "Juste différemment"

# game/characters_events_idles/sonya_idles.rpy:238
translate french sonya_Idle_night_girlroom_scene_559d1944:

    # gg "Улыбается во сне . . ."
    gg "Elle sourit dans son sommeil. . ."

# game/characters_events_idles/sonya_idles.rpy:239
translate french sonya_Idle_night_girlroom_scene_5651af4c:

    # gg "Интересно, что ей снится, раз выглядит такой довольной"
    gg "Je me demande à quoi elle rêve puisqu'elle a l'air si heureuse"

# game/characters_events_idles/sonya_idles.rpy:251
translate french sonya_Idle_morning_kitchen_scene_0b8a14be:

    # gg "Доброе утро, командир чистоты"
    gg "Bonjour, commandant de la pureté"

# game/characters_events_idles/sonya_idles.rpy:252
translate french sonya_Idle_morning_kitchen_scene_ed136649:

    # Sonya "Кто-то же должен следить, чтобы кухня не превратилась в поле боя"
    Sonya "Quelqu'un doit s'assurer que la cuisine ne se transforme pas en champ de bataille."

# game/characters_events_idles/sonya_idles.rpy:254
translate french sonya_Idle_morning_kitchen_scene_d094394a:

    # gg "А вдруг Мая проснётся и решит помочь?"
    gg "Et si Maya se réveillait et décidait d'aider ?"

# game/characters_events_idles/sonya_idles.rpy:256
translate french sonya_Idle_morning_kitchen_scene_c681883f:

    # Sonya "Тогда я просто вымою всё заново"
    Sonya "Ensuite, je vais tout laver à nouveau"

# game/characters_events_idles/sonya_idles.rpy:258
translate french sonya_Idle_morning_kitchen_scene_f2c9c474:

    # gg "Значит, тебе нравится, когда всё блестит"
    gg "Alors tu aimes quand tout brille"

# game/characters_events_idles/sonya_idles.rpy:260
translate french sonya_Idle_morning_kitchen_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "J'aime quand tout est sous contrôle"

# game/characters_events_idles/sonya_idles.rpy:261
translate french sonya_Idle_morning_kitchen_scene_86bbbfde:

    # gg "Даже люди?"
    gg "Même les gens ?"

# game/characters_events_idles/sonya_idles.rpy:264
translate french sonya_Idle_morning_kitchen_scene_655f980e:

    # Sonya "С людьми сложнее"
    Sonya "C'est plus difficile avec les gens"

# game/characters_events_idles/sonya_idles.rpy:265
translate french sonya_Idle_morning_kitchen_scene_6ae7acf8:

    # Sonya "Они, в отличие от кухни, редко слушаются"
    Sonya "Contrairement à la cuisine, ils obéissent rarement"

# game/characters_events_idles/sonya_idles.rpy:266
translate french sonya_Idle_morning_kitchen_scene_efabb06d:

    # gg "Может, им просто не хватает твоего руководства"
    gg "Peut-être qu'ils ont juste besoin de tes conseils."

# game/characters_events_idles/sonya_idles.rpy:268
translate french sonya_Idle_morning_kitchen_scene_59bb1b63:

    # Sonya "Осторожнее с комплиментами, а то решу, что ты тоже хочешь быть чистеньким"
    Sonya "Fais attention aux compliments, sinon je déciderai que tu veux aussi être propre"

# game/characters_events_idles/sonya_idles.rpy:269
translate french sonya_Idle_morning_kitchen_scene_19086387:

    # gg "Обещаю быть примерным"
    gg "Je promets d'être exemplaire"

# game/characters_events_idles/sonya_idles.rpy:270
translate french sonya_Idle_morning_kitchen_scene_de5751f7:

    # gg "Хотя недолго"
    gg "Même si ce n'est pas pour longtemps"

# game/characters_events_idles/sonya_idles.rpy:285
translate french sonya_Idle_evening_kitchen_scene_74d26ab6:

    # gg "Пахнет так, будто кто-то очень старается"
    gg "On dirait que quelqu'un fait de gros efforts"

# game/characters_events_idles/sonya_idles.rpy:287
translate french sonya_Idle_evening_kitchen_scene_38676ac8:

    # Sonya "А я и стараюсь"
    Sonya "Et j'essaye"

# game/characters_events_idles/sonya_idles.rpy:288
translate french sonya_Idle_evening_kitchen_scene_adfdb6f3:

    # Sonya "Без рецепта между прочем, просто . . . {w}хочется, чтобы получилось как дома"
    Sonya "Sans ordonnance, d'ailleurs, juste... . . {w}Je veux que ça ressemble à chez moi"

# game/characters_events_idles/sonya_idles.rpy:289
translate french sonya_Idle_evening_kitchen_scene_c3970015:

    # gg "Ты часто так готовишь?"
    gg "Cuisines-tu souvent comme ça ?"

# game/characters_events_idles/sonya_idles.rpy:291
translate french sonya_Idle_evening_kitchen_scene_2d72af39:

    # Sonya "Почти каждый день. С детства так привыкла"
    Sonya "Presque tous les jours. J'y suis habitué depuis l'enfance"

# game/characters_events_idles/sonya_idles.rpy:292
translate french sonya_Idle_evening_kitchen_scene_1cbd5882:

    # Sonya "Мне нравилось видеть, как люди садятся за стол и вдруг становятся добрее"
    Sonya "J'ai adoré voir les gens s'asseoir et devenir soudainement plus gentils."

# game/characters_events_idles/sonya_idles.rpy:294
translate french sonya_Idle_evening_kitchen_scene_33b06e3d:

    # Sonya "Еда делает людей мягче"
    Sonya "La nourriture rend les gens plus doux"

# game/characters_events_idles/sonya_idles.rpy:295
translate french sonya_Idle_evening_kitchen_scene_4347abfd:

    # Sonya "Даже тех, кто обычно каменные"
    Sonya "Même ceux qui sont habituellement en pierre"

# game/characters_events_idles/sonya_idles.rpy:297
translate french sonya_Idle_evening_kitchen_scene_3116970e:

    # gg "Может, потому что через неё ты делишься теплом"
    gg "Peut-être parce qu'à travers cela tu partages de la chaleur"

# game/characters_events_idles/sonya_idles.rpy:298
translate french sonya_Idle_evening_kitchen_scene_158f9e29:

    # Sonya "Наверное"
    Sonya "Peut être"

# game/characters_events_idles/sonya_idles.rpy:299
translate french sonya_Idle_evening_kitchen_scene_2af7df75:

    # Sonya "Готовить - это ведь не просто накормить"
    Sonya "Cuisiner ne consiste pas seulement à nourrir"

# game/characters_events_idles/sonya_idles.rpy:300
translate french sonya_Idle_evening_kitchen_scene_668b4e51:

    # Sonya "Это сказать: “ты можешь остаться”"
    Sonya "C’est à dire : « tu peux rester »"

# game/characters_events_idles/sonya_idles.rpy:302
translate french sonya_Idle_evening_kitchen_scene_8f974346:

    # Sonya "Помню, в детстве всё время помогала на кухне"
    Sonya "Je me souviens que quand j'étais enfant, j'aidais tout le temps à la cuisine."

# game/characters_events_idles/sonya_idles.rpy:303
translate french sonya_Idle_evening_kitchen_scene_970899ee:

    # Sonya "Мама только улыбалась - говорила, что из меня выйдет не повар, а “дом в человеческом виде”"
    Sonya "Maman a juste souri et a dit que je ne deviendrais pas cuisinière, mais « une maison sous forme humaine »"

# game/characters_events_idles/sonya_idles.rpy:305
translate french sonya_Idle_evening_kitchen_scene_22f1390f:

    # gg "Звучит будто про тебя"
    gg "On dirait que c'est à propos de toi"

# game/characters_events_idles/sonya_idles.rpy:307
translate french sonya_Idle_evening_kitchen_scene_36c5520f:

    # Sonya "Ну вот, ужин готов"
    Sonya "Eh bien, le dîner est prêt"

# game/characters_events_idles/sonya_idles.rpy:308
translate french sonya_Idle_evening_kitchen_scene_03998218:

    # Sonya "Без изысков, но с душой"
    Sonya "Sans fioritures, mais avec une âme"

# game/characters_events_idles/sonya_idles.rpy:310
translate french sonya_Idle_evening_kitchen_scene_44b18404:

    # gg "Это вкуснее, чем изысканно"
    gg "C'est plus savoureux que fantaisie"

# game/characters_events_idles/sonya_idles.rpy:311
translate french sonya_Idle_evening_kitchen_scene_16a4231c:

    # Sonya "Вот и хорошо"
    Sonya "C'est bien"

# game/characters_events_idles/sonya_idles.rpy:312
translate french sonya_Idle_evening_kitchen_scene_2c2fc2a4:

    # Sonya "Значит, не зря старалась"
    Sonya "Ce n'est donc pas en vain que j'ai essayé"

# game/characters_events_idles/sonya_idles.rpy:314
translate french sonya_Idle_evening_kitchen_scene_c6bde83f:

    # Sonya "Знаешь, мне нравится кормить людей"
    Sonya "Tu sais, j'aime nourrir les gens"

# game/characters_events_idles/sonya_idles.rpy:315
translate french sonya_Idle_evening_kitchen_scene_d763faf1:

    # Sonya "Это самое простое, но честное, что я умею делать"
    Sonya "C’est la chose la plus simple mais la plus honnête que je sache faire."

# game/characters_events_idles/sonya_idles.rpy:317
translate french sonya_Idle_evening_kitchen_scene_2b0e2ee7:

    # Sonya "Когда кто - то ест то, что ты приготовил, - он словно доверяет тебе"
    Sonya "Quand quelqu'un mange ce que tu as préparé, c'est comme s'il te faisait confiance"

# game/characters_events_idles/sonya_idles.rpy:332
translate french sonya_Idle_day_kitchen_scene_ad913161:

    # gg "Всё ещё ждёшь, пока чайник закипит?"
    gg "Tu attends toujours que la bouilloire bout ?"

# game/characters_events_idles/sonya_idles.rpy:334
translate french sonya_Idle_day_kitchen_scene_7f0755b3:

    # Sonya "Этот чайник кипит только если чувствует внимание. И настроение"
    Sonya "Cette bouilloire ne bout que si elle détecte de l'attention. Et l'ambiance"

# game/characters_events_idles/sonya_idles.rpy:336
translate french sonya_Idle_day_kitchen_scene_f15d06fa:

    # gg "У него характер как у людей здесь"
    gg "Il a un caractère comme les gens d'ici"

# game/characters_events_idles/sonya_idles.rpy:337
translate french sonya_Idle_day_kitchen_scene_da15dc83:

    # Sonya "Точно. Кстати чтобы узнать получше людей здесь"
    Sonya "Exactement. Au fait, pour mieux connaître les gens ici"

# game/characters_events_idles/sonya_idles.rpy:340
translate french sonya_Idle_day_kitchen_scene_d5290e36:

    # Sonya "Тут есть пара мест для прогулок"
    Sonya "Il y a quelques endroits où marcher"

# game/characters_events_idles/sonya_idles.rpy:341
translate french sonya_Idle_day_kitchen_scene_9f4c3048:

    # Sonya "Парк — небольшой, но с лавками, где можно застрять на час"
    Sonya "Le parc est petit, mais avec des bancs où l'on peut rester coincé pendant une heure"

# game/characters_events_idles/sonya_idles.rpy:343
translate french sonya_Idle_day_kitchen_scene_5b433dab:

    # gg "И всё?"
    gg "C'est tout ?"

# game/characters_events_idles/sonya_idles.rpy:345
translate french sonya_Idle_day_kitchen_scene_35184686:

    # Sonya "Ещё озеро. Маленькое, но красивое, особенно вечером"
    Sonya "Un autre lac. Petit mais beau, surtout le soir"

# game/characters_events_idles/sonya_idles.rpy:346
translate french sonya_Idle_day_kitchen_scene_f7d54fda:

    # Sonya "Только вода бодрит так, что потом спать не хочется"
    Sonya "Seule l’eau vous revigore tellement que vous n’avez plus envie de dormir après"

# game/characters_events_idles/sonya_idles.rpy:348
translate french sonya_Idle_day_kitchen_scene_95b73bc9:

    # Sonya "По субботам базар. Там продают всё — от мёда до слухов"
    Sonya "Marché le samedi. Ils y vendent de tout - du miel aux rumeurs"

# game/characters_events_idles/sonya_idles.rpy:349
translate french sonya_Idle_day_kitchen_scene_957c11d8:

    # gg "А многоэтажка — это правда?"
    gg "Le gratte-ciel est-il vrai ?"

# game/characters_events_idles/sonya_idles.rpy:351
translate french sonya_Idle_day_kitchen_scene_13cd2649:

    # Sonya "Правда. Наш “город в одном доме”"
    Sonya "Est-ce vrai. Notre « ville dans une maison »"

# game/characters_events_idles/sonya_idles.rpy:352
translate french sonya_Idle_day_kitchen_scene_c3a65cd2:

    # Sonya "Там почта, офис и девушка, которая считает себя айтишником"
    Sonya "Il y a un bureau de poste, un bureau et une fille qui se considère comme une informaticienne."

# game/characters_events_idles/sonya_idles.rpy:354
translate french sonya_Idle_day_kitchen_scene_ed9dc13a:

    # Sonya "Вот и всё веселье. Но если смотреть внимательно — здесь больше жизни, чем кажется"
    Sonya "C'est tout le plaisir. Mais si tu regardes attentivement, il y a plus de vie ici qu'il n'y paraît"

# game/characters_events_idles/sonya_idles.rpy:369
translate french sonya_Idle_morning_myroom_scene_3520e1f4:

    # Sonya "Ой . . . не разбудила?"
    Sonya "Oh . . . je t'ai réveillé ?"

# game/characters_events_idles/sonya_idles.rpy:370
translate french sonya_Idle_morning_myroom_scene_672ee57f:

    # gg "Нет, просто не привык, что по утрам кто-то сражается с пылью"
    gg "Non, je ne suis tout simplement pas habitué à ce que quelqu'un combatte la poussière le matin"

# game/characters_events_idles/sonya_idles.rpy:372
translate french sonya_Idle_morning_myroom_scene_7bcfcbe4:

    # Sonya "У каждого своё утро"
    Sonya "Chacun a sa matinée"

# game/characters_events_idles/sonya_idles.rpy:373
translate french sonya_Idle_morning_myroom_scene_125e44ff:

    # Sonya "Моё - с уборки"
    Sonya "Le mien vient du nettoyage"

# game/characters_events_idles/sonya_idles.rpy:375
translate french sonya_Idle_morning_myroom_scene_00768c69:

    # gg "Не думал, что ты одна из тех, кто так любит уборку"
    gg "Je ne pensais pas que tu faisais partie de ces personnes qui aiment autant nettoyer."

# game/characters_events_idles/sonya_idles.rpy:377
translate french sonya_Idle_morning_myroom_scene_05d695dc:

    # Sonya "Не люблю. {w}Просто, если не я, никто не сделает"
    Sonya "Je n'aime pas ça. {w}C'est juste que si je ne le fais pas, personne ne le fera"

# game/characters_events_idles/sonya_idles.rpy:378
translate french sonya_Idle_morning_myroom_scene_8b5d8733:

    # Sonya "Когда я сюда приехала, дом был знаешь . . . {w}какой-то пустой"
    Sonya "Quand je suis arrivé ici, la maison était, tu sais. . . {w}un peu vide"

# game/characters_events_idles/sonya_idles.rpy:379
translate french sonya_Idle_morning_myroom_scene_6e4588f3:

    # Sonya "Линда тогда часто уезжала, а Мая только въехала"
    Sonya "Linda partait souvent à cette époque et Maya venait d'emménager."

# game/characters_events_idles/sonya_idles.rpy:380
translate french sonya_Idle_morning_myroom_scene_b07f6cab:

    # Sonya "Всё было вверх дном"
    Sonya "Tout était à l'envers"

# game/characters_events_idles/sonya_idles.rpy:381
translate french sonya_Idle_morning_myroom_scene_c3dd8e50:

    # Sonya "Я осталась - просто чтобы стало немного тише"
    Sonya "Je suis resté - juste pour que ce soit un peu plus calme"

# game/characters_events_idles/sonya_idles.rpy:382
translate french sonya_Idle_morning_myroom_scene_58c3d544:

    # gg "И осталась до сих пор?"
    gg "Et est-ce toujours là ?"

# game/characters_events_idles/sonya_idles.rpy:384
translate french sonya_Idle_morning_myroom_scene_1e7a7a2e:

    # Sonya "Ага. Потом привыкла"
    Sonya "Ouais. Puis je m'y suis habitué"

# game/characters_events_idles/sonya_idles.rpy:385
translate french sonya_Idle_morning_myroom_scene_ce824a84:

    # Sonya "Линда как-то сказала, что дом любит, когда в нём кто-то есть"
    Sonya "Linda a dit un jour qu'une maison aime quand il y a quelqu'un dedans"

# game/characters_events_idles/sonya_idles.rpy:387
translate french sonya_Idle_morning_myroom_scene_80a846d0:

    # Sonya "Может, я просто не смогла уехать"
    Sonya "Peut-être que je ne pouvais tout simplement pas partir"

# game/characters_events_idles/sonya_idles.rpy:389
translate french sonya_Idle_morning_myroom_scene_db2e4457:

    # gg "А Мая? Вы ведь такие разные"
    gg "Et Maya ? Tu es si différene"

# game/characters_events_idles/sonya_idles.rpy:391
translate french sonya_Idle_morning_myroom_scene_55479aec:

    # Sonya "Очень"
    Sonya "Très"

# game/characters_events_idles/sonya_idles.rpy:393
translate french sonya_Idle_morning_myroom_scene_e017f5bc:

    # Sonya "Я - про порядок, она - про хаос. Но в этом и суть"
    Sonya "Je parle d'ordre, elle parle de chaos. Mais c'est le point"

# game/characters_events_idles/sonya_idles.rpy:396
translate french sonya_Idle_morning_myroom_scene_ef1d94c6:

    # Sonya "Знаешь, иногда кажется, что мы друг друга уравновешиваем"
    Sonya "Tu sais, parfois on a l'impression que nous nous équilibrons"

# game/characters_events_idles/sonya_idles.rpy:397
translate french sonya_Idle_morning_myroom_scene_77666d07:

    # Sonya "Я заставляю её остановиться, а она - меня жить чуть громче"
    Sonya "Je la fais arrêter, et elle me fait vivre un peu plus fort"

# game/characters_events_idles/sonya_idles.rpy:398
translate french sonya_Idle_morning_myroom_scene_686dcb6d:

    # gg "Похоже, вы нашли баланс"
    gg "On dirait que tu as trouvé un équilibre"

# game/characters_events_idles/sonya_idles.rpy:400
translate french sonya_Idle_morning_myroom_scene_8d1d6292:

    # Sonya "Баланс - вещь хрупкая"
    Sonya "L'équilibre est une chose fragile"

# game/characters_events_idles/sonya_idles.rpy:402
translate french sonya_Idle_morning_myroom_scene_6e252d73:

    # Sonya "Но, кажется, с тобой он только крепче стал"
    Sonya "Mais il semble qu'avec toi, il est devenu plus fort"

# game/characters_events_idles/sonya_idles.rpy:404
translate french sonya_Idle_morning_myroom_scene_2e6e7590:

    # Sonya "В смысле . . . просто в доме стало уютнее"
    Sonya "En termes de . . . la maison est devenue plus confortable"

# game/characters_events_idles/sonya_idles.rpy:406
translate french sonya_Idle_morning_myroom_scene_6bf72907:

    # Sonya "Вот и всё"
    Sonya "C'est ça"

# game/characters_events_idles/sonya_idles.rpy:407
translate french sonya_Idle_morning_myroom_scene_98ba9030:

    # gg "Конечно. Только уют"
    gg "Certainement. Seulement du confort"

# game/characters_events_idles/sonya_idles.rpy:408
translate french sonya_Idle_morning_myroom_scene_af3920fa:

    # Sonya "Вот именно. Только уют"
    Sonya "C'est ça. Seulement du confort"

# game/characters_events_idles/sonya_idles.rpy:422
translate french sonya_Idle_day_myroom_scene_de06330f:

    # gg "Привет за цветами ухаживаешь?"
    gg "Bonjour, est-ce que tu t'occupes des fleurs ?"

# game/characters_events_idles/sonya_idles.rpy:424
translate french sonya_Idle_day_myroom_scene_c76f7e91:

    # Sonya "Знаешь, за цветами нужно постоянно следить"
    Sonya "Tu sais, tu dois constamment surveiller les fleurs"

# game/characters_events_idles/sonya_idles.rpy:426
translate french sonya_Idle_day_myroom_scene_95b1f24a:

    # Sonya "Не слишком много воды, не слишком мало. . . иначе начинают вянуть"
    Sonya "Ni trop d’eau, ni trop peu. . . sinon ils commencent à dépérir"

# game/characters_events_idles/sonya_idles.rpy:427
translate french sonya_Idle_day_myroom_scene_ae18780a:

    # gg "Значит, всё дело в балансе"
    gg "C'est donc une question d'équilibre."

# game/characters_events_idles/sonya_idles.rpy:429
translate french sonya_Idle_day_myroom_scene_0e80b509:

    # Sonya "Внимание и время - вот что им действительно нужно"
    Sonya "L'attention et le temps sont ce dont ils ont vraiment besoin"

# game/characters_events_idles/sonya_idles.rpy:430
translate french sonya_Idle_day_myroom_scene_37400bc6:

    # Sonya "Не полил день - и всё, сразу обижаются"
    Sonya "Je n'ai pas arrosé pendant un jour - et c'est tout, ils s'offusquent immédiatement"

# game/characters_events_idles/sonya_idles.rpy:432
translate french sonya_Idle_day_myroom_scene_b6abea2a:

    # Sonya "У каждого из них свой характер"
    Sonya "Chacun d'eux a son propre caractère"

# game/characters_events_idles/sonya_idles.rpy:434
translate french sonya_Idle_day_myroom_scene_2c042e81:

    # Sonya "Один тянется к свету, другой прячется в тень"
    Sonya "L'un cherche la lumière, l'autre se cache dans l'ombre"

# game/characters_events_idles/sonya_idles.rpy:435
translate french sonya_Idle_day_myroom_scene_bffbba77:

    # Sonya "Есть те, кто растёт быстро, а есть, кому нужно просто больше терпения"
    Sonya "Il y a ceux qui grandissent vite, et il y a ceux qui ont juste besoin de plus de patience."

# game/characters_events_idles/sonya_idles.rpy:436
translate french sonya_Idle_day_myroom_scene_97f84296:

    # gg "Звучит как целая наука"
    gg "Cela ressemble à toute une science"

# game/characters_events_idles/sonya_idles.rpy:438
translate french sonya_Idle_day_myroom_scene_bc327c51:

    # Sonya "Может, и так. Только всё приходится чувствовать"
    Sonya "Peut-être. Tu dois juste tout ressentir"

# game/characters_events_idles/sonya_idles.rpy:440
translate french sonya_Idle_day_myroom_scene_16d43fdb:

    # Sonya "Иногда они долго не цветут, и кажется, что всё зря"
    Sonya "Parfois, ils ne fleurissent pas longtemps et il semble que tout soit en vain"

# game/characters_events_idles/sonya_idles.rpy:441
translate french sonya_Idle_day_myroom_scene_df3dcafe:

    # Sonya "А потом вдруг - один день, и раскрывается бутон"
    Sonya "Et puis soudain - un jour, et un bourgeon s'ouvre"

# game/characters_events_idles/sonya_idles.rpy:443
translate french sonya_Idle_day_myroom_scene_3ee4994e:

    # Sonya "Линда всегда говорила, что цветы живут там, где им хорошо"
    Sonya "Linda a toujours dit que les fleurs vivent là où elles se sentent bien"

# game/characters_events_idles/sonya_idles.rpy:444
translate french sonya_Idle_day_myroom_scene_bfd85b59:

    # Sonya "Не потому что солнце ярче, а потому что рядом кто-то заботится"
    Sonya "Non pas parce que le soleil est plus brillant, mais parce que quelqu'un à proximité s'en soucie"

# game/characters_events_idles/sonya_idles.rpy:445
translate french sonya_Idle_day_myroom_scene_d2c9efc2:

    # gg "Наверное, это правда"
    gg "C'est probablement vrai"

# game/characters_events_idles/sonya_idles.rpy:447
translate french sonya_Idle_day_myroom_scene_21a29e18:

    # Sonya "Думаю, да"
    Sonya "je pense que oui"

# game/characters_events_idles/sonya_idles.rpy:448
translate french sonya_Idle_day_myroom_scene_ea189aa5:

    # Sonya "Просто не все замечают, как это важно"
    Sonya "C'est juste que tout le monde ne réalise pas à quel point c'est important"

# game/characters_events_idles/sonya_idles.rpy:449
translate french sonya_Idle_day_myroom_scene_98f80f6a:

    # Sonya "Иногда достаточно совсем немного - тепла, слова, присутствия"
    Sonya "Parfois, un peu suffit - chaleur, mots, présence"

# game/characters_events_idles/sonya_idles.rpy:451
translate french sonya_Idle_day_myroom_scene_c2d87ad5:

    # Sonya "Главное - не перекормить заботой"
    Sonya "L'essentiel est de ne pas suralimenter avec précaution"

# game/characters_events_idles/sonya_idles.rpy:466
translate french sonya_Idle_evening_myroom_scene_21cb43a6:

    # Sonya "Так, у нас есть романтика, комедия, и . . . хоррор"
    Sonya "Nous avons donc de la romance, de la comédie, etc. . horreur"

# game/characters_events_idles/sonya_idles.rpy:468
translate french sonya_Idle_evening_myroom_scene_fd380690:

    # gg "Хоррор? Ты же потом не заснёшь"
    gg "Horreur? Tu ne t'endormiras pas plus tard"

# game/characters_events_idles/sonya_idles.rpy:470
translate french sonya_Idle_evening_myroom_scene_f65cd8c3:

    # Sonya "Ну тогда разбужу тебя и будем болтать до утра . . ."
    Sonya "Eh bien, je vais te réveiller et nous discuterons jusqu'au matin. . ."

# game/characters_events_idles/sonya_idles.rpy:471
translate french sonya_Idle_evening_myroom_scene_0f687ebc:

    # Sonya "Вместе страдать от бессонницы"
    Sonya "Souffrir d'insomnie ensemble"

# game/characters_events_idles/sonya_idles.rpy:472
translate french sonya_Idle_evening_myroom_scene_4fc2999c:

    # gg "Ну если ты вдруг случайно начнёшь засыпать - я тебе не дам"
    gg "Eh bien, si tu commences soudainement à t'endormir par accident, je ne te laisserai pas"

# game/characters_events_idles/sonya_idles.rpy:474
translate french sonya_Idle_evening_myroom_scene_d472f3eb:

    # Sonya "Просто люблю, когда немного страшно"
    Sonya "J'adore quand c'est un peu effrayant"

# game/characters_events_idles/sonya_idles.rpy:475
translate french sonya_Idle_evening_myroom_scene_53e63a45:

    # Sonya "В таких фильмах хоть что-то происходит по-настоящему"
    Sonya "Au moins quelque chose se passe réellement dans ces films."

# game/characters_events_idles/sonya_idles.rpy:477
translate french sonya_Idle_evening_myroom_scene_80cdfb7b:

    # gg "А ты не боишься?"
    gg "Tu n'as pas peur ?"

# game/characters_events_idles/sonya_idles.rpy:479
translate french sonya_Idle_evening_myroom_scene_562977d2:

    # Sonya "Боюсь. {w}Но мне нравится, когда страшно только снаружи, а внутри спокойно"
    Sonya "Effrayé. {w}Mais j'aime quand c'est seulement effrayant à l'extérieur, mais calme à l'intérieur"

# game/characters_events_idles/sonya_idles.rpy:481
translate french sonya_Idle_evening_myroom_scene_ca77da12:

    # Sonya "Хотя, если вдруг будет слишком жутко - я, может, чуть-чуть прижмусь. Для науки"
    Sonya "Mais si tout d’un coup ça devient trop effrayant, je vais peut-être me blottir un peu. Pour la science"

# game/characters_events_idles/sonya_idles.rpy:482
translate french sonya_Idle_evening_myroom_scene_c7a5bb2e:

    # gg "Чисто научный эксперимент?"
    gg "Expérience purement scientifique ?"

# game/characters_events_idles/sonya_idles.rpy:483
translate french sonya_Idle_evening_myroom_scene_96d1eac0:

    # Sonya "Конечно. Проверим, снижается ли уровень паники при тесном контакте"
    Sonya "Certainement. Vérifions si le niveau de panique diminue avec un contact étroit"

# game/characters_events_idles/sonya_idles.rpy:487
translate french sonya_Idle_evening_myroom_scene_0a9cd91f:

    # Sonya "Вот видишь, уже началось"
    Sonya "Tu vois, ça a déjà commencé"

# game/characters_events_idles/sonya_idles.rpy:488
translate french sonya_Idle_evening_myroom_scene_4b16a16b:

    # gg "И как результаты эксперимента?"
    gg "Et quels sont les résultats de l’expérience ?"

# game/characters_events_idles/sonya_idles.rpy:490
translate french sonya_Idle_evening_myroom_scene_1d60fbd7:

    # Sonya "Пока эффект положительный"
    Sonya "Pour l'instant l'effet est positif"

# game/characters_events_idles/sonya_idles.rpy:491
translate french sonya_Idle_evening_myroom_scene_c404867c:

    # Sonya "Но для точности нужно дождаться кульминации"
    Sonya "Mais pour être précis, il faut attendre le point culminant"

# game/characters_events_idles/sonya_idles.rpy:492
translate french sonya_Idle_evening_myroom_scene_24bf4b87:

    # Sonya "В такие вечера даже страх кажется уютным"
    Sonya "Des soirées comme celles-ci, même la peur semble confortable"

# game/characters_events_idles/sonya_idles.rpy:493
translate french sonya_Idle_evening_myroom_scene_741f04d1:

    # gg "Только если есть кому его разделить"
    gg "Seulement s'il y a quelqu'un avec qui le partager"

# game/characters_events_idles/sonya_idles.rpy:494
translate french sonya_Idle_evening_myroom_scene_cf08afaa:

    # Sonya "Думаю, у нас с этим всё в порядке"
    Sonya "Je pense que nous sommes d'accord avec ça"

translate french strings:

    # game/characters_events_idles/sonya_idles.rpy:5
    old "Доброе утро"
    new "Bonjour"

    # game/characters_events_idles/sonya_idles.rpy:48
    old "Потрясающе выглядишь"
    new "Tu es très belle"

    # game/characters_events_idles/sonya_idles.rpy:74
    old "Мне пора"
    new "Je dois y aller"

    # game/characters_events_idles/sonya_idles.rpy:138
    old "Привет"
    new "Bonjour"

    # game/characters_events_idles/sonya_idles.rpy:192
    old "Не мешать"
    new "Ne te mêle pas"

    # game/characters_events_idles/sonya_idles.rpy:201
    old "Присесть рядом"
    new "Assieds-toi à côté de moi"

    # game/characters_events_idles/sonya_idles.rpy:237
    old "Не тревожить"
    new "Ne pas déranger"

    # game/characters_events_idles/sonya_idles.rpy:249
    old "С добрым утром"
    new "Bonjour"

    # game/characters_events_idles/sonya_idles.rpy:274
    old "Позже загляну"
    new "Je reviendrai plus tard"

    # game/characters_events_idles/sonya_idles.rpy:283
    old "Вкусно пахнет"
    new "Ça sent trèsd bon"

    # game/characters_events_idles/sonya_idles.rpy:330
    old "Ждешь чайник?"
    new "Tu attends la bouilloire ?"

    # game/characters_events_idles/sonya_idles.rpy:367
    old "Опять с тряпкой?"
    new "Encore avec un chiffon ?"

    # game/characters_events_idles/sonya_idles.rpy:464
    old "Что смотрим?"
    new "Qu'est-ce qu'on regarde ?"

