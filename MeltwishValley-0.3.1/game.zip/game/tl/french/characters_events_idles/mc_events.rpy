﻿# TODO: Translation updated at 2026-01-21 13:15

# game/characters_events_idles/mc_events.rpy:84
translate french gg_intro_57d9b303:

    # gg "Чёрт . . . конец месяца"
    gg "Merde . . . fin du mois"

# game/characters_events_idles/mc_events.rpy:86
translate french gg_intro_fc2b37ea:

    # gg "Скоро платить по долгам . . ."
    gg "Bientôt il faudrat que je rembourse mes dettes. . ."

# game/characters_events_idles/mc_events.rpy:88
translate french gg_intro_a14d12e5:

    # gg "Ладно . . . хоть сегодня выходной"
    gg "BON . . . au moins aujourd'hui c'est un jour de congé"

# game/characters_events_idles/mc_events.rpy:89
translate french gg_intro_76bd858b:

    # gg "Хоть что-то"
    gg "C'est au moins ça"

# game/characters_events_idles/mc_events.rpy:91
translate french gg_intro_808930b3:

    # gg "Может, хоть пару часов отдохну. . . {w}просто расслаблюсь"
    gg "Peut-être que je vais me reposer pendant au moins quelques heures. . . {w}juste me détendre"

# game/characters_events_idles/mc_events.rpy:98
translate french gg_intro_df03d227:

    # gg "Ну хоть здесь кто-то есть . . ."
    gg "Eh bien, au moins, il y a quelqu'un ici. . ."

# game/characters_events_idles/mc_events.rpy:102
translate french gg_intro_9b1348ec:

    # gg "Найс, я их разнес"
    gg "Bien, je les ai écrasés"

# game/characters_events_idles/mc_events.rpy:104
translate french gg_intro_f004ad75:

    # gg "Ладно . . . бывает"
    gg "D'ACCORD . . . Ça arrive"

# game/characters_events_idles/mc_events.rpy:105
translate french gg_intro_3aef7ac5:

    # gg "Следующая будет норм"
    gg "La prochaine partie se passera mieux"

# game/characters_events_idles/mc_events.rpy:107
translate french gg_intro_f6ebf694:

    # gg "бляя . . ."
    gg "putain de. . ."

# game/characters_events_idles/mc_events.rpy:111
translate french gg_intro_e7a753f9:

    # gg "вот суки"
    gg "voilà, les salopes"

# game/characters_events_idles/mc_events.rpy:112
translate french gg_intro_3a97b002:

    # gg "Окей ладно супер последняя на победу"
    gg "Ok, ok, une dernière pour la victoire"

# game/characters_events_idles/mc_events.rpy:114
translate french gg_intro_94d70a59:

    # gg "{sc}{size=*1.5}СУКА!{/size}{/sc}" with vpunch
    gg "{sc}{size=*1.5}SALOPE !{/size}{/sc}" with vpunch

# game/characters_events_idles/mc_events.rpy:118
translate french gg_intro_08de7acc:

    # gg "Да пошло оно всё . . ."
    gg "Merde tout ça. . ."

# game/characters_events_idles/mc_events.rpy:119
translate french gg_intro_62b01796:

    # gg "Какая же трата времени"
    gg "Quelle perte de temps"

# game/characters_events_idles/mc_events.rpy:122
translate french gg_intro_55fbce1e:

    # gg "Выходной . . . единственный день . . ."
    gg "Jour de congé. . . le seul jour. . ."

# game/characters_events_idles/mc_events.rpy:123
translate french gg_intro_f0abf492:

    # gg "И я просто убил его на эту грёбаную игру"
    gg "Et je viens de le tuer pour ce putain de jeu"

# game/characters_events_idles/mc_events.rpy:125
translate french gg_intro_d924704e:

    # gg "Экран это единственное с чем я общаюсь последнее время"
    gg "L'écran est la seule chose avec laquelle je communique ces derniers temps"

# game/characters_events_idles/mc_events.rpy:131
translate french gg_intro_59ed329a:

    # gg "Я живу здесь . . . но эта квартира"
    gg "J'habite ici. . . mais cet appartement"

# game/characters_events_idles/mc_events.rpy:132
translate french gg_intro_0d6c2d2c:

    # gg "Просто точка между работой и снова работой"
    gg "Juste un moment entre le travail et le travail à nouveau"

# game/characters_events_idles/mc_events.rpy:140
translate french gg_intro_7ce95d1c:

    # gg "Только там . . ."
    gg "Seulement là. . ."

# game/characters_events_idles/mc_events.rpy:142
translate french gg_intro_fa2b02fe:

    # gg "Я чувствовал себя живым"
    gg "Je me sentais vivant"

# game/characters_events_idles/mc_events.rpy:144
translate french gg_intro_5a38b375:

    # gg "Я . . . устал так жить"
    gg "JE . . . j'en ai marre de vivre comme ça"

# game/characters_events_idles/mc_events.rpy:164
translate french gg_intro_eb77ecfa:

    # gg "Да иду я, иду . . ."
    gg "Oui, j'arrive, j'arrive. . ."

# game/characters_events_idles/mc_events.rpy:168
translate french gg_intro_565267c5:

    # gg "Кто там?"
    gg "Qui est là ?"

# game/characters_events_idles/mc_events.rpy:173
translate french gg_intro_60b12a13:

    # gg "Ты кто?"
    gg "Qui es-tu?"

# game/characters_events_idles/mc_events.rpy:175
translate french gg_intro_e00854e1:

    # PostMan "Я почтальон"
    PostMan "je suis la factrice"

# game/characters_events_idles/mc_events.rpy:176
translate french gg_intro_0715dd94:

    # gg "Почтальоны теперь так одеваются?"
    gg "Est-ce que les facteurs s'habillent comme ça maintenant ?"

# game/characters_events_idles/mc_events.rpy:178
translate french gg_intro_0d42e0ef:

    # PostMan "Вот смотри для тебя нарисовали"
    PostMan "Regarde, ils l'ont dessiné pour toi"

# game/characters_events_idles/mc_events.rpy:180
translate french gg_intro_e75db202:

    # PostMan "А я одеваюсь как хочу"
    PostMan "Et je m'habille comme je veux"

# game/characters_events_idles/mc_events.rpy:181
translate french gg_intro_615e77bc:

    # gg "Так а посылка?"
    gg "Alors qu'en est-il du colis ?"

# game/characters_events_idles/mc_events.rpy:183
translate french gg_intro_096cd512:

    # PostMan "А! сейчас"
    PostMan "Ah ! Tout de suite"

# game/characters_events_idles/mc_events.rpy:185
translate french gg_intro_0d3968a6:

    # PostMan "Вот, ты же [povname] правильно?"
    PostMan "Alors, tu es bien [povname], n’est-ce pas ?"

# game/characters_events_idles/mc_events.rpy:187
translate french gg_intro_df24437b:

    # gg "Да, спасибо"
    gg "Oui, merci"

# game/characters_events_idles/mc_events.rpy:189
translate french gg_intro_d7f65fd8:

    # PostMan "Доставка уже оплачена, так что до свидания"
    PostMan "Les frais de port ont déjà été payés, alors au revoir"

# game/characters_events_idles/mc_events.rpy:196
translate french gg_intro_94ec24eb:

    # gg_chat "Эта квартира слишком дорого мне обходится"
    gg_chat "Cet appartement me coûte trop cher"

# game/characters_events_idles/mc_events.rpy:200
translate french gg_intro_083c370e:

    # gg_chat "Эти долги меня скоро сьедят"
    gg_chat "Ces dettes vont bientôt me ronger"

# game/characters_events_idles/mc_events.rpy:203
translate french gg_intro_a7a8221e:

    # gg_chat "Что? {w}Линда?"
    gg_chat "Quoi? {w}Linde ?"

# game/characters_events_idles/mc_events.rpy:208
translate french gg_intro_98898eb6:

    # gg_chat "От бабушки . . ."
    gg_chat "De grand-mère. . ."

# game/characters_events_idles/mc_events.rpy:210
translate french gg_intro_3341868c:

    # gg_chat "Давно не видел её . . ."
    gg_chat "Je ne l'ai pas vue depuis longtemps. . ."

# game/characters_events_idles/mc_events.rpy:211
translate french gg_intro_6f756f5d:

    # gg_chat "Зачем она мне это?"
    gg_chat "Pourquoi a-t-elle besoin de m'envoyer ça ?"

# game/characters_events_idles/mc_events.rpy:212
translate french gg_intro_9f5ccf2a:

    # "Дорогой мой, [povname]"
    "Mon chérie, [povname]"

# game/characters_events_idles/mc_events.rpy:213
translate french gg_intro_7d8221c5:

    # "Пишу тебе это письмо с особым волнением — не потому, что что-то случилось"
    "Je vous écris cette lettre avec un enthousiasme particulier - non pas parce que quelque chose s'est passé"

# game/characters_events_idles/mc_events.rpy:214
translate french gg_intro_bb3819ba:

    # "А потому, что скоро мне предстоит небольшое, но долгое путешествие"
    "Mais parce que bientôt j'ai un court mais long voyage devant moi"

# game/characters_events_idles/mc_events.rpy:215
translate french gg_intro_a901876a:

    # "С тех пор, как ты уехал, тут многое стало тише, спокойнее"
    "Depuis votre départ, les choses sont devenues plus calmes ici."

# game/characters_events_idles/mc_events.rpy:216
translate french gg_intro_8aaddaf9:

    # "Но рядом всё ещё живут хорошие люди — кто-то поможет, если нужно, кто-то просто заглянет поболтать"
    "Mais il y a encore des gens sympas qui vivent à proximité - quelqu'un vous aidera si nécessaire, quelqu'un viendra simplement discuter"

# game/characters_events_idles/mc_events.rpy:217
translate french gg_intro_8049e805:

    # "Дом, в котором ты вырос летом, скоро останется без хозяйки . . ."
    "La maison dans laquelle vous avez grandi l'été se retrouvera bientôt sans maîtresse. . ."

# game/characters_events_idles/mc_events.rpy:218
translate french gg_intro_7713047b:

    # "И мне очень бы не хотелось, чтобы он начал ветшать"
    "Et je ne voudrais vraiment pas que ça commence à se détériorer."

# game/characters_events_idles/mc_events.rpy:220
translate french gg_intro_ce9ad3bf:

    # "Я уезжаю на несколько лет — не волнуйся, здоровье моё в порядке, просто пришло время пожить немного иначе"
    "Je pars pour quelques années - ne vous inquiétez pas, ma santé va bien, il est juste temps de vivre un peu différemment"

# game/characters_events_idles/mc_events.rpy:221
translate french gg_intro_56cba277:

    # "Пока меня не будет, хочу тебя попросить заглядывать в дом"
    "Pendant mon absence, je veux te demander de regarder dans la maison"

# game/characters_events_idles/mc_events.rpy:222
translate french gg_intro_9768b114:

    # "Пусть не пустеет, пусть скрипят половицы, пусть греется чайник"
    "Qu'il ne soit pas vide, que les planches grincent, que la bouilloire se réchauffe"

# game/characters_events_idles/mc_events.rpy:223
translate french gg_intro_040e7339:

    # "Он живой, наш дом — если забросить, начнёт хандрить"
    "Il est vivant, notre maison - si on l’abandonne, elle se mettra à se morfondre"

# game/characters_events_idles/mc_events.rpy:224
translate french gg_intro_581165e6:

    # gg "Она всегда так говорила . . . {w}будто дом — живой"
    gg "Elle a toujours dit ça. . . {w}C'est comme si la maison était vivante"

# game/characters_events_idles/mc_events.rpy:226
translate french gg_intro_82ffc349:

    # "И ещё . . . цветы"
    "Et encore une chose. . . les fleurs"

# game/characters_events_idles/mc_events.rpy:227
translate french gg_intro_3c7f2026:

    # "Мои две любимые. Они остались"
    "Mes deux préférées. Elles sont restés"

# game/characters_events_idles/mc_events.rpy:228
translate french gg_intro_a2adc801:

    # "Одна крепкая, корнями в землю, упрямая, немного колючая, зато как зацветёт — всем на удивление"
    "L'une est forte, avec des racines dans le sol, têtu, un peu épineux, mais quand elle fleurit, tout le monde est surpris"

# game/characters_events_idles/mc_events.rpy:229
translate french gg_intro_d1748522:

    # "Вторая — лёгкая, солнечная, смеётся даже в дождь, растёт, куда глянет, и всё ей в радость"
    "La seconde est légère, ensoleillée, rit même sous la pluie, grandit partout où elle regarde et tout la rend heureuse"

# game/characters_events_idles/mc_events.rpy:231
translate french gg_intro_5cd83b3b:

    # gg_chat "Причем здесь цветы вообще . . ."
    gg_chat "Et voici les fleurs en général. . ."

# game/characters_events_idles/mc_events.rpy:232
translate french gg_intro_d87a1c8d:

    # "Уход у них разный, но суть одна — внимание"
    "Leurs soins sont différents, mais l'essence est la même : attention"

# game/characters_events_idles/mc_events.rpy:233
translate french gg_intro_0733c9df:

    # "Ты справишься — у тебя ведь моё упрямство и моё сердце"
    "Tu y arriveras - tu as mon entêtement et mon cœur"

# game/characters_events_idles/mc_events.rpy:234
translate french gg_intro_3406a366:

    # "Очень хочу, чтобы ты оказался там пораньше — дом ждёт тебя"
    "Je veux vraiment que tu viennes rapidement - la maison t'attend"

# game/characters_events_idles/mc_events.rpy:235
translate french gg_intro_bfcc2649:

    # "С любовью"
    "Avec amour"

# game/characters_events_idles/mc_events.rpy:236
translate french gg_intro_3f6a1326:

    # "Твоя бабушка Линда"
    "Ta grand-mère Linda"

# game/characters_events_idles/mc_events.rpy:238
translate french gg_intro_22bce088:

    # gg_chat "Бабушка была всегда рядом, её дом был моим домом"
    gg_chat "Grand-mère était toujours là, sa maison était ma maison"

# game/characters_events_idles/mc_events.rpy:240
translate french gg_intro_4164e503:

    # gg_chat "Зачем она меня просит присматривать за домом?"
    gg_chat "Pourquoi me demande-t-elle de m'occuper de la maison ?"

# game/characters_events_idles/mc_events.rpy:242
translate french gg_intro_ad05e118:

    # gg_chat "Просто взять и уехать?"
    gg_chat "Juste tout laisser et partir ?"

# game/characters_events_idles/mc_events.rpy:244
translate french gg_intro_0ae1f5e0:

    # gg_chat "Будто у меня тут ничего нет"
    gg_chat "C'est comme si je n'avais rien ici"

# game/characters_events_idles/mc_events.rpy:246
translate french gg_intro_e3e17f69:

    # gg_chat "У меня своих проблем по горло"
    gg_chat "J'ai assez de problèmes à m'occuper"

# game/characters_events_idles/mc_events.rpy:248
translate french gg_intro_4810f11e:

    # gg_chat "Чёрт я опаздываю"
    gg_chat "Merde, je suis en retard"

# game/characters_events_idles/mc_events.rpy:250
translate french gg_intro_3aa5e105:

    # gg_chat "Потом поем"
    gg_chat "Je mangerais plus tard"

# game/characters_events_idles/mc_events.rpy:254
translate french gg_intro_4a0266b9:

    # gg_chat "Я отвечу бабушка попозже"
    gg_chat "Je répondrai à grand-mère plus tard"

# game/characters_events_idles/mc_events.rpy:261
translate french gg_intro_9cdabec6:

    # gg_chat "Серьёзно? . . ."
    gg_chat "Sérieusement? . . ."

# game/characters_events_idles/mc_events.rpy:265
translate french gg_intro_7331a474:

    # gg_chat "Блять . . ."
    gg_chat "Putain. . ."

# game/characters_events_idles/mc_events.rpy:266
translate french gg_intro_db310e96:

    # gg_chat "Как всегда"
    gg_chat "Comme toujours"

# game/characters_events_idles/mc_events.rpy:270
translate french gg_intro_4b9afd3e:

    # gg "Я пришел"
    gg "Je suis là"

# game/characters_events_idles/mc_events.rpy:272
translate french gg_intro_80d3fcff:

    # Assistant "Опоздал. Как всегда"
    Assistant "Je suis en retard. Comme toujours"

# game/characters_events_idles/mc_events.rpy:274
translate french gg_intro_d3b968fb:

    # Assistant "И напомню: если продолжишь {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "Et laissez-moi vous rappeler : si vous continuez, {w}la conversation sur une réduction de salaire n'est déjà qu'une question de temps"

# game/characters_events_idles/mc_events.rpy:276
translate french gg_intro_0bd28ad3:

    # gg_chat "Да, конечно"
    gg_chat "Oui bien sûr"

# game/characters_events_idles/mc_events.rpy:285
translate french gg_intro_603b869e:

    # Director "Это срочно"
    Director "C'est urgent"

# game/characters_events_idles/mc_events.rpy:287
translate french gg_intro_eac333f5:

    # Director "За Петрова сделаешь"
    Director "Tu le feras pour Petrov"

# game/characters_events_idles/mc_events.rpy:289
translate french gg_intro_2ccd9b60:

    # gg "Это не мои задачи"
    gg "Ce ne sont pas mes tâches"

# game/characters_events_idles/mc_events.rpy:290
translate french gg_intro_df8035b4:

    # gg "Почему я должен работать за другого"
    gg "Pourquoi devrais-je travailler pour quelqu’un d’autre ?"

# game/characters_events_idles/mc_events.rpy:292
translate french gg_intro_e2eb6337:

    # Director "Мне плевать"
    Director "Je m'en fiche"

# game/characters_events_idles/mc_events.rpy:294
translate french gg_intro_66f2f5ce:

    # Director "Сделаешь всё до конца недели"
    Director "Vous aurez tout terminé d'ici la fin de la semaine"

# game/characters_events_idles/mc_events.rpy:297
translate french gg_intro_b7d7b4b2:

    # Director "Не успеешь — сам знаешь последствия"
    Director "Si tu n'as pas le temps, tu connais les conséquences"

# game/characters_events_idles/mc_events.rpy:303
translate french gg_intro_3d5010f4:

    # gg_chat "Им всегда плевать"
    gg_chat "Ils s'en moquent toujours"

# game/characters_events_idles/mc_events.rpy:304
translate french gg_intro_1670588b:

    # gg_chat "Я здесь просто расходник"
    gg_chat "Je ne suis qu'un consommable ici"

# game/characters_events_idles/mc_events.rpy:308
translate french gg_intro_3c056c18:

    # gg_chat "Сколько ни делай — конца нет"
    gg_chat "Peu importe ce que tu fais, il n'y a pas de fin"

# game/characters_events_idles/mc_events.rpy:321
translate french gg_intro_577e1c14:

    # Director "Секретарша сказала"
    Director "Le secrétaire a dit"

# game/characters_events_idles/mc_events.rpy:324
translate french gg_intro_e2282b24:

    # Director "Что ты опоздал"
    Director "Pourquoi es-tu en retard"

# game/characters_events_idles/mc_events.rpy:326
translate french gg_intro_009afbde:

    # Director "Если не сдашь это в срок"
    Director "Si tu ne le rends pas à temps"

# game/characters_events_idles/mc_events.rpy:327
translate french gg_intro_e8f982f1:

    # Director "Можешь искать новую работу"
    Director "Vous pouvez chercher un nouvel emploi"

# game/characters_events_idles/mc_events.rpy:329
translate french gg_intro_5d67e1da:

    # Director "Понял?"
    Director "Compris?"

# game/characters_events_idles/mc_events.rpy:330
translate french gg_intro_ef555dd8:

    # gg_chat "Вот сука"
    gg_chat "C'est une salope"

# game/characters_events_idles/mc_events.rpy:332
translate french gg_intro_e967e307:

    # gg "Да"
    gg "Oui"

# game/characters_events_idles/mc_events.rpy:340
translate french gg_intro_aba5df1c:

    # gg_chat "Им всё равно — значит, и мне тоже"
    gg_chat "Ils s'en moquent, ce qui veut dire que moi non plus"

# game/characters_events_idles/mc_events.rpy:342
translate french gg_intro_59df236a:

    # gg_chat "С меня довольно"
    gg_chat "J'en ai assez"

# game/characters_events_idles/mc_events.rpy:344
translate french gg_intro_c0a84961:

    # gg_chat "Не поспешил ли я?"
    gg_chat "Suis-je trop pressé ?"

# game/characters_events_idles/mc_events.rpy:346
translate french gg_intro_a632776e:

    # gg_chat "Хватит"
    gg_chat "Assez"

# game/characters_events_idles/mc_events.rpy:355
translate french gg_intro_14d66a18:

    # Director "Ты вообще, что делаешь"
    Director "Qu'est-ce que tu fais au juste ?"

# game/characters_events_idles/mc_events.rpy:357
translate french gg_intro_dfc9c282:

    # gg "Я увольняюсь"
    gg "j'arrête"

# game/characters_events_idles/mc_events.rpy:359
translate french gg_intro_8543ef20:

    # Director "Как ты смеешь??"
    Director "Comment oses-tu ??"

# game/characters_events_idles/mc_events.rpy:371
translate french gg_intro_1a1334a8:

    # Assistant "Ой"
    Assistant "Oh"

# game/characters_events_idles/mc_events.rpy:373
translate french gg_intro_11803396:

    # Assistant "Ты что делаешь!?"
    Assistant "Que fais-tu!?"

# game/characters_events_idles/mc_events.rpy:374
translate french gg_intro_b31c2e41:

    # gg "Счастливо оставаться"
    gg "Bon séjour"

# game/characters_events_idles/mc_events.rpy:376
translate french gg_intro_96fd98eb:

    # gg_chat "Наконец-то"
    gg_chat "Enfin"

# game/characters_events_idles/mc_events.rpy:378
translate french gg_intro_e446a106:

    # gg_chat "Моя привычная жизнь закончилась"
    gg_chat "Ma vie normale est terminée"

# game/characters_events_idles/mc_events.rpy:382
translate french gg_intro_724c298c:

    # gg_chat "На улице столько парочек гуляет"
    gg_chat "Il y a tellement de couples qui marchent dans la rue"

# game/characters_events_idles/mc_events.rpy:383
translate french gg_intro_acc56f85:

    # gg_chat "Жизнь будто проходит мимо"
    gg_chat "La vie semble vous échapper"

# game/characters_events_idles/mc_events.rpy:397
translate french gg_intro_a57d47f4:

    # gg_chat "Я даже не заметил"
    gg_chat "Je n'ai même pas remarqué"

# game/characters_events_idles/mc_events.rpy:399
translate french gg_intro_1ba141ba:

    # gg_chat "Только у моего родного дома был такой ключ"
    gg_chat "Seule ma maison possédait une telle clé."

# game/characters_events_idles/mc_events.rpy:401
translate french gg_intro_cfb8599b:

    # gg_chat "Это шанс"
    gg_chat "C'est une chance"

# game/characters_events_idles/mc_events.rpy:402
translate french gg_intro_3ce8ccb4:

    # gg_chat "На новую жизнь"
    gg_chat "Pour une nouvelle vie"

# game/characters_events_idles/mc_events.rpy:404
translate french gg_intro_4db85a28:

    # gg_chat "Это все мне больше не нужно"
    gg_chat "Je n'ai plus besoin de tout ça"

# game/characters_events_idles/mc_events.rpy:414
translate french gg_intro_c3f38f42:

    # gg_chat "Пора начать сначала"
    gg_chat "Il est temps de recommencer"

# game/characters_events_idles/mc_events.rpy:422
translate french gg_intro_07728fd6:

    # gg_chat "После города — будто другой мир"
    gg_chat "Après la ville c'est comme un autre monde"

# game/characters_events_idles/mc_events.rpy:424
translate french gg_intro_fe890fb1:

    # gg_chat "Даже к этому я отвык . . ."
    gg_chat "Je ne suis même pas habitué à cela. . ."

# game/characters_events_idles/mc_events.rpy:428
translate french gg_intro_cac1bf85:

    # gg_chat "Мне здесь придётся многому научиться"
    gg_chat "J'ai beaucoup à apprendre ici"

# game/characters_events_idles/mc_events.rpy:431
translate french gg_intro_a05332c8:

    # gg_chat "Я даже позабыл где дом . . ."
    gg_chat "J'ai même oublié où est la maison. . ."

# game/characters_events_idles/mc_events.rpy:433
translate french gg_intro_a4a7b296:

    # gg_chat "Все кого я вижу со мной здороваются"
    gg_chat "Tous ceux que je vois me disent bonjour"

# game/characters_events_idles/mc_events.rpy:434
translate french gg_intro_720fce13:

    # gg_chat "Будто я тут не чужой"
    gg_chat "C'est comme si je n'étais pas un étranger ici"

# game/characters_events_idles/mc_events.rpy:435
translate french gg_intro_094d1de6:

    # UnknownGirl "Эй парень, постой-ка!"
    UnknownGirl "Hé mec, attends une minute !"

# game/characters_events_idles/mc_events.rpy:437
translate french gg_intro_050bbcbc:

    # gg "Здравствуйте"
    gg "Bonjour"

# game/characters_events_idles/mc_events.rpy:439
translate french gg_intro_0e31fcad:

    # UnknownGirl "Давно тут новых лиц не видели"
    UnknownGirl "Nous n'avons pas vu de nouveaux visages ici depuis longtemps"

# game/characters_events_idles/mc_events.rpy:441
translate french gg_intro_0ea7d489:

    # gg "Да только приехал"
    gg "Oui, je viens d'arriver"

# game/characters_events_idles/mc_events.rpy:443
translate french gg_intro_a55c0f0a:

    # UnknownGirl "У нас тут новым людям всегда рады"
    UnknownGirl "Les nouvelles personnes sont toujours les bienvenues ici"

# game/characters_events_idles/mc_events.rpy:445
translate french gg_intro_096f2b23:

    # UnknownGirl "Только вот"
    UnknownGirl "Seulement maintenant"

# game/characters_events_idles/mc_events.rpy:446
translate french gg_intro_83909d33:

    # UnknownGirl "Настоящих мужчин не хватает"
    UnknownGirl "Il n'y a pas assez de vrais hommes"

# game/characters_events_idles/mc_events.rpy:448
translate french gg_intro_8ffcdc07:

    # gg_chat "Что она вообще имеет в виду?"
    gg_chat "Que veut-elle dire au juste ?"

# game/characters_events_idles/mc_events.rpy:450
translate french gg_intro_f312c19f:

    # UnknownGirl "Ладно, не пугайся. Шучу"
    UnknownGirl "D'accord, n'aie pas peur. Je rigole"

# game/characters_events_idles/mc_events.rpy:452
translate french gg_intro_af75b79f:

    # UnknownGirl "Если что то нужно будет спрашивай помощь у любого"
    UnknownGirl "Si vous avez besoin de quelque chose, demandez de l’aide à quelqu’un."

# game/characters_events_idles/mc_events.rpy:454
translate french gg_intro_f35a0bb9:

    # UnknownGirl "Удачи тебе"
    UnknownGirl "Bonne chance"

# game/characters_events_idles/mc_events.rpy:456
translate french gg_intro_6a134ac2:

    # gg "Хорошо и вам отличного дня"
    gg "ok, passe une bonne journée toi aussi"

# game/characters_events_idles/mc_events.rpy:458
translate french gg_intro_b0f731c4:

    # gg_chat "Какая необычно добрая девушка"
    gg_chat "Quelle fille inhabituellement gentille"

# game/characters_events_idles/mc_events.rpy:459
translate french gg_intro_b08ae0cc:

    # gg_chat "Бабушка похоже говорила правду о людях здесь"
    gg_chat "Grand-mère semblait dire la vérité sur les gens d'ici"

# game/characters_events_idles/mc_events.rpy:463
translate french gg_intro_b07cdeca:

    # gg_chat "А если там уже не так, как я помню?"
    gg_chat "Et si ce n’était plus la même chose dont je me souviens ?"

# game/characters_events_idles/mc_events.rpy:465
translate french gg_intro_2c26269d:

    # gg_chat "Но назад пути нет"
    gg_chat "Mais il n'y a pas de retour en arrière"

# game/characters_events_idles/mc_events.rpy:474
translate french gg_intro_9b8edceb:

    # gg_chat "Да дом поменялся"
    gg_chat "Oui la maison a changé"

# game/characters_events_idles/mc_events.rpy:482
translate french gg_intro_766d518e:

    # gg_chat "Кто-то есть?"
    gg_chat "Y a-t-il quelqu'un ?"

# game/characters_events_idles/mc_events.rpy:492
translate french gg_intro_b989363c:

    # gg ". . ."
    gg ". . ."

# game/characters_events_idles/mc_events.rpy:498
translate french gg_intro_7ad2e1b7:

    # Sonya "АААА!"
    Sonya "AAAA !"

# game/characters_events_idles/mc_events.rpy:500
translate french gg_intro_684edc0b:

    # Sonya "МАЯ!"
    Sonya "MAYA!"

# game/characters_events_idles/mc_events.rpy:502
translate french gg_intro_1124aafa:

    # Sonya "МАЯ, ТУТ КТО-ТО ЕСТЬ!!"
    Sonya "MAI, IL Y A QUELQU'UN ICI !!"

# game/characters_events_idles/mc_events.rpy:506
translate french gg_intro_cba5cc13:

    # gg_chat "Что это сейчас было? . . ."
    gg_chat "Qu'est-ce que c'était que ça ? . . ."

# game/characters_events_idles/mc_events.rpy:508
translate french gg_intro_74014e3a:

    # gg_chat "Я . . ."
    gg_chat "JE . . ."

# game/characters_events_idles/mc_events.rpy:510
translate french gg_intro_8b3408ac:

    # gg_chat "Я ничего не понял"
    gg_chat "j'ai rien compris"

# game/characters_events_idles/mc_events.rpy:515
translate french gg_intro_18e79df2:

    # Maya "Ты кто такой?"
    Maya "Qui êtes-vous?"

# game/characters_events_idles/mc_events.rpy:517
translate french gg_intro_35cf3bf6:

    # Maya "Убирайся отсюда. Сейчас же"
    Maya "Sortez d'ici. Maintenant"

# game/characters_events_idles/mc_events.rpy:519
translate french gg_intro_be5ef2a9:

    # gg "Стой подожди"
    gg "Attends attends"

# game/characters_events_idles/mc_events.rpy:521
translate french gg_intro_8750b79b:

    # gg "Я внук хозяйки дома"
    gg "Je suis le petit-fils de la maîtresse de maison"

# game/characters_events_idles/mc_events.rpy:523
translate french gg_intro_eba62b3e:

    # gg "Это дом моей бабушки"
    gg "C'est la maison de ma grand-mère"

# game/characters_events_idles/mc_events.rpy:525
translate french gg_intro_d179509d:

    # Maya "Внук?"
    Maya "Petit fils?"

# game/characters_events_idles/mc_events.rpy:527
translate french gg_intro_cb51aa26:

    # Maya "Что то я такого внука никогда здесь не видела"
    Maya "Je n'ai jamais vu un tel petit-fils ici"

# game/characters_events_idles/mc_events.rpy:529
translate french gg_intro_fde7546c:

    # Maya "Думаешь я совсем тупая"
    Maya "Pensez-vous que je suis complètement stupide"

# game/characters_events_idles/mc_events.rpy:531
translate french gg_intro_a41fbef3:

    # gg "Подожди"
    gg "Attendez"

# game/characters_events_idles/mc_events.rpy:533
translate french gg_intro_0df5d29f:

    # gg "Я не знал, что здесь кто-то живёт"
    gg "Je ne savais pas que quelqu'un vivait ici"

# game/characters_events_idles/mc_events.rpy:535
translate french gg_intro_4b24971a:

    # Maya "Конечно не знал"
    Maya "Bien sûr, je ne savais pas"

# game/characters_events_idles/mc_events.rpy:537
translate french gg_intro_4af9c6fc:

    # Maya "А в чужие дома ты тоже «случайно» заходишь?"
    Maya "Allez-vous aussi « accidentellement » chez d’autres personnes ?"

# game/characters_events_idles/mc_events.rpy:543
translate french gg_intro_2a307bc4:

    # gg "Вот"
    gg "Ici"

# game/characters_events_idles/mc_events.rpy:545
translate french gg_intro_c9e9dab5:

    # gg "Это письмо от моей бабушки"
    gg "Cette lettre vient de ma grand-mère"

# game/characters_events_idles/mc_events.rpy:547
translate french gg_intro_4a769d1b:

    # gg "Она попросила меня присмотреть за домом"
    gg "Elle m'a demandé de m'occuper de la maison"

# game/characters_events_idles/mc_events.rpy:549
translate french gg_intro_ee0d1154:

    # Maya "И ты думаешь, я просто поверю этой бумажке?"
    Maya "Et tu penses que je vais juste croire ce morceau de papier ?"

# game/characters_events_idles/mc_events.rpy:551
translate french gg_intro_6d39543d:

    # gg "Я никуда не спешу"
    gg "je ne suis pas pressé"

# game/characters_events_idles/mc_events.rpy:563
translate french gg_intro_8ea26f73:

    # Maya "Дорогой"
    Maya "Cher"

# game/characters_events_idles/mc_events.rpy:565
translate french gg_intro_9a149321:

    # Maya "[povname]"
    Maya "[povname]"

# game/characters_events_idles/mc_events.rpy:569
translate french gg_intro_6e311c65:

    # Maya "Скоро останется без хозяйки"
    Maya "Bientôt il se retrouvera sans maîtresse"

# game/characters_events_idles/mc_events.rpy:571
translate french gg_intro_2d481ec2:

    # Maya "Уезжаю на несколько лет"
    Maya "je pars pour quelques années"

# game/characters_events_idles/mc_events.rpy:573
translate french gg_intro_cada9fb7:

    # Maya "Мои цветы две любимые. Они остались"
    Maya "Mes deux fleurs préférées. Elles sont restées"

# game/characters_events_idles/mc_events.rpy:575
translate french gg_intro_4e84a3f6:

    # Maya "Дом ждёт тебя"
    Maya "La maison vous attend"

# game/characters_events_idles/mc_events.rpy:577
translate french gg_intro_a2cdc4ac:

    # Maya "Твоя бабушка Линда"
    Maya "Ta grand-mère Linda"

# game/characters_events_idles/mc_events.rpy:582
translate french gg_intro_dfc10494:

    # Maya "Боже ладно"
    Maya "Bon d'accord"

# game/characters_events_idles/mc_events.rpy:583
translate french gg_intro_c4340902:

    # Maya "Похоже, на правду"
    Maya "On dirait que c'est vrai"

# game/characters_events_idles/mc_events.rpy:585
translate french gg_intro_329e21f7:

    # Maya "Но это ничего не меняет"
    Maya "Mais ça ne change rien"

# game/characters_events_idles/mc_events.rpy:587
translate french gg_intro_dd6c3bfe:

    # Maya "Ты здесь чужой"
    Maya "Tu es un étranger ici"

# game/characters_events_idles/mc_events.rpy:589
translate french gg_intro_69801038:

    # gg "Вообще-то это мой дом"
    gg "En fait, c'est ma maison"

# game/characters_events_idles/mc_events.rpy:591
translate french gg_intro_9a295059:

    # Maya "Это ты мы с Соней решим!"
    Maya "C'est vous et Sonya qui en déciderez !"

# game/characters_events_idles/mc_events.rpy:593
translate french gg_intro_9839e4df:

    # Maya "{sc}СОНЯ{/sc}" with hpunch
    Maya "{sc}SONYA{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:595
translate french gg_intro_2551f6f7:

    # Maya "Всё нормально, он не опасный"
    Maya "C'est bon, il n'est pas dangereux"

# game/characters_events_idles/mc_events.rpy:597
translate french gg_intro_d6a7eefb:

    # gg "Я так и сказал"
    gg "C'est ce que j'ai dit"

# game/characters_events_idles/mc_events.rpy:599
translate french gg_intro_f3cf760b:

    # Maya "Слушай если ты хоть что-то сделаешь"
    Maya "Écoute si tu fais quelque chose"

# game/characters_events_idles/mc_events.rpy:601
translate french gg_intro_d58555f3:

    # Maya "Я тебя мигом выгоню. Понял?"
    Maya "Je t'expulserais immédiatement. Compris?"

# game/characters_events_idles/mc_events.rpy:603
translate french gg_intro_d96e5a49:

    # gg "Понял"
    gg "Compris"

# game/characters_events_idles/mc_events.rpy:605
translate french gg_intro_a59664de:

    # Maya "Жди на кухне я передам письмо соне"
    Maya "Attends dans la cuisine, je vais donner la lettre à Sonya"

# game/characters_events_idles/mc_events.rpy:612
translate french gg_intro_0ac91294:

    # gg_chat "Вот это встреча"
    gg_chat "C'est la réunion"

# game/characters_events_idles/mc_events.rpy:616
translate french gg_intro_baac99bc:

    # gg_chat "Я не ожидал такого"
    gg_chat "Je ne m'attendais pas à ça"

# game/characters_events_idles/mc_events.rpy:618
translate french gg_intro_feaa3808:

    # gg_chat "Почему бабушка ничего не сказала?"
    gg_chat "Pourquoi grand-mère n'a rien dit ?"

# game/characters_events_idles/mc_events.rpy:627
translate french gg_intro_a070649e:

    # Sonya "Эм . . . привет"
    Sonya "Euh. . . Bonjour"

# game/characters_events_idles/mc_events.rpy:629
translate french gg_intro_6a2024b3:

    # Sonya "Я . . . я Соня"
    Sonya "JE . . . je m'appelle Sonya"

# game/characters_events_idles/mc_events.rpy:631
translate french gg_intro_12083d44:

    # Sonya "Я надеюсь ты не обиделся на Маю"
    Sonya "J'espère que tu n'es pas offensé par Maya"

# game/characters_events_idles/mc_events.rpy:633
translate french gg_intro_dfe04d57:

    # gg "Нет. Всё нормально"
    gg "Non, tout va bien"

# game/characters_events_idles/mc_events.rpy:635
translate french gg_intro_85f8708a:

    # gg "Я [povname]"
    gg "Je suis [povname]"

# game/characters_events_idles/mc_events.rpy:637
translate french gg_intro_78b27818:

    # Sonya "Мая сказала, что ты внук Линды"
    Sonya "Maya a dit que tu es le petit-fils de Linda"

# game/characters_events_idles/mc_events.rpy:638
translate french gg_intro_b5f632a7:

    # Sonya "Так . . . неожиданно получилось"
    Sonya "Donc . . . c'est arrivé de façon inattendue"

# game/characters_events_idles/mc_events.rpy:643
translate french gg_intro_053ce261:

    # Sonya "И если честно"
    Sonya "Et pour être honnête"

# game/characters_events_idles/mc_events.rpy:645
translate french gg_intro_4bf5a43d:

    # Sonya "Я сначала очень испугалась"
    Sonya "J'avais très peur au début"

# game/characters_events_idles/mc_events.rpy:649
translate french gg_intro_87cb5bde:

    # gg "Извини"
    gg "Désolé"

# game/characters_events_idles/mc_events.rpy:651
translate french gg_intro_1dc14df3:

    # gg "Я правда не хотел тебя пугать, стоило постучать"
    gg "Je ne voulais vraiment pas te faire peur, j'aurais dû frapper"

# game/characters_events_idles/mc_events.rpy:655
translate french gg_intro_2d8b9c21:

    # Sonya "Нет-нет всё нормально"
    Sonya "Non, non, tout va bien"

# game/characters_events_idles/mc_events.rpy:657
translate french gg_intro_9587b334:

    # Sonya "Просто не ожидали гостей"
    Sonya "Nous n'attendions tout simplement pas d'invités"

# game/characters_events_idles/mc_events.rpy:661
translate french gg_intro_9a863e77:

    # Sonya "Я прочла письмо линды"
    Sonya "J'ai lu la lettre de Linda"

# game/characters_events_idles/mc_events.rpy:663
translate french gg_intro_c7d51db6:

    # Sonya "Там про цветы было"
    Sonya "Il s'agissait de fleurs"

# game/characters_events_idles/mc_events.rpy:665
translate french gg_intro_c9e9d0a0:

    # Sonya "Это она так нас описывает"
    Sonya "C'est ainsi qu'elle nous décrit"

# game/characters_events_idles/mc_events.rpy:669
translate french gg_intro_7b39b9b5:

    # Sonya "Мы с Маей живём здесь вместе"
    Sonya "Maya et moi vivons ici ensemble"

# game/characters_events_idles/mc_events.rpy:671
translate french gg_intro_c3003883:

    # Sonya "Линда сначала просто сдавала нам комнаты"
    Sonya "Au début, Linda nous louait juste des chambres."

# game/characters_events_idles/mc_events.rpy:673
translate french gg_intro_eb14c7b5:

    # Sonya "А потом, когда уехала, сказала, что дом остаётся на нас"
    Sonya "Et puis, en partant, elle a dit que la maison restait avec nous"

# game/characters_events_idles/mc_events.rpy:675
translate french gg_intro_6dcfd261:

    # gg "То есть вы тут уже давно?"
    gg "Alors tu es ici depuis longtemps ?"

# game/characters_events_idles/mc_events.rpy:677
translate french gg_intro_c8772e87:

    # Sonya "Да"
    Sonya "Oui"

# game/characters_events_idles/mc_events.rpy:679
translate french gg_intro_5e85de7c:

    # Sonya "Мы привыкли. Даже кота завели"
    Sonya "Nous y sommes habitués. Nous avons même un chat"

# game/characters_events_idles/mc_events.rpy:681
translate french gg_intro_0879bf60:

    # Sonya "Для нас это уже дом"
    Sonya "C'est déjà chez nous pour nous"

# game/characters_events_idles/mc_events.rpy:683
translate french gg_intro_dad9ef91:

    # Sonya "Линда иногда о тебе говорила"
    Sonya "Linda parlait parfois de toi"

# game/characters_events_idles/mc_events.rpy:685
translate french gg_intro_a3493fdc:

    # Sonya "Говорила, что ты хороший, по крайнее мерее в дестве"
    Sonya "Elle a dit que tu étais bon, du moins dans ton enfance"

# game/characters_events_idles/mc_events.rpy:687
translate french gg_intro_0782f2e3:

    # gg "Надеюсь, она не слишком приукрашивала"
    gg "J'espère qu'elle ne l'a pas trop embelli"

# game/characters_events_idles/mc_events.rpy:689
translate french gg_intro_3e3d596e:

    # gg "Сейчас я сам не знаю, кем стал"
    gg "Maintenant, je ne sais pas qui je suis devenu"

# game/characters_events_idles/mc_events.rpy:691
translate french gg_intro_b8032679:

    # Sonya "А ты . . ."
    Sonya "Et toi . . ."

# game/characters_events_idles/mc_events.rpy:693
translate french gg_intro_7ad63786:

    # Sonya "Ты надолго?"
    Sonya "Combien de temps vas-tu rester ?"

# game/characters_events_idles/mc_events.rpy:695
translate french gg_intro_c2f6d189:

    # Sonya "Ну какой у тебя дальше план?"
    Sonya "Alors, quel est ton prochain plan ?"

# game/characters_events_idles/mc_events.rpy:697
translate french gg_intro_9f30eca5:

    # gg "Я пока не знаю"
    gg "je ne sais pas encore"

# game/characters_events_idles/mc_events.rpy:699
translate french gg_intro_51f05bc9:

    # gg "Мне нужно время"
    gg "j'ai besoin de temps"

# game/characters_events_idles/mc_events.rpy:701
translate french gg_intro_301f9bbb:

    # gg_chat "Хотя здесь приятно"
    gg_chat "Mais c'est sympa ici"

# game/characters_events_idles/mc_events.rpy:704
translate french gg_intro_a1c2b87a:

    # gg_chat "И как-то спокойно"
    gg_chat "Et en quelque sorte calme"

# game/characters_events_idles/mc_events.rpy:706
translate french gg_intro_1043df55:

    # Sonya "Уже поздно"
    Sonya "Il est déjà tard"

# game/characters_events_idles/mc_events.rpy:708
translate french gg_intro_f1483558:

    # Sonya "Мы можем поговорить ещё потом"
    Sonya "Nous pourrons en parler plus tard"

# game/characters_events_idles/mc_events.rpy:710
translate french gg_intro_701fa6da:

    # Sonya "Ты можешь лечь в зале"
    Sonya "Tu peux t'allonger dans le salon"

# game/characters_events_idles/mc_events.rpy:712
translate french gg_intro_7adf858b:

    # Sonya "Других мест спальных у нас нету"
    Sonya "Nous n'avons pas d'autres endroits pour dormir"

# game/characters_events_idles/mc_events.rpy:714
translate french gg_intro_e6ef238c:

    # gg "Да хорошо"
    gg "Oui, d'accord"

# game/characters_events_idles/mc_events.rpy:716
translate french gg_intro_18a3c2d6:

    # gg "Спасибо за теплый прием"
    gg "Merci pour l'accueil chaleureux"

# game/characters_events_idles/mc_events.rpy:718
translate french gg_intro_2857877c:

    # Sonya "Я положу все необходимое на диван"
    Sonya "Je mettrai tout ce dont tu as besoin sur le canapé"

# game/characters_events_idles/mc_events.rpy:720
translate french gg_intro_f96b8f09:

    # gg_chat "Похоже, пока я могу здесь остаться"
    gg_chat "On dirait que je peux rester ici pour le moment"

# game/characters_events_idles/mc_events.rpy:724
translate french gg_intro_19e97f44:

    # gg_chat "Я так устал за этот день"
    gg_chat "je suis tellement fatiguée aujourd'hui"

# game/characters_events_idles/mc_events.rpy:725
translate french gg_intro_6f0f1d5a:

    # gg_chat "Пора отдыхать"
    gg_chat "Il est temps de se reposer"

# game/characters_events_idles/mc_events.rpy:737
translate french gg_first_morning_8051fd9f:

    # gg_chat "Утро"
    gg_chat "Matin"

# game/characters_events_idles/mc_events.rpy:739
translate french gg_first_morning_c535b2eb:

    # gg_chat "Давно я так не просыпался"
    gg_chat "Je ne me suis pas réveillé comme ça depuis longtemps"

# game/characters_events_idles/mc_events.rpy:741
translate french gg_first_morning_654f0c17:

    # gg_chat "Никакой работы"
    gg_chat "Pas de travail"

# game/characters_events_idles/mc_events.rpy:743
translate french gg_first_morning_81883fea:

    # gg_chat "Никакого давления"
    gg_chat "Aucune pression"

# game/characters_events_idles/mc_events.rpy:745
translate french gg_first_morning_90c39e25:

    # gg_chat "Природа"
    gg_chat "Nature"

# game/characters_events_idles/mc_events.rpy:747
translate french gg_first_morning_dbabb2ca:

    # gg_chat "Здесь я свободен"
    gg_chat "Ici, je suis libre"

# game/characters_events_idles/mc_events.rpy:749
translate french gg_first_morning_663fb966:

    # gg_chat "В городе я жил как белка в колесе"
    gg_chat "En ville, je vivais comme un écureuil dans une roue"

# game/characters_events_idles/mc_events.rpy:751
translate french gg_first_morning_bb031547:

    # gg_chat "Не жизнь, а выживание"
    gg_chat "Pas la vie, mais la survie"

# game/characters_events_idles/mc_events.rpy:753
translate french gg_first_morning_49963596:

    # gg_chat "Мне не хватало этого в городе"
    gg_chat "J'ai raté ça en ville"

# game/characters_events_idles/mc_events.rpy:754
translate french gg_first_morning_0af076a7:

    # gg_chat "Кажется я останусь"
    gg_chat "Il semble que je vais rester"

# game/characters_events_idles/mc_events.rpy:756
translate french gg_first_morning_82a7ff6e:

    # gg_chat "Дорогой бабушке . . ."
    gg_chat "Chère grand-mère. . ."

# game/characters_events_idles/mc_events.rpy:757
translate french gg_first_morning_4f068f55:

    # gg_chat "Спасибо похоже, я нашёл то, чего мне не хватало"
    gg_chat "Merci, on dirait que j'ai trouvé ce qui me manquait"

# game/characters_events_idles/mc_events.rpy:759
translate french gg_first_morning_88a92574:

    # gg_chat "Моя жизнь меняется"
    gg_chat "Ma vie change"

# game/characters_events_idles/mc_events.rpy:761
translate french gg_first_morning_d67d6049:

    # gg_chat "Посмотрим, что из этого выйдет"
    gg_chat "Voyons ce qu'il en résulte"

# game/characters_events_idles/mc_events.rpy:780
translate french gg_first_morning_kitchen_b418e893:

    # gg_chat "Можно просто сидеть"
    gg_chat "Tu peux juste t'asseoir"

# game/characters_events_idles/mc_events.rpy:781
translate french gg_first_morning_kitchen_820306b2:

    # gg_chat "Никуда не спешить"
    gg_chat "Pas besoin de se précipitez nulle part"

# game/characters_events_idles/mc_events.rpy:787
translate french gg_first_morning_kitchen_47966b2a:

    # gg_chat "Обычно меня раздражает мытье посуды. А тут даже приятно"
    gg_chat "Faire la vaisselle m’irrite généralement. Et c'est même sympa ici"

# game/characters_events_idles/mc_events.rpy:789
translate french gg_first_morning_kitchen_2119fa08:

    # gg_chat "Нужно будет всё здесь изучить"
    gg_chat "Il faudra tout explorer ici"

# game/characters_events_idles/mc_events.rpy:791
translate french gg_first_morning_kitchen_52906127:

    # gg_chat "Хочу понять, как здесь живут"
    gg_chat "Je veux comprendre comment ils vivent ici"

# game/characters_events_idles/mc_events.rpy:792
translate french gg_first_morning_kitchen_1b6b16db:

    # gg_chat "Как всё устроено"
    gg_chat "Comment tout fonctionne"

# game/characters_events_idles/mc_events.rpy:795
translate french gg_first_morning_kitchen_681dfe7b:

    # gg_chat "Это теперь мой новый дом"
    gg_chat "C'est maintenant ma nouvelle maison"

# game/characters_events_idles/mc_events.rpy:810
translate french gg_first_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "Oh"

# game/characters_events_idles/mc_events.rpy:812
translate french gg_first_day_bathroom_7b463844:

    # Sonya "Прости, я не думала, что ты сейчас зайдешь"
    Sonya "Désolé, je ne pensais pas que tu viendrais maintenant"

# game/characters_events_idles/mc_events.rpy:813
translate french gg_first_day_bathroom_32835352:

    # Sonya "Я хотела прибраться"
    Sonya "je voulais nettoyer"

# game/characters_events_idles/mc_events.rpy:817
translate french gg_first_day_bathroom_826d81cb:

    # Sonya "Я не мешаю тебе?"
    Sonya "Je vous dérange?"

# game/characters_events_idles/mc_events.rpy:819
translate french gg_first_day_bathroom_c012b14a:

    # Sonya "Я сейчас закончу"
    Sonya "je vais finir maintenant"

# game/characters_events_idles/mc_events.rpy:821
translate french gg_first_day_bathroom_1c4c4c5a:

    # gg "Нет, всё нормально"
    gg "Non, ça va"

# game/characters_events_idles/mc_events.rpy:822
translate french gg_first_day_bathroom_bf898b26:

    # gg "Я подожду"
    gg "J'attendrai"

# game/characters_events_idles/mc_events.rpy:824
translate french gg_first_day_bathroom_1452bdd4:

    # gg "Если тебе нужна помощь — скажи"
    gg "Si tu as besoin d'aide, dis-le-moi"

# game/characters_events_idles/mc_events.rpy:826
translate french gg_first_day_bathroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "C'est vrai ?"

# game/characters_events_idles/mc_events.rpy:828
translate french gg_first_day_bathroom_6e75581c:

    # Sonya "Ты не обязан, я просто"
    Sonya "Tu n'es pas obligé, je voulais juste .. ."

# game/characters_events_idles/mc_events.rpy:830
translate french gg_first_day_bathroom_bad9a3a7:

    # Sonya "Ну, если тебе не сложно"
    Sonya "Eh bien, si ça ne te dérange pas"

# game/characters_events_idles/mc_events.rpy:832
translate french gg_first_day_bathroom_506ec94d:

    # Sonya "Можешь тогда разложить вещи для стирки"
    Sonya "Tu peux alors mettre les vêtements à laver"

# game/characters_events_idles/mc_events.rpy:834
translate french gg_first_day_bathroom_1b360134:

    # Sonya "Потом сложи что уже высохло"
    Sonya "Plier ensuite ce qui est déjà sec"

# game/characters_events_idles/mc_events.rpy:836
translate french gg_first_day_bathroom_cc2e9c27:

    # Sonya "Отнесу я сама"
    Sonya "je le porterai moi-même"

# game/characters_events_idles/mc_events.rpy:856
translate french gg_first_day_bathroom_fb297fd7:

    # gg_chat "Как будто мы тут давно живём"
    gg_chat "C'est comme si nous vivions ici depuis longtemps"

# game/characters_events_idles/mc_events.rpy:858
translate french gg_first_day_bathroom_adfa1b84:

    # Sonya "Мне чуть чуть осталось"
    Sonya "il m'en reste un peu"

# game/characters_events_idles/mc_events.rpy:860
translate french gg_first_day_bathroom_dc9b9999:

    # Sonya "Обычно в доме только я убираюсь"
    Sonya "Je suis généralement la seule à nettoyer la maison."

# game/characters_events_idles/mc_events.rpy:864
translate french gg_first_day_bathroom_09b9d111:

    # Sonya "А . . ."
    Sonya "AH . . ."

# game/characters_events_idles/mc_events.rpy:865
translate french gg_first_day_bathroom_a741acc1:

    # Sonya "Ты наверное хочешь в душ"
    Sonya "Tu veux probablement prendre une douche"

# game/characters_events_idles/mc_events.rpy:869
translate french gg_first_day_bathroom_9f7316a6:

    # Sonya "Полотенца сейчас у меня в комнате"
    Sonya "Les serviettes sont dans ma chambre maintenant"

# game/characters_events_idles/mc_events.rpy:871
translate french gg_first_day_bathroom_352fa084:

    # Sonya "Мы можем сходить туда, если хочешь"
    Sonya "On peut y aller si tu veux"

# game/characters_events_idles/mc_events.rpy:873
translate french gg_first_day_bathroom_264ee174:

    # gg "Пойдем"
    gg "Allons-y"

# game/characters_events_idles/mc_events.rpy:879
translate french gg_first_day_bathroom_a3853f22:

    # gg_chat "Как сильно поменялись комнаты"
    gg_chat "À quel point les pièces ont changé"

# game/characters_events_idles/mc_events.rpy:883
translate french gg_first_day_bathroom_1d2f5a17:

    # Sonya "Вот"
    Sonya "Ici"

# game/characters_events_idles/mc_events.rpy:885
translate french gg_first_day_bathroom_33def544:

    # Sonya "Если что, там ещё есть"
    Sonya "Si besoin, il y en a encore"

# game/characters_events_idles/mc_events.rpy:887
translate french gg_first_day_bathroom_5c20aef6:

    # Sonya "Э ну приятного купания"
    Sonya "Eh bien, bonne baignade"

# game/characters_events_idles/mc_events.rpy:889
translate french gg_first_day_bathroom_3eec94f5:

    # gg "А да спасибо"
    gg "Ah oui merci"

# game/characters_events_idles/mc_events.rpy:892
translate french gg_first_day_bathroom_b774dd45:

    # gg_chat "Оказывается, для уюта нужно совсем немного"
    gg_chat "Finalement, il ne faut pas grand-chose pour se sentir bien"

# game/characters_events_idles/mc_events.rpy:905
translate french gg_first_morning_mayaroom_ff197092:

    # Maya "Барси!"
    Maya "Barsi!"

# game/characters_events_idles/mc_events.rpy:907
translate french gg_first_morning_mayaroom_de472ed4:

    # Maya "Барсик!"
    Maya "Barsik!"

# game/characters_events_idles/mc_events.rpy:910
translate french gg_first_morning_mayaroom_a4a7667e:

    # gg_chat "Что-то случилось?"
    gg_chat "Est-ce qu'il s'est passé quelque chose ?"

# game/characters_events_idles/mc_events.rpy:914
translate french gg_first_morning_mayaroom_6f63b0d7:

    # gg_chat "Лучше ей не мешать . . ."
    gg_chat "Il vaut mieux ne pas la déranger. . ."

# game/characters_events_idles/mc_events.rpy:920
translate french gg_first_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "Attend"

# game/characters_events_idles/mc_events.rpy:922
translate french gg_first_morning_mayaroom_857efa08:

    # Maya "Ты кота не видел?"
    Maya "as-tu vu le chat ?"

# game/characters_events_idles/mc_events.rpy:924
translate french gg_first_morning_mayaroom_270e2f8c:

    # gg "Нет"
    gg "Non"

# game/characters_events_idles/mc_events.rpy:926
translate french gg_first_morning_mayaroom_def6171d:

    # gg "Но могу помочь"
    gg "Mais je peux aider"

# game/characters_events_idles/mc_events.rpy:928
translate french gg_first_morning_mayaroom_359a75af:

    # Maya "Твоя помощь мне не нужна"
    Maya "je n'ai pas besoin de ton aide"

# game/characters_events_idles/mc_events.rpy:930
translate french gg_first_morning_mayaroom_785a8355:

    # Maya "Хотя если будешь молчать — помогай"
    Maya "Mais si tu restes silencieux, aide"

# game/characters_events_idles/mc_events.rpy:932
translate french gg_first_morning_mayaroom_929a1d4f:

    # gg_chat "Это так на помощь соглашаются"
    gg_chat "C'est ainsi qu'ils acceptent d'aider"

# game/characters_events_idles/mc_events.rpy:937
translate french gg_first_morning_mayaroom_bb6b3842:

    # Maya "Ты где барсииик"
    Maya "Où es-tu, chérie ?"

# game/characters_events_idles/mc_events.rpy:946
translate french gg_first_morning_mayaroom_32a24542:

    # gg_chat "Нашёлся"
    gg_chat "Trouvé"

# game/characters_events_idles/mc_events.rpy:950
translate french gg_first_morning_mayaroom_954eaf61:

    # gg_chat "Главное не разбудить"
    gg_chat "L'essentiel est de ne pas le réveiller"

# game/characters_events_idles/mc_events.rpy:952
translate french gg_first_morning_mayaroom_79aa0dff:

    # Maya "Всё хорошо"
    Maya "Tout va bien"

# game/characters_events_idles/mc_events.rpy:954
translate french gg_first_morning_mayaroom_831f5c17:

    # Maya "Я здесь барсик"
    Maya "Tiens, Barsik, rentre dans ta chambre"

# game/characters_events_idles/mc_events.rpy:958
translate french gg_first_morning_mayaroom_f0949f54:

    # Maya "Ты меня напугал"
    Maya "Tu m'as fait peur"

# game/characters_events_idles/mc_events.rpy:959
translate french gg_first_morning_mayaroom_a8d4beb2:

    # Maya "Глупый"
    Maya "Idiot"

# game/characters_events_idles/mc_events.rpy:962
translate french gg_first_morning_mayaroom_ddc18c67:

    # gg_chat "Она не совсем такая, какой кажется"
    gg_chat "Elle n'est pas tout à fait ce qu'elle paraît"

# game/characters_events_idles/mc_events.rpy:974
translate french kate_day_kitchen_60e92ce9:

    # Kate "Так, где у вас тут кофе прячут?"
    Kate "Alors, où caches-tu ton café ?"

# game/characters_events_idles/mc_events.rpy:975
translate french kate_day_kitchen_077e1944:

    # gg "Ты кто вообще?"
    gg "Qui es-tu de toute façon ?"

# game/characters_events_idles/mc_events.rpy:977
translate french kate_day_kitchen_67f355f0:

    # Kate "О Привет"
    Kate "Ah bonjour"

# game/characters_events_idles/mc_events.rpy:980
translate french kate_day_kitchen_d81632e3:

    # Kate "Я Кейт"
    Kate "je m'appelle Kate"

# game/characters_events_idles/mc_events.rpy:982
translate french kate_day_kitchen_1e97df81:

    # Kate "Не пугайся, я не вор"
    Kate "N'aie pas peur, je ne suis pas une voleuse"

# game/characters_events_idles/mc_events.rpy:983
translate french kate_day_kitchen_b0950cd9:

    # Kate "Просто кофе мне жизненно необходим"
    Kate "j'ai juste besoin de café"

# game/characters_events_idles/mc_events.rpy:985
translate french kate_day_kitchen_e063e635:

    # gg "Меня [povname] зовут"
    gg "Je m'appelle [povname]"

# game/characters_events_idles/mc_events.rpy:986
translate french kate_day_kitchen_f0d355f9:

    # gg "Растворимый прям тут"
    gg "Du café soluble, juste ici"

# game/characters_events_idles/mc_events.rpy:988
translate french kate_day_kitchen_f2fdab56:

    # Kate "О, спаситель!"
    Kate "Ô sauveur !"

# game/characters_events_idles/mc_events.rpy:990
translate french kate_day_kitchen_fe62b24d:

    # Kate "Значит, ты и есть тот самый парень, который тут появился недавно?"
    Kate "Alors, tu es le même gars qui est apparu ici récemment ?"

# game/characters_events_idles/mc_events.rpy:992
translate french kate_day_kitchen_ce5edae1:

    # gg "Судя по слухам — да, я"
    gg "D'après les rumeurs - oui, je le suis"

# game/characters_events_idles/mc_events.rpy:994
translate french kate_day_kitchen_0d1fc413:

    # Kate "Мая рассказывала"
    Kate "Maya me l'a dit"

# game/characters_events_idles/mc_events.rpy:996
translate french kate_day_kitchen_7c8bce00:

    # Kate "Живёт с Соней давно, а потом появился ты"
    Kate "Elle vit avec Sonya depuis longtemps, et puis tu es apparu"

# game/characters_events_idles/mc_events.rpy:997
translate french kate_day_kitchen_34985df3:

    # Kate "Интересная компания"
    Kate "Une compagnie intéressante"

# game/characters_events_idles/mc_events.rpy:999
translate french kate_day_kitchen_2e63aac8:

    # gg "“Интересная” — мягко сказано"
    gg "\"Intéressant\", c'est un euphémisme"

# game/characters_events_idles/mc_events.rpy:1001
translate french kate_day_kitchen_cbdc207c:

    # Kate "Серьёзно? Это растворимый?"
    Kate "Sérieusement? C'est du soluble ?"

# game/characters_events_idles/mc_events.rpy:1003
translate french kate_day_kitchen_8937f276:

    # gg "Ага"
    gg "Ouais"

# game/characters_events_idles/mc_events.rpy:1005
translate french kate_day_kitchen_5746fae5:

    # Kate "А ведь вкусно"
    Kate "Mais c'est délicieux"

# game/characters_events_idles/mc_events.rpy:1006
translate french kate_day_kitchen_796538ef:

    # Kate "Обычно от растворимого хочется заплакать"
    Kate "Habituellement, l'instantané donne envie de pleurer"

# game/characters_events_idles/mc_events.rpy:1008
translate french kate_day_kitchen_3e92b413:

    # gg "Значит, я талантливый бариста"
    gg "Je suis donc un barista talentueux"

# game/characters_events_idles/mc_events.rpy:1009
translate french kate_day_kitchen_961ab98b:

    # Kate "Или тебе повезло"
    Kate "Ou tu as juste de la chance"

# game/characters_events_idles/mc_events.rpy:1011
translate french kate_day_kitchen_394c86a9:

    # Kate "Ну что, рассказывай, кто ты такой"
    Kate "Eh bien, dis-moi qui tu es"

# game/characters_events_idles/mc_events.rpy:1013
translate french kate_day_kitchen_517a6831:

    # gg "Обычно начинают с “как дела?”"
    gg "Habituellement, On commence par « comment vas-tu ? »"

# game/characters_events_idles/mc_events.rpy:1015
translate french kate_day_kitchen_bb3d7bf1:

    # Kate "Это скучно"
    Kate "C'est ennuyeux"

# game/characters_events_idles/mc_events.rpy:1017
translate french kate_day_kitchen_01155acc:

    # Kate "Я сразу к сути. Ты кто: сосед, ухажёр, постоялец или просто [povname]"
    Kate "J'irai droit au but. Qui es-tu: un voisin, un petit ami, un invité ou tout simplement [povname]"

# game/characters_events_idles/mc_events.rpy:1019
translate french kate_day_kitchen_4333516e:

    # gg "Пусть будет просто [povname]"
    gg "Je suis simplement [povname]"

# game/characters_events_idles/mc_events.rpy:1021
translate french kate_day_kitchen_95199003:

    # Kate "Значит, загадочный. Ладно, оставим интригу"
    Kate "C'est donc mystérieux. Bon, laissons l'intrigue"

# game/characters_events_idles/mc_events.rpy:1024
translate french kate_day_kitchen_eb2b6424:

    # Kate "Тут уютно"
    Kate "C'est confortable ici"

# game/characters_events_idles/mc_events.rpy:1025
translate french kate_day_kitchen_ad0e7b9c:

    # Kate "Не думала, что Мая вообще когда-то научится жить без хаоса"
    Kate "Je ne pensais pas que Maya apprendrait un jour à vivre sans chaos"

# game/characters_events_idles/mc_events.rpy:1029
translate french kate_day_kitchen_1e4f23c6:

    # Maya "Кейт! Ты тут"
    Maya "Kate ! T'es là"

# game/characters_events_idles/mc_events.rpy:1030
translate french kate_day_kitchen_ecdba904:

    # Maya "Я же сказала подожди меня!"
    Maya "Je t'avais dis de m'attendre !"

# game/characters_events_idles/mc_events.rpy:1032
translate french kate_day_kitchen_b6371751:

    # Maya "Ага, ты уже познакомилась с этим балбесом"
    Maya "Ah oui, tu as déjà rencontré ce cancre"

# game/characters_events_idles/mc_events.rpy:1034
translate french kate_day_kitchen_9c22616a:

    # Kate "Да! И кофе у него отличный, между прочим"
    Kate "Oui! Et son café est excellent, d'ailleurs."

# game/characters_events_idles/mc_events.rpy:1036
translate french kate_day_kitchen_08bc7129:

    # Maya "Хвалить не вздумай, зазнается. Нам пора"
    Maya "Ne penses même pas aux éloges, il est arrogant. Il est temps pour nous"

# game/characters_events_idles/mc_events.rpy:1038
translate french kate_day_kitchen_8ab29297:

    # Kate "Спасибо за кофе, бариста"
    Kate "Merci pour le café, barista"

# game/characters_events_idles/mc_events.rpy:1039
translate french kate_day_kitchen_11705c38:

    # Kate "Ладно. Ещё увидимся"
    Kate "BON. On se reverra"

translate french strings:

    # game/characters_events_idles/mc_events.rpy:361
    old "Послать нахуй"
    new "Va te faire foutre"

    # game/characters_events_idles/mc_events.rpy:363
    old "Молча уйти"
    new "Partir en silence"

# TODO: Translation updated at 2026-01-26 03:22

# game/characters_events_idles/mc_events.rpy:295
translate french gg_intro_4402cfd9:

    # gg_chat "Я отвечу попозже бабушка"
    gg_chat "je répondrai plus tard grand-mère"

# game/characters_events_idles/mc_events.rpy:668
translate french gg_intro_0997da9e:

    # Maya "Это мы с Соней решим!"
    Maya "Sonya et moi en déciderons !"

# game/characters_events_idles/mc_events.rpy:670
translate french gg_intro_6619e154:

    # Maya "{sc}{size=*1.5}СОНЯ{/sc}" with hpunch
    Maya "{sc}{size=*1.5}SONYA{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:805
translate french gg_intro_fadd240e:

    # "Ночью можно отдохнуть — нажми на кровать, чтобы начать новый день"
    "Vous pouvez vous reposer la nuit - cliquez sur le lit pour commencer une nouvelle journée"

# game/characters_events_idles/mc_events.rpy:895
translate french gg_first_day_bathroom_6c8604ba:

    # Sonya "Я не думала, что ты сейчас зайдешь"
    Sonya "Je ne pensais pas que tu viendrais maintenant"

# game/characters_events_idles/mc_events.rpy:896
translate french gg_first_day_bathroom_15c3e23b:

    # Sonya "Хотела прибраться"
    Sonya "je voulais nettoyer"

# game/characters_events_idles/mc_events.rpy:900
translate french gg_first_day_bathroom_94ef9943:

    # Sonya "Ты хотел в душ?"
    Sonya "Tu voulais prendre une douche ?"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/mc_events.rpy:287
translate french gg_intro_21dc756d:

    # gg_chat "Чёрт, я опаздываю"
    gg_chat "Merde, je suis en retard"

# game/characters_events_idles/mc_events.rpy:295
translate french gg_intro_01ac9e1d:

    # gg_chat "Я отвечу попозже, бабушка"
    gg_chat "Je répondrai plus tard, grand-mère"

# game/characters_events_idles/mc_events.rpy:325
translate french gg_intro_d5122bca:

    # Assistant "И напомню: если продолжишь, {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "Et laissez-moi vous rappeler : si vous continuez, {w}la conversation sur une réduction de salaire n'est déjà qu'une question de temps."

# game/characters_events_idles/mc_events.rpy:361
translate french gg_intro_4e8253d3:

    # gg_chat "Сколько ни работай, этому нет конца"
    gg_chat "Peu importe combien vous travaillez, il n'y a pas de fin"

# game/characters_events_idles/mc_events.rpy:393
translate french gg_intro_eb3e3aa2:

    # gg_chat "Да пошло оно все"
    gg_chat "J'emmerde tout"

# game/characters_events_idles/mc_events.rpy:409
translate french gg_intro_187f7fc4:

    # Director "Ты вообще что делаешь"
    Director "Qu'est-ce que tu fais même"

# game/characters_events_idles/mc_events.rpy:500
translate french gg_intro_bb6264b0:

    # gg_chat "Все, кого я вижу, со мной здороваются"
    gg_chat "Tous ceux que je vois me disent bonjour"

# game/characters_events_idles/mc_events.rpy:520
translate french gg_intro_2c4c4cb8:

    # UnknownGirl "Если что-то нужно будет, спрашивай помощь у любого"
    UnknownGirl "Si tu as besoin de quelque chose, demande de l'aide à quelqu'un"

# game/characters_events_idles/mc_events.rpy:524
translate french gg_intro_f654fdee:

    # gg "Хорошо и Вам отличного дня"
    gg "ok, passe une bonne journée à toi aussi"

# game/characters_events_idles/mc_events.rpy:527
translate french gg_intro_87051a07:

    # gg_chat "Бабушка, похоже, говорила правду о людях здесь"
    gg_chat "Grand-mère semblait dire la vérité sur les gens d'ici"

# game/characters_events_idles/mc_events.rpy:546
translate french gg_intro_95240a3b:

    # gg_chat "Да, дом поменялся"
    gg_chat "Oui, la maison a changé"

# game/characters_events_idles/mc_events.rpy:556
translate french gg_intro_e94b0047:

    # gg_chat "Здесь кто-то есть?"
    gg_chat "Y a-t-il quelqu'un ici ?"

# game/characters_events_idles/mc_events.rpy:596
translate french gg_intro_eee07a35:

    # gg "Стой, подожди"
    gg "Attends, attends"

# game/characters_events_idles/mc_events.rpy:604
translate french gg_intro_ca7cead7:

    # Maya "Что-то я такого внука никогда здесь не видела"
    Maya "Je n'ai jamais vu un tel petit-fils ici"

# game/characters_events_idles/mc_events.rpy:650
translate french gg_intro_f08474d4:

    # Maya "Мои цветочки любимые. Они остались"
    Maya "Mes fleurs préférées. Ils sont restés"

# game/characters_events_idles/mc_events.rpy:659
translate french gg_intro_90f291ff:

    # Maya "Боже, ладно"
    Maya "Dieu, d'accord"

# game/characters_events_idles/mc_events.rpy:660
translate french gg_intro_7b0b2a04:

    # Maya "Похоже на правду"
    Maya "On dirait la vérité"

# game/characters_events_idles/mc_events.rpy:676
translate french gg_intro_1b04d04b:

    # Maya "Слушай, если ты хоть что-то сделаешь"
    Maya "Écoute, si tu fais quelque chose"

# game/characters_events_idles/mc_events.rpy:734
translate french gg_intro_5834166b:

    # Sonya "Нет-нет, всё нормально"
    Sonya "Non, non, tout va bien"

# game/characters_events_idles/mc_events.rpy:740
translate french gg_intro_05ceb2ee:

    # Sonya "Я прочла письмо Линды"
    Sonya "J'ai lu la lettre de Linda"

# game/characters_events_idles/mc_events.rpy:744
translate french gg_intro_c73d3bb7:

    # Sonya "Она всегда нас так называла"
    Sonya "Elle nous a toujours appelé comme ça"

# game/characters_events_idles/mc_events.rpy:760
translate french gg_intro_d2363caa:

    # Sonya "Это место для нас стало родным"
    Sonya "Cet endroit est devenu notre maison"

# game/characters_events_idles/mc_events.rpy:764
translate french gg_intro_79c61e5f:

    # Sonya "Говорила, что ты хороший, по крайней мере в детстве"
    Sonya "Elle a dit que tu étais bon, du moins quand tu étais enfant."

# game/characters_events_idles/mc_events.rpy:774
translate french gg_intro_7f8fcf55:

    # Sonya "Ну, какой у тебя дальше план?"
    Sonya "Eh bien, quel est ton prochain plan ?"

# game/characters_events_idles/mc_events.rpy:787
translate french gg_intro_d7903980:

    # Sonya "Если захочешь мы еще поговорим"
    Sonya "Si tu veux, nous pouvons reparler"

# game/characters_events_idles/mc_events.rpy:789
translate french gg_intro_7d278239:

    # Sonya "А пока ты можешь лечь в зале"
    Sonya "En attendant, tu peux t'allonger dans le couloir"

# game/characters_events_idles/mc_events.rpy:793
translate french gg_intro_41b7f3b0:

    # gg "Да, хорошо"
    gg "Oui, d'accord"

# game/characters_events_idles/mc_events.rpy:835
translate french gg_first_morning_5b301338:

    # gg_chat "Эх, как же мне не хватало свободы"
    gg_chat "Oh, comme la liberté m'a manqué"

# game/characters_events_idles/mc_events.rpy:836
translate french gg_first_morning_146ca63e:

    # gg_chat "Кажется, я останусь"
    gg_chat "Il semble que je vais rester"

# game/characters_events_idles/mc_events.rpy:839
translate french gg_first_morning_9cc6e0e8:

    # gg_chat "Спасибо, похоже, я нашёл то, чего мне не хватало"
    gg_chat "Merci, on dirait que j'ai trouvé ce qui me manquait"

# game/characters_events_idles/mc_events.rpy:917
translate french gg_first_day_bathroom_c3b33eb8:

    # Sonya "Потом сложи, что уже высохло"
    Sonya "Pliez ensuite ce qui est déjà sec"

# game/characters_events_idles/mc_events.rpy:970
translate french gg_first_day_bathroom_887d1e72:

    # Sonya "Ээ... нуу приятного купания"
    Sonya "Euh... eh bien, bonne baignade"

# game/characters_events_idles/mc_events.rpy:972
translate french gg_first_day_bathroom_997383a9:

    # gg "А, да, спасибо"
    gg "Ah oui, merci"

# game/characters_events_idles/mc_events.rpy:1018
translate french gg_first_morning_mayaroom_123ee93a:

    # Maya "Хотя, если будешь молчать — помогай"
    Maya "Mais si vous restez silencieux, aidez-moi"

