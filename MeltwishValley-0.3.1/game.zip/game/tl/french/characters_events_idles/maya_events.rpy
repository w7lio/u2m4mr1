﻿# TODO: Translation updated at 2026-01-21 13:15

# game/characters_events_idles/maya_events.rpy:24
translate french maya_scene1_evening_myroom_ef5d982a:

    # Maya "Да ты издеваешься"
    Maya "C'est une plaisanterie j'espère"

# game/characters_events_idles/maya_events.rpy:37
translate french maya_scene1_evening_myroom_905d33c0:

    # Maya "Где они блин"
    Maya "Où diable sont-elles"

# game/characters_events_idles/maya_events.rpy:50
translate french maya_scene1_evening_myroom_bd666787:

    # Maya "Тьфу"
    Maya "Pouah"

# game/characters_events_idles/maya_events.rpy:56
translate french maya_scene1_evening_myroom_481be515:

    # Maya "Чё смотришь?"
    Maya "Qu'est-ce que tu regardes ?"

# game/characters_events_idles/maya_events.rpy:57
translate french maya_scene1_evening_myroom_2ca818a6:

    # gg "Проверь плюс и минус"
    gg "Vérifies le plus et le moins"

# game/characters_events_idles/maya_events.rpy:58
translate french maya_scene1_evening_myroom_4bbab9f1:

    # Maya "Проверяла"
    Maya "j'ai vérifié"

# game/characters_events_idles/maya_events.rpy:94
translate french maya_scene2_day_mayaroom_5bb53a51:

    # Maya "Кто там?"
    Maya "Qui est là ?"

# game/characters_events_idles/maya_events.rpy:96
translate french maya_scene2_day_mayaroom_14a18d19:

    # gg "Это я. Можно зайти по делу?"
    gg "C'est moi. Puis-je venir pour parler ?"

# game/characters_events_idles/maya_events.rpy:97
translate french maya_scene2_day_mayaroom_1c4734b1:

    # Maya "Входи"
    Maya "Entres"

# game/characters_events_idles/maya_events.rpy:105
translate french maya_scene2_day_mayaroom_ab7fedad:

    # gg "Музыку слушаешь?"
    gg "Écoutes-tu de la musique ?"

# game/characters_events_idles/maya_events.rpy:107
translate french maya_scene2_day_mayaroom_3884c669:

    # Maya "Нет, для соседей включила"
    Maya "Non, je l'ai allumé pour les voisins"

# game/characters_events_idles/maya_events.rpy:111
translate french maya_scene2_day_mayaroom_837eef0f:

    # gg "Я решил, что останусь тут"
    gg "J'ai décidé que je resterais ici"

# game/characters_events_idles/maya_events.rpy:113
translate french maya_scene2_day_mayaroom_95020588:

    # gg "Буду жить здесь"
    gg "je vivrai ici"

# game/characters_events_idles/maya_events.rpy:115
translate french maya_scene2_day_mayaroom_bca52f7e:

    # Maya "Ну"
    Maya "Bien"

# game/characters_events_idles/maya_events.rpy:117
translate french maya_scene2_day_mayaroom_705e10f4:

    # Maya "Соболезную"
    Maya "Mes condoléances"

# game/characters_events_idles/maya_events.rpy:125
translate french maya_scene2_day_mayaroom_27c60573:

    # Maya "Эй"
    Maya "Hé"

# game/characters_events_idles/maya_events.rpy:127
translate french maya_scene2_day_mayaroom_40785e40:

    # Maya "Дальше не надо"
    Maya "Pas besoin d'autre chose"

# game/characters_events_idles/maya_events.rpy:129
translate french maya_scene2_day_mayaroom_5f49e73a:

    # gg "Я просто хотел"
    gg "je voulais juste"

# game/characters_events_idles/maya_events.rpy:131
translate french maya_scene2_day_mayaroom_16e0a365:

    # Maya "Я всё услышала"
    Maya "j'ai tout entendu"

# game/characters_events_idles/maya_events.rpy:133
translate french maya_scene2_day_mayaroom_c48134de:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "Je m'en fiche que tu vives ici"

# game/characters_events_idles/maya_events.rpy:135
translate french maya_scene2_day_mayaroom_df1954ea:

    # Maya "Честно"
    Maya "Honnêtement"

# game/characters_events_idles/maya_events.rpy:139
translate french maya_scene2_day_mayaroom_df3a4321:

    # Maya "Но давай без этого"
    Maya "Mais allons-y sans"

# game/characters_events_idles/maya_events.rpy:141
translate french maya_scene2_day_mayaroom_e6c85abf:

    # gg "Без чего?"
    gg "Sans quoi ?"

# game/characters_events_idles/maya_events.rpy:143
translate french maya_scene2_day_mayaroom_d4ddd213:

    # Maya "Без контроля"
    Maya "Aucun contrôle"

# game/characters_events_idles/maya_events.rpy:145
translate french maya_scene2_day_mayaroom_bc54c15e:

    # Maya "Без «я помогу»"
    Maya "Sans \"je vais aider\""

# game/characters_events_idles/maya_events.rpy:147
translate french maya_scene2_day_mayaroom_7a220c2f:

    # gg "Я не про контроль"
    gg "je ne parle pas de contrôle"

# game/characters_events_idles/maya_events.rpy:148
translate french maya_scene2_day_mayaroom_dabe88df:

    # gg "Если по дому что-то"
    gg "S'il y a quelque chose dans la maison"

# game/characters_events_idles/maya_events.rpy:152
translate french maya_scene2_day_mayaroom_723b85d3:

    # Maya "Мне не нужна опека"
    Maya "je n'ai pas besoin de tutelle"

# game/characters_events_idles/maya_events.rpy:154
translate french maya_scene2_day_mayaroom_cad2c7d3:

    # gg "Я не это имел в виду"
    gg "Ce n'est pas ce que je voulais dire"

# game/characters_events_idles/maya_events.rpy:156
translate french maya_scene2_day_mayaroom_e9decfdb:

    # Maya "А звучит именно так"
    Maya "Et c'est exactement à ça que ça ressemble"

# game/characters_events_idles/maya_events.rpy:158
translate french maya_scene2_day_mayaroom_c48134de_1:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "Je m'en fiche que tu vives ici"

# game/characters_events_idles/maya_events.rpy:160
translate french maya_scene2_day_mayaroom_3e5d6dd4:

    # Maya "Просто"
    Maya "Juste"

# game/characters_events_idles/maya_events.rpy:162
translate french maya_scene2_day_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "Ne t’en mêle pas"

# game/characters_events_idles/maya_events.rpy:164
translate french maya_scene2_day_mayaroom_9727ea24:

    # Maya "В личное"
    Maya "C'est privé"

# game/characters_events_idles/maya_events.rpy:166
translate french maya_scene2_day_mayaroom_44696bee:

    # gg "Я понял"
    gg "Je comprends"

# game/characters_events_idles/maya_events.rpy:168
translate french maya_scene2_day_mayaroom_97fa7b2b:

    # Maya "И дверь закрывай"
    Maya "Et ferme la porte"

# game/characters_events_idles/maya_events.rpy:170
translate french maya_scene2_day_mayaroom_367b11d8:

    # Maya "Я не фанат"
    Maya "je ne suis pas fan"

# game/characters_events_idles/maya_events.rpy:171
translate french maya_scene2_day_mayaroom_5e882c77:

    # Maya "Открытых пространств"
    Maya "Des espaces ouverts"

# game/characters_events_idles/maya_events.rpy:198
translate french maya_scene3_evening_kitchen_9a8b0be2:

    # gg "Привет"
    gg "Bonjour"

# game/characters_events_idles/maya_events.rpy:211
translate french maya_scene3_evening_kitchen_a356674e:

    # gg "Тебе еще кофе принести?"
    gg "Dois-je t'apporter encore du café ?"

# game/characters_events_idles/maya_events.rpy:213
translate french maya_scene3_evening_kitchen_9a5dd35b:

    # Maya "Нет"
    Maya "Non"

# game/characters_events_idles/maya_events.rpy:225
translate french maya_scene3_evening_kitchen_00c41c60:

    # Maya "Не . . ."
    Maya "Pas . . ."

# game/characters_events_idles/maya_events.rpy:227
translate french maya_scene3_evening_kitchen_059eb6da:

    # gg "Что?"
    gg "Quoi?"

# game/characters_events_idles/maya_events.rpy:229
translate french maya_scene3_evening_kitchen_5c02f51f:

    # Maya "Ты вообще"
    Maya "Toi. . . franchement"

# game/characters_events_idles/maya_events.rpy:231
translate french maya_scene3_evening_kitchen_c954c369:

    # Maya "Ты зачем так близко?"
    ### don't appear
    Maya "Pourquoi es-tu si proche ?"

# game/characters_events_idles/maya_events.rpy:233
translate french maya_scene3_evening_kitchen_7de3a2ef:

    # gg "Я просто"
    gg "Je. . ."

# game/characters_events_idles/maya_events.rpy:235
translate french maya_scene3_evening_kitchen_25f0ffea:

    # Maya "Я сказала, не надо"
    Maya "J'ai dit pas besoin"

# game/characters_events_idles/maya_events.rpy:237
translate french maya_scene3_evening_kitchen_91d73b20:

    # Maya "И не звала"
    Maya "Et je n'ai pas appelé"

# game/characters_events_idles/maya_events.rpy:241
translate french maya_scene3_evening_kitchen_e10a0eab:

    # Maya "Мне нужно было просто кофе"
    Maya "J'avais juste besoin de café"

# game/characters_events_idles/maya_events.rpy:243
translate french maya_scene3_evening_kitchen_a41fbef3:

    # gg "Подожди"
    gg "Attends"

# game/characters_events_idles/maya_events.rpy:245
translate french maya_scene3_evening_kitchen_c8225194:

    # Maya "Не сейчас"
    Maya "Pas maintenant"

# game/characters_events_idles/maya_events.rpy:252
translate french maya_scene3_evening_kitchen_0d9a221f:

    # gg_chat "Как бы мне с ней поговорить"
    gg_chat "Comment puis-je lui parler ?"

# game/characters_events_idles/maya_events.rpy:263
translate french maya_scene4_morning_mayaroom_d3734f64:

    # Maya "Да что ж"
    Maya "tant pis"

# game/characters_events_idles/maya_events.rpy:265
translate french maya_scene4_morning_mayaroom_fa8ea266:

    # Maya "Ну давай же"
    Maya "Allez vas-y"

# game/characters_events_idles/maya_events.rpy:271
translate french maya_scene4_morning_mayaroom_d944481b:

    # gg "Опять воюешь с техникой?"
    gg "Es-tu encore aux prises avec la technologie ?"

# game/characters_events_idles/maya_events.rpy:273
translate french maya_scene4_morning_mayaroom_b6f44dea:

    # Maya "Все работало час назад"
    Maya "Tout fonctionnait il y a une heure"

# game/characters_events_idles/maya_events.rpy:275
translate french maya_scene4_morning_mayaroom_743f87c9:

    # gg "На вид, пауза — у меня была похожая проблема"
    gg "Cela ressemble à une pause - j'ai eu un problème similaire"

# game/characters_events_idles/maya_events.rpy:277
translate french maya_scene4_morning_mayaroom_5b9f31c5:

    # Maya "Конечно. У нашего местного игромана, разумеется, был подобный опыт"
    Maya "Certainement. Notre accro au jeu local a bien sûr vécu une expérience similaire."

# game/characters_events_idles/maya_events.rpy:279
translate french maya_scene4_morning_mayaroom_d67e684e:

    # gg "Это решается проще, чем кажется"
    gg "C'est plus facile à résoudre qu'il n'y paraît"

# game/characters_events_idles/maya_events.rpy:281
translate french maya_scene4_morning_mayaroom_6ac6687a:

    # Maya "Я разберусь"
    Maya "je vais le découvrir"

# game/characters_events_idles/maya_events.rpy:285
translate french maya_scene4_morning_mayaroom_ef21c62b:

    # Maya "Ладно поскольку ты уже встал тут в позу спасителя"
    Maya "D'accord, puisque tu as déjà pris la pose du sauveur ici"

# game/characters_events_idles/maya_events.rpy:287
translate french maya_scene4_morning_mayaroom_e4eef199:

    # Maya "Смотри"
    Maya "Regardes"

# game/characters_events_idles/maya_events.rpy:289
translate french maya_scene4_morning_mayaroom_b05b1e64:

    # Maya "Но если сломаешь новый купишь"
    Maya "Mais si tu le casse, achète-en un nouveau"

# game/characters_events_idles/maya_events.rpy:291
translate french maya_scene4_morning_mayaroom_2406a76f:

    # gg_chat "Так посмотрим"
    gg_chat "Alors voyons"

# game/characters_events_idles/maya_events.rpy:293
translate french maya_scene4_morning_mayaroom_3eccec99:

    # Maya "Только давай без «я же говорил»"
    Maya "Ne dis pas \"je te l'avais bien dit\""

# game/characters_events_idles/maya_events.rpy:295
translate french maya_scene4_morning_mayaroom_edca7a30:

    # gg "Хорошо Не собирался"
    gg "D'accord, je n'avais pas l'intention de le faire"

# game/characters_events_idles/maya_events.rpy:300
translate french maya_scene4_morning_mayaroom_33712776:

    # Maya "Главное делай вид, что понимаешь"
    Maya "L'essentiel est de faire semblant de comprendre"

# game/characters_events_idles/maya_events.rpy:306
translate french maya_scene4_morning_mayaroom_726d3183:

    # Maya "Ты что сделал?"
    Maya "Qu'est-ce que tu as fait?"

# game/characters_events_idles/maya_events.rpy:309
translate french maya_scene4_morning_mayaroom_5de5e399:

    # Maya "Показывай"
    Maya "Montre-moi"

# game/characters_events_idles/maya_events.rpy:311
translate french maya_scene4_morning_mayaroom_4572bfad:

    # Maya "Я уже готовлюсь к разочарованию"
    Maya "Je me prépare déjà à la déception"

# game/characters_events_idles/maya_events.rpy:313
translate french maya_scene4_morning_mayaroom_6c571b22:

    # gg "Пока ничего критичного"
    gg "Rien de critique pour l'instant"

# game/characters_events_idles/maya_events.rpy:315
translate french maya_scene4_morning_mayaroom_eab0c0bf:

    # Maya "Угу"
    Maya "Oui"

# game/characters_events_idles/maya_events.rpy:319
translate french maya_scene4_morning_mayaroom_4506bcc5:

    # Maya "Эй!"
    Maya "Hé!"

# game/characters_events_idles/maya_events.rpy:321
translate french maya_scene4_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "Stop"

# game/characters_events_idles/maya_events.rpy:323
translate french maya_scene4_morning_mayaroom_5144b708:

    # gg "Что"
    gg "Quoi"

# game/characters_events_idles/maya_events.rpy:325
translate french maya_scene4_morning_mayaroom_cfa517d6:

    # Maya "Не надо ко мне лезть"
    Maya "Ne viens pas vers moi"

# game/characters_events_idles/maya_events.rpy:327
translate french maya_scene4_morning_mayaroom_1400ea9e:

    # gg "Ты сама"
    gg "C’est toi qui est venue"

# game/characters_events_idles/maya_events.rpy:329
translate french maya_scene4_morning_mayaroom_fd37247c:

    # Maya "Цыц"
    Maya "Chut"

# game/characters_events_idles/maya_events.rpy:333
translate french maya_scene4_morning_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "Oublie ça"

# game/characters_events_idles/maya_events.rpy:337
translate french maya_scene4_morning_mayaroom_d09026b0:

    # Maya "Уже не важно"
    Maya "Cela n'a plus d'importance"

# game/characters_events_idles/maya_events.rpy:339
translate french maya_scene4_morning_mayaroom_98444aa5:

    # Maya "Я разберусь потом"
    Maya "je le découvrirai plus tard"

# game/characters_events_idles/maya_events.rpy:341
translate french maya_scene4_morning_mayaroom_d2acc454:

    # gg "Я же просто"
    gg "je suis juste"

# game/characters_events_idles/maya_events.rpy:343
translate french maya_scene4_morning_mayaroom_e0da4bdd:

    # Maya "Я сказала потом"
    Maya "J'ai dit plus tard"

# game/characters_events_idles/maya_events.rpy:349
translate french maya_scene4_morning_mayaroom_d821f777:

    # gg_chat "Нужно дать ей время"
    gg_chat "Je devrai lui donner du temps"

# game/characters_events_idles/maya_events.rpy:360
translate french maya_scene5_night_mayaroom_63a0d7ed:

    # gg "Я зайду"
    gg "J'entre"

# game/characters_events_idles/maya_events.rpy:364
translate french maya_scene5_night_mayaroom_6c5edc69:

    # gg "Слушай . . ."
    gg "Écoutes . . ."

# game/characters_events_idles/maya_events.rpy:366
translate french maya_scene5_night_mayaroom_68ee26d9:

    # gg "Я хочу понять"
    gg "je veux comprendre"

# game/characters_events_idles/maya_events.rpy:368
translate french maya_scene5_night_mayaroom_bc1e3bb5:

    # gg "Ты всё время"
    gg "Toi tout le temps"

# game/characters_events_idles/maya_events.rpy:369
translate french maya_scene5_night_mayaroom_024d1c74:

    # gg "Отталкиваешь"
    gg "Tu repousses"

# game/characters_events_idles/maya_events.rpy:370
translate french maya_scene5_night_mayaroom_8f03bb39:

    # gg "Резко"
    gg "Brusquement"

# game/characters_events_idles/maya_events.rpy:372
translate french maya_scene5_night_mayaroom_e92f63ca:

    # gg "Я не всегда понимаю"
    gg "je ne comprends pas toujours"

# game/characters_events_idles/maya_events.rpy:373
translate french maya_scene5_night_mayaroom_fc49f049:

    # gg "Где именно граница"
    gg "Où est exactement la frontière"

# game/characters_events_idles/maya_events.rpy:375
translate french maya_scene5_night_mayaroom_6d2d9756:

    # Maya "Да нигде"
    Maya "Nulle part"

# game/characters_events_idles/maya_events.rpy:377
translate french maya_scene5_night_mayaroom_5c27dae4:

    # Maya "Хочешь границы -"
    Maya "Tu veux des limites -"

# game/characters_events_idles/maya_events.rpy:378
translate french maya_scene5_night_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "Ne me dérange pas"

# game/characters_events_idles/maya_events.rpy:379
translate french maya_scene5_night_mayaroom_71b4348e:

    # gg "Я не . . .{nw=0.3}"
    gg "Je ne . . .{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:381
translate french maya_scene5_night_mayaroom_3a7c36e6:

    # Maya "Не надо"
    ### don't appear
    Maya "Pas besoin"

# game/characters_events_idles/maya_events.rpy:383
translate french maya_scene5_night_mayaroom_11f3acdb:

    # Maya "Не делай вид"
    Maya "Ne fais pas semblant"

# game/characters_events_idles/maya_events.rpy:384
translate french maya_scene5_night_mayaroom_e9a71e8d:

    # Maya "Что ты тут ни при чём"
    Maya "Que tu n'as rien à voir avec ça"

# game/characters_events_idles/maya_events.rpy:386
translate french maya_scene5_night_mayaroom_734313d9:

    # gg "Я не пытаюсь давить"
    gg "je n'essaye pas de pousser"

# game/characters_events_idles/maya_events.rpy:387
translate french maya_scene5_night_mayaroom_e3709e94:

    # gg "Я просто . . .{nw=0.3}"
    gg "Je suis juste. . .{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:389
translate french maya_scene5_night_mayaroom_76c878d4:

    # Maya "Ты всегда «просто»"
    ### don't appear
    Maya "Tu es toujours \"simple\""

# game/characters_events_idles/maya_events.rpy:391
translate french maya_scene5_night_mayaroom_7125aff8:

    # Maya "Просто заходишь"
    Maya "Tu viens juste"

# game/characters_events_idles/maya_events.rpy:392
translate french maya_scene5_night_mayaroom_8803de0c:

    # Maya "Просто начинаешь разговор"
    Maya "Tu commences à parler"

# game/characters_events_idles/maya_events.rpy:394
translate french maya_scene5_night_mayaroom_30ca9380:

    # Maya "Просто помогаешь"
    Maya "Tu aides"

# game/characters_events_idles/maya_events.rpy:396
translate french maya_scene5_night_mayaroom_a04f159c:

    # Maya "{sc}Это бесит{/sc}"
    Maya "{sc}C'est ennuyeux{/sc}"

# game/characters_events_idles/maya_events.rpy:398
translate french maya_scene5_night_mayaroom_3a8f909d:

    # Maya "Всё"
    Maya "C’est tout"

# game/characters_events_idles/maya_events.rpy:400
translate french maya_scene5_night_mayaroom_4d5d0603:

    # Maya "Разговор окончен"
    Maya "La conversation est terminée"

# game/characters_events_idles/maya_events.rpy:404
translate french maya_scene5_night_mayaroom_37d7c2ce:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Прости"
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Désolé"

# game/characters_events_idles/maya_events.rpy:410
translate french maya_scene5_night_mayaroom_2336b49e:

    # Maya "Хотя нет"
    Maya "Bien que non"

# game/characters_events_idles/maya_events.rpy:412
translate french maya_scene5_night_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "Oublie ça"

# game/characters_events_idles/maya_events.rpy:426
translate french maya_scene5_night_mayaroom_74fb972d:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Я . . ."
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Je suis. . ."

# game/characters_events_idles/maya_events.rpy:428
translate french maya_scene5_night_mayaroom_922caaa0:

    # Maya "Не это имела в виду"
    Maya "Ce n'est pas ce que je voulais dire"

# game/characters_events_idles/maya_events.rpy:430
translate french maya_scene5_night_mayaroom_3a8f909d_1:

    # Maya "Всё"
    Maya "C'est tout"

# game/characters_events_idles/maya_events.rpy:432
translate french maya_scene5_night_mayaroom_00c0f420:

    # Maya "Иди"
    Maya "Pars"

# game/characters_events_idles/maya_events.rpy:435
translate french maya_scene5_night_mayaroom_d0668ccb:

    # Maya "Я сказала — иди{nw=2}"
    Maya "J'ai dit vas-y {nw=2}"

# game/characters_events_idles/maya_events.rpy:463
translate french maya_scene6_evening_myroom_8846d5d4:

    # Maya "Ты сидишь будто"
    Maya "Tu es assis comme si"

# game/characters_events_idles/maya_events.rpy:465
translate french maya_scene6_evening_myroom_c3936052:

    # Maya "Ничего не было"
    Maya "Il n'y avait rien"

# game/characters_events_idles/maya_events.rpy:467
translate french maya_scene6_evening_myroom_ba188167:

    # gg "Я не делаю вид"
    gg "je ne fais pas semblant"

# game/characters_events_idles/maya_events.rpy:469
translate french maya_scene6_evening_myroom_4dd50b6c:

    # Maya "Ладно, не важно"
    Maya "D'accord, ça n'a pas d'importance"

# game/characters_events_idles/maya_events.rpy:471
translate french maya_scene6_evening_myroom_7eaa97d1:

    # Maya "Залипай дальше"
    Maya "Continue à rester ici"

# game/characters_events_idles/maya_events.rpy:479
translate french maya_scene6_evening_myroom_3c725bc9:

    # Maya "Слушай"
    Maya "Écoutes"

# game/characters_events_idles/maya_events.rpy:480
translate french maya_scene6_evening_myroom_250ec1e3:

    # Maya "А ты сейчас сильно занят?"
    Maya "Es-tu très occupé en ce moment ?"

# game/characters_events_idles/maya_events.rpy:482
translate french maya_scene6_evening_myroom_5ea33f12:

    # gg "Если честно — нет"
    gg "Pour être honnête - non"

# game/characters_events_idles/maya_events.rpy:486
translate french maya_scene6_evening_myroom_f9cfb58e:

    # Maya "Я просто спросила"
    Maya "je viens de demander"

# game/characters_events_idles/maya_events.rpy:488
translate french maya_scene6_evening_myroom_70c7e32f:

    # gg "А я просто отвечаю"
    gg "Et je viens de répondre"

# game/characters_events_idles/maya_events.rpy:489
translate french maya_scene6_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya ". . ."

# game/characters_events_idles/maya_events.rpy:491
translate french maya_scene6_evening_myroom_a2fcb33c:

    # Maya "Поможешь мне кое с чем"
    Maya "Peux-tu m'aider avec quelque chose ?"

# game/characters_events_idles/maya_events.rpy:493
translate french maya_scene6_evening_myroom_19d648ec:

    # Maya "Это быстро"
    Maya "C'est rapide"

# game/characters_events_idles/maya_events.rpy:497
translate french maya_scene6_evening_myroom_9619af02:

    # gg "С чем?"
    gg "Avec quoi ?"

# game/characters_events_idles/maya_events.rpy:499
translate french maya_scene6_evening_myroom_0b3abc75:

    # Maya "Потом увидишь"
    Maya "Alors tu verras"

# game/characters_events_idles/maya_events.rpy:510
translate french maya_scene6_evening_myroom_5529e2cd:

    # Maya "Только без лишней заботы"
    Maya "Juste sans soucis inutiles"

# game/characters_events_idles/maya_events.rpy:512
translate french maya_scene6_evening_myroom_52df9211:

    # gg "Как скажешь"
    gg "Comme tu dis"

# game/characters_events_idles/maya_events.rpy:514
translate french maya_scene6_evening_myroom_3226a25c:

    # Maya "Посмотрим на что ты способен"
    Maya "Voyons ce que tu peux faire"

# game/characters_events_idles/maya_events.rpy:516
translate french maya_scene6_evening_myroom_bca52f7e:

    # Maya "Ну"
    Maya "Bien"

# game/characters_events_idles/maya_events.rpy:518
translate french maya_scene6_evening_myroom_1771af09:

    # Maya "Вот"
    Maya "Ici"

# game/characters_events_idles/maya_events.rpy:520
translate french maya_scene6_evening_myroom_ba718844:

    # Maya "Что застыл"
    Maya "Pourquoi t’es figé ?"

# game/characters_events_idles/maya_events.rpy:522
translate french maya_scene6_evening_myroom_806872f9:

    # gg "О и давно у тебя это?"
    gg "Oh, depuis combien de temps as-tu ça ?"

# game/characters_events_idles/maya_events.rpy:524
translate french maya_scene6_evening_myroom_7d6ca25f:

    # Maya "Очень"
    Maya "Très longtemps"

# game/characters_events_idles/maya_events.rpy:525
translate french maya_scene6_evening_myroom_40562848:

    # Maya "Ещё когда я делала вид"
    Maya "Même quand je faisais semblant"

# game/characters_events_idles/maya_events.rpy:527
translate french maya_scene6_evening_myroom_0b5a891a:

    # Maya "Что у меня есть дисциплина"
    Maya "Que j'ai de la discipline"

# game/characters_events_idles/maya_events.rpy:529
translate french maya_scene6_evening_myroom_51392b4e:

    # gg "В смысле?"
    gg "En termes de?"

# game/characters_events_idles/maya_events.rpy:531
translate french maya_scene6_evening_myroom_4a4b36f7:

    # Maya "Спорт"
    Maya "Sport"

# game/characters_events_idles/maya_events.rpy:533
translate french maya_scene6_evening_myroom_bec9192a:

    # Maya "Секции, график, «надо»"
    Maya "Les cours, l’emploi du temps, « les obligations »"

# game/characters_events_idles/maya_events.rpy:535
translate french maya_scene6_evening_myroom_201efa03:

    # Maya "Потом одна удачная травма"
    Maya "Puis une blessure chanceuse"

# game/characters_events_idles/maya_events.rpy:537
translate french maya_scene6_evening_myroom_c633060c:

    # Maya "И всё"
    Maya "C'est tout"

# game/characters_events_idles/maya_events.rpy:539
translate french maya_scene6_evening_myroom_46291e24:

    # Maya "Цирк закрылся"
    Maya "Le cirque est fini"

# game/characters_events_idles/maya_events.rpy:541
translate french maya_scene6_evening_myroom_d39d8973:

    # gg "И ты бросила?"
    gg "Et tu as arrêté ?"

# game/characters_events_idles/maya_events.rpy:543
translate french maya_scene6_evening_myroom_9d7ad38f:

    # Maya "Я бы назвала это"
    Maya "je l'appellerais"

# game/characters_events_idles/maya_events.rpy:545
translate french maya_scene6_evening_myroom_ceee3b55:

    # Maya "«Энергосберегающий режим»"
    Maya "\"Mode économie d'énergie\""

# game/characters_events_idles/maya_events.rpy:549
translate french maya_scene6_evening_myroom_9a044748:

    # gg "Теперь понятно почему ты так реагируешь"
    gg "Maintenant je comprends pourquoi tu réagis de cette façon"

# game/characters_events_idles/maya_events.rpy:551
translate french maya_scene6_evening_myroom_5a3ffd6f:

    # Maya "Я просто не люблю"
    Maya "Je n'aime tout simplement pas"

# game/characters_events_idles/maya_events.rpy:552
translate french maya_scene6_evening_myroom_2b6fd943:

    # Maya "Когда кто-то начинает"
    Maya "Quand quelqu'un commence"

# game/characters_events_idles/maya_events.rpy:554
translate french maya_scene6_evening_myroom_8f57b276:

    # Maya "Объяснять мне как жить"
    Maya "À m'expliquer comment vivre"

# game/characters_events_idles/maya_events.rpy:557
translate french maya_scene6_evening_myroom_55d8d51b:

    # Maya "Вообщем нужно нанести крем и забинтовать"
    Maya "En général, il faut appliquer de la crème et la bander"

# game/characters_events_idles/maya_events.rpy:559
translate french maya_scene6_evening_myroom_a23c1350:

    # gg "А к Соне почему не пошла?"
    gg "Pourquoi n'es-tu pas allé voir Sonya ?"

# game/characters_events_idles/maya_events.rpy:561
translate french maya_scene6_evening_myroom_17ee92c5:

    # Maya "По той же причине, а еще"
    Maya "Pour la même raison, et aussi"

# game/characters_events_idles/maya_events.rpy:562
translate french maya_scene6_evening_myroom_6a81a1e1:

    # Maya "Это всегда превращается"
    Maya "Ça tourne toujours"

# game/characters_events_idles/maya_events.rpy:564
translate french maya_scene6_evening_myroom_f5a6f373:

    # Maya "В «давай я»"
    Maya "Dans \"laisse-moi\""

# game/characters_events_idles/maya_events.rpy:566
translate french maya_scene6_evening_myroom_5d26e27b:

    # Maya "Она начинает суетиться"
    Maya "Elle commence à s'agiter"

# game/characters_events_idles/maya_events.rpy:567
translate french maya_scene6_evening_myroom_c1824ee1:

    # Maya "Делать больше, чем надо"
    Maya "Fais plus que nécessaire"

# game/characters_events_idles/maya_events.rpy:569
translate french maya_scene6_evening_myroom_9ad0074f:

    # Maya "А потом я виноватой себя чувствую"
    Maya "Et puis je me sens coupable"

# game/characters_events_idles/maya_events.rpy:571
translate french maya_scene6_evening_myroom_ae8589c0:

    # gg "Кажется это называется забота"
    gg "Je pense que ça s'appelle prendre soin"

# game/characters_events_idles/maya_events.rpy:573
translate french maya_scene6_evening_myroom_a240282b:

    # Maya "Тогда давай посмотрим на твою заботу"
    Maya "Alors voyons à quel point tu t'en soucies"

# game/characters_events_idles/maya_events.rpy:575
translate french maya_scene6_evening_myroom_29c79ddd:

    # Maya "Надеюсь только без драм"
    Maya "J'espère qu'il n'y a pas de drames"

# game/characters_events_idles/maya_events.rpy:577
translate french maya_scene6_evening_myroom_63c1dadc:

    # gg "Не собирался"
    gg "Je n'avais pas l'intention de le faire"

# game/characters_events_idles/maya_events.rpy:582
translate french maya_scene6_evening_myroom_41f1b09f:

    # gg "Можно?"
    gg "Je peux?"

# game/characters_events_idles/maya_events.rpy:590
translate french maya_scene6_evening_myroom_43813c59:

    # Maya "Не бойся"
    Maya "N'aie pas peur"

# game/characters_events_idles/maya_events.rpy:591
translate french maya_scene6_evening_myroom_d139c2b0:

    # Maya "Я не из хрусталя"
    Maya "je ne suis pas fait de cristal"

# game/characters_events_idles/maya_events.rpy:594
translate french maya_scene6_evening_myroom_590f3ec6:

    # Maya "Ты всегда такой спокойный?"
    Maya "Es-tu toujours aussi calme ?"

# game/characters_events_idles/maya_events.rpy:595
translate french maya_scene6_evening_myroom_79f7b16f:

    # gg "Не всегда"
    gg "Pas toujours"

# game/characters_events_idles/maya_events.rpy:597
translate french maya_scene6_evening_myroom_481c4421:

    # gg "Просто сейчас{w} нет смысла психовать"
    gg "Cela ne sert à rien de paniquer pour le moment{w}"

# game/characters_events_idles/maya_events.rpy:599
translate french maya_scene6_evening_myroom_d38be043:

    # Maya "Понятно"
    Maya "Il est clair"

# game/characters_events_idles/maya_events.rpy:600
translate french maya_scene6_evening_myroom_41f6003e:

    # Maya "Экономишь нервы"
    Maya "Économises tes nerfs"

# game/characters_events_idles/maya_events.rpy:601
translate french maya_scene6_evening_myroom_9ea43bc7:

    # Maya "Умно"
    Maya "Intelligent"

# game/characters_events_idles/maya_events.rpy:603
translate french maya_scene6_evening_myroom_b413e8d5:

    # gg "Можно сказать и так"
    gg "Tu peux le dire comme ça"

# game/characters_events_idles/maya_events.rpy:606
translate french maya_scene6_evening_myroom_ea2de26b:

    # Maya "Теперь бинтуй"
    Maya "Maintenant, bandes"

# game/characters_events_idles/maya_events.rpy:614
translate french maya_scene6_evening_myroom_69d52a38:

    # Maya "Левее"
    Maya "À gauche"

# game/characters_events_idles/maya_events.rpy:618
translate french maya_scene6_evening_myroom_a9d70df9:

    # Maya "Нет{w} стой"
    Maya "Non{w} attends"

# game/characters_events_idles/maya_events.rpy:620
translate french maya_scene6_evening_myroom_4b3bbffe:

    # Maya "Вот так"
    Maya "Comme ça"

# game/characters_events_idles/maya_events.rpy:624
translate french maya_scene6_evening_myroom_9ee64c2c:

    # Maya "Ты вообще смотришь, что делаешь?"
    Maya "Est-ce que tu regardes même ce que tu fais ?"

# game/characters_events_idles/maya_events.rpy:626
translate french maya_scene6_evening_myroom_d39f0951:

    # gg "Мая"
    gg "Maya"

# game/characters_events_idles/maya_events.rpy:628
translate french maya_scene6_evening_myroom_4e31a75d:

    # Maya "Нет, серьёзно"
    Maya "Non, sérieusement"

# game/characters_events_idles/maya_events.rpy:629
translate french maya_scene6_evening_myroom_6049c785:

    # Maya "Ты сейчас наугад это бинтуешь"
    Maya "Maintenant tu le panses au hasard"

# game/characters_events_idles/maya_events.rpy:631
translate french maya_scene6_evening_myroom_7e1fd344:

    # Maya "Или делаешь вид"
    Maya "Ou tu fais semblant"

# game/characters_events_idles/maya_events.rpy:632
translate french maya_scene6_evening_myroom_84eb66b2:

    # Maya "Что уверен"
    Maya "J'en suis sûr"

# game/characters_events_idles/maya_events.rpy:637
translate french maya_scene6_evening_myroom_d39f0951_1:

    # gg "Мая"
    gg "Maya"

# game/characters_events_idles/maya_events.rpy:639
translate french maya_scene6_evening_myroom_9db87034:

    # gg "Если тебе так проще - я выйду"
    gg "Si c'est plus facile pour toi, je peux sortir"

# game/characters_events_idles/maya_events.rpy:641
translate french maya_scene6_evening_myroom_eb8fc374:

    # Maya "Подожди"
    Maya "Attends"

# game/characters_events_idles/maya_events.rpy:647
translate french maya_scene6_evening_myroom_43dc5209:

    # Maya "Я . . .{w} не это имела в виду"
    Maya "JE . . .{w} ne voulait pas dire ça"

# game/characters_events_idles/maya_events.rpy:649
translate french maya_scene6_evening_myroom_e89a435e:

    # Maya "Просто . . ."
    Maya "Juste . . ."

# game/characters_events_idles/maya_events.rpy:651
translate french maya_scene6_evening_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "Ne pars pas"

# game/characters_events_idles/maya_events.rpy:661
translate french maya_scene6_evening_myroom_0e9018a1:

    # gg "Иии"
    gg "Hmm"

# game/characters_events_idles/maya_events.rpy:663
translate french maya_scene6_evening_myroom_15ebc100:

    # gg "Операция закончена"
    gg "Opération terminée"

# game/characters_events_idles/maya_events.rpy:667
translate french maya_scene6_evening_myroom_1ceba70d:

    # Maya "Спасибо"
    Maya "Merci"

# game/characters_events_idles/maya_events.rpy:680
translate french maya_scene6_evening_myroom_6fdd6424:

    # Maya "Не привыкай"
    Maya "Ne t'y habitue pas"

# game/characters_events_idles/maya_events.rpy:683
translate french maya_scene6_evening_myroom_63c1dadc_1:

    # gg "Не собирался"
    gg "Je n'avais pas l'intention de le faire"

# game/characters_events_idles/maya_events.rpy:705
translate french maya_scene7_night_mayaroom_fec75b67:

    # gg "Ты до сих пор за ноутом?"
    gg "Tu es toujours sur ton ordinateur portable ?"

# game/characters_events_idles/maya_events.rpy:706
translate french maya_scene7_night_mayaroom_762dfc55:

    # gg "Уже за полночь"
    gg "Il est déjà minuit passé"

# game/characters_events_idles/maya_events.rpy:708
translate french maya_scene7_night_mayaroom_0d6d9e7f:

    # Maya "И что?"
    Maya "Et quoi ?"

# game/characters_events_idles/maya_events.rpy:709
translate french maya_scene7_night_mayaroom_f874de68:

    # Maya "У меня дела в отличие от некоторых"
    Maya "Je fais les choses différemment de certains"

# game/characters_events_idles/maya_events.rpy:711
translate french maya_scene7_night_mayaroom_6b992d2b:

    # gg "Уже ночь"
    gg "Il fait déjà nuit"

# game/characters_events_idles/maya_events.rpy:713
translate french maya_scene7_night_mayaroom_730b6969:

    # gg "А переписка это работа?"
    gg "Et discuter par messages, c’est du boulot ?"

# game/characters_events_idles/maya_events.rpy:716
translate french maya_scene7_night_mayaroom_ca9eb87e:

    # Maya "Да мои дела"
    Maya "Oui, c’est mes affaires"

# game/characters_events_idles/maya_events.rpy:718
translate french maya_scene7_night_mayaroom_e1a35225:

    # Maya "Вечно лезешь туда, куда не зовут"
    Maya "Tu vas toujours là où tu n'es pas invité"

# game/characters_events_idles/maya_events.rpy:720
translate french maya_scene7_night_mayaroom_54c856a0:

    # gg "А дверь открытая{w}, значит ждала"
    gg "Et la porte était ouverte {w}, ce qui veut dire que tu attendais"

# game/characters_events_idles/maya_events.rpy:722
translate french maya_scene7_night_mayaroom_5ebc71c5:

    # Maya "Ждала?"
    Maya "Que j'attendais ?"

# game/characters_events_idles/maya_events.rpy:724
translate french maya_scene7_night_mayaroom_ab53ee69:

    # Maya "Только если дурака, чтобы под руку мешался"
    Maya "Seulement si c'est pour un imbécile qui se met en travers"

# game/characters_events_idles/maya_events.rpy:725
translate french maya_scene7_night_mayaroom_e04cd055:

    # gg_chat "На вид она слишком устала для настоящей злости"
    gg_chat "Elle a l’air trop fatiguée pour être vraiment en colère."

# game/characters_events_idles/maya_events.rpy:730
translate french maya_scene7_night_mayaroom_8876fd31:

    # Maya "ЭЭ"
    Maya "EEHH"

# game/characters_events_idles/maya_events.rpy:733
translate french maya_scene7_night_mayaroom_588c8161:

    # Maya "Не смей! Это моё!" with hpunch
    Maya "N'ose même pas y penser ! C'est à moi !" with hpunch

# game/characters_events_idles/maya_events.rpy:735
translate french maya_scene7_night_mayaroom_30b1c14e:

    # gg "Да я и не собирался читать"
    gg "Je n'avais même pas l'intention de le lire"

# game/characters_events_idles/maya_events.rpy:736
translate french maya_scene7_night_mayaroom_4d7029b4:

    # gg "Просто . . . {w}ты могла бы не прятать"
    gg "Juste . . . {w}tu ne pouvais pas te cacher"

# game/characters_events_idles/maya_events.rpy:738
translate french maya_scene7_night_mayaroom_43898c08:

    # Maya "Потому что . . ."
    Maya "Parce que . . ."

# game/characters_events_idles/maya_events.rpy:740
translate french maya_scene7_night_mayaroom_7673a52d:

    # Maya "C тобой я . . ."
    Maya "Je suis d'accord. . ."

# game/characters_events_idles/maya_events.rpy:747
translate french maya_scene7_night_mayaroom_d57c47f7:

    # Maya ". . . "
    Maya ". . ."

# game/characters_events_idles/maya_events.rpy:748
translate french maya_scene7_night_mayaroom_8b57d927:

    # Maya ". . . {w}Я не своя . . ."
    Maya ". . . {w}Je ne suis pas moi-même. . ."

# game/characters_events_idles/maya_events.rpy:749
translate french maya_scene7_night_mayaroom_6f9409ff:

    # Maya "Я всё время о тебе думаю"
    Maya "Je pense à toi tout le temps"

# game/characters_events_idles/maya_events.rpy:754
translate french maya_scene7_night_mayaroom_df75b7f4:

    # Maya "С тобой я только и делаю, что тупею!"
    Maya "Tout ce que je fais avec toi, c'est me rendre plus bête !"

# game/characters_events_idles/maya_events.rpy:756
translate french maya_scene7_night_mayaroom_578ec278:

    # Maya "Вот и всё"
    Maya "C'est ça"

# game/characters_events_idles/maya_events.rpy:761
translate french maya_scene7_night_mayaroom_b56e467a:

    # gg "Ты прячешься за словами, но глаза выдают всё"
    gg "Tu te caches derrière les mots, mais tes yeux révèlent tout"

# game/characters_events_idles/maya_events.rpy:769
translate french maya_scene7_night_mayaroom_b0f630ba:

    # Maya "{size=*0.8}. . . Дурак . . .{/size}"
    Maya "{size=*0.8}. . . Idiot . . .{/size}"

# game/characters_events_idles/maya_events.rpy:770
translate french maya_scene7_night_mayaroom_8e74b6e2:

    # Maya "Если кому-то скажешь - я тебя прибью" with hpunch
    Maya "Si tu le dis à qui que ce soit, je te tue." with hpunch

# game/characters_events_idles/maya_events.rpy:774
translate french maya_scene7_night_mayaroom_03506582:

    # gg "Угрожаешь после такого? {w}Смелая"
    gg "Es-tu menaçante après ça ? {w}Courageux"

# game/characters_events_idles/maya_events.rpy:777
translate french maya_scene7_night_mayaroom_991c3acc:

    # gg "Никому {w}только между нами"
    gg "Personne {w}juste entre nous"

# game/characters_events_idles/maya_events.rpy:792
translate french maya_scene8_morning_mayaroom_3ccef67b:

    # gg_chat "Она выглядит . . . спокойно {w}Никакой злости {w} даже странно"
    gg_chat "Elle à l'air. . . calme. {w}Pas de colère, {w} c'est même étrange"

# game/characters_events_idles/maya_events.rpy:794
translate french maya_scene8_morning_mayaroom_8e119e79:

    # Maya "Ты чё . . . {w}уже встал?.."
    Maya "Que fais-tu ? . . {w}Tu es déjà debout ?..."

# game/characters_events_idles/maya_events.rpy:796
translate french maya_scene8_morning_mayaroom_fb3f31cf:

    # gg "Эм . . . да. Я не хотел мешать. Просто заглянул"
    gg "Euh. . . Oui. Je ne voulais pas te déranger. Je viens de passer"

# game/characters_events_idles/maya_events.rpy:798
translate french maya_scene8_morning_mayaroom_0a978bde:

    # Maya "Не уходи . . ."
    Maya "Ne pars pas. . ."

# game/characters_events_idles/maya_events.rpy:800
translate french maya_scene8_morning_mayaroom_3a0bea4a:

    # Maya "Сядь"
    Maya "Assieds-toi"

# game/characters_events_idles/maya_events.rpy:805
translate french maya_scene8_morning_mayaroom_970fe7c6:

    # Maya "Спала ужасно . . ."
    Maya "J'ai très mal dormi. . ."

# game/characters_events_idles/maya_events.rpy:807
translate french maya_scene8_morning_mayaroom_4ada6f49:

    # Maya "Всё крутилось в голове"
    Maya "Tout tournait dans ma tête"

# game/characters_events_idles/maya_events.rpy:808
translate french maya_scene8_morning_mayaroom_ee85048c:

    # Maya "Не выспалась"
    Maya "Je n'ai pas assez dormi"

# game/characters_events_idles/maya_events.rpy:810
translate french maya_scene8_morning_mayaroom_30004a57:

    # gg "А у тебя будто энергии с утра через край"
    gg "Et tu sembles avoir une énergie débordante le matin"

# game/characters_events_idles/maya_events.rpy:812
translate french maya_scene8_morning_mayaroom_c4e0d6af:

    # Maya "Очень смешно . . . "
    Maya "Très drôle. . ."

# game/characters_events_idles/maya_events.rpy:814
translate french maya_scene8_morning_mayaroom_c574ca14:

    # Maya "Я лентяйка {w}просто иногда притворяюсь"
    Maya "Je suis paresseux. {w}Je fais juste semblant parfois"

# game/characters_events_idles/maya_events.rpy:816
translate french maya_scene8_morning_mayaroom_42c46aa1:

    # Maya "Ляг"
    Maya "Allonge-toi"

# game/characters_events_idles/maya_events.rpy:817
translate french maya_scene8_morning_mayaroom_9e620d29:

    # Maya "Просто . . . {w}чтоб теплее было"
    Maya "Juste . . . {w}pour qu'il fasse plus chaud"

# game/characters_events_idles/maya_events.rpy:821
translate french maya_scene8_morning_mayaroom_d012bf21:

    # gg "Ты не заболела случайно?"
    gg "Tu es pas malade par hasard ?"

# game/characters_events_idles/maya_events.rpy:824
translate french maya_scene8_morning_mayaroom_06609c2f:

    # Maya "Убью, если кому-то расскажешь"
    Maya "Je te tuerai si tu le dis à quelqu'un"

# game/characters_events_idles/maya_events.rpy:827
translate french maya_scene8_morning_mayaroom_aed6c2f3:

    # gg_chat "Может это мой шанс . . ."
    gg_chat "C'est peut-être ma chance. . ."

# game/characters_events_idles/maya_events.rpy:833
translate french maya_scene8_morning_mayaroom_7f5f7cbf:

    # Maya "Дурак . . ."
    Maya "Idiot . . ."

# game/characters_events_idles/maya_events.rpy:837
translate french maya_scene8_morning_mayaroom_f7f3b708:

    # gg_chat "Слишком спокойно . . ."
    gg_chat "Trop calme. . ."

# game/characters_events_idles/maya_events.rpy:838
translate french maya_scene8_morning_mayaroom_fc2580e2:

    # gg_chat "Значит, самое время тихо уйти"
    gg_chat "Il est donc temps de partir tranquillement"

# game/characters_events_idles/maya_events.rpy:841
translate french maya_scene8_morning_mayaroom_4b32219f:

    # gg_chat "Никогда бы не подумал, что первый поцелуй с ней будет таким"
    gg_chat "Je n'aurais jamais pensé que mon premier baiser avec elle serait comme ça"

# game/characters_events_idles/maya_events.rpy:845
translate french maya_scene8_morning_mayaroom_31bdebc7:

    # gg_chat "Вот бы всегда так . . ."
    gg_chat "Si seulement c'était toujours comme ça. . ."

# game/characters_events_idles/maya_events.rpy:846
translate french maya_scene8_morning_mayaroom_7d3e081f:

    # gg_chat "Но, зная её, лучше не задерживаться"
    gg_chat "Mais la connaissant, il vaut mieux ne pas s'attarder"

# game/characters_events_idles/maya_events.rpy:851
translate french maya_scene8_morning_mayaroom_f57b1e37:

    # gg_chat "Мягкость её груди всё ещё чувствовалась . . ."
    gg_chat "La douceur de ses seins se faisait encore sentir. . ."

# game/characters_events_idles/maya_events.rpy:852
translate french maya_scene8_morning_mayaroom_ba3923be:

    # gg_chat "И отпускать не хотелось"
    gg_chat "Et je ne voulais pas lâcher prise"

# game/characters_events_idles/maya_events.rpy:872
translate french maya_scene9_day_kitchen_b483553f:

    # Maya "О ты тут, помоги посыпать соль"
    Maya "Oh, tu es là, aide-moi à saupoudrer de sel"

# game/characters_events_idles/maya_events.rpy:874
translate french maya_scene9_day_kitchen_564e6225:

    # gg "Окей"
    gg "D'accord"

# game/characters_events_idles/maya_events.rpy:877
translate french maya_scene9_day_kitchen_7d928982:

    # Maya "И аккуратней, а то пересолишь"
    Maya "Et sois prudent, sinon tu saleras trop"

# game/characters_events_idles/maya_events.rpy:887
translate french maya_scene9_day_kitchen_29721060:

    # Maya "Так . . . {w}вот теперь оно прилипло к сковородке"
    Maya "Donc . . . {w}maintenant, il est collé à la poêle"

# game/characters_events_idles/maya_events.rpy:888
translate french maya_scene9_day_kitchen_11cbabe0:

    # Maya "Прям не оторвать"
    Maya "Je ne peux pas l'arracher"

# game/characters_events_idles/maya_events.rpy:889
translate french maya_scene9_day_kitchen_927dfd8a:

    # gg "Тогда надо поддеть снизу, чтобы не пригорело"
    gg "Ensuite, tu dois le soulever par le bas pour qu’il ne brûle pas."

# game/characters_events_idles/maya_events.rpy:892
translate french maya_scene9_day_kitchen_b2073f58:

    # Maya "Главное - не давить слишком резко"
    Maya "L'essentiel est de ne pas trop forcer"

# game/characters_events_idles/maya_events.rpy:893
translate french maya_scene9_day_kitchen_e7cb36e7:

    # Maya "Иначе желток лопнет"
    Maya "Sinon le jaune va éclater"

# game/characters_events_idles/maya_events.rpy:894
translate french maya_scene9_day_kitchen_23aa5a43:

    # gg "Но если аккуратно, всё останется целым"
    gg "Mais si tu fais attention, tout restera intact"

# game/characters_events_idles/maya_events.rpy:895
translate french maya_scene9_day_kitchen_0c33c9a7:

    # Maya "Угу . . . {w}мягче перемешивай"
    Maya "Oui . . . {w}mélanger doucement"

# game/characters_events_idles/maya_events.rpy:896
translate french maya_scene9_day_kitchen_7c4d7305:

    # Maya "Тогда всё прожарится равномерно"
    Maya "Ensuite, tout cuira uniformément"

# game/characters_events_idles/maya_events.rpy:899
translate french maya_scene9_day_kitchen_b067ff5d:

    # Maya "Всё, почти готово . . ."
    Maya "Tout est presque prêt. . ."

# game/characters_events_idles/maya_events.rpy:900
translate french maya_scene9_day_kitchen_5805bb78:

    # Maya "Ещё чуть-чуть, и можно снимать с огня"
    Maya "Encore un peu et vous pourrez le retirer du feu."

# game/characters_events_idles/maya_events.rpy:901
translate french maya_scene9_day_kitchen_c61ed5a8:

    # gg "Думаю, будет очень вкусно"
    gg "je pense que ce sera très savoureux"

# game/characters_events_idles/maya_events.rpy:905
translate french maya_scene9_day_kitchen_152dc2f3:

    # Maya "Всё {w}a то сейчас пережарим"
    Maya "C'est bon {w}sinon on va trop le cuire maintenant"

# game/characters_events_idles/maya_events.rpy:907
translate french maya_scene9_day_kitchen_d98d84da:

    # Maya "Дальше сам себе готовь"
    Maya "Alors cuisine toi-même"

# game/characters_events_idles/maya_events.rpy:909
translate french maya_scene9_day_kitchen_c00c68f7:

    # gg_chat "Она подыгрывала"
    gg_chat "Elle a joué le jeu"

# game/characters_events_idles/maya_events.rpy:910
translate french maya_scene9_day_kitchen_8e86ab7e:

    # gg_chat "Но в конце всё равно сбежала . . ."
    gg_chat "Mais à la fin, elle s'est quand même enfuie. . ."

# game/characters_events_idles/maya_events.rpy:928
translate french maya_scene10_evening_myroom_b792031e:

    # Maya "Я дома"
    Maya "je suis à la maison"

# game/characters_events_idles/maya_events.rpy:930
translate french maya_scene10_evening_myroom_4c632d43:

    # Maya "О, ты тут"
    Maya "Oh, tu es là"

# game/characters_events_idles/maya_events.rpy:932
translate french maya_scene10_evening_myroom_e37dbd39:

    # gg "Привет. Как работа?"
    gg "Bonjour. Comment va le travail ?"

# game/characters_events_idles/maya_events.rpy:934
translate french maya_scene10_evening_myroom_92ca482a:

    # Maya "Словно вечность. Эта долбаные люди"
    Maya "Comme une éternité. Ces putains de gens"

# game/characters_events_idles/maya_events.rpy:936
translate french maya_scene10_evening_myroom_d1b85968:

    # gg "Хочешь чай? Или просто вырубиться?"
    gg "Veux-tu du thé ? Ou simplement s'évanouir ?"

# game/characters_events_idles/maya_events.rpy:938
translate french maya_scene10_evening_myroom_a28c5657:

    # Maya "Чай?{w} Ты решил внезапно заботиться?"
    Maya "Du thé ?{w} As-tu soudainement décidé de t'en soucier ?"

# game/characters_events_idles/maya_events.rpy:940
translate french maya_scene10_evening_myroom_ffaaaddc:

    # Maya "Ладно . . . да, пожалуй. И два сахара"
    Maya "D'accord . . . oui, peut-être. Et deux sucres"

# game/characters_events_idles/maya_events.rpy:944
translate french maya_scene10_evening_myroom_fc470a50:

    # Maya "Уфф устала"
    Maya "Ouf, je suis fatigué"

# game/characters_events_idles/maya_events.rpy:946
translate french maya_scene10_evening_myroom_d751ae58:

    # gg "Может, поговорим?"
    gg "Peut-être qu'on peut parler ?"

# game/characters_events_idles/maya_events.rpy:948
translate french maya_scene10_evening_myroom_dd61a1d4:

    # Maya "О чём?"
    Maya "À propos de quoi?"

# game/characters_events_idles/maya_events.rpy:950
translate french maya_scene10_evening_myroom_cb7be281:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Уволь"
    Maya "Comment j'ai encore renoncé à faire le ménage ?{w} {bt=a3-p2.0-s3.0}Fiche le camp !"

# game/characters_events_idles/maya_events.rpy:952
translate french maya_scene10_evening_myroom_49e84409:

    # gg "Необязательно. Можно просто помолчать"
    gg "Facultatif. Tu peux juste te taire"

# game/characters_events_idles/maya_events.rpy:954
translate french maya_scene10_evening_myroom_963962a9:

    # Maya "Ты странный. Сидишь тут . . . как будто ждёшь чего-то"
    Maya "Tu es bizarre. tu es assis ici. . . comme si tu attends quelque chose"

# game/characters_events_idles/maya_events.rpy:958
translate french maya_scene10_evening_myroom_31f86790:

    # gg "Может, и жду"
    gg "Peut-être que j'attends"

# game/characters_events_idles/maya_events.rpy:960
translate french maya_scene10_evening_myroom_7f342626:

    # Maya "Ты же знаешь, что я . . . колючая"
    Maya "Tu sais que je le suis. . . un peu piquante"

# game/characters_events_idles/maya_events.rpy:962
translate french maya_scene10_evening_myroom_27989031:

    # gg "Знаю"
    gg "Je sais"

# game/characters_events_idles/maya_events.rpy:964
translate french maya_scene10_evening_myroom_91a19161:

    # Maya "И что я всё испорчу"
    Maya "Et que je vais tout gâcher"

# game/characters_events_idles/maya_events.rpy:966
translate french maya_scene10_evening_myroom_d6704538:

    # Maya "Обязательно ляпну какую-нибудь чушь"
    Maya "Je vais certainement laisser échapper des bêtises"

# game/characters_events_idles/maya_events.rpy:968
translate french maya_scene10_evening_myroom_489ce109:

    # gg "{bt=a3-p2.0-s3.0}{size=*0.8}Привык уже"
    gg "{bt=a3-p2.0-s3.0}{size=*0.8}J'y suis déjà habitué"

# game/characters_events_idles/maya_events.rpy:974
translate french maya_scene10_evening_myroom_c0ac8816:

    # Maya "Ну конечно. Самое время для этого"
    Maya "Eh bien, bien sûr. Il est temps pour ça"

# game/characters_events_idles/maya_events.rpy:976
translate french maya_scene10_evening_myroom_ec57c0d1:

    # gg "Май . . ."
    gg "Maya. . ."

# game/characters_events_idles/maya_events.rpy:978
translate french maya_scene10_evening_myroom_16a831f4:

    # Maya "Заткнись"
    Maya "Fermes-la"

# game/characters_events_idles/maya_events.rpy:980
translate french maya_scene10_evening_myroom_71044ba9:

    # Maya "Просто . . . заткнись"
    Maya "Juste . . . ferme-la"

# game/characters_events_idles/maya_events.rpy:990
translate french maya_scene10_evening_myroom_742929c8:

    # Maya "Тише . . . Осторожно. Я не . . .{w} Я не готова ко всему сразу"
    Maya "Du calme . . . Doucement. Je ne . . .{w} Je ne suis pas prête à tout faire en même temps"

# game/characters_events_idles/maya_events.rpy:996
translate french maya_scene10_evening_myroom_66b26945:

    # Maya "Ох . . . боже . . ."
    Maya "Oh . . . Mon dieu . . ."

# game/characters_events_idles/maya_events.rpy:1008
translate french maya_scene10_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya ". . ."

# game/characters_events_idles/maya_events.rpy:1010
translate french maya_scene10_evening_myroom_71253d69:

    # Maya "Вот это да . . ."
    Maya "Ouah . . ."

# game/characters_events_idles/maya_events.rpy:1012
translate french maya_scene10_evening_myroom_22f5a5a6:

    # Maya "Ты это . . . там всё время носил?"
    Maya "Tu es. . . dans cet état depuis tout ce temps ?"

# game/characters_events_idles/maya_events.rpy:1018
translate french maya_scene10_evening_myroom_c014a37d:

    # Maya "Нет . . ."
    Maya "Non . . ."

# game/characters_events_idles/maya_events.rpy:1020
translate french maya_scene10_evening_myroom_2d2f095f:

    # Maya "Нет, стоп"
    Maya "Non, arrête"

# game/characters_events_idles/maya_events.rpy:1022
translate french maya_scene10_evening_myroom_6b00b07b:

    # Maya "Стоп, блядь"
    Maya "Arrête, putain"

# game/characters_events_idles/maya_events.rpy:1024
translate french maya_scene10_evening_myroom_f3f9fdab:

    # gg "Майя?"
    gg "Maya ?"

# game/characters_events_idles/maya_events.rpy:1026
translate french maya_scene10_evening_myroom_b9eafd1f:

    # Maya "Выйди. Пожалуйста.{w} Просто . . . выйди"
    Maya "Sors. S'il te plaît.{w} Juste . . . sors"

# game/characters_events_idles/maya_events.rpy:1028
translate french maya_scene10_evening_myroom_92d5f1bf:

    # gg "Я . . .{w} Я не хотел . . ."
    gg "JE . . .{w} Je ne voulais pas. . ."

# game/characters_events_idles/maya_events.rpy:1030
translate french maya_scene10_evening_myroom_e6bbb658:

    # Maya "{sc}{size=*1.2}Я ЗНАЮ{/size}{/sc}, что не хотел!"
    Maya "{sc}{size=*1.2}JE SAIS{/size}{/sc} Ce n'était pas mon intention !"

# game/characters_events_idles/maya_events.rpy:1032
translate french maya_scene10_evening_myroom_9ef6f711:

    # Maya "Именно поэтому — ВЫЙДИ!"
    Maya "C'est pourquoi - SORS!"

# game/characters_events_idles/maya_events.rpy:1034
translate french maya_scene10_evening_myroom_85e3ca37:

    # Maya "Не сейчас . . .{w} Я не могу{w} Это слишком . . . реально"
    Maya "Pas maintenant . . .{w}Je ne peux pas{w} C'est trop. . . vraiment"

# game/characters_events_idles/maya_events.rpy:1036
translate french maya_scene10_evening_myroom_a4abe766:

    # gg "Хорошо. Я . . .{w} Я ушёл"
    gg "Bien. JE . . .{w} Je suis parti"

# game/characters_events_idles/maya_events.rpy:1040
translate french maya_scene10_evening_myroom_8454737d:

    # Maya "{size=*0.8}Чёрт . . . Чёрт . . . Чёрт . . ."
    Maya "{size=*0.8}Merde. . . Merde . . . Merde . . ."

# game/characters_events_idles/maya_events.rpy:1041
translate french maya_scene10_evening_myroom_c2f04aea:

    # Maya "{size=*0.8}Он такой . . . большой . . ."
    Maya "{size=*0.8}Il est comme ça. . . grand . . ."

# game/characters_events_idles/maya_events.rpy:1043
translate french maya_scene10_evening_myroom_828ad43f:

    # Maya "{size=*0.8}И мне . . ."
    Maya "{size=*0.8}Moi aussi. . ."

# game/characters_events_idles/maya_events.rpy:1044
translate french maya_scene10_evening_myroom_b4c5d69e:

    # Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Понравилось"
    Maya "{size=*0.8}{bt=a3-p2.0-s3.0}J'aime"

# game/characters_events_idles/maya_events.rpy:1061
translate french maya_scene11_morning_bathroom_bd1a48b9:

    # gg "Ты с утра за стиркой"
    gg "Tu as fait la lessive le matin"

# game/characters_events_idles/maya_events.rpy:1062
translate french maya_scene11_morning_bathroom_17ad5908:

    # gg "Это что то мифическое"
    gg "C'est quelque chose de mythique"

# game/characters_events_idles/maya_events.rpy:1064
translate french maya_scene11_morning_bathroom_2998d6f9:

    # Maya "Миф"
    Maya "Mythe"

# game/characters_events_idles/maya_events.rpy:1066
translate french maya_scene11_morning_bathroom_fa12fc4b:

    # Maya "Это если бы ты сам что-то постирал"
    Maya "C'est si tu as lavé quelque chose toi-même"

# game/characters_events_idles/maya_events.rpy:1071
translate french maya_scene11_morning_bathroom_10404fc0:

    # gg "Я хотя бы свои вещи складываю"
    gg "Au moins je fais mes valises"

# game/characters_events_idles/maya_events.rpy:1073
translate french maya_scene11_morning_bathroom_cfff324a:

    # gg "А твои валялись по всей комнате"
    gg "Et les tiens gisaient partout dans la pièce"

# game/characters_events_idles/maya_events.rpy:1075
translate french maya_scene11_morning_bathroom_67c05e6d:

    # Maya "И кто же их собрал? Не ты"
    Maya "Et qui les a récupérés ? Pas toi"

# game/characters_events_idles/maya_events.rpy:1077
translate french maya_scene11_morning_bathroom_b4e5e9ee:

    # gg "Ещё чуть-чуть, и я подумаю, что ты скрытая трудяга"
    gg "Encore un peu et je penserai que tu es un travailleur acharné caché"

# game/characters_events_idles/maya_events.rpy:1079
translate french maya_scene11_morning_bathroom_4907bae2:

    # Maya "Чего говоришь!"
    Maya "Qu'est-ce que tu dis?"

# game/characters_events_idles/maya_events.rpy:1081
translate french maya_scene11_morning_bathroom_eaaef249:

    # Maya "Думаешь я настолько лентяйка?"
    Maya "Penses-tu que je suis si paresseux?"

# game/characters_events_idles/maya_events.rpy:1083
translate french maya_scene11_morning_bathroom_062411d1:

    # gg "Думаю"
    gg "Je pense"

# game/characters_events_idles/maya_events.rpy:1088
translate french maya_scene11_morning_bathroom_b708dc2c:

    # gg "Ты кое что забыла поставить на стирку"
    gg "Tu as oublié de mettre quelque chose au lavage"

# game/characters_events_idles/maya_events.rpy:1096
translate french maya_scene11_morning_bathroom_8c8070f2:

    # Maya "Ах так?"
    Maya "Ah et alors ?"

# game/characters_events_idles/maya_events.rpy:1098
translate french maya_scene11_morning_bathroom_cb35be97:

    # Maya "Тогда стираем всё"
    Maya "Ensuite on efface tout"

# game/characters_events_idles/maya_events.rpy:1104
translate french maya_scene11_morning_bathroom_cf4d3425:

    # Maya "Ага . . ."
    Maya "Ouais. . ."

# game/characters_events_idles/maya_events.rpy:1106
translate french maya_scene11_morning_bathroom_fa661e9f:

    # Maya "Похоже ЭТО нужно будет стирать деликатно"
    Maya "On dirait que CECI devra être lavé délicatement"

# game/characters_events_idles/maya_events.rpy:1108
translate french maya_scene11_morning_bathroom_9cd0adf2:

    # Maya "Думаю мы можем продолжить на чем закончили?"
    Maya "Je pense que nous pouvons continuer là où nous nous sommes arrêtés ?"

# game/characters_events_idles/maya_events.rpy:1112
translate french maya_scene11_morning_bathroom_84b09d0d:

    # Maya "Стиралка работает . . . {w}но тут жарче, чем должно быть"
    Maya "La machine à laver fonctionne. . . {w}mais il fait plus chaud qu'il ne devrait l'être"

# game/characters_events_idles/maya_events.rpy:1113
translate french maya_scene11_morning_bathroom_6df3a5e2:

    # gg "Главное - достирай до конца"
    gg "L'essentiel est de le finir jusqu'au bout"

# game/characters_events_idles/maya_events.rpy:1114
translate french maya_scene11_morning_bathroom_d0b88dcb:

    # gg "Если оставишь придется домывать . . ."
    gg "Si tu le laisses, tu devras le laver. . ."

# game/characters_events_idles/maya_events.rpy:1119
translate french maya_scene11_morning_bathroom_0467b855:

    # Maya "Так я думаю стиралка сама справится"
    Maya "Je pense donc que la machine à laver s'en chargera toute seule"

# game/characters_events_idles/maya_events.rpy:1122
translate french maya_scene11_morning_bathroom_542d4b95:

    # Maya "А ты . . . {w}сам достирай свое"
    Maya "Et toi . . . {w}fais ton propre ménage"

# game/characters_events_idles/maya_events.rpy:1123
translate french maya_scene11_morning_bathroom_83b51400:

    # Maya "Белье . . ."
    Maya "De sous-vêtements. . ."

# game/characters_events_idles/maya_events.rpy:1129
translate french maya_scene11_morning_bathroom_eb975221:

    # gg_chat "Она ушла . . ."
    gg_chat "Elle est partie. . ."

# game/characters_events_idles/maya_events.rpy:1130
translate french maya_scene11_morning_bathroom_3188cfc5:

    # gg_chat "В следующий раз ее нельзя отпускать . . ."
    gg_chat "La prochaine fois, tu ne pourras pas la laisser partir. . ."

# game/characters_events_idles/maya_events.rpy:1147
translate french maya_scene12_evening_myroom_bb653a62:

    # Maya "Ха, так вот где ты спрятался"
    Maya "Ha, donc c'est là que tu t'es caché"

# game/characters_events_idles/maya_events.rpy:1149
translate french maya_scene12_evening_myroom_4ca35500:

    # Maya "И что ты смотришь?"
    Maya "Et qu'est-ce que tu regardes ?"

# game/characters_events_idles/maya_events.rpy:1151
translate french maya_scene12_evening_myroom_7e8ca4c6:

    # gg "Подожди я в матче"
    gg "Attends, je suis dans le match"

# game/characters_events_idles/maya_events.rpy:1152
translate french maya_scene12_evening_myroom_5ed608a5:

    # gg "Если отвлекусь - проиграю"
    gg "Si je suis distrait, je perdrai"

# game/characters_events_idles/maya_events.rpy:1154
translate french maya_scene12_evening_myroom_8f98104b:

    # Maya "И это, по-твоему, веселье?"
    Maya "Et c'est ce que tu trouves amusant ?"

# game/characters_events_idles/maya_events.rpy:1156
translate french maya_scene12_evening_myroom_336dd03a:

    # gg "Когда сам играешь намного веселее . . ."
    gg "C'est beaucoup plus amusant quand on joue seul. . ."

# game/characters_events_idles/maya_events.rpy:1158
translate french maya_scene12_evening_myroom_3a2af852:

    # Maya "А по мне, как будто трата времени"
    Maya "Pour moi, cela semble être une perte de temps"

# game/characters_events_idles/maya_events.rpy:1160
translate french maya_scene12_evening_myroom_814660f9:

    # gg "Эй!" with hpunch
    gg "Hé!" with hpunch

# game/characters_events_idles/maya_events.rpy:1161
translate french maya_scene12_evening_myroom_a589a29a:

    # gg "Я ничего не вижу!"
    gg "je ne vois rien !"

# game/characters_events_idles/maya_events.rpy:1162
translate french maya_scene12_evening_myroom_6d7f26d1:

    # Maya "Ну и что?"
    Maya "Et alors ?"

# game/characters_events_idles/maya_events.rpy:1164
translate french maya_scene12_evening_myroom_8bb854aa:

    # Maya "Почему перестал играть?"
    Maya "Pourquoi as-tu arrêté de jouer ?"

# game/characters_events_idles/maya_events.rpy:1166
translate french maya_scene12_evening_myroom_9c0bce5d:

    # gg "Я же сказал"
    gg "Je te l'ai dit"

# game/characters_events_idles/maya_events.rpy:1168
translate french maya_scene12_evening_myroom_4430c970:

    # gg "Теперь только тебя и вижу"
    gg "Maintenant je ne vois que toi"

# game/characters_events_idles/maya_events.rpy:1170
translate french maya_scene12_evening_myroom_e1ca96ab:

    # Maya "Вот и отлично!"
    Maya "C'est super!"

# game/characters_events_idles/maya_events.rpy:1172
translate french maya_scene12_evening_myroom_e638502a:

    # Maya "Я теперь главный игрок"
    Maya "Je suis le joueur principal maintenant"

# game/characters_events_idles/maya_events.rpy:1174
translate french maya_scene12_evening_myroom_1751458f:

    # gg "Ты щас мне рейтинг сольешь"
    gg "Tu vas ruiner ma note maintenant"

# game/characters_events_idles/maya_events.rpy:1176
translate french maya_scene12_evening_myroom_ce7e136c:

    # Maya "Да ну, я просто проверяю"
    Maya "Ouais, et bien, je vérifie juste"

# game/characters_events_idles/maya_events.rpy:1178
translate french maya_scene12_evening_myroom_81a51f30:

    # Maya "Как тут . . . прыгает!"
    Maya "Comme ici. . . sauter!"

# game/characters_events_idles/maya_events.rpy:1180
translate french maya_scene12_evening_myroom_c46a67aa:

    # Maya "Ой, а это что делает?"
    Maya "Oh, qu'est-ce que ça fait ?"

# game/characters_events_idles/maya_events.rpy:1181
translate french maya_scene12_evening_myroom_9260e289:

    # gg "Стой, не так"
    gg "Attends, ce n'est pas comme ça"

# game/characters_events_idles/maya_events.rpy:1183
translate french maya_scene12_evening_myroom_16a342c4:

    # gg "Вот эта - стрелять, эта - использовать"
    gg "Celui-ci est pour la direction, celui-ci est pour l'utilisation"

# game/characters_events_idles/maya_events.rpy:1185
translate french maya_scene12_evening_myroom_c634457f:

    # gg "Держи крепче, смотри в экран"
    gg "Tiens bon, regarde l'écran"

# game/characters_events_idles/maya_events.rpy:1188
translate french maya_scene12_evening_myroom_b18fd1da:

    # Maya "Мм . . ."
    Maya "Mm. . ."

# game/characters_events_idles/maya_events.rpy:1189
translate french maya_scene12_evening_myroom_3f637927:

    # Maya "Тут у тебя геймпад немного неудобный . . ."
    Maya "Ici, ta manette de jeu est un peu inconfortable. . ."

# game/characters_events_idles/maya_events.rpy:1190
translate french maya_scene12_evening_myroom_8351e9a2:

    # gg "Нет . . . {w}я про . . ."
    gg "Non . . . {w}Je parle de . . ."

# game/characters_events_idles/maya_events.rpy:1193
translate french maya_scene12_evening_myroom_c16d1061:

    # gg "Целься и стреляй"
    gg "Vises et tires"

# game/characters_events_idles/maya_events.rpy:1197
translate french maya_scene12_evening_myroom_cbd60b88:

    # Maya "А! Я попала по нему!"
    Maya "AH ! Je l'ai toucher !"

# game/characters_events_idles/maya_events.rpy:1198
translate french maya_scene12_evening_myroom_15447830:

    # Maya "Но всё равно проиграла . . ."
    Maya "Mais j'ai quand même perdue. . ."

# game/characters_events_idles/maya_events.rpy:1199
translate french maya_scene12_evening_myroom_9b0188df:

    # gg "Нужно время, чтобы научиться"
    gg "Il faut du temps pour apprendre"

# game/characters_events_idles/maya_events.rpy:1201
translate french maya_scene12_evening_myroom_3a4b5fe2:

    # Maya "Время?"
    Maya "Du temps?"

# game/characters_events_idles/maya_events.rpy:1202
translate french maya_scene12_evening_myroom_7be2116f:

    # Maya "У меня терпения не хватит"
    Maya "je n'ai pas assez de patience"

# game/characters_events_idles/maya_events.rpy:1207
translate french maya_scene12_evening_myroom_502ea205:

    # Maya "Я лучше найду другой способ с тобой поиграть"
    Maya "Je préfère trouver une autre façon de jouer avec toi"

# game/characters_events_idles/maya_events.rpy:1209
translate french maya_scene12_evening_myroom_d76b3a67:

    # gg "Похоже, тебе важнее сбить меня с толку . . ."
    gg "Il semble que c'est plus important pour toi de m'embrouiller. . ."

# game/characters_events_idles/maya_events.rpy:1212
translate french maya_scene12_evening_myroom_9a170cb1:

    # Maya "Экран-то видишь ещё?"
    Maya "Tu peux toujours voir l'écran ?"

# game/characters_events_idles/maya_events.rpy:1214
translate french maya_scene12_evening_myroom_7c6d2d03:

    # Maya "А это"
    Maya "Et ça"

# game/characters_events_idles/maya_events.rpy:1216
translate french maya_scene12_evening_myroom_b1427dbd:

    # Maya "Не интереснее?"
    Maya "N'est-ce pas plus intéressant ?"

# game/characters_events_idles/maya_events.rpy:1219
translate french maya_scene12_evening_myroom_2fd00100:

    # gg "Интереснее, но я хочу выиграть"
    gg "Plus intéressant, mais je veux gagner"

# game/characters_events_idles/maya_events.rpy:1222
translate french maya_scene12_evening_myroom_161fdfc3:

    # Maya "Ну-ну"
    Maya "Eh bien, eh bien"

# game/characters_events_idles/maya_events.rpy:1223
translate french maya_scene12_evening_myroom_270d46ae:

    # Maya "Тогда держи удар"
    Maya "Alors prends le coup"

# game/characters_events_idles/maya_events.rpy:1227
translate french maya_scene12_evening_myroom_38cb6e8b:

    # Maya "Геймер"
    Maya "Petit joueur"

# game/characters_events_idles/maya_events.rpy:1229
translate french maya_scene12_evening_myroom_a093b46d:

    # gg_chat "Она решила так играть? . . ."
    gg_chat "A-t-elle décidé de jouer comme ça ? . . ."

# game/characters_events_idles/maya_events.rpy:1233
translate french maya_scene12_evening_myroom_5f58be75:

    # Maya "Давай, продолжай выигрывать"
    Maya "Allez, continue de gagner"

# game/characters_events_idles/maya_events.rpy:1234
translate french maya_scene12_evening_myroom_6c6c4f14:

    # Maya "Интересно, надолго ли тебя хватит"
    Maya "Je me demande combien de temps tu vas tenir"

# game/characters_events_idles/maya_events.rpy:1235
translate french maya_scene12_evening_myroom_cc2a1c48:

    # gg "Мая . . ."
    gg "Maya. . ."

# game/characters_events_idles/maya_events.rpy:1236
translate french maya_scene12_evening_myroom_a757aa6b:

    # gg "Ты . . ."
    gg "Toi . . ."

# game/characters_events_idles/maya_events.rpy:1237
translate french maya_scene12_evening_myroom_2ca54e92:

    # Maya "Тише, я разбираюсь с управлением"
    Maya "Chut, je commence à maîtriser les commandes."

# game/characters_events_idles/maya_events.rpy:1243
translate french maya_scene12_evening_myroom_60a36ddd:

    # Maya "Ну что?"
    Maya "Bien ?"

# game/characters_events_idles/maya_events.rpy:1244
translate french maya_scene12_evening_myroom_6ab6d9ce:

    # Maya "Поражение засчитано?"
    Maya "La défaite est-elle comptée ?"

# game/characters_events_idles/maya_events.rpy:1245
translate french maya_scene12_evening_myroom_c6558b58:

    # gg "Это вообще нечестная игра"
    gg "Ce n’est pas du tout un jeu équitable."

# game/characters_events_idles/maya_events.rpy:1247
translate french maya_scene12_evening_myroom_c6b0e67a:

    # Maya "Нечестные победы самые сладкие"
    Maya "Les victoires injustes sont les plus douces"

# game/characters_events_idles/maya_events.rpy:1248
translate french maya_scene12_evening_myroom_6e151f9e:

    # Maya "Теперь ты мой должник"
    Maya "Maintenant tu m'en dois une"

translate french strings:

    # game/characters_events_idles/maya_events.rpy:742
    old "Договаривай"
    new "Négocier"

    # game/characters_events_idles/maya_events.rpy:752
    old ". . ."
    new ". . ."

    # game/characters_events_idles/maya_events.rpy:772
    old "Угрожаешь?"
    new "Es-tu menaçante ?"

    # game/characters_events_idles/maya_events.rpy:775
    old "Никому"
    new "Personne"

    # game/characters_events_idles/maya_events.rpy:829
    old "Тихо поцеловать её"
    new "Embrasse-la tranquillement"

    # game/characters_events_idles/maya_events.rpy:842
    old "Уткнуться в ее грудь"
    new "Enterres-toi dans sa poitrine"

# TODO: Translation updated at 2026-01-26 03:22

# game/characters_events_idles/maya_events.rpy:248
translate french maya_scene3_evening_kitchen_2c2f92cd:

    # Maya "Зачем так близко?"
    Maya "Pourquoi si proche ?"

# game/characters_events_idles/maya_events.rpy:314
translate french maya_scene4_morning_mayaroom_0d36d4ee:

    # gg "Хорошо, не собирался"
    gg "D'accord, je ne voulais pas"

# game/characters_events_idles/maya_events.rpy:402
translate french maya_scene5_night_mayaroom_979f77d5:

    # Maya "{size=*1.3}Не надо"
    Maya "{size=*1.3}Pas besoin"

# game/characters_events_idles/maya_events.rpy:410
translate french maya_scene5_night_mayaroom_8fb3b4e0:

    # Maya "{size=*1.3}Ты всегда «просто»"
    Maya "{size=*1.3}Vous êtes toujours \"simple\""

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/maya_events.rpy:42
translate french maya_scene1_evening_myroom_82e75b03:

    # Maya "Где они, блин"
    Maya "Où diable sont-ils"

# game/characters_events_idles/maya_events.rpy:182
translate french maya_scene2_day_mayaroom_64552e65:

    # Maya "В мои дела"
    Maya "Dans mes affaires"

# game/characters_events_idles/maya_events.rpy:293
translate french maya_scene4_morning_mayaroom_aea30766:

    # gg "Погоди, у меня была похожая проблема"
    gg "Attends, j'ai eu un problème similaire"

# game/characters_events_idles/maya_events.rpy:304
translate french maya_scene4_morning_mayaroom_c677d050:

    # Maya "Ладно, поскольку ты уже встал тут в позу спасителя"
    Maya "D'accord, puisque tu as déjà pris la pose du sauveur ici"

# game/characters_events_idles/maya_events.rpy:308
translate french maya_scene4_morning_mayaroom_c7e3f4c3:

    # Maya "Но если сломаешь, новый купишь"
    Maya "Mais si tu le casse, achète-en un nouveau"

# game/characters_events_idles/maya_events.rpy:398
translate french maya_scene5_night_mayaroom_24e10eb1:

    # Maya "Хочешь границы"
    Maya "Voulez-vous des limites?"

# game/characters_events_idles/maya_events.rpy:521
translate french maya_scene6_evening_myroom_8447de22:

    # Maya "Увидишь"
    Maya "Tu verras"

# game/characters_events_idles/maya_events.rpy:580
translate french maya_scene6_evening_myroom_8974d68b:

    # Maya "В общем, нужно нанести крем и забинтовать"
    Maya "En général, il faut appliquer de la crème et la bander"

# game/characters_events_idles/maya_events.rpy:594
translate french maya_scene6_evening_myroom_94783c90:

    # gg "Кажется, это называется забота"
    gg "Je pense que ça s'appelle prendre soin"

# game/characters_events_idles/maya_events.rpy:620
translate french maya_scene6_evening_myroom_b0f0812d:

    # gg "Просто сейчас . . .{w} нет смысла психовать"
    gg "Tout à l' heure. . .{w} inutile de paniquer"

# game/characters_events_idles/maya_events.rpy:662
translate french maya_scene6_evening_myroom_98eb68ec:

    # gg "Если тебе так проще — я выйду"
    gg "Si c'est plus facile pour toi, je sortirai"

# game/characters_events_idles/maya_events.rpy:957
translate french maya_scene10_evening_myroom_e458abf1:

    # Maya "Словно вечность. Эти долбаные люди"
    Maya "Comme une éternité. Ces putains de gens"

# game/characters_events_idles/maya_events.rpy:967
translate french maya_scene10_evening_myroom_39f98df4:

    # Maya "Уфф, устала"
    Maya "Ugh, je suis fatigué"

# game/characters_events_idles/maya_events.rpy:973
translate french maya_scene10_evening_myroom_b1651980:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Отстань"
    Maya "À propos du fait que j'ai encore renoncé à faire le ménage ?{w} {bt=a3-p2.0-s3.0}Laissez-moi tranquille"

# game/characters_events_idles/maya_events.rpy:975
translate french maya_scene10_evening_myroom_cd61d42f:

    # gg "Да ладно тебе, можно просто помолчать"
    gg "Allez, tu peux juste te taire"

# TODO: Translation updated at 2026-02-16 03:29

# game/characters_events_idles/maya_events.rpy:1300
translate french maya_scene13_morning_girlroom_4a56a987:

    # gg_chat "Так, Cоня просила заказать новый шнур и заодно батарейки"
    gg_chat "Alors, Sonya m'a demandé de commander un nouveau câble et des piles en même temps"

# game/characters_events_idles/maya_events.rpy:1312
translate french maya_scene13_morning_girlroom_f5a72472:

    # gg "Ты чего?"
    gg "Qu'est-ce que tu fais ?"

# game/characters_events_idles/maya_events.rpy:1314
translate french maya_scene13_morning_girlroom_d958422f:

    # Maya "Ничего. Делай своё дело"
    Maya "Rien. Fais ton travail"

# game/characters_events_idles/maya_events.rpy:1318
translate french maya_scene13_morning_girlroom_6b37e39c:

    # Maya "Не отвлекайся"
    Maya "Ne te distrais pas"

# game/characters_events_idles/maya_events.rpy:1324
translate french maya_scene13_morning_girlroom_36d1af18:

    # gg "Мая одну секунду . . ."
    gg "Un instant, Maya . . ."

# game/characters_events_idles/maya_events.rpy:1325
translate french maya_scene13_morning_girlroom_df56cad2:

    # Maya "Я же сказала, делай свое дело"
    Maya "Je t'ai dit de faire ton travail"

# game/characters_events_idles/maya_events.rpy:1328
translate french maya_scene13_morning_girlroom_3fa97e8a:

    # gg "Готово"
    gg "C'est fait"

# game/characters_events_idles/maya_events.rpy:1351
translate french maya_scene13_morning_girlroom_d5360aaa:

    # Maya "Ну как тебе такое спокойное утро?"
    Maya "Alors, qu'est-ce que tu penses de ce matin tranquille ?"

# game/characters_events_idles/maya_events.rpy:1353
translate french maya_scene13_morning_girlroom_337e1de0:

    # gg "Замечательно"
    gg "C'est merveilleux"

# game/characters_events_idles/maya_events.rpy:1382
translate french maya_scene14_afternoon_myroom_72791318:

    # Sonya "Эй . . . [povname] можешь помочь с коробками?"
    Sonya "Hé . . . [povname], peux-tu m'aider avec les boîtes ?"

# game/characters_events_idles/maya_events.rpy:1384
translate french maya_scene14_afternoon_myroom_dce97add:

    # Maya "Ой. Тебя зовут"
    Maya "Oh, on t'appelle"

# game/characters_events_idles/maya_events.rpy:1386
translate french maya_scene14_afternoon_myroom_650d8ae1:

    # Maya "Беги. Не заставляй даму ждать"
    Maya "Cours. Ne fais pas attendre la dame"

# game/characters_events_idles/maya_events.rpy:1397
translate french maya_scene14_afternoon_myroom_134f9600:

    # Maya "Слушай . . ."
    Maya "Écoute . . ."

# game/characters_events_idles/maya_events.rpy:1399
translate french maya_scene14_afternoon_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "Ne pars pas"

# game/characters_events_idles/maya_events.rpy:1401
translate french maya_scene14_afternoon_myroom_6e0b7c57:

    # gg "Это из-за Сони?"
    gg "C'est à cause de Sonya ?"

# game/characters_events_idles/maya_events.rpy:1403
translate french maya_scene14_afternoon_myroom_b380699d:

    # Maya "Ты правда думаешь, что я буду это обсуждать?"
    Maya "Tu crois vraiment que je vais discuter de ça ?"

# game/characters_events_idles/maya_events.rpy:1406
translate french maya_scene14_afternoon_myroom_0ea54924:

    # Maya "Мне не нравится, как легко ты вскакиваешь"
    Maya "Je n'aime pas à quel point tu te lèves facilement"

# game/characters_events_idles/maya_events.rpy:1408
translate french maya_scene14_afternoon_myroom_e1764fab:

    # Maya "Как будто меня тут нет"
    Maya "Comme si je n'étais pas là"

# game/characters_events_idles/maya_events.rpy:1410
translate french maya_scene14_afternoon_myroom_1d844383:

    # Maya "Пять минут"
    Maya "Cinq minutes"

# game/characters_events_idles/maya_events.rpy:1415
translate french maya_scene14_afternoon_myroom_cab2c2bb:

    # Maya "Пять"
    Maya "Cinq"

# game/characters_events_idles/maya_events.rpy:1417
translate french maya_scene14_afternoon_myroom_b4e47535:

    # Maya "И потом делай что хочешь"
    Maya "Et après, fais ce que tu veux"

# game/characters_events_idles/maya_events.rpy:1419
translate french maya_scene14_afternoon_myroom_9b6c39fb:

    # Maya "Только не думай, что это признание"
    Maya "Ne pense pas que c'est une déclaration"

# game/characters_events_idles/maya_events.rpy:1426
translate french maya_scene14_afternoon_myroom_93de4523:

    # Maya "Чeрт . . . каждый раз будто в первый"
    Maya "Merde . . . chaque fois c'est comme la première fois"

# game/characters_events_idles/maya_events.rpy:1433
translate french maya_scene14_afternoon_myroom_3179047f:

    # Maya "Неужели всё это . . . мне?"
    Maya "Tout ça . . . pour moi ?"

# game/characters_events_idles/maya_events.rpy:1439
translate french maya_scene14_afternoon_myroom_8135a08f:

    # Maya "Такой . . . наглый"
    Maya "Tellement . . . audacieux"

# game/characters_events_idles/maya_events.rpy:1441
translate french maya_scene14_afternoon_myroom_b3c83659:

    # Maya "И такой тeплый . . ."
    Maya "Et tellement chaud . . ."

# game/characters_events_idles/maya_events.rpy:1449
translate french maya_scene14_afternoon_myroom_6a11d281:

    # Maya "Держись . . ."
    Maya "Tiens bon . . ."

# game/characters_events_idles/maya_events.rpy:1455
translate french maya_scene14_afternoon_myroom_53e2be3e:

    # Maya ". . . Всe"
    Maya ". . . Tout"

# game/characters_events_idles/maya_events.rpy:1459
translate french maya_scene14_afternoon_myroom_1f177920:

    # Maya "Моe"
    Maya "Mon"

# game/characters_events_idles/maya_events.rpy:1463
translate french maya_scene14_afternoon_myroom_9f7300e6:

    # Maya "Все"
    Maya "Tout"

# game/characters_events_idles/maya_events.rpy:1465
translate french maya_scene14_afternoon_myroom_00c0f420:

    # Maya "Иди"
    Maya "Va"

# game/characters_events_idles/maya_events.rpy:1467
translate french maya_scene14_afternoon_myroom_0efb861b:

    # gg "Ты уверена?"
    gg "Tu es sûre ?"

# game/characters_events_idles/maya_events.rpy:1469
translate french maya_scene14_afternoon_myroom_362d3834:

    # Maya "Ага"
    Maya "Ouais"

# game/characters_events_idles/maya_events.rpy:1471
translate french maya_scene14_afternoon_myroom_31d3f8e7:

    # Maya "Только не пропадай"
    Maya "Juste ne disparaît pas"

# game/characters_events_idles/maya_events.rpy:1473
translate french maya_scene14_afternoon_myroom_baa7f0c3:

    # Maya "Ты всё равно вернешься"
    Maya "De toute façon, tu reviendras"
