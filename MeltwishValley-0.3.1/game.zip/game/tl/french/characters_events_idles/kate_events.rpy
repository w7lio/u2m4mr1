﻿# TODO: Translation updated at 2026-01-21 13:15

# game/characters_events_idles/kate_events.rpy:8
translate french kate_day_myroom_66ca7b58:

    # Kate "О, живой человек"
    Kate "Oh un homme vivant"

# game/characters_events_idles/kate_events.rpy:9
translate french kate_day_myroom_b8813bdd:

    # Kate "Я уже начала думать, что вы тут все в спячке"
    Kate "Je commence déjà à penser que vous hibernez tous ici."

# game/characters_events_idles/kate_events.rpy:10
translate french kate_day_myroom_930c1443:

    # gg "Просто тихий день"
    gg "Juste une journée tranquille"

# game/characters_events_idles/kate_events.rpy:11
translate french kate_day_myroom_53322b78:

    # gg "Мая опять заставила ждать?"
    gg "Tu as fait attendre Maya encore ?"

# game/characters_events_idles/kate_events.rpy:13
translate french kate_day_myroom_995097d0:

    # Kate "Конечно. Я даже не удивляюсь"
    Kate "Certainement. je ne suis même pas surpris"

# game/characters_events_idles/kate_events.rpy:15
translate french kate_day_myroom_10cad415:

    # Kate "Знаешь"
    Kate "Tu sais"

# game/characters_events_idles/kate_events.rpy:17
translate french kate_day_myroom_c22e07fd:

    # Kate "Я тут недавно проезжала мимо старого бассейна, который возле рощи"
    Kate "Je suis récemment passé devant l'ancienne piscine, qui se trouve près du bosquet."

# game/characters_events_idles/kate_events.rpy:19
translate french kate_day_myroom_6a0c7cc1:

    # gg "Того, что сейчас с облупленной плиткой и заросшей дорожкой?"
    gg "Celui maintenant avec les tuiles écaillées et le chemin envahi par la végétation ?"

# game/characters_events_idles/kate_events.rpy:20
translate french kate_day_myroom_28bfe61b:

    # Kate "Ага. Ты его знаешь?"
    Kate "Ouais. Tu connais ?"

# game/characters_events_idles/kate_events.rpy:21
translate french kate_day_myroom_70967ed9:

    # gg "Осталось воспоминание"
    gg "Un souvenir reste"

# game/characters_events_idles/kate_events.rpy:22
translate french kate_day_myroom_f3840668:

    # gg "В детстве бабушка туда водила меня, интересно что же с ним случилось"
    gg "Ma grand-mère m'y emmenait quand j'étais enfant, je me demande ce qui est arrivé"

# game/characters_events_idles/kate_events.rpy:24
translate french kate_day_myroom_7d5745ab:

    # Kate "Я случилась"
    Kate "je peux te le dire"

# game/characters_events_idles/kate_events.rpy:26
translate french kate_day_myroom_1c84b7f9:

    # Kate "Это был бассейн моего деда"
    Kate "C'était la piscine de mon grand-père"

# game/characters_events_idles/kate_events.rpy:27
translate french kate_day_myroom_d7e25aaf:

    # Kate "Когда он умер, всё просто оставили. Я была маленькой"
    Kate "Quand il est mort, tout a été laissé derrière lui. j'étais petite"

# game/characters_events_idles/kate_events.rpy:29
translate french kate_day_myroom_f2aff5b8:

    # Kate "Тогда я часто туда ходила"
    Kate "Puis j'y suis souvent allé"

# game/characters_events_idles/kate_events.rpy:30
translate french kate_day_myroom_678d9c75:

    # Kate "Не знаю почему . . . {w}просто сидела, слушала, как эхо по плитке гуляет"
    Kate "Je ne sais pas pourquoi. . . {w}je viens de m'asseoir et d'écouter l'écho qui traverse les carreaux"

# game/characters_events_idles/kate_events.rpy:32
translate french kate_day_myroom_a3778e4f:

    # gg "Я помню, там вода была — чистая, голубая"
    gg "Je me souviens que l'eau là-bas était claire et bleue"

# game/characters_events_idles/kate_events.rpy:34
translate french kate_day_myroom_43319b98:

    # Kate "Да. А сейчас трещины пошли"
    Kate "Oui. Et maintenant les fissures ont commencé"

# game/characters_events_idles/kate_events.rpy:36
translate french kate_day_myroom_1917ed73:

    # Kate "И трава пробилась через бетон"
    Kate "Et l'herbe a percé le béton"

# game/characters_events_idles/kate_events.rpy:37
translate french kate_day_myroom_3128d351:

    # Kate "Но место до сих пор . . . родное, понимаешь?"
    Kate "Mais l'endroit est toujours là. . . familier, tu comprends ?"

# game/characters_events_idles/kate_events.rpy:39
translate french kate_day_myroom_fe5606ef:

    # gg "Можно было бы восстановить"
    gg "L'endroit pourrait être restauré"

# game/characters_events_idles/kate_events.rpy:41
translate french kate_day_myroom_cd6d5961:

    # Kate "Ха, говоришь, как будто это просто"
    Kate "Ha, tu dis ça comme si c'était facile"

# game/characters_events_idles/kate_events.rpy:42
translate french kate_day_myroom_5397ef5f:

    # gg "Ну . . . {w}если там не обрушено дно — это реально"
    gg "Et bien . . . {w}si le fond ne s'est pas effondré à cet endroit, c'est réel"

# game/characters_events_idles/kate_events.rpy:43
translate french kate_day_myroom_4ad2a7d6:

    # gg " Я могу помочь, если хочешь"
    gg "Je peux t'aider si tu veux"

# game/characters_events_idles/kate_events.rpy:45
translate french kate_day_myroom_2d06e21d:

    # Kate "Ты это серьёзно?"
    Kate "Tu es sérieux?"

# game/characters_events_idles/kate_events.rpy:46
translate french kate_day_myroom_9b243b4f:

    # gg "Почему нет. Место стоящее"
    gg "Pourquoi pas ? C'est un lieu intéressant"

# game/characters_events_idles/kate_events.rpy:47
translate french kate_day_myroom_7abebe15:

    # gg "И . . . {w} как будто жалко, что всё так осталось"
    gg "ET . . . {w} c'est dommage que tout reste comme ça"

# game/characters_events_idles/kate_events.rpy:49
translate french kate_day_myroom_ba8f7539:

    # Kate "Подожди, подожди!"
    Kate "Attends, attends !"

# game/characters_events_idles/kate_events.rpy:50
translate french kate_day_myroom_1b5ecaea:

    # Kate "То есть, если я найду цемент, кисти, старый насос — ты реально поможешь это оживить?"
    Kate "Autrement dit, si je trouve du ciment, des brosses, une vieille pompe, tu pourrais vraiment m'aider à lui redonner vie ?"

# game/characters_events_idles/kate_events.rpy:52
translate french kate_day_myroom_29e07d4d:

    # gg "Похоже, я только что подписался на летний ремонт"
    gg "On dirait que je viens de m'inscrire pour une rénovation d'été."

# game/characters_events_idles/kate_events.rpy:54
translate french kate_day_myroom_23062701:

    # Kate "Господи, ты не понимаешь!"
    Kate "Seigneur, tu ne comprends pas !"

# game/characters_events_idles/kate_events.rpy:55
translate french kate_day_myroom_0f27478e:

    # Kate "Там же можно сделать всё заново!"
    Kate "Là, Tu pourrais tout refaire !"

# game/characters_events_idles/kate_events.rpy:58
translate french kate_day_myroom_f8a1991c:

    # Kate "Подсветку включить, бортики покрасить . . ."
    Kate "Allumer l'éclairage, peindre les côtés. . ."

# game/characters_events_idles/kate_events.rpy:59
translate french kate_day_myroom_9fa28628:

    # Kate "Я даже помню, где лежала старая лестница!"
    Kate "Je me souviens même où se trouvait la vieille échelle !"

# game/characters_events_idles/kate_events.rpy:61
translate french kate_day_myroom_01599462:

    # Kate "Можем даже вывеску повесить — “Бассейн №1 Возрождён при участии безумцев”!"
    Kate "On peut même accrocher une pancarte - « Piscine n°1 relancée avec la participation de fous » !"

# game/characters_events_idles/kate_events.rpy:63
translate french kate_day_myroom_65417f70:

    # gg "Безумцев?"
    gg "Des hommes fous?"

# game/characters_events_idles/kate_events.rpy:65
translate french kate_day_myroom_37a114e4:

    # Kate "Ну, а кто ещё решит копаться в полузаброшенном дворе ради детской мечты?"
    Kate "Eh bien, qui d'autre décidera de creuser dans une cour à moitié abandonnée au nom d'un rêve d'enfant ?"

# game/characters_events_idles/kate_events.rpy:68
translate french kate_day_myroom_fb47222b:

    # Kate "Если получится . . . я, наверное, наконец перестану чувствовать, что всё хорошее осталось “там”, в прошлом"
    Kate "Si ça marche. . . Je vais probablement enfin arrêter de penser que toutes les bonnes choses sont laissées « là-bas » dans le passé"

# game/characters_events_idles/kate_events.rpy:69
translate french kate_day_myroom_9e4c9fbd:

    # gg "Значит, начнём с настоящего"
    gg "Alors commençons par le présent"

# game/characters_events_idles/kate_events.rpy:71
translate french kate_day_myroom_2d334a18:

    # Kate "Серьёзно!?"
    Kate "Sérieusement!?"

# game/characters_events_idles/kate_events.rpy:72
translate french kate_day_myroom_756e6836:

    # Kate "Спасибо. Ты первый, кто не сказал “забей”"
    Kate "Merci. Tu es le premier à ne pas dire \"abandonne le\""

# game/characters_events_idles/kate_events.rpy:73
translate french kate_day_myroom_651bc331:

    # gg "Я не умею “забивать”"
    gg "Je ne sais pas quoi dire"

# game/characters_events_idles/kate_events.rpy:79
translate french kate_day_myroom_7ace6d42:

    # Maya "Кейт! Я готова!"
    Maya "Kate ! Je suis prête !"

# game/characters_events_idles/kate_events.rpy:81
translate french kate_day_myroom_d05a36ed:

    # Kate "Опять вовремя"
    Kate "Encore à l'heure"

# game/characters_events_idles/kate_events.rpy:83
translate french kate_day_myroom_be210218:

    # Kate "Тогда Увидимся у бассейна [povname], строитель мечтаний"
    Kate "Alors rendez-vous au bord de la piscine [povname], bâtisseur de rêves"

