﻿# TODO: Translation updated at 2026-01-21 02:05

translate portugues strings:

    # game/core/variables.rpy:88
    old "Понедельник"
    new "segunda-feira"

    # game/core/variables.rpy:88
    old "Вторник"
    new "terça-feira"

    # game/core/variables.rpy:88
    old "Среда"
    new "quarta-feira"

    # game/core/variables.rpy:88
    old "Четверг"
    new "quinta-feira"

    # game/core/variables.rpy:88
    old "Пятница"
    new "sexta-feira"

    # game/core/variables.rpy:88
    old "Суббота"
    new "sábado"

    # game/core/variables.rpy:88
    old "Воскресенье"
    new "domingo"

    # game/core/variables.rpy:121
    old "Моя комната"
    new "Meu quarto"

# TODO: Translation updated at 2026-02-13 11:40

translate portugues strings:

    # game/core/variables.rpy:422
    old "Ночь Зал"
    new "Noite Sala"

# TODO: Translation updated at 2026-02-16 03:29

translate portugues strings:

    # game/core/variables.rpy:427
    old "Комната Сони"
    new "Quarto da Sonya"

# game/core/variables.rpy:427
    old "Утро комната Сони"
    new "Manhã, quarto da Sonya"

# game/core/variables.rpy:427
    old "День зал"
    new "Sala do dia"

