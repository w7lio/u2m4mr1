﻿# TODO: Translation updated at 2026-01-21 02:05

translate portugues strings:

    # game/core/characters.rpy:28
    old "Почтальон"
    new "Carteira"

    # game/core/characters.rpy:32
    old "Секретарь"
    new "Secretária"

    # game/core/characters.rpy:36
    old "Директор"
    new "Diretora"

    # game/core/characters.rpy:40
    old "Незнакомка"
    new "Desconhecida"


