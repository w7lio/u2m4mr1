﻿# TODO: Translation updated at 2026-01-21 02:05

translate portugues strings:

# game/core/after_load.rpy:9
    old "Спокойный и наблюдательный, он приехал в посёлок, чтобы сбежать от прошлого и найти себя заново. Не всегда уверен, но с каждым новым знакомством делает шаг ближе к тому, кем хочет стать"
    new "Calmo e observador, ele veio para a vila para fugir do passado e se redescobrir. Nem sempre confiante, mas a cada novo conhecimento dá um passo mais perto de quem quer se tornar"

    # game/core/after_load.rpy:9
    old "Союзник"
    new "Aliado"

    # game/core/after_load.rpy:9
    old "Вс."
    new "Dom"

    # game/core/after_load.rpy:9
    old "Кухня"
    new "Cozinha"

    # game/core/after_load.rpy:9
    old "Утро Кухня"
    new "Manhã Cozinha"

    # game/core/after_load.rpy:9
    old "Ждем тебя в следующем патче"
    new "Te esperamos no próximo patch"

    # game/core/after_load.rpy:9
    old "Вы прошли все сюжетные события этого персонажа в текущем патче"
    new "Você completou todos os eventos da história deste personagem no patch atual"

    # game/core/after_load.rpy:9
    old "Мая"
    new "Maya"

    # game/core/after_load.rpy:9
    old "Дерзкая, ироничная и ленивая, кажется отстранённой, но чувствует глубже, чем показывает. Скрывает мягкость за сарказмом, пока не решит открыть себя по-настоящему. Не терпит слабости — особенно в себе"
    new "Ousada, irônica e preguiçosa, parece distante, mas sente mais fundo do que mostra. Esconde a doçura atrás do sarcasmo até decidir se abrir de verdade. Não tolera fraqueza — especialmente em si mesma"

    # game/core/after_load.rpy:9
    old "Вт."
    new "Ter"

    # game/core/after_load.rpy:9
    old "Ср."
    new "Qua"

    # game/core/after_load.rpy:9
    old "Вечер"
    new "Noite"

    # game/core/after_load.rpy:9
    old "Зал"
    new "Sala"

    # game/core/after_load.rpy:9
    old "Вечер Зал"
    new "Noite Sala"

    # game/core/after_load.rpy:9
    old "Пт."
    new "Sex"

    # game/core/after_load.rpy:9
    old "Сб."
    new "Sáb"

    # game/core/after_load.rpy:9
    old "День"
    new "Tarde"

    # game/core/after_load.rpy:9
    old "Ее комната"
    new "Quarto dela"

    # game/core/after_load.rpy:9
    old "День Ее комната"
    new "Tarde Quarto dela"

    # game/core/after_load.rpy:9
    old "Пн."
    new "Seg"

    # game/core/after_load.rpy:9
    old "Чт."
    new "Qui"

    # game/core/after_load.rpy:9
    old "Вечер кухня"
    new "Noite cozinha"

    # game/core/after_load.rpy:9
    old "День ее комната"
    new "Tarde quarto dela"

    # game/core/after_load.rpy:9
    old "Ночь"
    new "Madrugada"

    # game/core/after_load.rpy:9
    old "Ночь ее комната"
    new "Madrugada quarto dela"

    # game/core/after_load.rpy:9
    old "Вечер зал"
    new "Noite sala"

    # game/core/after_load.rpy:9
    old "Утро ее комната"
    new "Manhã quarto dela"

    # game/core/after_load.rpy:9
    old "День кухня"
    new "Tarde cozinha"

    # game/core/after_load.rpy:9
    old "Ванная"
    new "Banheiro"

    # game/core/after_load.rpy:9
    old "Утро ванная"
    new "Manhã banheiro"

    # game/core/after_load.rpy:9
    old "Соня"
    new "Sônia"

    # game/core/after_load.rpy:9
    old "Тёплая и заботливая, но собранная и точная, как часы. Любит музыку, игры и порядок, иногда стесняется — но именно она делает шаг первой"
    new "Quente e cuidadosa, mas centrada e precisa como um relógio. Adora música, jogos e ordem, às vezes é tímida — mas é ela quem dá o primeiro passo"

    # game/core/after_load.rpy:9
    old "День Ванная"
    new "Tarde Banheiro"

    # game/core/after_load.rpy:9
    old "Утро Ванная"
    new "Manhã Banheiro"

    # game/core/after_load.rpy:9
    old "Стоит подождать"
    new "Vale a pena esperar"

    # game/core/after_load.rpy:9
    old "Думаю стоит подождать"
    new "Acho que vale a pena esperar"

    # game/core/after_load.rpy:9
    old "Вечер Ее комната"
    new "Noite Quarto dela"

    # game/core/after_load.rpy:9
    old "Кейт"
    new "Kate"

    # game/core/after_load.rpy:9
    old "Яркая и энергичная, Кейт не умеет сидеть на месте — она живёт движением и смехом. Кажется лёгкой и беззаботной, но за её улыбкой прячется страх остаться одной"
    new "Vibrante e energética, Kate não consegue ficar parada — ela vive de movimento e risadas. Parece leve e despreocupada, mas por trás do seu sorriso esconde-se o medo de ficar sozinha"

    # game/core/after_load.rpy:9
    old "Утро Зал"
    new "Manhã Sala"

# TODO: Translation updated at 2026-01-26 03:23

# game/core/after_load.rpy:4
translate portugues after_load_f281aeec:

    # "Привет. Игра потерпела большой реворк, получила новое интро и сцены"
    "Olá. O jogo passou por uma grande reformulação, ganhou uma nova introdução e cenas"

# game/core/after_load.rpy:5
translate portugues after_load_92feb703:

    # "Старые сейвы работать не будут(("
    "Os saves antigos não funcionarão mais (("

# game/core/after_load.rpy:6
translate portugues after_load_dc6483bb:

    # "Пожалуйста начните игру заново"
    "Por favor, comece o jogo novamente"

# TODO: Translation updated at 2026-01-27 02:10

# game/core/after_load.rpy:4
translate portugues after_load_75a05417:

    # "Привет. Игра претерпела большие изменения, получила новое интро и сцены"
    "Olá. O jogo passou por uma grande reformulação, ganhou uma nova introdução e cenas"

# game/core/after_load.rpy:6
translate portugues after_load_c7ff0b32:

    # "Пожалуйста, начните игру заново"
    "Por favor, comece o jogo novamente"

# TODO: Translation updated at 2026-01-27 22:49

translate portugues strings:

    # game/core/after_load.rpy:13
    old "День Зал"
    new "Tarde Sala"

