﻿# TODO: Translation updated at 2026-01-21 02:05

# game/core/scripts.rpy:52
translate portugues next_time_button_9cf59ffc:

    # "Пора спать"
    "Hora de dormir"

# game/core/scripts.rpy:97
translate portugues sleep_until_morning_caa36b56:

    # "Думаю еще не время ложиться спать"
    "Acho que ainda não é hora de dormir"

