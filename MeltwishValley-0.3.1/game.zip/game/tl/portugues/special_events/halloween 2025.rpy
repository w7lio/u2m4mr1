﻿# TODO: Translation updated at 2026-01-21 02:05

# game/special_events/halloween 2025.rpy:30
translate portugues halloween_prestart_6dc15a83_1:

    # gg "Хм . . ."
    gg "Hmm..."

# game/special_events/halloween 2025.rpy:31
translate portugues halloween_prestart_3173d374_1:

    # gg "А что это еще такое?"
    gg "O que será isso?"

# game/special_events/halloween 2025.rpy:32
translate portugues halloween_prestart_9d6bd7cd_1:

    # gg "Эта тыква будто манит меня дотронуться до нее"
    gg "Esta abóbora parece me atrair para tocá-la"

# game/special_events/halloween 2025.rpy:34
translate portugues halloween_prestart_6b235c12_1:

    # gg "Вроде ничего не случилось"
    gg "Parece que nada aconteceu"

# game/special_events/halloween 2025.rpy:35
translate portugues halloween_prestart_99b702cc_1:

    # gg "Просто обычная тыква"
    gg "Só uma abóbora comum"

# game/special_events/halloween 2025.rpy:36
translate portugues halloween_prestart_882ef6af_1:

    # gg "Так не интересно"
    gg "Que chato"

# game/special_events/halloween 2025.rpy:40
translate portugues halloween_prestart_2eb26325_1:

    # gg "Ай!" with hpunch
    gg "Ai!" with hpunch

# game/special_events/halloween 2025.rpy:41
translate portugues halloween_prestart_b858f49b_1:

    # gg "Почему так щипет"
    gg "Por que arde tanto?"

# game/special_events/halloween 2025.rpy:42
translate portugues halloween_prestart_eb8d9b68_1:

    # gg "Что то мне не хорошо"
    gg "Não estou me sentindo bem"

# game/special_events/halloween 2025.rpy:43
translate portugues halloween_prestart_462beaf3_1:

    # gg "Пойду отдохну"
    gg "Vou descansar"

# game/special_events/halloween 2025.rpy:55
translate portugues halloween_start_941a30ef_1:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/special_events/halloween 2025.rpy:57
translate portugues halloween_start_2768572c_1:

    # Sonya "Знаешь, что я поняла?"
    Sonya "Sabe o que percebi?"

# game/special_events/halloween 2025.rpy:58
translate portugues halloween_start_b99b94d3_1:

    # gg "Что пора поспать?"
    gg "Que é hora de dormir?"

# game/special_events/halloween 2025.rpy:60
translate portugues halloween_start_73751dc8_1:

    # Sonya "Что пора украшать дом"
    Sonya "Que é hora de decorar a casa"

# game/special_events/halloween 2025.rpy:62
translate portugues halloween_start_2efbd354_1:

    # gg "Украшать?"
    gg "Decorar?"

# game/special_events/halloween 2025.rpy:64
translate portugues halloween_start_baa9dc02_1:

    # Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    Sonya "Faltam 2 dias para o Halloween e não tem clima nenhum"

# game/special_events/halloween 2025.rpy:66
translate portugues halloween_start_d64dca0a_1:

    # Sonya "Я хочу, чтобы всё выглядело"
    Sonya "Quero que tudo pareça"

# game/special_events/halloween 2025.rpy:68
translate portugues halloween_start_c1524153_1:

    # Sonya "Хотя бы немного празднично"
    Sonya "Pelo menos um pouco festivo"

# game/special_events/halloween 2025.rpy:70
translate portugues halloween_start_c4c69fc7_1:

    # Maya "Украшать?{w} Пора бы да"
    Maya "Decorar?{w} Já estava na hora"

# game/special_events/halloween 2025.rpy:72
translate portugues halloween_start_f5a85bf6_1:

    # Maya "Можно повесить гирлянды и поставить свечи!"
    Maya "Podemos colocar guirlandas e velas!"

# game/special_events/halloween 2025.rpy:74
translate portugues halloween_start_88ab11a7_1:

    # Sonya "Вот. Поддержка есть"
    Sonya "Pronto. Temos apoio"

# game/special_events/halloween 2025.rpy:76
translate portugues halloween_start_f2b19d78_1:

    # gg "Видимо у меня нет выбора"
    gg "Parece que não tenho escolha"

# game/special_events/halloween 2025.rpy:78
translate portugues halloween_start_bc7a61df_1:

    # Maya "Ты просто устал, тебе нужно отвлечься"
    Maya "Você só está cansado, precisa se distrair"

# game/special_events/halloween 2025.rpy:80
translate portugues halloween_start_06d0d58b_1:

    # Sonya "Вот именно"
    Sonya "Exatamente"

# game/special_events/halloween 2025.rpy:82
translate portugues halloween_start_041234b8_1:

    # Sonya "Украшение дома - лучший антистресс"
    Sonya "Decorar a casa é o melhor antiestresse"

# game/special_events/halloween 2025.rpy:84
translate portugues halloween_start_c578bb24_1:

    # Maya "Тогда решено"
    Maya "Então decidido"

# game/special_events/halloween 2025.rpy:85
translate portugues halloween_start_6e15e900_1:

    # Maya "Начнём с гостиной"
    Maya "Vamos começar pela sala"

# game/special_events/halloween 2025.rpy:87
translate portugues halloween_start_d298f1fa_1:

    # Maya "Я за уют, но без перебора"
    Maya "Gosto de aconchego, mas sem exageros"

# game/special_events/halloween 2025.rpy:89
translate portugues halloween_start_2a522c28_1:

    # Sonya "Надо позвать Кейт"
    Sonya "Precisamos chamar a Kate"

# game/special_events/halloween 2025.rpy:90
translate portugues halloween_start_20197ce8_1:

    # Sonya "Без неё всё равно не обойдётся"
    Sonya "Não vai dar sem ela de qualquer forma"

# game/special_events/halloween 2025.rpy:92
translate portugues halloween_start_bcecc811_1:

    # Maya "Я напишу ей"
    Maya "Vou mandar mensagem"

# game/special_events/halloween 2025.rpy:93
translate portugues halloween_start_81baf5ad_1:

    # Maya "Если не занята, придёт"
    Maya "Se não estiver ocupada, vem"

# game/special_events/halloween 2025.rpy:95
translate portugues halloween_start_4a4b3e1e_1:

    # Sonya "Пойдем поможешь мне"
    Sonya "Vem me ajudar"

# game/special_events/halloween 2025.rpy:97
translate portugues halloween_start_082fbdc3_1:

    # Sonya "У нас в кладовке чего только нету"
    Sonya "Tem de tudo no nosso depósito"

# game/special_events/halloween 2025.rpy:99
translate portugues halloween_start_569f8605_1:

    # Sonya "Осторожно, она тяжёлая"
    Sonya "Cuidado, é pesada"

# game/special_events/halloween 2025.rpy:103
translate portugues halloween_start_08a41431_1:

    # gg "Не волнуйся, я пока справляюсь"
    gg "Não se preocupe, estou dando conta por enquanto"

# game/special_events/halloween 2025.rpy:105
translate portugues halloween_start_2ee9b67e_1:

    # Maya "Написала, сказала, что уже бежит"
    Maya "Mandei mensagem, ela disse que já está vindo"

# game/special_events/halloween 2025.rpy:107
translate portugues halloween_start_56e25c3d_1:

    # Sonya "Это хорошо"
    Sonya "Que bom"

# game/special_events/halloween 2025.rpy:109
translate portugues halloween_start_cc205380_1:

    # Maya "О, смотри, старая паутина!"
    Maya "Ah, olha, uma teia velha!"

# game/special_events/halloween 2025.rpy:111
translate portugues halloween_start_6d122aa8_1:

    # Sonya "Это не декор, не трогай!"
    Sonya "Isso não é decoração, não mexe!"

# game/special_events/halloween 2025.rpy:113
translate portugues halloween_start_1c832081_1:

    # Maya "Ты же знаешь я боюсь пауков!"
    Maya "Você sabe que tenho medo de aranhas!"

# game/special_events/halloween 2025.rpy:114
translate portugues halloween_start_e8c9fd97_1:

    # gg "Ха ха"
    gg "Ha ha"

# game/special_events/halloween 2025.rpy:119
translate portugues halloween_start_5c8cb7fa_1:

    # Kate "Я пришла"
    Kate "Cheguei"

# game/special_events/halloween 2025.rpy:120
translate portugues halloween_start_5cba982d_1:

    # Kate "Где вы, мои маленькие смертные?"
    Kate "Onde estão vocês, meus pequenos mortais?"

# game/special_events/halloween 2025.rpy:121
translate portugues halloween_start_66671892_1:

    # Maya "Привет!"
    Maya "Oi!"

# game/special_events/halloween 2025.rpy:123
translate portugues halloween_start_41cac97b_1:

    # Kate "О, вы уже начали без меня?{w} Это предательство"
    Kate "Ah, já começaram sem mim?{w} Isso é traição"

# game/special_events/halloween 2025.rpy:125
translate portugues halloween_start_3f833e29_1:

    # Maya "Мы только подготовились"
    Maya "Só nos preparamos"

# game/special_events/halloween 2025.rpy:127
translate portugues halloween_start_10a24600_1:

    # Sonya "Отлично, теперь можем начинать по-настоящему"
    Sonya "Ótimo, agora podemos começar de verdade"

# game/special_events/halloween 2025.rpy:129
translate portugues halloween_start_59716300_1:

    # Maya "Всё, распределяем задачи?"
    Maya "Pronto, distribuímos as tarefas?"

# game/special_events/halloween 2025.rpy:131
translate portugues halloween_start_c6287aa3_1:

    # Kate "Так эту куклу повесим вон там, над теликом"
    Kate "Então vamos pendurar essa boneca ali, em cima da TV"

# game/special_events/halloween 2025.rpy:132
translate portugues halloween_start_ddd8aded_1:

    # Kate "Еще нужны паутины, гирлянда из флажков, черепа . . ."
    Kate "Também precisamos de teias, guirlanda de bandeirinhas, caveiras..."

# game/special_events/halloween 2025.rpy:134
translate portugues halloween_start_c1c2f306_1:

    # Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    Maya "Então no meu quarto ficamos sem decorações assustadoras?"

# game/special_events/halloween 2025.rpy:136
translate portugues halloween_start_344d78c3_1:

    # gg "Ну это же Хэллоуин, а чем ты?"
    gg "Mas é Halloween, e você?"

# game/special_events/halloween 2025.rpy:138
translate portugues halloween_start_7e9f8506_1:

    # Sonya "Мая просто трусишка"
    Sonya "A Maya é só medrosa"

# game/special_events/halloween 2025.rpy:140
translate portugues halloween_start_423eeb13_1:

    # Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "EI!! É que acho isso bobo!"

# game/special_events/halloween 2025.rpy:141
translate portugues halloween_start_1c4935b1_1:

    # Maya "Можно сделать дом тёплым, как осень!"
    Maya "Dá para deixar a casa aconchegante, como o outono!"

# game/special_events/halloween 2025.rpy:142
translate portugues halloween_start_5acb8aac_1:

    # Maya "Листья и природу . . . И без жути . . ."
    Maya "Folhas e natureza... E sem sustos..."

# game/special_events/halloween 2025.rpy:144
translate portugues halloween_start_9d95e4f7_1:

    # Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    Kate "E eu quero que fique tão aasssustador que as crianças da vizinhança gritem de medo se ousarem bater na nossa porta"

# game/special_events/halloween 2025.rpy:146
translate portugues halloween_start_97fa9b09_1:

    # Sonya "Звучит как цель"
    Sonya "Soa como um objetivo"

# game/special_events/halloween 2025.rpy:148
translate portugues halloween_start_7a0152d7_1:

    # Maya "Надеюсь, что все пройдет без происшествий"
    Maya "Espero que tudo corra sem incidentes"

# game/special_events/halloween 2025.rpy:150
translate portugues halloween_start_cd410fe4_1:

    # gg "Ну что же, давайте постараемся"
    gg "Bem, vamos nos esforçar"

# game/special_events/halloween 2025.rpy:158
translate portugues halloween_start_e7148dd7_1:

    # Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    Maya "Sabe, até que não ficou ruim, muito fofo e aconchegante"

# game/special_events/halloween 2025.rpy:160
translate portugues halloween_start_4203fcb3_1:

    # Kate "ДА! Вышло супер, мы такие молодцы"
    Kate "SIM! Ficou ótimo, somos tão bons"

# game/special_events/halloween 2025.rpy:162
translate portugues halloween_start_3c177eb8_1:

    # Sonya "Давайте дальше украсим кухню!"
    Sonya "Vamos decorar a cozinha agora!"

# game/special_events/halloween 2025.rpy:163
translate portugues halloween_start_3fc97c96_1:

    # Sonya "[povname] хватай коробки с украшениями!"
    Sonya "[povname], pega as caixas com decorações!"

# game/special_events/halloween 2025.rpy:172
translate portugues halloween_start_c18a0daf_1:

    # Maya "Ну почему я должна ее вешать?"
    Maya "Mas por que eu tenho que pendurar isso?"

# game/special_events/halloween 2025.rpy:174
translate portugues halloween_start_538416e3_1:

    # Kate "Потому что ты самая высокая, это же логично!"
    Kate "Porque você é a mais alta, é lógico!"

# game/special_events/halloween 2025.rpy:176
translate portugues halloween_start_fac78089_1:

    # Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    Maya "Eca. Não tenho medo de aranhas, só que elas são nojentas, tenho nojinho"

# game/special_events/halloween 2025.rpy:178
translate portugues halloween_start_196b4d6a_1:

    # gg "Тыкву тоже поставь на полку"
    gg "Coloca a abóbora na prateleira também"

# game/special_events/halloween 2025.rpy:187
translate portugues halloween_start_3ee05b57_1:

    # Maya "АААААААААА!" with hpunch
    Maya "AAAAAAAAAA!" with hpunch

# game/special_events/halloween 2025.rpy:191
translate portugues halloween_start_7410244b_1:

    # gg "Все, я убрал, не бойся, он же не настоящий"
    gg "Pronto, tirei, não tenha medo, não é de verdade"

# game/special_events/halloween 2025.rpy:193
translate portugues halloween_start_1ceba70d_1:

    # Maya "Спасибо"
    Maya "Obrigada"

# game/special_events/halloween 2025.rpy:195
translate portugues halloween_start_5375f0ad_1:

    # gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    gg "Você cai muito nos meus braços, será que não é de propósito?"

# game/special_events/halloween 2025.rpy:197
translate portugues halloween_start_ccd7999c_1:

    # Maya "Еще чего!"
    Maya "Só se for!"

# game/special_events/halloween 2025.rpy:198
translate portugues halloween_start_c938832e_1:

    # Maya "Ты просто мешаешься на пути, вот и все!"
    Maya "Você só atrapalha no caminho, só isso!"

# game/special_events/halloween 2025.rpy:199
translate portugues halloween_start_5807bf69_1:

    # Kate "Не поранились? Голубки"
    Kate "Não se machucaram? Pombinhos"

# game/special_events/halloween 2025.rpy:201
translate portugues halloween_start_180bf5f1_1:

    # Maya "Все с паутиной мы закончили"
    Maya "Terminamos com a teia"

# game/special_events/halloween 2025.rpy:202
translate portugues halloween_start_62eaed17_1:

    # Maya "Пойду возьму яблочного сидра"
    Maya "Vou pegar cidra de maçã"

# game/special_events/halloween 2025.rpy:208
translate portugues halloween_start_6a9d122d_1:

    # Sonya "Еще 5 минут и кексы готовы"
    Sonya "Mais 5 minutos e os cupcakes ficam prontos"

# game/special_events/halloween 2025.rpy:210
translate portugues halloween_start_92462f90_1:

    # Kate "Пахнет потрясающе"
    Kate "Cheira maravilhoso"

# game/special_events/halloween 2025.rpy:212
translate portugues halloween_start_ada25b4b_1:

    # Maya "Всё, теперь осталось только подождать"
    Maya "Pronto, agora só falta esperar"

# game/special_events/halloween 2025.rpy:213
translate portugues halloween_start_4ac68531_1:

    # Maya "Потом будем украшать"
    Maya "Depois decoramos"

# game/special_events/halloween 2025.rpy:215
translate portugues halloween_start_7d203e0d_1:

    # Kate "Эй а кем вы будете в ночь Хэллоуина?"
    Kate "Ei, e o que vocês vão ser na noite de Halloween?"

# game/special_events/halloween 2025.rpy:217
translate portugues halloween_start_3e0fd7f3_1:

    # Sonya "Я уже думала об этом!"
    Sonya "Eu já pensei nisso!"

# game/special_events/halloween 2025.rpy:218
translate portugues halloween_start_21be6b25_1:

    # Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    Sonya "Hmm, Kate, um traje de demona cairia bem em você."

# game/special_events/halloween 2025.rpy:220
translate portugues halloween_start_8fc9e335_1:

    # Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    Maya "Aliás, sim, mesmo que você pareça um anjinho, você é astuta como um duende doméstico."

# game/special_events/halloween 2025.rpy:222
translate portugues halloween_start_6485ec70_1:

    # Kate "Эй!! Неплохая идея"
    Kate "Ei!! Não é uma má ideia."

# game/special_events/halloween 2025.rpy:226
translate portugues halloween_start_9ea771a0_1:

    # Kate "Королева демонов Уахахахаха!"
    Kate "Rainha dos demônios! Uahahahaha!"

# game/special_events/halloween 2025.rpy:227
translate portugues halloween_start_dfa5392d_1:

    # Kate "Все должны пасть к моим ногам!"
    Kate "Todos devem se curvar aos meus pés!"

# game/special_events/halloween 2025.rpy:229
translate portugues halloween_start_d1a70744_1:

    # Sonya "Все, ей больше не наливать!"
    Sonya "Chega! Não serve mais nada para ela!"

# game/special_events/halloween 2025.rpy:231
translate portugues halloween_start_67a78ead_1:

    # gg "Не знал что Кейт так быстро выносит с алкоголя"
    gg "Não sabia que a Kate ficava bêbada tão rápido com álcool."

# game/special_events/halloween 2025.rpy:233
translate portugues halloween_start_89e99062_1:

    # Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    Maya "Eu gostaria de uma fantasia de bruxinha ou de alguma dríade mágica..."

# game/special_events/halloween 2025.rpy:235
translate portugues halloween_start_ccfee06e_1:

    # Kate "Думаю тебе пойдет"
    Kate "Acho que vai ficar bom em você."

# game/special_events/halloween 2025.rpy:237
translate portugues halloween_start_8e96eaa2_1:

    # Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    Sonya "E eu comprei esses dias, em vez de 1 pacote de atadura, 6 pacotes. Parece um sinal para fazer uma fantasia de múmia?"

# game/special_events/halloween 2025.rpy:239
translate portugues halloween_start_2aa5e0fb_1:

    # Maya "Ты как раз самая старшая"
    Maya "Você é justamente a mais velha."

# game/special_events/halloween 2025.rpy:241
translate portugues halloween_start_38bc2712_1:

    # Sonya "Ах ты!"
    Sonya "Ah, você!"

# game/special_events/halloween 2025.rpy:243
translate portugues halloween_start_5d38e441_1:

    # Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "Espera, e o Barsik? Ele também precisa de uma fantasia!"

# game/special_events/halloween 2025.rpy:244
translate portugues halloween_start_fb608953_1:

    # Maya "Например дракончика или мистер тыковка . . ."
    Maya "Tipo um dragãozinho ou um Senhor Abóbora..."

# game/special_events/halloween 2025.rpy:246
translate portugues halloween_start_7fd69d94_1:

    # Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    Sonya "Tente pegar e vestir ele, o Sr. Barsik não vai se entregar!"

# game/special_events/halloween 2025.rpy:248
translate portugues halloween_start_70adb582_1:

    # Maya "Что ты . . . {w}Он любит переодевашки"
    Maya "O que você tá dizendo... {w}Ele adora se fantasiar."

# game/special_events/halloween 2025.rpy:251
translate portugues halloween_start_c0036cba_1:

    # Sonya "Вот и кексы готовы"
    Sonya "Pronto, os cupcakes estão feitos."

# game/special_events/halloween 2025.rpy:253
translate portugues halloween_start_ae45c746_1:

    # gg "С кухней готово, что дальше?"
    gg "A cozinha está pronta. O que é o próximo?"

# game/special_events/halloween 2025.rpy:254
translate portugues halloween_start_354f0704_1:

    # Sonya "Предлагаю разделиться"
    Sonya "Sugiro nos dividirmos."

# game/special_events/halloween 2025.rpy:255
translate portugues halloween_start_07a07420_1:

    # Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "Eu e a Maya vamos decorar nossos quartos. Kate, você decora o banheiro."

# game/special_events/halloween 2025.rpy:256
translate portugues halloween_start_4e86ac78_1:

    # Sonya "[povname], будешь помогать нам?"
    Sonya "[povname], você vai nos ajudar?"

# game/special_events/halloween 2025.rpy:257
translate portugues halloween_start_564e6225_1:

    # gg "Окей"
    gg "Ok."

# game/special_events/halloween 2025.rpy:271
translate portugues halloween_prepare_mayaroom_7afc2c47_1:

    # gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "Você tem aqui um verdadeiro covil de bruxa que prepara poções com ervas."

# game/special_events/halloween 2025.rpy:272
translate portugues halloween_prepare_mayaroom_63c64e7b_1:

    # gg "Мм. . . пахнет приятно"
    gg "Hmm... Tem um cheiro bom."

# game/special_events/halloween 2025.rpy:274
translate portugues halloween_prepare_mayaroom_1ca099b7_1:

    # Maya "Хватит нюхать женскую комнату!"
    Maya "Pare de cheirar o quarto de uma mulher!"

# game/special_events/halloween 2025.rpy:276
translate portugues halloween_prepare_mayaroom_eded9518_1:

    # Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "Você só está aqui para cumprir minhas ordens."

# game/special_events/halloween 2025.rpy:277
translate portugues halloween_prepare_mayaroom_799aa249_1:

    # Maya "Поставь эти тыквы в тот угол!"
    Maya "Coloque essas abóboras naquele canto!"

# game/special_events/halloween 2025.rpy:279
translate portugues halloween_prepare_mayaroom_292858b8_1:

    # gg "А где пожалуйста?"
    gg "E o 'por favor', onde fica?"

# game/special_events/halloween 2025.rpy:281
translate portugues halloween_prepare_mayaroom_ad71fbb0_1:

    # Maya "Пожалуйста, не беси меня"
    Maya "Por favor, não me irrite."

# game/special_events/halloween 2025.rpy:283
translate portugues halloween_prepare_mayaroom_63b60e81_1:

    # gg "Ох"
    gg "Oh."

# game/special_events/halloween 2025.rpy:285
translate portugues halloween_prepare_mayaroom_977c102e_1:

    # Maya "Мм. . . нет!"
    Maya "Hmm... não!"

# game/special_events/halloween 2025.rpy:287
translate portugues halloween_prepare_mayaroom_9cb8ca98_1:

    # Maya "Выглядит недостаточно хорошо!"
    Maya "Não parece bom o suficiente!"

# game/special_events/halloween 2025.rpy:289
translate portugues halloween_prepare_mayaroom_3b7bbda5_1:

    # Maya "Давай лучше в тот угол!"
    Maya "Melhor colocar naquele outro canto!"

# game/special_events/halloween 2025.rpy:291
translate portugues halloween_prepare_mayaroom_f714e642_1:

    # gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    gg "Que tal você decidir exatamente onde colocar primeiro, para eu não ter que carregar essas abóboras cem vezes?"

# game/special_events/halloween 2025.rpy:293
translate portugues halloween_prepare_mayaroom_a2933c08_1:

    # Maya "Говорю же туда неси!"
    Maya "Eu estou dizendo, leve para lá!"

# game/special_events/halloween 2025.rpy:295
translate portugues halloween_prepare_mayaroom_4c580716_1:

    # gg "Точно?"
    gg "Tem certeza?"

# game/special_events/halloween 2025.rpy:296
translate portugues halloween_prepare_mayaroom_fccb4de7_1:

    # gg "Я больше двигать не буду, подумай хорошо"
    gg "Não vou mover de novo, pense bem."

# game/special_events/halloween 2025.rpy:298
translate portugues halloween_prepare_mayaroom_4aa933c6_1:

    # Maya "Хотя как сейчас тоже неплохо . . ."
    Maya "Embora, como está agora também não esteja ruim..."

# game/special_events/halloween 2025.rpy:300
translate portugues halloween_prepare_mayaroom_b2b57087_1:

    # Maya "Все ты свободен!"
    Maya "Pronto, está dispensado!"

# game/special_events/halloween 2025.rpy:302
translate portugues halloween_prepare_mayaroom_04c6c53d_1:

    # gg "Спасибо"
    gg "Obrigado."

# game/special_events/halloween 2025.rpy:303
translate portugues halloween_prepare_mayaroom_dad56d9b_1:

    # Maya "Если что еще позову"
    Maya "Se precisar de mais alguma coisa, eu te chamo."

# game/special_events/halloween 2025.rpy:305
translate portugues halloween_prepare_mayaroom_6a8ac153_1:

    # Maya "Все Давай, давай, живее!!"
    Maya "Vamos, vamos, depressa!!"

# game/special_events/halloween 2025.rpy:321
translate portugues halloween_prepare_sonyaroom_b708d644_1:

    # Sonya "Ой" with hpunch
    Sonya "Ai!" with hpunch

# game/special_events/halloween 2025.rpy:323
translate portugues halloween_prepare_sonyaroom_4b100306_1:

    # Sonya "Добро пожаловать в мою обитель!"
    Sonya "Bem-vindo à minha morada!"

# game/special_events/halloween 2025.rpy:325
translate portugues halloween_prepare_sonyaroom_7fb491df_1:

    # gg "У тебя в стиле майнкрафта все, очень милая комната"
    gg "Tudo no estilo Minecraft, seu quarto é muito fofo."

# game/special_events/halloween 2025.rpy:327
translate portugues halloween_prepare_sonyaroom_9dc8d94c_1:

    # Sonya "Да, у меня много игрушек осталось"
    Sonya "Sim, eu tenho muitos brinquedos guardados."

# game/special_events/halloween 2025.rpy:328
translate portugues halloween_prepare_sonyaroom_1174b034_1:

    # gg "Чем то тебе помочь?"
    gg "Posso te ajudar em alguma coisa?"

# game/special_events/halloween 2025.rpy:330
translate portugues halloween_prepare_sonyaroom_36233e2b_1:

    # Sonya "О можешь пожалуйста разложить остальные блоки"
    Sonya "Ah, você poderia, por favor, organizar os outros blocos?"

# game/special_events/halloween 2025.rpy:332
translate portugues halloween_prepare_sonyaroom_51e25d01_1:

    # gg "Хорошо давай"
    gg "Tá bom, vamos lá."

# game/special_events/halloween 2025.rpy:336
translate portugues halloween_prepare_sonyaroom_5b80a77c_1:

    # Sonya "Так это сюда"
    Sonya "Então, isso vai aqui."

# game/special_events/halloween 2025.rpy:342
translate portugues halloween_prepare_sonyaroom_5e22d509_1:

    # Sonya "О забыла я же еще кексов поставила"
    Sonya "Ah, esqueci, ainda coloquei mais cupcakes no forno."

# game/special_events/halloween 2025.rpy:354
translate portugues halloween_prepare_bathroom_5d6a2459_1:

    # gg "Тук-Тук, к вам можно?"
    gg "Toc-toc, posso entrar?"

# game/special_events/halloween 2025.rpy:356
translate portugues halloween_prepare_bathroom_f77e9ebe_1:

    # Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "Ah, você chegou na hora certa. Eu ia justamente te chamar. Quero pendurar um fantasma sobre a banheira."

# game/special_events/halloween 2025.rpy:357
translate portugues halloween_prepare_bathroom_65af0236_1:

    # Kate "Но не достаю, вот"
    Kate "Mas não estou conseguindo alcançar. Olha."

# game/special_events/halloween 2025.rpy:359
translate portugues halloween_prepare_bathroom_b38aeb93_1:

    # Kate "Вот, видишь?"
    Kate "Aqui, tá vendo?"

# game/special_events/halloween 2025.rpy:361
translate portugues halloween_prepare_bathroom_e0f0e638_1:

    # Kate "Хм . . . а если я встану на бортики ванной?"
    Kate "Hmm... e se eu subir na borda da banheira?"

# game/special_events/halloween 2025.rpy:363
translate portugues halloween_prepare_bathroom_e11f6927_1:

    # gg "Стой, это не безопасно"
    gg "Pare! Isso não é seguro."

# game/special_events/halloween 2025.rpy:372
translate portugues halloween_prepare_bathroom_01550c8f_1:

    # Kate "ААй!" with hpunch
    Kate "Ai!" with hpunch

# game/special_events/halloween 2025.rpy:373
translate portugues halloween_prepare_bathroom_af26ae75_1:

    # Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    Kate "Ah, estou muito bêbada. Que bom que você estava por perto, obrigada."

# game/special_events/halloween 2025.rpy:375
translate portugues halloween_prepare_bathroom_78e2854b_1:

    # gg "Я так испугался за тебя"
    gg "Fiquei tão preocupado com você."

# game/special_events/halloween 2025.rpy:376
translate portugues halloween_prepare_bathroom_766703c6_1:

    # gg "За тобой глаз, да глаз, будь аккуратнее"
    gg "Tem que ficar de olho em você o tempo todo, tenha mais cuidado."

# game/special_events/halloween 2025.rpy:378
translate portugues halloween_prepare_bathroom_ef29b55b_1:

    # Kate "Хорошо, я обещаю . . ."
    Kate "Tá bom, eu prometo..."

# game/special_events/halloween 2025.rpy:380
translate portugues halloween_prepare_bathroom_61bd7d2f_1:

    # Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    Kate "Pode me soltar agora? Eu não vou subir lá de novo."

# game/special_events/halloween 2025.rpy:382
translate portugues halloween_prepare_bathroom_77a74e82_1:

    # gg "Ты такая легкая"
    gg "Você é tão leve."

# game/special_events/halloween 2025.rpy:384
translate portugues halloween_prepare_bathroom_a0e2f8bb_1:

    # Kate "Спасибо"
    Kate "Obrigada."

# game/special_events/halloween 2025.rpy:400
translate portugues halloween_prepare_myroom_5692ba1f_1:

    # gg "Эх устал я помогать всем девочкам, и так спать хотел"
    gg "Aff, cansei de ajudar todas as garotas, e já estava com sono mesmo."

# game/special_events/halloween 2025.rpy:402
translate portugues halloween_prepare_myroom_6e92de75_1:

    # gg "Думаю посплю часик"
    gg "Acho que vou tirar uma soneca."

# game/special_events/halloween 2025.rpy:420
translate portugues halloween_sonya_dream_8c6442c7_1:

    # gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "Eu acordo com um som estranho — como se alguém tivesse arranhado a madeira com uma unha."

# game/special_events/halloween 2025.rpy:421
translate portugues halloween_sonya_dream_a05b8801_1:

    # gg_chat "Это на кухне?"
    gg_chat "É na cozinha?"

# game/special_events/halloween 2025.rpy:423
translate portugues halloween_sonya_dream_514bb7b5_1:

    # gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "Vou até a cozinha, esfregando os olhos."

# game/special_events/halloween 2025.rpy:424
translate portugues halloween_sonya_dream_045482c0_1:

    # gg_chat "На столе - что-то, чего там не было"
    gg_chat "Sobre a mesa — tem algo que não estava lá antes."

# game/special_events/halloween 2025.rpy:425
translate portugues halloween_sonya_dream_e953cb07_1:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg_chat "Uma caixa.{w} Madeira escura, os cantos reforçados com um metal vermelho-sangue."

# game/special_events/halloween 2025.rpy:426
translate portugues halloween_sonya_dream_76809b89_1:

    # gg "Что за чёрт . . ."
    gg "Mas que diabos..."

# game/special_events/halloween 2025.rpy:427
translate portugues halloween_sonya_dream_b5f93453_1:

    # gg_chat "Она не выглядит новой"
    gg_chat "Ela não parece nova."

# game/special_events/halloween 2025.rpy:428
translate portugues halloween_sonya_dream_5ac4f621_1:

    # gg_chat "Скорее наоборот - как будто ей сотни лет"
    gg_chat "Pelo contrário — como se tivesse centenas de anos."

# game/special_events/halloween 2025.rpy:433
translate portugues halloween_sonya_dream_a96a7298_1:

    # gg "Просто кто-то оставил{w} Мая? Соня?"
    gg "Só alguém deixou isso aqui?{w} Maya? Sonya?"

# game/special_events/halloween 2025.rpy:434
translate portugues halloween_sonya_dream_f60dffa6_1:

    # gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "É bobo, mas mesmo assim eu toco a tampa."

# game/special_events/halloween 2025.rpy:435
translate portugues halloween_sonya_dream_7aa1f899_1:

    # gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    gg_chat "Está quente.{w} Como se fosse pele sob meus dedos, não madeira."

# game/special_events/halloween 2025.rpy:438
translate portugues halloween_sonya_dream_d4c068d1_1:

    # gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg_chat "Dentro — uma moeda. Velha, desgastada, com um olho cunhado nela, e as bordas irregulares, como se alguém a tivesse mordido."

# game/special_events/halloween 2025.rpy:439
translate portugues halloween_sonya_dream_891135f2_1:

    # gg "И всё? . . ."
    gg "E só?..."

# game/special_events/halloween 2025.rpy:441
translate portugues halloween_sonya_dream_5bbdc303_1:

    # gg "Ладно, пока возьму себе"
    gg "Tudo bem, vou ficar com isso por enquanto."

# game/special_events/halloween 2025.rpy:442
translate portugues halloween_sonya_dream_63ba62de_1:

    # gg_chat "Я поворачиваю её в пальцах"
    gg_chat "Eu giro ela entre meus dedos."

# game/special_events/halloween 2025.rpy:443
translate portugues halloween_sonya_dream_60e7c398_1:

    # gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    gg_chat "Um peso estranho, como se a moeda não fosse feita de metal, mas de algo vivo."

# game/special_events/halloween 2025.rpy:447
translate portugues halloween_sonya_dream_b51c492c_1:

    # gg "Где же все?"
    gg "Onde está todo mundo?"

# game/special_events/halloween 2025.rpy:452
translate portugues halloween_sonya_dream_867b75aa_1:

    # gg "Чёрт. что за бред телевизор сам включился . . ."
    gg "Droga. Que absurdo, a TV ligou sozinha..."

# game/special_events/halloween 2025.rpy:487
translate portugues halloween_sonya_dream_cfa5487f_1:

    # gg "Что за бред"
    gg "Que absurdo."

# game/special_events/halloween 2025.rpy:488
translate portugues halloween_sonya_dream_6ca44626_1:

    # gg "Нужно проверить остальные комнаты"
    gg "Preciso verificar os outros quartos."

# game/special_events/halloween 2025.rpy:491
translate portugues halloween_sonya_dream_3109e8d5_1:

    # gg "Соня?"
    gg "Sonya?"

# game/special_events/halloween 2025.rpy:493
translate portugues halloween_sonya_dream_af6b4c99_1:

    # gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    gg "Ei... já está tarde, você está me assustando, sério."

# game/special_events/halloween 2025.rpy:496
translate portugues halloween_sonya_dream_f09531f9_1:

    # gg "Просто показалось . . ."
    gg "Deve ter sido só impressão..."

# game/special_events/halloween 2025.rpy:497
translate portugues halloween_sonya_dream_6fecd311_1:

    # gg "Просто тень . . ."
    gg "Só uma sombra..."

# game/special_events/halloween 2025.rpy:504
translate portugues halloween_sonya_dream_b989363c_1:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:506
translate portugues halloween_sonya_dream_e5e215bc_1:

    # Sonya "Как ты посмел меня разбудить!" with hpunch
    Sonya "Como ousa me acordar!" with hpunch

# game/special_events/halloween 2025.rpy:508
translate portugues halloween_sonya_dream_cbf79f81_1:

    # gg "Соня, ты . . . {w}ты издеваешься? . . ."
    gg "Sonya, você... {w}está brincando comigo?..."

# game/special_events/halloween 2025.rpy:510
translate portugues halloween_sonya_dream_ea23c51e_1:

    # gg "Это ты? Что это за грёбаные игры? . . ."
    gg "É você? Que porra de joguinho é esse?..."

# game/special_events/halloween 2025.rpy:512
translate portugues halloween_sonya_dream_c5bc9963_1:

    # Sonya "Имя звучит знакомо"
    Sonya "O nome soa familiar."

# game/special_events/halloween 2025.rpy:513
translate portugues halloween_sonya_dream_4db18375_1:

    # Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    Sonya "Mas aquela que você chamou morreu junto com esta casa."

# game/special_events/halloween 2025.rpy:514
translate portugues halloween_sonya_dream_f5284849_1:

    # gg "Прекрати . . ."
    gg "Pare..."

# game/special_events/halloween 2025.rpy:516
translate portugues halloween_sonya_dream_bf221ec2_1:

    # Sonya "Дом теперь мой.{w} Я - его хозяин"
    Sonya "A casa agora é minha.{w} Eu sou sua dona."

# game/special_events/halloween 2025.rpy:518
translate portugues halloween_sonya_dream_2c4ebaa2_1:

    # Sonya "Боишься?"
    Sonya "Está com medo?"

# game/special_events/halloween 2025.rpy:519
translate portugues halloween_sonya_dream_0063da0b_1:

    # gg "Да . . ."
    gg "Sim..."

# game/special_events/halloween 2025.rpy:521
translate portugues halloween_sonya_dream_b67571be_1:

    # Sonya "Хорошо"
    Sonya "Bom."

# game/special_events/halloween 2025.rpy:523
translate portugues halloween_sonya_dream_14d503b0_1:

    # Sonya "Страх делает кровь живой"
    Sonya "O medo torna o sangue vivo."

# game/special_events/halloween 2025.rpy:531
translate portugues halloween_sonya_dream_ab894d3a_1:

    # Sonya "Ты принёс монету?"
    Sonya "Você trouxe a moeda?"

# game/special_events/halloween 2025.rpy:535
translate portugues halloween_sonya_dream_c3bf29e7_1:

    # gg "Что? . . ."
    gg "O quê?..."

# game/special_events/halloween 2025.rpy:537
translate portugues halloween_sonya_dream_52cb176c_1:

    # Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "O presente que estava selado. Você o abriu."

# game/special_events/halloween 2025.rpy:538
translate portugues halloween_sonya_dream_e3369996_1:

    # Sonya "Ты впустил меня"
    Sonya "Você me deixou entrar."

# game/special_events/halloween 2025.rpy:540
translate portugues halloween_sonya_dream_1f166693_1:

    # Sonya "Я не Соня"
    Sonya "Eu não sou a Sonya."

# game/special_events/halloween 2025.rpy:544
translate portugues halloween_sonya_dream_86fe7642_1:

    # Sonya "Я та, что носила её лицо"
    Sonya "Eu sou aquela que usou o rosto dela."

# game/special_events/halloween 2025.rpy:545
translate portugues halloween_sonya_dream_625b9f75_1:

    # Sonya "И теперь ты мой"
    Sonya "E agora você é meu."

# game/special_events/halloween 2025.rpy:547
translate portugues halloween_sonya_dream_0ac9332f_1:

    # Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    Sonya "Tudo que você temia perder... eu já tomei."

# game/special_events/halloween 2025.rpy:549
translate portugues halloween_sonya_dream_64ed8507_1:

    # Sonya "А теперь - перестань сопротивляться"
    Sonya "E agora — pare de resistir."

# game/special_events/halloween 2025.rpy:553
translate portugues halloween_sonya_dream_3d7ee945_1:

    # Sonya "Я выжму тебя досуха"
    Sonya "Vou espremer você até a última gota."

# game/special_events/halloween 2025.rpy:588
translate portugues halloween_maya_dream_032be6f2_1:

    # gg "Чёрт . . . {w}нет, нет, снова это . . ."
    gg "Droga... {w}não, não, de novo isso..."

# game/special_events/halloween 2025.rpy:590
translate portugues halloween_maya_dream_ff7388e6_1:

    # Maya "Эй, спокойно"
    Maya "Ei, calma."

# game/special_events/halloween 2025.rpy:592
translate portugues halloween_maya_dream_92686e55_1:

    # Maya "Ты в безопасности"
    Maya "Você está seguro."

# game/special_events/halloween 2025.rpy:593
translate portugues halloween_maya_dream_edf9349e_1:

    # gg "Где я? . . ."
    gg "Onde estou?..."

# game/special_events/halloween 2025.rpy:594
translate portugues halloween_maya_dream_de23ff68_1:

    # gg "Что . . . что это за место?"
    gg "O que... que lugar é este?"

# game/special_events/halloween 2025.rpy:596
translate portugues halloween_maya_dream_75c561e6_1:

    # Maya "Мой дом"
    Maya "Minha casa."

# game/special_events/halloween 2025.rpy:598
translate portugues halloween_maya_dream_912b1ea9_1:

    # gg "Почему . . . я . . . здесь? . . ."
    gg "Por que... eu... estou aqui?..."

# game/special_events/halloween 2025.rpy:600
translate portugues halloween_maya_dream_05fc8512_1:

    # Maya "Потому что ты боялся"
    Maya "Porque você estava com medo."

# game/special_events/halloween 2025.rpy:601
translate portugues halloween_maya_dream_657245c6_1:

    # Maya "И кто-то должен был тебя остановить"
    Maya "E alguém precisava pará-lo."

# game/special_events/halloween 2025.rpy:603
translate portugues halloween_maya_dream_dcba1503_1:

    # gg "Нет . . .{w} не приближайся"
    gg "Não... {w}não se aproxime."

# game/special_events/halloween 2025.rpy:604
translate portugues halloween_maya_dream_e91592a1_1:

    # gg "Я видел, как это начинается"
    gg "Eu vi como isso começa."

# game/special_events/halloween 2025.rpy:605
translate portugues halloween_maya_dream_d9b24014_1:

    # gg "Сначала свет, потом . . ."
    gg "Primeiro a luz, depois..."

# game/special_events/halloween 2025.rpy:608
translate portugues halloween_maya_dream_23c69478_1:

    # Maya "Никто не собирается тебя пугать"
    Maya "Ninguém vai assustá-lo."

# game/special_events/halloween 2025.rpy:609
translate portugues halloween_maya_dream_fb15da85_1:

    # gg "Это сон?"
    gg "Isso é um sonho?"

# game/special_events/halloween 2025.rpy:611
translate portugues halloween_maya_dream_ef47f8b8_1:

    # Maya "Возможно"
    Maya "Talvez."

# game/special_events/halloween 2025.rpy:612
translate portugues halloween_maya_dream_11e09330_1:

    # Maya "Но в этом сне тебе можно не убегать"
    Maya "Mas neste sonho você não precisa fugir."

# game/special_events/halloween 2025.rpy:614
translate portugues halloween_maya_dream_e96ceee2_1:

    # Maya "Сядь.{w} Попробуй просто дышать"
    Maya "Sente-se.{w} Tente apenas respirar."

# game/special_events/halloween 2025.rpy:615
translate portugues halloween_maya_dream_f1385d77_1:

    # gg "Я . . .{w} не могу"
    gg "Eu... {w}não consigo."

# game/special_events/halloween 2025.rpy:617
translate portugues halloween_maya_dream_38874e86_1:

    # Maya "Можешь{w}, начни только тихо"
    Maya "Você consegue{w}, apenas comece devagar."

# game/special_events/halloween 2025.rpy:619
translate portugues halloween_maya_dream_4a1eadac_1:

    # Maya "Ты думал, я кто-то другой, да?"
    Maya "Você pensou que eu era outra pessoa, não foi?"

# game/special_events/halloween 2025.rpy:621
translate portugues halloween_maya_dream_8d83da3f_1:

    # gg "После всего . . ."
    gg "Depois de tudo..."

# game/special_events/halloween 2025.rpy:622
translate portugues halloween_maya_dream_9aa85be5_1:

    # gg "Я и не знаю, кому верить"
    gg "Eu nem sei em quem acreditar."

# game/special_events/halloween 2025.rpy:623
translate portugues halloween_maya_dream_95a67e98_1:

    # Maya "Тогда не верь"
    Maya "Então não acredite."

# game/special_events/halloween 2025.rpy:624
translate portugues halloween_maya_dream_cf12428b_1:

    # Maya "Просто смотри"
    Maya "Apenas observe."

# game/special_events/halloween 2025.rpy:628
translate portugues halloween_maya_dream_5da82532_1:

    # gg "Чувствуешь?{w} Здесь нет боли"
    gg "Sente?{w} Aqui não há dor."

# game/special_events/halloween 2025.rpy:630
translate portugues halloween_maya_dream_df19ec31_1:

    # Maya "Ты дрожишь"
    Maya "Você está tremendo."

# game/special_events/halloween 2025.rpy:631
translate portugues halloween_maya_dream_b989363c_2:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:634
translate portugues halloween_maya_dream_718947a3_1:

    # Maya "Бедный"
    Maya "Coitado."

# game/special_events/halloween 2025.rpy:636
translate portugues halloween_maya_dream_20c45a93_1:

    # Maya "Я давно не видела людей"
    Maya "Faz tempo que não vejo pessoas."

# game/special_events/halloween 2025.rpy:638
translate portugues halloween_maya_dream_0f6f1ec4_1:

    # Maya "Вот, видишь?{w} Уже лучше"
    Maya "Viu?{w} Já está melhor."

# game/special_events/halloween 2025.rpy:639
translate portugues halloween_maya_dream_1db499d0_1:

    # gg "Не знаю, что это.{w} Но уже лучше"
    gg "Não sei o que é isso.{w} Mas já está melhor."

# game/special_events/halloween 2025.rpy:641
translate portugues halloween_maya_dream_927ad5b3_1:

    # Maya "Сейчас кое что тебя поставит на ноги"
    Maya "Agora, algo vai te colocar de pé."

# game/special_events/halloween 2025.rpy:644
translate portugues halloween_maya_dream_9add8ae1_1:

    # Maya "Здесь только травы"
    Maya "Aqui só tem ervas."

# game/special_events/halloween 2025.rpy:645
translate portugues halloween_maya_dream_338034af_1:

    # Maya "Лаванда, мята, немного корицы.{w} Попей"
    Maya "Lavanda, hortelã, um pouco de canela.{w} Beba."

# game/special_events/halloween 2025.rpy:647
translate portugues halloween_maya_dream_8f20081e_1:

    # gg "Что это?"
    gg "O que é isso?"

# game/special_events/halloween 2025.rpy:648
translate portugues halloween_maya_dream_3fdb7032_1:

    # Maya "Это магия"
    Maya "É magia."

# game/special_events/halloween 2025.rpy:650
translate portugues halloween_maya_dream_7c4cba20_1:

    # Maya "Лечебное зелье, с небольшим побочным эфектом"
    Maya "Uma poção curativa, com um pequeno efeito colateral."

# game/special_events/halloween 2025.rpy:652
translate portugues halloween_maya_dream_59e469a3_1:

    # gg "Каким еще эфектом"
    gg "Que tipo de efeito colateral?"

# game/special_events/halloween 2025.rpy:655
translate portugues halloween_maya_dream_809b7a3a_1:

    # Maya "Просто отдохни.{w} Не думай об этом"
    Maya "Apenas descanse.{w} Não pense nisso."

# game/special_events/halloween 2025.rpy:657
translate portugues halloween_maya_dream_ae92cf27_1:

    # gg "А если я снова усну?"
    gg "E se eu adormecer de novo?"

# game/special_events/halloween 2025.rpy:659
translate portugues halloween_maya_dream_c1fe7b6b_1:

    # Maya "Тогда пусть этот сон, будет приятным"
    Maya "Então que este sonho seja agradável."

# game/special_events/halloween 2025.rpy:683
translate portugues halloween_maya_dream_b989363c_3:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:684
translate portugues halloween_maya_dream_5174a63c_1:

    # gg "Приснится же такое . . ."
    gg "Que sonho foi esse..."

# game/special_events/halloween 2025.rpy:686
translate portugues halloween_maya_dream_13dee7c8_1:

    # "Тыква хранит воспоминания"
    "A abóbora guarda memórias."

# game/special_events/halloween 2025.rpy:687
translate portugues halloween_maya_dream_bb8e42de_1:

    # "Коснись её, чтобы вновь увидеть сцену"
    "Toque nela para ver a cena novamente."

translate portugues strings:

    # game/special_events/halloween 2025.rpy:8
    old "Сначала"
    new "Primeiro"

    # game/special_events/halloween 2025.rpy:10
    old "Сон с Соней"
    new "Sonho com a Sonya"

    # game/special_events/halloween 2025.rpy:14
    old "Сон с Маей"
    new "Sonho com a Maya"

# TODO: Translation updated at 2026-01-26 03:23

# game/special_events/halloween 2025.rpy:28
translate portugues halloween_prestart_6dc15a83:

    # gg "Хм . . ."
    gg "Hmm..."

# game/special_events/halloween 2025.rpy:29
translate portugues halloween_prestart_3173d374:

    # gg "А что это еще такое?"
    gg "E o que é isso?"

# game/special_events/halloween 2025.rpy:30
translate portugues halloween_prestart_9d6bd7cd:

    # gg "Эта тыква будто манит меня дотронуться до нее"
    gg "Esta abóbora parece me atrair para tocá-la."

# game/special_events/halloween 2025.rpy:32
translate portugues halloween_prestart_6b235c12:

    # gg "Вроде ничего не случилось"
    gg "Parece que nada aconteceu."

# game/special_events/halloween 2025.rpy:33
translate portugues halloween_prestart_99b702cc:

    # gg "Просто обычная тыква"
    gg "Só uma abóbora comum."

# game/special_events/halloween 2025.rpy:34
translate portugues halloween_prestart_882ef6af:

    # gg "Так не интересно"
    gg "Isso não é interessante."

# game/special_events/halloween 2025.rpy:38
translate portugues halloween_prestart_2eb26325:

    # gg "Ай!" with hpunch
    gg "Ai!" with hpunch

# game/special_events/halloween 2025.rpy:39
translate portugues halloween_prestart_b858f49b:

    # gg "Почему так щипет"
    gg "Por que está formigando tanto?"

# game/special_events/halloween 2025.rpy:40
translate portugues halloween_prestart_eb8d9b68:

    # gg "Что то мне не хорошо"
    gg "Não estou me sentindo bem."

# game/special_events/halloween 2025.rpy:41
translate portugues halloween_prestart_462beaf3:

    # gg "Пойду отдохну"
    gg "Vou descansar."

# game/special_events/halloween 2025.rpy:50
translate portugues halloween_start_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/special_events/halloween 2025.rpy:52
translate portugues halloween_start_2768572c:

    # Sonya "Знаешь, что я поняла?"
    Sonya "Sabe o que eu percebi?"

# game/special_events/halloween 2025.rpy:53
translate portugues halloween_start_b99b94d3:

    # gg "Что пора поспать?"
    gg "Que é hora de dormir?"

# game/special_events/halloween 2025.rpy:55
translate portugues halloween_start_73751dc8:

    # Sonya "Что пора украшать дом"
    Sonya "Que é hora de decorar a casa."

# game/special_events/halloween 2025.rpy:57
translate portugues halloween_start_2efbd354:

    # gg "Украшать?"
    gg "Decorar?"

# game/special_events/halloween 2025.rpy:59
translate portugues halloween_start_baa9dc02:

    # Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    Sonya "Temos Halloween em 2 dias e a atmosfera é zero."

# game/special_events/halloween 2025.rpy:61
translate portugues halloween_start_d64dca0a:

    # Sonya "Я хочу, чтобы всё выглядело"
    Sonya "Eu quero que tudo pareça..."

# game/special_events/halloween 2025.rpy:63
translate portugues halloween_start_c1524153:

    # Sonya "Хотя бы немного празднично"
    Sonya "Pelo menos um pouco festivo."

# game/special_events/halloween 2025.rpy:65
translate portugues halloween_start_c4c69fc7:

    # Maya "Украшать?{w} Пора бы да"
    Maya "Decorar?{w} Já está na hora, sim."

# game/special_events/halloween 2025.rpy:67
translate portugues halloween_start_f5a85bf6:

    # Maya "Можно повесить гирлянды и поставить свечи!"
    Maya "Podemos pendurar guirlandas e colocar velas!"

# game/special_events/halloween 2025.rpy:69
translate portugues halloween_start_88ab11a7:

    # Sonya "Вот. Поддержка есть"
    Sonya "Pronto. Temos apoio."

# game/special_events/halloween 2025.rpy:71
translate portugues halloween_start_f2b19d78:

    # gg "Видимо у меня нет выбора"
    gg "Parece que não tenho escolha."

# game/special_events/halloween 2025.rpy:73
translate portugues halloween_start_bc7a61df:

    # Maya "Ты просто устал, тебе нужно отвлечься"
    Maya "Você só está cansado, precisa se distrair."

# game/special_events/halloween 2025.rpy:75
translate portugues halloween_start_06d0d58b:

    # Sonya "Вот именно"
    Sonya "Exatamente."

# game/special_events/halloween 2025.rpy:77
translate portugues halloween_start_041234b8:

    # Sonya "Украшение дома - лучший антистресс"
    Sonya "Decorar a casa é o melhor antiestresse."

# game/special_events/halloween 2025.rpy:79
translate portugues halloween_start_c578bb24:

    # Maya "Тогда решено"
    Maya "Então, decidido."

# game/special_events/halloween 2025.rpy:80
translate portugues halloween_start_6e15e900:

    # Maya "Начнём с гостиной"
    Maya "Vamos começar pela sala de estar."

# game/special_events/halloween 2025.rpy:82
translate portugues halloween_start_d298f1fa:

    # Maya "Я за уют, но без перебора"
    Maya "Sou a favor do aconchego, mas sem exageros."

# game/special_events/halloween 2025.rpy:84
translate portugues halloween_start_2a522c28:

    # Sonya "Надо позвать Кейт"
    Sonya "Precisamos chamar a Kate."

# game/special_events/halloween 2025.rpy:85
translate portugues halloween_start_20197ce8:

    # Sonya "Без неё всё равно не обойдётся"
    Sonya "Não vamos conseguir sem ela de qualquer maneira."

# game/special_events/halloween 2025.rpy:87
translate portugues halloween_start_bcecc811:

    # Maya "Я напишу ей"
    Maya "Vou mandar uma mensagem para ela."

# game/special_events/halloween 2025.rpy:88
translate portugues halloween_start_81baf5ad:

    # Maya "Если не занята, придёт"
    Maya "Se não estiver ocupada, ela virá."

# game/special_events/halloween 2025.rpy:90
translate portugues halloween_start_4a4b3e1e:

    # Sonya "Пойдем поможешь мне"
    Sonya "Vem me ajudar."

# game/special_events/halloween 2025.rpy:92
translate portugues halloween_start_082fbdc3:

    # Sonya "У нас в кладовке чего только нету"
    Sonya "No nosso depósito tem de tudo."

# game/special_events/halloween 2025.rpy:94
translate portugues halloween_start_569f8605:

    # Sonya "Осторожно, она тяжёлая"
    Sonya "Cuidado, ela é pesada."

# game/special_events/halloween 2025.rpy:98
translate portugues halloween_start_08a41431:

    # gg "Не волнуйся, я пока справляюсь"
    gg "Não se preocupe, estou dando conta por enquanto."

# game/special_events/halloween 2025.rpy:100
translate portugues halloween_start_2ee9b67e:

    # Maya "Написала, сказала, что уже бежит"
    Maya "Mandei mensagem. Ela disse que já está vindo."

# game/special_events/halloween 2025.rpy:102
translate portugues halloween_start_56e25c3d:

    # Sonya "Это хорошо"
    Sonya "Que bom."

# game/special_events/halloween 2025.rpy:104
translate portugues halloween_start_cc205380:

    # Maya "О, смотри, старая паутина!"
    Maya "Ah, olha, teia de aranha velha!"

# game/special_events/halloween 2025.rpy:106
translate portugues halloween_start_6d122aa8:

    # Sonya "Это не декор, не трогай!"
    Sonya "Isso não é decoração, não mexe!"

# game/special_events/halloween 2025.rpy:108
translate portugues halloween_start_1c832081:

    # Maya "Ты же знаешь я боюсь пауков!"
    Maya "Você sabe que eu tenho medo de aranhas!"

# game/special_events/halloween 2025.rpy:109
translate portugues halloween_start_e8c9fd97:

    # gg "Ха ха"
    gg "Haha."

# game/special_events/halloween 2025.rpy:114
translate portugues halloween_start_5c8cb7fa:

    # Kate "Я пришла"
    Kate "Cheguei."

# game/special_events/halloween 2025.rpy:115
translate portugues halloween_start_5cba982d:

    # Kate "Где вы, мои маленькие смертные?"
    Kate "Onde estão vocês, meus pequenos mortais?"

# game/special_events/halloween 2025.rpy:116
translate portugues halloween_start_66671892:

    # Maya "Привет!"
    Maya "Oi!"

# game/special_events/halloween 2025.rpy:118
translate portugues halloween_start_41cac97b:

    # Kate "О, вы уже начали без меня?{w} Это предательство"
    Kate "Ah, já começaram sem mim?{w} Isso é traição."

# game/special_events/halloween 2025.rpy:120
translate portugues halloween_start_3f833e29:

    # Maya "Мы только подготовились"
    Maya "A gente só se preparou."

# game/special_events/halloween 2025.rpy:122
translate portugues halloween_start_10a24600:

    # Sonya "Отлично, теперь можем начинать по-настоящему"
    Sonya "Excelente, agora podemos começar de verdade."

# game/special_events/halloween 2025.rpy:124
translate portugues halloween_start_59716300:

    # Maya "Всё, распределяем задачи?"
    Maya "Pronto, vamos dividir as tarefas?"

# game/special_events/halloween 2025.rpy:126
translate portugues halloween_start_c6287aa3:

    # Kate "Так эту куклу повесим вон там, над теликом"
    Kate "Então essa boneca vamos pendurar ali, em cima da TV."

# game/special_events/halloween 2025.rpy:127
translate portugues halloween_start_ddd8aded:

    # Kate "Еще нужны паутины, гирлянда из флажков, черепа . . ."
    Kate "Também precisamos de teias, uma guirlanda de bandeirinhas, caveiras..."

# game/special_events/halloween 2025.rpy:129
translate portugues halloween_start_c1c2f306:

    # Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    Maya "Então no meu quarto vamos ficar sem decorações assustadoras?"

# game/special_events/halloween 2025.rpy:131
translate portugues halloween_start_344d78c3:

    # gg "Ну это же Хэллоуин, а чем ты?"
    gg "Mas é Halloween, e você?"

# game/special_events/halloween 2025.rpy:133
translate portugues halloween_start_7e9f8506:

    # Sonya "Мая просто трусишка"
    Sonya "Maya é só uma medrosa."

# game/special_events/halloween 2025.rpy:135
translate portugues halloween_start_423eeb13:

    # Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "EI!! É só que eu acho isso bobo!"

# game/special_events/halloween 2025.rpy:136
translate portugues halloween_start_1c4935b1:

    # Maya "Можно сделать дом тёплым, как осень!"
    Maya "Dá pra deixar a casa aconchegante, como o outono!"

# game/special_events/halloween 2025.rpy:137
translate portugues halloween_start_5acb8aac:

    # Maya "Листья и природу . . . И без жути . . ."
    Maya "Folhas e natureza... E sem coisas assustadoras..."

# game/special_events/halloween 2025.rpy:139
translate portugues halloween_start_9d95e4f7:

    # Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    Kate "E eu quero que fique tão aassustador, que as crianças da vizinhança gritem de medo se ousarem bater na nossa porta."

# game/special_events/halloween 2025.rpy:141
translate portugues halloween_start_97fa9b09:

    # Sonya "Звучит как цель"
    Sonya "Soa como um objetivo."

# game/special_events/halloween 2025.rpy:143
translate portugues halloween_start_7a0152d7:

    # Maya "Надеюсь, что все пройдет без происшествий"
    Maya "Espero que tudo aconteça sem incidentes."

# game/special_events/halloween 2025.rpy:145
translate portugues halloween_start_cd410fe4:

    # gg "Ну что же, давайте постараемся"
    gg "Bom, então vamos nos esforçar."

# game/special_events/halloween 2025.rpy:153
translate portugues halloween_start_e7148dd7:

    # Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    Maya "Sabem, não ficou tão ruim, ficou bem fofo e aconchegante."

# game/special_events/halloween 2025.rpy:155
translate portugues halloween_start_4203fcb3:

    # Kate "ДА! Вышло супер, мы такие молодцы"
    Kate "SIM! Ficou ótimo, somos tão boas nisso."

# game/special_events/halloween 2025.rpy:157
translate portugues halloween_start_3c177eb8:

    # Sonya "Давайте дальше украсим кухню!"
    Sonya "Vamos decorar a cozinha agora!"

# game/special_events/halloween 2025.rpy:158
translate portugues halloween_start_3fc97c96:

    # Sonya "[povname] хватай коробки с украшениями!"
    Sonya "[povname], pega as caixas de decoração!"

# game/special_events/halloween 2025.rpy:167
translate portugues halloween_start_c18a0daf:

    # Maya "Ну почему я должна ее вешать?"
    Maya "Ah, por que eu tenho que pendurar isso?"

# game/special_events/halloween 2025.rpy:169
translate portugues halloween_start_538416e3:

    # Kate "Потому что ты самая высокая, это же логично!"
    Kate "Porque você é a mais alta, é lógico!"

# game/special_events/halloween 2025.rpy:171
translate portugues halloween_start_fac78089:

    # Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    Maya "Eca. Eu não tenho medo de aranhas, é só que elas são nojentas, me dão repulsa."

# game/special_events/halloween 2025.rpy:173
translate portugues halloween_start_196b4d6a:

    # gg "Тыкву тоже поставь на полку"
    gg "Coloca a abóbora na prateleira também."

# game/special_events/halloween 2025.rpy:182
translate portugues halloween_start_3ee05b57:

    # Maya "АААААААААА!" with hpunch
    Maya "AAAAAAAAAH!" with hpunch

# game/special_events/halloween 2025.rpy:186
translate portugues halloween_start_7410244b:

    # gg "Все, я убрал, не бойся, он же не настоящий"
    gg "Pronto, tirei. Não tenha medo, não é de verdade."

# game/special_events/halloween 2025.rpy:188
translate portugues halloween_start_1ceba70d:

    # Maya "Спасибо"
    Maya "Obrigada."

# game/special_events/halloween 2025.rpy:190
translate portugues halloween_start_5375f0ad:

    # gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    gg "Você cai muito nos meus braços. Será que não é de propósito?"

# game/special_events/halloween 2025.rpy:192
translate portugues halloween_start_ccd7999c:

    # Maya "Еще чего!"
    Maya "O quê?! Nem pensar!"

# game/special_events/halloween 2025.rpy:193
translate portugues halloween_start_c938832e:

    # Maya "Ты просто мешаешься на пути, вот и все!"
    Maya "Você só fica no meio do caminho, só isso!"

# game/special_events/halloween 2025.rpy:194
translate portugues halloween_start_5807bf69:

    # Kate "Не поранились? Голубки"
    Kate "Não se machucaram? Pombinhos."

# game/special_events/halloween 2025.rpy:196
translate portugues halloween_start_180bf5f1:

    # Maya "Все с паутиной мы закончили"
    Maya "Terminamos com a teia."

# game/special_events/halloween 2025.rpy:197
translate portugues halloween_start_62eaed17:

    # Maya "Пойду возьму яблочного сидра"
    Maya "Vou pegar cidra de maçã."

# game/special_events/halloween 2025.rpy:203
translate portugues halloween_start_6a9d122d:

    # Sonya "Еще 5 минут и кексы готовы"
    Sonya "Mais 5 minutos e os cupcakes estarão prontos."

# game/special_events/halloween 2025.rpy:205
translate portugues halloween_start_92462f90:

    # Kate "Пахнет потрясающе"
    Kate "O cheiro está incrível."

# game/special_events/halloween 2025.rpy:207
translate portugues halloween_start_ada25b4b:

    # Maya "Всё, теперь осталось только подождать"
    Maya "Pronto, agora só falta esperar."

# game/special_events/halloween 2025.rpy:208
translate portugues halloween_start_4ac68531:

    # Maya "Потом будем украшать"
    Maya "Depois a gente decora."

# game/special_events/halloween 2025.rpy:210
translate portugues halloween_start_7d203e0d:

    # Kate "Эй а кем вы будете в ночь Хэллоуина?"
    Kate "Ei, e vocês, quem vão ser na noite de Halloween?"

# game/special_events/halloween 2025.rpy:212
translate portugues halloween_start_3e0fd7f3:

    # Sonya "Я уже думала об этом!"
    Sonya "Eu já pensei nisso!"

# game/special_events/halloween 2025.rpy:213
translate portugues halloween_start_21be6b25:

    # Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    Sonya "Hmm, Kate, um traje de demona cairia bem em você."

# game/special_events/halloween 2025.rpy:215
translate portugues halloween_start_8fc9e335:

    # Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    Maya "Aliás, sim, mesmo que você pareça um anjinho, você é astuta como um duende doméstico."

# game/special_events/halloween 2025.rpy:217
translate portugues halloween_start_6485ec70:

    # Kate "Эй!! Неплохая идея"
    Kate "Ei!! Não é uma má ideia."

# game/special_events/halloween 2025.rpy:221
translate portugues halloween_start_9ea771a0:

    # Kate "Королева демонов Уахахахаха!"
    Kate "Rainha dos demônios! Uahahahaha!"

# game/special_events/halloween 2025.rpy:222
translate portugues halloween_start_dfa5392d:

    # Kate "Все должны пасть к моим ногам!"
    Kate "Todos devem se curvar aos meus pés!"

# game/special_events/halloween 2025.rpy:224
translate portugues halloween_start_d1a70744:

    # Sonya "Все, ей больше не наливать!"
    Sonya "Chega! Não serve mais nada para ela!"

# game/special_events/halloween 2025.rpy:226
translate portugues halloween_start_67a78ead:

    # gg "Не знал что Кейт так быстро выносит с алкоголя"
    gg "Não sabia que a Kate ficava bêbada tão rápido com álcool."

# game/special_events/halloween 2025.rpy:228
translate portugues halloween_start_89e99062:

    # Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    Maya "Eu gostaria de uma fantasia de bruxinha ou de alguma dríade mágica..."

# game/special_events/halloween 2025.rpy:230
translate portugues halloween_start_ccfee06e:

    # Kate "Думаю тебе пойдет"
    Kate "Acho que vai ficar bom em você."

# game/special_events/halloween 2025.rpy:232
translate portugues halloween_start_8e96eaa2:

    # Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    Sonya "E eu comprei esses dias, em vez de 1 pacote de atadura, 6 pacotes. Parece um sinal para fazer uma fantasia de múmia?"

# game/special_events/halloween 2025.rpy:234
translate portugues halloween_start_2aa5e0fb:

    # Maya "Ты как раз самая старшая"
    Maya "Você é justamente a mais velha."

# game/special_events/halloween 2025.rpy:236
translate portugues halloween_start_38bc2712:

    # Sonya "Ах ты!"
    Sonya "Ah, você!"

# game/special_events/halloween 2025.rpy:238
translate portugues halloween_start_5d38e441:

    # Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "Espera, e o Barsik? Ele também precisa de uma fantasia!"

# game/special_events/halloween 2025.rpy:239
translate portugues halloween_start_fb608953:

    # Maya "Например дракончика или мистер тыковка . . ."
    Maya "Tipo um dragãozinho ou um Senhor Abóbora..."

# game/special_events/halloween 2025.rpy:241
translate portugues halloween_start_7fd69d94:

    # Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    Sonya "Tente pegar e vestir ele, o Sr. Barsik não vai se entregar!"

# game/special_events/halloween 2025.rpy:243
translate portugues halloween_start_70adb582:

    # Maya "Что ты . . . {w}Он любит переодевашки"
    Maya "O que você tá dizendo... {w}Ele adora se fantasiar."

# game/special_events/halloween 2025.rpy:246
translate portugues halloween_start_c0036cba:

    # Sonya "Вот и кексы готовы"
    Sonya "Pronto, os cupcakes estão feitos."

# game/special_events/halloween 2025.rpy:248
translate portugues halloween_start_ae45c746:

    # gg "С кухней готово, что дальше?"
    gg "A cozinha está pronta. O que é o próximo?"

# game/special_events/halloween 2025.rpy:249
translate portugues halloween_start_354f0704:

    # Sonya "Предлагаю разделиться"
    Sonya "Sugiro nos dividirmos."

# game/special_events/halloween 2025.rpy:250
translate portugues halloween_start_07a07420:

    # Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "Eu e a Maya vamos decorar nossos quartos. Kate, você decora o banheiro."

# game/special_events/halloween 2025.rpy:251
translate portugues halloween_start_4e86ac78:

    # Sonya "[povname], будешь помогать нам?"
    Sonya "[povname], você vai nos ajudar?"

# game/special_events/halloween 2025.rpy:252
translate portugues halloween_start_564e6225:

    # gg "Окей"
    gg "Ok."

# game/special_events/halloween 2025.rpy:263
translate portugues halloween_prepare_mayaroom_7afc2c47:

    # gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "Você tem aqui um verdadeiro covil de bruxa que prepara poções com ervas."

# game/special_events/halloween 2025.rpy:264
translate portugues halloween_prepare_mayaroom_63c64e7b:

    # gg "Мм. . . пахнет приятно"
    gg "Hmm... Tem um cheiro bom."

# game/special_events/halloween 2025.rpy:266
translate portugues halloween_prepare_mayaroom_1ca099b7:

    # Maya "Хватит нюхать женскую комнату!"
    Maya "Pare de cheirar o quarto de uma mulher!"

# game/special_events/halloween 2025.rpy:268
translate portugues halloween_prepare_mayaroom_eded9518:

    # Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "Você só está aqui para cumprir minhas ordens."

# game/special_events/halloween 2025.rpy:269
translate portugues halloween_prepare_mayaroom_799aa249:

    # Maya "Поставь эти тыквы в тот угол!"
    Maya "Coloque essas abóboras naquele canto!"

# game/special_events/halloween 2025.rpy:271
translate portugues halloween_prepare_mayaroom_292858b8:

    # gg "А где пожалуйста?"
    gg "E o 'por favor', onde fica?"

# game/special_events/halloween 2025.rpy:273
translate portugues halloween_prepare_mayaroom_ad71fbb0:

    # Maya "Пожалуйста, не беси меня"
    Maya "Por favor, não me irrite."

# game/special_events/halloween 2025.rpy:275
translate portugues halloween_prepare_mayaroom_63b60e81:

    # gg "Ох"
    gg "Oh."

# game/special_events/halloween 2025.rpy:277
translate portugues halloween_prepare_mayaroom_977c102e:

    # Maya "Мм. . . нет!"
    Maya "Hmm... não!"

# game/special_events/halloween 2025.rpy:279
translate portugues halloween_prepare_mayaroom_9cb8ca98:

    # Maya "Выглядит недостаточно хорошо!"
    Maya "Não parece bom o suficiente!"

# game/special_events/halloween 2025.rpy:281
translate portugues halloween_prepare_mayaroom_3b7bbda5:

    # Maya "Давай лучше в тот угол!"
    Maya "Melhor colocar naquele outro canto!"

# game/special_events/halloween 2025.rpy:283
translate portugues halloween_prepare_mayaroom_f714e642:

    # gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    gg "Que tal você decidir exatamente onde colocar primeiro, para eu não ter que carregar essas abóboras cem vezes?"

# game/special_events/halloween 2025.rpy:285
translate portugues halloween_prepare_mayaroom_a2933c08:

    # Maya "Говорю же туда неси!"
    Maya "Eu estou dizendo, leve para lá!"

# game/special_events/halloween 2025.rpy:287
translate portugues halloween_prepare_mayaroom_4c580716:

    # gg "Точно?"
    gg "Tem certeza?"

# game/special_events/halloween 2025.rpy:288
translate portugues halloween_prepare_mayaroom_fccb4de7:

    # gg "Я больше двигать не буду, подумай хорошо"
    gg "Não vou mover de novo, pense bem."

# game/special_events/halloween 2025.rpy:290
translate portugues halloween_prepare_mayaroom_4aa933c6:

    # Maya "Хотя как сейчас тоже неплохо . . ."
    Maya "Embora, como está agora também não esteja ruim..."

# game/special_events/halloween 2025.rpy:292
translate portugues halloween_prepare_mayaroom_b2b57087:

    # Maya "Все ты свободен!"
    Maya "Pronto, está dispensado!"

# game/special_events/halloween 2025.rpy:294
translate portugues halloween_prepare_mayaroom_04c6c53d:

    # gg "Спасибо"
    gg "Obrigado."

# game/special_events/halloween 2025.rpy:295
translate portugues halloween_prepare_mayaroom_dad56d9b:

    # Maya "Если что еще позову"
    Maya "Se precisar de mais alguma coisa, eu te chamo."

# game/special_events/halloween 2025.rpy:297
translate portugues halloween_prepare_mayaroom_6a8ac153:

    # Maya "Все Давай, давай, живее!!"
    Maya "Vamos, vamos, depressa!!"

# game/special_events/halloween 2025.rpy:310
translate portugues halloween_prepare_sonyaroom_b708d644:

    # Sonya "Ой" with hpunch
    Sonya "Ai!" with hpunch

# game/special_events/halloween 2025.rpy:312
translate portugues halloween_prepare_sonyaroom_4b100306:

    # Sonya "Добро пожаловать в мою обитель!"
    Sonya "Bem-vindo à minha morada!"

# game/special_events/halloween 2025.rpy:314
translate portugues halloween_prepare_sonyaroom_7fb491df:

    # gg "У тебя в стиле майнкрафта все, очень милая комната"
    gg "Tudo no estilo Minecraft, seu quarto é muito fofo."

# game/special_events/halloween 2025.rpy:316
translate portugues halloween_prepare_sonyaroom_9dc8d94c:

    # Sonya "Да, у меня много игрушек осталось"
    Sonya "Sim, eu tenho muitos brinquedos guardados."

# game/special_events/halloween 2025.rpy:317
translate portugues halloween_prepare_sonyaroom_1174b034:

    # gg "Чем то тебе помочь?"
    gg "Posso te ajudar em alguma coisa?"

# game/special_events/halloween 2025.rpy:319
translate portugues halloween_prepare_sonyaroom_36233e2b:

    # Sonya "О можешь пожалуйста разложить остальные блоки"
    Sonya "Ah, você poderia, por favor, organizar os outros blocos?"

# game/special_events/halloween 2025.rpy:321
translate portugues halloween_prepare_sonyaroom_51e25d01:

    # gg "Хорошо давай"
    gg "Tá bom, vamos lá."

# game/special_events/halloween 2025.rpy:325
translate portugues halloween_prepare_sonyaroom_5b80a77c:

    # Sonya "Так это сюда"
    Sonya "Então, isso vai aqui."

# game/special_events/halloween 2025.rpy:331
translate portugues halloween_prepare_sonyaroom_5e22d509:

    # Sonya "О забыла я же еще кексов поставила"
    Sonya "Ah, esqueci, ainda coloquei mais cupcakes no forno."

# game/special_events/halloween 2025.rpy:340
translate portugues halloween_prepare_bathroom_5d6a2459:

    # gg "Тук-Тук, к вам можно?"
    gg "Toc-toc, posso entrar?"

# game/special_events/halloween 2025.rpy:342
translate portugues halloween_prepare_bathroom_f77e9ebe:

    # Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "Ah, você chegou na hora certa. Eu ia justamente te chamar. Quero pendurar um fantasma sobre a banheira."

# game/special_events/halloween 2025.rpy:343
translate portugues halloween_prepare_bathroom_65af0236:

    # Kate "Но не достаю, вот"
    Kate "Mas não estou conseguindo alcançar. Olha."

# game/special_events/halloween 2025.rpy:345
translate portugues halloween_prepare_bathroom_b38aeb93:

    # Kate "Вот, видишь?"
    Kate "Aqui, tá vendo?"

# game/special_events/halloween 2025.rpy:347
translate portugues halloween_prepare_bathroom_e0f0e638:

    # Kate "Хм . . . а если я встану на бортики ванной?"
    Kate "Hmm... e se eu subir na borda da banheira?"

# game/special_events/halloween 2025.rpy:349
translate portugues halloween_prepare_bathroom_e11f6927:

    # gg "Стой, это не безопасно"
    gg "Pare! Isso não é seguro."

# game/special_events/halloween 2025.rpy:358
translate portugues halloween_prepare_bathroom_01550c8f:

    # Kate "ААй!" with hpunch
    Kate "Ai!" with hpunch

# game/special_events/halloween 2025.rpy:359
translate portugues halloween_prepare_bathroom_af26ae75:

    # Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    Kate "Ah, estou muito bêbada. Que bom que você estava por perto, obrigada."

# game/special_events/halloween 2025.rpy:361
translate portugues halloween_prepare_bathroom_78e2854b:

    # gg "Я так испугался за тебя"
    gg "Fiquei tão preocupado com você."

# game/special_events/halloween 2025.rpy:362
translate portugues halloween_prepare_bathroom_766703c6:

    # gg "За тобой глаз, да глаз, будь аккуратнее"
    gg "Tem que ficar de olho em você o tempo todo, tenha mais cuidado."

# game/special_events/halloween 2025.rpy:364
translate portugues halloween_prepare_bathroom_ef29b55b:

    # Kate "Хорошо, я обещаю . . ."
    Kate "Tá bom, eu prometo..."

# game/special_events/halloween 2025.rpy:366
translate portugues halloween_prepare_bathroom_61bd7d2f:

    # Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    Kate "Pode me soltar agora? Eu não vou subir lá de novo."

# game/special_events/halloween 2025.rpy:368
translate portugues halloween_prepare_bathroom_77a74e82:

    # gg "Ты такая легкая"
    gg "Você é tão leve."

# game/special_events/halloween 2025.rpy:370
translate portugues halloween_prepare_bathroom_a0e2f8bb:

    # Kate "Спасибо"
    Kate "Obrigada."

# game/special_events/halloween 2025.rpy:383
translate portugues halloween_prepare_myroom_5692ba1f:

    # gg "Эх устал я помогать всем девочкам, и так спать хотел"
    gg "Aff, cansei de ajudar todas as garotas, e já estava com sono mesmo."

# game/special_events/halloween 2025.rpy:385
translate portugues halloween_prepare_myroom_6e92de75:

    # gg "Думаю посплю часик"
    gg "Acho que vou tirar uma soneca."

# game/special_events/halloween 2025.rpy:400
translate portugues halloween_sonya_dream_8c6442c7:

    # gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "Eu acordo com um som estranho — como se alguém tivesse arranhado a madeira com uma unha."

# game/special_events/halloween 2025.rpy:401
translate portugues halloween_sonya_dream_a05b8801:

    # gg_chat "Это на кухне?"
    gg_chat "É na cozinha?"

# game/special_events/halloween 2025.rpy:403
translate portugues halloween_sonya_dream_514bb7b5:

    # gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "Vou até a cozinha, esfregando os olhos."

# game/special_events/halloween 2025.rpy:404
translate portugues halloween_sonya_dream_045482c0:

    # gg_chat "На столе - что-то, чего там не было"
    gg_chat "Sobre a mesa — tem algo que não estava lá antes."

# game/special_events/halloween 2025.rpy:405
translate portugues halloween_sonya_dream_e953cb07:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg_chat "Uma caixa.{w} Madeira escura, os cantos reforçados com um metal vermelho-sangue."

# game/special_events/halloween 2025.rpy:406
translate portugues halloween_sonya_dream_76809b89:

    # gg "Что за чёрт . . ."
    gg "Mas que diabos..."

# game/special_events/halloween 2025.rpy:407
translate portugues halloween_sonya_dream_b5f93453:

    # gg_chat "Она не выглядит новой"
    gg_chat "Ela não parece nova."

# game/special_events/halloween 2025.rpy:408
translate portugues halloween_sonya_dream_5ac4f621:

    # gg_chat "Скорее наоборот - как будто ей сотни лет"
    gg_chat "Pelo contrário — como se tivesse centenas de anos."

# game/special_events/halloween 2025.rpy:413
translate portugues halloween_sonya_dream_a96a7298:

    # gg "Просто кто-то оставил{w} Мая? Соня?"
    gg "Só alguém deixou isso aqui?{w} Maya? Sonya?"

# game/special_events/halloween 2025.rpy:414
translate portugues halloween_sonya_dream_f60dffa6:

    # gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "É bobo, mas mesmo assim eu toco a tampa."

# game/special_events/halloween 2025.rpy:415
translate portugues halloween_sonya_dream_7aa1f899:

    # gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    gg_chat "Está quente.{w} Como se fosse pele sob meus dedos, não madeira."

# game/special_events/halloween 2025.rpy:418
translate portugues halloween_sonya_dream_d4c068d1:

    # gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg_chat "Dentro — uma moeda. Velha, desgastada, com um olho cunhado nela, e as bordas irregulares, como se alguém a tivesse mordido."

# game/special_events/halloween 2025.rpy:419
translate portugues halloween_sonya_dream_891135f2:

    # gg "И всё? . . ."
    gg "E só?..."

# game/special_events/halloween 2025.rpy:421
translate portugues halloween_sonya_dream_5bbdc303:

    # gg "Ладно, пока возьму себе"
    gg "Tudo bem, vou ficar com isso por enquanto."

# game/special_events/halloween 2025.rpy:422
translate portugues halloween_sonya_dream_63ba62de:

    # gg_chat "Я поворачиваю её в пальцах"
    gg_chat "Eu giro ela entre meus dedos."

# game/special_events/halloween 2025.rpy:423
translate portugues halloween_sonya_dream_60e7c398:

    # gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    gg_chat "Um peso estranho, como se a moeda não fosse feita de metal, mas de algo vivo."

# game/special_events/halloween 2025.rpy:427
translate portugues halloween_sonya_dream_b51c492c:

    # gg "Где же все?"
    gg "Onde está todo mundo?"

# game/special_events/halloween 2025.rpy:432
translate portugues halloween_sonya_dream_867b75aa:

    # gg "Чёрт. что за бред телевизор сам включился . . ."
    gg "Droga. Que absurdo, a TV ligou sozinha..."

# game/special_events/halloween 2025.rpy:467
translate portugues halloween_sonya_dream_cfa5487f:

    # gg "Что за бред"
    gg "Que absurdo."

# game/special_events/halloween 2025.rpy:468
translate portugues halloween_sonya_dream_6ca44626:

    # gg "Нужно проверить остальные комнаты"
    gg "Preciso verificar os outros quartos."

# game/special_events/halloween 2025.rpy:471
translate portugues halloween_sonya_dream_3109e8d5:

    # gg "Соня?"
    gg "Sonya?"

# game/special_events/halloween 2025.rpy:473
translate portugues halloween_sonya_dream_af6b4c99:

    # gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    gg "Ei... já está tarde, você está me assustando, sério."

# game/special_events/halloween 2025.rpy:476
translate portugues halloween_sonya_dream_f09531f9:

    # gg "Просто показалось . . ."
    gg "Deve ter sido só impressão..."

# game/special_events/halloween 2025.rpy:477
translate portugues halloween_sonya_dream_6fecd311:

    # gg "Просто тень . . ."
    gg "Só uma sombra..."

# game/special_events/halloween 2025.rpy:484
translate portugues halloween_sonya_dream_b989363c:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:486
translate portugues halloween_sonya_dream_e5e215bc:

    # Sonya "Как ты посмел меня разбудить!" with hpunch
    Sonya "Como ousa me acordar!" with hpunch

# game/special_events/halloween 2025.rpy:488
translate portugues halloween_sonya_dream_cbf79f81:

    # gg "Соня, ты . . . {w}ты издеваешься? . . ."
    gg "Sonya, você... {w}está brincando comigo?..."

# game/special_events/halloween 2025.rpy:490
translate portugues halloween_sonya_dream_ea23c51e:

    # gg "Это ты? Что это за грёбаные игры? . . ."
    gg "É você? Que porra de joguinho é esse?..."

# game/special_events/halloween 2025.rpy:492
translate portugues halloween_sonya_dream_c5bc9963:

    # Sonya "Имя звучит знакомо"
    Sonya "O nome soa familiar."

# game/special_events/halloween 2025.rpy:493
translate portugues halloween_sonya_dream_4db18375:

    # Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    Sonya "Mas aquela que você chamou morreu junto com esta casa."

# game/special_events/halloween 2025.rpy:494
translate portugues halloween_sonya_dream_f5284849:

    # gg "Прекрати . . ."
    gg "Pare..."

# game/special_events/halloween 2025.rpy:496
translate portugues halloween_sonya_dream_bf221ec2:

    # Sonya "Дом теперь мой.{w} Я - его хозяин"
    Sonya "A casa agora é minha.{w} Eu sou sua dona."

# game/special_events/halloween 2025.rpy:498
translate portugues halloween_sonya_dream_2c4ebaa2:

    # Sonya "Боишься?"
    Sonya "Está com medo?"

# game/special_events/halloween 2025.rpy:499
translate portugues halloween_sonya_dream_0063da0b:

    # gg "Да . . ."
    gg "Sim..."

# game/special_events/halloween 2025.rpy:501
translate portugues halloween_sonya_dream_b67571be:

    # Sonya "Хорошо"
    Sonya "Bom."

# game/special_events/halloween 2025.rpy:503
translate portugues halloween_sonya_dream_14d503b0:

    # Sonya "Страх делает кровь живой"
    Sonya "O medo torna o sangue vivo."

# game/special_events/halloween 2025.rpy:511
translate portugues halloween_sonya_dream_ab894d3a:

    # Sonya "Ты принёс монету?"
    Sonya "Você trouxe a moeda?"

# game/special_events/halloween 2025.rpy:515
translate portugues halloween_sonya_dream_c3bf29e7:

    # gg "Что? . . ."
    gg "O quê?..."

# game/special_events/halloween 2025.rpy:517
translate portugues halloween_sonya_dream_52cb176c:

    # Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "O presente que estava selado. Você o abriu."

# game/special_events/halloween 2025.rpy:518
translate portugues halloween_sonya_dream_e3369996:

    # Sonya "Ты впустил меня"
    Sonya "Você me deixou entrar."

# game/special_events/halloween 2025.rpy:520
translate portugues halloween_sonya_dream_1f166693:

    # Sonya "Я не Соня"
    Sonya "Eu não sou a Sonya."

# game/special_events/halloween 2025.rpy:524
translate portugues halloween_sonya_dream_86fe7642:

    # Sonya "Я та, что носила её лицо"
    Sonya "Eu sou aquela que usou o rosto dela."

# game/special_events/halloween 2025.rpy:525
translate portugues halloween_sonya_dream_625b9f75:

    # Sonya "И теперь ты мой"
    Sonya "E agora você é meu."

# game/special_events/halloween 2025.rpy:527
translate portugues halloween_sonya_dream_0ac9332f:

    # Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    Sonya "Tudo que você temia perder... eu já tomei."

# game/special_events/halloween 2025.rpy:529
translate portugues halloween_sonya_dream_64ed8507:

    # Sonya "А теперь - перестань сопротивляться"
    Sonya "E agora — pare de resistir."

# game/special_events/halloween 2025.rpy:533
translate portugues halloween_sonya_dream_9d9be648:

    # Sonya "Да . . . вот оно. Жар под кожей. Сок, который ты копил для кого-то другого. Теперь он мой"
    Sonya "Sim... aí está. O calor sob a pele. O suco que você guardou para outra pessoa. Agora é meu."

# game/special_events/halloween 2025.rpy:534
translate portugues halloween_sonya_dream_709e3011:

    # Sonya "Я чувствую . . . как твоя суть отделяется от костей. Как светится . . . и течёт ко мне"
    Sonya "Eu sinto... sua essência se separando dos ossos. Como brilha... e flui para mim."

# game/special_events/halloween 2025.rpy:535
translate portugues halloween_sonya_dream_5e3f412d:

    # Sonya "Скоро . . . скоро ты станешь пустым. Лёгким. И будешь спать"
    Sonya "Logo... logo você estará vazio. Leve. E você vai dormir."

# game/special_events/halloween 2025.rpy:540
translate portugues halloween_sonya_dream_8f2a3a2a:

    # Sonya "Сейчас. Отдай мне последнюю искру. Тот всполох, что зовут экстазом… я приму его как дань"
    Sonya "Agora. Entregue-me a última centelha. Aquele estremecimento que chamam de êxtase... aceitarei como tributo."

# game/special_events/halloween 2025.rpy:543
translate portugues halloween_sonya_dream_279834b2:

    # Sonya "ДА! Вот . . . пылающая монета твоей души . . . я беру её!"
    Sonya "SIM! Aí... a moeda flamejante da sua alma... eu a tomo!"

# game/special_events/halloween 2025.rpy:546
translate portugues halloween_sonya_dream_feb25de8:

    # Sonya "Спи. В твоих снах будет песок. И глаза в темноте . . . мои глаза"
    Sonya "Durma. Em seus sonhos haverá areia. E olhos na escuridão... meus olhos."

# game/special_events/halloween 2025.rpy:549
translate portugues halloween_sonya_dream_dbd299d0:

    # Sonya "Может быть, я позову снова . . . когда проголодаюсь"
    Sonya "Talvez eu chame novamente... quando tiver fome."

# game/special_events/halloween 2025.rpy:574
translate portugues halloween_maya_dream_032be6f2:

    # gg "Чёрт . . . {w}нет, нет, снова это . . ."
    gg "Droga... {w}não, não, de novo isso..."

# game/special_events/halloween 2025.rpy:576
translate portugues halloween_maya_dream_ff7388e6:

    # Maya "Эй, спокойно"
    Maya "Ei, calma."

# game/special_events/halloween 2025.rpy:578
translate portugues halloween_maya_dream_92686e55:

    # Maya "Ты в безопасности"
    Maya "Você está seguro."

# game/special_events/halloween 2025.rpy:579
translate portugues halloween_maya_dream_edf9349e:

    # gg "Где я? . . ."
    gg "Onde estou?..."

# game/special_events/halloween 2025.rpy:580
translate portugues halloween_maya_dream_de23ff68:

    # gg "Что . . . что это за место?"
    gg "O que... que lugar é este?"

# game/special_events/halloween 2025.rpy:582
translate portugues halloween_maya_dream_75c561e6:

    # Maya "Мой дом"
    Maya "Minha casa."

# game/special_events/halloween 2025.rpy:584
translate portugues halloween_maya_dream_912b1ea9:

    # gg "Почему . . . я . . . здесь? . . ."
    gg "Por que... eu... estou aqui?..."

# game/special_events/halloween 2025.rpy:586
translate portugues halloween_maya_dream_05fc8512:

    # Maya "Потому что ты боялся"
    Maya "Porque você estava com medo."

# game/special_events/halloween 2025.rpy:587
translate portugues halloween_maya_dream_657245c6:

    # Maya "И кто-то должен был тебя остановить"
    Maya "E alguém precisava pará-lo."

# game/special_events/halloween 2025.rpy:589
translate portugues halloween_maya_dream_dcba1503:

    # gg "Нет . . .{w} не приближайся"
    gg "Não... {w}não se aproxime."

# game/special_events/halloween 2025.rpy:590
translate portugues halloween_maya_dream_e91592a1:

    # gg "Я видел, как это начинается"
    gg "Eu vi como isso começa."

# game/special_events/halloween 2025.rpy:591
translate portugues halloween_maya_dream_d9b24014:

    # gg "Сначала свет, потом . . ."
    gg "Primeiro a luz, depois..."

# game/special_events/halloween 2025.rpy:594
translate portugues halloween_maya_dream_23c69478:

    # Maya "Никто не собирается тебя пугать"
    Maya "Ninguém vai assustá-lo."

# game/special_events/halloween 2025.rpy:595
translate portugues halloween_maya_dream_fb15da85:

    # gg "Это сон?"
    gg "Isso é um sonho?"

# game/special_events/halloween 2025.rpy:597
translate portugues halloween_maya_dream_ef47f8b8:

    # Maya "Возможно"
    Maya "Talvez."

# game/special_events/halloween 2025.rpy:598
translate portugues halloween_maya_dream_11e09330:

    # Maya "Но в этом сне тебе можно не убегать"
    Maya "Mas neste sonho você não precisa fugir."

# game/special_events/halloween 2025.rpy:600
translate portugues halloween_maya_dream_e96ceee2:

    # Maya "Сядь.{w} Попробуй просто дышать"
    Maya "Sente-se.{w} Tente apenas respirar."

# game/special_events/halloween 2025.rpy:601
translate portugues halloween_maya_dream_f1385d77:

    # gg "Я . . .{w} не могу"
    gg "Eu... {w}não consigo."

# game/special_events/halloween 2025.rpy:603
translate portugues halloween_maya_dream_38874e86:

    # Maya "Можешь{w}, начни только тихо"
    Maya "Você consegue{w}, apenas comece devagar."

# game/special_events/halloween 2025.rpy:605
translate portugues halloween_maya_dream_4a1eadac:

    # Maya "Ты думал, я кто-то другой, да?"
    Maya "Você pensou que eu era outra pessoa, não foi?"

# game/special_events/halloween 2025.rpy:607
translate portugues halloween_maya_dream_8d83da3f:

    # gg "После всего . . ."
    gg "Depois de tudo..."

# game/special_events/halloween 2025.rpy:608
translate portugues halloween_maya_dream_9aa85be5:

    # gg "Я и не знаю, кому верить"
    gg "Eu nem sei em quem acreditar."

# game/special_events/halloween 2025.rpy:609
translate portugues halloween_maya_dream_95a67e98:

    # Maya "Тогда не верь"
    Maya "Então não acredite."

# game/special_events/halloween 2025.rpy:610
translate portugues halloween_maya_dream_cf12428b:

    # Maya "Просто смотри"
    Maya "Apenas observe."

# game/special_events/halloween 2025.rpy:614
translate portugues halloween_maya_dream_5da82532:

    # gg "Чувствуешь?{w} Здесь нет боли"
    gg "Sente?{w} Aqui não há dor."

# game/special_events/halloween 2025.rpy:616
translate portugues halloween_maya_dream_df19ec31:

    # Maya "Ты дрожишь"
    Maya "Você está tremendo."

# game/special_events/halloween 2025.rpy:617
translate portugues halloween_maya_dream_b989363c:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:620
translate portugues halloween_maya_dream_718947a3:

    # Maya "Бедный"
    Maya "Coitado."

# game/special_events/halloween 2025.rpy:622
translate portugues halloween_maya_dream_20c45a93:

    # Maya "Я давно не видела людей"
    Maya "Faz tempo que não vejo pessoas."

# game/special_events/halloween 2025.rpy:624
translate portugues halloween_maya_dream_0f6f1ec4:

    # Maya "Вот, видишь?{w} Уже лучше"
    Maya "Viu?{w} Já está melhor."

# game/special_events/halloween 2025.rpy:625
translate portugues halloween_maya_dream_1db499d0:

    # gg "Не знаю, что это.{w} Но уже лучше"
    gg "Não sei o que é isso.{w} Mas já está melhor."

# game/special_events/halloween 2025.rpy:627
translate portugues halloween_maya_dream_927ad5b3:

    # Maya "Сейчас кое что тебя поставит на ноги"
    Maya "Agora, algo vai te colocar de pé."

# game/special_events/halloween 2025.rpy:630
translate portugues halloween_maya_dream_9add8ae1:

    # Maya "Здесь только травы"
    Maya "Aqui só tem ervas."

# game/special_events/halloween 2025.rpy:631
translate portugues halloween_maya_dream_338034af:

    # Maya "Лаванда, мята, немного корицы.{w} Попей"
    Maya "Lavanda, hortelã, um pouco de canela.{w} Beba."

# game/special_events/halloween 2025.rpy:633
translate portugues halloween_maya_dream_8f20081e:

    # gg "Что это?"
    gg "O que é isso?"

# game/special_events/halloween 2025.rpy:634
translate portugues halloween_maya_dream_3fdb7032:

    # Maya "Это магия"
    Maya "É magia."

# game/special_events/halloween 2025.rpy:636
translate portugues halloween_maya_dream_7c4cba20:

    # Maya "Лечебное зелье, с небольшим побочным эфектом"
    Maya "Uma poção curativa, com um pequeno efeito colateral."

# game/special_events/halloween 2025.rpy:638
translate portugues halloween_maya_dream_59e469a3:

    # gg "Каким еще эфектом"
    gg "Que tipo de efeito colateral?"

# game/special_events/halloween 2025.rpy:641
translate portugues halloween_maya_dream_809b7a3a:

    # Maya "Просто отдохни.{w} Не думай об этом"
    Maya "Apenas descanse.{w} Não pense nisso."

# game/special_events/halloween 2025.rpy:643
translate portugues halloween_maya_dream_ae92cf27:

    # gg "А если я снова усну?"
    gg "E se eu adormecer de novo?"

# game/special_events/halloween 2025.rpy:645
translate portugues halloween_maya_dream_c1fe7b6b:

    # Maya "Тогда пусть этот сон, будет приятным"
    Maya "Então que este sonho seja agradável."

# game/special_events/halloween 2025.rpy:650
translate portugues halloween_maya_dream_6274b812:

    # Maya "Да . . . вот так . . . Ты так нуждаешься в этом. Я знала"
    Maya "Sim... assim... Você precisa tanto disso. Eu sabia."

# game/special_events/halloween 2025.rpy:651
translate portugues halloween_maya_dream_c101e994:

    # gg "Майя . . . Я . . ."
    gg "Maya... Eu..."

# game/special_events/halloween 2025.rpy:652
translate portugues halloween_maya_dream_5e852895:

    # Maya "Какая прекрасная . . . реакция. Всё для меня?"
    Maya "Que bela... reação. Tudo para mim?"

# game/special_events/halloween 2025.rpy:653
translate portugues halloween_maya_dream_cab511be:

    # Maya "О-ох . . . Да . . . Вот так"
    Maya "Oh-oh... Sim... Assim."

# game/special_events/halloween 2025.rpy:654
translate portugues halloween_maya_dream_87be51c0:

    # Maya "Да-да-да! Вот здесь! Чувствую, как ты пульсируешь!"
    Maya "Sim-sim-sim! Bem aqui! Sinto você pulsando!"

# game/special_events/halloween 2025.rpy:656
translate portugues halloween_maya_dream_aafdbf4d:

    # Maya "Aaa-ох . . ."
    Maya "Aaa-ah..."

# game/special_events/halloween 2025.rpy:659
translate portugues halloween_maya_dream_162eda56:

    # Maya "Идеально . . . Ты был идеален . . . Запомни это . . . Запомни меня . . ."
    Maya "Perfeito... Você foi perfeito... Lembre-se disso... Lembre-se de mim..."

# game/special_events/halloween 2025.rpy:687
translate portugues halloween_kate_dream_2a6a4db2:

    # gg "Кейт? . . ."
    gg "Kate?..."

# game/special_events/halloween 2025.rpy:692
translate portugues halloween_kate_dream_3c8f411e:

    # gg "Что . . . что происходит?"
    gg "O que... o que está acontecendo?"

# game/special_events/halloween 2025.rpy:696
translate portugues halloween_kate_dream_6b307304:

    # Kate "{sc}{size=*1.2}Ты"
    Kate "{sc}{size=*1.2}Você"

# game/special_events/halloween 2025.rpy:698
translate portugues halloween_kate_dream_21111df8:

    # Kate "Вторгся в середину ритуала"
    Kate "Invadiu o meio do ritual."

# game/special_events/halloween 2025.rpy:699
translate portugues halloween_kate_dream_2caa82ea:

    # Kate "Твоё присутствие нарушило поток"
    Kate "Sua presença perturbou o fluxo."

# game/special_events/halloween 2025.rpy:701
translate portugues halloween_kate_dream_bc58cb35:

    # gg "Гх . . . {w}Прости, я не знал . . ."
    gg "Ah... {w}Desculpe, eu não sabia..."

# game/special_events/halloween 2025.rpy:703
translate portugues halloween_kate_dream_91b43246:

    # Kate "Ты не просто услышал. Ты почувствовал зов"
    Kate "Você não apenas ouviu. Você sentiu o chamado."

# game/special_events/halloween 2025.rpy:705
translate portugues halloween_kate_dream_211858ba:

    # Kate "Иначе ты бы не вошёл"
    Kate "Caso contrário, você não teria entrado."

# game/special_events/halloween 2025.rpy:707
translate portugues halloween_kate_dream_0f5b8117:

    # Kate "Люди носят маски каждый день"
    Kate "As pessoas usam máscaras todos os dias."

# game/special_events/halloween 2025.rpy:708
translate portugues halloween_kate_dream_4fc89b6e:

    # Kate "Они молятся свету, а в темноте становятся теми, кем боятся быть"
    Kate "Elas rezam à luz, e na escuridão se tornam aquilo que temem ser."

# game/special_events/halloween 2025.rpy:710
translate portugues halloween_kate_dream_fd7485b5:

    # gg "Кейт, пожалуйста . . . остановись"
    gg "Kate, por favor... pare."

# game/special_events/halloween 2025.rpy:712
translate portugues halloween_kate_dream_21bb7ba7:

    # Kate "Это имя лишь оболочка, которую я носила"
    Kate "Esse nome é apenas uma casca que eu usei."

# game/special_events/halloween 2025.rpy:713
translate portugues halloween_kate_dream_54373c98:

    # Kate "Сейчас я — та, кто принимает исповедь. А исповедь требует . . . отдачи"
    Kate "Agora eu sou aquela que ouve a confissão. E a confissão exige... entrega."

# game/special_events/halloween 2025.rpy:715
translate portugues halloween_kate_dream_6aceb243:

    # Kate "Ты боишься. Это хорошо. Страх очищает"
    Kate "Você tem medo. Isso é bom. O medo purifica."

# game/special_events/halloween 2025.rpy:716
translate portugues halloween_kate_dream_6993148d:

    # Kate "Но за страхом . . . всегда прячется желание"
    Kate "Mas atrás do medo... sempre se esconde o desejo."

# game/special_events/halloween 2025.rpy:718
translate portugues halloween_kate_dream_5f463a3c:

    # Kate "Мой ритуал требует энергии. Чистой, незамутнённой лицемерием"
    Kate "Meu ritual exige energia. Pura, não turvada pela hipocrisia."

# game/special_events/halloween 2025.rpy:720
translate portugues halloween_kate_dream_e52aea01:

    # Kate "Твой страх — это начало. Но чтобы завершить круг . . . нужно"
    Kate "Seu medo é o começo. Mas para completar o círculo... é preciso"

# game/special_events/halloween 2025.rpy:722
translate portugues halloween_kate_dream_6c364d34:

    # Kate "Нечто большее"
    Kate "Algo mais."

# game/special_events/halloween 2025.rpy:725
translate portugues halloween_kate_dream_4729db36:

    # gg "Что ты хочешь? . . . "
    gg "O que você quer?..."

# game/special_events/halloween 2025.rpy:727
translate portugues halloween_kate_dream_14ab3952:

    # Kate "Я хочу ту часть себя, которая не боится тьмы"
    Kate "Eu quero aquela parte de você que não tem medo da escuridão."

# game/special_vents/halloween 2025.rpy:729
translate portugues halloween_kate_dream_d9bfbc43:

    # Kate "Которая жаждет её"
    Kate "Que a deseja."

# game/special_events/halloween 2025.rpy:730
translate portugues halloween_kate_dream_2a999a14:

    # Kate "Это не сердце. Это — пустота, которую ты пытался заполнить ложью"
    Kate "Não é o coração. É o vazio que você tentou preencher com mentiras."

# game/special_events/halloween 2025.rpy:732
translate portugues halloween_kate_dream_62c66a6e:

    # Kate "Позволь мне заполнить её истиной"
    Kate "Deixe-me preenchê-lo com a verdade."

# game/special_events/halloween 2025.rpy:733
translate portugues halloween_kate_dream_6f6518cc:

    # gg "Гхк . . ."
    gg "Ah..."

# game/special_events/halloween 2025.rpy:734
translate portugues halloween_kate_dream_a32c9003:

    # gg "Я не могу подвинуться"
    gg "Não consigo me mexer."

# game/special_events/halloween 2025.rpy:736
translate portugues halloween_kate_dream_12b2e70f:

    # Kate "Не сопротивляйся. Это тоже часть ритуала"
    Kate "Não resista. Isso também faz parte do ritual."

# game/special_events/halloween 2025.rpy:738
translate portugues halloween_kate_dream_fd3fd304:

    # Kate "Ты отдаёшь — я принимаю. Так было всегда"
    Kate "Você entrega — eu aceito. Sempre foi assim."

# game/special_events/halloween 2025.rpy:740
translate portugues halloween_kate_dream_7cee1ec3:

    # Kate "Видишь? Твоё тело уже понимает. Оно помнит правила"
    Kate "Viu? Seu corpo já entende. Ele se lembra das regras."

# game/special_events/halloween 2025.rpy:753
translate portugues halloween_kate_dream_e36daadf:

    # Kate "Это дрожь . . . пробуждения"
    Kate "Este tremor... do despertar."

# game/special_events/halloween 2025.rpy:761
translate portugues halloween_kate_dream_18a21981:

    # Kate "Тише. Не мешай"
    Kate "Calma. Não atrapalhe."

# game/special_events/halloween 2025.rpy:762
translate portugues halloween_kate_dream_64b1ddea:

    # Kate "Я только знакомлюсь с тем, что моё"
    Kate "Estou apenas conhecendo o que é meu."

# game/special_events/halloween 2025.rpy:764
translate portugues halloween_kate_dream_fa83af8e:

    # Kate "Ты . . . для этого . . .{w} и пришёл . . ."
    Kate "Você... veio...{w} para isso..."

# game/special_events/halloween 2025.rpy:765
translate portugues halloween_kate_dream_475590f4:

    # Kate "Чтоб тебя . . . размяли . . .{w} взяли в руки . . ."
    Kate "Para ser... amassado...{w} tomado nas mãos..."

# game/special_events/halloween 2025.rpy:767
translate portugues halloween_kate_dream_020e238d:

    # gg "Агхх . ."
    gg "Ahh..."

# game/special_events/halloween 2025.rpy:768
translate portugues halloween_kate_dream_0c86ca7b:

    # Kate "Да!"
    Kate "Sim!"

# game/special_events/halloween 2025.rpy:769
translate portugues halloween_kate_dream_d0b4a1d1:

    # Kate "Вот так"
    Kate "Assim."

# game/special_events/halloween 2025.rpy:770
translate portugues halloween_kate_dream_854a0208:

    # Kate "Рвись! Кончай!{w} Отдавай это мне"
    Kate "Entregue-se! Goze!{w} Entregue isso a mim."

# game/special_events/halloween 2025.rpy:772
translate portugues halloween_kate_dream_4402c96f:

    # Kate "Ахахаха ха ха"
    Kate "Ahahahaha ha ha"

# game/special_events/halloween 2025.rpy:774
translate portugues halloween_kate_dream_c8fc9712:

    # Kate "Видишь? Даже твой пик — в моей власти"
    Kate "Viu? Até seu clímax está sob meu controle."

# game/special_events/halloween 2025.rpy:775
translate portugues halloween_kate_dream_ab9b9a56:

    # Kate "Я решаю когда и как"
    Kate "Eu decido quando e como."

# game/special_events/halloween 2025.rpy:777
translate portugues halloween_kate_dream_d8951333:

    # Kate "А теперь хватит игр"
    Kate "E agora, chega de brincadeiras."

# game/special_events/halloween 2025.rpy:786
translate portugues halloween_kate_dream_088e1fcf:

    # Kate "Всё, время нежностей кончилось"
    Kate "Pronto, o tempo das gentilezas acabou."

# game/special_events/halloween 2025.rpy:789
translate portugues halloween_kate_dream_d84a2e22:

    # Kate "Молчи и терпи. Это плата за твой глупый интерес"
    Kate "Fique quieto e aguente. É o preço pelo seu interesse idiota."

# game/special_events/halloween 2025.rpy:791
translate portugues halloween_kate_dream_959b5201:

    # Kate "А-ах . . . Так . . . Глубоко . . ."
    Kate "Ah... Assim... Fundo..."

# game/special_events/halloween 2025.rpy:794
translate portugues halloween_kate_dream_ad7fd02e:

    # Kate "Да . . . Вот так"
    Kate "Sim... Assim."

# game/special_events/halloween 2025.rpy:795
translate portugues halloween_kate_dream_e0d93040:

    # Kate "Отдай мне это.{w} Всю свою подавленную тьму.{w} Всю свою скрытую жажду"
    Kate "Entregue-me isso.{w} Toda a sua escuridão reprimida.{w} Todo o seu desejo oculto."

# game/special_events/halloween 2025.rpy:796
translate portugues halloween_kate_dream_3f099ced:

    # gg "Я . . . я не могу . . ."
    gg "Eu... eu não consigo..."

# game/special_events/halloween 2025.rpy:797
translate portugues halloween_kate_dream_0e94451f:

    # Kate "Можешь. И ты сделаешь.{w} Сейчас"
    Kate "Consegue. E vai fazer.{w} Agora."

# game/special_events/halloween 2025.rpy:800
translate portugues halloween_kate_dream_866aa006:

    # Kate "А-ах . . ."
    Kate "Ah..."

# game/special_events/halloween 2025.rpy:802
translate portugues halloween_kate_dream_25c1049a:

    # Kate "Ха.."
    Kate "Ha..."

# game/special_events/halloween 2025.rpy:804
translate portugues halloween_kate_dream_c4c58437:

    # Kate "Ритуал завершён. Ты отдал достаточно . . . чтобы я продолжила свой путь"
    Kate "O ritual está completo. Você entregou o suficiente... para que eu continue meu caminho."

# game/special_events/halloween 2025.rpy:806
translate portugues halloween_kate_dream_c5ab54b2:

    # Kate "Ты проснёшься пустым.{w} Безнадёжно пустым. И, может быть, снова выползешь ко мне . . ."
    Kate "Você vai acordar vazio.{w} Irremediavelmente vazio. E talvez rasteje até mim de novo..."

# game/special_events/halloween 2025.rpy:807
translate portugues halloween_kate_dream_0eb6bd42:

    # Kate "Чтобы снова украсть немного этой полноты"
    Kate "Para roubar um pouco dessa plenitude novamente."

# game/special_events/halloween 2025.rpy:809
translate portugues halloween_kate_dream_2f7f297c:

    # Kate "Хотя бы на мгновение"
    Kate "Mesmo que por um instante."

# game/special_events/halloween 2025.rpy:832
translate portugues halloween_kate_dream_b989363c:

    # gg ". . ."
    gg "..."

# game/special_events/halloween 2025.rpy:833
translate portugues halloween_kate_dream_5174a63c:

    # gg "Приснится же такое . . ."
    gg "Que sonho foi esse..."

# game/special_events/halloween 2025.rpy:835
translate portugues halloween_kate_dream_13dee7c8:

    # "Тыква хранит воспоминания"
    "A abóbora guarda memórias."

# game/special_events/halloween 2025.rpy:836
translate portugues halloween_kate_dream_bb8e42de:

    # "Коснись её, чтобы вновь увидеть сцену"
    "Toque nela para ver a cena novamente."

translate portugues strings:

    # game/special_events/halloween 2025.rpy:15
    old "Сон с Кейт"
    new "Sonho com a Kate"

# TODO: Translation updated at 2026-01-27 02:10

# game/special_events/halloween 2025.rpy:727
translate portugues halloween_kate_dream_195da2d7:

    # Kate "Я хочу ту часть тебя, которая не боится тьмы"
    Kate "Quero a parte de você que não teme a escuridão"

