﻿# TODO: Translation updated at 2026-01-21 02:05

translate portugues strings:

    # game/screens.rpy:427
    old "Назад"
    new "Voltar"

    # game/screens.rpy:429
    old "Пропуск"
    new "Pular"

    # game/screens.rpy:430
    old "Авто"
    new "Auto"

    # game/screens.rpy:431
    old "Сохранить"
    new "Salvar"

    # game/screens.rpy:432
    old "Б.Сохр"
    new "Salv. Ráp."

    # game/screens.rpy:433
    old "Б.Загр"
    new "Carreg. Ráp."

    # game/screens.rpy:434
    old "Настройки"
    new "Configurações"

    # game/screens.rpy:583
    old "НОВАЯ ИГРА"
    new "NOVO JOGO"

    # game/screens.rpy:584
    old "ЗАГРУЗИТЬ"
    new "CARREGAR"

    # game/screens.rpy:585
    old "НАСТРОЙКИ"
    new "CONFIGURAÇÕES"

    # game/screens.rpy:586
    old "О ИГРЕ"
    new "SOBRE"

    # game/screens.rpy:593
    old "ИСТОРИЯ"
    new "HISTÓRICO"

    # game/screens.rpy:594
    old "СОХРАНИТЬ"
    new "SALVAR"

    # game/screens.rpy:599
    old "ЗАВЕРШИТЬ ПОВТОР"
    new "ENCERRAR REPLAY"

    # game/screens.rpy:601
    old "МЕНЮ"
    new "MENU"

    # game/screens.rpy:606
    old "ВЫХОД"
    new "SAIR"

    # game/screens.rpy:758
    old "Вернуться"
    new "Voltar"

    # game/screens.rpy:912
    old "Версия [config.version!t]\n"
    new "Versão [config.version!t]\n"

    # game/screens.rpy:951
    old "{} страница"
    new "Página {}"

    # game/screens.rpy:951
    old "Автосохранения"
    new "Salvamentos automáticos"

    # game/screens.rpy:951
    old "Быстрые сохранения"
    new "Salvamentos rápidos"

    # game/screens.rpy:999
    old "{#file_time}%A, %d %B %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    # game/screens.rpy:999
    old "Пустой слот"
    new "Espaço vazio"

    # game/screens.rpy:1020
    old "<"
    new "<"

    # game/screens.rpy:1024
    old "{#auto_page}А"
    new "{#auto_page}A"

    # game/screens.rpy:1027
    old "{#quick_page}Б"
    new "{#quick_page}R"

    # game/screens.rpy:1033
    old ">"
    new ">"

    # game/screens.rpy:1105
    old "Всего текста"
    new "Todo o texto"

    # game/screens.rpy:1106
    old "После выборов"
    new "Após as escolhas"

    # game/screens.rpy:1112
    old "Режим экрана"
    new "Modo de exibição"

    # game/screens.rpy:1113
    old "Оконный"
    new "Janela"

    # game/screens.rpy:1114
    old "Полный"
    new "Tela cheia"

    # game/screens.rpy:1118
    old "Язык"
    new "Idioma"

    # game/screens.rpy:1151
    old "Скорость текста"
    new "Velocidade do texto"

    # game/screens.rpy:1155
    old "Скорость авточтения"
    new "Velocidade da leitura automática"

    # game/screens.rpy:1159
    old "Прозрачность окна"
    new "Transparência da caixa de texto"

    # game/screens.rpy:1165
    old "Громкость музыки"
    new "Volume da música"

    # game/screens.rpy:1172
    old "Громкость звуков"
    new "Volume dos efeitos sonoros"

    # game/screens.rpy:1178
    old "Тест"
    new "Teste"

    # game/screens.rpy:1182
    old "Громкость голоса"
    new "Volume da voz"

    # game/screens.rpy:1193
    old "Без звука"
    new "Sem som"

    # game/screens.rpy:1378
    old "История диалогов пуста."
    new "O histórico de diálogos está vazio."

    # game/screens.rpy:1621
    old "Ты правда хочешь выйти"
    new "Você realmente quer sair?"

    # game/screens.rpy:1628
    old "Да"
    new "Sim"

    # game/screens.rpy:1632
    old "Нет"
    new "Não"

    # game/screens.rpy:1686
    old "Пропускаю"
    new "Pulando"

    # game/screens.rpy:1997
    old "Меню"
    new "Menu"

    # game/screens.rpy:2362
    old "д"
    new "d"

    # game/screens.rpy:2488
    old "Персонажи"
    new "Personagens"

    # game/screens.rpy:2608
    old "Подсказка"
    new "Dica"

    # game/screens.rpy:2627
    old "Отслеживать квест"
    new "Rastrear missão"

    # game/screens.rpy:2636
    old "Перестать отслеживать"
    new "Parar de acompanhar"

    # game/screens.rpy:2657
    old "Продвигайтесь по сюжету"
    new "Progrida na história"# TODO: Translation updated at 2026-01-27 02:10

translate portugues strings:

    # game/screens.rpy:574
    old "ИГРАЙ РАНЬШЕ ДРУГИХ"
    new "ASSINE E JOGUE ANTES"

# TODO: Translation updated at 2026-01-27 02:18

translate portugues strings:

    # game/screens.rpy:602
    old "Бесплатные девлоги"
    new "Devlogs grátis"

