﻿# TODO: Translation updated at 2026-01-21 02:05

# game/script.rpy:25
translate portugues start_fe40380a:

    # "Вы уже играли в нашу игру раньше?"
    "Você já jogou o nosso jogo antes?"

# game/script.rpy:26
translate portugues start_dc363420:

    # "Интро содержит важные сюжетные события и знакомство с миром игры"
    "A introdução contém eventos importantes da trama e apresenta o mundo do jogo."

# game/script.rpy:27
translate portugues start_96a117ce:

    # "Если пропустить его при первом прохождении, вы рискуете упустить значительную часть истории и контента"
    "Se pular na primeira vez que jogar, você corre o risco de perder uma parte significativa da história e do conteúdo."

translate portugues strings:

    # game/script.rpy:15
    old "И как же вас зовут"
    new "E qual é o seu nome?"

    # game/script.rpy:17
    old "Дэн"
    new "Dan"

    # game/script.rpy:29
    old "Начать игру"
    new "Iniciar jogo"

    # game/script.rpy:31
    old "Пропустить интро"
    new "Pular introdução"