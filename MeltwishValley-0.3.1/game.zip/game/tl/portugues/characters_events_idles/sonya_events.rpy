﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/sonya_events.rpy:6
translate portugues sonya_scene1_morning_kitchen_a756dbc0:

    # gg "Утречко"
    gg "Bom dia"

# game/characters_events_idles/sonya_events.rpy:12
translate portugues sonya_scene1_morning_kitchen_2641e2c9:

    # Sonya "Доброе утро"
    Sonya "Bom dia"

# game/characters_events_idles/sonya_events.rpy:14
translate portugues sonya_scene1_morning_kitchen_50dcebad:

    # Sonya "Как тебе спалось?"
    Sonya "Dormiu bem?"

# game/characters_events_idles/sonya_events.rpy:16
translate portugues sonya_scene1_morning_kitchen_9fdea20a:

    # gg "Нормально"
    gg "Normal"

# game/characters_events_idles/sonya_events.rpy:18
translate portugues sonya_scene1_morning_kitchen_c923e04f:

    # gg "Тихо"
    gg "Silêncio"

# game/characters_events_idles/sonya_events.rpy:20
translate portugues sonya_scene1_morning_kitchen_367f1af9:

    # Sonya "Там диван конечно старый"
    Sonya "O sofá é velho, claro"

# game/characters_events_idles/sonya_events.rpy:22
translate portugues sonya_scene1_morning_kitchen_0a0eba96:

    # Sonya "Но удобный"
    Sonya "Mas é confortável"

# game/characters_events_idles/mc_events.rpy:24
translate portugues sonya_scene1_morning_kitchen_0f37c26d:

    # gg "Я заметил"
    gg "Percebi"

# game/characters_events_idles/sonya_events.rpy:26
translate portugues sonya_scene1_morning_kitchen_93b6fb71:

    # Sonya "Ты уже успел пройтись по деревне?"
    Sonya "Já deu uma volta pela vila?"

# game/characters_events_idles/sonya_events.rpy:28
translate portugues sonya_scene1_morning_kitchen_0839a090:

    # Sonya "Или пока только дом вспоминаешь?"
    Sonya "Ou ainda está se acostumando com a casa?"

# game/characters_events_idles/sonya_events.rpy:30
translate portugues sonya_scene1_morning_kitchen_12aa0f18:

    # gg "Немного посмотрел"
    gg "Dei uma olhada"

# game/characters_events_idles/sonya_events.rpy:32
translate portugues sonya_scene1_morning_kitchen_c33e58bc:

    # gg "Тут . . . Хорошие люди"
    gg "Aqui... As pessoas são boas"

# game/characters_events_idles/sonya_events.rpy:34
translate portugues sonya_scene1_morning_kitchen_c8772e87:

    # Sonya "Да"
    Sonya "Sim"

# game/characters_events_idles/sonya_events.rpy:36
translate portugues sonya_scene1_morning_kitchen_ed137d91:

    # Sonya "Ты к этому быстро привыкаешь"
    Sonya "Você se acostuma rápido com isso"

# game/characters_events_idles/sonya_events.rpy:48
translate portugues sonya_scene1_morning_kitchen_e45ac0f2:

    # Sonya "Если вдруг проголодаешься — бери что хочешь"
    Sonya "Se ficar com fome, pegue o que quiser"

# game/characters_events_idles/sonya_events.rpy:50
translate portugues sonya_scene1_morning_kitchen_947178ba:

    # Sonya "У нас обычно никто особо не спрашивает"
    Sonya "Aqui normalmente ninguém pergunta muito"

# game/characters_events_idles/sonya_events.rpy:56
translate portugues sonya_scene1_morning_kitchen_04c6c53d:

    # gg "Спасибо"
    gg "Obrigado"

# game/characters_events_idles/sonya_events.rpy:60
translate portugues sonya_scene1_morning_kitchen_77469d65:

    # Sonya "А вообще"
    Sonya "Mas, falando nisso"

# game/characters_events_idles/sonya_events.rpy:62
translate portugues sonya_scene1_morning_kitchen_ebb5bb0f:

    # Sonya "Как тебе здесь?"
    Sonya "O que você acha daqui?"

# game/characters_events_idles/sonya_events.rpy:66
translate portugues sonya_scene1_morning_kitchen_77102205:

    # Sonya "В смысле . . . жить вместе"
    Sonya "Digo... Morar junto"

# game/characters_events_idles/sonya_events.rpy:70
translate portugues sonya_scene1_morning_kitchen_dcf6ae5e:

    # gg "Непривычно"
    gg "Estranho"

# game/characters_events_idles/sonya_events.rpy:72
translate portugues sonya_scene1_morning_kitchen_0dd94278:

    # gg "Но нормально"
    gg "Mas tudo bem"

# game/characters_events_idles/sonya_events.rpy:74
translate portugues sonya_scene1_morning_kitchen_c8772e87_1:

    # Sonya "Да"
    Sonya "Sim"

# game/characters_events_idles/sonya_events.rpy:76
translate portugues sonya_scene1_morning_kitchen_8aa7b1fd:

    # Sonya "Мы тоже не сразу привыкли"
    Sonya "Nós também não nos acostumamos de imediato"

# game/characters_events_idles/sonya_events.rpy:78
translate portugues sonya_scene1_morning_kitchen_270848f3:

    # Sonya "Когда людей в доме становится больше"
    Sonya "Quando mais pessoas chegam na casa"

# game/characters_events_idles/sonya_events.rpy:80
translate portugues sonya_scene1_morning_kitchen_816d8504:

    # Sonya "Всё немного меняется"
    Sonya "Tudo muda um pouco"

# game/characters_events_idles/sonya_events.rpy:99
translate portugues sonya_scene1_morning_kitchen_7b099c93:

    # gg_chat "Мае — завтрак"
    gg_chat "Para a Maya — café da manhã"

# game/characters_events_idles/sonya_events.rpy:100
translate portugues sonya_scene1_morning_kitchen_fcffc8ef:

    # gg_chat "Если не успею — купи, пожалуйста, продукты"
    gg_chat "Se eu não der tempo — por favor, compre mantimentos"

# game/characters_events_idles/sonya_events.rpy:109
translate portugues sonya_scene1_morning_kitchen_7158ba01:

    # gg "Ладно, я пойду"
    gg "Tudo bem, vou indo"

# game/characters_events_idles/sonya_events.rpy:111
translate portugues sonya_scene1_morning_kitchen_fbb535a1:

    # gg "Не буду мешать"
    gg "Não vou atrapalhar"

# game/characters_events_idles/sonya_events.rpy:113
translate portugues sonya_scene1_morning_kitchen_98963b02:

    # Sonya "Да ты и не мешаешь"
    Sonya "Mas você nem está atrapalhando"

# game/characters_events_idles/sonya_events.rpy:117
translate portugues sonya_scene1_morning_kitchen_d24f6aaf:

    # Sonya "Но . . . хорошо"
    Sonya "Mas... Tudo bem"

# game/characters_events_idles/sonya_events.rpy:133
translate portugues sonya_scene2_day_girlroom_68c12557:

    # gg "Сонь"
    gg "Sônia"

# game/characters_events_idles/sonya_events.rpy:137
translate portugues sonya_scene2_day_girlroom_d3ca52ed:

    # gg "Ты не знаешь, где у вас аптечка?"
    gg "Você sabe onde fica o kit de primeiros socorros?"

# game/characters_events_idles/sonya_events.rpy:139
translate portugues sonya_scene2_day_girlroom_fb949c9e:

    # Sonya "Аптечка?"
    Sonya "Kit de primeiros socorros?"

# game/characters_events_idles/sonya_events.rpy:141
translate portugues sonya_scene2_day_girlroom_695184c3:

    # Sonya "А что случилось?"
    Sonya "O que aconteceu?"

# game/characters_events_idles/sonya_events.rpy:143
translate portugues sonya_scene2_day_girlroom_55820831:

    # gg "Да так"
    gg "Ah, nada"

# game/characters_events_idles/sonya_events.rpy:145
translate portugues sonya_scene2_day_girlroom_41aa37fb:

    # gg "Поцарапался.{w} Ерунда"
    gg "Me arranhei.{w} Bobagem"

# game/characters_events_idles/sonya_events.rpy:149
translate portugues sonya_scene2_day_girlroom_06e5075f:

    # Sonya "Подожди"
    Sonya "Espera"

# game/characters_events_idles/sonya_events.rpy:151
translate portugues sonya_scene2_day_girlroom_b43c4c5e:

    # Sonya "Сейчас все сделаем"
    Sonya "Vamos cuidar disso agora"

# game/characters_events_idles/sonya_events.rpy:155
translate portugues sonya_scene2_day_girlroom_7cc8260f:

    # Sonya "А ты почти без вещей приехал"
    Sonya "E você veio quase sem nada"

# game/characters_events_idles/sonya_events.rpy:157
translate portugues sonya_scene2_day_girlroom_b1f32e8a:

    # Sonya "Так и планировал"
    Sonya "Já planejava assim?"

# game/characters_events_idles/sonya_events.rpy:158
translate portugues sonya_scene2_day_girlroom_06e860df:

    # Sonya "Или просто не успел собрать?"
    Sonya "Ou só não deu tempo de arrumar?"

# game/characters_events_idles/sonya_events.rpy:164
translate portugues sonya_scene2_day_girlroom_cc881b3b:

    # gg "Скорее второе"
    gg "Mais a segunda opção"

# game/characters_events_idles/sonya_events.rpy:166
translate portugues sonya_scene2_day_girlroom_72e0315a:

    # gg "Решил не тащить за собой старое"
    gg "Decidi não carregar o passado comigo"

# game/characters_events_idles/sonya_events.rpy:169
translate portugues sonya_scene2_day_girlroom_fef188e6:

    # gg "Посмотреть, как будет"
    gg "Ver como seria"

# game/characters_events_idles/sonya_events.rpy:171
translate portugues sonya_scene2_day_girlroom_4b248478:

    # Sonya "Будто новая жизнь"
    Sonya "Como uma vida nova"

# game/characters_events_idles/sonya_events.rpy:173
translate portugues sonya_scene2_day_girlroom_84c6a1f8:

    # Sonya "Ты получается больше утренний человек?"
    Sonya "Então você é mais uma pessoa matutina?"

# game/characters_events_idles/sonya_events.rpy:175
translate portugues sonya_scene2_day_girlroom_e550b517:

    # Sonya "Или нет?"
    Sonya "Ou não?"

# game/characters_events_idles/sonya_events.rpy:177
translate portugues sonya_scene2_day_girlroom_254f159a:

    # gg "Раньше — скорее вечерний"
    gg "Antes era mais noturno"

# game/characters_events_idles/sonya_events.rpy:179
translate portugues sonya_scene2_day_girlroom_bf5f3aef:

    # gg "А здесь почему-то весь день на ногах"
    gg "Mas aqui, por algum motivo, fico em pé o dia todo"

# game/characters_events_idles/sonya_events.rpy:181
translate portugues sonya_scene2_day_girlroom_633d56a5:

    # gg "Сам удивляюсь"
    gg "Até eu me surpreendo"

# game/characters_events_idles/sonya_events.rpy:183
translate portugues sonya_scene2_day_girlroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "Sério?"

# game/characters_events_idles/sonya_events.rpy:185
translate portugues sonya_scene2_day_girlroom_7e52f22d:

    # Sonya "Значит, деревня на тебя хорошо действует"
    Sonya "Então a vila está fazendo bem a você"

# game/characters_events_idles/sonya_events.rpy:187
translate portugues sonya_scene2_day_girlroom_d0a33041:

    # Sonya "И часто ты так . . ."
    Sonya "E você costuma se..."

# game/characters_events_idles/sonya_events.rpy:189
translate portugues sonya_scene2_day_girlroom_25b95c9d:

    # Sonya "Царапаешься?"
    Sonya "Arranhar?"

# game/characters_events_idles/sonya_events.rpy:191
translate portugues sonya_scene2_day_girlroom_8f76c3f1:

    # gg "Не особо"
    gg "Não muito"

# game/characters_events_idles/sonya_events.rpy:193
translate portugues sonya_scene2_day_girlroom_2171a9af:

    # gg "Просто ещё не привык к местной фауне"
    gg "Só ainda não me acostumei com a fauna local"

# game/characters_events_idles/sonya_events.rpy:195
translate portugues sonya_scene2_day_girlroom_09b9d111:

    # Sonya "А . . ."
    Sonya "Ah..."

# game/characters_events_idles/sonya_events.rpy:196
translate portugues sonya_scene2_day_girlroom_521ff667:

    # Sonya "Тогда понятно"
    Sonya "Então entendi"

# game/characters_events_idles/sonya_events.rpy:203
translate portugues sonya_scene2_day_girlroom_6b068d33:

    # gg "Ты так аккуратно всё делаешь . . ."
    gg "Você faz tudo com tanto cuidado..."

# game/characters_events_idles/sonya_events.rpy:205
translate portugues sonya_scene2_day_girlroom_bbcf86fd:

    # gg "Это привычка?"
    gg "É costume?"

# game/characters_events_idles/sonya_events.rpy:207
translate portugues sonya_scene2_day_girlroom_a174002e:

    # Sonya "Ага"
    Sonya "Aham"

# game/characters_events_idles/sonya_events.rpy:208
translate portugues sonya_scene2_day_girlroom_5e6a7fb2:

    # Sonya "Мне так спокойнее"
    Sonya "Me sinto mais tranquila assim"

# game/characters_events_idles/sonya_events.rpy:210
translate portugues sonya_scene2_day_girlroom_ea7be3c1:

    # Sonya "Когда всё сделано как надо"
    Sonya "Quando tudo está feito do jeito certo"

# game/characters_events_idles/sonya_events.rpy:212
translate portugues sonya_scene2_day_girlroom_d9f6fc3a:

    # Sonya "Готово"
    Sonya "Pronto"

# game/characters_events_idles/sonya_events.rpy:216
translate portugues sonya_scene2_day_girlroom_04c6c53d:

    # gg "Спасибо"
    gg "Obrigado"

# game/characters_events_idles/sonya_events.rpy:218
translate portugues sonya_scene2_day_girlroom_1c0e0b38:

    # Sonya "А у тебя . . ."
    Sonya "E você..."

# game/characters_events_idles/sonya_events.rpy:220
translate portugues sonya_scene2_day_girlroom_041495e8:

    # Sonya "Там, в городе . . ."
    Sonya "Lá, na cidade..."

# game/characters_events_idles/sonya_events.rpy:222
translate portugues sonya_scene2_day_girlroom_ec4c11a0:

    # Sonya "Кто-нибудь остался?"
    Sonya "Ficou alguém?"

# game/characters_events_idles/sonya_events.rpy:224
translate portugues sonya_scene2_day_girlroom_d26255df:

    # gg "Был один человек"
    gg "Havia uma pessoa"

# game/characters_events_idles/sonya_events.rpy:226
translate portugues sonya_scene2_day_girlroom_5319b6ee:

    # gg "Мы давно разошлись"
    gg "Nós nos separamos há tempos"

# game/characters_events_idles/sonya_events.rpy:228
translate portugues sonya_scene2_day_girlroom_48254a12:

    # gg "Сейчас . . .{w} скорее нет, чем да"
    gg "Agora...{w} Mais não do que sim"

# game/characters_events_idles/sonya_events.rpy:230
translate portugues sonya_scene2_day_girlroom_93bf8783:

    # Sonya "Понятно"
    Sonya "Entendi"

# game/characters_events_idles/sonya_events.rpy:232
translate portugues sonya_scene2_day_girlroom_bfbf3b82:

    # Sonya "Я просто спросила"
    Sonya "Só estava perguntando"

# game/characters_events_idles/sonya_events.rpy:238
translate portugues sonya_scene2_day_girlroom_bde02200:

    # Sonya "Тогда я наверно . . ."
    Sonya "Então eu provavelmente..."

# game/characters_events_idles/sonya_events.rpy:240
translate portugues sonya_scene2_day_girlroom_230ea232:

    # Sonya "Буду дальше убираться, пыль быстро собирается"
    Sonya "Vou continuar limpando, o pó acumula rápido"

# game/characters_events_idles/sonya_events.rpy:243
translate portugues sonya_scene2_day_girlroom_944c14eb:

    # gg "Спасибо еще раз"
    gg "Obrigado de novo"

# game/characters_events_idles/sonya_events.rpy:245
translate portugues sonya_scene2_day_girlroom_3735a72e:

    # Sonya "Угу"
    Sonya "Uhum"

# game/characters_events_idles/sonya_events.rpy:247
translate portugues sonya_scene2_day_girlroom_ccc766ff:

    # Sonya "Если что аптечка всегда здесь"
    Sonya "Se precisar, o kit de primeiros socorros sempre está aqui"

# game/characters_events_idles/sonya_events.rpy:273
translate portugues sonya_scene3_day_bathroom_03e250ee:

    # gg "Эмм Соня, я тут"
    gg "Hmm, Sônia, estou aqui"

# game/characters_events_idles/sonya_events.rpy:281
translate portugues sonya_scene3_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "Oi"

# game/characters_events_idles/sonya_events.rpy:294
translate portugues sonya_scene3_day_bathroom_b3aa243a:

    # Sonya "Прости"
    Sonya "Desculpa"

# game/characters_events_idles/sonya_events.rpy:296
translate portugues sonya_scene3_day_bathroom_ea2e53f8:

    # Sonya "Я думала, ванная свободна"
    Sonya "Achei que o banheiro estava livre"

# game/characters_events_idles/sonya_events.rpy:298
translate portugues sonya_scene3_day_bathroom_7f3525bd:

    # Sonya "Это моя ошибка"
    Sonya "Foi meu erro"

# game/characters_events_idles/sonya_events.rpy:300
translate portugues sonya_scene3_day_bathroom_b8f5eb09:

    # gg "Всё нормально"
    gg "Está tudo bem"

# game/characters_events_idles/sonya_events.rpy:302
translate portugues sonya_scene3_day_bathroom_623f3607:

    # gg "Ничего страшного"
    gg "Não foi nada"

# game/characters_events_idles/sonya_events.rpy:304
translate portugues sonya_scene3_day_bathroom_7fce0f16:

    # Sonya "{size=*1.3}Нет"
    Sonya "{size=*1.3}Não"

# game/characters_events_idles/sonya_events.rpy:306
translate portugues sonya_scene3_day_bathroom_c2e17951:

    # Sonya "Я просто сделаю вид"
    Sonya "Vou só fingir"

# game/characters_events_idles/sonya_events.rpy:308
translate portugues sonya_scene3_day_bathroom_1a86b367:

    # Sonya "Что этого не было"
    Sonya "Que isso não aconteceu"

# game/characters_events_idles/sonya_events.rpy:325
translate portugues sonya_scene3_day_bathroom_475b14a6:

    # Sonya "Я оставила тебе чай на кухне"
    Sonya "Deixei chá para você na cozinha"

# game/characters_events_idles/sonya_events.rpy:327
translate portugues sonya_scene3_day_bathroom_c0c28f24:

    # Sonya "Горячий аккуратнее"
    Sonya "Cuidado que está quente"

# game/characters_events_idles/sonya_events.rpy:330
translate portugues sonya_scene3_day_bathroom_04c6c53d:

    # gg "Спасибо"
    gg "Obrigado"

# game/characters_events_idles/sonya_events.rpy:351
translate portugues sonya_scene4_morning_bathroom_db34cd4c:

    # gg "Эм . . ."
    gg "Hmm..."

# game/characters_events_idles/sonya_events.rpy:353
translate portugues sonya_scene4_morning_bathroom_f18372c4:

    # Sonya "Ой . . ." with hpunch
    Sonya "Ai..." with hpunch

# game/characters_events_idles/sonya_events.rpy:354
translate portugues sonya_scene4_morning_bathroom_d5441823:

    # gg "Наверно, я зайду попозже"
    gg "Talvez eu volte mais tarde"

# game/characters_events_idles/sonya_events.rpy:356
translate portugues sonya_scene4_morning_bathroom_b9dc4392:

    # Sonya "Стой"
    Sonya "Espera"

# game/characters_events_idles/sonya_events.rpy:358
translate portugues sonya_scene4_morning_bathroom_e21251db:

    # Sonya "Не стесняйся. Чисти зубы, я уже заканчиваю"
    Sonya "Não fique tímido. Escove os dentes, já estou terminando"

# game/characters_events_idles/sonya_events.rpy:360
translate portugues sonya_scene4_morning_bathroom_0d97ff86:

    # gg_chat "Ого . . ."
    gg_chat "Uau..."

# game/characters_events_idles/sonya_events.rpy:364
translate portugues sonya_scene4_morning_bathroom_7f534b36:

    # Sonya "Тут раньше жили только мы с Маей"
    Sonya "Antes só a Maya e eu morávamos aqui"

# game/characters_events_idles/sonya_events.rpy:366
translate portugues sonya_scene4_morning_bathroom_8e74c8b9:

    # Sonya "Девушки"
    Sonya "Garotas"

# game/characters_events_idles/sonya_events.rpy:368
translate portugues sonya_scene4_morning_bathroom_822105aa:

    # Sonya "Я привыкла ходить"
    Sonya "Me acostumei a andar"

# game/characters_events_idles/sonya_events.rpy:370
translate portugues sonya_scene4_morning_bathroom_759d9a83:

    # Sonya "Так"
    Sonya "Assim"

# game/characters_events_idles/sonya_events.rpy:373
translate portugues sonya_scene4_morning_bathroom_893810bd:

    # Sonya "Никого это не смущало . . ."
    Sonya "Ninguém se importava..."

# game/characters_events_idles/sonya_events.rpy:375
translate portugues sonya_scene4_morning_bathroom_2d618e7e:

    # gg "Да где-то я уже такое видел"
    gg "Ah, já vi algo assim em algum lugar"

# game/characters_events_idles/sonya_events.rpy:377
translate portugues sonya_scene4_morning_bathroom_26a90d56:

    # Sonya "Ты смотришь"
    Sonya "Você está olhando"

# game/characters_events_idles/sonya_events.rpy:379
translate portugues sonya_scene4_morning_bathroom_62a5f760:

    # Sonya "Даже не пытаешься отвернуться"
    Sonya "Nem tenta virar o rosto"

# game/characters_events_idles/sonya_events.rpy:382
translate portugues sonya_scene4_morning_bathroom_1c65dff9:

    # Sonya "И знаешь . . ."
    Sonya "E sabe..."

# game/characters_events_idles/sonya_events.rpy:384
translate portugues sonya_scene4_morning_bathroom_7516d68e:

    # Sonya "Мне это нравится . . ."
    Sonya "Eu gosto disso..."

# game/characters_events_idles/sonya_events.rpy:388
translate portugues sonya_scene4_morning_bathroom_6911a69b:

    # Sonya "Всё"
    Sonya "Pronto"

# game/characters_events_idles/sonya_events.rpy:390
translate portugues sonya_scene4_morning_bathroom_bc7d5f86:

    # Sonya "Хватит тебе утренней зарядки для глаз"
    Sonya "Chega de exercício matinal para os olhos"

# game/characters_events_idles/sonya_events.rpy:395
translate portugues sonya_scene4_morning_bathroom_9bf5f0cd:

    # Sonya "Но всё же . . ."
    Sonya "Mas mesmo assim..."

# game/characters_events_idles/sonya_events.rpy:397
translate portugues sonya_scene4_morning_bathroom_3780446f:

    # extend " Как ты можешь смотреть"
    extend " Como você pode olhar"

# game/characters_events_idles/sonya_events.rpy:401
translate portugues sonya_scene4_morning_bathroom_1f146f5f:

    # Sonya "И не трогать?"
    Sonya "E não tocar?"

# game/characters_events_idles/sonya_events.rpy:416
translate portugues sonya_scene5_night_girlroom_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/characters_events_idles/sonya_events.rpy:418
translate portugues sonya_scene5_night_girlroom_f0ccb195:

    # Sonya "[povname] . . ."
    Sonya "[povname]..."

# game/characters_events_idles/sonya_events.rpy:422
translate portugues sonya_scene5_night_girlroom_f0ccb195_1:

    # Sonya "[povname] . . ."
    Sonya "[povname]..."

# game/characters_events_idles/sonya_events.rpy:425
translate portugues sonya_scene5_night_girlroom_6c32fa14:

    # gg "А что . . ."
    gg "O que foi..."

# game/characters_events_idles/sonya_events.rpy:427
translate portugues sonya_scene5_night_girlroom_b3aa243a:

    # Sonya "Прости"
    Sonya "Desculpa"

# game/characters_events_idles/sonya_events.rpy:428
translate portugues sonya_scene5_night_girlroom_4aff93e9:

    # Sonya "Я не хотела тебя резко будить"
    Sonya "Não queria te acordar bruscamente"

# game/characters_events_idles/sonya_events.rpy:431
translate portugues sonya_scene5_night_girlroom_cbd4343b:

    # Sonya "Просто . . . не могу заснуть"
    Sonya "É que... não consigo dormir"

# game/characters_events_idles/sonya_events.rpy:433
translate portugues sonya_scene5_night_girlroom_873c4360:

    # Sonya "Ты спишь так спокойно"
    Sonya "Você dorme tão tranquilamente"

# game/characters_events_idles/sonya_events.rpy:435
translate portugues sonya_scene5_night_girlroom_988f1304:

    # Sonya "Посидишь со мной немного?"
    Sonya "Fica comigo um pouco?"

# game/characters_events_idles/sonya_events.rpy:437
translate portugues sonya_scene5_night_girlroom_2970a146:

    # Sonya "Пока не отпустит"
    Sonya "Até passar"

# game/characters_events_idles/sonya_events.rpy:439
translate portugues sonya_scene5_night_girlroom_a9b332b7:

    # gg "Ты устала?"
    gg "Está cansada?"

# game/characters_events_idles/sonya_events.rpy:441
translate portugues sonya_scene5_night_girlroom_0fb040eb:

    # Sonya "Нет,{w} не совсем"
    Sonya "Não,{w} não exatamente"

# game/characters_events_idles/sonya_events.rpy:443
translate portugues sonya_scene5_night_girlroom_5527f93e:

    # Sonya "Просто думала"
    Sonya "Só estava pensando"

# game/characters_events_idles/sonya_events.rpy:446
translate portugues sonya_scene5_night_girlroom_72ba6d47:

    # gg "О чём?"
    gg "No quê?"

# game/characters_events_idles/sonya_events.rpy:448
translate portugues sonya_scene5_night_girlroom_69179d28:

    # Sonya "Да не важно"
    Sonya "Ah, não importa"

# game/characters_events_idles/sonya_events.rpy:452
translate portugues sonya_scene5_night_girlroom_589ad1ec:

    # gg "Ты всё время так?"
    gg "Você é assim o tempo todo?"

# game/characters_events_idles/sonya_events.rpy:453
translate portugues sonya_scene5_night_girlroom_6f30ec91:

    # gg "Или бывает, что расслабляешься?"
    gg "Ou às vezes consegue relaxar?"

# game/characters_events_idles/sonya_events.rpy:455
translate portugues sonya_scene5_night_girlroom_fda29abb:

    # Sonya "Раньше было легче"
    Sonya "Antes era mais fácil"

# game/characters_events_idles/sonya_events.rpy:457
translate portugues sonya_scene5_night_girlroom_1684e2b6:

    # Sonya "Просто я"
    Sonya "É que eu"

# game/characters_events_idles/sonya_events.rpy:459
translate portugues sonya_scene5_night_girlroom_09ea6a66:

    # Sonya "Привыкла держать всё под контролем"
    Sonya "Me acostumei a manter tudo sob controle"

# game/characters_events_idles/sonya_events.rpy:462
translate portugues sonya_scene5_night_girlroom_27fc4b94:

    # Sonya "Ладно . . ."
    Sonya "Tudo bem..."

# game/characters_events_idles/sonya_events.rpy:465
translate portugues sonya_scene5_night_girlroom_04a163be:

    # Sonya "Вот видишь"
    Sonya "Viu só"

# game/characters_events_idles/sonya_events.rpy:467
translate portugues sonya_scene5_night_girlroom_1825b5d8:

    # Sonya "Даже это нормально не могу"
    Sonya "Nem isso consigo fazer direito"

# game/characters_events_idles/sonya_events.rpy:473
translate portugues sonya_scene5_night_girlroom_4706c7d6:

    # Sonya "Давай просто полежим"
    Sonya "Vamos só deitar"

# game/characters_events_idles/sonya_events.rpy:475
translate portugues sonya_scene5_night_girlroom_dd04d853:

    # Sonya "Я не хочу думать сейчас"
    Sonya "Não quero pensar agora"

# game/characters_events_idles/sonya_events.rpy:493
translate portugues sonya_scene5_night_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "Obrigada..."

# game/characters_events_idles/sonya_events.rpy:495
translate portugues sonya_scene5_night_girlroom_7edcc3c4:

    # Sonya "Я давно так нормально не спала"
    Sonya "Faz tempo que não durmo bem assim"

# game/characters_events_idles/sonya_events.rpy:503
translate portugues sonya_scene5_night_girlroom_a9d8faa5:

    # Sonya "Если Мая увидит нас, будет много вопросов"
    Sonya "Se a Maya nos vir, vai ter muitas perguntas"

# game/characters_events_idles/sonya_events.rpy:505
translate portugues sonya_scene5_night_girlroom_2c86168e:

    # Sonya "Я сделаю тебе завтрак"
    Sonya "Vou fazer café da manhã para você"

# game/characters_events_idles/sonya_events.rpy:507
translate portugues sonya_scene5_night_girlroom_9663ea36:

    # Sonya "Он будет вкусным, не переживай"
    Sonya "Vai ficar gostoso, não se preocupe"

# game/characters_events_idles/sonya_events.rpy:525
translate portugues sonya_scene6_evening_myroom_1d152ede:

    # gg "Привет!"
    gg "Oi!"

# game/characters_events_idles/sonya_events.rpy:527
translate portugues sonya_scene6_evening_myroom_4979c711:

    # Sonya "Эй, ты аниме смотришь?"
    Sonya "Ei, você assiste anime?"

# game/characters_events_idles/sonya_events.rpy:529
translate portugues sonya_scene6_evening_myroom_8dbdedb7:

    # Sonya "Тут только началось"
    Sonya "Acabou de começar"

# game/characters_events_idles/sonya_events.rpy:531
translate portugues sonya_scene6_evening_myroom_a94af5bd:

    # gg "Ага, почему бы и нет"
    gg "Sim, por que não"

# game/characters_events_idles/sonya_events.rpy:538
translate portugues sonya_scene6_evening_myroom_4fa070d4:

    # gg "Забавно . . ."
    gg "Engraçado..."

# game/characters_events_idles/sonya_events.rpy:540
translate portugues sonya_scene6_evening_myroom_2e5cd401:

    # extend "Теперь этот диван - моя кровать"
    extend " Agora este sofá é minha cama"

# game/characters_events_idles/sonya_events.rpy:542
translate portugues sonya_scene6_evening_myroom_a3f8d8b5:

    # gg "Я привык на нём фильмы смотреть, а теперь ещё и сплю здесь"
    gg "Me acostumei a assistir filmes nele, e agora também durmo aqui"

# game/characters_events_idles/sonya_events.rpy:543
translate portugues sonya_scene6_evening_myroom_8d9b5058:

    # Sonya "Вообще - то"
    Sonya "Na verdade"

# game/characters_events_idles/sonya_events.rpy:547
translate portugues sonya_scene6_evening_myroom_8bf7cd77:

    # extend " раньше это была моя кровать"
    extend " antes era minha cama"

# game/characters_events_idles/sonya_events.rpy:549
translate portugues sonya_scene6_evening_myroom_4b9b63e3:

    # Sonya "До ухода Линды"
    Sonya "Antes da Linda sair"

# game/characters_events_idles/sonya_events.rpy:551
translate portugues sonya_scene6_evening_myroom_2c51288e:

    # Sonya "А она тогда жила в моей комнатe"
    Sonya "E ela morava no meu quarto na época"

# game/characters_events_idles/sonya_events.rpy:553
translate portugues sonya_scene6_evening_myroom_3467de90:

    # gg "Серьёзно?"
    gg "Sério?"

# game/characters_events_idles/sonya_events.rpy:555
translate portugues sonya_scene6_evening_myroom_80955fa4:

    # Sonya "Да, но потом мы сделали ремонт, чтобы всё было по - нашему"
    Sonya "Sim, mas depois fizemos reforma para deixar tudo do nosso jeito"

# game/characters_events_idles/sonya_events.rpy:557
translate portugues sonya_scene6_evening_myroom_3d5a6534:

    # gg "Красиво получилось . . . {w}и дом где провел детство все еще чувствуется"
    gg "Ficou bonito... {w}e ainda dá para sentir a casa da infância"

# game/characters_events_idles/sonya_events.rpy:562
translate portugues sonya_scene6_evening_myroom_0bab6ed7:

    # "Ты мог бы идти один. Я бы справилась"
    "Você poderia ir sozinho. Eu daria conta"

# game/characters_events_idles/sonya_events.rpy:564
translate portugues sonya_scene6_evening_myroom_e09cf293:

    # "Ты слишком спокоен. Обычно люди стараются понравиться"
    "Você é muito tranquilo. Normalmente as pessoas tentam agradar"

# game/characters_events_idles/sonya_events.rpy:566
translate portugues sonya_scene6_evening_myroom_93462049:

    # "А я не хочу «стараться». Хочу, чтобы ты узнала меня настоящего"
    "Mas eu não quero 'tentar'. Quero que você conheça o meu verdadeiro eu"

# game/characters_events_idles/sonya_events.rpy:568
translate portugues sonya_scene6_evening_myroom_25dcefcc:

    # "Знаешь, у меня есть и более интересные дела"
    "Sabe, eu tenho coisas mais interessantes para fazer"

# game/characters_events_idles/sonya_events.rpy:570
translate portugues sonya_scene6_evening_myroom_fda89b59:

    # "Тогда почему ты всё ещё здесь?"
    "Então por que ainda está aqui?"

# game/characters_events_idles/sonya_events.rpy:573
translate portugues sonya_scene6_evening_myroom_7f029619:

    # Sonya "Вот смотри . . ."
    Sonya "Olha só..."

# game/characters_events_idles/sonya_events.rpy:575
translate portugues sonya_scene6_evening_myroom_6f549ff9:

    # extend " она играет „недоступную“"
    extend " ela está fazendo a 'inacessível'"

# game/characters_events_idles/sonya_events.rpy:577
translate portugues sonya_scene6_evening_myroom_beb1c184:

    # Sonya "Хотя видно, что сохнет по нему . . ."
    Sonya "Mas dá para ver que ela está apaixonada por ele..."

# game/characters_events_idles/sonya_events.rpy:580
translate portugues sonya_scene6_evening_myroom_766aa28c:

    # gg "Может, в этом и драма?"
    gg "Talvez seja aí que está o drama?"

# game/characters_events_idles/sonya_events.rpy:582
translate portugues sonya_scene6_evening_myroom_ae35e350:

    # Sonya "Драма в том, что тянет резину"
    Sonya "O drama é que está enrolando"

# game/characters_events_idles/sonya_events.rpy:584
translate portugues sonya_scene6_evening_myroom_70feb79f:

    # Sonya "Зачем, если всё ясно?"
    Sonya "Pra quê, se está tudo claro?"

# game/characters_events_idles/sonya_events.rpy:585
translate portugues sonya_scene6_evening_myroom_b291874f:

    # Sonya "{sc}Это раздражает{/sc}" with hpunch
    Sonya "{sc}Isso é irritante{/sc}" with hpunch

# game/characters_events_idles/sonya_events.rpy:587
translate portugues sonya_scene6_evening_myroom_6ef8cdd4:

    # gg "Ты бы решила быстрее?"
    gg "Você resolveria mais rápido?"

# game/characters_events_idles/sonya_events.rpy:589
translate portugues sonya_scene6_evening_myroom_2db4fbf2:

    # Sonya "Намного быстрее . . ."
    Sonya "Muito mais rápido..."

# game/characters_events_idles/sonya_events.rpy:591
translate portugues sonya_scene6_evening_myroom_c5704027:

    # Sonya "Скучное аниме"
    Sonya "Anime chato"

# game/characters_events_idles/sonya_events.rpy:593
translate portugues sonya_scene6_evening_myroom_9be82b23:

    # Sonya "Я не могу сидеть спокойно"
    Sonya "Não consigo ficar parada"

# game/characters_events_idles/sonya_events.rpy:595
translate portugues sonya_scene6_evening_myroom_13513f79:

    # gg "Тогда ложись, может, так будет легче"
    gg "Então deita, talvez fique mais fácil"

# game/characters_events_idles/sonya_events.rpy:597
translate portugues sonya_scene6_evening_myroom_0d9cdeae:

    # Sonya "Лечь говоришь?"
    Sonya "Deitar, você diz?"

# game/characters_events_idles/sonya_events.rpy:605
translate portugues sonya_scene6_evening_myroom_448d2ea3:

    # Sonya "Да так спокойнее . . ."
    Sonya "Sim, assim é mais tranquilo..."

# game/characters_events_idles/sonya_events.rpy:610
translate portugues sonya_scene6_evening_myroom_75e70e12:

    # Sonya "{sc}Ах . . .{/sc}"
    Sonya "{sc}Ah...{/sc}"

# game/characters_events_idles/sonya_events.rpy:613
translate portugues sonya_scene6_evening_myroom_376482db:

    # Sonya "Вот так . . ."
    Sonya "Assim..."

# game/characters_events_idles/sonya_events.rpy:614
translate portugues sonya_scene6_evening_myroom_28a0cb64:

    # Sonya "Наконец - то"
    Sonya "Finalmente"

# game/characters_events_idles/sonya_events.rpy:616
translate portugues sonya_scene6_evening_myroom_2157c7a2:

    # Sonya "Не бойся, мне нравится"
    Sonya "Não tenha medo, eu gosto"

# game/characters_events_idles/sonya_events.rpy:619
translate portugues sonya_scene6_evening_myroom_e0c310ab:

    # Sonya "В ванной ты только смотрел"
    Sonya "No banheiro você só olhou"

# game/characters_events_idles/sonya_events.rpy:621
translate portugues sonya_scene6_evening_myroom_23073e11:

    # Sonya "Тут я тебе помогу"
    Sonya "Aqui eu te ajudo"

# game/characters_events_idles/sonya_events.rpy:623
translate portugues sonya_scene6_evening_myroom_77e32f3e:

    # Sonya "Я знаю, что ты хочешь"
    Sonya "Eu sei o que você quer"

# game/characters_events_idles/sonya_events.rpy:625
translate portugues sonya_scene6_evening_myroom_314984e9:

    # Sonya "Просто помогаю"
    Sonya "Só estou ajudando"

# game/characters_events_idles/sonya_events.rpy:629
translate portugues sonya_scene6_evening_myroom_70da84e8:

    # Sonya "Мне приятно . . . {w}даже больше, чем я ожидала"
    Sonya "É bom... {w}até mais do que eu esperava"

# game/characters_events_idles/sonya_events.rpy:630
translate portugues sonya_scene6_evening_myroom_42733475:

    # gg "У тебя прекрасная грудь . . . {w}мягкая и тёплая"
    gg "Você tem seios lindos... {w}macios e quentes"

# game/characters_events_idles/sonya_events.rpy:631
translate portugues sonya_scene6_evening_myroom_ae3a5ec7:

    # gg "Идеальная"
    gg "Perfeitos"

# game/characters_events_idles/sonya_events.rpy:632
translate portugues sonya_scene6_evening_myroom_ec947a50:

    # Sonya "Хитрый . . ."
    Sonya "Esperto..."

# game/characters_events_idles/sonya_events.rpy:633
translate portugues sonya_scene6_evening_myroom_9e059832:

    # Sonya "Знаешь ведь, что я краснею от таких слов"
    Sonya "Você sabe que eu fico corada com essas palavras"

# game/characters_events_idles/sonya_events.rpy:635
translate portugues sonya_scene6_evening_myroom_9a2913c4:

    # Sonya "Но продолжай"
    Sonya "Mas continue"

# game/characters_events_idles/sonya_events.rpy:644
translate portugues sonya_scene6_evening_myroom_394ba447:

    # Maya "А что это вы тут . . ."
    Maya "E o que vocês estão fazendo aqui..."

# game/characters_events_idles/sonya_events.rpy:646
translate portugues sonya_scene6_evening_myroom_f2d7a854:

    # Maya "В обнимку сидите?"
    Maya "De conchinha?"

# game/characters_events_idles/sonya_events.rpy:648
translate portugues sonya_scene6_evening_myroom_a3e76380:

    # Sonya "Аниме смотрим. {w}Но он скучный"
    Sonya "Assistindo anime. {w}Mas está chato"


# game/characters_events_idles/sonya_events.rpy:649
translate portugues sonya_scene6_evening_myroom_28afd6ea:

    # gg "Да, просто аниме"
    gg "Sim, só anime"

# game/characters_events_idles/sonya_events.rpy:651
translate portugues sonya_scene6_evening_myroom_aa558823:

    # Maya "Не думайте что я этого не видела . . ."
    Maya "Não pense que não vi isso..."

# game/characters_events_idles/sonya_events.rpy:654
translate portugues sonya_scene6_evening_myroom_eba4c233:

    # Sonya "Спасибо за вечер"
    Sonya "Obrigada pela noite"

# game/characters_events_idles/sonya_events.rpy:656
translate portugues sonya_scene6_evening_myroom_e7128efe:

    # Sonya "Было . . . {w} приятно"
    Sonya "Foi... {w} bom"

# game/characters_events_idles/sonya_events.rpy:660
translate portugues sonya_scene6_evening_myroom_222b7c49:

    # Sonya "Давай оставим аниме на завтра"
    Sonya "Vamos deixar o anime para amanhã"

# game/characters_events_idles/sonya_events.rpy:661
translate portugues sonya_scene6_evening_myroom_be1b9cb9:

    # Sonya "Закончим на этом, а то я и сама не остановлюсь"
    Sonya "Vamos parar por aqui, senão eu mesma não vou conseguir parar"

# game/characters_events_idles/sonya_events.rpy:663
translate portugues sonya_scene6_evening_myroom_b989363c:

    # gg ". . ."
    gg "..."

# game/characters_events_idles/sonya_events.rpy:678
translate portugues sonya_scene7_evening_girlroom_0262890b:

    # Sonya "Зайдёшь ко мне?"
    Sonya "Vem no meu quarto?"

# game/characters_events_idles/sonya_events.rpy:680
translate portugues sonya_scene7_evening_girlroom_cf65688b:

    # Sonya "Просто . . . {w}хочу поговорить "
    Sonya "Só... {w}quero conversar"

# game/characters_events_idles/sonya_events.rpy:682
translate portugues sonya_scene7_evening_girlroom_0609085f:

    # gg "Конечно"
    gg "Claro"

# game/characters_events_idles/sonya_events.rpy:684
translate portugues sonya_scene7_evening_girlroom_fe1b6c78:

    # gg "Ты какая-то задумчивая"
    gg "Você está pensativa"

# game/characters_events_idles/sonya_events.rpy:686
translate portugues sonya_scene7_evening_girlroom_24fe6265:

    # Sonya "Да . . ."
    Sonya "Sim..."

# game/characters_events_idles/sonya_events.rpy:688
translate portugues sonya_scene7_evening_girlroom_546a584b:

    # Sonya "Просто не могу всё выкинуть из головы"
    Sonya "É que não consigo tirar da cabeça"

# game/characters_events_idles/sonya_events.rpy:690
translate portugues sonya_scene7_evening_girlroom_7ff0eaf1:

    # Sonya "Всё как-то закрутилось слишком быстро"
    Sonya "Tudo aconteceu muito rápido"

# game/characters_events_idles/sonya_events.rpy:692
translate portugues sonya_scene7_evening_girlroom_fb1f6848:

    # gg "В каком смысле?"
    gg "Em que sentido?"

# game/characters_events_idles/sonya_events.rpy:694
translate portugues sonya_scene7_evening_girlroom_b7dadb54:

    # Sonya "Ну . . . {w}обычно я держусь спокойно"
    Sonya "Bem... {w}normalmente eu fico calma"

# game/characters_events_idles/sonya_events.rpy:696
translate portugues sonya_scene7_evening_girlroom_8a221fed:

    # Sonya "Всё у меня под контролем"
    Sonya "Tudo sob meu controle"

# game/characters_events_idles/sonya_events.rpy:698
translate portugues sonya_scene7_evening_girlroom_afb359d5:

    # Sonya "Но рядом с тобой . . . {w}всё иначе"
    Sonya "Mas perto de você... {w}tudo é diferente"

# game/characters_events_idles/sonya_events.rpy:700
translate portugues sonya_scene7_evening_girlroom_486c8325:

    # gg "Иначе - это плохо?"
    gg "Diferente é ruim?"

# game/characters_events_idles/sonya_events.rpy:702
translate portugues sonya_scene7_evening_girlroom_6f2ad814:

    # Sonya "Иногда кажется, что я делаю глупости"
    Sonya "Às vezes parece que estou fazendo bobagens"

# game/characters_events_idles/sonya_events.rpy:704
translate portugues sonya_scene7_evening_girlroom_b81ca64b:

    # Sonya "Такие . . . {w}нелепые"
    Sonya "Tão... {w}ridículas"

# game/characters_events_idles/sonya_events.rpy:706
translate portugues sonya_scene7_evening_girlroom_716ea2d0:

    # Sonya "Будто я снова подросток"
    Sonya "Como se eu fosse adolescente de novo"

# game/characters_events_idles/sonya_events.rpy:708
translate portugues sonya_scene7_evening_girlroom_c3165439:

    # gg " . . ."
    gg "..."

# game/characters_events_idles/sonya_events.rpy:710
translate portugues sonya_scene7_evening_girlroom_43cc3ee5:

    # Sonya "Я не уверена в своём поведении"
    Sonya "Não estou certa do meu comportamento"

# game/characters_events_idles/sonya_events.rpy:711
translate portugues sonya_scene7_evening_girlroom_bf81f51b:

    # Sonya "Может, я слишком тороплюсь"
    Sonya "Talvez esteja indo rápido demais"

# game/characters_events_idles/sonya_events.rpy:713
translate portugues sonya_scene7_evening_girlroom_7263e949:

    # Sonya "Может, выгляжу смешно"
    Sonya "Talvez pareça engraçada"

# game/characters_events_idles/sonya_events.rpy:715
translate portugues sonya_scene7_evening_girlroom_5c74b5ea:

    # gg "Мне так не кажется"
    gg "Não me parece"

# game/characters_events_idles/sonya_events.rpy:717
translate portugues sonya_scene7_evening_girlroom_9d42851b:

    # Sonya "А если вдруг?"
    Sonya "E se for?"

# game/characters_events_idles/sonya_events.rpy:718
translate portugues sonya_scene7_evening_girlroom_6fb3c26c:

    # Sonya "Если я правда не такая, какой должна быть?"
    Sonya "Se eu realmente não for como deveria ser?"

# game/characters_events_idles/sonya_events.rpy:720
translate portugues sonya_scene7_evening_girlroom_5c8cc88c:

    # Sonya "Ты всё равно примешь меня?"
    Sonya "Você ainda vai me aceitar?"

# game/characters_events_idles/sonya_events.rpy:727
translate portugues sonya_scene7_evening_girlroom_ca1ff0ec:

    # gg "Мне нравишься настоящая ты"
    gg "Eu gosto da verdadeira você"

# game/characters_events_idles/sonya_events.rpy:730
translate portugues sonya_scene7_evening_girlroom_495fe1ef:

    # gg "Мне не нужно, чтобы ты была какой-то другой"
    gg "Eu não preciso que você seja diferente"

# game/characters_events_idles/sonya_events.rpy:746
translate portugues sonya_scene7_evening_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "Obrigada..."

# game/characters_events_idles/sonya_events.rpy:747
translate portugues sonya_scene7_evening_girlroom_860f4d16:

    # Sonya "Это именно то что я хотела"
    Sonya "Isso é exatamente o que eu queria"

# game/characters_events_idles/sonya_events.rpy:753
translate portugues sonya_scene7_evening_girlroom_489479bc:

    # Sonya "{sc}Да . . . Так . . .{/sc}"
    Sonya "{sc}Sim... Assim...{/sc}"

# game/characters_events_idles/sonya_events.rpy:759
translate portugues sonya_scene7_evening_girlroom_2d94ee37:

    # Sonya "На диване ты меня трогал"
    Sonya "No sofá você me tocou"

# game/characters_events_idles/sonya_events.rpy:760
translate portugues sonya_scene7_evening_girlroom_fc982615:

    # Sonya "Теперь - моя очередь"
    Sonya "Agora é minha vez"

# game/characters_events_idles/sonya_events.rpy:767
translate portugues sonya_scene7_evening_girlroom_7b973257:

    # Sonya "Смотри на меня"
    Sonya "Olha para mim"

# game/characters_events_idles/sonya_events.rpy:775
translate portugues sonya_scene7_evening_girlroom_1b8740c5:

    # Sonya "Всё - ты теперь мой!"
    Sonya "Pronto - agora você é meu!"

# game/characters_events_idles/sonya_events.rpy:783
translate portugues sonya_scene7_evening_girlroom_2da445da:

    # Sonya "Подожди тут"
    Sonya "Espera aqui"

# game/characters_events_idles/sonya_events.rpy:785
translate portugues sonya_scene7_evening_girlroom_250fe814:

    # Sonya "Я быстро"
    Sonya "Já volto"

# game/characters_events_idles/sonya_events.rpy:791
translate portugues sonya_scene7_evening_girlroom_dadabf98:

    # gg_chat "Это случилось так быстро . . . "
    gg_chat "Aconteceu tão rápido..."

# game/characters_events_idles/sonya_events.rpy:798
translate portugues sonya_scene7_evening_girlroom_e844ad84:

    # Sonya "Останься"
    Sonya "Fica"

# game/characters_events_idles/sonya_events.rpy:800
translate portugues sonya_scene7_evening_girlroom_1d2efc6a:

    # Sonya "Посиди со мной"
    Sonya "Fica comigo"

# game/characters_events_idles/sonya_events.rpy:802
translate portugues sonya_scene7_evening_girlroom_b435d332:

    # Sonya "И посмотрим, куда это нас приведёт."
    Sonya "E vamos ver aonde isso nos leva."

# game/characters_events_idles/sonya_events.rpy:805
translate portugues sonya_scene7_evening_girlroom_ca91d43d:

    # gg_chat "Было тепло"
    gg_chat "Estava quente"

# game/characters_events_idles/sonya_events.rpy:806
translate portugues sonya_scene7_evening_girlroom_899d5485:

    # gg_chat "Я хотел остаться рядом"
    gg_chat "Eu queria ficar perto"

translate portugues strings:

    # game/characters_events_idles/sonya_events.rpy:516
    old "Утро"
    new "Manhã"

    # game/characters_events_idles/sonya_events.rpy:608
    old "Играешь со мной?"
    new "Está brincando comigo?"

    # game/characters_events_idles/sonya_events.rpy:618
    old "Мне так хорошо"
    new "Me sinto tão bem"

    # game/characters_events_idles/sonya_events.rpy:725
    old "Такой ты и нужна"
    new "É assim que eu preciso que você seja"

    # game/characters_events_idles/sonya_events.rpy:734
    old "Поцеловать"
    new "Beijar"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/sonya_events.rpy:20
translate portugues sonya_scene1_morning_kitchen_c92bc08a:

    # Sonya "Там диван, конечно, старый"
    Sonya "O sofá ali é velho, claro"

# game/characters_events_idles/sonya_events.rpy:50
translate portugues sonya_scene1_morning_kitchen_12302e27:

    # Sonya "У нас, обычно, никто особо не спрашивает"
    Sonya "Aqui, normalmente, ninguém pergunta muito"

# game/characters_events_idles/sonya_events.rpy:161
translate portugues sonya_scene2_day_girlroom_9c553288:

    # Sonya "Так и планировал . . ."
    Sonya "Era isso que eu planejava..."

# game/characters_events_idles/sonya_events.rpy:177
translate portugues sonya_scene2_day_girlroom_c5761118:

    # Sonya "Ты, получается, больше утренний человек?"
    Sonya "Então, você é mais uma pessoa da manhã?"

# game/characters_events_idles/sonya_events.rpy:335
translate portugues sonya_scene3_day_bathroom_21f8234f:

    # Sonya "Горячий, аккуратнее"
    Sonya "Tá quente, cuidado"

# game/characters_events_idles/sonya_events.rpy:383
translate portugues sonya_scene4_morning_bathroom_0d2b005c:

    # gg "Да, где-то я уже такое видел"
    gg "É, acho que já vi algo assim antes"

# game/characters_events_idles/sonya_events.rpy:385
translate portugues sonya_scene4_morning_bathroom_11b14ed3:

    # Sonya "Ты смотришь . . ."
    Sonya "Você tá olhando..."

# game/characters_events_idles/sonya_events.rpy:486
translate portugues sonya_scene5_night_girlroom_44967887:

    # Sonya "Я не хочу ни о чем думать . . ."
    Sonya "Eu não quero pensar em nada..."

# game/characters_events_idles/sonya_events.rpy:835
translate portugues sonya_scene8_morning_kitchen_a482bb49:

    # gg "Утречка"
    gg "Bom dia"

# game/characters_events_idles/sonya_events.rpy:837
translate portugues sonya_scene8_morning_kitchen_ce42d6cf:

    # Sonya "Доброе утро . . ."
    Sonya "Bom dia . . ."

# game/characters_events_idles/sonya_events.rpy:839
translate portugues sonya_scene8_morning_kitchen_72c13c11:

    # Sonya "Я . . . почти закончила готовить, садись"
    Sonya "Eu . . . quase terminei de cozinhar, sente-se"

# game/characters_events_idles/sonya_events.rpy:842
translate portugues sonya_scene8_morning_kitchen_bb1eb7c8:

    # gg "Ты рано встала"
    gg "Você acordou cedo"

# game/characters_events_idles/sonya_events.rpy:844
translate portugues sonya_scene8_morning_kitchen_42ef4d92:

    # Sonya "Не спалось"
    Sonya "Não consegui dormir"

# game/characters_events_idles/sonya_events.rpy:846
translate portugues sonya_scene8_morning_kitchen_a756dcde:

    # Sonya "Подумала . . ."
    Sonya "Pensei . . ."

# game/characters_events_idles/sonya_events.rpy:848
translate portugues sonya_scene8_morning_kitchen_381d05fd:

    # Sonya "Раз ты всё равно проснёшься . . ."
    Sonya "Já que você vai acordar de qualquer maneira . . ."

# game/characters_events_idles/sonya_events.rpy:850
translate portugues sonya_scene8_morning_kitchen_13f1fe10:

    # Sonya "Будет хорошо, заранее приготовить тебе"
    Sonya "Será bom preparar algo para você com antecedência"

# game/characters_events_idles/sonya_events.rpy:861
translate portugues sonya_scene8_morning_kitchen_c3201521:

    # Sonya "Можно?"
    Sonya "Está bem?"

# game/characters_events_idles/sonya_events.rpy:865
translate portugues sonya_scene8_morning_kitchen_0609085f:

    # gg "Конечно"
    gg "Claro"

# game/characters_events_idles/sonya_events.rpy:870
translate portugues sonya_scene8_morning_kitchen_f49db0d9:

    # gg "Очень вкусно"
    gg "Está muito gostoso"

# game/characters_events_idles/sonya_events.rpy:872
translate portugues sonya_scene8_morning_kitchen_6f15bff0:

    # Sonya "Я рада"
    Sonya "Fico feliz"

# game/characters_events_idles/sonya_events.rpy:874
translate portugues sonya_scene8_morning_kitchen_8bd5d020:

    # Sonya "Мне важно, чтобы тебе было хорошо"
    Sonya "É importante para mim que você esteja bem"

# game/characters_events_idles/sonya_events.rpy:882
translate portugues sonya_scene8_morning_kitchen_41dbce33:

    # Sonya "Я всю ночь думала . . ."
    Sonya "Pensei a noite toda . . ."

# game/characters_events_idles/sonya_events.rpy:885
translate portugues sonya_scene8_morning_kitchen_f519c6fc:

    # Sonya "Раньше я беспокоилась"
    Sonya "Antes eu me preocupava"

# game/characters_events_idles/sonya_events.rpy:887
translate portugues sonya_scene8_morning_kitchen_b0e09a72:

    # Sonya "А сегодня . . ."
    Sonya "Mas hoje . . ."

# game/characters_events_idles/sonya_events.rpy:889
translate portugues sonya_scene8_morning_kitchen_814991c8:

    # Sonya "Мне спокойно"
    Sonya "Eu me sinto tranquila"

# game/characters_events_idles/sonya_events.rpy:898
translate portugues sonya_scene8_morning_kitchen_d0794f94:

    # Sonya "Если ты не против . . ."
    Sonya "Se você não se importar . . ."

# game/characters_events_idles/sonya_events.rpy:900
translate portugues sonya_scene8_morning_kitchen_9c748c84:

    # Sonya "Я могу . . ."
    Sonya "Eu posso . . ."

# game/characters_events_idles/sonya_events.rpy:904
translate portugues sonya_scene8_morning_kitchen_a877578e:

    # Sonya "Быть чуть ближе"
    Sonya "Ficar um pouco mais perto"

# game/characters_events_idles/sonya_events.rpy:926
translate portugues sonya_scene8_morning_kitchen_1b7d05a8:

    # Sonya "Чувствовать, как ты становишься твёрже . . ."
    Sonya "Sentir como você fica mais firme . . ."

# game/characters_events_idles/sonya_events.rpy:927
translate portugues sonya_scene8_morning_kitchen_b85aacb1:

    # Sonya "От моего прикосновения . . . {w}это так . . ."
    Sonya "Com o meu toque . . . {w}é tão . . ."

# game/characters_events_idles/sonya_events.rpy:928
translate portugues sonya_scene8_morning_kitchen_9213f2a8:

    # Sonya ". . . Заводит. {w}Сильнее, чем я думала"
    Sonya ". . . Me excita. {w}Mais do que eu pensava"

# game/characters_events_idles/sonya_events.rpy:929
translate portugues sonya_scene8_morning_kitchen_9bc062d5:

    # Sonya "Смотри на меня . . . только на меня . . ."
    Sonya "Olhe para mim . . . só para mim . . ."

# game/characters_events_idles/sonya_events.rpy:940
translate portugues sonya_scene8_morning_kitchen_55a277bb:

    # Sonya "Я . . . не знаю, как правильно это сказать . . ."
    Sonya "Eu . . . não sei como dizer isso corretamente . . ."

# game/characters_events_idles/sonya_events.rpy:942
translate portugues sonya_scene8_morning_kitchen_beb08d03:

    # Sonya "Но мне хорошо, когда ты рядом"
    Sonya "Mas eu me sinto bem quando você está perto"


# game/characters_events_idles/sonya_events.rpy:961
translate portugues sonya_scene9_night_myroom_9a8b0be2:

    # gg "Привет"
    gg "Oi"

# game/characters_events_idles/sonya_events.rpy:963
translate portugues sonya_scene9_night_myroom_b3a2b8a1:

    # Sonya "Привет ты ещё не ложишься?"
    Sonya "Oi, você ainda não vai dormir?"

# game/characters_events_idles/sonya_events.rpy:965
translate portugues sonya_scene9_night_myroom_bb3c3085:

    # Sonya "Тогда пойдём вместе в ванную?"
    Sonya "Então, vamos juntos para o banheiro?"

# game/characters_events_idles/sonya_events.rpy:967
translate portugues sonya_scene9_night_myroom_9afefc8e:

    # Sonya "Я хочу голову помыть . . ."
    Sonya "Quero lavar o cabelo . . ."

# game/characters_events_idles/sonya_events.rpy:969
translate portugues sonya_scene9_night_myroom_b4639877:

    # Sonya "И тебе тоже"
    Sonya "E você também"

# game/characters_events_idles/sonya_events.rpy:971
translate portugues sonya_scene9_night_myroom_66416cc5:

    # gg "Ну пойдем"
    gg "Vamos então"

# game/characters_events_idles/sonya_events.rpy:981
translate portugues sonya_scene9_night_myroom_c5d3f2b1:

    # Sonya "Ты тоже раздевайся давай"
    Sonya "Tire a roupa também, vamos lá"

# game/characters_events_idles/sonya_events.rpy:987
translate portugues sonya_scene9_night_myroom_ebd2cc14:

    # Sonya "Подожди . . ."
    Sonya "Espera . . ."

# game/characters_events_idles/sonya_events.rpy:989
translate portugues sonya_scene9_night_myroom_abb56970:

    # Sonya "У тебя молния заела"
    Sonya "Sua zíper está preso"

# game/characters_events_idles/sonya_events.rpy:996
translate portugues sonya_scene9_night_myroom_3672b0c0:

    # Sonya "Быстро ты . . ."
    Sonya "Você é rápido . . ."

# game/characters_events_idles/sonya_events.rpy:998
translate portugues sonya_scene9_night_myroom_ba83a14c:

    # Sonya "Давай садись"
    Sonya "Sente-se, vamos"

# game/characters_events_idles/sonya_events.rpy:1000
translate portugues sonya_scene9_night_myroom_674bc70f:

    # Sonya "Стой . . . не двигайся"
    Sonya "Espera . . . não se mexa"

# game/characters_events_idles/sonya_events.rpy:1002
translate portugues sonya_scene9_night_myroom_dc365125:

    # Sonya "Я хочу сама"
    Sonya "Quero fazer isso sozinha"

# game/characters_events_idles/sonya_events.rpy:1006
translate portugues sonya_scene9_night_myroom_9c274529:

    # gg "У меня отличный вид"
    gg "Eu tenho uma ótima visão"

# game/characters_events_idles/sonya_events.rpy:1008
translate portugues sonya_scene9_night_myroom_4af82ab0:

    # Sonya "Я знаю"
    Sonya "Eu sei"

# game/characters_events_idles/sonya_events.rpy:1010
translate portugues sonya_scene9_night_myroom_d339691d:

    # Sonya "Мне просто приятно, что ты смотришь"
    Sonya "Eu gosto que você me olhe"

# game/characters_events_idles/sonya_events.rpy:1012
translate portugues sonya_scene9_night_myroom_98944675:

    # Sonya "Теперь ты меня"
    Sonya "Agora você me tem"

# game/characters_events_idles/sonya_events.rpy:1016
translate portugues sonya_scene9_night_myroom_06da4938:

    # Sonya "Ты точно будешь пахнуть как я"
    Sonya "Você com certeza vai cheirar como eu"

# game/characters_events_idles/sonya_events.rpy:1018
translate portugues sonya_scene9_night_myroom_aa254d79:

    # Sonya "Ты такой тёплый сейчас . . . мне это нравится"
    Sonya "Você está tão quente agora . . . Eu gosto disso"

# game/characters_events_idles/sonya_events.rpy:1020
translate portugues sonya_scene9_night_myroom_908db179:

    # Sonya "Пойдём спать вместе"
    Sonya "Vamos dormir juntos"

# game/characters_events_idles/sonya_events.rpy:1022
translate portugues sonya_scene9_night_myroom_e190b45e:

    # Sonya "Я не хочу сегодня одна"
    Sonya "Eu não quero ficar sozinha hoje"

# game/characters_events_idles/sonya_events.rpy:1024
translate portugues sonya_scene9_night_myroom_dd09f522:

    # Sonya "Но на сегодня приключений хватит . . . а то я завтра вообще не проснусь"
    Sonya "Mas já basta de aventuras por hoje . . . caso contrário, não vou acordar amanhã"

# game/characters_events_idles/sonya_events.rpy:1031
translate portugues sonya_scene9_night_myroom_654cb5b3:

    # Sonya "Спокойной ночи"
    Sonya "Boa noite"

# game/characters_events_idles/sonya_events.rpy:1032
translate portugues sonya_scene9_night_myroom_5e65cbb1:

    # Sonya "{bt=a3-p2.0-s3.0}Любимый"
    Sonya "{bt=a3-p2.0-s3.0}Amor"

# game/characters_events_idles/sonya_events.rpy:1038
translate portugues sonya_scene9_night_myroom_7f924e87:

    # gg "Спокойной"
    gg "Boa"

# game/characters_events_idles/sonya_events.rpy:1039
translate portugues sonya_scene9_night_myroom_02749544:

    # gg "Я правда рад, что я с тобой"
    gg "Eu realmente fico feliz por estar com você"


