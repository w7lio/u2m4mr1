﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/sonya_idles.rpy:7
translate portugues sonya_Idle_morning_bathroom_scene_26477ebd:

    # Sonya "О, кто-то перестал стучаться?"
    Sonya "Ah, alguém parou de bater?"

# game/characters_events_idles/sonya_idles.rpy:8
translate portugues sonya_Idle_morning_bathroom_scene_e490c24b:

    # gg "А смысл, если дверь открыта . . ."
    gg "E qual o sentido, se a porta está aberta..."

# game/characters_events_idles/sonya_idles.rpy:10
translate portugues sonya_Idle_morning_bathroom_scene_2e0a6a8c:

    # Sonya "Смелый стал с утра . . ."
    Sonya "Corajoso de manhã..."

# game/characters_events_idles/sonya_idles.rpy:12
translate portugues sonya_Idle_morning_bathroom_scene_f7e61e71:

    # gg "Просто решил не терять привычку к риску"
    gg "Só decidi não perder o hábito de arriscar"

# game/characters_events_idles/sonya_idles.rpy:13
translate portugues sonya_Idle_morning_bathroom_scene_31735247:

    # gg_chat "Она даже в такие моменты выглядит так, будто специально проверяет, насколько далеко можно зайти"
    gg_chat "Ela até em momentos assim parece estar testando de propósito até onde pode ir"

# game/characters_events_idles/sonya_idles.rpy:15
translate portugues sonya_Idle_morning_bathroom_scene_43fc63bc:

    # Sonya "Хочешь полюбоваться видом?"
    Sonya "Quer apreciar a vista?"

# game/characters_events_idles/sonya_idles.rpy:17
translate portugues sonya_Idle_morning_bathroom_scene_274bd888:

    # Sonya "Я не против"
    Sonya "Não me importo"

# game/characters_events_idles/sonya_idles.rpy:18
translate portugues sonya_Idle_morning_bathroom_scene_e8a5a241:

    # gg "С таким предложением даже утренний кофе станет лишним"
    gg "Com uma oferta dessas até o café da manhã fica dispensável"

# game/characters_events_idles/sonya_idles.rpy:20
translate portugues sonya_Idle_morning_bathroom_scene_14ae5b75:

    # Sonya "Ну хоть кто-то ценит мой вклад в твое утро"
    Sonya "Bom, pelo menos alguém valoriza minha contribuição para sua manhã"

# game/characters_events_idles/sonya_idles.rpy:22
translate portugues sonya_Idle_morning_bathroom_scene_daf8e8db:

    # gg "Смотря, что ты предложишь взамен"
    gg "Depende do que você oferecer em troca"

# game/characters_events_idles/sonya_idles.rpy:24
translate portugues sonya_Idle_morning_bathroom_scene_2ff9a6da:

    # Sonya "Знаешь, я бы тоже не отказалась провести утро поинтереснее"
    Sonya "Sabe, eu também não recusaria uma manhã mais interessante"

# game/characters_events_idles/sonya_idles.rpy:26
translate portugues sonya_Idle_morning_bathroom_scene_e6700bf3:

    # Sonya "Особенно с тобой"
    Sonya "Especialmente com você"

# game/characters_events_idles/sonya_idles.rpy:27
translate portugues sonya_Idle_morning_bathroom_scene_9a24ffbd:

    # gg "Звучит как приглашение"
    gg "Parece um convite"

# game/characters_events_idles/sonya_idles.rpy:29
translate portugues sonya_Idle_morning_bathroom_scene_818d5283:

    # Sonya "Да это оно. Но, увы, у меня дела"
    Sonya "Sim, é. Mas, infelizmente, tenho coisas para fazer"

# game/characters_events_idles/sonya_idles.rpy:30
translate portugues sonya_Idle_morning_bathroom_scene_82d60fb2:

    # gg "Ты знаешь это нечестно"
    gg "Você sabe que isso não é justo"

# game/characters_events_idles/sonya_idles.rpy:32
translate portugues sonya_Idle_morning_bathroom_scene_0d7eca0c:

    # Sonya "Я просто оставляю десерт на потом"
    Sonya "Só estou deixando a sobremesa para depois"

# game/characters_events_idles/sonya_idles.rpy:34
translate portugues sonya_Idle_morning_bathroom_scene_0d86f13a:

    # Sonya "Ну что ж, герой, ванная вся твоя"
    Sonya "Bem, herói, o banheiro é todo seu"

# game/characters_events_idles/sonya_idles.rpy:35
translate portugues sonya_Idle_morning_bathroom_scene_3e148853:

    # Sonya "Главное, когда будешь мыться не забудь, кто тебя вдохновил"
    Sonya "O importante é, quando for tomar banho, não esquecer quem te inspirou"

# game/characters_events_idles/sonya_idles.rpy:50
translate portugues sonya_Idle_evening_bathroom_scene_247f83e8:

    # gg "Не думал, что можно так красиво мыться под душем"
    gg "Não imaginava que dava para tomar banho tão lindamente"

# game/characters_events_idles/sonya_idles.rpy:51
translate portugues sonya_Idle_evening_bathroom_scene_361d1da4:

    # Sonya "Я знала, что ты заглянешь"
    Sonya "Eu sabia que você ia aparecer"

# game/characters_events_idles/sonya_idles.rpy:52
translate portugues sonya_Idle_evening_bathroom_scene_dd689906:

    # Sonya "У тебя шаги узнаются ещё до двери"
    Sonya "Seus passos são reconhecíveis antes mesmo da porta"

# game/characters_events_idles/sonya_idles.rpy:54
translate portugues sonya_Idle_evening_bathroom_scene_69f260a8:

    # gg "Хотел убедиться, что ты не уплыла в параллельную реальность"
    gg "Queria ter certeza de que você não fugiu para uma realidade paralela"

# game/characters_events_idles/sonya_idles.rpy:55
translate portugues sonya_Idle_evening_bathroom_scene_81769a4a:

    # Sonya "Ещё нет. Хотя, если бы там было потеплее — можно было бы и остаться"
    Sonya "Ainda não. Mas se fosse mais quente lá, dava para ficar"

# game/characters_events_idles/sonya_idles.rpy:57
translate portugues sonya_Idle_evening_bathroom_scene_1517ae3e:

    # Sonya "Знаешь, если бы я захотела — могла бы тебя соблазнить прямо сейчас"
    Sonya "Sabe, se eu quisesse, poderia te seduzir agora mesmo"

# game/characters_events_idles/sonya_idles.rpy:58
translate portugues sonya_Idle_evening_bathroom_scene_1371ca10:

    # Sonya "Только чтобы забрать себе"
    Sonya "Só para te levar para mim"

# game/characters_events_idles/sonya_idles.rpy:60
translate portugues sonya_Idle_evening_bathroom_scene_21c8c83c:

    # Sonya "Но ты ведь тогда точно не ушёл бы, да?"
    Sonya "Mas você com certeza não iria embora, né?"

# game/characters_events_idles/sonya_idles.rpy:61
translate portugues sonya_Idle_evening_bathroom_scene_e75862b1:

    # gg "Вряд ли бы смог"
    gg "Difícilmente conseguiria"

# game/characters_events_idles/sonya_idles.rpy:64
translate portugues sonya_Idle_evening_bathroom_scene_6b3e3f56:

    # Sonya "Вот именно, поэтому уходи"
    Sonya "Exatamente, por isso vá embora"

# game/characters_events_idles/sonya_idles.rpy:65
translate portugues sonya_Idle_evening_bathroom_scene_0c771583:

    # Sonya "Пока Мая не заглянула и не устроила мне лекцию на тему “личных границ”"
    Sonya "Antes que a Maya apareça e me dê uma palestra sobre 'limites pessoais'"

# game/characters_events_idles/sonya_idles.rpy:67
translate portugues sonya_Idle_evening_bathroom_scene_7782c9fd:

    # gg "Значит, спасаю нас обоих"
    gg "Então estou salvando nós dois"

# game/characters_events_idles/sonya_idles.rpy:68
translate portugues sonya_Idle_evening_bathroom_scene_61bc67e7:

    # Sonya "Спасай. Но не надолго"
    Sonya "Salve. Mas não por muito tempo"

# game/characters_events_idles/sonya_idles.rpy:69
translate portugues sonya_Idle_evening_bathroom_scene_b8d4595f:

    # gg_chat "Её слова звучали полушуткой, но от этого не становилось легче"
    gg_chat "Suas palavras soavam como meia brincadeira, mas isso não facilitava"

# game/characters_events_idles/sonya_idles.rpy:70
translate portugues sonya_Idle_evening_bathroom_scene_0892a9fc:

    # gg_chat "В каждой улыбке Сони теперь пряталось что-то большее, чем просто игра"
    gg_chat "Em cada sorriso da Sônia agora havia algo mais do que apenas brincadeira"

# game/characters_events_idles/sonya_idles.rpy:85
translate portugues sonya_Idle_morning_girlroom_scene_5a6cf65f:

    # gg "Доброе утро. Ты уже с рассветом на работе?"
    gg "Bom dia. Já trabalhando desde o amanhecer?"

# game/characters_events_idles/sonya_idles.rpy:87
translate portugues sonya_Idle_morning_girlroom_scene_782b60a4:

    # Sonya "Почти. У меня тут урожай созрел, не могу бросить"
    Sonya "Quase. Minha colheita aqui amadureceu, não posso abandonar"

# game/characters_events_idles/sonya_idles.rpy:88
translate portugues sonya_Idle_morning_girlroom_scene_a3c52931:

    # gg "А я думал, ты в такие игры не играешь"
    gg "E eu pensei que você não jogava esses tipos de jogos"

# game/characters_events_idles/sonya_idles.rpy:90
translate portugues sonya_Idle_morning_girlroom_scene_bbda1d39:

    # Sonya "А зря, это лучшая медитация"
    Sonya "Ledo engano, é a melhor meditação"

# game/characters_events_idles/sonya_idles.rpy:91
translate portugues sonya_Idle_morning_girlroom_scene_afc574c1:

    # Sonya "Никакой спешки, просто строишь, выращиваешь, приручаешь кошек"
    Sonya "Sem pressa, só constrói, cultiva, domestica gatos"

# game/characters_events_idles/sonya_idles.rpy:93
translate portugues sonya_Idle_morning_girlroom_scene_2c50640e:

    # Sonya "Вот, видишь? Мой котик"
    Sonya "Viu? Meu gatinho"

# game/characters_events_idles/sonya_idles.rpy:94
translate portugues sonya_Idle_morning_girlroom_scene_4c464678:

    # Sonya "Зовут Барсик"
    Sonya "Chama-se Barsik"

# game/characters_events_idles/sonya_idles.rpy:95
translate portugues sonya_Idle_morning_girlroom_scene_cabe3537:

    # gg "Конечно. Даже тут он с тобой"
    gg "Claro. Até aqui ele está com você"

# game/characters_events_idles/sonya_idles.rpy:96
translate portugues sonya_Idle_morning_girlroom_scene_d4be7bb4:

    # Sonya "Да не совсем того цвета, хотя бы не ворует еду"
    Sonya "Não é bem da mesma cor, mas pelo menos não rouba comida"

# game/characters_events_idles/sonya_idles.rpy:97
translate portugues sonya_Idle_morning_girlroom_scene_725c6cbd:

    # Sonya "И на клавиатуру не ложится"
    Sonya "E não deita no teclado"

# game/characters_events_idles/sonya_idles.rpy:98
translate portugues sonya_Idle_morning_girlroom_scene_fbf5b42b:

    # Sonya "Я построила ему дом. Маленький, но уютный"
    Sonya "Fiz uma casinha para ele. Pequena, mas aconchegante"

# game/characters_events_idles/sonya_idles.rpy:100
translate portugues sonya_Idle_morning_girlroom_scene_cfe34a6f:

    # gg "Как и в жизни"
    gg "Como na vida real"

# game/characters_events_idles/sonya_idles.rpy:101
translate portugues sonya_Idle_morning_girlroom_scene_de0ba10f:

    # Sonya "Возможно. Я люблю, когда всё на своих местах. Даже в пикселях"
    Sonya "Talvez. Gosto quando tudo está no seu lugar. Até em pixels"

# game/characters_events_idles/sonya_idles.rpy:102
translate portugues sonya_Idle_morning_girlroom_scene_c16cc569:

    # gg "А с монстрами что делаешь?"
    gg "E o que faz com os monstros?"

# game/characters_events_idles/sonya_idles.rpy:104
translate portugues sonya_Idle_morning_girlroom_scene_c08d01fe:

    # Sonya "Ну избегаю. Я не про битвы, я про порядок"
    Sonya "Bom, evito. Não sou de batalhas, sou de ordem"

# game/characters_events_idles/sonya_idles.rpy:105
translate portugues sonya_Idle_morning_girlroom_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "Gosto quando tudo está sob controle"

# game/characters_events_idles/sonya_idles.rpy:107
translate portugues sonya_Idle_morning_girlroom_scene_740206dd:

    # gg "Даже кот в игре слушается. Везёт тебе"
    gg "Até o gato no jogo obedece. Sorte sua"

# game/characters_events_idles/sonya_idles.rpy:108
translate portugues sonya_Idle_morning_girlroom_scene_fb402d59:

    # Sonya "А ты попробуй приручи кого-нибудь - узнаешь, что это целая наука"
    Sonya "Você tenta domesticar alguém - vai ver que é uma ciência"

# game/characters_events_idles/sonya_idles.rpy:109
translate portugues sonya_Idle_morning_girlroom_scene_1b49be1f:

    # gg "Думаешь, справлюсь?"
    gg "Acha que eu consigo?"

# game/characters_events_idles/sonya_idles.rpy:111
translate portugues sonya_Idle_morning_girlroom_scene_228ee7fd:

    # Sonya "Сомневаюсь"
    Sonya "Duvido"

# game/characters_events_idles/sonya_idles.rpy:112
translate portugues sonya_Idle_morning_girlroom_scene_e99c47d3:

    # Sonya "Ты не тот тип, кто строит. Скорее тот, кто случайно всё ломает"
    Sonya "Você não é do tipo que constrói. Mais do tipo que acidentalmente quebra tudo"

# game/characters_events_idles/sonya_idles.rpy:113
translate portugues sonya_Idle_morning_girlroom_scene_382eac3e:

    # gg "Эй, я в детстве играл. Даже базу под землёй сделал"
    gg "Ei, eu jogava quando criança. Até fiz uma base subterrânea"

# game/characters_events_idles/sonya_idles.rpy:115
translate portugues sonya_Idle_morning_girlroom_scene_0d62bf92:

    # Sonya "Ага, и подорвал через пять минут?"
    Sonya "Ah, e explodiu depois de cinco minutos?"

# game/characters_events_idles/sonya_idles.rpy:116
translate portugues sonya_Idle_morning_girlroom_scene_81cf123c:

    # gg "Через десять. Но всё по плану"
    gg "Depois de dez. Mas tudo conforme o plano"

# game/characters_events_idles/sonya_idles.rpy:118
translate portugues sonya_Idle_morning_girlroom_scene_24c0b733:

    # Sonya "Тогда аккуратнее с моим миром"
    Sonya "Então tenha cuidado com meu mundo"

# game/characters_events_idles/sonya_idles.rpy:119
translate portugues sonya_Idle_morning_girlroom_scene_3938ea91:

    # Sonya "Тут всё с любовью и без взрывчатки"
    Sonya "Aqui tudo é com amor e sem explosivos"

# game/characters_events_idles/sonya_idles.rpy:120
translate portugues sonya_Idle_morning_girlroom_scene_5664d0ac:

    # gg "Учту. Буду только наблюдать"
    gg "Vou me lembrar. Só vou observar"

# game/characters_events_idles/sonya_idles.rpy:121
translate portugues sonya_Idle_morning_girlroom_scene_af4f45a5:

    # Sonya "Если хочешь, потом покажу тебе свой сад"
    Sonya "Se quiser, depois te mostro meu jardim"

# game/characters_events_idles/sonya_idles.rpy:122
translate portugues sonya_Idle_morning_girlroom_scene_91498926:

    # Sonya "Там столько цветов и пчелок"
    Sonya "Tem tantas flores e abelhinhas"

# game/characters_events_idles/sonya_idles.rpy:123
translate portugues sonya_Idle_morning_girlroom_scene_89b49bad:

    # gg "Звучит как место, где тебе действительно спокойно"
    gg "Parece um lugar onde você realmente fica tranquila"

# game/characters_events_idles/sonya_idles.rpy:124
translate portugues sonya_Idle_morning_girlroom_scene_4a30e5b0:

    # Sonya "Наверное да, думаю нам стоит поиграть в будущем вместе!"
    Sonya "Provavelmente sim, acho que devíamos jogar juntos no futuro!"

# game/characters_events_idles/sonya_idles.rpy:125
translate portugues sonya_Idle_morning_girlroom_scene_c8df07f1:

    # gg "Обязательно . . ."
    gg "Com certeza..."

# game/characters_events_idles/sonya_idles.rpy:139
translate portugues sonya_Idle_day_girlroom_scene_a20a3fae:

    # gg "Привет как дела?"
    gg "Oi, como vai?"

# game/characters_events_idles/sonya_idles.rpy:141
translate portugues sonya_Idle_day_girlroom_scene_9dc60813:

    # Sonya "Эти таблицы просто издеваются надо мной . . ."
    Sonya "Essas planilhas estão zombando de mim..."

# game/characters_events_idles/sonya_idles.rpy:142
translate portugues sonya_Idle_day_girlroom_scene_92df120a:

    # Sonya "Хоть бросай всё и иди пасти коров"
    Sonya "Dá vontade de largar tudo e ir pastorear vacas"

# game/characters_events_idles/sonya_idles.rpy:144
translate portugues sonya_Idle_day_girlroom_scene_e2f61865:

    # gg "Похоже, у тебя с ними война"
    gg "Parece que você está em guerra com elas"

# game/characters_events_idles/sonya_idles.rpy:146
translate portugues sonya_Idle_day_girlroom_scene_053f0179:

    # Sonya "Война, да. И я проигрываю с первого дня"
    Sonya "Guerra, sim. E estou perdendo desde o primeiro dia"

# game/characters_events_idles/sonya_idles.rpy:147
translate portugues sonya_Idle_day_girlroom_scene_d3cbfb79:

    # Sonya "Не знаю, почему все эти цифры так упрямо меня не слушаются"
    Sonya "Não sei por que todos esses números teimam em não me obedecer"

# game/characters_events_idles/sonya_idles.rpy:150
translate portugues sonya_Idle_day_girlroom_scene_8d39ea32:

    # Sonya "Знаешь, я ведь здесь выросла"
    Sonya "Sabe, eu cresci aqui"

# game/characters_events_idles/sonya_idles.rpy:151
translate portugues sonya_Idle_day_girlroom_scene_65c67f0f:

    # Sonya "Ну, не прямо в этом доме, но в этом посёлке"
    Sonya "Bem, não exatamente nesta casa, mas nesta vila"

# game/characters_events_idles/sonya_idles.rpy:152
translate portugues sonya_Idle_day_girlroom_scene_4c34bce3:

    # gg "Правда?"
    gg "Sério?"

# game/characters_events_idles/sonya_idles.rpy:154
translate portugues sonya_Idle_day_girlroom_scene_70dec560:

    # Sonya "Да. Тогда всё казалось больше - и улицы, и дома, и даже небо"
    Sonya "Sim. Naquela época tudo parecia maior - as ruas, as casas, até o céu"

# game/characters_events_idles/sonya_idles.rpy:155
translate portugues sonya_Idle_day_girlroom_scene_d0fea2c7:

    # Sonya "Потом я уехала, думала, найду место получше, что-то новое"
    Sonya "Depois fui embora, pensei que encontraria um lugar melhor, algo novo"

# game/characters_events_idles/sonya_idles.rpy:157
translate portugues sonya_Idle_day_girlroom_scene_4acb46e4:

    # Sonya "А в итоге вернулась туда, где мне и было хорошо с самого начала"
    Sonya "E no final voltei para onde já estava bem desde o início"

# game/characters_events_idles/sonya_idles.rpy:158
translate portugues sonya_Idle_day_girlroom_scene_e5c60ec3:

    # gg "А как ты познакомилась с Линдой?"
    gg "E como você conheceu a Linda?"

# game/characters_events_idles/sonya_idles.rpy:160
translate portugues sonya_Idle_day_girlroom_scene_b9747f5f:

    # Sonya "О, это было случайно"
    Sonya "Ah, foi por acaso"

# game/characters_events_idles/sonya_idles.rpy:161
translate portugues sonya_Idle_day_girlroom_scene_4203728c:

    # Sonya "Я тогда снимала комнату в соседнем доме, а она как-то увидела, что я таскаю тяжелые коробки и просто подошла помочь"
    Sonya "Eu estava alugando um quarto na casa ao lado, e ela me viu carregando caixas pesadas e simplesmente veio ajudar"

# game/characters_events_idles/sonya_idles.rpy:163
translate portugues sonya_Idle_day_girlroom_scene_6c6eaa0a:

    # Sonya "С тех пор мы начали общаться"
    Sonya "Desde então começamos a conversar"

# game/characters_events_idles/sonya_idles.rpy:164
translate portugues sonya_Idle_day_girlroom_scene_a7d57230:

    # Sonya "Она часто звала меня на чай, а потом сказала, что у неё всё равно пустует комната - и я переехала"
    Sonya "Ela frequentemente me chamava para tomar chá, e depois disse que tinha um quarto vago de qualquer forma - e eu me mudei"

# game/characters_events_idles/sonya_idles.rpy:166
translate portugues sonya_Idle_day_girlroom_scene_d72f25aa:

    # gg "То есть Линда тебя приютила?"
    gg "Então a Linda te acolheu?"

# game/characters_events_idles/sonya_idles.rpy:168
translate portugues sonya_Idle_day_girlroom_scene_181e70fe:

    # Sonya "Можно и так сказать"
    Sonya "Pode-se dizer que sim"

# game/characters_events_idles/sonya_idles.rpy:169
translate portugues sonya_Idle_day_girlroom_scene_c5827422:

    # Sonya "Она никогда не делала из этого что-то большое, просто . . . {w}была рядом"
    Sonya "Ela nunca fez disso algo grande, apenas... {w}esteve por perto"

# game/characters_events_idles/sonya_idles.rpy:170
translate portugues sonya_Idle_day_girlroom_scene_967e2aa8:

    # Sonya "Знаешь, таких людей немного"
    Sonya "Sabe, há poucas pessoas assim"

# game/characters_events_idles/sonya_idles.rpy:172
translate portugues sonya_Idle_day_girlroom_scene_6ab10a33:

    # Sonya "А теперь вот я за ее столом"
    Sonya "E agora aqui estou eu na mesa dela"

# game/characters_events_idles/sonya_idles.rpy:173
translate portugues sonya_Idle_day_girlroom_scene_75e4a1ee:

    # Sonya "Иногда кажется, что она всё ещё где-то рядом, наблюдает и тихо подсказывает, что делать"
    Sonya "Às vezes parece que ela ainda está por perto em algum lugar, observando e sussurrando o que fazer"

# game/characters_events_idles/sonya_idles.rpy:174
translate portugues sonya_Idle_day_girlroom_scene_842a9d6c:

    # gg "Может, поэтому тебе так важно всё довести до идеала"
    gg "Talvez por isso seja tão importante para você deixar tudo perfeito"

# game/characters_events_idles/sonya_idles.rpy:176
translate portugues sonya_Idle_day_girlroom_scene_e1ccf1c4:

    # Sonya "Возможно. Только вот с таблицами идеала точно не получится"
    Sonya "Possivelmente. Só que com planilhas definitivamente não vai ficar perfeito"

# game/characters_events_idles/sonya_idles.rpy:178
translate portugues sonya_Idle_day_girlroom_scene_cb6d8969:

    # Sonya "Спасибо, что подошёл"
    Sonya "Obrigada por vir"

# game/characters_events_idles/sonya_idles.rpy:179
translate portugues sonya_Idle_day_girlroom_scene_45ba29af:

    # Sonya "Без тебя я бы и дальше злилась на эти несчастные ячейки"
    Sonya "Sem você eu continuaria brava com essas células infelizes"

# game/characters_events_idles/sonya_idles.rpy:180
translate portugues sonya_Idle_day_girlroom_scene_c55fced7:

    # gg "Рад помочь"
    gg "Fico feliz em ajudar"

# game/characters_events_idles/sonya_idles.rpy:181
translate portugues sonya_Idle_day_girlroom_scene_c59d3a8e:

    # gg "Иногда лучший способ справиться с работой - просто отвлечься"
    gg "Às vezes a melhor maneira de lidar com o trabalho é simplesmente se distrair"

# game/characters_events_idles/sonya_idles.rpy:183
translate portugues sonya_Idle_day_girlroom_scene_dc01f949:

    # Sonya "Ты прав. А можешь мне чаек сделать пожалуйста . . ."
    Sonya "Você está certo. Pode fazer um chá para mim, por favor..."

# game/characters_events_idles/sonya_idles.rpy:184
translate portugues sonya_Idle_day_girlroom_scene_307a264f:

    # gg "Да конечно"
    gg "Sim, claro"

# game/characters_events_idles/sonya_idles.rpy:186
translate portugues sonya_Idle_day_girlroom_scene_b0fc80b8:

    # Sonya "Спасибо огромное"
    Sonya "Muito obrigada"

# game/characters_events_idles/sonya_idles.rpy:187
translate portugues sonya_Idle_day_girlroom_scene_11813a95:

    # gg_chat "В ней было что-то от Линды - то же спокойствие и мягкость, только моложе, живее"
    gg_chat "Havia algo da Linda nela - a mesma calma e suavidade, só que mais jovem, mais viva"

# game/characters_events_idles/sonya_idles.rpy:188
translate portugues sonya_Idle_day_girlroom_scene_660cc2e9:

    # gg_chat "И, пожалуй, даже теплее"
    gg_chat "E, talvez, até mais calorosa"

# game/characters_events_idles/sonya_idles.rpy:203
translate portugues sonya_Idle_evening_girlroom_scene_42feeaf6:

    # gg "Можно присесть?"
    gg "Posso sentar?"

# game/characters_events_idles/sonya_idles.rpy:205
translate portugues sonya_Idle_evening_girlroom_scene_8460369c:

    # Sonya "Можно . . . {w}но с тебя - плата"
    Sonya "Pode... {w}mas você paga"

# game/characters_events_idles/sonya_idles.rpy:206
translate portugues sonya_Idle_evening_girlroom_scene_a599bb6d:

    # gg "Какая?"
    gg "Qual?"

# game/characters_events_idles/sonya_idles.rpy:208
translate portugues sonya_Idle_evening_girlroom_scene_81b816f5:

    # Sonya "Остаться до конца вечера"
    Sonya "Ficar até o final da noite"

# game/characters_events_idles/sonya_idles.rpy:209
translate portugues sonya_Idle_evening_girlroom_scene_e27a7e82:

    # Sonya "И не сбежать"
    Sonya "E não fugir"

# game/characters_events_idles/sonya_idles.rpy:210
translate portugues sonya_Idle_evening_girlroom_scene_7f2d6628:

    # gg "Если ты обещаешь не гнать - я и до утра не уйду"
    gg "Se prometer não me expulsar, fico até de manhã"

# game/characters_events_idles/sonya_idles.rpy:212
translate portugues sonya_Idle_evening_girlroom_scene_1cdd78f4:

    # Sonya "Тогда, может, и расскажу что-нибудь . . . {w}личное"
    Sonya "Então talvez eu conte algo... {w}pessoal"

# game/characters_events_idles/sonya_idles.rpy:215
translate portugues sonya_Idle_evening_girlroom_scene_9eb3b8ed:

    # Sonya "Забавно, получилось"
    Sonya "Engraçado, aconteceu"

# game/characters_events_idles/sonya_idles.rpy:216
translate portugues sonya_Idle_evening_girlroom_scene_8bb9cddd:

    # Sonya "Мы с Маей обе любим тишину, но по-разному"
    Sonya "A Maya e eu ambas gostamos de silêncio, mas de formas diferentes"

# game/characters_events_idles/sonya_idles.rpy:217
translate portugues sonya_Idle_evening_girlroom_scene_fb1f6848:

    # gg "В каком смысле?"
    gg "Em que sentido?"

# game/characters_events_idles/sonya_idles.rpy:219
translate portugues sonya_Idle_evening_girlroom_scene_a5d3ae91:

    # Sonya "Она включает музыку, чтобы заглушить всё вокруг"
    Sonya "Ela coloca música para abafar tudo ao redor"

# game/characters_events_idles/sonya_idles.rpy:220
translate portugues sonya_Idle_evening_girlroom_scene_b0cd0795:

    # Sonya "А я наоборот - выключаю, чтобы услышать хоть что-то своё"
    Sonya "Eu, ao contrário, desligo para ouvir algo meu"

# game/characters_events_idles/sonya_idles.rpy:221
translate portugues sonya_Idle_evening_girlroom_scene_7162f44d:

    # gg "Тогда у тебя получается лучше"
    gg "Então você se sai melhor"

# game/characters_events_idles/sonya_idles.rpy:223
translate portugues sonya_Idle_evening_girlroom_scene_b5b15ec8:

    # Sonya "Ну не знаю"
    Sonya "Bem, não sei"

# game/characters_events_idles/sonya_idles.rpy:224
translate portugues sonya_Idle_evening_girlroom_scene_03522836:

    # Sonya "Просто по-другому"
    Sonya "Só é diferente"

# game/characters_events_idles/sonya_idles.rpy:238
translate portugues sonya_Idle_night_girlroom_scene_559d1944:

    # gg "Улыбается во сне . . ."
    gg "Sorri enquanto dorme..."

# game/characters_events_idles/sonya_idles.rpy:239
translate portugues sonya_Idle_night_girlroom_scene_5651af4c:

    # gg "Интересно, что ей снится, раз выглядит такой довольной"
    gg "O que será que ela está sonhando para parecer tão satisfeita?"

# game/characters_events_idles/sonya_idles.rpy:251
translate portugues sonya_Idle_morning_kitchen_scene_0b8a14be:

    # gg "Доброе утро, командир чистоты"
    gg "Bom dia, comandante da limpeza"

# game/characters_events_idles/sonya_idles.rpy:252
translate portugues sonya_Idle_morning_kitchen_scene_ed136649:

    # Sonya "Кто-то же должен следить, чтобы кухня не превратилась в поле боя"
    Sonya "Alguém tem que garantir que a cozinha não vire um campo de batalha"

# game/characters_events_idles/sonya_idles.rpy:254
translate portugues sonya_Idle_morning_kitchen_scene_d094394a:

    # gg "А вдруг Мая проснётся и решит помочь?"
    gg "E se a Maya acordar e decidir ajudar?"

# game/characters_events_idles/sonya_idles.rpy:256
translate portugues sonya_Idle_morning_kitchen_scene_c681883f:

    # Sonya "Тогда я просто вымою всё заново"
    Sonya "Aí eu só lavo tudo de novo"

# game/characters_events_idles/sonya_idles.rpy:258
translate portugues sonya_Idle_morning_kitchen_scene_f2c9c474:

    # gg "Значит, тебе нравится, когда всё блестит"
    gg "Então você gosta quando tudo brilha"

# game/characters_events_idles/sonya_idles.rpy:260
translate portugues sonya_Idle_morning_kitchen_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "Gosto quando tudo está sob controle"

# game/characters_events_idles/sonya_idles.rpy:261
translate portugues sonya_Idle_morning_kitchen_scene_86bbbfde:

    # gg "Даже люди?"
    gg "Até as pessoas?"

# game/characters_events_idles/sonya_idles.rpy:264
translate portugues sonya_Idle_morning_kitchen_scene_655f980e:

    # Sonya "С людьми сложнее"
    Sonya "Com pessoas é mais difícil"

# game/characters_events_idles/sonya_idles.rpy:265
translate portugues sonya_Idle_morning_kitchen_scene_6ae7acf8:

    # Sonya "Они, в отличие от кухни, редко слушаются"
    Sonya "Elas, diferente da cozinha, raramente obedecem"

# game/characters_events_idles/sonya_idles.rpy:266
translate portugues sonya_Idle_morning_kitchen_scene_efabb06d:

    # gg "Может, им просто не хватает твоего руководства"
    gg "Talvez só falte sua liderança"

# game/characters_events_idles/sonya_idles.rpy:268
translate portugues sonya_Idle_morning_kitchen_scene_59bb1b63:

    # Sonya "Осторожнее с комплиментами, а то решу, что ты тоже хочешь быть чистеньким"
    Sonya "Cuidado com os elogios, senão vou pensar que você também quer ficar limpinho"

# game/characters_events_idles/sonya_idles.rpy:269
translate portugues sonya_Idle_morning_kitchen_scene_19086387:

    # gg "Обещаю быть примерным"
    gg "Prometo ser comportado"

# game/characters_events_idles/sonya_idles.rpy:270
translate portugues sonya_Idle_morning_kitchen_scene_de5751f7:

    # gg "Хотя недолго"
    gg "Mas não por muito tempo"

# game/characters_events_idles/sonya_idles.rpy:285
translate portugues sonya_Idle_evening_kitchen_scene_74d26ab6:

    # gg "Пахнет так, будто кто-то очень старается"
    gg "Cheira como se alguém estivesse se esforçando muito"

# game/characters_events_idles/sonya_idles.rpy:287
translate portugues sonya_Idle_evening_kitchen_scene_38676ac8:

    # Sonya "А я и стараюсь"
    Sonya "E eu estou mesmo"

# game/characters_events_idles/sonya_idles.rpy:288
translate portugues sonya_Idle_evening_kitchen_scene_adfdb6f3:

    # Sonya "Без рецепта между прочем, просто . . . {w}хочется, чтобы получилось как дома"
    Sonya "Sem receita, aliás, só... {w}quero que fique como em casa"

# game/characters_events_idles/sonya_idles.rpy:289
translate portugues sonya_Idle_evening_kitchen_scene_c3970015:

    # gg "Ты часто так готовишь?"
    gg "Você cozinha assim frequentemente?"

# game/characters_events_idles/sonya_idles.rpy:291
translate portugues sonya_Idle_evening_kitchen_scene_2d72af39:

    # Sonya "Почти каждый день. С детства так привыкла"
    Sonya "Quase todo dia. Acostumei assim desde criança"

# game/characters_events_idles/sonya_idles.rpy:292
translate portugues sonya_Idle_evening_kitchen_scene_1cbd5882:

    # Sonya "Мне нравилось видеть, как люди садятся за стол и вдруг становятся добрее"
    Sonya "Gostava de ver as pessoas sentando à mesa e de repente ficando mais gentis"

# game/characters_events_idles/sonya_idles.rpy:294
translate portugues sonya_Idle_evening_kitchen_scene_33b06e3d:

    # Sonya "Еда делает людей мягче"
    Sonya "A comida deixa as pessoas mais suaves"

# game/characters_events_idles/sonya_idles.rpy:295
translate portugues sonya_Idle_evening_kitchen_scene_4347abfd:

    # Sonya "Даже тех, кто обычно каменные"
    Sonya "Até aquelas que normalmente são de pedra"

# game/characters_events_idles/sonya_idles.rpy:297
translate portugues sonya_Idle_evening_kitchen_scene_3116970e:

    # gg "Может, потому что через неё ты делишься теплом"
    gg "Talvez porque através dela você compartilhe calor"

# game/characters_events_idles/sonya_idles.rpy:298
translate portugues sonya_Idle_evening_kitchen_scene_158f9e29:

    # Sonya "Наверное"
    Sonya "Provavelmente"

# game/characters_events_idles/sonya_idles.rpy:299
translate portugues sonya_Idle_evening_kitchen_scene_2af7df75:

    # Sonya "Готовить - это ведь не просто накормить"
    Sonya "Cozinhar não é só alimentar"

# game/characters_events_idles/sonya_idles.rpy:300
translate portugues sonya_Idle_evening_kitchen_scene_668b4e51:

    # Sonya "Это сказать: “ты можешь остаться”"
    Sonya "É dizer: 'você pode ficar'"

# game/characters_events_idles/sonya_idles.rpy:302
translate portugues sonya_Idle_evening_kitchen_scene_8f974346:

    # Sonya "Помню, в детстве всё время помогала на кухне"
    Sonya "Lembro que na infância ajudava na cozinha o tempo todo"

# game/characters_events_idles/sonya_idles.rpy:303
translate portugues sonya_Idle_evening_kitchen_scene_970899ee:

    # Sonya "Мама только улыбалась - говорила, что из меня выйдет не повар, а “дом в человеческом виде”"
    Sonya "Mamãe só sorria - dizia que eu não seria uma cozinheira, mas uma 'casa em forma humana'"

# game/characters_events_idles/sonya_idles.rpy:305
translate portugues sonya_Idle_evening_kitchen_scene_22f1390f:

    # gg "Звучит будто про тебя"
    gg "Parece que é sobre você"

# game/characters_events_idles/sonya_idles.rpy:307
translate portugues sonya_Idle_evening_kitchen_scene_36c5520f:

    # Sonya "Ну вот, ужин готов"
    Sonya "Pronto, o jantar está feito"

# game/characters_events_idles/sonya_idles.rpy:308
translate portugues sonya_Idle_evening_kitchen_scene_03998218:

    # Sonya "Без изысков, но с душой"
    Sonya "Sem extravagâncias, mas com alma"

# game/characters_events_idles/sonya_idles.rpy:310
translate portugues sonya_Idle_evening_kitchen_scene_44b18404:

    # gg "Это вкуснее, чем изысканно"
    gg "Isso é mais gostoso do que extravagante"

# game/characters_events_idles/sonya_idles.rpy:311
translate portugues sonya_Idle_evening_kitchen_scene_16a4231c:

    # Sonya "Вот и хорошо"
    Sonya "Então está bom"

# game/characters_events_idles/sonya_idles.rpy:312
translate portugues sonya_Idle_evening_kitchen_scene_2c2fc2a4:

    # Sonya "Значит, не зря старалась"
    Sonya "Então não me esforcei em vão"

# game/characters_events_idles/sonya_idles.rpy:314
translate portugues sonya_Idle_evening_kitchen_scene_c6bde83f:

    # Sonya "Знаешь, мне нравится кормить людей"
    Sonya "Sabe, gosto de alimentar as pessoas"

# game/characters_events_idles/sonya_idles.rpy:315
translate portugues sonya_Idle_evening_kitchen_scene_d763faf1:

    # Sonya "Это самое простое, но честное, что я умею делать"
    Sonya "É a coisa mais simples, mas honesta, que sei fazer"

# game/characters_events_idles/sonya_idles.rpy:317
translate portugues sonya_Idle_evening_kitchen_scene_2b0e2ee7:

    # Sonya "Когда кто - то ест то, что ты приготовил, - он словно доверяет тебе"
    Sonya "Quando alguém come o que você preparou, é como se confiasse em você"

# game/characters_events_idles/sonya_idles.rpy:332
translate portugues sonya_Idle_day_kitchen_scene_ad913161:

    # gg "Всё ещё ждёшь, пока чайник закипит?"
    gg "Ainda esperando a chaleira ferver?"

# game/characters_events_idles/sonya_idles.rpy:334
translate portugues sonya_Idle_day_kitchen_scene_7f0755b3:

    # Sonya "Этот чайник кипит только если чувствует внимание. И настроение"
    Sonya "Esta chaleira só ferve se sentir atenção. E bom humor"

# game/characters_events_idles/sonya_idles.rpy:336
translate portugues sonya_Idle_day_kitchen_scene_f15d06fa:

    # gg "У него характер как у людей здесь"
    gg "Ela tem personalidade como as pessoas daqui"

# game/characters_events_idles/sonya_idles.rpy:337
translate portugues sonya_Idle_day_kitchen_scene_da15dc83:

    # Sonya "Точно. Кстати чтобы узнать получше людей здесь"
    Sonya "Exato. Aliás, para conhecer melhor as pessoas daqui"

# game/characters_events_idles/sonya_idles.rpy:340
translate portugues sonya_Idle_day_kitchen_scene_d5290e36:

    # Sonya "Тут есть пара мест для прогулок"
    Sonya "Tem alguns lugares para passear aqui"

# game/characters_events_idles/sonya_idles.rpy:341
translate portugues sonya_Idle_day_kitchen_scene_9f4c3048:

    # Sonya "Парк — небольшой, но с лавками, где можно застрять на час"
    Sonya "O parque é pequeno, mas com bancos onde dá para passar uma hora"

# game/characters_events_idles/sonya_idles.rpy:343
translate portugues sonya_Idle_day_kitchen_scene_5b433dab:

    # gg "И всё?"
    gg "E só?"

# game/characters_events_idles/sonya_idles.rpy:345
translate portugues sonya_Idle_day_kitchen_scene_35184686:

    # Sonya "Ещё озеро. Маленькое, но красивое, особенно вечером"
    Sonya "Também tem o lago. Pequeno, mas bonito, especialmente à noite"

# game/characters_events_idles/sonya_idles.rpy:346
translate portugues sonya_Idle_day_kitchen_scene_f7d54fda:

    # Sonya "Только вода бодрит так, что потом спать не хочется"
    Sonya "Só que a água é tão revigorante que depois não dá sono"

# game/characters_events_idles/sonya_idles.rpy:348
translate portugues sonya_Idle_day_kitchen_scene_95b73bc9:

    # Sonya "По субботам базар. Там продают всё — от мёда до слухов"
    Sonya "Aos sábados tem feira. Vendem de tudo — de mel a fofocas"

# game/characters_events_idles/sonya_idles.rpy:349
translate portugues sonya_Idle_day_kitchen_scene_957c11d8:

    # gg "А многоэтажка — это правда?"
    gg "E o prédio de vários andares — é verdade?"

# game/characters_events_idles/sonya_idles.rpy:351
translate portugues sonya_Idle_day_kitchen_scene_13cd2649:

    # Sonya "Правда. Наш “город в одном доме”"
    Sonya "Verdade. Nossa 'cidade em uma casa só'"

# game/characters_events_idles/sonya_idles.rpy:352
translate portugues sonya_Idle_day_kitchen_scene_c3a65cd2:

    # Sonya "Там почта, офис и девушка, которая считает себя aйтишником"
    Sonya "Lá tem correios, escritório e uma moça que se acha de TI"

# game/characters_events_idles/sonya_idles.rpy:354
translate portugues sonya_Idle_day_kitchen_scene_ed9dc13a:

    # Sonya "Вот и всё веселье. Но если смотреть внимательно — здесь больше жизни, чем кажется"
    Sonya "Essa é toda a diversão. Mas se olhar com atenção — tem mais vida aqui do que parece"

# game/characters_events_idles/sonya_idles.rpy:369
translate portugues sonya_Idle_morning_myroom_scene_3520e1f4:

    # Sonya "Ой . . . не разбудила?"
    Sonya "Oi... não acordei você?"

# game/characters_events_idles/sonya_idles.rpy:370
translate portugues sonya_Idle_morning_myroom_scene_672ee57f:

    # gg "Нет, просто не привык, что по утрам кто-то сражается с пылью"
    gg "Não, só não estou acostumado que alguém lute contra a poeira de manhã"

# game/characters_events_idles/sonya_idles.rpy:372
translate portugues sonya_Idle_morning_myroom_scene_7bcfcbe4:

    # Sonya "У каждого своё утро"
    Sonya "Cada um tem sua manhã"

# game/characters_events_idles/sonya_idles.rpy:373
translate portugues sonya_Idle_morning_myroom_scene_125e44ff:

    # Sonya "Моё - с уборки"
    Sonya "A minha é com limpeza"

# game/characters_events_idles/sonya_idles.rpy:375
translate portugues sonya_Idle_morning_myroom_scene_00768c69:

    # gg "Не думал, что ты одна из тех, кто так любит уборку"
    gg "Não imaginei que você fosse daquelas que gostam tanto de limpar"

# game/characters_events_idles/sonya_idles.rpy:377
translate portugues sonya_Idle_morning_myroom_scene_05d695dc:

    # Sonya "Не люблю. {w}Просто, если не я, никто не сделает"
    Sonya "Não gosto. {w}Só que se não for eu, ninguém faz"

# game/characters_events_idles/sonya_idles.rpy:378
translate portugues sonya_Idle_morning_myroom_scene_8b5d8733:

    # Sonya "Когда я сюда приехала, дом был знаешь . . . {w}какой-то пустой"
    Sonya "Quando cheguei aqui, a casa estava, sabe... {w}meio vazia"

# game/characters_events_idles/sonya_idles.rpy:379
translate portugues sonya_Idle_morning_myroom_scene_6e4588f3:

    # Sonya "Линда тогда часто уезжала, а Мая только въехала"
    Sonya "A Linda viajava bastante na época, e a Maya tinha acabado de mudar"

# game/characters_events_idles/sonya_idles.rpy:380
translate portugues sonya_Idle_morning_myroom_scene_b07f6cab:

    # Sonya "Всё было вверх дном"
    Sonya "Tudo estava de pernas para o ar"

# game/characters_events_idles/sonya_idles.rpy:381
translate portugues sonya_Idle_morning_myroom_scene_c3dd8e50:

    # Sonya "Я осталась - просто чтобы стало немного тише"
    Sonya "Fiquei — só para ficar um pouco mais calmo"

# game/characters_events_idles/sonya_idles.rpy:382
translate portugues sonya_Idle_morning_myroom_scene_58c3d544:

    # gg "И осталась до сих пор?"
    gg "E ficou até agora?"

# game/characters_events_idles/sonya_idles.rpy:384
translate portugues sonya_Idle_morning_myroom_scene_1e7a7a2e:

    # Sonya "Ага. Потом привыкла"
    Sonya "Sim. Depois me acostumei"

# game/characters_events_idles/sonya_idles.rpy:385
translate portugues sonya_Idle_morning_myroom_scene_ce824a84:

    # Sonya "Линда как-то сказала, что дом любит, когда в нём кто-то есть"
    Sonya "A Linda disse uma vez que a casa gosta quando tem alguém nela"

# game/characters_events_idles/sonya_idles.rpy:387
translate portugues sonya_Idle_morning_myroom_scene_80a846d0:

    # Sonya "Может, я просто не смогла уехать"
    Sonya "Talvez eu simplesmente não conseguisse ir embora"

# game/characters_events_idles/sonya_idles.rpy:389
translate portugues sonya_Idle_morning_myroom_scene_db2e4457:

    # gg "А Мая? Вы ведь такие разные"
    gg "E a Maya? Vocês são tão diferentes"

# game/characters_events_idles/sonya_idles.rpy:391
translate portugues sonya_Idle_morning_myroom_scene_55479aec:

    # Sonya "Очень"
    Sonya "Muito"

# game/characters_events_idles/sonya_idles.rpy:393
translate portugues sonya_Idle_morning_myroom_scene_e017f5bc:

    # Sonya "Я - про порядок, она - про хаос. Но в этом и суть"
    Sonya "Eu sou sobre ordem, ela sobre caos. Mas aí está o ponto"

# game/characters_events_idles/sonya_idles.rpy:396
translate portugues sonya_Idle_morning_myroom_scene_ef1d94c6:

    # Sonya "Знаешь, иногда кажется, что мы друг друга уравновешиваем"
    Sonya "Sabe, às vezes parece que nos equilibramos"

# game/characters_events_idles/sonya_idles.rpy:397
translate portugues sonya_Idle_morning_myroom_scene_77666d07:

    # Sonya "Я заставляю её остановиться, а она - меня жить чуть громче"
    Sonya "Eu a faço parar, e ela me faz viver um pouco mais alto"

# game/characters_events_idles/sonya_idles.rpy:398
translate portugues sonya_Idle_morning_myroom_scene_686dcb6d:

    # gg "Похоже, вы нашли баланс"
    gg "Parece que encontraram equilíbrio"

# game/characters_events_idles/sonya_idles.rpy:400
translate portugues sonya_Idle_morning_myroom_scene_8d1d6292:

    # Sonya "Баланс - вещь хрупкая"
    Sonya "Equilíbrio é uma coisa frágil"

# game/characters_events_idles/sonya_idles.rpy:402
translate portugues sonya_Idle_morning_myroom_scene_6e252d73:

    # Sonya "Но, кажется, с тобой он только крепче стал"
    Sonya "Mas, parece que com você ele só ficou mais forte"

# game/characters_events_idles/sonya_idles.rpy:404
translate portugues sonya_Idle_morning_myroom_scene_2e6e7590:

    # Sonya "В смысле . . . просто в доме стало уютнее"
    Sonya "Digo... só que a casa ficou mais aconchegante"

# game/characters_events_idles/sonya_idles.rpy:406
translate portugues sonya_Idle_morning_myroom_scene_6bf72907:

    # Sonya "Вот и всё"
    Sonya "Só isso"

# game/characters_events_idles/sonya_idles.rpy:407
translate portugues sonya_Idle_morning_myroom_scene_98ba9030:

    # gg "Конечно. Только уют"
    gg "Claro. Só aconchego"

# game/characters_events_idles/sonya_idles.rpy:408
translate portugues sonya_Idle_morning_myroom_scene_af3920fa:

    # Sonya "Вот именно. Только уют"
    Sonya "Exatamente. Só aconchego"

# game/characters_events_idles/sonya_idles.rpy:422
translate portugues sonya_Idle_day_myroom_scene_de06330f:

    # gg "Привет за цветами ухаживаешь?"
    gg "Oi, cuidando das flores?"

# game/characters_events_idles/sonya_idles.rpy:424
translate portugues sonya_Idle_day_myroom_scene_c76f7e91:

    # Sonya "Знаешь, за цветами нужно постоянно следить"
    Sonya "Sabe, tem que cuidar das flores constantemente"

# game/characters_events_idles/sonya_idles.rpy:426
translate portugues sonya_Idle_day_myroom_scene_95b1f24a:

    # Sonya "Не слишком много воды, не слишком мало. . . иначе начинают вянуть"
    Sonya "Nem muita água, nem pouca... senão começam a murchar"

# game/characters_events_idles/sonya_idles.rpy:427
translate portugues sonya_Idle_day_myroom_scene_ae18780a:

    # gg "Значит, всё дело в балансе"
    gg "Então é tudo questão de equilíbrio"

# game/characters_events_idles/sonya_idles.rpy:429
translate portugues sonya_Idle_day_myroom_scene_0e80b509:

    # Sonya "Внимание и время - вот что им действительно нужно"
    Sonya "Atenção e tempo — é isso que elas realmente precisam"

# game/characters_events_idles/sonya_idles.rpy:430
translate portugues sonya_Idle_day_myroom_scene_37400bc6:

    # Sonya "Не полил день - и всё, сразу обижаются"
    Sonya "Esquece um dia — e pronto, ficam magoadas"

# game/characters_events_idles/sonya_idles.rpy:432
translate portugues sonya_Idle_day_myroom_scene_b6abea2a:

    # Sonya "У каждого из них свой характер"
    Sonya "Cada uma tem sua personalidade"

# game/characters_events_idles/sonya_idles.rpy:434
translate portugues sonya_Idle_day_myroom_scene_2c042e81:

    # Sonya "Один тянется к свету, другой прячется в тень"
    Sonya "Uma busca a luz, a outra se esconde na sombra"

# game/characters_events_idles/sonya_idles.rpy:435
translate portugues sonya_Idle_day_myroom_scene_bffbba77:

    # Sonya "Есть те, кто растёт быстро, а есть, кому нужно просто больше терпения"
    Sonya "Tem as que crescem rápido, e as que só precisam de mais paciência"

# game/characters_events_idles/sonya_idles.rpy:436
translate portugues sonya_Idle_day_myroom_scene_97f84296:

    # gg "Звучит как целая наука"
    gg "Parece uma ciência inteira"

# game/characters_events_idles/sonya_idles.rpy:438
translate portugues sonya_Idle_day_myroom_scene_bc327c51:

    # Sonya "Может, и так. Только всё приходится чувствовать"
    Sonya "Pode ser. Só que tem que sentir tudo"

# game/characters_events_idles/sonya_idles.rpy:440
translate portugues sonya_Idle_day_myroom_scene_16d43fdb:

    # Sonya "Иногда они долго не цветут, и кажется, что всё зря"
    Sonya "Às vezes elas demoram para florir, e parece que foi tudo em vão"

# game/characters_events_idles/sonya_idles.rpy:441
translate portugues sonya_Idle_day_myroom_scene_df3dcafe:

    # Sonya "А потом вдруг - один день, и раскрывается бутон"
    Sonya "E então de repente — um dia, e o botão se abre"

# game/characters_events_idles/sonya_idles.rpy:443
translate portugues sonya_Idle_day_myroom_scene_3ee4994e:

    # Sonya "Линда всегда говорила, что цветы живут там, где им хорошо"
    Sonya "Linda sempre dizia que as flores vivem onde se sentem bem"

# game/characters_events_idles/sonya_idles.rpy:444
translate portugues sonya_Idle_day_myroom_scene_bfd85b59:

    # Sonya "Не потому что солнце ярче, а потому что рядом кто-то заботится"
    Sonya "Não porque o sol é mais forte, mas porque tem alguém cuidando por perto"

# game/characters_events_idles/sonya_idles.rpy:445
translate portugues sonya_Idle_day_myroom_scene_d2c9efc2:

    # gg "Наверное, это правда"
    gg "Acho que é verdade"

# game/characters_events_idles/sonya_idles.rpy:447
translate portugues sonya_Idle_day_myroom_scene_21a29e18:

    # Sonya "Думаю, да"
    Sonya "Acho que sim"

# game/characters_events_idles/sonya_idles.rpy:448
translate portugues sonya_Idle_day_myroom_scene_ea189aa5:

    # Sonya "Просто не все замечают, как это важно"
    Sonya "Só que nem todo mundo percebe o quanto isso é importante"

# game/characters_events_idles/sonya_idles.rpy:449
translate portugues sonya_Idle_day_myroom_scene_98f80f6a:

    # Sonya "Иногда достаточно совсем немного - тепла, слова, присутствия"
    Sonya "Às vezes é preciso bem pouco — calor, uma palavra, presença"

# game/characters_events_idles/sonya_idles.rpy:451
translate portugues sonya_Idle_day_myroom_scene_c2d87ad5:

    # Sonya "Главное - не перекормить заботой"
    Sonya "O importante é não exagerar nos cuidados"

# game/characters_events_idles/sonya_idles.rpy:466
translate portugues sonya_Idle_evening_myroom_scene_21cb43a6:

    # Sonya "Так, у нас есть романтика, комедия, и . . . хоррор"
    Sonya "Certo, temos romance, comédia e... terror"

# game/characters_events_idles/sonya_idles.rpy:468
translate portugues sonya_Idle_evening_myroom_scene_fd380690:

    # gg "Хоррор? Ты же потом не заснёшь"
    gg "Terror? Você não vai conseguir dormir depois"

# game/characters_events_idles/sonya_idles.rpy:470
translate portugues sonya_Idle_evening_myroom_scene_f65cd8c3:

    # Sonya "Ну тогда разбужу тебя и будем болтать до утра . . ."
    Sonya "Bom, aí eu te acordo e a gente conversa até de manhã..."

# game/characters_events_idles/sonya_idles.rpy:471
translate portugues sonya_Idle_evening_myroom_scene_0f687ebc:

    # Sonya "Вместе страдать от бессонницы"
    Sonya "Sofrendo de insônia juntos"

# game/characters_events_idles/sonya_idles.rpy:472
translate portugues sonya_Idle_evening_myroom_scene_4fc2999c:

    # gg "Ну если ты вдруг случайно начнёшь засыпать - я тебе не дам"
    gg "Bom, se você por acaso começar a adormecer — eu não deixo"

# game/characters_events_idles/sonya_idles.rpy:474
translate portugues sonya_Idle_evening_myroom_scene_d472f3eb:

    # Sonya "Просто люблю, когда немного страшно"
    Sonya "Só gosto quando dá um pouco de medo"

# game/characters_events_idles/sonya_idles.rpy:475
translate portugues sonya_Idle_evening_myroom_scene_53e63a45:

    # Sonya "В таких фильмах хоть что-то происходит по-настоящему"
    Sonya "Nesses filmes pelo menos algo acontece de verdade"

# game/characters_events_idles/sonya_idles.rpy:477
translate portugues sonya_Idle_evening_myroom_scene_80cdfb7b:

    # gg "А ты не боишься?"
    gg "E você não tem medo?"

# game/characters_events_idles/sonya_idles.rpy:479
translate portugues sonya_Idle_evening_myroom_scene_562977d2:

    # Sonya "Боюсь. {w}Но мне нравится, когда страшно только снаружи, а внутри спокойно"
    Sonya "Tenho. {w}Mas gosto quando só dá medo por fora, e por dentro está calmo"

# game/characters_events_idles/sonya_idles.rpy:481
translate portugues sonya_Idle_evening_myroom_scene_ca77da12:

    # Sonya "Хотя, если вдруг будет слишком жутко - я, может, чуть-чуть прижмусь. Для науки"
    Sonya "Mas, se ficar muito assustador, talvez eu chegue pertinho. Para fins científicos"

# game/characters_events_idles/sonya_idles.rpy:482
translate portugues sonya_Idle_evening_myroom_scene_c7a5bb2e:

    # gg "Чисто научный эксперимент?"
    gg "Puramente um experimento científico?"

# game/characters_events_idles/sonya_idles.rpy:483
translate portugues sonya_Idle_evening_myroom_scene_96d1eac0:

    # Sonya "Конечно. Проверим, снижается ли уровень паники при тесном контакте"
    Sonya "Claro. Vamos testar se o nível de pânico diminui com contato próximo"

# game/characters_events_idles/sonya_idles.rpy:487
translate portugues sonya_Idle_evening_myroom_scene_0a9cd91f:

    # Sonya "Вот видишь, уже началось"
    Sonya "Viu, já começou"

# game/characters_events_idles/sonya_idles.rpy:488
translate portugues sonya_Idle_evening_myroom_scene_4b16a16b:

    # gg "И как результаты эксперимента?"
    gg "E como estão os resultados do experimento?"

# game/characters_events_idles/sonya_idles.rpy:490
translate portugues sonya_Idle_evening_myroom_scene_1d60fbd7:

    # Sonya "Пока эффект положительный"
    Sonya "Por enquanto o efeito é positivo"

# game/characters_events_idles/sonya_idles.rpy:491
translate portugues sonya_Idle_evening_myroom_scene_c404867c:

    # Sonya "Но для точности нужно дождаться кульминации"
    Sonya "Mas para precisão precisamos esperar o clímax"

# game/characters_events_idles/sonya_idles.rpy:492
translate portugues sonya_Idle_evening_myroom_scene_24bf4b87:

    # Sonya "В такие вечера даже страх кажется уютным"
    Sonya "Nessas noites até o medo parece aconchegante"

# game/characters_events_idles/sonya_idles.rpy:493
translate portugues sonya_Idle_evening_myroom_scene_741f04d1:

    # gg "Только если есть кому его разделить"
    gg "Só se tiver alguém para dividir"

# game/characters_events_idles/sonya_idles.rpy:494
translate portugues sonya_Idle_evening_myroom_scene_cf08afaa:

    # Sonya "Думаю, у нас с этим всё в порядке"
    Sonya "Acho que estamos bem nesse aspecto"

translate portugues strings:

    # game/characters_events_idles/sonya_idles.rpy:5
    old "Доброе утро"
    new "Bom dia"

    # game/characters_events_idles/sonya_idles.rpy:48
    old "Потрясающе выглядишь"
    new "Está deslumbrante"

    # game/characters_events_idles/sonya_idles.rpy:74
    old "Мне пора"
    new "Preciso ir"

    # game/characters_events_idles/sonya_idles.rpy:138
    old "Привет"
    new "Oi"

    # game/characters_events_idles/sonya_idles.rpy:192
    old "Не мешать"
    new "Não atrapalhar"

    # game/characters_events_idles/sonya_idles.rpy:201
    old "Присесть рядом"
    new "Sentar ao lado"

    # game/characters_events_idles/sonya_idles.rpy:237
    old "Не тревожить"
    new "Não perturbar"

    # game/characters_events_idles/sonya_idles.rpy:249
    old "С добрым утром"
    new "Bom dia"

    # game/characters_events_idles/sonya_idles.rpy:274
    old "Позже загляну"
    new "Passo depois"

    # game/characters_events_idles/sonya_idles.rpy:283
    old "Вкусно пахнет"
    new "Cheira bem"

    # game/characters_events_idles/sonya_idles.rpy:330
    old "Ждешь чайник?"
    new "Esperando a chaleira?"

    # game/characters_events_idles/sonya_idles.rpy:367
    old "Опять с тряпкой?"
    new "De pano de novo?"

    # game/characters_events_idles/sonya_idles.rpy:464
    old "Что смотрим?"
    new "O que vamos assistir?"

