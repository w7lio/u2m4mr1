﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/maya_idles.rpy:7
translate portugues maya_Idle_day_myroom_scene_5a17c289:

    # gg "А я думал, этот предатель спит только у Сони"
    gg "E eu achava que esse traidor só dormia com a Sonia"

# game/characters_events_idles/maya_idles.rpy:9
translate portugues maya_Idle_day_myroom_scene_67e33434:

    # Maya "Он выбирает по настроению"
    Maya "Ele escolhe pelo humor"

# game/characters_events_idles/maya_idles.rpy:10
translate portugues maya_Idle_day_myroom_scene_d5b84977:

    # Maya "Сегодня, видимо, у меня нужная температура коленей"
    Maya "Hoje, pelo visto, meus joelhos têm a temperatura certa"

# game/characters_events_idles/maya_idles.rpy:11
translate portugues maya_Idle_day_myroom_scene_60432ccb:

    # gg "Или просто знаешь, чем подкупить"
    gg "Ou você só sabe como subornar"

# game/characters_events_idles/maya_idles.rpy:13
translate portugues maya_Idle_day_myroom_scene_e3e70aea:

    # Maya "Конечно"
    Maya "Claro"

# game/characters_events_idles/maya_idles.rpy:14
translate portugues maya_Idle_day_myroom_scene_d43eb27c:

    # Maya "Я его нашла - я и лицензированный поставщик любви и корма"
    Maya "Eu encontrei ele — eu sou a fornecedora licenciada de amor e comida"

# game/characters_events_idles/maya_idles.rpy:15
translate portugues maya_Idle_day_myroom_scene_567c8898:

    # gg "Нашла?"
    gg "Encontrou?"

# game/characters_events_idles/maya_idles.rpy:17
translate portugues maya_Idle_day_myroom_scene_a785c258:

    # Maya "Год назад. Под дождём, под машиной сидел"
    Maya "Um ano atrás. Sentado debaixo de um carro, na chuva"

# game/characters_events_idles/maya_idles.rpy:18
translate portugues maya_Idle_day_myroom_scene_81fc3249:

    # Maya "Маленький, грязный, дрожал, а я шла домой с кофе"
    Maya "Pequeno, sujo, tremendo, e eu tava voltando pra casa com café"

# game/characters_events_idles/maya_idles.rpy:19
translate portugues maya_Idle_day_myroom_scene_f0aa2ab7:

    # Maya "И подумала: “Ладно, кофе подождёт”"
    Maya "E pensei: 'Tá bom, o café pode esperar'"

# game/characters_events_idles/maya_idles.rpy:21
translate portugues maya_Idle_day_myroom_scene_8924b2a5:

    # Maya "С тех пор он решил, что я его персональный обогреватель"
    Maya "Desde então ele decidiu que eu sou o aquecedor pessoal dele"

# game/characters_events_idles/maya_idles.rpy:23
translate portugues maya_Idle_day_myroom_scene_38f294e2:

    # gg "Повезло ему"
    gg "Sortudo ele"

# game/characters_events_idles/maya_idles.rpy:25
translate portugues maya_Idle_day_myroom_scene_1538c3c1:

    # Maya "Ага. Только не говори Соне, что я так сказала"
    Maya "Sim. Só não conta pra Sonia que eu falei isso"

# game/characters_events_idles/maya_idles.rpy:26
translate portugues maya_Idle_day_myroom_scene_d9ab69f9:

    # Maya "Она делает вид, что ей всё равно, но я видела, как она однажды сушила ему лапы феном"
    Maya "Ela finge que não liga, mas eu já vi ela secando as patinhas dele com secador uma vez"

# game/characters_events_idles/maya_idles.rpy:27
translate portugues maya_Idle_day_myroom_scene_5e0ad0a7:

    # gg "Правда? Не ожидал"
    gg "Sério? Não esperava"

# game/characters_events_idles/maya_idles.rpy:28
translate portugues maya_Idle_day_myroom_scene_e31c6d2d:

    # Maya "Ну, она просто не из тех, кто сюсюкает. Но и не выгонит"
    Maya "Bem, ela não é do tipo que fica fazendo carinho. Mas também não bota pra fora"

# game/characters_events_idles/maya_idles.rpy:29
translate portugues maya_Idle_day_myroom_scene_5e1c1537:

    # Maya "Иногда подкармливает, когда думает, что я не вижу"
    Maya "Às vezes dá umas comidinhas extras quando acha que eu não tô vendo"

# game/characters_events_idles/maya_idles.rpy:30
translate portugues maya_Idle_day_myroom_scene_dd7932db:

    # Maya "У нас, знаешь, баланс: я - шум, она - порядок, а Барсик - нейтральная территория"
    Maya "A gente tem um equilíbrio, sabe: eu sou a bagunça, ela é a ordem, e o Barsik é território neutro"

# game/characters_events_idles/maya_idles.rpy:31
translate portugues maya_Idle_day_myroom_scene_ff61f178:

    # gg "И кто из вас лидер?"
    gg "E quem é o líder entre vocês?"

# game/characters_events_idles/maya_idles.rpy:33
translate portugues maya_Idle_day_myroom_scene_4579d2be:

    # Maya "Он. Сто процентов"
    Maya "Ele. Cem por cento"

# game/characters_events_idles/maya_idles.rpy:34
translate portugues maya_Idle_day_myroom_scene_73c39706:

    # Maya "Ему всё равно, кто орёт, кто убирает - он всё равно получает своё место и миску"
    Maya "Ele não tá nem aí quem grita, quem limpa — ele sempre ganha seu lugar e sua tigela"

# game/characters_events_idles/maya_idles.rpy:36
translate portugues maya_Idle_day_myroom_scene_c39583ae:

    # Maya "Видишь? {w}Даже в доме с нами двумя кто-то умеет быть по-настоящему счастливым"
    Maya "Tá vendo? {w}Até numa casa com a gente dois, alguém sabe ser verdadeiramente feliz"

# game/characters_events_idles/maya_idles.rpy:38
translate portugues maya_Idle_day_myroom_scene_04531df3:

    # gg "Может, секрет в том, чтобы просто мурчать и не спорить"
    gg "Talvez o segredo seja só ronronar e não discutir"

# game/characters_events_idles/maya_idles.rpy:39
translate portugues maya_Idle_day_myroom_scene_25a0e3ac:

    # Maya "Или в том, чтобы спать на тёплом и не думать"
    Maya "Ou em dormir num lugar quentinho e não pensar"

# game/characters_events_idles/maya_idles.rpy:54
translate portugues maya_Idle_morning_myroom_scene_323bf253:

    # gg "Уже читаешь? . . ."
    gg "Já lendo?..."
    
# game/characters_events_idles/maya_idles.rpy:55
translate portugues maya_Idle_morning_myroom_scene_92e4f307:

    # Maya "Ага. Утро тихое, редкость"
    Maya "Sim. Manhã quieta, uma raridade"

# game/characters_events_idles/maya_idles.rpy:56
translate portugues maya_Idle_morning_myroom_scene_43a1c1b0:

    # Maya "Грех не пользоваться, пока никто не шумит и не ищет кружку"
    Maya "Seria um pecado não aproveitar, enquanto ninguém tá fazendo barulho nem procurando caneca"

# game/characters_events_idles/maya_idles.rpy:57
translate portugues maya_Idle_morning_myroom_scene_7ac1c8ed:

    # gg "Что на этот раз?"
    gg "O que é dessa vez?"

# game/characters_events_idles/maya_idles.rpy:59
translate portugues maya_Idle_morning_myroom_scene_6a78f6bb:

    # Maya "Манга"
    Maya "Mangá"

# game/characters_events_idles/maya_idles.rpy:60
translate portugues maya_Idle_morning_myroom_scene_932f7db6:

    # Maya "После Линдиных книг захотелось чего-то полегче"
    Maya "Depois dos livros da Linda, deu vontade de algo mais leve"

# game/characters_events_idles/maya_idles.rpy:62
translate portugues maya_Idle_morning_myroom_scene_cffdb9b8:

    # Maya "Она могла читать про философию даже за ужином"
    Maya "Ela conseguia ler sobre filosofia até no jantar"

# game/characters_events_idles/maya_idles.rpy:63
translate portugues maya_Idle_morning_myroom_scene_3d9df54a:

    # Maya "Я же за ужином максимум комментирую философию людей в интернете"
    Maya "Eu, no jantar, no máximo comento a filosofia das pessoas na internet"

# game/characters_events_idles/maya_idles.rpy:65
translate portugues maya_Idle_morning_myroom_scene_c6ff46fa:

    # Maya "Хотя по этой манге не скажешь"
    Maya "Mas por esse mangá não dá pra ver"

# game/characters_events_idles/maya_idles.rpy:66
translate portugues maya_Idle_morning_myroom_scene_5ff05dc4:

    # Maya "Автор явно страдал, но красиво"
    Maya "O autor claramente sofreu, mas de um jeito bonito"

# game/characters_events_idles/maya_idles.rpy:67
translate portugues maya_Idle_morning_myroom_scene_f96de996:

    # gg "К картинкам и эмоциям?"
    gg "Pelas imagens e emoções?"

# game/characters_events_idles/maya_idles.rpy:69
translate portugues maya_Idle_morning_myroom_scene_b2396673:

    # Maya "К историям, где герои хотя бы честные"
    Maya "Pelas histórias onde os personagens pelo menos são honestos"

# game/characters_events_idles/maya_idles.rpy:71
translate portugues maya_Idle_morning_myroom_scene_6e6a997d:

    # Maya "Иногда читаю японское или корейское"
    Maya "Às vezes leio japonês ou coreano"

# game/characters_events_idles/maya_idles.rpy:72
translate portugues maya_Idle_morning_myroom_scene_3aeeaab4:

    # Maya "У них всё немного грустно, но по-тёплому"
    Maya "O deles é um pouco triste, mas de um jeito aconchegante"

# game/characters_events_idles/maya_idles.rpy:73
translate portugues maya_Idle_morning_myroom_scene_d16d1737:

    # Maya "В отличие от наших драм, где все страдают просто из принципа"
    Maya "Ao contrário dos nossos dramas, onde todo mundo sofre só por princípio"

# game/characters_events_idles/maya_idles.rpy:74
translate portugues maya_Idle_morning_myroom_scene_0bb250f6:

    # gg "Под настроение, значит"
    gg "Então depende do humor"

# game/characters_events_idles/maya_idles.rpy:76
translate portugues maya_Idle_morning_myroom_scene_bc0bb57f:

    # Maya "Угу. Когда настроение “оставьте меня в покое, но с уютом”"
    Maya "Aham. Quando o humor é 'me deixem em paz, mas com aconchego'"

# game/characters_events_idles/maya_idles.rpy:77
translate portugues maya_Idle_morning_myroom_scene_c92c399c:

    # gg "Ты давно здесь?"
    gg "Faz tempo que você tá aqui?"

# game/characters_events_idles/maya_idles.rpy:79
translate portugues maya_Idle_morning_myroom_scene_8b0e76c6:

    # Maya "Год, может чуть больше"
    Maya "Um ano, talvez um pouco mais"

# game/characters_events_idles/maya_idles.rpy:80
translate portugues maya_Idle_morning_myroom_scene_924b98a2:

    # Maya "После универа приехала в посёлок работать. Захотелось тишины и воздуха"
    Maya "Depois da faculdade, vim pro vilarejo trabalhar. Deu vontade de silêncio e ar puro"

# game/characters_events_idles/maya_idles.rpy:82
translate portugues maya_Idle_morning_myroom_scene_f611f1fe:

    # Maya "Искала жильё - наткнулась на объявление: “Сдам комнату. Дом с садом”"
    Maya "Tava procurando um lugar — esbarrei num anúncio: 'Alugo quarto. Casa com jardim'"

# game/characters_events_idles/maya_idles.rpy:83
translate portugues maya_Idle_morning_myroom_scene_12f76597:

    # Maya "Открывает дверь Линда и спрашивает: “Ты громкая?”"
    Maya "A Linda abre a porta e pergunta: 'Você é barulhenta?'"

# game/characters_events_idles/maya_idles.rpy:84
translate portugues maya_Idle_morning_myroom_scene_5517b596:

    # Maya "Я ответила: “Только когда думаю.” Она засмеялась и сказала: “Тогда уживайся”"
    Maya "Eu respondi: 'Só quando tô pensando.' Ela riu e disse: 'Então se acomode'"

# game/characters_events_idles/maya_idles.rpy:85
translate portugues maya_Idle_morning_myroom_scene_20b975de:

    # gg "И Соня уже тут была?"
    gg "E a Sonia já tava aqui?"

# game/characters_events_idles/maya_idles.rpy:87
translate portugues maya_Idle_morning_myroom_scene_37745fdb:

    # Maya "Да. Мы познакомились на кухне, где я чуть не спалила чайник"
    Maya "Sim. A gente se conheceu na cozinha, onde eu quase queimei a chaleira"

# game/characters_events_idles/maya_idles.rpy:88
translate portugues maya_Idle_morning_myroom_scene_4e7209b5:

    # Maya "С тех пор она - порядок, я - импровизация"
    Maya "Desde então ela é a ordem, eu sou a improvisação"

# game/characters_events_idles/maya_idles.rpy:89
translate portugues maya_Idle_morning_myroom_scene_f337d502:

    # Maya "Иногда даже чай кипит от ужаса"
    Maya "Às vezes até o chá ferve de desespero"

# game/characters_events_idles/maya_idles.rpy:90
translate portugues maya_Idle_morning_myroom_scene_b1814b27:

    # Maya "Линда звала нас “шум и тишина”"
    Maya "A Linda nos chamava de 'barulho e silêncio'"

# game/characters_events_idles/maya_idles.rpy:91
translate portugues maya_Idle_morning_myroom_scene_ab4dac88:

    # Maya "Хотя, скорее, “тишина и источник хаоса”"
    Maya "Ou melhor, 'silêncio e fonte do caos'"

# game/characters_events_idles/maya_idles.rpy:92
translate portugues maya_Idle_morning_myroom_scene_f2159d17:

    # gg "А теперь ещё и я"
    gg "E agora tem eu também"

# game/characters_events_idles/maya_idles.rpy:94
translate portugues maya_Idle_morning_myroom_scene_ecb2ad9f:

    # Maya "Теперь да. Баланс окончательно нарушен, но зато весело"
    Maya "Agora sim. O equilíbrio tá totalmente quebrado, mas pelo menos é divertido"

# game/characters_events_idles/maya_idles.rpy:96
translate portugues maya_Idle_morning_myroom_scene_cea1d0c9:

    # Maya "Вон, слышишь? Она уже с шести на ногах"
    Maya "Olha, ouviu? Ela já tá de pé desde as seis"

# game/characters_events_idles/maya_idles.rpy:97
translate portugues maya_Idle_morning_myroom_scene_deefee09:

    # Maya "Я так пробовала - уснула прямо с кружкой в руке"
    Maya "Eu tentei isso uma vez — dormi com a caneca na mão"

# game/characters_events_idles/maya_idles.rpy:98
translate portugues maya_Idle_morning_myroom_scene_bd135488:

    # Maya "Зато хоть кто-то следит, чтобы дом не просыпался в хаосе. Я - больше за безделие"
    Maya "Pelo menos alguém cuida pra casa não acordar no caos. Eu tô mais pro lado da vagabundagem"

# game/characters_events_idles/maya_idles.rpy:113
translate portugues maya_Idle_evening_bathroom_scene_d8fba7e0:

    # gg "Ко сну готовишься?"
    gg "Se preparando pra dormir?"

# game/characters_events_idles/maya_idles.rpy:114
translate portugues maya_Idle_evening_bathroom_scene_768e9905:

    # Maya "Ага. Осталось немного. Главное, чтобы никто не отвлекал"
    Maya "Sim. Falta pouco. O importante é que ninguém atrapalhe"

# game/characters_events_idles/maya_idles.rpy:115
translate portugues maya_Idle_evening_bathroom_scene_c84b09d3:

    # Maya "А то всё придётся начинать заново — тут процесс деликатный"
    Maya "Senão vai ter que começar de novo — é um processo delicado"

# game/characters_events_idles/maya_idles.rpy:116
translate portugues maya_Idle_evening_bathroom_scene_ff89b4d4:

    # gg "Надеюсь, ты не про стирку опять"
    gg "Espero que não seja sobre lavar roupa de novo"

# game/characters_events_idles/maya_idles.rpy:118
translate portugues maya_Idle_evening_bathroom_scene_63a219ac:

    # Maya "А что, если и про неё? Не все вещи выдерживают жёсткий режим"
    Maya "E se for? Nem todas as roupas aguentam o modo pesado"

# game/characters_events_idles/maya_idles.rpy:119
translate portugues maya_Idle_evening_bathroom_scene_16a58674:

    # gg "В прошлый раз ты, кажется, не всё достирала"
    gg "Da última vez você, parece, não lavou até o fim"

# game/characters_events_idles/maya_idles.rpy:121
translate portugues maya_Idle_evening_bathroom_scene_6782c239:

    # Maya "Ха. Ну, издержки ручной работы. Зато результат запомнился, верно?"
    Maya "Hah. Bem, custo do trabalho manual. Mas o resultado ficou na memória, né?"

# game/characters_events_idles/maya_idles.rpy:122
translate portugues maya_Idle_evening_bathroom_scene_d25c24db:

    # gg "Даже слишком"
    gg "Até demais"

# game/characters_events_idles/maya_idles.rpy:124
translate portugues maya_Idle_evening_bathroom_scene_a5bb0cfc:

    # Maya "Значит, не зря старалась"
    Maya "Então, não foi em vão"

# game/characters_events_idles/maya_idles.rpy:126
translate portugues maya_Idle_evening_bathroom_scene_91354786:

    # Maya "Правда, немного смущалась. Такое со мной редко бывает"
    Maya "Mas, confesso, fiquei um pouco envergonhada. Isso é raro comigo"

# game/characters_events_idles/maya_idles.rpy:127
translate portugues maya_Idle_evening_bathroom_scene_2b597177:

    # gg "Удивительно. Я думал, ты вообще не из тех, кто смущается"
    gg "Que surpresa. Achei que você nem fosse do tipo que se envergonha"

# game/characters_events_idles/maya_idles.rpy:129
translate portugues maya_Idle_evening_bathroom_scene_aa3db339:

    # Maya "Все когда-то ошибаются. Но не переживай, в следующий раз я компенсирую моральный ущерб"
    Maya "Todo mundo erra uma hora. Mas não se preocupa, da próxima vez eu compenso o dano moral"

# game/characters_events_idles/maya_idles.rpy:130
translate portugues maya_Idle_evening_bathroom_scene_ed2cbd06:

    # gg "Это угроза или обещание?"
    gg "Isso é uma ameaça ou uma promessa?"

# game/characters_events_idles/maya_idles.rpy:132
translate portugues maya_Idle_evening_bathroom_scene_0f1383f3:

    # Maya "Назови это приглашением на повторный эксперимент"
    Maya "Chame de convite pra um novo experimento"

# game/characters_events_idles/maya_idles.rpy:147
translate portugues maya_Idle_morning_kitchen_scene_ff259315:

    # gg "Это так теперь готовят яищницу?"
    gg "É assim que se faz ovo mexido agora?"

# game/characters_events_idles/maya_idles.rpy:148
translate portugues maya_Idle_morning_kitchen_scene_2a72a3a2:

    # Maya "Умник. Не все рождаются с магией кулинарии, ладно?"
    Maya "Espertinho. Nem todo mundo nasce com a magia da culinária, tá bom?"

# game/characters_events_idles/maya_idles.rpy:149
translate portugues maya_Idle_morning_kitchen_scene_5c70bf26:

    # Maya "Обычно Соня этим занимается"
    Maya "Normalmente a Sonia que cuida disso"

# game/characters_events_idles/maya_idles.rpy:151
translate portugues maya_Idle_morning_kitchen_scene_602f32f7:

    # Maya "Вот, видишь? Сковородка меня ненавидит"
    Maya "Tá vendo? A frigideira me odeia"

# game/characters_events_idles/maya_idles.rpy:152
translate portugues maya_Idle_morning_kitchen_scene_6441a501:

    # gg "Ага, ты с ней просто не разговариваешь достаточно вежливо"
    gg "Aham, você só não fala com ela com educação suficiente"

# game/characters_events_idles/maya_idles.rpy:154
translate portugues maya_Idle_morning_kitchen_scene_92534113:

    # Maya "Серьёзно? Может, ей ещё комплимент сказать?"
    Maya "Sério? Quer que eu faça um elogio também?"

# game/characters_events_idles/maya_idles.rpy:155
translate portugues maya_Idle_morning_kitchen_scene_9a46a58c:

    # gg "Можешь попробовать. Я подстрахую, если начнёт мстить"
    gg "Pode tentar. Eu seguro as pontas se ela começar a se vingar"

# game/characters_events_idles/maya_idles.rpy:157
translate portugues maya_Idle_morning_kitchen_scene_f6d334fe:

    # Maya "Вот именно поэтому я по утрам не встаю"
    Maya "É por isso que eu não levanto de manhã"

# game/characters_events_idles/maya_idles.rpy:159
translate portugues maya_Idle_morning_kitchen_scene_b8a73fc6:

    # Maya "Мир в это время суток явно против меня"
    Maya "O mundo nesse horário claramente tá contra mim"

# game/characters_events_idles/maya_idles.rpy:160
translate portugues maya_Idle_morning_kitchen_scene_92828b86:

    # gg "А я думал, это просто твой ритуал - проспать завтрак и появиться к обеду"
    gg "E eu achava que era só seu ritual — dormir o café da manhã e aparecer pro almoço"

# game/characters_events_idles/maya_idles.rpy:162
translate portugues maya_Idle_morning_kitchen_scene_2d194bcc:

    # Maya "Был"
    Maya "Era"

# game/characters_events_idles/maya_idles.rpy:163
translate portugues maya_Idle_morning_kitchen_scene_06f3f849:

    # Maya "Но с твоим появлением режим сбился"
    Maya "Mas com a sua chegada, a rotina desandou"

# game/characters_events_idles/maya_idles.rpy:165
translate portugues maya_Idle_morning_kitchen_scene_c5cd9bdc:

    # Maya "Знаешь . . . {w}странно, когда в доме появился кто-то третий"
    Maya "Sabe... {w}é estranho quando aparece uma terceira pessoa na casa"

# game/characters_events_idles/maya_idles.rpy:167
translate portugues maya_Idle_morning_kitchen_scene_2d60322d:

    # gg "“Странно” - в хорошем смысле?"
    gg "'Estranho' — no bom sentido?"

# game/characters_events_idles/maya_idles.rpy:169
translate portugues maya_Idle_morning_kitchen_scene_0392e6e1:

    # Maya "Скорее . . . непривычно."
    Maya "Mais... estranho."

# game/characters_events_idles/maya_idles.rpy:170
translate portugues maya_Idle_morning_kitchen_scene_09dca06f:

    # Maya "Мы с Соней как будто уже притёрлись. У неё - тишина, у меня - беспорядок"
    Maya "Eu e a Sonia já tínhamos nos acostumado. Ela com o silêncio, eu com a bagunça"

# game/characters_events_idles/maya_idles.rpy:171
translate portugues maya_Idle_morning_kitchen_scene_f70c520e:

    # Maya "А теперь добавился ты. И вроде ничего не изменилось, но стало . . . другое"
    Maya "E agora você chegou. E tipo, nada mudou, mas ficou... diferente"

# game/characters_events_idles/maya_idles.rpy:173
translate portugues maya_Idle_morning_kitchen_scene_ac44cc52:

    # gg "Надеюсь, не хуже"
    gg "Espero que não seja pior"

# game/characters_events_idles/maya_idles.rpy:174
translate portugues maya_Idle_morning_kitchen_scene_7331e581:

    # Maya "Пока нет"
    Maya "Por enquanto não"

# game/characters_events_idles/maya_idles.rpy:175
translate portugues maya_Idle_morning_kitchen_scene_a84e22a5:

    # Maya "Иногда даже спокойнее . . . а иногда бесишь"
    Maya "Às vezes até mais calmo... e às vezes você enche o saco"

# game/characters_events_idles/maya_idles.rpy:190
translate portugues maya_Idle_day_kitchen_scene_1cdbaa35:

    # gg "Не верится"
    gg "Não acredito"

# game/characters_events_idles/maya_idles.rpy:191
translate portugues maya_Idle_day_kitchen_scene_286ac20b:

    # gg "Ты с чаем? Где же твоя коллекция вредных газировок?"
    gg "Você com chá? Cadê sua coleção de refrigerantes nocivos?"

# game/characters_events_idles/maya_idles.rpy:193
translate portugues maya_Idle_day_kitchen_scene_158529f9:

    # Maya "Иногда организм хочет чай и все"
    Maya "Às vezes o corpo quer chá e pronto"

# game/characters_events_idles/maya_idles.rpy:194
translate portugues maya_Idle_day_kitchen_scene_61e5a4a1:

    # Maya "И не хочу, чтобы Соня опять читала лекцию о “здоровом балансе”"
    Maya "E não quero que a Sonia dê outra palestra sobre 'equilíbrio saudável'"

# game/characters_events_idles/maya_idles.rpy:195
translate portugues maya_Idle_day_kitchen_scene_0a361203:

    # gg "О, значит, это не просто чай - это акт самопожертвования"
    gg "Ah, então não é só chá — é um ato de autossacrifício"

# game/characters_events_idles/maya_idles.rpy:197
translate portugues maya_Idle_day_kitchen_scene_d1dbd3ae:

    # Maya "Ага. Пью и страдаю"
    Maya "Sim. Bebo e sofro"

# game/characters_events_idles/maya_idles.rpy:199
translate portugues maya_Idle_day_kitchen_scene_8b4629d0:

    # Maya "Ладно, раз уж ты сам подошёл - что планируешь делать?"
    Maya "Tá bom, já que você veio — o que você planeja fazer?"

# game/characters_events_idles/maya_idles.rpy:200
translate portugues maya_Idle_day_kitchen_scene_51392b4e:

    # gg "В смысле?"
    gg "Como assim?"

# game/characters_events_idles/maya_idles.rpy:202
translate portugues maya_Idle_day_kitchen_scene_e2d10f18:

    # Maya "Ну, в целом"
    Maya "Bom, no geral"

# game/characters_events_idles/maya_idles.rpy:203
translate portugues maya_Idle_day_kitchen_scene_3b447692:

    # Maya "Сидеть, отдыхать, страдать или притворяться, что у тебя есть план?"
    Maya "Ficar sentado, descansar, sofrer ou fingir que você tem um plano?"

# game/characters_events_idles/maya_idles.rpy:204
translate portugues maya_Idle_day_kitchen_scene_ba096a56:

    # gg "План есть - не иметь плана. Хотя, если честно, я просто устал от города"
    gg "O plano é não ter plano. Mas, pra ser sincero, só tô cansado da cidade"

# game/characters_events_idles/maya_idles.rpy:205
translate portugues maya_Idle_day_kitchen_scene_a341feee:

    # gg "Хотел отдохнуть, помочь бабушке с домом . . . {w}ну, а теперь, похоже, пора искать работу"
    gg "Queria descansar, ajudar minha avó com a casa... {w}bem, e agora parece que é hora de procurar emprego"

# game/characters_events_idles/maya_idles.rpy:207
translate portugues maya_Idle_day_kitchen_scene_226b1041:

    # Maya "Добро пожаловать в реальность"
    Maya "Bem-vindo à realidade"

# game/characters_events_idles/maya_idles.rpy:208
translate portugues maya_Idle_day_kitchen_scene_a886fda9:

    # Maya "И где ищут работу люди, которые сбежали от людей?"
    Maya "E onde pessoas que fugiram de pessoas procuram emprego?"

# game/characters_events_idles/maya_idles.rpy:210
translate portugues maya_Idle_day_kitchen_scene_a73a3597:

    # gg "Пока не знаю. Может, в посёлке что-то найду"
    gg "Ainda não sei. Talvez ache algo no vilarejo"

# game/characters_events_idles/maya_idles.rpy:211
translate portugues maya_Idle_day_kitchen_scene_a04c7319:

    # gg "Мне и ритм нравится - медленный, настоящий"
    gg "E eu gosto do ritmo — lento, de verdade"

# game/characters_events_idles/maya_idles.rpy:212
translate portugues maya_Idle_day_kitchen_scene_4dc705a2:

    # Maya "Настоящий?"
    Maya "De verdade?"

# game/characters_events_idles/maya_idles.rpy:213
translate portugues maya_Idle_day_kitchen_scene_57978980:

    # Maya "Это пока ты не застрянешь тут зимой"
    Maya "Isso até você ficar preso aqui no inverno"

# game/characters_events_idles/maya_idles.rpy:214
translate portugues maya_Idle_day_kitchen_scene_25de1f66:

    # gg "Зато не метро и не толпы"
    gg "Mas pelo menos não tem metrô nem multidão"

# game/characters_events_idles/maya_idles.rpy:216
translate portugues maya_Idle_day_kitchen_scene_f04c48a5:

    # Maya "Ну да. Только мы и Барсик, который судя по всему - местный депутат"
    Maya "É. Só a gente e o Barsik, que pelo visto é o deputado local"

# game/characters_events_idles/maya_idles.rpy:217
translate portugues maya_Idle_day_kitchen_scene_9b820f0a:

    # gg "Главное, чтобы не требовал отчёта о проделанной работе"
    gg "O importante é que ele não peça relatório das atividades"

# game/characters_events_idles/maya_idles.rpy:219
translate portugues maya_Idle_day_kitchen_scene_67b66e53:

    # Maya "Ага. Хотя Соня могла бы - она бы тебе график расписала"
    Maya "Sim. Mas a Sonia poderia — ela faria um cronograma pra você"

# game/characters_events_idles/maya_idles.rpy:220
translate portugues maya_Idle_day_kitchen_scene_d9d4e1ed:

    # gg "Я замечал. У неё всё как по часам"
    gg "Já percebi. Com ela tudo é no horário"

# game/characters_events_idles/maya_idles.rpy:222
translate portugues maya_Idle_day_kitchen_scene_8841e92a:

    # Maya "Потому что кто-то в этом доме должен компенсировать мой хаос"
    Maya "Porque alguém nessa casa tem que compensar meu caos"

# game/characters_events_idles/maya_idles.rpy:224
translate portugues maya_Idle_day_kitchen_scene_962fec54:

    # Maya "Так что, если решишь остаться надолго, готовься привыкать к контрастам"
    Maya "Então, se decidir ficar por muito tempo, prepare-se pra se acostumar com os contrastes"

# game/characters_events_idles/maya_idles.rpy:225
translate portugues maya_Idle_day_kitchen_scene_5401d48b:

    # gg "Мне кажется, я уже начинаю"
    gg "Acho que já tô começando"

# game/characters_events_idles/maya_idles.rpy:226
translate portugues maya_Idle_day_kitchen_scene_a207aba8:

    # Maya "Осторожнее"
    Maya "Cuidado"

# game/characters_events_idles/maya_idles.rpy:227
translate portugues maya_Idle_day_kitchen_scene_2fbe2d88:

    # Maya "Это затягивает"
    Maya "Isso vicia"

# game/characters_events_idles/maya_idles.rpy:241
translate portugues maya_Idle_morning_mayaroom_scene_f8fe1494:

    # gg ". . . "
    gg "..."

# game/characters_events_idles/maya_idles.rpy:242
translate portugues maya_Idle_morning_mayaroom_scene_7e0bd9fb:

    # gg "Так сладко спит"
    gg "Dormindo tão docemente"

# game/characters_events_idles/maya_idles.rpy:253
translate portugues maya_Idle_day_mayaroom_scene_94873986:

    # gg "Серьёзный вид"
    gg "Cara de seriedade"

# game/characters_events_idles/maya_idles.rpy:254
translate portugues maya_Idle_day_mayaroom_scene_80d9437f:

    # gg "Ты что, музыку миксуешь?"
    gg "O que, tá mixando música?"

# game/characters_events_idles/maya_idles.rpy:256
translate portugues maya_Idle_day_mayaroom_scene_f4b03c23:

    # Maya "Ха, мечтай. Работаю"
    Maya "Hah, sonha. Tô trabalhando"

# game/characters_events_idles/maya_idles.rpy:257
translate portugues maya_Idle_day_mayaroom_scene_f8277c64:

    # gg "Звучит опасно. А я думал, ты против дисциплины"
    gg "Parece perigoso. E eu achava que você era contra disciplina"

# game/characters_events_idles/maya_idles.rpy:259
translate portugues maya_Idle_day_mayaroom_scene_7888996f:

    # Maya "Я против бессмысленной дисциплины"
    Maya "Eu sou contra disciplina sem sentido"

# game/characters_events_idles/maya_idles.rpy:260
translate portugues maya_Idle_day_mayaroom_scene_927b0fd4:

    # Maya "Но если платят - можно и притвориться взрослой"
    Maya "Mas se pagam, dá pra fingir ser adulta"

# game/characters_events_idles/maya_idles.rpy:261
translate portugues maya_Idle_day_mayaroom_scene_d96b72a5:

    # gg "И что за работа?"
    gg "E que tipo de trabalho?"

# game/characters_events_idles/maya_idles.rpy:263
translate portugues maya_Idle_day_mayaroom_scene_c6edbdd9:

    # Maya "Связано с проектами. Неинтересно"
    Maya "Relacionado a projetos. Não é interessante"

# game/characters_events_idles/maya_idles.rpy:264
translate portugues maya_Idle_day_mayaroom_scene_3908c185:

    # Maya "Раньше приходилось ездить в офис, а теперь могу делать всё из дома"
    Maya "Antes tinha que ir pro escritório, agora posso fazer tudo de casa"

# game/characters_events_idles/maya_idles.rpy:266
translate portugues maya_Idle_day_mayaroom_scene_0fc56267:

    # Maya "Так что не мешай моей продуктивности"
    Maya "Então não atrapalhe minha produtividade"

# game/characters_events_idles/maya_idles.rpy:267
translate portugues maya_Idle_day_mayaroom_scene_77dec125:

    # gg "Не мешаю"
    gg "Não tô atrapalhando"

# game/characters_events_idles/maya_idles.rpy:268
translate portugues maya_Idle_day_mayaroom_scene_585ed193:

    # gg "Просто проверяю, не заснула ли ты с открытым документом"
    gg "Só tô verificando se você não dormiu com o documento aberto"

# game/characters_events_idles/maya_idles.rpy:270
translate portugues maya_Idle_day_mayaroom_scene_e95f31f8:

    # Maya "Ещё нет"
    Maya "Ainda não"

# game/characters_events_idles/maya_idles.rpy:271
translate portugues maya_Idle_day_mayaroom_scene_4d0580f6:

    # Maya "Но если будешь стоять и таращиться, это ускорит процесс"
    Maya "Mas se ficar aí encarando, vai acelerar o processo"

# game/characters_events_idles/maya_idles.rpy:274
translate portugues maya_Idle_day_mayaroom_scene_d2135720:

    # Maya "И да, на будущее . . ."
    Maya "E sim, pra próxima..."

# game/characters_events_idles/maya_idles.rpy:275
translate portugues maya_Idle_day_mayaroom_scene_8af163bc:

    # Maya "Стучи, когда входишь"
    Maya "Bata quando for entrar"

# game/characters_events_idles/maya_idles.rpy:276
translate portugues maya_Idle_day_mayaroom_scene_9797f5b6:

    # gg "А ты дверь закрывай, если хочешь секретности"
    gg "E você fecha a porta, se quer privacidade"

# game/characters_events_idles/maya_idles.rpy:278
translate portugues maya_Idle_day_mayaroom_scene_7d229fff:

    # Maya "Закрытая дверь - это скучно"
    Maya "Porta fechada é chato"

# game/characters_events_idles/maya_idles.rpy:279
translate portugues maya_Idle_day_mayaroom_scene_6d90d8fb:

    # Maya "Мне нравится знать, что кто-то может ввалиться в самый неподходящий момент. Добавляет адреналина"
    Maya "Gosto de saber que alguém pode invadir no pior momento. Adiciona adrenalina"

# game/characters_events_idles/maya_idles.rpy:280
translate portugues maya_Idle_day_mayaroom_scene_5348c7b0:

    # gg "Опасное хобби"
    gg "Hobby perigoso"

# game/characters_events_idles/maya_idles.rpy:295
translate portugues maya_Idle_evening_mayaroom_scene_c74a33fe:

    # gg "Опять зависла?"
    gg "Viajando de novo?"

# game/characters_events_idles/maya_idles.rpy:297
translate portugues maya_Idle_evening_mayaroom_scene_66aa8fb0:

    # Maya "Называется “отдыхаю”"
    Maya "Chama-se 'descansando'"

# game/characters_events_idles/maya_idles.rpy:298
translate portugues maya_Idle_evening_mayaroom_scene_29fea123:

    # Maya "Иногда даже без музыки"
    Maya "Às vezes até sem música"

# game/characters_events_idles/maya_idles.rpy:299
translate portugues maya_Idle_evening_mayaroom_scene_bbc28184:

    # gg "Опасный эксперимент"
    gg "Experimento perigoso"

# game/characters_events_idles/maya_idles.rpy:300
translate portugues maya_Idle_evening_mayaroom_scene_cc606e86:

    # Maya "Ага. Учёные уже фиксируют первые побочные эффекты - мысли начали возвращаться"
    Maya "Sim. Os cientistas já tão registrando os primeiros efeitos colaterais — os pensamentos tão voltando"

# game/characters_events_idles/maya_idles.rpy:301
translate portugues maya_Idle_evening_mayaroom_scene_a4eb2f4d:

    # gg "О чём думаешь?"
    gg "Pensando no quê?"

# game/characters_events_idles/maya_idles.rpy:303
translate portugues maya_Idle_evening_mayaroom_scene_f963639a:

    # Maya "Ни о чём особенном. Просто день какой-то неспокойный"
    Maya "Nada de especial. Só que o dia tá meio agitado"

# game/characters_events_idles/maya_idles.rpy:305
translate portugues maya_Idle_evening_mayaroom_scene_9622db09:

    # Maya "Иногда мне кажется, что этот дом дышит"
    Maya "Às vezes acho que essa casa respira"

# game/characters_events_idles/maya_idles.rpy:306
translate portugues maya_Idle_evening_mayaroom_scene_0a637ee0:

    # Maya "Когда все расходятся по комнатам, он будто вздыхает - типа “наконец-то”"
    Maya "Quando todo mundo vai pros seus quartos, ela parece suspirar — tipo 'finalmente'"

# game/characters_events_idles/maya_idles.rpy:307
translate portugues maya_Idle_evening_mayaroom_scene_c4190f3c:

    # gg "Может, он просто устал от нас"
    gg "Talvez ela só esteja cansada da gente"

# game/characters_events_idles/maya_idles.rpy:309
translate portugues maya_Idle_evening_mayaroom_scene_9a1cfc06:

    # Maya "Или от тебя"
    Maya "Ou de você"

# game/characters_events_idles/maya_idles.rpy:310
translate portugues maya_Idle_evening_mayaroom_scene_9ca1630b:

    # Maya "Ты ж теперь главный источник событий"
    Maya "Você agora é a principal fonte de eventos"

# game/characters_events_idles/maya_idles.rpy:311
translate portugues maya_Idle_evening_mayaroom_scene_4618c7f3:

    # gg "Ну спасибо"
    gg "Bom, obrigado"

# game/characters_events_idles/maya_idles.rpy:312
translate portugues maya_Idle_evening_mayaroom_scene_9314e70f:

    # gg "Хоть не шумовой загрязнитель"
    gg "Pelo menos não sou um poluidor sonoro"

# game/characters_events_idles/maya_idles.rpy:314
translate portugues maya_Idle_evening_mayaroom_scene_1c9556b7:

    # Maya "Не переживай, ты в двух шагах от этого звания"
    Maya "Não se preocupe, você tá a dois passos desse título"

# game/characters_events_idles/maya_idles.rpy:317
translate portugues maya_Idle_evening_mayaroom_scene_3ece4663:

    # gg "Ладно, не мешаю твоему “отдыханию”"
    gg "Tá bom, não vou atrapalhar seu 'descanso'"

# game/characters_events_idles/maya_idles.rpy:318
translate portugues maya_Idle_evening_mayaroom_scene_c8d80171:

    # Maya "Уже поздно. Ты в моём поле общения, это необратимо"
    Maya "Já é tarde. Você tá no meu campo de comunicação, é irreversível"

# game/characters_events_idles/maya_idles.rpy:319
translate portugues maya_Idle_evening_mayaroom_scene_52424bb1:

    # gg "Тогда я официально заражён"
    gg "Então tô oficialmente infectado"

# game/characters_events_idles/maya_idles.rpy:333
translate portugues maya_Idle_night_mayaroom_scene_f715f6b4:

    # gg "Спит без задних ног . . ."
    gg "Dormindo feito uma pedra..."

# game/characters_events_idles/maya_idles.rpy:334
translate portugues maya_Idle_night_mayaroom_scene_fd8d0a8c:

    # gg "Хоть будильник под ухом взрывай — не проснётся"
    gg "Pode explodir o despertador no ouvido dela — não acorda"

# game/characters_events_idles/maya_idles.rpy:345
translate portugues maya_Idle_evening_myroom_scene_f6ddbad8:

    # gg "Засыпаешь?"
    gg "Tá pegando no sono?"

# game/characters_events_idles/maya_idles.rpy:347
translate portugues maya_Idle_evening_myroom_scene_60b26d3f:

    # Maya "Нет. Просто отдыхаю в позе ленивой медитации"
    Maya "Não. Só descansando na pose da meditação preguiçosa"

# game/characters_events_idles/maya_idles.rpy:348
translate portugues maya_Idle_evening_myroom_scene_5197b7fb:

    # gg "Выглядит как битва с подушкой на выживание"
    gg "Parece uma batalha de sobrevivência com o travesseiro"

# game/characters_events_idles/maya_idles.rpy:350
translate portugues maya_Idle_evening_myroom_scene_ef00b824:

    # Maya "Ха. Не завидуй"
    Maya "Hah. Não tenha inveja"

# game/characters_events_idles/maya_idles.rpy:352
translate portugues maya_Idle_evening_myroom_scene_87bfdb57:

    # gg "Соня говорила что спала раньше на этом диване. Он удобный"
    gg "A Sonia disse que dormia nesse sofá antes. É confortável"

# game/characters_events_idles/maya_idles.rpy:353
translate portugues maya_Idle_evening_myroom_scene_b9e42dcf:

    # Maya "Ага. Она любила здесь засыпать под телевизор"
    Maya "Sim. Ela adormecia aqui com a TV ligada"

# game/characters_events_idles/maya_idles.rpy:354
translate portugues maya_Idle_evening_myroom_scene_01c1b004:

    # Maya "Говорила, что этот гул помогает думать"
    Maya "Dizia que aquele zumbido ajudava a pensar"

# game/characters_events_idles/maya_idles.rpy:357
translate portugues maya_Idle_evening_myroom_scene_69ea4813:

    # Maya "А теперь вот ты"
    Maya "E agora tem você"

# game/characters_events_idles/maya_idles.rpy:358
translate portugues maya_Idle_evening_myroom_scene_1c914aec:

    # Maya "И диван как будто сменил хозяина"
    Maya "E o sofá parece que trocou de dono"

# game/characters_events_idles/maya_idles.rpy:359
translate portugues maya_Idle_evening_myroom_scene_c99ae1d2:

    # gg "Ничего, я постараюсь не испортить его репутацию"
    gg "Tudo bem, vou tentar não estragar a reputação dele"

# game/characters_events_idles/maya_idles.rpy:360
translate portugues maya_Idle_evening_myroom_scene_4ed4ce95:

    # Maya "Да уж, будь добр"
    Maya "Pois é, faça o favor"

# game/characters_events_idles/maya_idles.rpy:361
translate portugues maya_Idle_evening_myroom_scene_a777aa23:

    # Maya "У него длинная история, он видел больше ссор и сериалов, чем мы оба вместе"
    Maya "Ele tem uma longa história, viu mais brigas e séries do que nós dois juntos"

# game/characters_events_idles/maya_idles.rpy:362
translate portugues maya_Idle_evening_myroom_scene_3f329134:

    # gg "Кстати, а вы вообще платите Линде за жильё? Или это всё “по знакомству”?"
    gg "A propósito, vocês pagam aluguel pra Linda? Ou é tudo 'por conhecidência'?"

# game/characters_events_idles/maya_idles.rpy:364
translate portugues maya_Idle_evening_myroom_scene_ac2bb573:

    # Maya "Платим . . . {w}Ну как “платим” - скорее благодарим"
    Maya "Pagamos... {w}bem, 'pagamos' — mais agradecemos"

# game/characters_events_idles/maya_idles.rpy:365
translate portugues maya_Idle_evening_myroom_scene_b48308d4:

    # Maya "Сумма символическая, Линда больше из принципа берёт, чем из необходимости"
    Maya "É um valor simbólico, a Linda cobra mais por princípio do que por necessidade"

# game/characters_events_idles/maya_idles.rpy:366
translate portugues maya_Idle_evening_myroom_scene_361a0566:

    # Maya "Её это, кажется, успокаивает: типа дом не стоит пустой и приносит пользу"
    Maya "Isso parece acalmá-la: tipo, a casa não fica vazia e traz benefício"

# game/characters_events_idles/maya_idles.rpy:367
translate portugues maya_Idle_evening_myroom_scene_e9782332:

    # gg "Узнаю свою бабушку"
    gg "Reconheço minha avó"

# game/characters_events_idles/maya_idles.rpy:369
translate portugues maya_Idle_evening_myroom_scene_5822e6c1:

    # Maya "Ага. Только вот было бы ещё хорошо, если бы она хотя бы предупредила, что внучок вот-вот приедет"
    Maya "Sim. Só que seria bom se ela pelo menos avisasse que o netinho tava chegando"

# game/characters_events_idles/maya_idles.rpy:370
translate portugues maya_Idle_evening_myroom_scene_3f1ab8b6:

    # Maya "Я чуть не упала тогда, когда ты появился в дверях"
    Maya "Quase caí quando você apareceu na porta"

# game/characters_events_idles/maya_idles.rpy:371
translate portugues maya_Idle_evening_myroom_scene_1bd89a55:

    # Maya "Уже чего только не думала"
    Maya "Já tava pensando de tudo"

# game/characters_events_idles/maya_idles.rpy:372
translate portugues maya_Idle_evening_myroom_scene_5d3dcdb5:

    # gg "Извини, я тоже не ожидал, что в доме будут люди"
    gg "Desculpe, também não esperava que tivesse gente na casa"

# game/characters_events_idles/maya_idles.rpy:373
translate portugues maya_Idle_evening_myroom_scene_43ff1f8d:

    # Maya "Вот и замечательно"
    Maya "Ótimo então"

# game/characters_events_idles/maya_idles.rpy:374
translate portugues maya_Idle_evening_myroom_scene_6c224d29:

    # Maya "Никто ничего не ожидал - поэтому всё как обычно"
    Maya "Ninguém esperava nada — então tá tudo como sempre"

# game/characters_events_idles/maya_idles.rpy:377
translate portugues maya_Idle_evening_myroom_scene_cbdc658c:

    # Maya "Знаешь, может, это и к лучшему"
    Maya "Sabe, talvez seja melhor assim"

# game/characters_events_idles/maya_idles.rpy:378
translate portugues maya_Idle_evening_myroom_scene_10ae6709:

    # gg "Я стараюсь как лучше"
    gg "Eu tento fazer o melhor"

# game/characters_events_idles/maya_idles.rpy:379
translate portugues maya_Idle_evening_myroom_scene_2738bbdd:

    # Maya "Ладно, ты уже часть декора"
    Maya "Tá bom, você já é parte da decoração"

# game/characters_events_idles/maya_idles.rpy:380
translate portugues maya_Idle_evening_myroom_scene_a3e55433:

    # Maya "Даже телевизор теперь включается по тебе"
    Maya "Até a TV agora liga por sua causa"

# game/characters_events_idles/maya_idles.rpy:381
translate portugues maya_Idle_evening_myroom_scene_51392b4e:

    # gg "В смысле?"
    gg "Como assim?"

# game/characters_events_idles/maya_idles.rpy:382
translate portugues maya_Idle_evening_myroom_scene_6214a218:

    # Maya "Стоит тебе появиться - сразу что-то происходит. Иногда полезное, иногда нет"
    Maya "Basta você aparecer — alguma coisa acontece. Às vezes útil, às vezes não"

# game/characters_events_idles/maya_idles.rpy:383
translate portugues maya_Idle_evening_myroom_scene_a17c73ec:

    # Maya "Но скучно с тобой не бывает"
    Maya "Mas com você nunca é chato"

# game/characters_events_idles/maya_idles.rpy:385
translate portugues maya_Idle_evening_myroom_scene_3edde83f:

    # Maya "Всё, вечер окончен"
    Maya "Pronto, noite encerrada"

# game/characters_events_idles/maya_idles.rpy:386
translate portugues maya_Idle_evening_myroom_scene_2082f32a:

    # Maya "Телевизор устал смотреть на нас"
    Maya "A TV cansou de olhar pra gente"

# game/characters_events_idles/maya_idles.rpy:387
translate portugues maya_Idle_evening_myroom_scene_3c45ded0:

    # gg "Тогда спокойной ночи"
    gg "Então boa noite"

# game/characters_events_idles/maya_idles.rpy:388
translate portugues maya_Idle_evening_myroom_scene_9adb5a5c:

    # Maya "Ага. И не растяни диван - он к тебе уже привязался"
    Maya "Sim. E não estrague o sofá — ele já tá apegado a você"

translate portugues strings:

    # game/characters_events_idles/maya_idles.rpy:5
    old "Барсик у тебя?"
    new "O Barsik tá com você?"

    # game/characters_events_idles/maya_idles.rpy:43
    old "Позже зайду"
    new "Depois eu passo"

    # game/characters_events_idles/maya_idles.rpy:52
    old "С книжкой с утра?"
    new "Com livro de manhã?"

    # game/characters_events_idles/maya_idles.rpy:102
    old "Не мешаю"
    new "Não vou atrapalhar"

    # game/characters_events_idles/maya_idles.rpy:111
    old "Ко сну готовишься?"
    new "Se preparando pra dormir?"

    # game/characters_events_idles/maya_idles.rpy:136
    old "Не буду мешать"
    new "Não vou atrapalhar"

    # game/characters_events_idles/maya_idles.rpy:145
    old "Новый рецепт?"
    new "Nova receita?"

    # game/characters_events_idles/maya_idles.rpy:188
    old "Газировка кончилась?"
    new "O refrigerante acabou?"

    # game/characters_events_idles/maya_idles.rpy:231
    old "Пойду"
    new "Vou indo"

    # game/characters_events_idles/maya_idles.rpy:240
    old "Не беспокоить"
    new "Não perturbe"

    # game/characters_events_idles/maya_idles.rpy:251
    old "Музыку миксуешь?"
    new "Tá mixando música?"

    # game/characters_events_idles/maya_idles.rpy:284
    old "Уйти"
    new "Sair"

    # game/characters_events_idles/maya_idles.rpy:293
    old "Опять зависла?"
    new "Viajando de novo?"

    # game/characters_events_idles/maya_idles.rpy:343
    old "Засыпаешь?"
    new "Tá pegando no sono?"

