﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/mc_events.rpy:84
translate portugues gg_intro_57d9b303:

    # gg "Чёрт . . . конец месяца"
    gg "Droga... final do mês"

# game/characters_events_idles/mc_events.rpy:86
translate portugues gg_intro_fc2b37ea:

    # gg "Скоро платить по долгам . . ."
    gg "Logo tenho que pagar as dívidas..."

# game/characters_events_idles/mc_events.rpy:88
translate portugues gg_intro_a14d12e5:

    # gg "Ладно . . . хоть сегодня выходной"
    gg "Tá bom... pelo menos hoje é folga"

# game/characters_events_idles/mc_events.rpy:89
translate portugues gg_intro_76bd858b:

    # gg "Хоть что-то"
    gg "Pelo menos alguma coisa"

# game/characters_events_idles/mc_events.rpy:91
translate portugues gg_intro_808930b3:

    # gg "Может, хоть пару часов отдохну. . . {w}просто расслаблюсь"
    gg "Talvez eu descanse algumas horas... {w}só relaxar"

# game/characters_events_idles/mc_events.rpy:98
translate portugues gg_intro_df03d227:

    # gg "Ну хоть здесь кто-то есть . . ."
    gg "Bom, pelo menos tem alguém aqui..."

# game/characters_events_idles/mc_events.rpy:102
translate portugues gg_intro_9b1348ec:

    # gg "Найс, я их разнес"
    gg "Massa, acabei com eles"

# game/characters_events_idles/mc_events.rpy:104
translate portugues gg_intro_f004ad75:

    # gg "Ладно . . . бывает"
    gg "Tá bom... acontece"

# game/characters_events_idles/mc_events.rpy:105
translate portugues gg_intro_3aef7ac5:

    # gg "Следующая будет норм"
    gg "A próxima vai ser de boa"

# game/characters_events_idles/mc_events.rpy:107
translate portugues gg_intro_f6ebf694:

    # gg "бляя . . ."
    gg "Porraaa..."

# game/characters_events_idles/mc_events.rpy:111
translate portugues gg_intro_e7a753f9:

    # gg "вот суки"
    gg "Esses filhos da puta"

# game/characters_events_idles/mc_events.rpy:112
translate portugues gg_intro_3a97b002:

    # gg "Окей ладно супер последняя на победу"
    gg "Ok, tá bom, última super pra vencer"

# game/characters_events_idles/mc_events.rpy:114
translate portugues gg_intro_94d70a59:

    # gg "{sc}{size=*1.5}СУКА!{/size}{/sc}" with vpunch
    gg "{sc}{size=*1.5}PORRA!{/size}{/sc}" with vpunch

# game/characters_events_idles/mc_events.rpy:118
translate portugues gg_intro_08de7acc:

    # gg "Да пошло оно всё . . ."
    gg "Ah, tudo vai pro inferno..."

# game/characters_events_idles/mc_events.rpy:119
translate portugues gg_intro_62b01796:

    # gg "Какая же трата времени"
    gg "Que perda de tempo"

# game/characters_events_idles/mc_events.rpy:122
translate portugues gg_intro_55fbce1e:

    # gg "Выходной . . . единственный день . . ."
    gg "Folga... o único dia..."

# game/characters_events_idles/mc_events.rpy:123
translate portugues gg_intro_f0abf492:

    # gg "И я просто убил его на эту грёбаную игру"
    gg "E eu simplesmente matei ele nesse maldito jogo"

# game/characters_events_idles/mc_events.rpy:125
translate portugues gg_intro_d924704e:

    # gg "Экран это единственное с чем я общаюсь последнее время"
    gg "A tela é a única coisa com que tenho conversado ultimamente"

# game/characters_events_idles/mc_events.rpy:131
translate portugues gg_intro_59ed329a:

    # gg "Я живу здесь . . . но эта квартира"
    gg "Eu moro aqui... mas esse apartamento"

# game/characters_events_idles/mc_events.rpy:132
translate portugues gg_intro_0d6c2d2c:

    # gg "Просто точка между работой и снова работой"
    gg "É só um ponto entre o trabalho e o trabalho de novo"

# game/characters_events_idles/mc_events.rpy:140
translate portugues gg_intro_7ce95d1c:

    # gg "Только там . . ."
    gg "Só que lá..."

# game/characters_events_idles/mc_events.rpy:142
translate portugues gg_intro_fa2b02fe:

    # gg "Я чувствовал себя живым"
    gg "Eu me sentia vivo"

# game/characters_events_idles/mc_events.rpy:144
translate portugues gg_intro_5a38b375:

    # gg "Я . . . устал так жить"
    gg "Eu... cansei de viver assim"

# game/characters_events_idles/mc_events.rpy:164
translate portugues gg_intro_eb77ecfa:

    # gg "Да иду я, иду . . ."
    gg "Sim, tô indo, indo..."

# game/characters_events_idles/mc_events.rpy:168
translate portugues gg_intro_565267c5:

    # gg "Кто там?"
    gg "Quem é?"

# game/characters_events_idles/mc_events.rpy:173
translate portugues gg_intro_60b12a13:

    # gg "Ты кто?"
    gg "Quem é você?"

# game/characters_events_idles/mc_events.rpy:175
translate portugues gg_intro_e00854e1:

    # PostMan "Я почтальон"
    PostMan "Sou o carteiro"

# game/characters_events_idles/mc_events.rpy:176
translate portugues gg_intro_0715dd94:

    # gg "Почтальоны теперь так одеваются?"
    gg "Os carteiros se vestem assim agora?"

# game/characters_events_idles/mc_events.rpy:178
translate portugues gg_intro_0d42e0ef:

    # PostMan "Вот смотри для тебя нарисовали"
    PostMan "Olha, desenharam pra você"

# game/characters_events_idles/mc_events.rpy:180
translate portugues gg_intro_e75db202:

    # PostMan "А я одеваюсь как хочу"
    PostMan "E eu me visto como quero"

# game/characters_events_idles/mc_events.rpy:181
translate portugues gg_intro_615e77bc:

    # gg "Так а посылка?"
    gg "E a encomenda?"

# game/characters_events_idles/mc_events.rpy:183
translate portugues gg_intro_096cd512:

    # PostMan "А! сейчас"
    PostMan "Ah! agora"

# game/characters_events_idles/mc_events.rpy:185
translate portugues gg_intro_0d3968a6:

    # PostMan "Вот, ты же [povname] правильно?"
    PostMan "Pronto, você é o [povname], certo?"

# game/characters_events_idles/mc_events.rpy:187
translate portugues gg_intro_df24437b:

    # gg "Да, спасибо"
    gg "Sim, obrigado"

# game/characters_events_idles/mc_events.rpy:189
translate portugues gg_intro_d7f65fd8:

    # PostMan "Доставка уже оплачена, так что до свидания"
    PostMan "A entrega já tá paga, então até mais"

# game/characters_events_idles/mc_events.rpy:196
translate portugues gg_intro_94ec24eb:

    # gg_chat "Эта квартира слишком дорого мне обходится"
    gg_chat "Esse apartamento custa caro demais pra mim"

# game/characters_events_idles/mc_events.rpy:200
translate portugues gg_intro_083c370e:

    # gg_chat "Эти долги меня скоро сьедят"
    gg_chat "Essas dívidas vão me consumir logo"

# game/characters_events_idles/mc_events.rpy:203
translate portugues gg_intro_a7a8221e:

    # gg_chat "Что? {w}Линда?"
    gg_chat "O quê? {w}Linda?"

# game/characters_events_idles/mc_events.rpy:208
translate portugues gg_intro_98898eb6:

    # gg_chat "От бабушки . . ."
    gg_chat "Da vovó..."

# game/characters_events_idles/mc_events.rpy:210
translate portugues gg_intro_3341868c:

    # gg_chat "Давно не видел её . . ."
    gg_chat "Faz tempo que não vejo ela..."

# game/characters_events_idles/mc_events.rpy:211
translate portugues gg_intro_6f756f5d:

    # gg_chat "Зачем она мне это?"
    gg_chat "Por que ela me manda isso?"

# game/characters_events_idles/mc_events.rpy:212
translate portugues gg_intro_9f5ccf2a:

    # "Дорогой мой, [povname]"
    "Meu querido, [povname]"

# game/characters_events_idles/mc_events.rpy:213
translate portugues gg_intro_7d8221c5:

    # "Пишу тебе это письмо с особым волнением — не потому, что что-то случилось"
    "Escrevo esta carta com uma agitação especial — não porque algo aconteceu"

# game/characters_events_idles/mc_events.rpy:214
translate portugues gg_intro_bb3819ba:

    # "А потому, что скоро мне предстоит небольшое, но долгое путешествие"
    "Mas porque em breve farei uma pequena, mas longa viagem"

# game/characters_events_idles/mc_events.rpy:215
translate portugues gg_intro_a901876a:

    # "С тех пор, как ты уехал, тут многое стало тише, спокойнее"
    "Desde que você foi embora, as coisas aqui ficaram mais quietas, mais calmas"

# game/characters_events_idles/mc_events.rpy:216
translate portugues gg_intro_8aaddaf9:

    # "Но рядом всё ещё живут хорошие люди — кто-то поможет, если нужно, кто-то просто заглянет поболтать"
    "Mas ainda há boas pessoas por perto — alguém ajuda se precisar, alguém só vem bater papo"

# game/characters_events_idles/mc_events.rpy:217
translate portugues gg_intro_8049e805:

    # "Дом, в котором ты вырос летом, скоро останется без хозяйки . . ."
    "A casa onde você cresceu no verão, logo ficará sem dona..."

# game/characters_events_idles/mc_events.rpy:218
translate portugues gg_intro_7713047b:

    # "И мне очень бы не хотелось, чтобы он начал ветшать"
    "E eu não gostaria nada que ela começasse a deteriorar"

# game/characters_events_idles/mc_events.rpy:220
translate portugues gg_intro_ce9ad3bf:

    # "Я уезжаю на несколько лет — не волнуйся, здоровье моё в порядке, просто пришло время пожить немного иначе"
    "Vou embora por alguns anos — não se preocupe, minha saúde tá boa, só chegou a hora de viver um pouco diferente"

# game/characters_events_idles/mc_events.rpy:221
translate portugues gg_intro_56cba277:

    # "Пока меня не будет, хочу тебя попросить заглядывать в дом"
    "Enquanto eu não estiver, quero pedir que você dê uma olhada na casa"

# game/characters_events_idles/mc_events.rpy:222
translate portugues gg_intro_9768b114:

    # "Пусть не пустеет, пусть скрипят половицы, пусть греется чайник"
    "Que não fique vazia, que o assoalho range, que o bule esquente"

# game/characters_events_idles/mc_events.rpy:223
translate portugues gg_intro_040e7339:

    # "Он живой, наш дом — если забросить, начнёт хандрить"
    "Ele é vivo, nossa casa — se for abandonada, vai ficar deprimida"

# game/characters_events_idles/mc_events.rpy:224
translate portugues gg_intro_581165e6:

    # gg "Она всегда так говорила . . . {w}будто дом — живой"
    gg "Ela sempre falava assim... {w}como se a casa fosse viva"

# game/characters_events_idles/mc_events.rpy:226
translate portugues gg_intro_82ffc349:

    # "И ещё . . . цветы"
    "E ainda... as flores"

# game/characters_events_idles/mc_events.rpy:227
translate portugues gg_intro_3c7f2026:

    # "Мои две любимые. Они остались"
    "Minhas duas favoritas. Elas ficaram"

# game/characters_events_idles/mc_events.rpy:228
translate portugues gg_intro_a2adc801:

    # "Одна крепкая, корнями в землю, упрямая, немного колючая, зато как зацветёт — всем на удивление"
    "Uma é forte, com raízes na terra, teimosa, um pouco espinhosa, mas quando floresce — é uma surpresa para todos"

# game/characters_events_idles/mc_events.rpy:229
translate portugues gg_intro_d1748522:

    # "Вторая — лёгкая, солнечная, смеётся даже в дождь, растёт, куда глянет, и всё ей в радость"
    "A segunda — leve, solar, ri até na chuva, cresce para onde olha, e tudo é alegria para ela"

# game/characters_events_idles/mc_events.rpy:231
translate portugues gg_intro_5cd83b3b:

    # gg_chat "Причем здесь цветы вообще . . ."
    gg_chat "O que as flores têm a ver com isso?..."

# game/characters_events_idles/mc_events.rpy:232
translate portugues gg_intro_d87a1c8d:

    # "Уход у них разный, но суть одна — внимание"
    "Os cuidados são diferentes, mas a essência é a mesma — atenção"

# game/characters_events_idles/mc_events.rpy:233
translate portugues gg_intro_0733c9df:

    # "Ты справишься — у тебя ведь моё упрямство и моё сердце"
    "Você vai conseguir — você tem a minha teimosia e o meu coração"

# game/characters_events_idles/mc_events.rpy:234
translate portugues gg_intro_3406a366:

    # "Очень хочу, чтобы ты оказался там пораньше — дом ждёт тебя"
    "Quero muito que você chegue lá logo — a casa está esperando por você"

# game/characters_events_idles/mc_events.rpy:235
translate portugues gg_intro_bfcc2649:

    # "С любовью"
    "Com amor"

# game/characters_events_idles/mc_events.rpy:236
translate portugues gg_intro_3f6a1326:

    # "Твоя бабушка Линда"
    "Sua avó, Linda"

# game/characters_events_idles/mc_events.rpy:238
translate portugues gg_intro_22bce088:

    # gg_chat "Бабушка была всегда рядом, её дом был моим домом"
    gg_chat "A vovó sempre esteve por perto, a casa dela era minha casa"

# game/characters_events_idles/mc_events.rpy:240
translate portugues gg_intro_4164e503:

    # gg_chat "Зачем она меня просит присматривать за домом?"
    gg_chat "Por que ela está me pedindo para tomar conta da casa?"

# game/characters_events_idles/mc_events.rpy:242
translate portugues gg_intro_ad05e118:

    # gg_chat "Просто взять и уехать?"
    gg_chat "Simplesmente pegar e ir embora?"

# game/characters_events_idles/mc_events.rpy:244
translate portugues gg_intro_0ae1f5e0:

    # gg_chat "Будто у меня тут ничего нет"
    gg_chat "Como se eu não tivesse nada aqui"

# game/characters_events_idles/mc_events.rpy:246
translate portugues gg_intro_e3e17f69:

    # gg_chat "У меня своих проблем по горло"
    gg_chat "Já tenho problemas até o pescoço"

# game/characters_events_idles/mc_events.rpy:248
translate portugues gg_intro_4810f11e:

    # gg_chat "Чёрт я опаздываю"
    gg_chat "Droga, estou atrasado"

# game/characters_events_idles/mc_events.rpy:250
translate portugues gg_intro_3aa5e105:

    # gg_chat "Потом поем"
    gg_chat "Depois eu como"

# game/characters_events_idles/mc_events.rpy:254
translate portugues gg_intro_4a0266b9:

    # gg_chat "Я отвечу бабушка попозже"
    gg_chat "Vou responder a vovó mais tarde"

# game/characters_events_idles/mc_events.rpy:261
translate portugues gg_intro_9cdabec6:

    # gg_chat "Серьёзно? . . ."
    gg_chat "Sério?..."
    
# game/characters_events_idles/mc_events.rpy:265
translate portugues gg_intro_7331a474:

    # gg_chat "Блять . . ."
    gg_chat "Porra..."

# game/characters_events_idles/mc_events.rpy:266
translate portugues gg_intro_db310e96:

    # gg_chat "Как всегда"
    gg_chat "Como sempre"

# game/characters_events_idles/mc_events.rpy:270
translate portugues gg_intro_4b9afd3e:

    # gg "Я пришел"
    gg "Cheguei"

# game/characters_events_idles/mc_events.rpy:272
translate portugues gg_intro_80d3fcff:

    # Assistant "Опоздал. Как всегда"
    Assistant "Atrasado. Como sempre"

# game/characters_events_idles/mc_events.rpy:274
translate portugues gg_intro_d3b968fb:

    # Assistant "И напомню: если продолжишь {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "E lembrando: se continuar {w}a conversa sobre redução salarial é só questão de tempo"

# game/characters_events_idles/mc_events.rpy:276
translate portugues gg_intro_0bd28ad3:

    # gg_chat "Да, конечно"
    gg_chat "Sim, claro"

# game/characters_events_idles/mc_events.rpy:285
translate portugues gg_intro_603b869e:

    # Director "Это срочно"
    Director "É urgente"

# game/characters_events_idles/mc_events.rpy:287
translate portugues gg_intro_eac333f5:

    # Director "За Петрова сделаешь"
    Director "Você faz a do Petrov"

# game/characters_events_idles/mc_events.rpy:289
translate portugues gg_intro_2ccd9b60:

    # gg "Это не мои задачи"
    gg "Essas não são minhas tarefas"

# game/characters_events_idles/mc_events.rpy:290
translate portugues gg_intro_df8035b4:

    # gg "Почему я должен работать за другого"
    gg "Por que tenho que trabalhar por outro?"

# game/characters_events_idles/mc_events.rpy:292
translate portugues gg_intro_e2eb6337:

    # Director "Мне плевать"
    Director "Não me importo"

# game/characters_events_idles/mc_events.rpy:294
translate portugues gg_intro_66f2f5ce:

    # Director "Сделаешь всё до конца недели"
    Director "Você faz tudo até o final da semana"

# game/characters_events_idles/mc_events.rpy:297
translate portugues gg_intro_b7d7b4b2:

    # Director "Не успеешь — сам знаешь последствия"
    Director "Se não terminar — você sabe as consequências"

# game/characters_events_idles/mc_events.rpy:303
translate portugues gg_intro_3d5010f4:

    # gg_chat "Им всегда плевать"
    gg_chat "Eles nunca se importam"

# game/characters_events_idles/mc_events.rpy:304
translate portugues gg_intro_1670588b:

    # gg_chat "Я здесь просто расходник"
    gg_chat "Sou só um descartável aqui"

# game/characters_events_idles/mc_events.rpy:308
translate portugues gg_intro_3c056c18:

    # gg_chat "Сколько ни делай — конца нет"
    gg_chat "Por mais que você faça — não tem fim"

# game/characters_events_idles/mc_events.rpy:321
translate portugues gg_intro_577e1c14:

    # Director "Секретарша сказала"
    Director "A secretária disse"

# game/characters_events_idles/mc_events.rpy:324
translate portugues gg_intro_e2282b24:

    # Director "Что ты опоздал"
    Director "Que você se atrasou"

# game/characters_events_idles/mc_events.rpy:326
translate portugues gg_intro_009afbde:

    # Director "Если не сдашь это в срок"
    Director "Se não entregar isso no prazo"

# game/characters_events_idles/mc_events.rpy:327
translate portugues gg_intro_e8f982f1:

    # Director "Можешь искать новую работу"
    Director "Pode procurar um novo emprego"

# game/characters_events_idles/mc_events.rpy:329
translate portugues gg_intro_5d67e1da:

    # Director "Понял?"
    Director "Entendeu?"

# game/characters_events_idles/mc_events.rpy:330
translate portugues gg_intro_ef555dd8:

    # gg_chat "Вот сука"
    gg_chat "Que filho da puta"

# game/characters_events_idles/mc_events.rpy:332
translate portugues gg_intro_e967e307:

    # gg "Да"
    gg "Sim"

# game/characters_events_idles/mc_events.rpy:340
translate portugues gg_intro_aba5df1c:

    # gg_chat "Им всё равно — значит, и мне тоже"
    gg_chat "Eles não se importam — então eu também não"

# game/characters_events_idles/mc_events.rpy:342
translate portugues gg_intro_59df236a:

    # gg_chat "С меня довольно"
    gg_chat "Já chega para mim"

# game/characters_events_idles/mc_events.rpy:344
translate portugues gg_intro_c0a84961:

    # gg_chat "Не поспешил ли я?"
    gg_chat "Será que me apressei demais?"

# game/characters_events_idles/mc_events.rpy:346
translate portugues gg_intro_a632776e:

    # gg_chat "Хватит"
    gg_chat "Chega"

# game/characters_events_idles/mc_events.rpy:355
translate portugues gg_intro_14d66a18:

    # Director "Ты вообще, что делаешь"
    Director "O que você está fazendo, afinal?"

# game/characters_events_idles/mc_events.rpy:357
translate portugues gg_intro_dfc9c282:

    # gg "Я увольняюсь"
    gg "Estou pedindo demissão"

# game/characters_events_idles/mc_events.rpy:359
translate portugues gg_intro_8543ef20:

    # Director "Как ты смеешь??"
    Director "Como você ousa??"

# game/characters_events_idles/mc_events.rpy:371
translate portugues gg_intro_1a1334a8:

    # Assistant "Ой"
    Assistant "Ai"

# game/characters_events_idles/mc_events.rpy:373
translate portugues gg_intro_11803396:

    # Assistant "Ты что делаешь!?"
    Assistant "O que você está fazendo!?"

# game/characters_events_idles/mc_events.rpy:374
translate portugues gg_intro_b31c2e41:

    # gg "Счастливо оставаться"
    gg "Fique bem"

# game/characters_events_idles/mc_events.rpy:376
translate portugues gg_intro_96fd98eb:

    # gg_chat "Наконец-то"
    gg_chat "Finalmente"

# game/characters_events_idles/mc_events.rpy:378
translate portugues gg_intro_e446a106:

    # gg_chat "Моя привычная жизнь закончилась"
    gg_chat "Minha vida habitual acabou"

# game/characters_events_idles/mc_events.rpy:382
translate portugues gg_intro_724c298c:

    # gg_chat "На улице столько парочек гуляет"
    gg_chat "Tem tantos casais passeando na rua"

# game/characters_events_idles/mc_events.rpy:383
translate portugues gg_intro_acc56f85:

    # gg_chat "Жизнь будто проходит мимо"
    gg_chat "A vida parece passar por mim"

# game/characters_events_idles/mc_events.rpy:397
translate portugues gg_intro_a57d47f4:

    # gg_chat "Я даже не заметил"
    gg_chat "Nem percebi"

# game/characters_events_idles/mc_events.rpy:399
translate portugues gg_intro_1ba141ba:

    # gg_chat "Только у моего родного дома был такой ключ"
    gg_chat "Só a minha casa de infância tinha uma chave assim"

# game/characters_events_idles/mc_events.rpy:401
translate portugues gg_intro_cfb8599b:

    # gg_chat "Это шанс"
    gg_chat "É uma chance"

# game/characters_events_idles/mc_events.rpy:402
translate portugues gg_intro_3ce8ccb4:

    # gg_chat "На новую жизнь"
    gg_chat "Para uma nova vida"

# game/characters_events_idles/mc_events.rpy:404
translate portugues gg_intro_4db85a28:

    # gg_chat "Это все мне больше не нужно"
    gg_chat "Não preciso mais de nada disso"

# game/characters_events_idles/mc_events.rpy:414
translate portugues gg_intro_c3f38f42:

    # gg_chat "Пора начать сначала"
    gg_chat "Hora de começar do zero"

# game/characters_events_idles/mc_events.rpy:422
translate portugues gg_intro_07728fd6:

    # gg_chat "После города — будто другой мир"
    gg_chat "Depois da cidade — é como outro mundo"

# game/characters_events_idles/mc_events.rpy:424
translate portugues gg_intro_fe890fb1:

    # gg_chat "Даже к этому я отвык . . ."
    gg_chat "Até pra isso eu desacostumei..."

# game/characters_events_idles/mc_events.rpy:428
translate portugues gg_intro_cac1bf85:

    # gg_chat "Мне здесь придётся многому научиться"
    gg_chat "Vou ter que aprender muita coisa aqui"

# game/characters_events_idles/mc_events.rpy:431
translate portugues gg_intro_a05332c8:

    # gg_chat "Я даже позабыл где дом . . ."
    gg_chat "Até esqueci onde fica a casa..."

# game/characters_events_idles/mc_events.rpy:433
translate portugues gg_intro_a4a7b296:

    # gg_chat "Все кого я вижу со мной здороваются"
    gg_chat "Todos que vejo me cumprimentam"

# game/characters_events_idles/mc_events.rpy:434
translate portugues gg_intro_720fce13:

    # gg_chat "Будто я тут не чужой"
    gg_chat "Como se eu não fosse um estranho aqui"

# game/characters_events_idles/mc_events.rpy:435
translate portugues gg_intro_094d1de6:

    # UnknownGirl "Эй парень, постой-ка!"
    UnknownGirl "Ei moço, espere aí!"

# game/characters_events_idles/mc_events.rpy:437
translate portugues gg_intro_050bbcbc:

    # gg "Здравствуйте"
    gg "Olá"

# game/characters_events_idles/mc_events.rpy:439
translate portugues gg_intro_0e31fcad:

    # UnknownGirl "Давно тут новых лиц не видели"
    UnknownGirl "Faz tempo que a gente não vê caras novas por aqui"

# game/characters_events_idles/mc_events.rpy:441
translate portugues gg_intro_0ea7d489:

    # gg "Да только приехал"
    gg "É, acabei de chegar"

# game/characters_events_idles/mc_events.rpy:443
translate portugues gg_intro_a55c0f0a:

    # UnknownGirl "У нас тут новым людям всегда рады"
    UnknownGirl "Aqui a gente sempre fica feliz com gente nova"

# game/characters_events_idles/mc_events.rpy:445
translate portugues gg_intro_096f2b23:

    # UnknownGirl "Только вот"
    UnknownGirl "Só que"

# game/characters_events_idles/mc_events.rpy:446
translate portugues gg_intro_83909d33:

    # UnknownGirl "Настоящих мужчин не хватает"
    UnknownGirl "Falta homens de verdade"

# game/characters_events_idles/mc_events.rpy:448
translate portugues gg_intro_8ffcdc07:

    # gg_chat "Что она вообще имеет в виду?"
    gg_chat "O que ela quer dizer com isso?"

# game/characters_events_idles/mc_events.rpy:450
translate portugues gg_intro_f312c19f:

    # UnknownGirl "Ладно, не пугайся. Шучу"
    UnknownGirl "Tá bom, não se assuste. Tô brincando"

# game/characters_events_idles/mc_events.rpy:452
translate portugues gg_intro_af75b79f:

    # UnknownGirl "Если что то нужно будет спрашивай помощь у любого"
    UnknownGirl "Se precisar de alguma coisa, peça ajuda a qualquer um"

# game/characters_events_idles/mc_events.rpy:454
translate portugues gg_intro_f35a0bb9:

    # UnknownGirl "Удачи тебе"
    UnknownGirl "Boa sorte pra você"

# game/characters_events_idles/mc_events.rpy:456
translate portugues gg_intro_6a134ac2:

    # gg "Хорошо и вам отличного дня"
    gg "Tá bom, e tenha um ótimo dia"

# game/characters_events_idles/mc_events.rpy:458
translate portugues gg_intro_b0f731c4:

    # gg_chat "Какая необычно добрая девушка"
    gg_chat "Que garota incomumente gentil"

# game/characters_events_idles/mc_events.rpy:459
translate portugues gg_intro_b08ae0cc:

    # gg_chat "Бабушка похоже говорила правду о людях здесь"
    gg_chat "Parece que a vovó falava a verdade sobre as pessoas daqui"

# game/characters_events_idles/mc_events.rpy:463
translate portugues gg_intro_b07cdeca:

    # gg_chat "А если там уже не так, как я помню?"
    gg_chat "E se não for mais como eu lembro?"

# game/characters_events_idles/mc_events.rpy:465
translate portugues gg_intro_2c26269d:

    # gg_chat "Но назад пути нет"
    gg_chat "Mas não há volta"

# game/characters_events_idles/mc_events.rpy:474
translate portugues gg_intro_9b8edceb:

    # gg_chat "Да дом поменялся"
    gg_chat "É, a casa mudou"

# game/characters_events_idles/mc_events.rpy:482
translate portugues gg_intro_766d518e:

    # gg_chat "Кто-то есть?"
    gg_chat "Tem alguém aí?"

# game/characters_events_idles/mc_events.rpy:492
translate portugues gg_intro_b989363c:

    # gg ". . ."
    gg "..."

# game/characters_events_idles/mc_events.rpy:498
translate portugues gg_intro_7ad2e1b7:

    # Sonya "АААА!"
    Sonya "AAAAH!"

# game/characters_events_idles/mc_events.rpy:500
translate portugues gg_intro_684edc0b:

    # Sonya "МАЯ!"
    Sonya "MAYA!"

# game/characters_events_idles/mc_events.rpy:502
translate portugues gg_intro_1124aafa:

    # Sonya "МАЯ, ТУТ КТО-ТО ЕСТЬ!!"
    Sonya "MAYA, TEM ALGUÉM AQUI!!"

# game/characters_events_idles/mc_events.rpy:506
translate portugues gg_intro_cba5cc13:

    # gg_chat "Что это сейчас было? . . ."
    gg_chat "O que foi isso agora?..."
    
# game/characters_events_idles/mc_events.rpy:508
translate portugues gg_intro_74014e3a:

    # gg_chat "Я . . ."
    gg_chat "Eu..."

# game/characters_events_idles/mc_events.rpy:510
translate portugues gg_intro_8b3408ac:

    # gg_chat "Я ничего не понял"
    gg_chat "Não entendi nada"

# game/characters_events_idles/mc_events.rpy:515
translate portugues gg_intro_18e79df2:

    # Maya "Ты кто такой?"
    Maya "Quem é você?"

# game/characters_events_idles/mc_events.rpy:517
translate portugues gg_intro_35cf3bf6:

    # Maya "Убирайся отсюда. Сейчас же"
    Maya "Cai fora daqui. Agora mesmo"

# game/characters_events_idles/mc_events.rpy:519
translate portugues gg_intro_be5ef2a9:

    # gg "Стой подожди"
    gg "Espera, calma"

# game/characters_events_idles/mc_events.rpy:521
translate portugues gg_intro_8750b79b:

    # gg "Я внук хозяйки дома"
    gg "Eu sou o neto da dona da casa"

# game/characters_events_idles/mc_events.rpy:523
translate portugues gg_intro_eba62b3e:

    # gg "Это дом моей бабушки"
    gg "Esta é a casa da minha avó"

# game/characters_events_idles/mc_events.rpy:525
translate portugues gg_intro_d179509d:

    # Maya "Внук?"
    Maya "Neto?"

# game/characters_events_idles/mc_events.rpy:527
translate portugues gg_intro_cb51aa26:

    # Maya "Что то я такого внука никогда здесь не видела"
    Maya "Algo me diz que nunca vi um neto assim por aqui"

# game/characters_events_idles/mc_events.rpy:529
translate portugues gg_intro_fde7546c:

    # Maya "Думаешь я совсем тупая"
    Maya "Acha que eu sou completamente burra?"

# game/characters_events_idles/mc_events.rpy:531
translate portugues gg_intro_a41fbef3:

    # gg "Подожди"
    gg "Espera"

# game/characters_events_idles/mc_events.rpy:533
translate portugues gg_intro_0df5d29f:

    # gg "Я не знал, что здесь кто-то живёт"
    gg "Não sabia que tinha alguém morando aqui"

# game/characters_events_idles/mc_events.rpy:535
translate portugues gg_intro_4b24971a:

    # Maya "Конечно не знал"
    Maya "Claro que não sabia"

# game/characters_events_idles/mc_events.rpy:537
translate portugues gg_intro_4af9c6fc:

    # Maya "А в чужие дома ты тоже «случайно» заходишь?"
    Maya "E em casas alheias você também entra 'por acidente'?"

# game/characters_events_idles/mc_events.rpy:543
translate portugues gg_intro_2a307bc4:

    # gg "Вот"
    gg "Aqui"

# game/characters_events_idles/mc_events.rpy:545
translate portugues gg_intro_c9e9dab5:

    # gg "Это письмо от моей бабушки"
    gg "É uma carta da minha avó"

# game/characters_events_idles/mc_events.rpy:547
translate portugues gg_intro_4a769d1b:

    # gg "Она попросила меня присмотреть за домом"
    gg "Ela me pediu para tomar conta da casa"

# game/characters_events_idles/mc_events.rpy:549
translate portugues gg_intro_ee0d1154:

    # Maya "И ты думаешь, я просто поверю этой бумажке?"
    Maya "E você acha que eu simplesmente vou acreditar nesse papel?"

# game/characters_events_idles/mc_events.rpy:551
translate portugues gg_intro_6d39543d:

    # gg "Я никуда не спешу"
    gg "Não tenho pressa pra nada"

# game/characters_events_idles/mc_events.rpy:563
translate portugues gg_intro_8ea26f73:

    # Maya "Дорогой"
    Maya "Querido"

# game/characters_events_idles/mc_events.rpy:565
translate portugues gg_intro_9a149321:

    # Maya "[povname]"
    Maya "[povname]"

# game/characters_events_idles/mc_events.rpy:569
translate portugues gg_intro_6e311c65:

    # Maya "Скоро останется без хозяйки"
    Maya "Logo ficará sem dona"

# game/characters_events_idles/mc_events.rpy:571
translate portugues gg_intro_2d481ec2:

    # Maya "Уезжаю на несколько лет"
    Maya "Vou embora por alguns anos"

# game/characters_events_idles/mc_events.rpy:573
translate portugues gg_intro_cada9fb7:

    # Maya "Мои цветы две любимые. Они остались"
    Maya "Minhas duas flores favoritas. Elas ficaram"

# game/characters_events_idles/mc_events.rpy:575
translate portugues gg_intro_4e84a3f6:

    # Maya "Дом ждёт тебя"
    Maya "A casa está esperando por você"

# game/characters_events_idles/mc_events.rpy:577
translate portugues gg_intro_a2cdc4ac:

    # Maya "Твоя бабушка Линда"
    Maya "Sua avó, Linda"

# game/characters_events_idles/mc_events.rpy:582
translate portugues gg_intro_dfc10494:

    # Maya "Боже ладно"
    Maya "Deus, tá bom"

# game/characters_events_idles/mc_events.rpy:583
translate portugues gg_intro_c4340902:

    # Maya "Похоже, на правду"
    Maya "Parece verdade"

# game/characters_events_idles/mc_events.rpy:585
translate portugues gg_intro_329e21f7:

    # Maya "Но это ничего не меняет"
    Maya "Mas isso não muda nada"

# game/characters_events_idles/mc_events.rpy:587
translate portugues gg_intro_dd6c3bfe:

    # Maya "Ты здесь чужой"
    Maya "Você é um estranho aqui"

# game/characters_events_idles/mc_events.rpy:589
translate portugues gg_intro_69801038:

    # gg "Вообще-то это мой дом"
    gg "Na verdade, esta é a minha casa"

# game/characters_events_idles/mc_events.rpy:591
translate portugues gg_intro_9a295059:

    # Maya "Это ты мы с Соней решим!"
    Maya "Isso eu e a Sonia vamos decidir!"

# game/characters_events_idles/mc_events.rpy:593
translate portugues gg_intro_9839e4df:

    # Maya "{sc}СОНЯ{/sc}" with hpunch
    Maya "{sc}SONIA{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:595
translate portugues gg_intro_2551f6f7:

    # Maya "Всё нормально, он не опасный"
    Maya "Está tudo bem, ele não é perigoso"

# game/characters_events_idles/mc_events.rpy:597
translate portugues gg_intro_d6a7eefb:

    # gg "Я так и сказал"
    gg "Eu disse que não era"

# game/characters_events_idles/mc_events.rpy:599
translate portugues gg_intro_f3cf760b:

    # Maya "Слушай если ты хоть что-то сделаешь"
    Maya "Olha, se você fizer qualquer coisa"

# game/characters_events_idles/mc_events.rpy:601
translate portugues gg_intro_d58555f3:

    # Maya "Я тебя мигом выгоню. Понял?"
    Maya "Te boto pra fora na hora. Entendeu?"

# game/characters_events_idles/mc_events.rpy:603
translate portugues gg_intro_d96e5a49:

    # gg "Понял"
    gg "Entendido"

# game/characters_events_idles/mc_events.rpy:605
translate portugues gg_intro_a59664de:

    # Maya "Жди на кухне я передам письмо соне"
    Maya "Espere na cozinha, vou entregar a carta para a Sônia"

# game/characters_events_idles/mc_events.rpy:612
translate portugues gg_intro_0ac91294:

    # gg_chat "Вот это встреча"
    gg_chat "Que encontro"

# game/characters_events_idles/mc_events.rpy:616
translate portugues gg_intro_baac99bc:

    # gg_chat "Я не ожидал такого"
    gg_chat "Eu não esperava por isso"

# game/characters_events_idles/mc_events.rpy:618
translate portugues gg_intro_feaa3808:

    # gg_chat "Почему бабушка ничего не сказала?"
    gg_chat "Por que a vovó não disse nada?"

# game/characters_events_idles/mc_events.rpy:627
translate portugues gg_intro_a070649e:

    # Sonya "Эм . . . привет"
    Sonya "Hm . . . oi"

# game/characters_events_idles/mc_events.rpy:629
translate portugues gg_intro_6a2024b3:

    # Sonya "Я . . . я Соня"
    Sonya "Eu . . . eu sou a Sônia"

# game/characters_events_idles/mc_events.rpy:631
translate portugues gg_intro_12083d44:

    # Sonya "Я надеюсь ты не обиделся на Маю"
    Sonya "Espero que não esteja bravo com a Maya"

# game/characters_events_idles/mc_events.rpy:633
translate portugues gg_intro_dfe04d57:

    # gg "Нет. Всё нормально"
    gg "Não. Tudo bem"

# game/characters_events_idles/mc_events.rpy:635
translate portugues gg_intro_85f8708a:

    # gg "Я [povname]"
    gg "Eu sou [povname]"

# game/characters_events_idles/mc_events.rpy:637
translate portugues gg_intro_78b27818:

    # Sonya "Мая сказала, что ты внук Линды"
    Sonya "Maya disse que você é neto da Linda"

# game/characters_events_idles/mc_events.rpy:638
translate portugues gg_intro_b5f632a7:

    # Sonya "Так . . . неожиданно получилось"
    Sonya "Foi . . . tão inesperado"

# game/characters_events_idles/mc_events.rpy:643
translate portugues gg_intro_053ce261:

    # Sonya "И если честно"
    Sonya "E para ser honesta"

# game/characters_events_idles/mc_events.rpy:645
translate portugues gg_intro_4bf5a43d:

    # Sonya "Я сначала очень испугалась"
    Sonya "No começo, eu fiquei muito assustada"

# game/characters_events_idles/mc_events.rpy:649
translate portugues gg_intro_87cb5bde:

    # gg "Извини"
    gg "Desculpa"

# game/characters_events_idles/mc_events.rpy:651
translate portugues gg_intro_1dc14df3:

    # gg "Я правда не хотел тебя пугать, стоило постучать"
    gg "Eu realmente não queria te assustar, deveria ter batido"

# game/characters_events_idles/mc_events.rpy:655
translate portugues gg_intro_2d8b9c21:

    # Sonya "Нет-нет всё нормально"
    Sonya "Não-não, está tudo bem"

# game/characters_events_idles/mc_events.rpy:657
translate portugues gg_intro_9587b334:

    # Sonya "Просто не ожидали гостей"
    Sonya "Só não estávamos esperando visitas"

# game/characters_events_idles/mc_events.rpy:661
translate portugues gg_intro_9a863e77:

    # Sonya "Я прочла письмо линды"
    Sonya "Eu li a carta da Linda"

# game/characters_events_idles/mc_events.rpy:663
translate portugues gg_intro_c7d51db6:

    # Sonya "Там про цветы было"
    Sonya "Era sobre as flores"

# game/characters_events_idles/mc_events.rpy:665
translate portugues gg_intro_c9e9d0a0:

    # Sonya "Это она так нас описывает"
    Sonya "É assim que ela nos descreve"

# game/characters_events_idles/mc_events.rpy:669
translate portugues gg_intro_7b39b9b5:

    # Sonya "Мы с Маей живём здесь вместе"
    Sonya "A Maya e eu moramos aqui juntas"

# game/characters_events_idles/mc_events.rpy:671
translate portugues gg_intro_c3003883:

    # Sonya "Линда сначала просто сдавала нам комнаты"
    Sonya "No início, Linda só nos alugava os quartos"

# game/characters_events_idles/mc_events.rpy:673
translate portugues gg_intro_eb14c7b5:

    # Sonya "А потом, когда уехала, сказала, что дом остаётся на нас"
    Sonya "E depois, quando ela partiu, disse que a casa ficava conosco"

# game/characters_events_idles/mc_events.rpy:675
translate portugues gg_intro_6dcfd261:

    # gg "То есть вы тут уже давно?"
    gg "Então vocês já estão aqui há muito tempo?"

# game/characters_events_idles/mc_events.rpy:677
translate portugues gg_intro_c8772e87:

    # Sonya "Да"
    Sonya "Sim"

# game/characters_events_idles/mc_events.rpy:679
translate portugues gg_intro_5e85de7c:

    # Sonya "Мы привыкли. Даже кота завели"
    Sonya "Nos acostumamos. Até pegamos um gato"

# game/characters_events_idles/mc_events.rpy:681
translate portugues gg_intro_0879bf60:

    # Sonya "Для нас это уже дом"
    Sonya "Para nós, já é nosso lar"

# game/characters_events_idles/mc_events.rpy:683
translate portugues gg_intro_dad9ef91:

    # Sonya "Линда иногда о тебе говорила"
    Sonya "Linda às vezes falava sobre você"

# game/characters_events_idles/mc_events.rpy:685
translate portugues gg_intro_a3493fdc:

    # Sonya "Говорила, что ты хороший, по крайнее мерее в дестве"
    Sonya "Dizia que você era bom, pelo menos quando criança"

# game/characters_events_idles/mc_events.rpy:687
translate portugues gg_intro_0782f2e3:

    # gg "Надеюсь, она не слишком приукрашивала"
    gg "Espero que ela não tenha exagerado muito"

# game/characters_events_idles/mc_events.rpy:689
translate portugues gg_intro_3e3d596e:

    # gg "Сейчас я сам не знаю, кем стал"
    gg "Agora eu mesmo não sei no que me tornei"

# game/characters_events_idles/mc_events.rpy:691
translate portugues gg_intro_b8032679:

    # Sonya "А ты . . ."
    Sonya "E você . . ."

# game/characters_events_idles/mc_events.rpy:693
translate portugues gg_intro_7ad63786:

    # Sonya "Ты надолго?"
    Sonya "Você fica muito tempo?"

# game/characters_events_idles/mc_events.rpy:695
translate portugues gg_intro_c2f6d189:

    # Sonya "Ну какой у тебя дальше план?"
    Sonya "Tipo, quais são seus planos agora?"

# game/characters_events_idles/mc_events.rpy:697
translate portugues gg_intro_9f30eca5:

    # gg "Я пока не знаю"
    gg "Ainda não sei"

# game/characters_events_idles/mc_events.rpy:699
translate portugues gg_intro_51f05bc9:

    # gg "Мне нужно время"
    gg "Preciso de tempo"

# game/characters_events_idles/mc_events.rpy:701
translate portugues gg_intro_301f9bbb:

    # gg_chat "Хотя здесь приятно"
    gg_chat "Embora seja agradável aqui"

# game/characters_events_idles/mc_events.rpy:704
translate portugues gg_intro_a1c2b87a:

    # gg_chat "И как-то спокойно"
    gg_chat "E é tão calmo"

# game/characters_events_idles/mc_events.rpy:706
translate portugues gg_intro_1043df55:

    # Sonya "Уже поздно"
    Sonya "Já está tarde"

# game/characters_events_idles/mc_events.rpy:708
translate portugues gg_intro_f1483558:

    # Sonya "Мы можем поговорить ещё потом"
    Sonya "Podemos conversar mais depois"

# game/characters_events_idles/mc_events.rpy:710
translate portugues gg_intro_701fa6da:

    # Sonya "Ты можешь лечь в зале"
    Sonya "Você pode deitar na sala"

# game/characters_events_idles/mc_events.rpy:712
translate portugues gg_intro_7adf858b:

    # Sonya "Других мест спальных у нас нету"
    Sonya "Não temos outros lugares para dormir"

# game/characters_events_idles/mc_events.rpy:714
translate portugues gg_intro_e6ef238c:

    # gg "Да хорошо"
    gg "Sim, tudo bem"

# game/characters_events_idles/mc_events.rpy:716
translate portugues gg_intro_18a3c2d6:

    # gg "Спасибо за теплый прием"
    gg "Obrigado pela recepção calorosa"

# game/characters_events_idles/mc_events.rpy:718
translate portugues gg_intro_2857877c:

    # Sonya "Я положу все необходимое на диван"
    Sonya "Vou deixar tudo o que você precisa no sofá"

# game/characters_events_idles/mc_events.rpy:720
translate portugues gg_intro_f96b8f09:

    # gg_chat "Похоже, пока я могу здесь остаться"
    gg_chat "Parece que posso ficar aqui por enquanto"

# game/characters_events_idles/mc_events.rpy:724
translate portugues gg_intro_19e97f44:

    # gg_chat "Я так устал за этот день"
    gg_chat "Estou tão cansado deste dia"

# game/characters_events_idles/mc_events.rpy:725
translate portugues gg_intro_6f0f1d5a:

    # gg_chat "Пора отдыхать"
    gg_chat "Hora de descansar"

# game/characters_events_idles/mc_events.rpy:737
translate portugues gg_first_morning_8051fd9f:

    # gg_chat "Утро"
    gg_chat "Manhã"

# game/characters_events_idles/mc_events.rpy:739
translate portugues gg_first_morning_c535b2eb:

    # gg_chat "Давно я так не просыпался"
    gg_chat "Faz tempo que não acordo assim"

# game/characters_events_idles/mc_events.rpy:741
translate portugues gg_first_morning_654f0c17:

    # gg_chat "Никакой работы"
    gg_chat "Sem trabalho"

# game/characters_events_idles/mc_events.rpy:743
translate portugues gg_first_morning_81883fea:

    # gg_chat "Никакого давления"
    gg_chat "Sem pressão"

# game/characters_events_idles/mc_events.rpy:745
translate portugues gg_first_morning_90c39e25:

    # gg_chat "Природа"
    gg_chat "Natureza"

# game/characters_events_idles/mc_events.rpy:747
translate portugues gg_first_morning_dbabb2ca:

    # gg_chat "Здесь я свободен"
    gg_chat "Aqui eu sou livre"

# game/characters_events_idles/mc_events.rpy:749
translate portugues gg_first_morning_663fb966:

    # gg_chat "В городе я жил как белка в колесе"
    gg_chat "Na cidade, eu vivia como um hamster na roda"

# game/characters_events_idles/mc_events.rpy:751
translate portugues gg_first_morning_bb031547:

    # gg_chat "Не жизнь, а выживание"
    gg_chat "Não era vida, era sobrevivência"

# game/characters_events_idles/mc_events.rpy:753
translate portugues gg_first_morning_49963596:

    # gg_chat "Мне не хватало этого в городе"
    gg_chat "Sentia falta disso na cidade"

# game/characters_events_idles/mc_events.rpy:754
translate portugues gg_first_morning_0af076a7:

    # gg_chat "Кажется я останусь"
    gg_chat "Acho que vou ficar"

# game/characters_events_idles/mc_events.rpy:756
translate portugues gg_first_morning_82a7ff6e:

    # gg_chat "Дорогой бабушке . . ."
    gg_chat "Querida vovó . . ."

# game/characters_events_idles/mc_events.rpy:757
translate portugues gg_first_morning_4f068f55:

    # gg_chat "Спасибо похоже, я нашёл то, чего мне не хватало"
    gg_chat "Obrigado, parece que encontrei o que estava faltando"

# game/characters_events_idles/mc_events.rpy:759
translate portugues gg_first_morning_88a92574:

    # gg_chat "Моя жизнь меняется"
    gg_chat "Minha vida está mudando"

# game/characters_events_idles/mc_events.rpy:761
translate portugues gg_first_morning_d67d6049:

    # gg_chat "Посмотрим, что из этого выйдет"
    gg_chat "Vamos ver no que vai dar"

# game/characters_events_idles/mc_events.rpy:780
translate portugues gg_first_morning_kitchen_b418e893:

    # gg_chat "Можно просто сидеть"
    gg_chat "Dá só para sentar"

# game/characters_events_idles/mc_events.rpy:781
translate portugues gg_first_morning_kitchen_820306b2:

    # gg_chat "Никуда не спешить"
    gg_chat "Sem pressa para nada"

# game/characters_events_idles/mc_events.rpy:787
translate portugues gg_first_morning_kitchen_47966b2a:

    # gg_chat "Обычно меня раздражает мытье посуды. А тут даже приятно"
    gg_chat "Normalmente lavar louça me irrita. Mas aqui até que é gostoso"

# game/characters_events_idles/mc_events.rpy:789
translate portugues gg_first_morning_kitchen_2119fa08:

    # gg_chat "Нужно будет всё здесь изучить"
    gg_chat "Vou ter que explorar tudo aqui"

# game/characters_events_idles/mc_events.rpy:791
translate portugues gg_first_morning_kitchen_52906127:

    # gg_chat "Хочу понять, как здесь живут"
    gg_chat "Quero entender como a vida funciona aqui"

# game/characters_events_idles/mc_events.rpy:792
translate portugues gg_first_morning_kitchen_1b6b16db:

    # gg_chat "Как всё устроено"
    gg_chat "Como tudo é organizado"

# game/characters_events_idles/mc_events.rpy:795
translate portugues gg_first_morning_kitchen_681dfe7b:

    # gg_chat "Это теперь мой новый дом"
    gg_chat "Esta agora é a minha nova casa"

# game/characters_events_idles/mc_events.rpy:810
translate portugues gg_first_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "Oi"

# game/characters_events_idles/mc_events.rpy:812
translate portugues gg_first_day_bathroom_7b463844:

    # Sonya "Прости, я не думала, что ты сейчас зайдешь"
    Sonya "Desculpa, não pensei que você fosse entrar agora"

# game/characters_events_idles/mc_events.rpy:813
translate portugues gg_first_day_bathroom_32835352:

    # Sonya "Я хотела прибраться"
    Sonya "Eu ia limpar um pouco"

# game/characters_events_idles/mc_events.rpy:817
translate portugues gg_first_day_bathroom_826d81cb:

    # Sonya "Я не мешаю тебе?"
    Sonya "Não estou atrapalhando?"

# game/characters_events_idles/mc_events.rpy:819
translate portugues gg_first_day_bathroom_c012b14a:

    # Sonya "Я сейчас закончу"
    Sonya "Termino já"

# game/characters_events_idles/mc_events.rpy:821
translate portugues gg_first_day_bathroom_1c4c4c5a:

    # gg "Нет, всё нормально"
    gg "Não, está tudo bem"

# game/characters_events_idles/mc_events.rpy:822
translate portugues gg_first_day_bathroom_bf898b26:

    # gg "Я подожду"
    gg "Eu espero"

# game/characters_events_idles/mc_events.rpy:824
translate portugues gg_first_day_bathroom_1452bdd4:

    # gg "Если тебе нужна помощь — скажи"
    gg "Se precisar de ajuda, é só falar"

# game/characters_events_idles/mc_events.rpy:826
translate portugues gg_first_day_bathroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "Sério?"

# game/characters_events_idles/mc_events.rpy:828
translate portugues gg_first_day_bathroom_6e75581c:

    # Sonya "Ты не обязан, я просто"
    Sonya "Você não precisa, é que..."

# game/characters_events_idles/mc_events.rpy:830
translate portugues gg_first_day_bathroom_bad9a3a7:

    # Sonya "Ну, если тебе не сложно"
    Sonya "Bom, se não for incômodo"

# game/characters_events_idles/mc_events.rpy:832
translate portugues gg_first_day_bathroom_506ec94d:

    # Sonya "Можешь тогда разложить вещи для стирки"
    Sonya "Pode separar as roupas para lavar então"


# game/characters_events_idles/mc_events.rpy:834
translate portugues gg_first_day_bathroom_1b360134:

    # Sonya "Потом сложи что уже высохло"
    Sonya "Depois dobra o que já secou"

# game/characters_events_idles/mc_events.rpy:836
translate portugues gg_first_day_bathroom_cc2e9c27:

    # Sonya "Отнесу я сама"
    Sonya "Eu levo depois"

# game/characters_events_idles/mc_events.rpy:856
translate portugues gg_first_day_bathroom_fb297fd7:

    # gg_chat "Как будто мы тут давно живём"
    gg_chat "Como se a gente já morasse aqui há tempos"

# game/characters_events_idles/mc_events.rpy:858
translate portugues gg_first_day_bathroom_adfa1b84:

    # Sonya "Мне чуть чуть осталось"
    Sonya "Só falta um pouquinho"

# game/characters_events_idles/mc_events.rpy:860
translate portugues gg_first_day_bathroom_dc9b9999:

    # Sonya "Обычно в доме только я убираюсь"
    Sonya "Normalmente só eu que limpo a casa"

# game/characters_events_idles/mc_events.rpy:864
translate portugues gg_first_day_bathroom_09b9d111:

    # Sonya "А . . ."
    Sonya "Ah . . ."

# game/characters_events_idles/mc_events.rpy:865
translate portugues gg_first_day_bathroom_a741acc1:

    # Sonya "Ты наверное хочешь в душ"
    Sonya "Você provavelmente quer tomar banho"

# game/characters_events_idles/mc_events.rpy:869
translate portugues gg_first_day_bathroom_9f7316a6:

    # Sonya "Полотенца сейчас у меня в комнате"
    Sonya "As toalhas estão no meu quarto agora"

# game/characters_events_idles/mc_events.rpy:871
translate portugues gg_first_day_bathroom_352fa084:

    # Sonya "Мы можем сходить туда, если хочешь"
    Sonya "Podemos ir lá, se quiser"

# game/characters_events_idles/mc_events.rpy:873
translate portugues gg_first_day_bathroom_264ee174:

    # gg "Пойдем"
    gg "Vamos"

# game/characters_events_idles/mc_events.rpy:879
translate portugues gg_first_day_bathroom_a3853f22:

    # gg_chat "Как сильно поменялись комнаты"
    gg_chat "Como os quartos mudaram bastante"

# game/characters_events_idles/mc_events.rpy:883
translate portugues gg_first_day_bathroom_1d2f5a17:

    # Sonya "Вот"
    Sonya "Aqui"

# game/characters_events_idles/mc_events.rpy:885
translate portugues gg_first_day_bathroom_33def544:

    # Sonya "Если что, там ещё есть"
    Sonya "Se precisar, tem mais"

# game/characters_events_idles/mc_events.rpy:887
translate portugues gg_first_day_bathroom_5c20aef6:

    # Sonya "Э ну приятного купания"
    Sonya "Eh, bom banho então"

# game/characters_events_idles/mc_events.rpy:889
translate portugues gg_first_day_bathroom_3eec94f5:

    # gg "А да спасибо"
    gg "Ah, sim, obrigado"

# game/characters_events_idles/mc_events.rpy:892
translate portugues gg_first_day_bathroom_b774dd45:

    # gg_chat "Оказывается, для уюта нужно совсем немного"
    gg_chat "Afinal, não precisa de muito para ter aconchego"

# game/characters_events_idles/mc_events.rpy:905
translate portugues gg_first_morning_mayaroom_ff197092:

    # Maya "Барси!"
    Maya "Barsi!"

# game/characters_events_idles/mc_events.rpy:907
translate portugues gg_first_morning_mayaroom_de472ed4:

    # Maya "Барсик!"
    Maya "Barsik!"

# game/characters_events_idles/mc_events.rpy:910
translate portugues gg_first_morning_mayaroom_a4a7667e:

    # gg_chat "Что-то случилось?"
    gg_chat "Aconteceu alguma coisa?"

# game/characters_events_idles/mc_events.rpy:914
translate portugues gg_first_morning_mayaroom_6f63b0d7:

    # gg_chat "Лучше ей не мешать . . ."
    gg_chat "Melhor não atrapalhar ela..."

# game/characters_events_idles/mc_events.rpy:920
translate portugues gg_first_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "Pera"

# game/characters_events_idles/mc_events.rpy:922
translate portugues gg_first_morning_mayaroom_857efa08:

    # Maya "Ты кота не видел?"
    Maya "Você viu o gato?"

# game/characters_events_idles/mc_events.rpy:924
translate portugues gg_first_morning_mayaroom_270e2f8c:

    # gg "Нет"
    gg "Não"

# game/characters_events_idles/mc_events.rpy:926
translate portugues gg_first_morning_mayaroom_def6171d:

    # gg "Но могу помочь"
    gg "Mas posso ajudar"

# game/characters_events_idles/mc_events.rpy:928
translate portugues gg_first_morning_mayaroom_359a75af:

    # Maya "Твоя помощь мне не нужна"
    Maya "Não preciso da sua ajuda"

# game/characters_events_idles/mc_events.rpy:930
translate portugues gg_first_morning_mayaroom_785a8355:

    # Maya "Хотя если будешь молчать — помогай"
    Maya "Mas se ficar quieto, pode ajudar"

# game/characters_events_idles/mc_events.rpy:932
translate portugues gg_first_morning_mayaroom_929a1d4f:

    # gg_chat "Это так на помощь соглашаются"
    gg_chat "É assim que se aceita ajuda, né"

# game/characters_events_idles/mc_events.rpy:937
translate portugues gg_first_morning_mayaroom_bb6b3842:

    # Maya "Ты где барсииик"
    Maya "Cadê você, Barsiiiiik"

# game/characters_events_idles/mc_events.rpy:946
translate portugues gg_first_morning_mayaroom_32a24542:

    # gg_chat "Нашёлся"
    gg_chat "Achou"

# game/characters_events_idles/mc_events.rpy:950
translate portugues gg_first_morning_mayaroom_954eaf61:

    # gg_chat "Главное не разбудить"
    gg_chat "O importante é não acordar"

# game/characters_events_idles/mc_events.rpy:952
translate portugues gg_first_morning_mayaroom_79aa0dff:

    # Maya "Всё хорошо"
    Maya "Tudo bem"

# game/characters_events_idles/mc_events.rpy:954
translate portugues gg_first_morning_mayaroom_831f5c17:

    # Maya "Я здесь барсик"
    Maya "Estou aqui, Barsik"

# game/characters_events_idles/mc_events.rpy:958
translate portugues gg_first_morning_mayaroom_f0949f54:

    # Maya "Ты меня напугал"
    Maya "Você me assustou"

# game/characters_events_idles/mc_events.rpy:959
translate portugues gg_first_morning_mayaroom_a8d4beb2:

    # Maya "Глупый"
    Maya "Bobinho"

# game/characters_events_idles/mc_events.rpy:962
translate portugues gg_first_morning_mayaroom_ddc18c67:

    # gg_chat "Она не совсем такая, какой кажется"
    gg_chat "Ela não é bem do jeito que parece"

# game/characters_events_idles/mc_events.rpy:974
translate portugues kate_day_kitchen_60e92ce9:

    # Kate "Так, где у вас тут кофе прячут?"
    Kate "Então, onde vocês escondem o café aqui?"

# game/characters_events_idles/mc_events.rpy:975
translate portugues kate_day_kitchen_077e1944:

    # gg "Ты кто вообще?"
    gg "Quem é você, afinal?"

# game/characters_events_idles/mc_events.rpy:977
translate portugues kate_day_kitchen_67f355f0:

    # Kate "О Привет"
    Kate "Ah, Oi"

# game/characters_events_idles/mc_events.rpy:980
translate portugues kate_day_kitchen_d81632e3:

    # Kate "Я Кейт"
    Kate "Sou a Kate"

# game/characters_events_idles/mc_events.rpy:982
translate portugues kate_day_kitchen_1e97df81:

    # Kate "Не пугайся, я не вор"
    Kate "Não se assuste, não sou ladra"

# game/characters_events_idles/mc_events.rpy:983
translate portugues kate_day_kitchen_b0950cd9:

    # Kate "Просто кофе мне жизненно необходим"
    Kate "É que café é vital para mim"

# game/characters_events_idles/mc_events.rpy:985
translate portugues kate_day_kitchen_e063e635:

    # gg "Меня [povname] зовут"
    gg "Meu nome é [povname]"

# game/characters_events_idles/mc_events.rpy:986
translate portugues kate_day_kitchen_f0d355f9:

    # gg "Растворимый прям тут"
    gg "O solúvel tá bem aqui"

# game/characters_events_idles/mc_events.rpy:988
translate portugues kate_day_kitchen_f2fdab56:

    # Kate "О, спаситель!"
    Kate "Oh, salvador!"

# game/characters_events_idles/mc_events.rpy:990
translate portugues kate_day_kitchen_fe62b24d:

    # Kate "Значит, ты и есть тот самый парень, который тут появился недавно?"
    Kate "Então você é o cara que apareceu aqui recentemente?"

# game/characters_events_idles/mc_events.rpy:992
translate portugues kate_day_kitchen_ce5edae1:

    # gg "Судя по слухам — да, я"
    gg "Pelos rumores, sim, sou eu"

# game/characters_events_idles/mc_events.rpy:994
translate portugues kate_day_kitchen_0d1fc413:

    # Kate "Мая рассказывала"
    Kate "A Maya contou"

# game/characters_events_idles/mc_events.rpy:996
translate portugues kate_day_kitchen_7c8bce00:

    # Kate "Живёт с Соней давно, а потом появился ты"
    Kate "Mora com a Sônia há tempos, e aí você apareceu"

# game/characters_events_idles/mc_events.rpy:997
translate portugues kate_day_kitchen_34985df3:

    # Kate "Интересная компания"
    Kate "Que grupo interessante"

# game/characters_events_idles/mc_events.rpy:999
translate portugues kate_day_kitchen_2e63aac8:

    # gg "“Интересная” — мягко сказано"
    gg "'Interessante' é pouco"

# game/characters_events_idles/mc_events.rpy:1001
translate portugues kate_day_kitchen_cbdc207c:

    # Kate "Серьёзно? Это растворимый?"
    Kate "Sério? Isso é solúvel?"

# game/characters_events_idles/mc_events.rpy:1003
translate portugues kate_day_kitchen_8937f276:

    # gg "Ага"
    gg "Aham"

# game/characters_events_idles/mc_events.rpy:1005
translate portugues kate_day_kitchen_5746fae5:

    # Kate "А ведь вкусно"
    Kate "Mas até que é gostoso"

# game/characters_events_idles/mc_events.rpy:1006
translate portugues kate_day_kitchen_796538ef:

    # Kate "Обычно от растворимого хочется заплакать"
    Kate "Normalmente café solúvel dá vontade de chorar"

# game/characters_events_idles/mc_events.rpy:1008
translate portugues kate_day_kitchen_3e92b413:

    # gg "Значит, я талантливый бариста"
    gg "Então sou um barista talentoso"

# game/characters_events_idles/mc_events.rpy:1009
translate portugues kate_day_kitchen_961ab98b:

    # Kate "Или тебе повезло"
    Kate "Ou você teve sorte"

# game/characters_events_idles/mc_events.rpy:1011
translate portugues kate_day_kitchen_394c86a9:

    # Kate "Ну что, рассказывай, кто ты такой"
    Kate "Então, conta, quem é você"

# game/characters_events_idles/mc_events.rpy:1013
translate portugues kate_day_kitchen_517a6831:

    # gg "Обычно начинают с “как дела?”"
    gg "Normalmente começa com 'como vai?'"

# game/characters_events_idles/mc_events.rpy:1015
translate portugues kate_day_kitchen_bb3d7bf1:

    # Kate "Это скучно"
    Kate "Isso é chato"

# game/characters_events_idles/mc_events.rpy:1017
translate portugues kate_day_kitchen_01155acc:

    # Kate "Я сразу к сути. Ты кто: сосед, ухажёр, постоялец или просто [povname]"
    Kate "Vou direto ao ponto. Você é: vizinho, pretendente, hóspede ou só [povname]"

# game/characters_events_idles/mc_events.rpy:1019
translate portugues kate_day_kitchen_4333516e:

    # gg "Пусть будет просто [povname]"
    gg "Que seja só [povname]"

# game/characters_events_idles/mc_events.rpy:1021
translate portugues kate_day_kitchen_95199003:

    # Kate "Значит, загадочный. Ладно, оставим интригу"
    Kate "Então, misterioso. Tudo bem, deixa a intriga"


# game/characters_events_idles/mc_events.rpy:1024
translate portugues kate_day_kitchen_eb2b6424:

    # Kate "Тут уютно"
    Kate "É aconchegante aqui"

# game/characters_events_idles/mc_events.rpy:1025
translate portugues kate_day_kitchen_ad0e7b9c:

    # Kate "Не думала, что Мая вообще когда-то научится жить без хаоса"
    Kate "Nunca pensei que a Maya um dia aprenderia a viver sem caos"

# game/characters_events_idles/mc_events.rpy:1029
translate portugues kate_day_kitchen_1e4f23c6:

    # Maya "Кейт! Ты тут"
    Maya "Kate! Você está aqui"

# game/characters_events_idles/mc_events.rpy:1030
translate portugues kate_day_kitchen_ecdba904:

    # Maya "Я же сказала подожди меня!"
    Maya "Eu disse para me esperar!"

# game/characters_events_idles/mc_events.rpy:1032
translate portugues kate_day_kitchen_b6371751:

    # Maya "Ага, ты уже познакомилась с этим балбесом"
    Maya "Ah, você já conheceu esse bobo"

# game/characters_events_idles/mc_events.rpy:1034
translate portugues kate_day_kitchen_9c22616a:

    # Kate "Да! И кофе у него отличный, между прочим"
    Kate "Sim! E o café dele é ótimo, por sinal"

# game/characters_events_idles/mc_events.rpy:1036
translate portugues kate_day_kitchen_08bc7129:

    # Maya "Хвалить не вздумай, зазнается. Нам пора"
    Maya "Nem pense em elogiar, ele vai ficar convencido. Precisamos ir"

# game/characters_events_idles/mc_events.rpy:1038
translate portugues kate_day_kitchen_8ab29297:

    # Kate "Спасибо за кофе, бариста"
    Kate "Obrigada pelo café, barista"

# game/characters_events_idles/mc_events.rpy:1039
translate portugues kate_day_kitchen_11705c38:

    # Kate "Ладно. Ещё увидимся"
    Kate "Tudo bem. Até mais"

translate portugues strings:

    # game/characters_events_idles/mc_events.rpy:361
    old "Послать нахуй"
    new "Mandar à merda"

    # game/characters_events_idles/mc_events.rpy:363
    old "Молча уйти"
    new "Sair em silêncio"

# TODO: Translation updated at 2026-01-26 03:23

# game/characters_events_idles/mc_events.rpy:295
translate portugues gg_intro_4402cfd9:

    # gg_chat "Я отвечу попозже бабушка"
    gg_chat "Vou responder mais tarde, vovó"

# game/characters_events_idles/mc_events.rpy:668
translate portugues gg_intro_0997da9e:

    # Maya "Это мы с Соней решим!"
    Maya "Isso a Sônia e eu vamos decidir!"

# game/characters_events_idles/mc_events.rpy:670
translate portugues gg_intro_6619e154:

    # Maya "{sc}{size=*1.5}СОНЯ{/sc}" with hpunch
    Maya "{sc}SONIA{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:805
translate portugues gg_intro_fadd240e:

    # "Ночью можно отдохнуть — нажми на кровать, чтобы начать новый день"
    "À noite você pode descansar — clique na cama para começar um novo dia"

# game/characters_events_idles/mc_events.rpy:895
translate portugues gg_first_day_bathroom_6c8604ba:

    # Sonya "Я не думала, что ты сейчас зайдешь"
    Sonya "Não pensei que você fosse entrar agora"

# game/characters_events_idles/mc_events.rpy:896
translate portugues gg_first_day_bathroom_15c3e23b:

    # Sonya "Хотела прибраться"
    Sonya "Queria dar uma limpada"

# game/characters_events_idles/mc_events.rpy:900
translate portugues gg_first_day_bathroom_94ef9943:

    # Sonya "Ты хотел в душ?"
    Sonya "Você queria tomar banho?"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/mc_events.rpy:287
translate portugues gg_intro_21dc756d:

    # gg_chat "Чёрт, я опаздываю"
    gg_chat "Droga, tô atrasado"

# game/characters_events_idles/mc_events.rpy:295
translate portugues gg_intro_01ac9e1d:

    # gg_chat "Я отвечу попозже, бабушка"
    gg_chat "Respondo mais tarde, vovó"

# game/characters_events_idles/mc_events.rpy:325
translate portugues gg_intro_d5122bca:

    # Assistant "И напомню: если продолжишь, {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "E só pra lembrar: se continuar assim,{w} a conversa sobre reduzir o salário é só questão de tempo"

# game/characters_events_idles/mc_events.rpy:361
translate portugues gg_intro_4e8253d3:

    # gg_chat "Сколько ни работай, этому нет конца"
    gg_chat "Não importa o quanto eu trabalhe, isso nunca acaba"

# game/characters_events_idles/mc_events.rpy:393
translate portugues gg_intro_eb3e3aa2:

    # gg_chat "Да пошло оно все"
    gg_chat "Que se dane tudo isso"

# game/characters_events_idles/mc_events.rpy:409
translate portugues gg_intro_187f7fc4:

    # Director "Ты вообще что делаешь"
    Director "O que você pensa que está fazendo?"

# game/characters_events_idles/mc_events.rpy:500
translate portugues gg_intro_bb6264b0:

    # gg_chat "Все, кого я вижу, со мной здороваются"
    gg_chat "Todo mundo que eu vejo me cumprimenta"

# game/characters_events_idles/mc_events.rpy:520
translate portugues gg_intro_2c4c4cb8:

    # UnknownGirl "Если что-то нужно будет, спрашивай помощь у любого"
    UnknownGirl "Se precisar de alguma coisa, pode pedir ajuda a qualquer um"

# game/characters_events_idles/mc_events.rpy:524
translate portugues gg_intro_f654fdee:

    # gg "Хорошо и Вам отличного дня"
    gg "Tudo bem, e tenha um ótimo dia"

# game/characters_events_idles/mc_events.rpy:527
translate portugues gg_intro_87051a07:

    # gg_chat "Бабушка, похоже, говорила правду о людях здесь"
    gg_chat "Vovó, parece que você falava a verdade sobre as pessoas daqui"

# game/characters_events_idles/mc_events.rpy:546
translate portugues gg_intro_95240a3b:

    # gg_chat "Да, дом поменялся"
    gg_chat "É, a casa mudou"

# game/characters_events_idles/mc_events.rpy:556
translate portugues gg_intro_e94b0047:

    # gg_chat "Здесь кто-то есть?"
    gg_chat "Tem alguém aí?"

# game/characters_events_idles/mc_events.rpy:596
translate portugues gg_intro_eee07a35:

    # gg "Стой, подожди"
    gg "Ei, espera"

# game/characters_events_idles/mc_events.rpy:604
translate portugues gg_intro_ca7cead7:

    # Maya "Что-то я такого внука никогда здесь не видела"
    Maya "Nunca vi um neto assim por aqui"

# game/characters_events_idles/mc_events.rpy:650
translate portugues gg_intro_f08474d4:

    # Maya "Мои цветочки любимые. Они остались"
    Maya "Minhas florzinhas queridas. Elas ficaram"

# game/characters_events_idles/mc_events.rpy:659
translate portugues gg_intro_90f291ff:

    # Maya "Боже, ладно"
    Maya "Meu Deus, tá bom"

# game/characters_events_idles/mc_events.rpy:660
translate portugues gg_intro_7b0b2a04:

    # Maya "Похоже на правду"
    Maya "Parece verdade"

# game/characters_events_idles/mc_events.rpy:676
translate portugues gg_intro_1b04d04b:

    # Maya "Слушай, если ты хоть что-то сделаешь"
    Maya "Olha, se você fizer pelo menos alguma coisa"

# game/characters_events_idles/mc_events.rpy:734
translate portugues gg_intro_5834166b:

    # Sonya "Нет-нет, всё нормально"
    Sonya "Não, não, tá tudo bem"

# game/characters_events_idles/mc_events.rpy:740
translate portugues gg_intro_05ceb2ee:

    # Sonya "Я прочла письмо Линды"
    Sonya "Eu li a carta da Linda"

# game/characters_events_idles/mc_events.rpy:744
translate portugues gg_intro_c73d3bb7:

    # Sonya "Она всегда нас так называла"
    Sonya "Ela sempre nos chamava assim"

# game/characters_events_idles/mc_events.rpy:760
translate portugues gg_intro_d2363caa:

    # Sonya "Это место для нас стало родным"
    Sonya "Esse lugar se tornou nosso lar"

# game/characters_events_idles/mc_events.rpy:764
translate portugues gg_intro_79c61e5f:

    # Sonya "Говорила, что ты хороший, по крайней мере в детстве"
    Sonya "Ela dizia que você era bom, pelo menos quando criança"

# game/characters_events_idles/mc_events.rpy:774
translate portugues gg_intro_7f8fcf55:

    # Sonya "Ну, какой у тебя дальше план?"
    Sonya "Então, qual é o seu plano agora?"

# game/characters_events_idles/mc_events.rpy:787
translate portugues gg_intro_d7903980:

    # Sonya "Если захочешь мы еще поговорим"
    Sonya "Se quiser, a gente conversa mais depois"

# game/characters_events_idles/mc_events.rpy:789
translate portugues gg_intro_7d278239:

    # Sonya "А пока ты можешь лечь в зале"
    Sonya "Por enquanto, você pode dormir na sala"

# game/characters_events_idles/mc_events.rpy:793
translate portugues gg_intro_41b7f3b0:

    # gg "Да, хорошо"
    gg "Sim, tudo bem"

# game/characters_events_idles/mc_events.rpy:835
translate portugues gg_first_morning_5b301338:

    # gg_chat "Эх, как же мне не хватало свободы"
    gg_chat "Ah, como eu sentia falta de liberdade"

# game/characters_events_idles/mc_events.rpy:836
translate portugues gg_first_morning_146ca63e:

    # gg_chat "Кажется, я останусь"
    gg_chat "Acho que vou ficar"

# game/characters_events_idles/mc_events.rpy:839
translate portugues gg_first_morning_9cc6e0e8:

    # gg_chat "Спасибо, похоже, я нашёл то, чего мне не хватало"
    gg_chat "Obrigado, acho que encontrei o que me faltava"

# game/characters_events_idles/mc_events.rpy:917
translate portugues gg_first_day_bathroom_c3b33eb8:

    # Sonya "Потом сложи, что уже высохло"
    Sonya "Depois dobra o que já secou"

# game/characters_events_idles/mc_events.rpy:970
translate portugues gg_first_day_bathroom_887d1e72:

    # Sonya "Ээ... нуу приятного купания"
    Sonya "É... bom banho"

# game/characters_events_idles/mc_events.rpy:972
translate portugues gg_first_day_bathroom_997383a9:

    # gg "А, да, спасибо"
    gg "Ah, sim, obrigado"

# game/characters_events_idles/mc_events.rpy:1018
translate portugues gg_first_morning_mayaroom_123ee93a:

    # Maya "Хотя, если будешь молчать — помогай"
    Maya "Mas, se for ficar quieto, ajuda"