﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/maya_events.rpy:24
translate portugues maya_scene1_evening_myroom_ef5d982a:

    # Maya "Да ты издеваешься"
    Maya "Você tá de sacanagem"

# game/characters_events_idles/maya_events.rpy:37
translate portugues maya_scene1_evening_myroom_905d33c0:

    # Maya "Где они блин"
    Maya "Cadê eles, droga"

# game/characters_events_idles/maya_events.rpy:50
translate portugues maya_scene1_evening_myroom_bd666787:

    # Maya "Тьфу"
    Maya "Ugh"

# game/characters_events_idles/maya_events.rpy:56
translate portugues maya_scene1_evening_myroom_481be515:

    # Maya "Чё смотришь?"
    Maya "Tá olhando o quê?"

# game/characters_events_idles/maya_events.rpy:57
translate portugues maya_scene1_evening_myroom_2ca818a6:

    # gg "Проверь плюс и минус"
    gg "Verifica o positivo e o negativo"

# game/characters_events_idles/maya_events.rpy:58
translate portugues maya_scene1_evening_myroom_4bbab9f1:

    # Maya "Проверяла"
    Maya "Já verifiquei"

# game/characters_events_idles/maya_events.rpy:94
translate portugues maya_scene2_day_mayaroom_5bb53a51:

    # Maya "Кто там?"
    Maya "Quem é?"

# game/characters_events_idles/maya_events.rpy:96
translate portugues maya_scene2_day_mayaroom_14a18d19:

    # gg "Это я. Можно зайти по делу?"
    gg "Sou eu. Posso entrar? É importante."

# game/characters_events_idles/maya_events.rpy:97
translate portugues maya_scene2_day_mayaroom_1c4734b1:

    # Maya "Входи"
    Maya "Entra"

# game/characters_events_idles/maya_events.rpy:105
translate portugues maya_scene2_day_mayaroom_ab7fedad:

    # gg "Музыку слушаешь?"
    gg "Tá ouvindo música?"

# game/characters_events_idles/maya_events.rpy:107
translate portugues maya_scene2_day_mayaroom_3884c669:

    # Maya "Нет, для соседей включила"
    Maya "Não, liguei pros vizinhos"

# game/characters_events_idles/maya_events.rpy:111
translate portugues maya_scene2_day_mayaroom_837eef0f:

    # gg "Я решил, что останусь тут"
    gg "Eu decidi que vou ficar aqui"

# game/characters_events_idles/maya_events.rpy:113
translate portugues maya_scene2_day_mayaroom_95020588:

    # gg "Буду жить здесь"
    gg "Vou morar aqui"

# game/characters_events_idles/maya_events.rpy:115
translate portugues maya_scene2_day_mayaroom_bca52f7e:

    # Maya "Ну"
    Maya "Bem..."

# game/characters_events_idles/maya_events.rpy:117
translate portugues maya_scene2_day_mayaroom_705e10f4:

    # Maya "Соболезную"
    Maya "Meus pêsames"

# game/characters_events_idles/maya_events.rpy:125
translate portugues maya_scene2_day_mayaroom_27c60573:

    # Maya "Эй"
    Maya "Ei"

# game/characters_events_idles/maya_events.rpy:127
translate portugues maya_scene2_day_mayaroom_40785e40:

    # Maya "Дальше не надо"
    Maya "Não precisa continuar"

# game/characters_events_idles/maya_events.rpy:129
translate portugues maya_scene2_day_mayaroom_5f49e73a:

    # gg "Я просто хотел"
    gg "Eu só queria"

# game/characters_events_idles/maya_events.rpy:131
translate portugues maya_scene2_day_mayaroom_16e0a365:

    # Maya "Я всё услышала"
    Maya "Eu ouvi tudo"

# game/characters_events_idles/maya_events.rpy:133
translate portugues maya_scene2_day_mayaroom_c48134de:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "Eu não tô nem aí se você mora aqui"

# game/characters_events_idles/maya_events.rpy:135
translate portugues maya_scene2_day_mayaroom_df1954ea:

    # Maya "Честно"
    Maya "Sério"

# game/characters_events_idles/maya_events.rpy:139
translate portugues maya_scene2_day_mayaroom_df3a4321:

    # Maya "Но давай без этого"
    Maya "Mas vamos deixar isso de lado"

# game/characters_events_idles/maya_events.rpy:141
translate portugues maya_scene2_day_mayaroom_e6c85abf:

    # gg "Без чего?"
    gg "Deixar o quê de lado?"

# game/characters_events_idles/maya_events.rpy:143
translate portugues maya_scene2_day_mayaroom_d4ddd213:

    # Maya "Без контроля"
    Maya "Sem controle"

# game/characters_events_idles/maya_events.rpy:145
translate portugues maya_scene2_day_mayaroom_bc54c15e:

    # Maya "Без «я помогу»"
    Maya "Sem o 'eu vou ajudar'"

# game/characters_events_idles/maya_events.rpy:147
translate portugues maya_scene2_day_mayaroom_7a220c2f:

    # gg "Я не про контроль"
    gg "Não é sobre controle"

# game/characters_events_idles/maya_events.rpy:148
translate portugues maya_scene2_day_mayaroom_dabe88df:

    # gg "Если по дому что-то"
    gg "Se tiver algo em casa..."

# game/characters_events_idles/maya_events.rpy:152
translate portugues maya_scene2_day_mayaroom_723b85d3:

    # Maya "Мне не нужна опека"
    Maya "Eu não preciso de proteção"

# game/characters_events_idles/maya_events.rpy:154
translate portugues maya_scene2_day_mayaroom_cad2c7d3:

    # gg "Я не это имел в виду"
    gg "Não foi isso que eu quis dizer"

# game/characters_events_idles/maya_events.rpy:156
translate portugues maya_scene2_day_mayaroom_e9decfdb:

    # Maya "А звучит именно так"
    Maya "Mas soa exatamente assim"

# game/characters_events_idles/maya_events.rpy:158
translate portugues maya_scene2_day_mayaroom_c48134de_1:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "Eu não tô nem aí se você mora aqui"

# game/characters_events_idles/maya_events.rpy:160
translate portugues maya_scene2_day_mayaroom_3e5d6dd4:

    # Maya "Просто"
    Maya "Só que..."

# game/characters_events_idles/maya_events.rpy:162
translate portugues maya_scene2_day_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "Não se intrometa"

# game/characters_events_idles/maya_events.rpy:164
translate portugues maya_scene2_day_mayaroom_9727ea24:

    # Maya "В личное"
    Maya "Na minha vida pessoal"

# game/characters_events_idles/maya_events.rpy:166
translate portugues maya_scene2_day_mayaroom_44696bee:

    # gg "Я понял"
    gg "Entendi"

# game/characters_events_idles/maya_events.rpy:168
translate portugues maya_scene2_day_mayaroom_97fa7b2b:

    # Maya "И дверь закрывай"
    Maya "E fecha a porta"

# game/characters_events_idles/maya_events.rpy:170
translate portugues maya_scene2_day_mayaroom_367b11d8:

    # Maya "Я не фанат"
    Maya "Eu não sou fã"

# game/characters_events_idles/maya_events.rpy:171
translate portugues maya_scene2_day_mayaroom_5e882c77:

    # Maya "Открытых пространств"
    Maya "De espaços abertos"

# game/characters_events_idles/maya_events.rpy:198
translate portugues maya_scene3_evening_kitchen_9a8b0be2:

    # gg "Привет"
    gg "Oi"

# game/characters_events_idles/maya_events.rpy:211
translate portugues maya_scene3_evening_kitchen_a356674e:

    # gg "Тебе еще кофе принести?"
    gg "Quer que eu traga mais café?"

# game/characters_events_idles/maya_events.rpy:213
translate portugues maya_scene3_evening_kitchen_9a5dd35b:

    # Maya "Нет"
    Maya "Não"

# game/characters_events_idles/maya_events.rpy:225
translate portugues maya_scene3_evening_kitchen_00c41c60:

    # Maya "Не . . ."
    Maya "Não..."

# game/characters_events_idles/maya_events.rpy:227
translate portugues maya_scene3_evening_kitchen_059eb6da:

    # gg "Что?"
    gg "O quê?"

# game/characters_events_idles/maya_events.rpy:229
translate portugues maya_scene3_evening_kitchen_5c02f51f:

    # Maya "Ты вообще"
    Maya "Você..."

# game/characters_events_idles/maya_events.rpy:231
translate portugues maya_scene3_evening_kitchen_c954c369:

    # Maya "Ты зачем так близко?"
    Maya "Por que você tá tão perto?"

# game/characters_events_idles/maya_events.rpy:233
translate portugues maya_scene3_evening_kitchen_7de3a2ef:

    # gg "Я просто"
    gg "Eu só..."

# game/characters_events_idles/maya_events.rpy:235
translate portugues maya_scene3_evening_kitchen_25f0ffea:

    # Maya "Я сказала, не надо"
    Maya "Eu disse, não precisa"

# game/characters_events_idles/maya_events.rpy:237
translate portugues maya_scene3_evening_kitchen_91d73b20:

    # Maya "И не звала"
    Maya "E não te chamei"

# game/characters_events_idles/maya_events.rpy:241
translate portugues maya_scene3_evening_kitchen_e10a0eab:

    # Maya "Мне нужно было просто кофе"
    Maya "Eu só queria café"

# game/characters_events_idles/maya_events.rpy:243
translate portugues maya_scene3_evening_kitchen_a41fbef3:

    # gg "Подожди"
    gg "Espera"

# game/characters_events_idles/maya_events.rpy:245
translate portugues maya_scene3_evening_kitchen_c8225194:

    # Maya "Не сейчас"
    Maya "Agora não"

# game/characters_events_idles/maya_events.rpy:252
translate portugues maya_scene3_evening_kitchen_0d9a221f:

    # gg_chat "Как бы мне с ней поговорить"
    gg_chat "Como será que eu falo com ela"

# game/characters_events_idles/maya_events.rpy:263
translate portugues maya_scene4_morning_mayaroom_d3734f64:

    # Maya "Да что ж"
    Maya "Mas que diabos..."

# game/characters_events_idles/maya_events.rpy:265
translate portugues maya_scene4_morning_mayaroom_fa8ea266:

    # Maya "Ну давай же"
    Maya "Vamos lá"

# game/characters_events_idles/maya_events.rpy:271
translate portugues maya_scene4_morning_mayaroom_d944481b:

    # gg "Опять воюешь с техникой?"
    gg "Brigando com a tecnologia de novo?"

# game/characters_events_idles/maya_events.rpy:273
translate portugues maya_scene4_morning_mayaroom_b6f44dea:

    # Maya "Все работало час назад"
    Maya "Tudo tava funcionando uma hora atrás"

# game/characters_events_idles/maya_events.rpy:275
translate portugues maya_scene4_morning_mayaroom_743f87c9:

    # gg "На вид, пауза — у меня была похожая проблема"
    gg "Parece que tá pausado. Já tive um problema parecido."

# game/characters_events_idles/maya_events.rpy:277
translate portugues maya_scene4_morning_mayaroom_5b9f31c5:

    # Maya "Конечно. У нашего местного игромана, разумеется, был подобный опыт"
    Maya "Claro. O nosso viciado em jogos local, com certeza, teve uma experiência parecida."

# game/characters_events_idles/maya_events.rpy:279
translate portugues maya_scene4_morning_mayaroom_d67e684e:

    # gg "Это решается проще, чем кажется"
    gg "É mais simples de resolver do que parece"

# game/characters_events_idles/maya_events.rpy:281
translate portugues maya_scene4_morning_mayaroom_6ac6687a:

    # Maya "Я разберусь"
    Maya "Eu resolvo"

# game/characters_events_idles/maya_events.rpy:285
translate portugues maya_scene4_morning_mayaroom_ef21c62b:

    # Maya "Ладно поскольку ты уже встал тут в позу спасителя"
    Maya "Tá bom, já que você já tá aí na pose de salvador"

# game/characters_events_idles/maya_events.rpy:287
translate portugues maya_scene4_morning_mayaroom_e4eef199:

    # Maya "Смотри"
    Maya "Olha só"

# game/characters_events_idles/maya_events.rpy:289
translate portugues maya_scene4_morning_mayaroom_b05b1e64:

    # Maya "Но если сломаешь новый купишь"
    Maya "Mas se quebrar, você compra um novo"

# game/characters_events_idles/maya_events.rpy:291
translate portugues maya_scene4_morning_mayaroom_2406a76f:

    # gg_chat "Так посмотрим"
    gg_chat "Vamos ver então"

# game/characters_events_idles/maya_events.rpy:293
translate portugues maya_scene4_morning_mayaroom_3eccec99:

    # Maya "Только давай без «я же говорил»"
    Maya "Só sem o 'eu avisei', tá?"

# game/characters_events_idles/maya_events.rpy:295
translate portugues maya_scene4_morning_mayaroom_edca7a30:

    # gg "Хорошо Не собирался"
    gg "Tá bom. Nem ia falar."

# game/characters_events_idles/maya_events.rpy:300
translate portugues maya_scene4_morning_mayaroom_33712776:

    # Maya "Главное делай вид, что понимаешь"
    Maya "O importante é fingir que entende"

# game/characters_events_idles/maya_events.rpy:306
translate portugues maya_scene4_morning_mayaroom_726d3183:

    # Maya "Ты что сделал?"
    Maya "O que você fez?"

# game/characters_events_idles/maya_events.rpy:309
translate portugues maya_scene4_morning_mayaroom_5de5e399:

    # Maya "Показывай"
    Maya "Mostra aí"

# game/characters_events_idles/maya_events.rpy:311
translate portugues maya_scene4_morning_mayaroom_4572bfad:

    # Maya "Я уже готовлюсь к разочарованию"
    Maya "Já tô me preparando pra decepção"

# game/characters_events_idles/maya_events.rpy:313
translate portugues maya_scene4_morning_mayaroom_6c571b22:

    # gg "Пока ничего критичного"
    gg "Por enquanto nada crítico"

# game/characters_events_idles/maya_events.rpy:315
translate portugues maya_scene4_morning_mayaroom_eab0c0bf:

    # Maya "Угу"
    Maya "Aham"

# game/characters_events_idles/maya_events.rpy:319
translate portugues maya_scene4_morning_mayaroom_4506bcc5:

    # Maya "Эй!"
    Maya "Ei!"

# game/characters_events_idles/maya_events.rpy:321
translate portugues maya_scene4_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "Para"

# game/characters_events_idles/maya_events.rpy:323
translate portugues maya_scene4_morning_mayaroom_5144b708:

    # gg "Что"
    gg "O quê?"

# game/characters_events_idles/maya_events.rpy:325
translate portugues maya_scene4_morning_mayaroom_cfa517d6:

    # Maya "Не надо ко мне лезть"
    Maya "Não precisa se aproximar de mim"

# game/characters_events_idles/maya_events.rpy:327
translate portugues maya_scene4_morning_mayaroom_1400ea9e:

    # gg "Ты сама"
    gg "Você que..."

# game/characters_events_idles/maya_events.rpy:329
translate portugues maya_scene4_morning_mayaroom_fd37247c:

    # Maya "Цыц"
    Maya "Shhh"

# game/characters_events_idles/maya_events.rpy:333
translate portugues maya_scene4_morning_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "Esquece"

# game/characters_events_idles/maya_events.rpy:337
translate portugues maya_scene4_morning_mayaroom_d09026b0:

    # Maya "Уже не важно"
    Maya "Já não importa mais"

# game/characters_events_idles/maya_events.rpy:339
translate portugues maya_scene4_morning_mayaroom_98444aa5:

    # Maya "Я разберусь потом"
    Maya "Eu resolvo depois"

# game/characters_events_idles/maya_events.rpy:341
translate portugues maya_scene4_morning_mayaroom_d2acc454:

    # gg "Я же просто"
    gg "Mas eu só..."

# game/characters_events_idles/maya_events.rpy:343
translate portugues maya_scene4_morning_mayaroom_e0da4bdd:

    # Maya "Я сказала потом"
    Maya "Eu disse depois"

# game/characters_events_idles/maya_events.rpy:349
translate portugues maya_scene4_morning_mayaroom_d821f777:

    # gg_chat "Нужно дать ей время"
    gg_chat "Preciso dar tempo a ela"

# game/characters_events_idles/maya_events.rpy:360
translate portugues maya_scene5_night_mayaroom_63a0d7ed:

    # gg "Я зайду"
    gg "Eu vou entrar"

# game/characters_events_idles/maya_events.rpy:364
translate portugues maya_scene5_night_mayaroom_6c5edc69:

    # gg "Слушай . . ."
    gg "Olha..."

# game/characters_events_idles/maya_events.rpy:366
translate portugues maya_scene5_night_mayaroom_68ee26d9:

    # gg "Я хочу понять"
    gg "Eu quero entender"

# game/characters_events_idles/maya_events.rpy:368
translate portugues maya_scene5_night_mayaroom_bc1e3bb5:

    # gg "Ты всё время"
    gg "Você o tempo todo"

# game/characters_events_idles/maya_events.rpy:369
translate portugues maya_scene5_night_mayaroom_024d1c74:

    # gg "Отталкиваешь"
    gg "Afasta"

# game/characters_events_idles/maya_events.rpy:370
translate portugues maya_scene5_night_mayaroom_8f03bb39:

    # gg "Резко"
    gg "De repente"

# game/characters_events_idles/maya_events.rpy:372
translate portugues maya_scene5_night_mayaroom_e92f63ca:

    # gg "Я не всегда понимаю"
    gg "Eu nem sempre entendo"

# game/characters_events_idles/maya_events.rpy:373
translate portugues maya_scene5_night_mayaroom_fc49f049:

    # gg "Где именно граница"
    gg "Onde exatamente é o limite"

# game/characters_events_idles/maya_events.rpy:375
translate portugues maya_scene5_night_mayaroom_6d2d9756:

    # Maya "Да нигде"
    Maya "Em lugar nenhum"

# game/characters_events_idles/maya_events.rpy:377
translate portugues maya_scene5_night_mayaroom_5c27dae4:

    # Maya "Хочешь границы -"
    Maya "Quer limites?"

# game/characters_events_idles/maya_events.rpy:378
translate portugues maya_scene5_night_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "Não se intrometa"

# game/characters_events_idles/maya_events.rpy:379
translate portugues maya_scene5_night_mayaroom_71b4348e:

    # gg "Я не . . .{nw=0.3}"
    gg "Eu não...{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:381
translate portugues maya_scene5_night_mayaroom_3a7c36e6:

    # Maya "Не надо"
    Maya "Não precisa"

# game/characters_events_idles/maya_events.rpy:383
translate portugues maya_scene5_night_mayaroom_11f3acdb:

    # Maya "Не делай вид"
    Maya "Não finja"

# game/characters_events_idles/maya_events.rpy:384
translate portugues maya_scene5_night_mayaroom_e9a71e8d:

    # Maya "Что ты тут ни при чём"
    Maya "Que você não tem nada a ver com isso"

# game/characters_events_idles/maya_events.rpy:386
translate portugues maya_scene5_night_mayaroom_734313d9:

    # gg "Я не пытаюсь давить"
    gg "Eu não tô tentando pressionar"

# game/characters_events_idles/maya_events.rpy:387
translate portugues maya_scene5_night_mayaroom_e3709e94:

    # gg "Я просто . . .{nw=0.3}"
    gg "Eu só...{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:389
translate portugues maya_scene5_night_mayaroom_76c878d4:

    # Maya "Ты всегда «просто»"
    Maya "Você sempre 'só'"

# game/characters_events_idles/maya_events.rpy:391
translate portugues maya_scene5_night_mayaroom_7125aff8:

    # Maya "Просто заходишь"
    Maya "Só entra"

# game/characters_events_idles/maya_events.rpy:392
translate portugues maya_scene5_night_mayaroom_8803de0c:

    # Maya "Просто начинаешь разговор"
    Maya "Só começa uma conversa"

# game/characters_events_idles/maya_events.rpy:394
translate portugues maya_scene5_night_mayaroom_30ca9380:

    # Maya "Просто помогаешь"
    Maya "Só ajuda"

# game/characters_events_idles/maya_events.rpy:396
translate portugues maya_scene5_night_mayaroom_a04f159c:

    # Maya "{sc}Это бесит{/sc}"
    Maya "{sc}Isso enche o saco{/sc}"

# game/characters_events_idles/maya_events.rpy:398
translate portugues maya_scene5_night_mayaroom_3a8f909d:

    # Maya "Всё"
    Maya "Chega"

# game/characters_events_idles/maya_events.rpy:400
translate portugues maya_scene5_night_mayaroom_4d5d0603:

    # Maya "Разговор окончен"
    Maya "Conversa encerrada"

# game/characters_events_idles/maya_events.rpy:404
translate portugues maya_scene5_night_mayaroom_37d7c2ce:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Прости"
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Desculpa"

# game/characters_events_idles/maya_events.rpy:410
translate portugues maya_scene5_night_mayaroom_2336b49e:

    # Maya "Хотя нет"
    Maya "Ou melhor, não"

# game/characters_events_idles/maya_events.rpy:412
translate portugues maya_scene5_night_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "Esquece"

# game/characters_events_idles/maya_events.rpy:426
translate portugues maya_scene5_night_mayaroom_74fb972d:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Я . . ."
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Eu..."

# game/characters_events_idles/maya_events.rpy:428
translate portugues maya_scene5_night_mayaroom_922caaa0:

    # Maya "Не это имела в виду"
    Maya "Não foi isso que eu quis dizer"

# game/characters_events_idles/maya_events.rpy:430
translate portugues maya_scene5_night_mayaroom_3a8f909d_1:

    # Maya "Всё"
    Maya "Chega"

# game/characters_events_idles/maya_events.rpy:432
translate portugues maya_scene5_night_mayaroom_00c0f420:

    # Maya "Иди"
    Maya "Vai"

# game/characters_events_idles/maya_events.rpy:435
translate portugues maya_scene5_night_mayaroom_d0668ccb:

    # Maya "Я сказала — иди{nw=2}"
    Maya "Eu disse — vai{nw=2}"

# game/characters_events_idles/maya_events.rpy:463
translate portugues maya_scene6_evening_myroom_8846d5d4:

    # Maya "Ты сидишь будто"
    Maya "Você tá sentado como se"

# game/characters_events_idles/maya_events.rpy:465
translate portugues maya_scene6_evening_myroom_c3936052:

    # Maya "Ничего не было"
    Maya "Nada tivesse acontecido"

# game/characters_events_idles/maya_events.rpy:467
translate portugues maya_scene6_evening_myroom_ba188167:

    # gg "Я не делаю вид"
    gg "Eu não tô fingindo"

# game/characters_events_idles/maya_events.rpy:469
translate portugues maya_scene6_evening_myroom_4dd50b6c:

    # Maya "Ладно, не важно"
    Maya "Tá bom, não importa"

# game/characters_events_idles/maya_events.rpy:471
translate portugues maya_scene6_evening_myroom_7eaa97d1:

    # Maya "Залипай дальше"
    Maya "Continua aí vidrado"

# game/characters_events_idles/maya_events.rpy:479
translate portugues maya_scene6_evening_myroom_3c725bc9:

    # Maya "Слушай"
    Maya "Olha"

# game/characters_events_idles/maya_events.rpy:480
translate portugues maya_scene6_evening_myroom_250ec1e3:

    # Maya "А ты сейчас сильно занят?"
    Maya "Você tá muito ocupado agora?"

# game/characters_events_idles/maya_events.rpy:482
translate portugues maya_scene6_evening_myroom_5ea33f12:

    # gg "Если честно — нет"
    gg "Pra ser sincero — não"

# game/characters_events_idles/maya_events.rpy:486
translate portugues maya_scene6_evening_myroom_f9cfb58e:

    # Maya "Я просто спросила"
    Maya "Eu só perguntei"

# game/characters_events_idles/maya_events.rpy:488
translate portugues maya_scene6_evening_myroom_70c7e32f:

    # gg "А я просто отвечаю"
    gg "E eu só tô respondendo"

# game/characters_events_idles/maya_events.rpy:489
translate portugues maya_scene6_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya "..."

# game/characters_events_idles/maya_events.rpy:491
translate portugues maya_scene6_evening_myroom_a2fcb33c:

    # Maya "Поможешь мне кое с чем"
    Maya "Me ajuda com uma coisa"

# game/characters_events_idles/maya_events.rpy:493
translate portugues maya_scene6_evening_myroom_19d648ec:

    # Maya "Это быстро"
    Maya "É rápido"

# game/characters_events_idles/maya_events.rpy:497
translate portugues maya_scene6_evening_myroom_9619af02:

    # gg "С чем?"
    gg "Com o quê?"

# game/characters_events_idles/maya_events.rpy:499
translate portugues maya_scene6_evening_myroom_0b3abc75:

    # Maya "Потом увидишь"
    Maya "Depois você vê"

# game/characters_events_idles/maya_events.rpy:510
translate portugues maya_scene6_evening_myroom_5529e2cd:

    # Maya "Только без лишней заботы"
    Maya "Só sem cuidado excessivo"

# game/characters_events_idles/maya_events.rpy:512
translate portugues maya_scene6_evening_myroom_52df9211:

    # gg "Как скажешь"
    gg "Como você quiser"

# game/characters_events_idles/maya_events.rpy:514
translate portugues maya_scene6_evening_myroom_3226a25c:

    # Maya "Посмотрим на что ты способен"
    Maya "Vamos ver do que você é capaz"

# game/characters_events_idles/maya_events.rpy:516
translate portugues maya_scene6_evening_myroom_bca52f7e:

    # Maya "Ну"
    Maya "Bem"

# game/characters_events_idles/maya_events.rpy:518
translate portugues maya_scene6_evening_myroom_1771af09:

    # Maya "Вот"
    Maya "Pronto"

# game/characters_events_idles/maya_events.rpy:520
translate portugues maya_scene6_evening_myroom_ba718844:

    # Maya "Что застыл"
    Maya "O que tá parado?"

# game/characters_events_idles/maya_events.rpy:522
translate portugues maya_scene6_evening_myroom_806872f9:

    # gg "О и давно у тебя это?"
    gg "Ah, e faz tempo que você tem isso?"

# game/characters_events_idles/maya_events.rpy:524
translate portugues maya_scene6_evening_myroom_7d6ca25f:

    # Maya "Очень"
    Maya "Muito"

# game/characters_events_idles/maya_events.rpy:525
translate portugues maya_scene6_evening_myroom_40562848:

    # Maya "Ещё когда я делала вид"
    Maya "Ainda quando eu fingia"

# game/characters_events_idles/maya_events.rpy:527
translate portugues maya_scene6_evening_myroom_0b5a891a:

    # Maya "Что у меня есть дисциплина"
    Maya "Que eu tinha disciplina"

# game/characters_events_idles/maya_events.rpy:529
translate portugues maya_scene6_evening_myroom_51392b4e:

    # gg "В смысле?"
    gg "Como assim?"

# game/characters_events_idles/maya_events.rpy:531
translate portugues maya_scene6_evening_myroom_4a4b36f7:

    # Maya "Спорт"
    Maya "Esporte"

# game/characters_events_idles/maya_events.rpy:533
translate portugues maya_scene6_evening_myroom_bec9192a:

    # Maya "Секции, график, «надо»"
    Maya "Seções, cronograma, 'preciso'"

# game/characters_events_idles/maya_events.rpy:535
translate portugues maya_scene6_evening_myroom_201efa03:

    # Maya "Потом одна удачная травма"
    Maya "Aí veio uma lesão bem-sucedida"

# game/characters_events_idles/maya_events.rpy:537
translate portugues maya_scene6_evening_myroom_c633060c:

    # Maya "И всё"
    Maya "E pronto"

# game/characters_events_idles/maya_events.rpy:539
translate portugues maya_scene6_evening_myroom_46291e24:

    # Maya "Цирк закрылся"
    Maya "O circo fechou"

# game/characters_events_idles/maya_events.rpy:541
translate portugues maya_scene6_evening_myroom_d39d8973:

    # gg "И ты бросила?"
    gg "E você largou?"

# game/characters_events_idles/maya_events.rpy:543
translate portugues maya_scene6_evening_myroom_9d7ad38f:

    # Maya "Я бы назвала это"
    Maya "Eu chamaria isso de"

# game/characters_events_idles/maya_events.rpy:545
translate portugues maya_scene6_evening_myroom_ceee3b55:

    # Maya "«Энергосберегающий режим»"
    Maya "'Modo de economia de energia'"

# game/characters_events_idles/maya_events.rpy:549
translate portugues maya_scene6_evening_myroom_9a044748:

    # gg "Теперь понятно почему ты так реагируешь"
    gg "Agora entendi por que você reage assim"

# game/characters_events_idles/maya_events.rpy:551
translate portugues maya_scene6_evening_myroom_5a3ffd6f:

    # Maya "Я просто не люблю"
    Maya "Eu só não gosto"

# game/characters_events_idles/maya_events.rpy:552
translate portugues maya_scene6_evening_myroom_2b6fd943:

    # Maya "Когда кто-то начинает"
    Maya "Quando alguém começa"

# game/characters_events_idles/maya_events.rpy:554
translate portugues maya_scene6_evening_myroom_8f57b276:

    # Maya "Объяснять мне как жить"
    Maya "A me explicar como viver"

# game/characters_events_idles/maya_events.rpy:557
translate portugues maya_scene6_evening_myroom_55d8d51b:

    # Maya "Вообщем нужно нанести крем и забинтовать"
    Maya "Enfim, precisa passar o creme e enfaixar"

# game/characters_events_idles/maya_events.rpy:559
translate portugues maya_scene6_evening_myroom_a23c1350:

    # gg "А к Соне почему не пошла?"
    gg "E por que não foi com a Sonia?"

# game/characters_events_idles/maya_events.rpy:561
translate portugues maya_scene6_evening_myroom_17ee92c5:

    # Maya "По той же причине, а еще"
    Maya "Pela mesma razão, e ainda"

# game/characters_events_idles/maya_events.rpy:562
translate portugues maya_scene6_evening_myroom_6a81a1e1:

    # Maya "Это всегда превращается"
    Maya "Isso sempre vira"

# game/characters_events_idles/maya_events.rpy:564
translate portugues maya_scene6_evening_myroom_f5a6f373:

    # Maya "В «давай я»"
    Maya "Num 'deixa que eu'"

# game/characters_events_idles/maya_events.rpy:566
translate portugues maya_scene6_evening_myroom_5d26e27b:

    # Maya "Она начинает суетиться"
    Maya "Ela começa a se agitar"

# game/characters_events_idles/maya_events.rpy:567
translate portugues maya_scene6_evening_myroom_c1824ee1:

    # Maya "Делать больше, чем надо"
    Maya "Fazer mais do que precisa"

# game/characters_events_idles/maya_events.rpy:569
translate portugues maya_scene6_evening_myroom_9ad0074f:

    # Maya "А потом я виноватой себя чувствую"
    Maya "E aí eu me sinto culpada"

# game/characters_events_idles/maya_events.rpy:571
translate portugues maya_scene6_evening_myroom_ae8589c0:

    # gg "Кажется это называется забота"
    gg "Parece que isso se chama cuidado"

# game/characters_events_idles/maya_events.rpy:573
translate portugues maya_scene6_evening_myroom_a240282b:

    # Maya "Тогда давай посмотрим на твою заботу"
    Maya "Então vamos ver seu cuidado"

# game/characters_events_idles/maya_events.rpy:575
translate portugues maya_scene6_evening_myroom_29c79ddd:

    # Maya "Надеюсь только без драм"
    Maya "Espero que sem drama"

# game/characters_events_idles/maya_events.rpy:577
translate portugues maya_scene6_evening_myroom_63c1dadc:

    # gg "Не собирался"
    gg "Nem ia"

# game/characters_events_idles/maya_events.rpy:582
translate portugues maya_scene6_evening_myroom_41f1b09f:

    # gg "Можно?"
    gg "Posso?"

# game/characters_events_idles/maya_events.rpy:590
translate portugues maya_scene6_evening_myroom_43813c59:

    # Maya "Не бойся"
    Maya "Não tenha medo"

# game/characters_events_idles/maya_events.rpy:591
translate portugues maya_scene6_evening_myroom_d139c2b0:

    # Maya "Я не из хрусталя"
    Maya "Eu não sou de cristal"

# game/characters_events_idles/maya_events.rpy:594
translate portugues maya_scene6_evening_myroom_590f3ec6:

    # Maya "Ты всегда такой спокойный?"
    Maya "Você é sempre tão tranquilo?"

# game/characters_events_idles/maya_events.rpy:595
translate portugues maya_scene6_evening_myroom_79f7b16f:

    # gg "Не всегда"
    gg "Nem sempre"

# game/characters_events_idles/maya_events.rpy:597
translate portugues maya_scene6_evening_myroom_481c4421:

    # gg "Просто сейчас{w} нет смысла психовать"
    gg "Só que agora{w} não adianta surtar"

# game/characters_events_idles/maya_events.rpy:599
translate portugues maya_scene6_evening_myroom_d38be043:

    # Maya "Понятно"
    Maya "Entendi"

# game/characters_events_idles/maya_events.rpy:600
translate portugues maya_scene6_evening_myroom_41f6003e:

    # Maya "Экономишь нервы"
    Maya "Economizando os nervos"

# game/characters_events_idles/maya_events.rpy:601
translate portugues maya_scene6_evening_myroom_9ea43bc7:

    # Maya "Умно"
    Maya "Inteligente"

# game/characters_events_idles/maya_events.rpy:603
translate portugues maya_scene6_evening_myroom_b413e8d5:

    # gg "Можно сказать и так"
    gg "Pode-se dizer que sim"

# game/characters_events_idles/maya_events.rpy:606
translate portugues maya_scene6_evening_myroom_ea2de26b:

    # Maya "Теперь бинтуй"
    Maya "Agora enfaixa"

# game/characters_events_idles/maya_events.rpy:614
translate portugues maya_scene6_evening_myroom_69d52a38:

    # Maya "Левее"
    Maya "Mais para a esquerda"

# game/characters_events_idles/maya_events.rpy:618
translate portugues maya_scene6_evening_myroom_a9d70df9:

    # Maya "Нет{w} стой"
    Maya "Não{w} para"

# game/characters_events_idles/maya_events.rpy:620
translate portugues maya_scene6_evening_myroom_4b3bbffe:

    # Maya "Вот так"
    Maya "Assim"

# game/characters_events_idles/maya_events.rpy:624
translate portugues maya_scene6_evening_myroom_9ee64c2c:

    # Maya "Ты вообще смотришь, что делаешь?"
    Maya "Você tá olhando o que tá fazendo?"

# game/characters_events_idles/maya_events.rpy:626
translate portugues maya_scene6_evening_myroom_d39f0951:

    # gg "Мая"
    gg "Maya"

# game/characters_events_idles/maya_events.rpy:628
translate portugues maya_scene6_evening_myroom_4e31a75d:

    # Maya "Нет, серьёзно"
    Maya "Não, sério"

# game/characters_events_idles/maya_events.rpy:629
translate portugues maya_scene6_evening_myroom_6049c785:

    # Maya "Ты сейчас наугад это бинтуешь"
    Maya "Você tá enfaixando isso no chute"

# game/characters_events_idles/maya_events.rpy:631
translate portugues maya_scene6_evening_myroom_7e1fd344:

    # Maya "Или делаешь вид"
    Maya "Ou tá fingindo"

# game/characters_events_idles/maya_events.rpy:632
translate portugues maya_scene6_evening_myroom_84eb66b2:

    # Maya "Что уверен"
    Maya "Que tem certeza"

# game/characters_events_idles/maya_events.rpy:637
translate portugues maya_scene6_evening_myroom_d39f0951_1:

    # gg "Мая"
    gg "Maya"

# game/characters_events_idles/maya_events.rpy:639
translate portugues maya_scene6_evening_myroom_9db87034:

    # gg "Если тебе так проще - я выйду"
    gg "Se for mais fácil pra você — eu saio"

# game/characters_events_idles/maya_events.rpy:641
translate portugues maya_scene6_evening_myroom_eb8fc374:

    # Maya "Подожди"
    Maya "Espera"

# game/characters_events_idles/maya_events.rpy:647
translate portugues maya_scene6_evening_myroom_43dc5209:

    # Maya "Я . . .{w} не это имела в виду"
    Maya "Eu...{w} não foi isso que eu quis dizer"

# game/characters_events_idles/maya_events.rpy:649
translate portugues maya_scene6_evening_myroom_e89a435e:

    # Maya "Просто . . ."
    Maya "É só que..."

# game/characters_events_idles/maya_events.rpy:651
translate portugues maya_scene6_evening_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "Não vai embora"

# game/characters_events_idles/maya_events.rpy:661
translate portugues maya_scene6_evening_myroom_0e9018a1:

    # gg "Иии"
    gg "Eeee"

# game/characters_events_idles/maya_events.rpy:663
translate portugues maya_scene6_evening_myroom_15ebc100:

    # gg "Операция закончена"
    gg "Operação concluída"

# game/characters_events_idles/maya_events.rpy:667
translate portugues maya_scene6_evening_myroom_1ceba70d:

    # Maya "Спасибо"
    Maya "Obrigada"

# game/characters_events_idles/maya_events.rpy:680
translate portugues maya_scene6_evening_myroom_6fdd6424:

    # Maya "Не привыкай"
    Maya "Não se acostume"

# game/characters_events_idles/maya_events.rpy:683
translate portugues maya_scene6_evening_myroom_63c1dadc_1:

    # gg "Не собирался"
    gg "Nem ia"

# game/characters_events_idles/maya_events.rpy:705
translate portugues maya_scene7_night_mayaroom_fec75b67:

    # gg "Ты до сих пор за ноутом?"
    gg "Você ainda tá no notebook?"

# game/characters_events_idles/maya_events.rpy:706
translate portugues maya_scene7_night_mayaroom_762dfc55:

    # gg "Уже за полночь"
    gg "Já passou da meia-noite"

# game/characters_events_idles/maya_events.rpy:708
translate portugues maya_scene7_night_mayaroom_0d6d9e7f:

    # Maya "И что?"
    Maya "E daí?"

# game/characters_events_idles/maya_events.rpy:709
translate portugues maya_scene7_night_mayaroom_f874de68:

    # Maya "У меня дела в отличие от некоторых"
    Maya "Eu tenho coisas pra fazer, ao contrário de alguns"

# game/characters_events_idles/maya_events.rpy:711
translate portugues maya_scene7_night_mayaroom_6b992d2b:

    # gg "Уже ночь"
    gg "Já é noite"

# game/characters_events_idles/maya_events.rpy:713
translate portugues maya_scene7_night_mayaroom_730b6969:

    # gg "А переписка это работа?"
    gg "E conversar no chat é trabalho?"

# game/characters_events_idles/maya_events.rpy:716
translate portugues maya_scene7_night_mayaroom_ca9eb87e:

    # Maya "Да мои дела"
    Maya "São minhas coisas"

# game/characters_events_idles/maya_events.rpy:718
translate portugues maya_scene7_night_mayaroom_e1a35225:

    # Maya "Вечно лезешь туда, куда не зовут"
    Maya "Sempre se metendo onde não foi chamado"

# game/characters_events_idles/maya_events.rpy:720
translate portugues maya_scene7_night_mayaroom_54c856a0:

    # gg "А дверь открытая{w}, значит ждала"
    gg "E a porta aberta{w}, significa que tava esperando"

# game/characters_events_idles/maya_events.rpy:722
translate portugues maya_scene7_night_mayaroom_5ebc71c5:

    # Maya "Ждала?"
    Maya "Esperando?"

# game/characters_events_idles/maya_events.rpy:724
translate portugues maya_scene7_night_mayaroom_ab53ee69:

    # Maya "Только если дурака, чтобы под руку мешался"
    Maya "Só se fosse um idiota pra ficar atrapalhando"

# game/characters_events_idles/maya_events.rpy:725
translate portugues maya_scene7_night_mayaroom_e04cd055:

    # gg_chat "На вид она слишком устала для настоящей злости"
    gg_chat "Ela parece cansada demais pra uma raiva de verdade"

# game/characters_events_idles/maya_events.rpy:730
translate portugues maya_scene7_night_mayaroom_8876fd31:

    # Maya "ЭЭ"
    Maya "EI"

# game/characters_events_idles/maya_events.rpy:733
translate portugues maya_scene7_night_mayaroom_588c8161:

    # Maya "Не смей! Это моё!" with hpunch
    Maya "Não ouse! Isso é meu!" with hpunch

# game/characters_events_idles/maya_events.rpy:735
translate portugues maya_scene7_night_mayaroom_30b1c14e:

    # gg "Да я и не собирался читать"
    gg "Mas eu nem ia ler"

# game/characters_events_idles/maya_events.rpy:736
translate portugues maya_scene7_night_mayaroom_4d7029b4:

    # gg "Просто . . . {w}ты могла бы не прятать"
    gg "Só que... {w}você não precisava esconder"

# game/characters_events_idles/maya_events.rpy:738
translate portugues maya_scene7_night_mayaroom_43898c08:

    # Maya "Потому что . . ."
    Maya "Porque..."

# game/characters_events_idles/maya_events.rpy:740
translate portugues maya_scene7_night_mayaroom_7673a52d:

    # Maya "C тобой я . . ."
    Maya "Com você eu..."

# game/characters_events_idles/maya_events.rpy:747
translate portugues maya_scene7_night_mayaroom_d57c47f7:

    # Maya ". . . "
    Maya "..."

# game/characters_events_idles/maya_events.rpy:748
translate portugues maya_scene7_night_mayaroom_8b57d927:

    # Maya ". . . {w}Я не своя . . ."
    Maya "...{w}Eu não tô sendo eu mesma..."

# game/characters_events_idles/maya_events.rpy:749
translate portugues maya_scene7_night_mayaroom_6f9409ff:

    # Maya "Я всё время о тебе думаю"
    Maya "Eu fico pensando em você o tempo todo"

# game/characters_events_idles/maya_events.rpy:754
translate portugues maya_scene7_night_mayaroom_df75b7f4:

    # Maya "С тобой я только и делаю, что тупею!"
    Maya "Com você eu só fico mais burra!"

# game/characters_events_idles/maya_events.rpy:756
translate portugues maya_scene7_night_mayaroom_578ec278:

    # Maya "Вот и всё"
    Maya "E é isso"

# game/characters_events_idles/maya_events.rpy:761
translate portugues maya_scene7_night_mayaroom_b56e467a:

    # gg "Ты прячешься за словами, но глаза выдают всё"
    gg "Você se esconde atrás das palavras, mas seus olhos entregam tudo"

# game/characters_events_idles/maya_events.rpy:769
translate portugues maya_scene7_night_mayaroom_b0f630ba:

    # Maya "{size=*0.8}. . . Дурак . . .{/size}"
    Maya "{size=*0.8}... Idiota...{/size}"

# game/characters_events_idles/maya_events.rpy:770
translate portugues maya_scene7_night_mayaroom_8e74b6e2:

    # Maya "Если кому-то скажешь - я тебя прибью" with hpunch
    Maya "Se contar pra alguém — eu te arrebento" with hpunch

# game/characters_events_idles/maya_events.rpy:774
translate portugues maya_scene7_night_mayaroom_03506582:

    # gg "Угрожаешь после такого? {w}Смелая"
    gg "Ameaçando depois disso? {w}Corajosa"

# game/characters_events_idles/maya_events.rpy:777
translate portugues maya_scene7_night_mayaroom_991c3acc:

    # gg "Никому {w}только между нами"
    gg "Pra ninguém {w}só entre a gente"

# game/characters_events_idles/maya_events.rpy:792
translate portugues maya_scene8_morning_mayaroom_3ccef67b:

    # gg_chat "Она выглядит . . . спокойно {w}Никакой злости {w} даже странно"
    gg_chat "Ela parece... calma {w}Nada de raiva {w}até estranho"

# game/characters_events_idles/maya_events.rpy:794
translate portugues maya_scene8_morning_mayaroom_8e119e79:

    # Maya "Ты чё . . . {w}уже встал?.."
    Maya "Você o quê... {w}já levantou?.."

# game/characters_events_idles/maya_events.rpy:796
translate portugues maya_scene8_morning_mayaroom_fb3f31cf:

    # gg "Эм . . . да. Я не хотел мешать. Просто заглянул"
    gg "Hm... sim. Não queria atrapalhar. Só vim dar uma olhada"

# game/characters_events_idles/maya_events.rpy:798
translate portugues maya_scene8_morning_mayaroom_0a978bde:

    # Maya "Не уходи . . ."
    Maya "Não vai..."

# game/characters_events_idles/maya_events.rpy:800
translate portugues maya_scene8_morning_mayaroom_3a0bea4a:

    # Maya "Сядь"
    Maya "Senta"

# game/characters_events_idles/maya_events.rpy:805
translate portugues maya_scene8_morning_mayaroom_970fe7c6:

    # Maya "Спала ужасно . . ."
    Maya "Dormi horrível..."

# game/characters_events_idles/maya_events.rpy:807
translate portugues maya_scene8_morning_mayaroom_4ada6f49:

    # Maya "Всё крутилось в голове"
    Maya "Tudo ficou girando na minha cabeça"

# game/characters_events_idles/maya_events.rpy:808
translate portugues maya_scene8_morning_mayaroom_ee85048c:

    # Maya "Не выспалась"
    Maya "Não dormi o suficiente"

# game/characters_events_idles/maya_events.rpy:810
translate portugues maya_scene8_morning_mayaroom_30004a57:

    # gg "А у тебя будто энергии с утра через край"
    gg "E você parece cheia de energia de manhã"

# game/characters_events_idles/maya_events.rpy:812
translate portugues maya_scene8_morning_mayaroom_c4e0d6af:

    # Maya "Очень смешно . . . "
    Maya "Muito engraçado..."

# game/characters_events_idles/maya_events.rpy:814
translate portugues maya_scene8_morning_mayaroom_c574ca14:

    # Maya "Я лентяйка {w}просто иногда притворяюсь"
    Maya "Eu sou preguiçosa {w}só que às vezes finjo"

# game/characters_events_idles/maya_events.rpy:816
translate portugues maya_scene8_morning_mayaroom_42c46aa1:

    # Maya "Ляг"
    Maya "Deita"

# game/characters_events_idles/maya_events.rpy:817
translate portugues maya_scene8_morning_mayaroom_9e620d29:

    # Maya "Просто . . . {w}чтоб теплее было"
    Maya "Só... {w}pra ficar mais quente"

# game/characters_events_idles/maya_events.rpy:821
translate portugues maya_scene8_morning_mayaroom_d012bf21:

    # gg "Ты не заболела случайно?"
    gg "Você não tá doente, por acaso?"

# game/characters_events_idles/maya_events.rpy:824
translate portugues maya_scene8_morning_mayaroom_06609c2f:

    # Maya "Убью, если кому-то расскажешь"
    Maya "Te mato se contar pra alguém"

# game/characters_events_idles/maya_events.rpy:827
translate portugues maya_scene8_morning_mayaroom_aed6c2f3:

    # gg_chat "Может это мой шанс . . ."
    gg_chat "Talvez seja minha chance..."

# game/characters_events_idles/maya_events.rpy:833
translate portugues maya_scene8_morning_mayaroom_7f5f7cbf:

    # Maya "Дурак . . ."
    Maya "Idiota..."

# game/characters_events_idles/maya_events.rpy:837
translate portugues maya_scene8_morning_mayaroom_f7f3b708:

    # gg_chat "Слишком спокойно . . ."
    gg_chat "Tão calma..."

# game/characters_events_idles/maya_events.rpy:838
translate portugues maya_scene8_morning_mayaroom_fc2580e2:

    # gg_chat "Значит, самое время тихо уйти"
    gg_chat "Então, é hora de ir embora quieto"

# game/characters_events_idles/maya_events.rpy:841
translate portugues maya_scene8_morning_mayaroom_4b32219f:

    # gg_chat "Никогда бы не подумал, что первый поцелуй с ней будет таким"
    gg_chat "Nunca imaginei que o primeiro beijo com ela seria assim"

# game/characters_events_idles/maya_events.rpy:845
translate portugues maya_scene8_morning_mayaroom_31bdebc7:

    # gg_chat "Вот бы всегда так . . ."
    gg_chat "Queria que fosse sempre assim..."

# game/characters_events_idles/maya_events.rpy:846
translate portugues maya_scene8_morning_mayaroom_7d3e081f:

    # gg_chat "Но, зная её, лучше не задерживаться"
    gg_chat "Mas, conhecendo ela, melhor não demorar"

# game/characters_events_idles/maya_events.rpy:851
translate portugues maya_scene8_morning_mayaroom_f57b1e37:

    # gg_chat "Мягкость её груди всё ещё чувствовалась . . ."
    gg_chat "A suavidade dos seios dela ainda dava pra sentir..."

# game/characters_events_idles/maya_events.rpy:852
translate portugues maya_scene8_morning_mayaroom_ba3923be:

    # gg_chat "И отпускать не хотелось"
    gg_chat "E eu não queria soltar"

# game/characters_events_idles/maya_events.rpy:872
translate portugues maya_scene9_day_kitchen_b483553f:

    # Maya "О ты тут, помоги посыпать соль"
    Maya "Ah, você tá aí, me ajuda a salgar"

# game/characters_events_idles/maya_events.rpy:874
translate portugues maya_scene9_day_kitchen_564e6225:

    # gg "Окей"
    gg "Ok"

# game/characters_events_idles/maya_events.rpy:877
translate portugues maya_scene9_day_kitchen_7d928982:

    # Maya "И аккуратней, а то пересолишь"
    Maya "E com cuidado, senão vai salgar demais"

# game/characters_events_idles/maya_events.rpy:887
translate portugues maya_scene9_day_kitchen_29721060:

    # Maya "Так . . . {w}вот теперь оно прилипло к сковородке"
    Maya "Então... {w}agora grudou na frigideira"

# game/characters_events_idles/maya_events.rpy:888
translate portugues maya_scene9_day_kitchen_11cbabe0:

    # Maya "Прям не оторвать"
    Maya "Nem dá pra desgrudar"

# game/characters_events_idles/maya_events.rpy:889
translate portugues maya_scene9_day_kitchen_927dfd8a:

    # gg "Тогда надо поддеть снизу, чтобы не пригорело"
    gg "Então tem que levantar por baixo, pra não queimar"

# game/characters_events_idles/maya_events.rpy:892
translate portugues maya_scene9_day_kitchen_b2073f58:

    # Maya "Главное - не давить слишком резко"
    Maya "O importante é não pressionar muito bruscamente"

# game/characters_events_idles/maya_events.rpy:893
translate portugues maya_scene9_day_kitchen_e7cb36e7:

    # Maya "Иначе желток лопнет"
    Maya "Senão a gema estoura"

# game/characters_events_idles/maya_events.rpy:894
translate portugues maya_scene9_day_kitchen_23aa5a43:

    # gg "Но если аккуратно, всё останется целым"
    gg "Mas se for com cuidado, tudo fica intacto"

# game/characters_events_idles/maya_events.rpy:895
translate portugues maya_scene9_day_kitchen_0c33c9a7:

    # Maya "Угу . . . {w}мягче перемешивай"
    Maya "Aham... {w}mexe mais devagar"

# game/characters_events_idles/maya_events.rpy:896
translate portugues maya_scene9_day_kitchen_7c4d7305:

    # Maya "Тогда всё прожарится равномерно"
    Maya "Aí tudo frita uniformemente"

# game/characters_events_idles/maya_events.rpy:899
translate portugues maya_scene9_day_kitchen_b067ff5d:

    # Maya "Всё, почти готово . . ."
    Maya "Pronto, quase acabando..."

# game/characters_events_idles/maya_events.rpy:900
translate portugues maya_scene9_day_kitchen_5805bb78:

    # Maya "Ещё чуть-чуть, и можно снимать с огня"
    Maya "Só mais um pouquinho, e pode tirar do fogo"

# game/characters_events_idles/maya_events.rpy:901
translate portugues maya_scene9_day_kitchen_c61ed5a8:

    # gg "Думаю, будет очень вкусно"
    gg "Acho que vai ficar muito bom"

# game/characters_events_idles/maya_events.rpy:905
translate portugues maya_scene9_day_kitchen_152dc2f3:

    # Maya "Всё {w}a то сейчас пережарим"
    Maya "Pronto {w}senão agora vamos queimar"

# game/characters_events_idles/maya_events.rpy:907
translate portugues maya_scene9_day_kitchen_d98d84da:

    # Maya "Дальше сам себе готовь"
    Maya "Daqui pra frente se vira pra cozinhar"

# game/characters_events_idles/maya_events.rpy:909
translate portugues maya_scene9_day_kitchen_c00c68f7:

    # gg_chat "Она подыгрывала"
    gg_chat "Ela estava entrando no jogo"

# game/characters_events_idles/maya_events.rpy:910
translate portugues maya_scene9_day_kitchen_8e86ab7e:

    # gg_chat "Но в конце всё равно сбежала . . ."
    gg_chat "Mas no final mesmo assim fugiu..."

# game/characters_events_idles/maya_events.rpy:928
translate portugues maya_scene10_evening_myroom_b792031e:

    # Maya "Я дома"
    Maya "Cheguei"

# game/characters_events_idles/maya_events.rpy:930
translate portugues maya_scene10_evening_myroom_4c632d43:

    # Maya "О, ты тут"
    Maya "Ah, você tá aqui"

# game/characters_events_idles/maya_events.rpy:932
translate portugues maya_scene10_evening_myroom_e37dbd39:

    # gg "Привет. Как работа?"
    gg "Oi. Como foi o trabalho?"

# game/characters_events_idles/maya_events.rpy:934
translate portugues maya_scene10_evening_myroom_92ca482a:

    # Maya "Словно вечность. Эта долбаные люди"
    Maya "Parecia uma eternidade. Essas pessoas chatas"

# game/characters_events_idles/maya_events.rpy:936
translate portugues maya_scene10_evening_myroom_d1b85968:

    # gg "Хочешь чай? Или просто вырубиться?"
    gg "Quer chá? Ou só desmaiar mesmo?"

# game/characters_events_idles/maya_events.rpy:938
translate portugues maya_scene10_evening_myroom_a28c5657:

    # Maya "Чай?{w} Ты решил внезапно заботиться?"
    Maya "Chá?{w} Você decidiu de repente cuidar de mim?"

# game/characters_events_idles/maya_events.rpy:940
translate portugues maya_scene10_evening_myroom_ffaaaddc:

    # Maya "Ладно . . . да, пожалуй. И два сахара"
    Maya "Tá bom... sim, por favor. E dois açúcares"

# game/characters_events_idles/maya_events.rpy:944
translate portugues maya_scene10_evening_myroom_fc470a50:

    # Maya "Уфф устала"
    Maya "Uff, cansada"

# game/characters_events_idles/maya_events.rpy:946
translate portugues maya_scene10_evening_myroom_d751ae58:

    # gg "Может, поговорим?"
    gg "Que tal a gente conversar?"

# game/characters_events_idles/maya_events.rpy:948
translate portugues maya_scene10_evening_myroom_dd61a1d4:

    # Maya "О чём?"
    Maya "Sobre o quê?"

# game/characters_events_idles/maya_events.rpy:950
translate portugues maya_scene10_evening_myroom_cb7be281:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Уволь"
    Maya "Sobre como eu ignorei a limpeza de novo?{w} {bt=a3-p2.0-s3.0}Esquece"

# game/characters_events_idles/maya_events.rpy:952
translate portugues maya_scene10_evening_myroom_49e84409:

    # gg "Необязательно. Можно просто помолчать"
    gg "Não precisa. Pode ser só ficar em silêncio"

# game/characters_events_idles/maya_events.rpy:954
translate portugues maya_scene10_evening_myroom_963962a9:

    # Maya "Ты странный. Сидишь тут . . . как будто ждёшь чего-то"
    Maya "Você é esquisito. Sentado aí... como se estivesse esperando alguma coisa"

# game/characters_events_idles/maya_events.rpy:958
translate portugues maya_scene10_evening_myroom_31f86790:

    # gg "Может, и жду"
    gg "Talvez esteja"

# game/characters_events_idles/maya_events.rpy:960
translate portugues maya_scene10_evening_myroom_7f342626:

    # Maya "Ты же знаешь, что я . . . колючая"
    Maya "Você sabe que eu sou... espinhosa"

# game/characters_events_idles/maya_events.rpy:962
translate portugues maya_scene10_evening_myroom_27989031:

    # gg "Знаю"
    gg "Sei"

# game/characters_events_idles/maya_events.rpy:964
translate portugues maya_scene10_evening_myroom_91a19161:

    # Maya "И что я всё испорчу"
    Maya "E que eu vou estragar tudo"

# game/characters_events_idles/maya_events.rpy:966
translate portugues maya_scene10_evening_myroom_d6704538:

    # Maya "Обязательно ляпну какую-нибудь чушь"
    Maya "Com certeza vou falar alguma besteira"

# game/characters_events_idles/maya_events.rpy:968
translate portugues maya_scene10_evening_myroom_489ce109:

    # gg "{bt=a3-p2.0-s3.0}{size=*0.8}Привык уже"
    gg "{bt=a3-p2.0-s3.0}{size=*0.8}Já me acostumei"

# game/characters_events_idles/maya_events.rpy:974
translate portugues maya_scene10_evening_myroom_c0ac8816:

    # Maya "Ну конечно. Самое время для этого"
    Maya "Claro. Hora perfeita pra isso"

# game/characters_events_idles/maya_events.rpy:976
translate portugues maya_scene10_evening_myroom_ec57c0d1:

    # gg "Май . . ."
    gg "Mai..."

# game/characters_events_idles/maya_events.rpy:978
translate portugues maya_scene10_evening_myroom_16a831f4:

    # Maya "Заткнись"
    Maya "Cala a boca"

# game/characters_events_idles/maya_events.rpy:980
translate portugues maya_scene10_evening_myroom_71044ba9:

    # Maya "Просто . . . заткнись"
    Maya "Só... cala a boca"

# game/characters_events_idles/maya_events.rpy:990
translate portugues maya_scene10_evening_myroom_742929c8:

    # Maya "Тише . . . Осторожно. Я не . . .{w} Я не готова ко всему сразу"
    Maya "Devagar... Cuidado. Eu não...{w} Eu não tô pronta pra tudo de uma vez"

# game/characters_events_idles/maya_events.rpy:996
translate portugues maya_scene10_evening_myroom_66b26945:

    # Maya "Ох . . . боже . . ."
    Maya "Ah... meu Deus..."

# game/characters_events_idles/maya_events.rpy:1008
translate portugues maya_scene10_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya "..."

# game/characters_events_idles/maya_events.rpy:1010
translate portugues maya_scene10_evening_myroom_71253d69:

    # Maya "Вот это да . . ."
    Maya "Nossa..."

# game/characters_events_idles/maya_events.rpy:1012
translate portugues maya_scene10_evening_myroom_22f5a5a6:

    # Maya "Ты это . . . там всё время носил?"
    Maya "Você tava... com isso o tempo todo?"

# game/characters_events_idles/maya_events.rpy:1018
translate portugues maya_scene10_evening_myroom_c014a37d:

    # Maya "Нет . . ."
    Maya "Não..."

# game/characters_events_idles/maya_events.rpy:1020
translate portugues maya_scene10_evening_myroom_2d2f095f:

    # Maya "Нет, стоп"
    Maya "Não, para"

# game/characters_events_idles/maya_events.rpy:1022
translate portugues maya_scene10_evening_myroom_6b00b07b:

    # Maya "Стоп, блядь"
    Maya "Para, porra"

# game/characters_events_idles/maya_events.rpy:1024
translate portugues maya_scene10_evening_myroom_f3f9fdab:

    # gg "Майя?"
    gg "Maya?"

# game/characters_events_idles/maya_events.rpy:1026
translate portugues maya_scene10_evening_myroom_b9eafd1f:

    # Maya "Выйди. Пожалуйста.{w} Просто . . . выйди"
    Maya "Sai. Por favor.{w} Só... sai"

# game/characters_events_idles/maya_events.rpy:1028
translate portugues maya_scene10_evening_myroom_92d5f1bf:

    # gg "Я . . .{w} Я не хотел . . ."
    gg "Eu...{w} Eu não queria..."

# game/characters_events_idles/maya_events.rpy:1030
translate portugues maya_scene10_evening_myroom_e6bbb658:

    # Maya "{sc}{size=*1.2}Я ЗНАЮ{/size}{/sc}, что не хотел!"
    Maya "{sc}{size=*1.2}EU SEI{/size}{/sc} que não queria!"

# game/characters_events_idles/maya_events.rpy:1032
translate portugues maya_scene10_evening_myroom_9ef6f711:

    # Maya "Именно поэтому — ВЫЙДИ!"
    Maya "É por isso mesmo — SAI!"

# game/characters_events_idles/maya_events.rpy:1034
translate portugues maya_scene10_evening_myroom_85e3ca37:

    # Maya "Не сейчас . . .{w} Я не могу{w} Это слишком . . . реально"
    Maya "Agora não...{w} Eu não consigo{w} Isso é... real demais"

# game/characters_events_idles/maya_events.rpy:1036
translate portugues maya_scene10_evening_myroom_a4abe766:

    # gg "Хорошо. Я . . .{w} Я ушёл"
    gg "Tá bom. Eu...{w} Eu vou embora"

# game/characters_events_idles/maya_events.rpy:1040
translate portugues maya_scene10_evening_myroom_8454737d:

    # Maya "{size=*0.8}Чёрт . . . Чёрт . . . Чёрт . . ."
    Maya "{size=*0.8}Droga... Droga... Droga..."

# game/characters_events_idles/maya_events.rpy:1041
translate portugues maya_scene10_evening_myroom_c2f04aea:

    # Maya "{size=*0.8}Он такой . . . большой . . ."
    Maya "{size=*0.8}Ele é tão... grande..."

# game/characters_events_idles/maya_events.rpy:1043
translate portugues maya_scene10_evening_myroom_828ad43f:

    # Maya "{size=*0.8}И мне . . ."
    Maya "{size=*0.8}E eu..."

# game/characters_events_idles/maya_events.rpy:1044
translate portugues maya_scene10_evening_myroom_b4c5d69e:

    # Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Понравилось"
    Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Gostei"

# game/characters_events_idles/maya_events.rpy:1061
translate portugues maya_scene11_morning_bathroom_bd1a48b9:

    # gg "Ты с утра за стиркой"
    gg "Você lavando roupa de manhã"

# game/characters_events_idles/maya_events.rpy:1062
translate portugues maya_scene11_morning_bathroom_17ad5908:

    # gg "Это что то мифическое"
    gg "Isso é meio mítico"

# game/characters_events_idles/maya_events.rpy:1064
translate portugues maya_scene11_morning_bathroom_2998d6f9:

    # Maya "Миф"
    Maya "Mito"

# game/characters_events_idles/maya_events.rpy:1066
translate portugues maya_scene11_morning_bathroom_fa12fc4b:

    # Maya "Это если бы ты сам что-то постирал"
    Maya "Isso seria se você mesmo lavasse alguma coisa"

# game/characters_events_idles/maya_events.rpy:1071
translate portugues maya_scene11_morning_bathroom_10404fc0:

    # gg "Я хотя бы свои вещи складываю"
    gg "Eu pelo menos dobro minhas roupas"

# game/characters_events_idles/maya_events.rpy:1073
translate portugues maya_scene11_morning_bathroom_cfff324a:

    # gg "А твои валялись по всей комнате"
    gg "E as suas tavam jogadas por todo o quarto"

# game/characters_events_idles/maya_events.rpy:1075
translate portugues maya_scene11_morning_bathroom_67c05e6d:

    # Maya "И кто же их собрал? Не ты"
    Maya "E quem juntou elas? Não foi você"

# game/characters_events_idles/maya_events.rpy:1077
translate portugues maya_scene11_morning_bathroom_b4e5e9ee:

    # gg "Ещё чуть-чуть, и я подумаю, что ты скрытая трудяга"
    gg "Mais um pouquinho e eu vou achar que você é uma trabalhadora secreta"

# game/characters_events_idles/maya_events.rpy:1079
translate portugues maya_scene11_morning_bathroom_4907bae2:

    # Maya "Чего говоришь!"
    Maya "O que você tá dizendo!"

# game/characters_events_idles/maya_events.rpy:1081
translate portugues maya_scene11_morning_bathroom_eaaef249:

    # Maya "Думаешь я настолько лентяйка?"
    Maya "Acha que eu sou tão preguiçosa?"

# game/characters_events_idles/maya_events.rpy:1083
translate portugues maya_scene11_morning_bathroom_062411d1:

    # gg "Думаю"
    gg "Acho"

# game/characters_events_idles/maya_events.rpy:1088
translate portugues maya_scene11_morning_bathroom_b708dc2c:

    # gg "Ты кое что забыла поставить на стирку"
    gg "Você esqueceu de botar uma coisa pra lavar"

# game/characters_events_idles/maya_events.rpy:1096
translate portugues maya_scene11_morning_bathroom_8c8070f2:

    # Maya "Ах так?"
    Maya "Ah é?"

# game/characters_events_idles/maya_events.rpy:1098
translate portugues maya_scene11_morning_bathroom_cb35be97:

    # Maya "Тогда стираем всё"
    Maya "Então vamos lavar tudo"

# game/characters_events_idles/maya_events.rpy:1104
translate portugues maya_scene11_morning_bathroom_cf4d3425:

    # Maya "Ага . . ."
    Maya "Aham..."

# game/characters_events_idles/maya_events.rpy:1106
translate portugues maya_scene11_morning_bathroom_fa661e9f:

    # Maya "Похоже ЭТО нужно будет стирать деликатно"
    Maya "Parece que ISSO vai precisar de uma lavagem delicada"

# game/characters_events_idles/maya_events.rpy:1108
translate portugues maya_scene11_morning_bathroom_9cd0adf2:

    # Maya "Думаю мы можем продолжить на чем закончили?"
    Maya "Acho que podemos continuar de onde paramos?"

# game/characters_events_idles/maya_events.rpy:1112
translate portugues maya_scene11_morning_bathroom_84b09d0d:

    # Maya "Стиралка работает . . . {w}но тут жарче, чем должно быть"
    Maya "A máquina tá funcionando... {w}mas tá mais quente aqui do que devia"

# game/characters_events_idles/maya_events.rpy:1113
translate portugues maya_scene11_morning_bathroom_6df3a5e2:

    # gg "Главное - достирай до конца"
    gg "O importante é lavar até o fim"

# game/characters_events_idles/maya_events.rpy:1114
translate portugues maya_scene11_morning_bathroom_d0b88dcb:

    # gg "Если оставишь придется домывать . . ."
    gg "Se deixar pela metade vai ter que relavar..."

# game/characters_events_idles/maya_events.rpy:1119
translate portugues maya_scene11_morning_bathroom_0467b855:

    # Maya "Так я думаю стиралка сама справится"
    Maya "Bom, acho que a máquina dá conta sozinha"

# game/characters_events_idles/maya_events.rpy:1122
translate portugues maya_scene11_morning_bathroom_542d4b95:

    # Maya "А ты . . . {w}сам достирай свое"
    Maya "E você... {w}lave o seu até o fim"

# game/characters_events_idles/maya_events.rpy:1123
translate portugues maya_scene11_morning_bathroom_83b51400:

    # Maya "Белье . . ."
    Maya "Roupa de baixo..."

# game/characters_events_idles/maya_events.rpy:1129
translate portugues maya_scene11_morning_bathroom_eb975221:

    # gg_chat "Она ушла . . ."
    gg_chat "Ela foi embora..."

# game/characters_events_idles/maya_events.rpy:1130
translate portugues maya_scene11_morning_bathroom_3188cfc5:

    # gg_chat "В следующий раз ее нельзя отпускать . . ."
    gg_chat "Da próxima vez não posso deixar ela ir..."

# game/characters_events_idles/maya_events.rpy:1147
translate portugues maya_scene12_evening_myroom_bb653a62:

    # Maya "Ха, так вот где ты спрятался"
    Maya "Hah, então foi aqui que você se escondeu"

# game/characters_events_idles/maya_events.rpy:1149
translate portugues maya_scene12_evening_myroom_4ca35500:

    # Maya "И что ты смотришь?"
    Maya "E o que você tá assistindo?"

# game/characters_events_idles/maya_events.rpy:1151
translate portugues maya_scene12_evening_myroom_7e8ca4c6:

    # gg "Подожди я в матче"
    gg "Espera, tô numa partida"

# game/characters_events_idles/maya_events.rpy:1152
translate portugues maya_scene12_evening_myroom_5ed608a5:

    # gg "Если отвлекусь - проиграю"
    gg "Se me distrair — vou perder"

# game/characters_events_idles/maya_events.rpy:1154
translate portugues maya_scene12_evening_myroom_8f98104b:

    # Maya "И это, по-твоему, веселье?"
    Maya "E isso pra você é diversão?"

# game/characters_events_idles/maya_events.rpy:1156
translate portugues maya_scene12_evening_myroom_336dd03a:

    # gg "Когда сам играешь намного веселее . . ."
    gg "Quando você joga é muito mais divertido..."

# game/characters_events_idles/maya_events.rpy:1158
translate portugues maya_scene12_evening_myroom_3a2af852:

    # Maya "А по мне, как будто трата времени"
    Maya "Pra mim parece perda de tempo"

# game/characters_events_idles/maya_events.rpy:1160
translate portugues maya_scene12_evening_myroom_814660f9:

    # gg "Эй!" with hpunch
    gg "Ei!" with hpunch

# game/characters_events_idles/maya_events.rpy:1161
translate portugues maya_scene12_evening_myroom_a589a29a:

    # gg "Я ничего не вижу!"
    gg "Não tô vendo nada!"

# game/characters_events_idles/maya_events.rpy:1162
translate portugues maya_scene12_evening_myroom_6d7f26d1:

    # Maya "Ну и что?"
    Maya "E daí?"

# game/characters_events_idles/maya_events.rpy:1164
translate portugues maya_scene12_evening_myroom_8bb854aa:

    # Maya "Почему перестал играть?"
    Maya "Por que parou de jogar?"

# game/characters_events_idles/maya_events.rpy:1166
translate portugues maya_scene12_evening_myroom_9c0bce5d:

    # gg "Я же сказал"
    gg "Eu já disse"

# game/characters_events_idles/maya_events.rpy:1168
translate portugues maya_scene12_evening_myroom_4430c970:

    # gg "Теперь только тебя и вижу"
    gg "Agora só tô vendo você"

# game/characters_events_idles/maya_events.rpy:1170
translate portugues maya_scene12_evening_myroom_e1ca96ab:

    # Maya "Вот и отлично!"
    Maya "Ótimo então!"

# game/characters_events_idles/maya_events.rpy:1172
translate portugues maya_scene12_evening_myroom_e638502a:

    # Maya "Я теперь главный игрок"
    Maya "Agora eu sou a jogadora principal"

# game/characters_events_idles/maya_events.rpy:1174
translate portugues maya_scene12_evening_myroom_1751458f:

    # gg "Ты щас мне рейтинг сольешь"
    gg "Você vai acabar com meu rating agora"

# game/characters_events_idles/maya_events.rpy:1176
translate portugues maya_scene12_evening_myroom_ce7e136c:

    # Maya "Да ну, я просто проверяю"
    Maya "Ah qual é, só tô testando"

# game/characters_events_idles/maya_events.rpy:1178
translate portugues maya_scene12_evening_myroom_81a51f30:

    # Maya "Как тут . . . прыгает!"
    Maya "Como é que... pula!"

# game/characters_events_idles/maya_events.rpy:1180
translate portugues maya_scene12_evening_myroom_c46a67aa:

    # Maya "Ой, а это что делает?"
    Maya "Ah, e isso aqui faz o quê?"

# game/characters_events_idles/maya_events.rpy:1181
translate portugues maya_scene12_evening_myroom_9260e289:

    # gg "Стой, не так"
    gg "Para, não assim"

# game/characters_events_idles/maya_events.rpy:1183
translate portugues maya_scene12_evening_myroom_16a342c4:

    # gg "Вот эта - стрелять, эта - использовать"
    gg "Essa aqui — atira, essa — usa"

# game/characters_events_idles/maya_events.rpy:1185
translate portugues maya_scene12_evening_myroom_c634457f:

    # gg "Держи крепче, смотри в экран"
    gg "Segura firme, olha pra tela"

# game/characters_events_idles/maya_events.rpy:1188
translate portugues maya_scene12_evening_myroom_b18fd1da:

    # Maya "Мм . . ."
    Maya "Mm..."

# game/characters_events_idles/maya_events.rpy:1189
translate portugues maya_scene12_evening_myroom_3f637927:

    # Maya "Тут у тебя геймпад немного неудобный . . ."
    Maya "Seu controle é um pouco desconfortável..."

# game/characters_events_idles/maya_events.rpy:1190
translate portugues maya_scene12_evening_myroom_8351e9a2:

    # gg "Нет . . . {w}я про . . ."
    gg "Não... {w}eu tô falando..."

# game/characters_events_idles/maya_events.rpy:1193
translate portugues maya_scene12_evening_myroom_c16d1061:

    # gg "Целься и стреляй"
    gg "Mira e atira"

# game/characters_events_idles/maya_events.rpy:1197
translate portugues maya_scene12_evening_myroom_cbd60b88:

    # Maya "А! Я попала по нему!"
    Maya "Ah! Acertei ele!"

# game/characters_events_idles/maya_events.rpy:1198
translate portugues maya_scene12_evening_myroom_15447830:

    # Maya "Но всё равно проиграла . . ."
    Maya "Mas mesmo assim perdi..."

# game/characters_events_idles/maya_events.rpy:1199
translate portugues maya_scene12_evening_myroom_9b0188df:

    # gg "Нужно время, чтобы научиться"
    gg "Precisa de tempo pra aprender"

# game/characters_events_idles/maya_events.rpy:1201
translate portugues maya_scene12_evening_myroom_3a4b5fe2:

    # Maya "Время?"
    Maya "Tempo?"

# game/characters_events_idles/maya_events.rpy:1202
translate portugues maya_scene12_evening_myroom_7be2116f:

    # Maya "У меня терпения не хватит"
    Maya "Eu não tenho paciência pra isso"

# game/characters_events_idles/maya_events.rpy:1207
translate portugues maya_scene12_evening_myroom_502ea205:

    # Maya "Я лучше найду другой способ с тобой поиграть"
    Maya "É melhor eu achar outro jeito de brincar com você"

# game/characters_events_idles/maya_events.rpy:1209
translate portugues maya_scene12_evening_myroom_d76b3a67:

    # gg "Похоже, тебе важнее сбить меня с толку . . ."
    gg "Parece que é mais importante pra você me confundir..."

# game/characters_events_idles/maya_events.rpy:1212
translate portugues maya_scene12_evening_myroom_9a170cb1:

    # Maya "Экран-то видишь ещё?"
    Maya "Ainda tá vendo a tela?"

# game/characters_events_idles/maya_events.rpy:1214
translate portugues maya_scene12_evening_myroom_7c6d2d03:

    # Maya "А это"
    Maya "E isso"

# game/characters_events_idles/maya_events.rpy:1216
translate portugues maya_scene12_evening_myroom_b1427dbd:

    # Maya "Не интереснее?"
    Maya "Não é mais interessante?"

# game/characters_events_idles/maya_events.rpy:1219
translate portugues maya_scene12_evening_myroom_2fd00100:

    # gg "Интереснее, но я хочу выиграть"
    gg "É, mas eu quero ganhar"

# game/characters_events_idles/maya_events.rpy:1222
translate portugues maya_scene12_evening_myroom_161fdfc3:

    # Maya "Ну-ну"
    Maya "Tá, tá"

# game/characters_events_idles/maya_events.rpy:1223
translate portugues maya_scene12_evening_myroom_270d46ae:

    # Maya "Тогда держи удар"
    Maya "Então aguenta o tranco"

# game/characters_events_idles/maya_events.rpy:1227
translate portugues maya_scene12_evening_myroom_38cb6e8b:

    # Maya "Геймер"
    Maya "Gamer"

# game/characters_events_idles/maya_events.rpy:1229
translate portugues maya_scene12_evening_myroom_a093b46d:

    # gg_chat "Она решила так играть? . . ."
    gg_chat "Ela decidiu jogar assim?..."
    
# game/characters_events_idles/maya_events.rpy:1233
translate portugues maya_scene12_evening_myroom_5f58be75:

    # Maya "Давай, продолжай выигрывать"
    Maya "Vai lá, continua ganhando"

# game/characters_events_idles/maya_events.rpy:1234
translate portugues maya_scene12_evening_myroom_6c6c4f14:

    # Maya "Интересно, надолго ли тебя хватит"
    Maya "Quero ver quanto tempo você aguenta"

# game/characters_events_idles/maya_events.rpy:1235
translate portugues maya_scene12_evening_myroom_cc2a1c48:

    # gg "Мая . . ."
    gg "Maya..."

# game/characters_events_idles/maya_events.rpy:1236
translate portugues maya_scene12_evening_myroom_a757aa6b:

    # gg "Ты . . ."
    gg "Você..."

# game/characters_events_idles/maya_events.rpy:1237
translate portugues maya_scene12_evening_myroom_2ca54e92:

    # Maya "Тише, я разбираюсь с управлением"
    Maya "Shhh, tô aprendendo os controles"

# game/characters_events_idles/maya_events.rpy:1243
translate portugues maya_scene12_evening_myroom_60a36ddd:

    # Maya "Ну что?"
    Maya "E aí?"

# game/characters_events_idles/maya_events.rpy:1244
translate portugues maya_scene12_evening_myroom_6ab6d9ce:

    # Maya "Поражение засчитано?"
    Maya "Derrota confirmada?"

# game/characters_events_idles/maya_events.rpy:1245
translate portugues maya_scene12_evening_myroom_c6558b58:

    # gg "Это вообще нечестная игра"
    gg "Isso nem é um jogo justo"

# game/characters_events_idles/maya_events.rpy:1247
translate portugues maya_scene12_evening_myroom_c6b0e67a:

    # Maya "Нечестные победы самые сладкие"
    Maya "Vitórias desleais são as mais doces"

# game/characters_events_idles/maya_events.rpy:1248
translate portugues maya_scene12_evening_myroom_6e151f9e:

    # Maya "Теперь ты мой должник"
    Maya "Agora você me deve"

translate portugues strings:

    # game/characters_events_idles/maya_events.rpy:742
    old "Договаривай"
    new "Termina"

    # game/characters_events_idles/maya_events.rpy:752
    old ". . ."
    new "..."

    # game/characters_events_idles/maya_events.rpy:772
    old "Угрожаешь?"
    new "Ameaçando?"

    # game/characters_events_idles/maya_events.rpy:775
    old "Никому"
    new "Pra ninguém"

    # game/characters_events_idles/maya_events.rpy:829
    old "Тихо поцеловать её"
    new "Beijá-la calmamente"

    # game/characters_events_idles/maya_events.rpy:842
    old "Уткнуться в ее грудь"
    new "Enterrar o rosto nos seios dela"

# TODO: Translation updated at 2026-01-26 03:23

# game/characters_events_idles/maya_events.rpy:248
translate portugues maya_scene3_evening_kitchen_2c2f92cd:

    # Maya "Зачем так близко?"
    Maya "Por que tão perto?"

# game/characters_events_idles/maya_events.rpy:314
translate portugues maya_scene4_morning_mayaroom_0d36d4ee:

    # gg "Хорошо, не собирался"
    gg "Tá bom, nem ia"

# game/characters_events_idles/maya_events.rpy:402
translate portugues maya_scene5_night_mayaroom_979f77d5:

    # Maya "{size=*1.3}Не надо"
    Maya "{size=*1.3}Não precisa"

# game/characters_events_idles/maya_events.rpy:410
translate portugues maya_scene5_night_mayaroom_8fb3b4e0:

    # Maya "{size=*1.3}Ты всегда «просто»"
    Maya "{size=*1.3}Você sempre 'só'"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/maya_events.rpy:42
translate portugues maya_scene1_evening_myroom_82e75b03:

    # Maya "Где они, блин"
    Maya "Onde eles estão, droga"

# game/characters_events_idles/maya_events.rpy:182
translate portugues maya_scene2_day_mayaroom_64552e65:

    # Maya "В мои дела"
    Maya "Nos meus assuntos"

# game/characters_events_idles/maya_events.rpy:293
translate portugues maya_scene4_morning_mayaroom_aea30766:

    # gg "Погоди, у меня была похожая проблема"
    gg "Espera, eu já tive um problema parecido"

# game/characters_events_idles/maya_events.rpy:304
translate portugues maya_scene4_morning_mayaroom_c677d050:

    # Maya "Ладно, поскольку ты уже встал тут в позу спасителя"
    Maya "Tá bom, já que você resolveu bancar o salvador"

# game/characters_events_idles/maya_events.rpy:308
translate portugues maya_scene4_morning_mayaroom_c7e3f4c3:

    # Maya "Но если сломаешь, новый купишь"
    Maya "Mas se quebrar, vai comprar outro"

# game/characters_events_idles/maya_events.rpy:398
translate portugues maya_scene5_night_mayaroom_24e10eb1:

    # Maya "Хочешь границы"
    Maya "Quer limites"

# game/characters_events_idles/maya_events.rpy:521
translate portugues maya_scene6_evening_myroom_8447de22:

    # Maya "Увидишь"
    Maya "Você vai ver"

# game/characters_events_idles/maya_events.rpy:580
translate portugues maya_scene6_evening_myroom_8974d68b:

    # Maya "В общем, нужно нанести крем и забинтовать"
    Maya "Enfim, precisa passar o creme e enfaixar"

# game/characters_events_idles/maya_events.rpy:594
translate portugues maya_scene6_evening_myroom_94783c90:

    # gg "Кажется, это называется забота"
    gg "Acho que isso se chama cuidado"

# game/characters_events_idles/maya_events.rpy:620
translate portugues maya_scene6_evening_myroom_b0f0812d:

    # gg "Просто сейчас . . .{w} нет смысла психовать"
    gg "Agora simplesmente...{w} não faz sentido surtar"

# game/characters_events_idles/maya_events.rpy:662
translate portugues maya_scene6_evening_myroom_98eb68ec:

    # gg "Если тебе так проще — я выйду"
    gg "Se for mais fácil pra você, eu saio"

# game/characters_events_idles/maya_events.rpy:957
translate portugues maya_scene10_evening_myroom_e458abf1:

    # Maya "Словно вечность. Эти долбаные люди"
    Maya "Parece uma eternidade. Essas pessoas malditas"

# game/characters_events_idles/maya_events.rpy:967
translate portugues maya_scene10_evening_myroom_39f98df4:

    # Maya "Уфф, устала"
    Maya "Uff, tô cansada"

# game/characters_events_idles/maya_events.rpy:973
translate portugues maya_scene10_evening_myroom_b1651980:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Отстань"
    Maya "Sobre como eu deixei a limpeza de lado de novo?{w} {bt=a3-p2.0-s3.0}Me deixa em paz"

# game/characters_events_idles/maya_events.rpy:975
translate portugues maya_scene10_evening_myroom_cd61d42f:

    # gg "Да ладно тебе, можно просто помолчать"
    gg "Ah, vai, a gente pode só ficar em silêncio"
# TODO: Translation updated at 2026-02-16 03:29

# game/characters_events_idles/maya_events.rpy:1300
translate portugues maya_scene13_morning_girlroom_4a56a987:

    # gg_chat "Так, Cоня просила заказать новый шнур и заодно батарейки"
    gg_chat "Então, Sonya pediu para eu encomendar um novo cabo e algumas pilhas"

# game/characters_events_idles/maya_events.rpy:1312
translate portugues maya_scene13_morning_girlroom_f5a72472:

    # gg "Ты чего?"
    gg "O que foi?"

# game/characters_events_idles/maya_events.rpy:1314
translate portugues maya_scene13_morning_girlroom_d958422f:

    # Maya "Ничего. Делай своё дело"
    Maya "Nada. Faça o seu trabalho"

# game/characters_events_idles/maya_events.rpy:1318
translate portugues maya_scene13_morning_girlroom_6b37e39c:

    # Maya "Не отвлекайся"
    Maya "Não se distraia"

# game/characters_events_idles/maya_events.rpy:1324
translate portugues maya_scene13_morning_girlroom_36d1af18:

    # gg "Мая одну секунду . . ."
    gg "Maya, só um segundo . . ."

# game/characters_events_idles/maya_events.rpy:1325
translate portugues maya_scene13_morning_girlroom_df56cad2:

    # Maya "Я же сказала, делай свое дело"
    Maya "Eu te disse para fazer o seu trabalho"

# game/characters_events_idles/maya_events.rpy:1328
translate portugues maya_scene13_morning_girlroom_3fa97e8a:

    # gg "Готово"
    gg "Pronto"

# game/characters_events_idles/maya_events.rpy:1351
translate portugues maya_scene13_morning_girlroom_d5360aaa:

    # Maya "Ну как тебе такое спокойное утро?"
    Maya "O que você acha desta manhã tranquila?"

# game/characters_events_idles/maya_events.rpy:1353
translate portugues maya_scene13_morning_girlroom_337e1de0:

    # gg "Замечательно"
    gg "Maravilhoso"

# game/characters_events_idles/maya_events.rpy:1382
translate portugues maya_scene14_afternoon_myroom_72791318:

    # Sonya "Эй . . . [povname] можешь помочь с коробками?"
    Sonya "Ei . . . [povname], você pode ajudar com as caixas?"

# game/characters_events_idles/maya_events.rpy:1384
translate portugues maya_scene14_afternoon_myroom_dce97add:

    # Maya "Ой. Тебя зовут"
    Maya "Oh, estão te chamando"

# game/characters_events_idles/maya_events.rpy:1386
translate portugues maya_scene14_afternoon_myroom_650d8ae1:

    # Maya "Беги. Не заставляй даму ждать"
    Maya "Corra. Não faça a dama esperar"

# game/characters_events_idles/maya_events.rpy:1397
translate portugues maya_scene14_afternoon_myroom_134f9600:

    # Maya "Слушай . . ."
    Maya "Escute . . ."

# game/characters_events_idles/maya_events.rpy:1399
translate portugues maya_scene14_afternoon_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "Não vá"

# game/characters_events_idles/maya_events.rpy:1401
translate portugues maya_scene14_afternoon_myroom_6e0b7c57:

    # gg "Это из-за Сони?"
    gg "Isso é por causa da Sonya?"

# game/characters_events_idles/maya_events.rpy:1403
translate portugues maya_scene14_afternoon_myroom_b380699d:

    # Maya "Ты правда думаешь, что я буду это обсуждать?"
    Maya "Você realmente acha que vou discutir isso?"

# game/characters_events_idles/maya_events.rpy:1406
translate portugues maya_scene14_afternoon_myroom_0ea54924:

    # Maya "Мне не нравится, как легко ты вскакиваешь"
    Maya "Não gosto de como você se levanta tão fácil"

# game/characters_events_idles/maya_events.rpy:1408
translate portugues maya_scene14_afternoon_myroom_e1764fab:

    # Maya "Как будто меня тут нет"
    Maya "Como se eu não estivesse aqui"

# game/characters_events_idles/maya_events.rpy:1410
translate portugues maya_scene14_afternoon_myroom_1d844383:

    # Maya "Пять минут"
    Maya "Cinco minutos"

# game/characters_events_idles/maya_events.rpy:1415
translate portugues maya_scene14_afternoon_myroom_cab2c2bb:

    # Maya "Пять"
    Maya "Cinco"

# game/characters_events_idles/maya_events.rpy:1417
translate portugues maya_scene14_afternoon_myroom_b4e47535:

    # Maya "И потом делай что хочешь"
    Maya "E depois faça o que quiser"

# game/characters_events_idles/maya_events.rpy:1419
translate portugues maya_scene14_afternoon_myroom_9b6c39fb:

    # Maya "Только не думай, что это признание"
    Maya "Só não pense que isso é uma declaração"

# game/characters_events_idles/maya_events.rpy:1426
translate portugues maya_scene14_afternoon_myroom_93de4523:

    # Maya "Чeрт . . . каждый раз будто в первый"
    Maya "Droga . . . toda vez parece a primeira"

# game/characters_events_idles/maya_events.rpy:1433
translate portugues maya_scene14_afternoon_myroom_3179047f:

    # Maya "Неужели всё это . . . мне?"
    Maya "Será que tudo isso . . . é para mim?"

# game/characters_events_idles/maya_events.rpy:1439
translate portugues maya_scene14_afternoon_myroom_8135a08f:

    # Maya "Такой . . . наглый"
    Maya "Tão . . . atrevido"

# game/characters_events_idles/maya_events.rpy:1441
translate portugues maya_scene14_afternoon_myroom_b3c83659:

    # Maya "И такой тeплый . . ."
    Maya "E tão quente . . ."

# game/characters_events_idles/maya_events.rpy:1449
translate portugues maya_scene14_afternoon_myroom_6a11d281:

    # Maya "Держись . . ."
    Maya "Aguente . . ."

# game/characters_events_idles/maya_events.rpy:1455
translate portugues maya_scene14_afternoon_myroom_53e2be3e:

    # Maya ". . . Всe"
    Maya ". . . Tudo"

# game/characters_events_idles/maya_events.rpy:1459
translate portugues maya_scene14_afternoon_myroom_1f177920:

    # Maya "Моe"
    Maya "Meu"

# game/characters_events_idles/maya_events.rpy:1463
translate portugues maya_scene14_afternoon_myroom_9f7300e6:

    # Maya "Все"
    Maya "Tudo"

# game/characters_events_idles/maya_events.rpy:1465
translate portugues maya_scene14_afternoon_myroom_00c0f420:

    # Maya "Иди"
    Maya "Vá"

# game/characters_events_idles/maya_events.rpy:1467
translate portugues maya_scene14_afternoon_myroom_0efb861b:

    # gg "Ты уверена?"
    gg "Você tem certeza?"

# game/characters_events_idles/maya_events.rpy:1469
translate portugues maya_scene14_afternoon_myroom_362d3834:

    # Maya "Ага"
    Maya "Sim"

# game/characters_events_idles/maya_events.rpy:1471
translate portugues maya_scene14_afternoon_myroom_31d3f8e7:

    # Maya "Только не пропадай"
    Maya "Só não desapareça"

# game/characters_events_idles/maya_events.rpy:1473
translate portugues maya_scene14_afternoon_myroom_baa7f0c3:

    # Maya "Ты всё равно вернешься"
    Maya "Você vai voltar de qualquer forma"


