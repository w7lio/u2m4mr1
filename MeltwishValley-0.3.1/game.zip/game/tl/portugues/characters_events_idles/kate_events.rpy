﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/kate_events.rpy:8
translate portugues kate_day_myroom_66ca7b58:

    # Kate "О, живой человек"
    Kate "Ah, um ser humano vivo!"

# game/characters_events_idles/kate_events.rpy:9
translate portugues kate_day_myroom_b8813bdd:

    # Kate "Я уже начала думать, что вы тут все в спячке"
    Kate "Eu já estava começando a pensar que vocês todos estavam hibernando."

# game/characters_events_idles/kate_events.rpy:10
translate portugues kate_day_myroom_930c1443:

    # gg "Просто тихий день"
    gg "É só um dia tranquilo."

# game/characters_events_idles/kate_events.rpy:11
translate portugues kate_day_myroom_53322b78:

    # gg "Мая опять заставила ждать?"
    gg "A Maya te fez esperar de novo?"

# game/characters_events_idles/kate_events.rpy:13
translate portugues kate_day_myroom_995097d0:

    # Kate "Конечно. Я даже не удивляюсь"
    Kate "Claro. Eu nem fico surpresa."

# game/characters_events_idles/kate_events.rpy:15
translate portugues kate_day_myroom_10cad415:

    # Kate "Знаешь"
    Kate "Sabe..."

# game/characters_events_idles/kate_events.rpy:17
translate portugues kate_day_myroom_c22e07fd:

    # Kate "Я тут недавно проезжала мимо старого бассейна, который возле рощи"
    Kate "Outro dia eu passei perto daquela piscina velha, perto do bosque."

# game/characters_events_idles/kate_events.rpy:19
translate portugues kate_day_myroom_6a0c7cc1:

    # gg "Того, что сейчас с облупленной плиткой и заросшей дорожкой?"
    gg "Aquela com os azulejos descascados e a trilha cheia de mato?"

# game/characters_events_idles/kate_events.rpy:20
translate portugues kate_day_myroom_28bfe61b:

    # Kate "Ага. Ты его знаешь?"
    Kate "Isso. Você conhece?"

# game/characters_events_idles/kate_events.rpy:21
translate portugues kate_day_myroom_70967ed9:

    # gg "Осталось воспоминание"
    gg "Só uma lembrança."

# game/characters_events_idles/kate_events.rpy:22
translate portugues kate_day_myroom_f3840668:

    # gg "В детстве бабушка туда водила меня, интересно что же с ним случилось"
    gg "Minha avó me levava lá quando criança. Me pergunto o que aconteceu com aquele lugar."

# game/characters_events_idles/kate_events.rpy:24
translate portugues kate_day_myroom_7d5745ab:

    # Kate "Я случилась"
    Kate "Eu aconteci."

# game/characters_events_idles/kate_events.rpy:26
translate portugues kate_day_myroom_1c84b7f9:

    # Kate "Это был бассейн моего деда"
    Kate "Era a piscina do meu avô."

# game/characters_events_idles/kate_events.rpy:27
translate portugues kate_day_myroom_d7e25aaf:

    # Kate "Когда он умер, всё просто оставили. Я была маленькой"
    Kate "Quando ele morreu, tudo foi simplesmente abandonado. Eu era pequena."

# game/characters_events_idles/kate_events.rpy:29
translate portugues kate_day_myroom_f2aff5b8:

    # Kate "Тогда я часто туда ходила"
    Kate "Naquela época, eu ia muito lá."

# game/characters_events_idles/kate_events.rpy:30
translate portugues kate_day_myroom_678d9c75:

    # Kate "Не знаю почему . . . {w}просто сидела, слушала, как эхо по плитке гуляет"
    Kate "Não sei por quê... {w}só ficava sentada, ouvindo o eco pelos azulejos."

# game/characters_events_idles/kate_events.rpy:32
translate portugues kate_day_myroom_a3778e4f:

    # gg "Я помню, там вода была — чистая, голубая"
    gg "Eu lembro que a água era limpa, azul."

# game/characters_events_idles/kate_events.rpy:34
translate portugues kate_day_myroom_43319b98:

    # Kate "Да. А сейчас трещины пошли"
    Kate "Sim. E agora tem rachaduras."

# game/characters_events_idles/kate_events.rpy:36
translate portugues kate_day_myroom_1917ed73:

    # Kate "И трава пробилась через бетон"
    Kate "E a grama brotou pelo concreto."

# game/characters_events_idles/kate_events.rpy:37
translate portugues kate_day_myroom_3128d351:

    # Kate "Но место до сих пор . . . родное, понимаешь?"
    Kate "Mas o lugar ainda é... familiar, entende?"

# game/characters_events_idles/kate_events.rpy:39
translate portugues kate_day_myroom_fe5606ef:

    # gg "Можно было бы восстановить"
    gg "Dava para restaurar."

# game/characters_events_idles/kate_events.rpy:41
translate portugues kate_day_myroom_cd6d5961:

    # Kate "Ха, говоришь, как будто это просто"
    Kate "Hah, você fala como se fosse fácil."

# game/characters_events_idles/kate_events.rpy:42
translate portugues kate_day_myroom_5397ef5f:

    # gg "Ну . . . {w}если там не обрушено дно — это реально"
    gg "Bem... {w}se o fundo não estiver desabado, é possível."

# game/characters_events_idles/kate_events.rpy:43
translate portugues kate_day_myroom_4ad2a7d6:

    # gg " Я могу помочь, если хочешь"
    gg "Eu posso ajudar, se quiser."

# game/characters_events_idles/kate_events.rpy:45
translate portugues kate_day_myroom_2d06e21d:

    # Kate "Ты это серьёзно?"
    Kate "Você está falando sério?"

# game/characters_events_idles/kate_events.rpy:46
translate portugues kate_day_myroom_9b243b4f:

    # gg "Почему нет. Место стоящее"
    gg "Por que não? É um lugar que vale a pena."

# game/characters_events_idles/kate_events.rpy:47
translate portugues kate_day_myroom_7abebe15:

    # gg "И . . . {w} как будто жалко, что всё так осталось"
    gg "E... {w}é meio triste deixar tudo como está."

# game/characters_events_idles/kate_events.rpy:49
translate portugues kate_day_myroom_ba8f7539:

    # Kate "Подожди, подожди!"
    Kate "Espera, espera!"

# game/characters_events_idles/kate_events.rpy:50
translate portugues kate_day_myroom_1b5ecaea:

    # Kate "То есть, если я найду цемент, кисти, старый насос — ты реально поможешь это оживить?"
    Kate "Então, se eu arrumar cimento, pincéis, uma bomba velha... você realmente vai ajudar a reviver aquele lugar?"

# game/characters_events_idles/kate_events.rpy:52
translate portugues kate_day_myroom_29e07d4d:

    # gg "Похоже, я только что подписался на летний ремонт"
    gg "Parece que acabei de me inscrever para uma reforma de verão."

# game/characters_events_idles/kate_events.rpy:54
translate portugues kate_day_myroom_23062701:

    # Kate "Господи, ты не понимаешь!"
    Kate "Meu Deus, você não entende!"

# game/characters_events_idles/kate_events.rpy:55
translate portugues kate_day_myroom_0f27478e:

    # Kate "Там же можно сделать всё заново!"
    Kate "Dá para fazer tudo de novo lá!"

# game/characters_events_idles/kate_events.rpy:58
translate portugues kate_day_myroom_f8a1991c:

    # Kate "Подсветку включить, бортики покрасить . . ."
    Kate "Colocar iluminação, pintar as bordas..."

# game/characters_events_idles/kate_events.rpy:59
translate portugues kate_day_myroom_9fa28628:

    # Kate "Я даже помню, где лежала старая лестница!"
    Kate "Eu até lembro onde estava a escada velha!"

# game/characters_events_idles/kate_events.rpy:61
translate portugues kate_day_myroom_01599462:

    # Kate "Можем даже вывеску повесить — “Бассейн №1 Возрождён при участии безумцев”!"
    Kate "Podemos até pendurar uma placa: 'Piscina Nº1 - Renascida com a ajuda de uns malucos'!"

# game/characters_events_idles/kate_events.rpy:63
translate portugues kate_day_myroom_65417f70:

    # gg "Безумцев?"
    gg "Malucos?"

# game/characters_events_idles/kate_events.rpy:65
translate portugues kate_day_myroom_37a114e4:

    # Kate "Ну, а кто ещё решит копаться в полузаброшенном дворе ради детской мечты?"
    Kate "Bom, quem mais decidiria mexer num quintal semiabandonado por causa de um sonho de criança?"

# game/characters_events_idles/kate_events.rpy:68
translate portugues kate_day_myroom_fb47222b:

    # Kate "Если получится . . . я, наверное, наконец перестану чувствовать, что всё хорошее осталось “там”, в прошлом"
    Kate "Se der certo... acho que finalmente vou parar de sentir que tudo de bom ficou 'lá', no passado."

# game/characters_events_idles/kate_events.rpy:69
translate portugues kate_day_myroom_9e4c9fbd:

    # gg "Значит, начнём с настоящего"
    gg "Então, vamos começar pelo presente."

# game/characters_events_idles/kate_events.rpy:71
translate portugues kate_day_myroom_2d334a18:

    # Kate "Серьёзно!?"
    Kate "Sério!?"

# game/characters_events_idles/kate_events.rpy:72
translate portugues kate_day_myroom_756e6836:

    # Kate "Спасибо. Ты первый, кто не сказал “забей”"
    Kate "Obrigada. Você é o primeiro que não falou 'esquece'."

# game/characters_events_idles/kate_events.rpy:73
translate portugues kate_day_myroom_651bc331:

    # gg "Я не умею “забивать”"
    gg "Eu não sei 'esquecer'."

# game/characters_events_idles/kate_events.rpy:79
translate portugues kate_day_myroom_7ace6d42:

    # Maya "Кейт! Я готова!"
    Maya "Kate! Estou pronta!"

# game/characters_events_idles/kate_events.rpy:81
translate portugues kate_day_myroom_d05a36ed:

    # Kate "Опять вовремя"
    Kate "Na hora certa, de novo."

# game/characters_events_idles/kate_events.rpy:83
translate portugues kate_day_myroom_be210218:

    # Kate "Тогда Увидимся у бассейна [povname], строитель мечтаний"
    Kate "Então, te vejo na piscina, [povname], construtor de sonhos."

