﻿# TODO: Translation updated at 2026-01-26 03:23

# game/locations/main_house/bathroom.rpy:19
translate portugues bathroom_8df379f4:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Маей"
    gg "Acho que ainda não conheço bem a Maya"

# game/locations/main_house/bathroom.rpy:25
translate portugues bathroom_675eb9d2:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Соней"
    gg "Acho que ainda não conheço bem a Sonia"

