﻿# TODO: Translation updated at 2026-01-21 02:05

# game/locations/main_house/kitchen.rpy:24
translate portugues kitchen_e44eab80:

    # "Привет, перед началом игры давай быстро разберемся с управлением"
    "Oi, antes de começar o jogo, vamos rapidinho entender os controles"

# game/locations/main_house/kitchen.rpy:25
translate portugues kitchen_e9ff8856:

    # "Что бы перейти в другую комнату тебе нужно навестись мышкой в правую часть экрана"
    "Para ir para outra sala, você precisa mover o mouse para a direita da tela"

# game/locations/main_house/kitchen.rpy:28
translate portugues kitchen_22e95808:

    # "После выбери комнату в которую хочешь попасть"
    "Depois, escolha a sala para a qual quer ir"

# game/locations/main_house/kitchen.rpy:29
translate portugues kitchen_c3e67100:

    # "На иконках комнат будут отображены девушки которые сейчас там находятся"
    "Nos ícones das salas serão mostradas as garotas que estão lá no momento"

# game/locations/main_house/kitchen.rpy:30
translate portugues kitchen_ffc31834:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой ключевое действие"
    "Uma {color=#fffb27ff}estrelinha{/color} aparecerá ao lado do ícone se houver uma ação importante com a garota"

# game/locations/main_house/kitchen.rpy:31
translate portugues kitchen_4c3bfaea:

    # "Попробуйте перейти в комнату Маи"
    "Tente ir para o quarto da Maya"

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/kitchen.rpy:30
translate portugues kitchen_b2963125:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой доступно ключевое действие"
    "Uma {color=#fffb27ff}estrelinha{/color} aparecerá ao lado do ícone se houver uma ação importante com a garota"

# game/locations/main_house/kitchen.rpy:31
translate portugues kitchen_b1f7eb9e:

    # "Попробуй перейти в комнату Маи"
    "Tente ir para o quarto da Maya"

