﻿# TODO: Translation updated at 2026-01-21 02:05

# game/locations/main_house/myroom.rpy:22
translate portugues myroom_c1835e38:

    # "Что бы лечь спать нажмите ночью на кровать"
    "Para ir dormir, clique na cama durante a noite"

# game/locations/main_house/myroom.rpy:27
translate portugues myroom_71fb3107:

    # "Теперь вы можете управлять временем суток"
    "Agora você pode controlar a hora do dia"

# game/locations/main_house/myroom.rpy:28
translate portugues myroom_a6aee4e7:

    # "Нажмите на значок в правом верхнем углу, чтобы сменить время"
    "Clique no ícone no canto superior direito para mudar a hora"

# game/locations/main_house/myroom.rpy:30
translate portugues myroom_2f1c23a7:

    # "В левом нижнем углу отображаются текущее время суток, день недели и счётчик дней"
    "No canto inferior esquerdo são mostrados a hora atual do dia, o dia da semana e o contador de dias"

# game/locations/main_house/myroom.rpy:33
translate portugues myroom_b9554520:

    # "Также вам доступна книга персонажей"
    "Além disso, você tem acesso ao livro de personagens"

# game/locations/main_house/myroom.rpy:36
translate portugues myroom_f5a7354e:

    # "В ней вы можете посмотреть описание каждой девушки и текущий уровень отношений"
    "Nele você pode ver a descrição de cada garota e o nível atual de relacionamento"

# game/locations/main_house/myroom.rpy:37
translate portugues myroom_b927df5c:

    # "Здесь же доступны подсказки к следующему событию и возможность закрепить активный квест"
    "Aqui também estão disponíveis dicas para o próximo evento e a opção de fixar a missão ativa"

# TODO: Translation updated at 2026-01-26 03:23

# game/locations/main_house/myroom.rpy:27
translate portugues myroom_71fb3107:

    # "Теперь вы можете управлять временем суток"
    "Agora você pode controlar a hora do dia"

# game/locations/main_house/myroom.rpy:28
translate portugues myroom_a6aee4e7:

    # "Нажмите на значок в правом верхнем углу, чтобы сменить время"
    "Clique no ícone no canto superior direito para mudar a hora"

# game/locations/main_house/myroom.rpy:33
translate portugues myroom_b9554520:

    # "Также вам доступна книга персонажей"
    "Além disso, você tem acesso ao livro de personagens"

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/myroom.rpy:27
translate portugues myroom_ac4e4f25:

    # "Теперь ты можешь управлять временем суток"
    ""

# game/locations/main_house/myroom.rpy:28
translate portugues myroom_6784fea3:

    # "Нажми на значок в правом верхнем углу, чтобы сменить время"
    ""

# game/locations/main_house/myroom.rpy:33
translate portugues myroom_b3480ee4:

    # "Также тебе доступна книга персонажей"
    ""

# game/locations/main_house/myroom.rpy:36
translate portugues myroom_030a80cc:

    # "В ней ты можешь посмотреть описание каждой девушки и текущий уровень отношений"
    ""

