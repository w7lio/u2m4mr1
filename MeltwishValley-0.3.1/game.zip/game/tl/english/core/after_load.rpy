﻿# TODO: Translation updated at 2026-01-21 02:04

translate english strings:

    # game/core/after_load.rpy:9
    old "Спокойный и наблюдательный, он приехал в посёлок, чтобы сбежать от прошлого и найти себя заново. Не всегда уверен, но с каждым новым знакомством делает шаг ближе к тому, кем хочет стать"
    new "Điềm tĩnh và quan sát, anh đến thị trấn nhỏ để trốn khỏi quá khứ và tìm lại chính mình. Không phải lúc nào cũng tự tin, nhưng với mỗi mối quen biết mới, anh tiến gần hơn một bước tới con người mà anh muốn trở thành"

    # game/core/after_load.rpy:9
    old "Союзник"
    new "Đồng minh"

    # game/core/after_load.rpy:9
    old "Вс."
    new "CN."

    # game/core/after_load.rpy:9
    old "Кухня"
    new "Bếp"

    # game/core/after_load.rpy:9
    old "Утро Кухня"
    new "Buổi sáng Bếp"

    # game/core/after_load.rpy:9
    old "Ждем тебя в следующем патче"
    new "Chờ bạn ở bản vá tiếp theo"

    # game/core/after_load.rpy:9
    old "Вы прошли все сюжетные события этого персонажа в текущем патче"
    new "Bạn đã hoàn thành tất cả sự kiện cốt truyện của nhân vật này trong bản vá hiện tại"

    # game/core/after_load.rpy:9
    old "Мая"
    new "Maya"

    # game/core/after_load.rpy:9
    old "Дерзкая, ироничная и ленивая, кажется отстранённой, но чувствует глубже, чем показывает. Скрывает мягкость за сарказмом, пока не решит открыть себя по-настоящему. Не терпит слабости — особенно в себе"
    new "Ngổ ngáo, mỉa mai và lười biếng, cô có vẻ xa cách, nhưng cảm nhận sâu sắc hơn những gì cô thể hiện. Cô giấu sự dịu dàng sau vẻ châm biếm, cho đến khi quyết định thật sự mở lòng. Cô không chịu đựng được sự yếu đuối — đặc biệt là ở chính mình"

    # game/core/after_load.rpy:9
    old "Вт."
    new "Th 3."

    # game/core/after_load.rpy:9
    old "Ср."
    new "Th 4."

    # game/core/after_load.rpy:9
    old "Вечер"
    new "Buổi tối"

    # game/core/after_load.rpy:9
    old "Зал"
    new "Phòng khách"

    # game/core/after_load.rpy:9
    old "Вечер Зал"
    new "Buổi tối Phòng khách"

    # game/core/after_load.rpy:9
    old "Пт."
    new "Th 6."

    # game/core/after_load.rpy:9
    old "Сб."
    new "Th 7."

    # game/core/after_load.rpy:9
    old "День"
    new "Ban ngày"

    # game/core/after_load.rpy:9
    old "Ее комната"
    new "Phòng của cô ấy"

    # game/core/after_load.rpy:9
    old "День Ее комната"
    new "Ban ngày Phòng của cô ấy"

    # game/core/after_load.rpy:9
    old "Пн."
    new "Th 2."

    # game/core/after_load.rpy:9
    old "Чт."
    new "Th 5."

    # game/core/after_load.rpy:9
    old "Вечер кухня"
    new "Buổi tối bếp"

    # game/core/after_load.rpy:9
    old "День ее комната"
    new "Ban ngày phòng của cô ấy"

    # game/core/after_load.rpy:9
    old "Ночь"
    new "Ban đêm"

    # game/core/after_load.rpy:9
    old "Ночь ее комната"
    new "Ban đêm phòng của cô ấy"

    # game/core/after_load.rpy:9
    old "Вечер зал"
    new "Buổi tối phòng khách"

    # game/core/after_load.rpy:9
    old "Утро ее комната"
    new "Buổi sáng phòng của cô ấy"

    # game/core/after_load.rpy:9
    old "День кухня"
    new "Ban ngày bếp"

    # game/core/after_load.rpy:9
    old "Ванная"
    new "Phòng tắm"

    # game/core/after_load.rpy:9
    old "Утро ванная"
    new "Buổi sáng phòng tắm"

    # game/core/after_load.rpy:9
    old "Соня"
    new "Sonya"

    # game/core/after_load.rpy:9
    old "Тёплая и заботливая, но собранная и точная, как часы. Любит музыку, игры и порядок, иногда стесняется — но именно она делает шаг первой"
    new "Ấm áp và chu đáo, nhưng chỉn chu và chính xác như đồng hồ. Cô thích âm nhạc, trò chơi và sự ngăn nắp, đôi khi ngại ngùng — nhưng chính cô là người chủ động bước tới trước"

    # game/core/after_load.rpy:9
    old "День Ванная"
    new "Ban ngày Phòng tắm"

    # game/core/after_load.rpy:9
    old "Утро Ванная"
    new "Buổi sáng Phòng tắm"

    # game/core/after_load.rpy:9
    old "Стоит подождать"
    new "Nên đợi đã"

    # game/core/after_load.rpy:9
    old "Думаю стоит подождать"
    new "Tôi nghĩ nên đợi đã"

    # game/core/after_load.rpy:9
    old "Вечер Ее комната"
    new "Buổi tối Phòng của cô ấy"

    # game/core/after_load.rpy:9
    old "Кейт"
    new "Kate"

    # game/core/after_load.rpy:9
    old "Яркая и энергичная, Кейт не умеет сидеть на месте — она живёт движением и смехом. Кажется лёгкой и беззаботной, но за её улыбкой прячется страх остаться одной"
    new "Rực rỡ và tràn đầy năng lượng, Kate không thể ngồi yên — cô sống bằng chuyển động và tiếng cười. Cô có vẻ nhẹ nhàng và vô tư, nhưng đằng sau nụ cười ấy là nỗi sợ bị bỏ lại một mình"

    # game/core/after_load.rpy:9
    old "Утро Зал"
    new "Buổi sáng Phòng khách"

# TODO: Translation updated at 2026-01-26 03:21




# TODO: Translation updated at 2026-01-27 02:10

# game/core/after_load.rpy:4
translate english after_load_75a05417:

    # "Привет. Игра претерпела большие изменения, получила новое интро и сцены"
    "Xin chào. Trò chơi đã trải qua nhiều thay đổi lớn, có đoạn mở đầu và các cảnh mới"

# game/core/after_load.rpy:5
translate english after_load_92feb703:

    # "Старые сейвы работать не будут(("
    "Các bản lưu cũ sẽ không hoạt động được(("


# game/core/after_load.rpy:6
translate english after_load_c7ff0b32:

    # "Пожалуйста, начните игру заново"
    "Vui lòng bắt đầu trò chơi lại từ đầu"

# TODO: Translation updated at 2026-01-27 22:55

translate english strings:

    # game/core/after_load.rpy:13
    old "День Зал"
    new "Ban ngày Phòng khách"

