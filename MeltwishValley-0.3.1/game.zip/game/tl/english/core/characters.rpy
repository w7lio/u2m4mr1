﻿# TODO: Translation updated at 2026-01-21 02:04

translate english strings:

    # game/core/characters.rpy:28
    old "Почтальон"
    new "Người đưa thư"

    # game/core/characters.rpy:32
    old "Секретарь"
    new "Thư ký"

    # game/core/characters.rpy:36
    old "Директор"
    new "Giám đốc"

    # game/core/characters.rpy:40
    old "Незнакомая девушка"
    new "Cô gái xa lạ"

# TODO: Translation updated at 2026-01-26 03:21

translate english strings:

    # game/core/characters.rpy:40
    old "Незнакомка"
    new "Người phụ nữ xa lạ"

