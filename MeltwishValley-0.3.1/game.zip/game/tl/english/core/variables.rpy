﻿# TODO: Translation updated at 2026-01-21 02:04

translate english strings:

    # game/core/variables.rpy:88
    old "Понедельник"
    new "Thứ Hai"

    # game/core/variables.rpy:88
    old "Вторник"
    new "Thứ Ba"

    # game/core/variables.rpy:88
    old "Среда"
    new "Thứ Tư"

    # game/core/variables.rpy:88
    old "Четверг"
    new "Thứ Năm"

    # game/core/variables.rpy:88
    old "Пятница"
    new "Thứ Sáu"

    # game/core/variables.rpy:88
    old "Суббота"
    new "Thứ Bảy"

    # game/core/variables.rpy:88
    old "Воскресенье"
    new "Chủ Nhật"

    # game/core/variables.rpy:121
    old "Моя комната"
    new "Phòng của tôi"

# TODO: Translation updated at 2026-02-13 11:40

translate english strings:

    # game/core/variables.rpy:422
    old "Ночь Зал"
    new "Sảnh ban đêm"

# TODO: Translation updated at 2026-02-16 03:29

translate english strings:

    # game/core/variables.rpy:427
    old "Комната Сони"
    new "Phòng của Sonya"

    # game/core/variables.rpy:427
    old "Утро комната Сони"
    new "Phòng của Sonya buổi sáng"

    # game/core/variables.rpy:427
    old "День зал"
    new "Sảnh ban ngày"

