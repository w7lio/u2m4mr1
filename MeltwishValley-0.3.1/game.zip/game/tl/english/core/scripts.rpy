﻿# TODO: Translation updated at 2026-01-21 02:04

# game/core/scripts.rpy:52
translate english next_time_button_9cf59ffc:

    # "Пора спать"
    "Đến giờ đi ngủ rồi"

# game/core/scripts.rpy:97
translate english sleep_until_morning_caa36b56:

    # "Думаю еще не время ложиться спать"
    "Tôi nghĩ vẫn chưa đến lúc đi ngủ"

