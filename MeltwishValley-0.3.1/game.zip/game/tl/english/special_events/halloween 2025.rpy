﻿# TODO: Translation updated at 2026-01-21 02:04

# game/special_events/halloween 2025.rpy:30
translate english halloween_prestart_6dc15a83:

    # gg "Хм . . ."
    gg "Hừm . . ."

# game/special_events/halloween 2025.rpy:31
translate english halloween_prestart_3173d374:

    # gg "А что это еще такое?"
    gg "Còn đây là thứ gì nữa？"

# game/special_events/halloween 2025.rpy:32
translate english halloween_prestart_9d6bd7cd:

    # gg "Эта тыква будто манит меня дотронуться до нее"
    gg "Quả bí này cứ như đang dụ tôi chạm vào nó"

# game/special_events/halloween 2025.rpy:34
translate english halloween_prestart_6b235c12:

    # gg "Вроде ничего не случилось"
    gg "Hình như chẳng có gì xảy ra"

# game/special_events/halloween 2025.rpy:35
translate english halloween_prestart_99b702cc:

    # gg "Просто обычная тыква"
    gg "Chỉ là một quả bí bình thường"

# game/special_events/halloween 2025.rpy:36
translate english halloween_prestart_882ef6af:

    # gg "Так не интересно"
    gg "Chán thật"

# game/special_events/halloween 2025.rpy:40
translate english halloween_prestart_2eb26325:

    # gg "Ай!" with hpunch
    gg "Ái!" with hpunch

# game/special_events/halloween 2025.rpy:41
translate english halloween_prestart_b858f49b:

    # gg "Почему так щипет"
    gg "Sao lại châm chích thế này"

# game/special_events/halloween 2025.rpy:42
translate english halloween_prestart_eb8d9b68:

    # gg "Что то мне не хорошо"
    gg "Tôi thấy hơi không ổn"

# game/special_events/halloween 2025.rpy:43
translate english halloween_prestart_462beaf3:

    # gg "Пойду отдохну"
    gg "Tôi đi nghỉ chút đây"

# game/special_events/halloween 2025.rpy:55
translate english halloween_start_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/special_events/halloween 2025.rpy:57
translate english halloween_start_2768572c:

    # Sonya "Знаешь, что я поняла?"
    Sonya "Cậu biết tớ vừa nhận ra gì không？"

# game/special_events/halloween 2025.rpy:58
translate english halloween_start_b99b94d3:

    # gg "Что пора поспать?"
    gg "Đến giờ ngủ rồi à？"

# game/special_events/halloween 2025.rpy:60
translate english halloween_start_73751dc8:

    # Sonya "Что пора украшать дом"
    Sonya "Rằng đã đến lúc trang trí nhà cửa"

# game/special_events/halloween 2025.rpy:62
translate english halloween_start_2efbd354:

    # gg "Украшать?"
    gg "Trang trí？"

# game/special_events/halloween 2025.rpy:64
translate english halloween_start_baa9dc02:

    # Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    Sonya "Hai ngày nữa là Halloween rồi, mà chẳng có chút không khí nào"

# game/special_events/halloween 2025.rpy:66
translate english halloween_start_d64dca0a:

    # Sonya "Я хочу, чтобы всё выглядело"
    Sonya "Tớ muốn mọi thứ trông"

# game/special_events/halloween 2025.rpy:68
translate english halloween_start_c1524153:

    # Sonya "Хотя бы немного празднично"
    Sonya "Ít nhất cũng có chút không khí lễ hội"

# game/special_events/halloween 2025.rpy:70
translate english halloween_start_c4c69fc7:

    # Maya "Украшать?{w} Пора бы да"
    Maya "Trang trí？{w} Đúng là đến lúc rồi"

# game/special_events/halloween 2025.rpy:72
translate english halloween_start_f5a85bf6:

    # Maya "Можно повесить гирлянды и поставить свечи!"
    Maya "Có thể treo dây đèn và đặt nến!"

# game/special_events/halloween 2025.rpy:74
translate english halloween_start_88ab11a7:

    # Sonya "Вот. Поддержка есть"
    Sonya "Đó. Có người ủng hộ rồi"

# game/special_events/halloween 2025.rpy:76
translate english halloween_start_f2b19d78:

    # gg "Видимо у меня нет выбора"
    gg "Có vẻ tôi không có lựa chọn"

# game/special_events/halloween 2025.rpy:78
translate english halloween_start_bc7a61df:

    # Maya "Ты просто устал, тебе нужно отвлечься"
    Maya "Cậu chỉ là mệt thôi, cần làm gì đó khuây khỏa"

# game/special_events/halloween 2025.rpy:80
translate english halloween_start_06d0d58b:

    # Sonya "Вот именно"
    Sonya "Chuẩn luôn"

# game/special_events/halloween 2025.rpy:82
translate english halloween_start_041234b8:

    # Sonya "Украшение дома - лучший антистресс"
    Sonya "Trang trí nhà cửa là cách chống căng thẳng tốt nhất"

# game/special_events/halloween 2025.rpy:84
translate english halloween_start_c578bb24:

    # Maya "Тогда решено"
    Maya "Vậy quyết định thế nhé"

# game/special_events/halloween 2025.rpy:85
translate english halloween_start_6e15e900:

    # Maya "Начнём с гостиной"
    Maya "Bắt đầu từ phòng khách"

# game/special_events/halloween 2025.rpy:87
translate english halloween_start_d298f1fa:

    # Maya "Я за уют, но без перебора"
    Maya "Tớ thích ấm cúng, nhưng đừng quá đà"

# game/special_events/halloween 2025.rpy:89
translate english halloween_start_2a522c28:

    # Sonya "Надо позвать Кейт"
    Sonya "Phải gọi Kate nữa"

# game/special_events/halloween 2025.rpy:90
translate english halloween_start_20197ce8:

    # Sonya "Без неё всё равно не обойдётся"
    Sonya "Dù sao cũng không thể thiếu cô ấy"

# game/special_events/halloween 2025.rpy:92
translate english halloween_start_bcecc811:

    # Maya "Я напишу ей"
    Maya "Tớ sẽ nhắn cho cô ấy"

# game/special_events/halloween 2025.rpy:93
translate english halloween_start_81baf5ad:

    # Maya "Если не занята, придёт"
    Maya "Nếu không bận thì cô ấy sẽ đến"

# game/special_events/halloween 2025.rpy:95
translate english halloween_start_4a4b3e1e:

    # Sonya "Пойдем поможешь мне"
    Sonya "Đi giúp tớ một tay"

# game/special_events/halloween 2025.rpy:97
translate english halloween_start_082fbdc3:

    # Sonya "У нас в кладовке чего только нету"
    Sonya "Trong kho nhà mình thiếu gì đâu"

# game/special_events/halloween 2025.rpy:99
translate english halloween_start_569f8605:

    # Sonya "Осторожно, она тяжёлая"
    Sonya "Cẩn thận, nó nặng đấy"

# game/halloween.rpy:103
translate english halloween_start_08a41431:

    # gg "Не волнуйся, я пока справляюсь"
    gg "Đừng lo, tạm thời tôi vẫn xoay được"

# game/halloween.rpy:105
translate english halloween_start_2ee9b67e:

    # Maya "Написала, сказала, что уже бежит"
    Maya "Tớ nhắn rồi, cô ấy bảo đang chạy tới"

# game/halloween.rpy:107
translate english halloween_start_56e25c3d:

    # Sonya "Это хорошо"
    Sonya "Tốt quá"

# game/halloween.rpy:109
translate english halloween_start_cc205380:

    # Maya "О, смотри, старая паутина!"
    Maya "Ồ, nhìn kìa, mạng nhện cũ!"

# game/halloween.rpy:111
translate english halloween_start_6d122aa8:

    # Sonya "Это не декор, не трогай!"
    Sonya "Đó không phải đồ trang trí, đừng chạm vào!"

# game/halloween.rpy:113
translate english halloween_start_1c832081:

    # Maya "Ты же знаешь я боюсь пауков!"
    Maya "Cậu biết tớ sợ nhện mà!"

# game/halloween.rpy:114
translate english halloween_start_e8c9fd97:

    # gg "Ха ха"
    gg "Ha ha"

# game/halloween.rpy:119
translate english halloween_start_5c8cb7fa:

    # Kate "Я пришла"
    Kate "Tớ tới rồi"

# game/halloween.rpy:120
translate english halloween_start_5cba982d:

    # Kate "Где вы, мои маленькие смертные?"
    Kate "Các ngươi đâu rồi, những kẻ phàm trần bé nhỏ của ta？"

# game/halloween.rpy:121
translate english halloween_start_66671892:

    # Maya "Привет!"
    Maya "Chào!"

# game/halloween.rpy:123
translate english halloween_start_41cac97b:

    # Kate "О, вы уже начали без меня?{w} Это предательство"
    Kate "Ồ, các ngươi đã bắt đầu mà không có ta à？{w} Thật là phản bội"

# game/halloween.rpy:125
translate english halloween_start_3f833e29:

    # Maya "Мы только подготовились"
    Maya "Bọn tớ mới chỉ chuẩn bị thôi"

# game/halloween.rpy:127
translate english halloween_start_10a24600:

    # Sonya "Отлично, теперь можем начинать по-настоящему"
    Sonya "Tuyệt, giờ có thể bắt đầu thật sự rồi"

# game/halloween.rpy:129
translate english halloween_start_59716300:

    # Maya "Всё, распределяем задачи?"
    Maya "Được rồi, chia việc nhé？"

# game/halloween.rpy:131
translate english halloween_start_c6287aa3:

    # Kate "Так эту куклу повесим вон там, над теликом"
    Kate "Vậy treo con búp bê này ở kia, phía trên TV"

# game/halloween.rpy:132
translate english halloween_start_ddd8aded:

    # Kate "Еще нужны паутины, гирлянда из флажков, черепа . . "
    Kate "Còn cần mạng nhện, dây cờ, đầu lâu . . "

# game/halloween.rpy:134
translate english halloween_start_c1c2f306:

    # Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    Maya "Vậy trong phòng tớ sẽ không cần đồ trang trí đáng sợ nhé？"

# game/halloween.rpy:136
translate english halloween_start_344d78c3:

    # gg "Ну это же Хэллоуин, а чем ты?"
    gg "Nhưng mà đây là Halloween, còn cậu thì sao？"

# game/special_events/halloween 2025.rpy:138
translate english halloween_start_7e9f8506:

    # Sonya "Мая просто трусишка"
    Sonya "Maya chỉ là đồ nhát gan thôi"

# game/halloween.rpy:140
translate english halloween_start_423eeb13:

    # Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "NÀY!! Tớ chỉ thấy thế là ngớ ngẩn thôi!"

# game/halloween.rpy:141
translate english halloween_start_1c4935b1:

    # Maya "Можно сделать дом тёплым, как осень!"
    Maya "Có thể làm ngôi nhà ấm áp như mùa thu!"

# game/halloween.rpy:142
translate english halloween_start_5acb8aac:

    # Maya "Листья и природу . . . И без жути . . "
    Maya "Lá cây và thiên nhiên . . . Và không có gì đáng sợ . . "

# game/halloween.rpy:144
translate english halloween_start_9d95e4f7:

    # Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    Kate "Còn tớ muốn nó đáng sợ đúúúng kiểu, đến mức bọn trẻ hàng xóm sẽ hét lên vì sợ nếu dám gõ cửa nhà mình"

# game/halloween.rpy:146
translate english halloween_start_97fa9b09:

    # Sonya "Звучит как цель"
    Sonya "Nghe như một mục tiêu đấy"

# game/halloween.rpy:148
translate english halloween_start_7a0152d7:

    # Maya "Надеюсь, что все пройдет без происшествий"
    Maya "Tớ hy vọng mọi chuyện sẽ diễn ra suôn sẻ"

# game/halloween.rpy:150
translate english halloween_start_cd410fe4:

    # gg "Ну что же, давайте постараемся"
    gg "Thôi được, cùng cố gắng nào"

# game/halloween.rpy:158
translate english halloween_start_e7148dd7:

    # Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    Maya "Mà các cậu biết không, không tệ chút nào, thậm chí còn rất dễ thương và ấm cúng"

# game/halloween.rpy:160
translate english halloween_start_4203fcb3:

    # Kate "ДА! Вышло супер, мы такие молодцы"
    Kate "ĐÚNG VẬY! Tuyệt lắm, bọn mình giỏi thật"

# game/halloween.rpy:162
translate english halloween_start_3c177eb8:

    # Sonya "Давайте дальше украсим кухню!"
    Sonya "Giờ trang trí tiếp nhà bếp nào!"

# game/halloween.rpy:163
translate english halloween_start_3fc97c96:

    # Sonya "[povname] хватай коробки с украшениями!"
    Sonya "[povname] ôm mấy hộp đồ trang trí đi!"

# game/halloween.rpy:172
translate english halloween_start_c18a0daf:

    # Maya "Ну почему я должна ее вешать?"
    Maya "Sao tớ lại phải treo nó chứ？"

# game/halloween.rpy:174
translate english halloween_start_538416e3:

    # Kate "Потому что ты самая высокая, это же логично!"
    Kate "Vì cậu cao nhất, hợp lý mà!"

# game/halloween.rpy:176
translate english halloween_start_fac78089:

    # Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    Maya "Eo ôi. Tớ không sợ nhện, chỉ là chúng ghê quá, tớ thấy tởm"

# game/halloween.rpy:178
translate english halloween_start_196b4d6a:

    # gg "Тыкву тоже поставь на полку"
    gg "Đặt quả bí lên kệ luôn đi"

# game/halloween.rpy:187
translate english halloween_start_3ee05b57:

    # Maya "АААААААААА!" with hpunch
    Maya "AAAAAAA!" with hpunch

# game/halloween.rpy:191
translate english halloween_start_7410244b:

    # gg "Все, я убрал, не бойся, он же не настоящий"
    gg "Rồi, tôi dẹp nó rồi, đừng sợ, nó có phải thật đâu"

# game/halloween.rpy:193
translate english halloween_start_1ceba70d:

    # Maya "Спасибо"
    Maya "Cảm ơn"

# game/halloween.rpy:195
translate english halloween_start_5375f0ad:

    # gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    gg "Cậu ngã vào lòng tôi hơi nhiều đấy, không phải cố ý đấy chứ？"

# game/halloween.rpy:197
translate english halloween_start_ccd7999c:

    # Maya "Еще чего!"
    Maya "Mơ đi!"

# game/halloween.rpy:198
translate english halloween_start_c938832e:

    # Maya "Ты просто мешаешься на пути, вот и все!"
    Maya "Cậu chỉ vướng đường thôi, thế thôi!"

# game/halloween.rpy:199
translate english halloween_start_5807bf69:

    # Kate "Не поранились? Голубки"
    Kate "Có ai bị thương không？ Các cưng"

# game/halloween.rpy:201
translate english halloween_start_180bf5f1:

    # Maya "Все с паутиной мы закончили"
    Maya "Xong phần mạng nhện rồi"

# game/halloween.rpy:202
translate english halloween_start_62eaed17:

    # Maya "Пойду возьму яблочного сидра"
    Maya "Tớ đi lấy rượu táo"

# game/halloween.rpy:208
translate english halloween_start_6a9d122d:

    # Sonya "Еще 5 минут и кексы готовы"
    Sonya "Còn 5 phút nữa là bánh cupcake xong"

# game/halloween.rpy:210
translate english halloween_start_92462f90:

    # Kate "Пахнет потрясающе"
    Kate "Mùi thơm tuyệt vời"

# game/halloween.rpy:212
translate english halloween_start_ada25b4b:

    # Maya "Всё, теперь осталось только подождать"
    Maya "Xong, giờ chỉ cần chờ thôi"

# game/halloween.rpy:213
translate english halloween_start_4ac68531:

    # Maya "Потом будем украшать"
    Maya "Sau đó sẽ trang trí"

# game/halloween.rpy:215
translate english halloween_start_7d203e0d:

    # Kate "Эй а кем вы будете в ночь Хэллоуина?"
    Kate "Này, các cậu sẽ hóa trang thành ai trong đêm Halloween？"

# game/halloween.rpy:217
translate english halloween_start_3e0fd7f3:

    # Sonya "Я уже думала об этом!"
    Sonya "Tớ nghĩ về chuyện đó rồi!"

# game/halloween.rpy:218
translate english halloween_start_21be6b25:

    # Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    Sonya "Mm, Kate, bộ đồ nữ quỷ sẽ hợp với cậu đấy"

# game/halloween.rpy:220
translate english halloween_start_8fc9e335:

    # Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    Maya "Đúng đấy, dù trông như thiên thần nhưng cậu ranh ma như con yêu tinh nhà ấy"

# game/halloween.rpy:222
translate english halloween_start_6485ec70:

    # Kate "Эй!! Неплохая идея"
    Kate "Này!! Ý hay đấy"

# game/halloween.rpy:226
translate english halloween_start_9ea771a0:

    # Kate "Королева демонов Уахахахаха!"
    Kate "Nữ hoàng quỷ dữ Uahahahaha!"

# game/halloween.rpy:227
translate english halloween_start_dfa5392d:

    # Kate "Все должны пасть к моим ногам!"
    Kate "Tất cả phải quỳ dưới chân ta!"

# game/halloween.rpy:229
translate english halloween_start_d1a70744:

    # Sonya "Все, ей больше не наливать!"
    Sonya "Thôi, đừng rót cho cô ấy nữa!"

# game/halloween.rpy:231
translate english halloween_start_67a78ead:

    # gg "Не знал что Кейт так быстро выносит с алкоголя"
    gg "Không ngờ Kate say nhanh thế"

# game/halloween.rpy:233
translate english halloween_start_89e99062:

    # Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    Maya "Tớ muốn bộ đồ phù thủy nhỏ hoặc kiểu nữ thần cây phép thuật nào đó . . ."

# game/halloween.rpy:235
translate english halloween_start_ccfee06e:

    # Kate "Думаю тебе пойдет"
    Kate "Tớ nghĩ sẽ hợp với cậu"

# game/halloween.rpy:237
translate english halloween_start_8e96eaa2:

    # Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    Sonya "Còn tớ mới đặt hàng mấy hôm trước, thay vì 1 gói băng thì thành 6 gói, có vẻ là dấu hiệu để làm đồ xác ướp nhỉ？"

# game/halloween.rpy:239
translate english halloween_start_2aa5e0fb:

    # Maya "Ты как раз самая старшая"
    Maya "Cậu đúng là lớn tuổi nhất mà"

# game/halloween.rpy:241
translate english halloween_start_38bc2712:

    # Sonya "Ах ты!"
    Sonya "Cái cậu này!"

# game/halloween.rpy:243
translate english halloween_start_5d38e441:

    # Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "Khoan, còn Barsik thì sao？ Nó cũng cần đồ hóa trang!"

# game/halloween.rpy:244
translate english halloween_start_fb608953:

    # Maya "Например дракончика или мистер тыковка . . ."
    Maya "Ví dụ như rồng con hay ông Bí Ngô . . ."

# game/halloween.rpy:246
translate english halloween_start_7fd69d94:

    # Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    Sonya "Thử bắt và mặc đồ cho nó xem, ông Barsik sẽ không để yên đâu!"

# game/halloween.rpy:248
translate english halloween_start_70adb582:

    # Maya "Что ты . . . {w}Он любит переодевашки"
    Maya "Cậu nói gì thế . . . {w}Nó thích được thay đồ mà"

# game/halloween.rpy:251
translate english halloween_start_c0036cba:

    # Sonya "Вот и кексы готовы"
    Sonya "Bánh cupcake xong rồi đây"

# game/halloween.rpy:253
translate english halloween_start_ae45c746:

    # gg "С кухней готово, что дальше?"
    gg "Nhà bếp xong rồi, tiếp theo là gì？"

# game/halloween.rpy:254
translate english halloween_start_354f0704:

    # Sonya "Предлагаю разделиться"
    Sonya "Tớ đề nghị chia nhau ra"

# game/halloween.rpy:255
translate english halloween_start_07a07420:

    # Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "Tớ với Maya sẽ trang trí phòng bọn tớ, Kate, cậu trang trí phòng tắm nhé"

# game/halloween.rpy:256
translate english halloween_start_4e86ac78:

    # Sonya "[povname], будешь помогать нам?"
    Sonya "[povname], cậu sẽ giúp bọn tớ chứ？"

# game/special_events/halloween 2025.rpy:257
translate english halloween_start_564e6225:

    # gg "Окей"
    gg "Được"

# game/halloween.rpy:271
translate english halloween_prepare_mayaroom_7afc2c47:

    # gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "Phòng cậu đúng là hang ổ của phù thủy nấu thuốc từ thảo mộc"

# game/halloween.rpy:272
translate english halloween_prepare_mayaroom_b0cc7780:

    # gg "Мм пахнет приятно"
    gg "Mm, mùi thơm thật"

# game/halloween.rpy:274
translate english halloween_prepare_mayaroom_1ca099b7:

    # Maya "Хватит нюхать женскую комнату!"
    Maya "Đừng có ngửi phòng con gái nữa!"

# game/halloween.rpy:276
translate english halloween_prepare_mayaroom_eded9518:

    # Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "Cậu ở đây chỉ để thực hiện mệnh lệnh của tớ thôi"

# game/halloween.rpy:277
translate english halloween_prepare_mayaroom_799aa249:

    # Maya "Поставь эти тыквы в тот угол!"
    Maya "Đặt mấy quả bí này vào góc kia!"

# game/halloween.rpy:279
translate english halloween_prepare_mayaroom_292858b8:

    # gg "А где пожалуйста?"
    gg "Còn \"làm ơn\" đâu？"

# game/halloween.rpy:281
translate english halloween_prepare_mayaroom_ad71fbb0:

    # Maya "Пожалуйста, не беси меня"
    Maya "Làm ơn, đừng chọc tức tớ"

# game/halloween.rpy:283
translate english halloween_prepare_mayaroom_63b60e81:

    # gg "Ох"
    gg "Ôi"

# game/halloween.rpy:285
translate english halloween_prepare_mayaroom_0ab11e6d:

    # Maya "Мм . . . нет!"
    Maya "Mm . . . không!"

# game/halloween.rpy:287
translate english halloween_prepare_mayaroom_2f72e2c6:

    # Maya "Выглядит не достаточно хорошо!"
    Maya "Trông chưa đủ đẹp!"

# game/halloween.rpy:289
translate english halloween_prepare_mayaroom_3b7bbda5:

    # Maya "Давай лучше в тот угол!"
    Maya "Thôi để ở góc kia đi!"

# game/halloween.rpy:291
translate english halloween_prepare_mayaroom_9c145638:

    # gg "Давай сначала реши точно куда, чтоб я не таскал 100 раз эти тыквы"
    gg "Cậu quyết định chính xác chỗ nào trước đi, để tôi khỏi phải khuân mấy quả bí này 100 lần"

# game/halloween.rpy:293
translate english halloween_prepare_mayaroom_a2933c08:

    # Maya "Говорю же туда неси!"
    Maya "Tớ bảo là mang tới đó!"

# game/halloween.rpy:295
translate english halloween_prepare_mayaroom_4c580716:

    # gg "Точно?"
    gg "Chắc chứ？"

# game/halloween.rpy:296
translate english halloween_prepare_mayaroom_fccb4de7:

    # gg "Я больше двигать не буду, подумай хорошо"
    gg "Tôi sẽ không dời nữa đâu, nghĩ cho kỹ đi"

# game/halloween.rpy:298
translate english halloween_prepare_mayaroom_1a27198d:

    # Maya "Хотя как сейчас тоже не плохо . . ."
    Maya "Mà như hiện giờ cũng không tệ . . ."

# game/halloween.rpy:300
translate english halloween_prepare_mayaroom_b2b57087:

    # Maya "Все ты свободен!"
    Maya "Thôi, cậu được tự do!"

# game/halloween.rpy:302
translate english halloween_prepare_mayaroom_04c6c53d:

    # gg "Спасибо"
    gg "Cảm ơn"

# game/halloween.rpy:303
translate english halloween_prepare_mayaroom_dad56d9b:

    # Maya "Если что еще позову"
    Maya "Nếu cần gì tớ sẽ gọi"

# game/halloween.rpy:305
translate english halloween_prepare_mayaroom_6a8ac153:

    # Maya "Все Давай, давай, живее!!"
    Maya "Được rồi, mau lên, mau lên, nhanh nữa!!"

# game/halloween.rpy:321
translate english halloween_prepare_sonyaroom_b708d644:

    # Sonya "Ой" with hpunch
    Sonya "Ôi" with hpunch

# game/halloween.rpy:323
translate english halloween_prepare_sonyaroom_4b100306:

    # Sonya "Добро пожаловать в мою обитель!"
    Sonya "Chào mừng đến nơi ở của tớ!"

# game/halloween.rpy:325
translate english halloween_prepare_sonyaroom_7fb491df:

    # gg "У тебя в стиле майнкрафта все, очень милая комната"
    gg "Phòng cậu phong cách Minecraft hết, dễ thương thật"

# game/halloween.rpy:327
translate english halloween_prepare_sonyaroom_9dc8d94c:

    # Sonya "Да, у меня много игрушек осталось"
    Sonya "Ừ, tớ còn nhiều đồ chơi lắm"

# game/halloween.rpy:328
translate english halloween_prepare_sonyaroom_1174b034:

    # gg "Чем то тебе помочь?"
    gg "Cần tôi giúp gì không？"

# game/halloween.rpy:330
translate english halloween_prepare_sonyaroom_36233e2b:

    # Sonya "О можешь пожалуйста разложить остальные блоки"
    Sonya "Ồ, cậu có thể xếp nốt mấy khối còn lại không？"

# game/halloween.rpy:332
translate english halloween_prepare_sonyaroom_51e25d01:

    # gg "Хорошо давай"
    gg "Được thôi"

# game/halloween.rpy:336
translate english halloween_prepare_sonyaroom_5b80a77c:

    # Sonya "Так это сюда"
    Sonya "Vậy cái này để đây"

# game/halloween.rpy:342
translate english halloween_prepare_sonyaroom_5e22d509:

    # Sonya "О забыла я же еще кексов поставила"
    Sonya "Ồ tớ quên, tớ còn đặt bánh cupcake nữa"

# game/halloween.rpy:354
translate english halloween_prepare_bathroom_5d6a2459:

    # gg "Тук-Тук, к вам можно?"
    gg "Cốc cốc, vào được không？"

# game/halloween.rpy:356
translate english halloween_prepare_bathroom_f77e9ebe:

    # Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "Ồ, cậu đến đúng lúc, tớ vừa định gọi cậu, tớ muốn treo con ma lên trên bồn tắm"

# game/halloween.rpy:357
translate english halloween_prepare_bathroom_65af0236:

    # Kate "Но не достаю, вот"
    Kate "Nhưng tớ không với tới, này"

# game/halloween.rpy:359
translate english halloween_prepare_bathroom_b38aeb93:

    # Kate "Вот, видишь?"
    Kate "Đây, thấy chứ？"

# game/halloween.rpy:361
translate english halloween_prepare_bathroom_e0f0e638:

    # Kate "Хм . . . а если я встану на бортики ванной?"
    Kate "Hừm . . . hay là tớ đứng lên thành bồn tắm nhỉ？"

# game/halloween.rpy:363
translate english halloween_prepare_bathroom_e11f6927:

    # gg "Стой, это не безопасно"
    gg "Đứng lại, không an toàn đâu"

# game/halloween.rpy:372
translate english halloween_prepare_bathroom_0be60d3f:

    # Kate "ААй" with hpunch
    Kate "AÁi" with hpunch

# game/halloween.rpy:373
translate english halloween_prepare_bathroom_af26ae75:

    # Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    Kate "Ôi, tớ say quá, may mà cậu ở bên cạnh, cảm ơn"

# game/halloween.rpy:375
translate english halloween_prepare_bathroom_78e2854b:

    # gg "Я так испугался за тебя"
    gg "Tôi lo cho cậu đến phát sợ"

# game/halloween.rpy:376
translate english halloween_prepare_bathroom_7667036:

    # gg "За тобой глаз да глаз, будь аккуратнее"
    gg "Phải để mắt trông cậu suốt, cẩn thận hơn đi"

# game/halloween.rpy:378
translate english halloween_prepare_bathroom_ef29b55b:

    # Kate "Хорошо, я обещаю . . "
    Kate "Được, tớ hứa . . "

# game/halloween.rpy:380
translate english halloween_prepare_bathroom_61bd7d2f:

    # Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    Kate "Có thể buông tớ ra được rồi chứ？ Tớ sẽ không trèo lên đó nữa"

# game/halloween.rpy:382
translate english halloween_prepare_bathroom_77a74e82:

    # gg "Ты такая легкая"
    gg "Cậu nhẹ thật"

# game/halloween.rpy:384
translate english halloween_prepare_bathroom_a0e2f8bb:

    # Kate "Спасибо"
    Kate "Cảm ơn"

# game/halloween.rpy:400
translate english halloween_prepare_myroom_5692ba1f:

    # gg "Эх устал я помогать всем девочкам, и так спать хотел"
    gg "Haiz, giúp các cô gái hết lượt mệt thật, mà tôi còn buồn ngủ nữa"

# game/halloween.rpy:402
translate english halloween_prepare_myroom_6e92de75:

    # gg "Думаю посплю часик"
    gg "Chắc tôi ngủ một tiếng đã"

# game/halloween.rpy:420
translate english halloween_sonya_dream_8c6442c7:

    # gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "Tôi tỉnh dậy vì một âm thanh kỳ lạ - cứ như ai đó cào móng tay lên gỗ"

# game/halloween.rpy:421
translate english halloween_sonya_dream_a05b8801:

    # gg_chat "Это на кухне?"
    gg_chat "Là ở nhà bếp à？"

# game/halloween.rpy:423
translate english halloween_sonya_dream_514bb7b5:

    # gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "Tôi bước ra bếp, dụi mắt"

# game/halloween.rpy:424
translate english halloween_sonya_dream_045482c0:

    # gg_chat "На столе - что-то, чего там не было"
    gg_chat "Trên bàn - có thứ gì đó không hề ở đó trước đây"

# game/halloween.rpy:425
translate english halloween_sonya_dream_d9fa9d7d:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы блестят золотом"
    gg_chat "Một chiếc hộp nhỏ.{w} Gỗ sẫm màu, các góc lấp lánh ánh vàng"

# game/halloween.rpy:426
translate english halloween_sonya_dream_76809b89:

    # gg "Что за чёрт . . ."
    gg "Cái quái gì thế . . ."

# game/halloween.rpy:427
translate english halloween_sonya_dream_b5f93453:

    # gg_chat "Она не выглядит новой"
    gg_chat "Nó trông không mới"

# game/halloween.rpy:428
translate english halloween_sonya_dream_5ac4f621:

    # gg_chat "Скорее наоборот - как будто ей сотни лет"
    gg_chat "Ngược lại mới đúng - cứ như nó đã hàng trăm năm tuổi"

# game/halloween.rpy:433
translate english halloween_sonya_dream_5d15d2b4:

    # gg "Просто кто-то оставил{w} Мая? Соня? . . ."
    gg "Chắc ai đó để lại thôi{w} Maya？ Sonya？ . . ."

# game/halloween.rpy:434
translate english halloween_sonya_dream_f60dffa6:

    # gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "Ngớ ngẩn thật, nhưng tôi vẫn chạm vào nắp"

# game/halloween.rpy:435
translate english halloween_sonya_dream_7aa1f899:

    # gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    gg_chat "Ấm.{w} Cứ như dưới ngón tay là da, chứ không phải gỗ"

# game/halloween.rpy:438
translate english halloween_sonya_dream_d4c068d1:

    # gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg_chat "Bên trong - một đồng xu. Cũ, mòn, trên đó có khắc hình con mắt, còn các cạnh thì gồ ghề như ai đó đã gặm nó"

# game/halloween.rpy:439
translate english halloween_sonya_dream_891135f2:

    # gg "И всё? . . ."
    gg "Vậy thôi à？ . . ."

# game/halloween.rpy:441
translate english halloween_sonya_dream_a19b8684:

    # gg "Ладно пока возьму себе"
    gg "Thôi cứ giữ lấy vậy"

# game/halloween.rpy:442
translate english halloween_sonya_dream_63ba62de:

    # gg_chat "Я поворачиваю её в пальцах"
    gg_chat "Tôi xoay nó trong các ngón tay"

# game/halloween.rpy:443
translate english halloween_sonya_dream_60e7c398:

    # gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    gg_chat "Nặng một cách kỳ lạ, cứ như đồng xu không làm từ kim loại mà từ thứ gì đó sống"

# game/halloween.rpy:447
translate english halloween_sonya_dream_b51c492c:

    # gg "Где же все?"
    gg "Mọi người đâu hết rồi？"

# game/halloween.rpy:452
translate english halloween_sonya_dream_867b75aa:

    # gg "Чёрт. что за бред телевизор сам включился . . ."
    gg "Chết thật. chuyện vớ vẩn gì thế, TV tự bật . . ."

# game/halloween.rpy:487
translate english halloween_sonya_dream_cfa5487f:

    # gg "Что за бред"
    gg "Thật vớ vẩn"

# game/halloween.rpy:488
translate english halloween_sonya_dream_6ca44626:

    # gg "Нужно проверить остальные комнаты"
    gg "Cần kiểm tra các phòng còn lại"

# game/halloween.rpy:491
translate english halloween_sonya_dream_3109e8d5:

    # gg "Соня?"
    gg "Sonya？"

# game/halloween.rpy:493
translate english halloween_sonya_dream_af6b4c99:

    # gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    gg "Này . . . muộn rồi, cậu làm tôi sợ thật đấy"

# game/halloween.rpy:496
translate english halloween_sonya_dream_f09531f9:

    # gg "Просто показалось . . ."
    gg "Chỉ là ảo giác thôi . . ."

# game/halloween.rpy:497
translate english halloween_sonya_dream_6fecd311:

    # gg "Просто тень . . ."
    gg "Chỉ là cái bóng . . ."

# game/halloween.rpy:503
translate english halloween_sonya_dream_b989363c:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:506
translate english halloween_sonya_dream_e5e215bc:

    # Sonya "Как ты посмел меня разбудить!" with hpunch
    Sonya "Sao ngươi dám đánh thức ta!" with hpunch

# game/special_events/halloween 2025.rpy:508
translate english halloween_sonya_dream_cbf79f81:

    # gg "Соня, ты . . . {w}ты издеваешься? . . ."
    gg "Sonya, cậu . . . {w}cậu đang giỡn à？ . . ."

# game/special_events/halloween 2025.rpy:510
translate english halloween_sonya_dream_ea23c51e:

    # gg "Это ты? Что это за грёбаные игры? . . ."
    gg "Là cậu à？ Trò chơi chết tiệt gì thế này？ . . ."

# game/special_events/halloween 2025.rpy:512
translate english halloween_sonya_dream_c5bc9963:

    # Sonya "Имя звучит знакомо"
    Sonya "Cái tên nghe quen thật"

# game/special_events/halloween 2025.rpy:513
translate english halloween_sonya_dream_4db18375:

    # Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    Sonya "Nhưng kẻ ngươi gọi đã chết cùng ngôi nhà này rồi"

# game/special_events/halloween 2025.rpy:514
translate english halloween_sonya_dream_f5284849:

    # gg "Прекрати . . ."
    gg "Dừng lại . . ."

# game/special_events/halloween 2025.rpy:516
translate english halloween_sonya_dream_bf221ec2:

    # Sonya "Дом теперь мой.{w} Я - его хозяин"
    Sonya "Ngôi nhà giờ là của ta.{w} Ta là chủ của nó"

# game/special_events/halloween 2025.rpy:518
translate english halloween_sonya_dream_2c4ebaa2:

    # Sonya "Боишься?"
    Sonya "Sợ à？"

# game/special_events/halloween 2025.rpy:519
translate english halloween_sonya_dream_0063da0b:

    # gg "Да . . ."
    gg "Vâng . . ."

# game/special_events/halloween 2025.rpy:521
translate english halloween_sonya_dream_b67571be:

    # Sonya "Хорошо"
    Sonya "Tốt"

# game/special_events/halloween 2025.rpy:523
translate english halloween_sonya_dream_14d503b0:

    # Sonya "Страх делает кровь живой"
    Sonya "Nỗi sợ khiến máu trở nên sống động"

# game/special_events/halloween 2025.rpy:531
translate english halloween_sonya_dream_ab894d3a:

    # Sonya "Ты принёс монету?"
    Sonya "Ngươi mang đồng xu đến chứ？"

# game/special_events/halloween 2025.rpy:535
translate english halloween_sonya_dream_c3bf29e7:

    # gg "Что? . . ."
    gg "Gì cơ？ . . ."

# game/special_events/halloween 2025.rpy:537
translate english halloween_sonya_dream_52cb176c:

    # Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "Món quà đã bị phong ấn. Ngươi đã mở nó"

# game/special_events/halloween 2025.rpy:538
translate english halloween_sonya_dream_e3369996:

    # Sonya "Ты впустил меня"
    Sonya "Ngươi đã để ta vào"

# game/special_events/halloween 2025.rpy:540
translate english halloween_sonya_dream_1f166693:

    # Sonya "Я не Соня"
    Sonya "Ta không phải Sonya"

# game/special_events/halloween 2025.rpy:544
translate english halloween_sonya_dream_86fe7642:

    # Sonya "Я та, что носила её лицо"
    Sonya "Ta là kẻ đã mang gương mặt của cô ta"

# game/special_events/halloween 2025.rpy:545
translate english halloween_sonya_dream_625b9f75:

    # Sonya "И теперь ты мой"
    Sonya "Và giờ ngươi là của ta"

# game/special_events/halloween 2025.rpy:547
translate english halloween_sonya_dream_0ac9332f:

    # Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    Sonya "Tất cả những gì ngươi sợ mất . . . ta đã lấy rồi"

# game/special_events/halloween 2025.rpy:549
translate english halloween_sonya_dream_64ed8507:

    # Sonya "А теперь - перестань сопротивляться"
    Sonya "Còn bây giờ - thôi chống cự đi"

# game/special_events/halloween 2025.rpy:553
translate english halloween_sonya_dream_3d7ee945:

    # Sonya "Я выжму тебя досуха"
    Sonya "Ta sẽ vắt kiệt ngươi"

# game/special_events/halloween 2025.rpy:588
translate english halloween_maya_dream_032be6f2:

    # gg "Чёрт . . . {w}нет, нет, снова это . . ."
    gg "Chết tiệt . . . {w}không, không, lại nữa rồi . . ."

# game/special_events/halloween 2025.rpy:590
translate english halloween_maya_dream_ff7388e6:

    # Maya "Эй, спокойно"
    Maya "Này, bình tĩnh"

# game/special_events/halloween 2025.rpy:592
translate english halloween_maya_dream_92686e55:

    # Maya "Ты в безопасности"
    Maya "Cậu an toàn rồi"

# game/special_events/halloween 2025.rpy:593
translate english halloween_maya_dream_edf9349e:

    # gg "Где я? . . ."
    gg "Tôi đang ở đâu？ . . ."

# game/special_events/halloween 2025.rpy:594
translate english halloween_maya_dream_de23ff68:

    # gg "Что . . . что это за место?"
    gg "Cái . . . cái nơi này là gì？"

# game/special_events/halloween 2025.rpy:596
translate english halloween_maya_dream_75c561e6:

    # Maya "Мой дом"
    Maya "Nhà tớ"

# game/special_events/halloween 2025.rpy:598
translate english halloween_maya_dream_912b1ea9:

    # gg "Почему . . . я . . . здесь? . . ."
    gg "Tại sao . . . tôi . . . lại ở đây？ . . ."

# game/special_events/halloween 2025.rpy:600
translate english halloween_maya_dream_05fc8512:

    # Maya "Потому что ты боялся"
    Maya "Vì cậu đã sợ"

# game/special_events/halloween 2025.rpy:601
translate english halloween_maya_dream_657245c6:

    # Maya "И кто-то должен был тебя остановить"
    Maya "Và ai đó phải ngăn cậu lại"

# game/special_events/halloween 2025.rpy:603
translate english halloween_maya_dream_dcba1503:

    # gg "Нет . . .{w} не приближайся"
    gg "Không . . .{w} đừng lại gần"

# game/special_events/halloween 2025.rpy:604
translate english halloween_maya_dream_e91592a1:

    # gg "Я видел, как это начинается"
    gg "Tôi đã thấy nó bắt đầu thế nào"

# game/special_events/halloween 2025.rpy:605
translate english halloween_maya_dream_d9b24014:

    # gg "Сначала свет, потом . . ."
    gg "Đầu tiên là ánh sáng, rồi thì . . ."

# game/special_events/halloween 2025.rpy:608
translate english halloween_maya_dream_23c69478:

    # Maya "Никто не собирается тебя пугать"
    Maya "Không ai định làm cậu sợ đâu"

# game/special_events/halloween 2025.rpy:609
translate english halloween_maya_dream_fb15da85:

    # gg "Это сон?"
    gg "Đây là mơ à？"

# game/special_events/halloween 2025.rpy:611
translate english halloween_maya_dream_ef47f8b8:

    # Maya "Возможно"
    Maya "Có thể"

# game/special_events/halloween 2025.rpy:612
translate english halloween_maya_dream_11e09330:

    # Maya "Но в этом сне тебе можно не убегать"
    Maya "Nhưng trong giấc mơ này, cậu không cần phải bỏ chạy"

# game/special_events/halloween 2025.rpy:614
translate english halloween_maya_dream_e96ceee2:

    # Maya "Сядь.{w} Попробуй просто дышать"
    Maya "Ngồi xuống.{w} Thử chỉ hít thở thôi"

# game/special_events/halloween 2025.rpy:615
translate english halloween_maya_dream_f1385d77:

    # gg "Я . . .{w} не могу"
    gg "Tôi . . .{w} không thể"

# game/special_events/halloween 2025.rpy:617
translate english halloween_maya_dream_38874e86:

    # Maya "Можешь{w}, начни только тихо"
    Maya "Cậu có thể{w}, chỉ cần bắt đầu thật nhẹ nhàng"

# game/special_events/halloween 2025.rpy:619
translate english halloween_maya_dream_4a1eadac:

    # Maya "Ты думал, я кто-то другой, да?"
    Maya "Cậu tưởng tớ là ai khác, đúng không？"

# game/special_events/halloween 2025.rpy:621
translate english halloween_maya_dream_8d83da3f:

    # gg "После всего . . ."
    gg "Sau tất cả mọi chuyện . . ."

# game/special_events/halloween 2025.rpy:622
translate english halloween_maya_dream_9aa85be5:

    # gg "Я и не знаю, кому верить"
    gg "Tôi cũng không biết tin ai nữa"

# game/special_events/halloween 2025.rpy:623
translate english halloween_maya_dream_95a67e98:

    # Maya "Тогда не верь"
    Maya "Vậy thì đừng tin"

# game/special_events/halloween 2025.rpy:624
translate english halloween_maya_dream_cf12428b:

    # Maya "Просто смотри"
    Maya "Chỉ cần nhìn thôi"

# game/special_events/halloween 2025.rpy:628
translate english halloween_maya_dream_5da82532:

    # gg "Чувствуешь?{w} Здесь нет боли"
    gg "Cậu cảm thấy chứ？{w} Ở đây không có đau đớn"

# game/special_events/halloween 2025.rpy:630
translate english halloween_maya_dream_df19ec31:

    # Maya "Ты дрожишь"
    Maya "Cậu đang run kìa"

# game/special_events/halloween 2025.rpy:631
translate english halloween_maya_dream_b989363c_2:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:634
translate english halloween_maya_dream_718947a3:

    # Maya "Бедный"
    Maya "Tội nghiệp"

# game/special_events/halloween 2025.rpy:636
translate english halloween_maya_dream_20c45a93:

    # Maya "Я давно не видела людей"
    Maya "Lâu lắm rồi tớ chưa gặp người"

# game/special_events/halloween 2025.rpy:638
translate english halloween_maya_dream_0f6f1ec4:

    # Maya "Вот, видишь?{w} Уже лучше"
    Maya "Đây, thấy chứ？{w} Khá hơn rồi"

# game/special_events/halloween 2025.rpy:639
translate english halloween_maya_dream_1db499d0:

    # gg "Не знаю, что это.{w} Но уже лучше"
    gg "Tôi không biết đó là gì.{w} Nhưng đúng là khá hơn rồi"

# game/special_events/halloween 2025.rpy:641
translate english halloween_maya_dream_927ad5b3:

    # Maya "Сейчас кое что тебя поставит на ноги"
    Maya "Giờ có một thứ sẽ giúp cậu đứng dậy"

# game/special_events/halloween 2025.rpy:644
translate english halloween_maya_dream_9add8ae1:

    # Maya "Здесь только травы"
    Maya "Ở đây chỉ có thảo mộc thôi"

# game/special_events/halloween 2025.rpy:645
translate english halloween_maya_dream_338034af:

    # Maya "Лаванда, мята, немного корицы.{w} Попей"
    Maya "Oải hương, bạc hà, một chút quế.{w} Uống đi"

# game/special_events/halloween 2025.rpy:647
translate english halloween_maya_dream_8f20081e:

    # gg "Что это?"
    gg "Đây là gì？"

# game/special_events/halloween 2025.rpy:648
translate english halloween_maya_dream_3fdb7032:

    # Maya "Это магия"
    Maya "Đó là phép thuật"

# game/special_events/halloween 2025.rpy:650
translate english halloween_maya_dream_7c4cba20:

    # Maya "Лечебное зелье, с небольшим побочным эфектом"
    Maya "Thuốc chữa trị, với một chút tác dụng phụ nhỏ"

# game/special_events/halloween 2025.rpy:652
translate english halloween_maya_dream_59e469a3:

    # gg "Каким еще эфектом"
    gg "Tác dụng phụ gì nữa？"

# game/special_events/halloween 2025.rpy:655
translate english halloween_maya_dream_809b7a3a:

    # Maya "Просто отдохни.{w} Не думай об этом"
    Maya "Chỉ cần nghỉ ngơi thôi.{w} Đừng nghĩ về nó"

# game/special_events/halloween 2025.rpy:657
translate english halloween_maya_dream_ae92cf27:

    # gg "А если я снова усну?"
    gg "Nếu tôi ngủ lại thì sao？"

# game/special_events/halloween 2025.rpy:659
translate english halloween_maya_dream_c1fe7b6b:

    # Maya "Тогда пусть этот сон, будет приятным"
    Maya "Vậy thì hãy để giấc mơ này trở nên dễ chịu"

# game/special_events/halloween 2025.rpy:683
translate english halloween_maya_dream_b989363c_3:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:684
translate english halloween_maya_dream_5174a63c:

    # gg "Приснится же такое . . ."
    gg "Lại mơ thấy thứ như thế này chứ . . ."

# game/special_events/halloween 2025.rpy:686
translate english halloween_maya_dream_13dee7c8:

    # "Тыква хранит воспоминания"
    "Quả bí lưu giữ ký ức"

# game/special_events/halloween 2025.rpy:687
translate english halloween_maya_dream_bb8e42de:

    # "Коснись её, чтобы вновь увидеть сцену"
    "Chạm vào nó để xem lại cảnh đó"

translate english strings:

    # game/special_events/halloween 2025.rpy:8
    old "Сначала"
    new "Đầu tiên"

    # game/special_events/halloween 2025.rpy:10
    old "Сон с Соней"
    new "Giấc mơ với Sonya"

    # game/special_events/halloween 2025.rpy:14
    old "Сон с Маей"
    new "Giấc mơ với Maya"

# TODO: Translation updated at 2026-01-21 14:06

# game/special_events/halloween 2025.rpy:272
translate english halloween_prepare_mayaroom_63c64e7b:

    # gg "Мм. . . пахнет приятно"
    gg "Mm. . . mùi thơm thật"

# game/special_events/halloween 2025.rpy:285
translate english halloween_prepare_mayaroom_977c102e:

    # Maya "Мм. . . нет!"
    Maya "Mm. . . không!"

# game/special_events/halloween 2025.rpy:287
translate english halloween_prepare_mayaroom_9cb8ca98:

    # Maya "Выглядит недостаточно хорошо!"
    Maya "Trông chưa đủ đẹp!"

# game/special_events/halloween 2025.rpy:291
translate english halloween_prepare_mayaroom_f714e642:

    # gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    gg "Để cậu quyết định chính xác chỗ nào trước đi, để tôi khỏi khuân mấy quả bí này trăm lần"

# game/special_events/halloween 2025.rpy:298
translate english halloween_prepare_mayaroom_4aa933c6:

    # Maya "Хотя как сейчас тоже неплохо . . ."
    Maya "Mà như hiện giờ cũng không tệ . . ."

# game/special_events/halloween 2025.rpy:372
translate english halloween_prepare_bathroom_01550c8f:

    # Kate "ААй!" with hpunch
    Kate "AÁi!" with hpunch

# game/special_events/halloween 2025.rpy:376
translate english halloween_prepare_bathroom_766703c6:

    # gg "За тобой глаз, да глаз, будь аккуратнее"
    gg "Phải để mắt trông cậu suốt, cẩn thận hơn đi"

# game/special_events/halloween 2025.rpy:425
translate english halloween_sonya_dream_e953cb07:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg_chat "Chiếc hộp nhỏ.{w} Gỗ sẫm màu, các góc bọc kim loại đỏ như máu"

# game/special_events/halloween 2025.rpy:433
translate english halloween_sonya_dream_a96a7298:

    # gg "Просто кто-то оставил{w} Мая? Соня?"
    gg "Chắc ai đó để lại thôi{w} Maya？ Sonya？"

# game/special_events/halloween 2025.rpy:441
translate english halloween_sonya_dream_5bbdc303:

    # gg "Ладно, пока возьму себе"
    gg "Thôi, cứ giữ lấy vậy"

# TODO: Translation updated at 2026-01-27 02:14

# game/special_events/halloween 2025.rpy:533
translate english halloween_sonya_dream_9d9be648:

    # Sonya "Да . . . вот оно. Жар под кожей. Сок, который ты копил для кого-то другого. Теперь он мой"
    Sonya "Đúng . . . là nó. Hơi nóng dưới da. Dòng nhựa sống ngươi tích tụ cho kẻ khác. Giờ nó là của ta"

# game/special_events/halloween 2025.rpy:534
translate english halloween_sonya_dream_709e3011:

    # Sonya "Я чувствую . . . как твоя суть отделяется от костей. Как светится . . . и течёт ко мне"
    Sonya "Ta cảm thấy . . . bản thể ngươi đang tách khỏi xương cốt. Đang phát sáng . . . và chảy về phía ta"

# game/special_events/halloween 2025.rpy:535
translate english halloween_sonya_dream_5e3f412d:

    # Sonya "Скоро . . . скоро ты станешь пустым. Лёгким. И будешь спать"
    Sonya "Sắp rồi . . . sắp rồi ngươi sẽ trở nên trống rỗng. Nhẹ tênh. Và sẽ ngủ"

# game/special_events/halloween 2025.rpy:540
translate english halloween_sonya_dream_8f2a3a2a:

    # Sonya "Сейчас. Отдай мне последнюю искру. Тот всполох, что зовут экстазом… я приму его как дань"
    Sonya "Ngay bây giờ. Giao cho ta tia lửa cuối cùng. Tia lóe ấy, thứ người ta gọi là cực khoái… ta sẽ nhận nó như một món cống phẩm"

# game/special_events/halloween 2025.rpy:543
translate english halloween_sonya_dream_279834b2:

    # Sonya "ДА! Вот . . . пылающая монета твоей души . . . я беру её!"
    Sonya "ĐÚNG VẬY! Đây . . . đồng xu cháy bỏng của linh hồn ngươi . . . ta lấy nó!"

# game/special_events/halloween 2025.rpy:546
translate english halloween_sonya_dream_feb25de8:

    # Sonya "Спи. В твоих снах будет песок. И глаза в темноте . . . мои глаза"
    Sonya "Ngủ đi. Trong những giấc mơ của ngươi sẽ có cát. Và những con mắt trong bóng tối . . . mắt của ta"

# game/special_events/halloween 2025.rpy:549
translate english halloween_sonya_dream_dbd299d0:

    # Sonya "Может быть, я позову снова . . . когда проголодаюсь"
    Sonya "Có lẽ ta sẽ gọi lại . . . khi ta đói"

# game/special_events/halloween 2025.rpy:617
translate english halloween_maya_dream_b989363c:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:650
translate english halloween_maya_dream_6274b812:

    # Maya "Да . . . вот так . . . Ты так нуждаешься в этом. Я знала"
    Maya "Đúng . . . như thế . . . Cậu cần điều này đến vậy. Tớ biết mà"

# game/special_events/halloween 2025.rpy:651
translate english halloween_maya_dream_c101e994:

    # gg "Майя . . . Я . . ."
    gg "Maya . . . Tôi . . ."

# game/special_events/halloween 2025.rpy:652
translate english halloween_maya_dream_5e852895:

    # Maya "Какая прекрасная . . . реакция. Всё для меня?"
    Maya "Phản ứng . . . tuyệt đẹp làm sao. Tất cả là vì tớ à？"

# game/special_events/halloween 2025.rpy:653
translate english halloween_maya_dream_cab511be:

    # Maya "О-ох . . . Да . . . Вот так"
    Maya "Ô-ồ . . . Đúng . . . Như thế"

# game/special_events/halloween 2025.rpy:654
translate english halloween_maya_dream_87be51c0:

    # Maya "Да-да-да! Вот здесь! Чувствую, как ты пульсируешь!"
    Maya "Đúng-đúng-đúng! Chỗ này! Tớ cảm thấy cậu đang co giật theo từng nhịp!"

# game/special_events/halloween 2025.rpy:656
translate english halloween_maya_dream_aafdbf4d:

    # Maya "Aaa-ох . . ."
    Maya "Aaa-ồ . . ."

# game/special_events/halloween 2025.rpy:659
translate english halloween_maya_dream_162eda56:

    # Maya "Идеально . . . Ты был идеален . . . Запомни это . . . Запомни меня . . ."
    Maya "Hoàn hảo . . . Cậu đã hoàn hảo . . . Hãy nhớ điều này . . . Nhớ tớ nhé . . ."

# game/special_events/halloween 2025.rpy:687
translate english halloween_kate_dream_2a6a4db2:

    # gg "Кейт? . . ."
    gg "Kate？ . . ."

# game/special_events/halloween 2025.rpy:692
translate english halloween_kate_dream_3c8f411e:

    # gg "Что . . . что происходит?"
    gg "Cái . . . chuyện gì đang xảy ra？"

# game/special_events/halloween 2025.rpy:696
translate english halloween_kate_dream_6b307304:

    # Kate "{sc}{size=*1.2}Ты"
    Kate "{sc}{size=*1.2}Ngươi"

# game/special_events/halloween 2025.rpy:698
translate english halloween_kate_dream_21111df8:

    # Kate "Вторгся в середину ритуала"
    Kate "Đã xâm nhập vào giữa nghi lễ"

# game/special_events/halloween 2025.rpy:699
translate english halloween_kate_dream_2caa82ea:

    # Kate "Твоё присутствие нарушило поток"
    Kate "Sự hiện diện của ngươi đã làm gián đoạn dòng chảy"

# game/special_events/halloween 2025.rpy:701
translate english halloween_kate_dream_bc58cb35:

    # gg "Гх . . . {w}Прости, я не знал . . ."
    gg "Khụ . . . {w}Xin lỗi, tôi không biết . . ."

# game/special_events/halloween 2025.rpy:703
translate english halloween_kate_dream_91b43246:

    # Kate "Ты не просто услышал. Ты почувствовал зов"
    Kate "Ngươi không chỉ nghe thấy. Ngươi đã cảm nhận được tiếng gọi"

# game/special_events/halloween 2025.rpy:705
translate english halloween_kate_dream_211858ba:

    # Kate "Иначе ты бы не вошёл"
    Kate "Nếu không thì ngươi đã không bước vào"

# game/special_events/halloween 2025.rpy:707
translate english halloween_kate_dream_0f5b8117:

    # Kate "Люди носят маски каждый день"
    Kate "Con người đeo mặt nạ mỗi ngày"

# game/special_events/halloween 2025.rpy:708
translate english halloween_kate_dream_4fc89b6e:

    # Kate "Они молятся свету, а в темноте становятся теми, кем боятся быть"
    Kate "Họ cầu nguyện với ánh sáng, nhưng trong bóng tối lại trở thành kẻ mà họ sợ phải trở thành"

# game/special_events/halloween 2025.rpy:710
translate english halloween_kate_dream_fd7485b5:

    # gg "Кейт, пожалуйста . . . остановись"
    gg "Kate, làm ơn . . . dừng lại"

# game/special_events/halloween 2025.rpy:712
translate english halloween_kate_dream_21bb7ba7:

    # Kate "Это имя лишь оболочка, которую я носила"
    Kate "Cái tên đó chỉ là vỏ bọc ta từng mang"

# game/special_events/halloween 2025.rpy:713
translate english halloween_kate_dream_54373c98:

    # Kate "Сейчас я — та, кто принимает исповедь. А исповедь требует . . . отдачи"
    Kate "Giờ ta là kẻ tiếp nhận lời thú tội. Mà thú tội thì đòi hỏi . . . sự dâng hiến"

# game/special_events/halloween 2025.rpy:715
translate english halloween_kate_dream_6aceb243:

    # Kate "Ты боишься. Это хорошо. Страх очищает"
    Kate "Ngươi sợ. Tốt. Nỗi sợ thanh tẩy"

# game/special_events/halloween 2025.rpy:716
translate english halloween_kate_dream_6993148d:

    # Kate "Но за страхом . . . всегда прячется желание"
    Kate "Nhưng đằng sau nỗi sợ . . . luôn ẩn giấu dục vọng"

# game/special_events/halloween 2025.rpy:718
translate english halloween_kate_dream_5f463a3c:

    # Kate "Мой ритуал требует энергии. Чистой, незамутнённой лицемерием"
    Kate "Nghi lễ của ta cần năng lượng. Thuần khiết, không bị vẩn đục bởi đạo đức giả"

# game/special_events/halloween 2025.rpy:720
translate english halloween_kate_dream_e52aea01:

    # Kate "Твой страх — это начало. Но чтобы завершить круг . . . нужно"
    Kate "Nỗi sợ của ngươi là khởi đầu. Nhưng để hoàn thành vòng tròn . . . cần"

# game/special_events/halloween 2025.rpy:722
translate english halloween_kate_dream_6c364d34:

    # Kate "Нечто большее"
    Kate "Một thứ lớn hơn"

# game/special_events/halloween 2025.rpy:725
translate english halloween_kate_dream_4729db36:

    # gg "Что ты хочешь? . . . "
    gg "Cô muốn gì？ . . . "

# game/special_events/halloween 2025.rpy:727
translate english halloween_kate_dream_195da2d7:

    # Kate "Я хочу ту часть тебя, которая не боится тьмы"
    Kate "Ta muốn phần trong ngươi không sợ bóng tối"

# game/special_events/halloween 2025.rpy:729
translate english halloween_kate_dream_d9bfbc43:

    # Kate "Которая жаждет её"
    Kate "Phần khao khát nó"

# game/special_events/halloween 2025.rpy:730
translate english halloween_kate_dream_2a999a14:

    # Kate "Это не сердце. Это — пустота, которую ты пытался заполнить ложью"
    Kate "Đó không phải trái tim. Đó là khoảng trống mà ngươi cố lấp đầy bằng dối trá"

# game/special_events/halloween 2025.rpy:732
translate english halloween_kate_dream_62c66a6e:

    # Kate "Позволь мне заполнить её истиной"
    Kate "Hãy để ta lấp đầy nó bằng sự thật"

# game/special_events/halloween 2025.rpy:733
translate english halloween_kate_dream_6f6518cc:

    # gg "Гхк . . ."
    gg "Khự . . ."

# game/special_events/halloween 2025.rpy:734
translate english halloween_kate_dream_a32c9003:

    # gg "Я не могу подвинуться"
    gg "Tôi không thể nhúc nhích"

# game/special_events/halloween 2025.rpy:736
translate english halloween_kate_dream_12b2e70f:

    # Kate "Не сопротивляйся. Это тоже часть ритуала"
    Kate "Đừng chống cự. Đây cũng là một phần của nghi lễ"

# game/special_events/halloween 2025.rpy:738
translate english halloween_kate_dream_fd3fd304:

    # Kate "Ты отдаёшь — я принимаю. Так было всегда"
    Kate "Ngươi trao đi — ta nhận lấy. Xưa nay vẫn vậy"

# game/special_events/halloween 2025.rpy:740
translate english halloween_kate_dream_7cee1ec3:

    # Kate "Видишь? Твоё тело уже понимает. Оно помнит правила"
    Kate "Thấy chứ？ Cơ thể ngươi đã hiểu rồi. Nó nhớ luật lệ"

# game/special_events/halloween 2025.rpy:753
translate english halloween_kate_dream_e36daadf:

    # Kate "Это дрожь . . . пробуждения"
    Kate "Đây là cơn run rẩy . . . của sự thức tỉnh"

# game/special_events/halloween 2025.rpy:761
translate english halloween_kate_dream_18a21981:

    # Kate "Тише. Не мешай"
    Kate "Im lặng. Đừng quấy rầy"

# game/special_events/halloween 2025.rpy:762
translate english halloween_kate_dream_64b1ddea:

    # Kate "Я только знакомлюсь с тем, что моё"
    Kate "Ta chỉ đang làm quen với thứ thuộc về ta"

# game/special_events/halloween 2025.rpy:764
translate english halloween_kate_dream_fa83af8e:

    # Kate "Ты . . . для этого . . .{w} и пришёл . . ."
    Kate "Ngươi . . . đến đây . . .{w} chính là để làm việc này . . ."

# game/special_events/halloween 2025.rpy:765
translate english halloween_kate_dream_475590f4:

    # Kate "Чтоб тебя . . . размяли . . .{w} взяли в руки . . ."
    Kate "Để ngươi . . . được làm mềm . . .{w} được cầm lấy trong tay . . ."

# game/special_events/halloween 2025.rpy:767
translate english halloween_kate_dream_020e238d:

    # gg "Агхх . ."
    gg "Aghh . ."

# game/special_events/halloween 2025.rpy:768
translate english halloween_kate_dream_0c86ca7b:

    # Kate "Да!"
    Kate "Đúng vậy!"

# game/special_events/halloween 2025.rpy:769
translate english halloween_kate_dream_d0b4a1d1:

    # Kate "Вот так"
    Kate "Như thế"

# game/special_events/halloween 2025.rpy:770
translate english halloween_kate_dream_854a0208:

    # Kate "Рвись! Кончай!{w} Отдавай это мне"
    Kate "Bung ra! Bắn đi!{w} Dâng nó cho ta"

# game/special_events/halloween 2025.rpy:772
translate english halloween_kate_dream_4402c96f:

    # Kate "Ахахаха ха ха"
    Kate "Ahahaha ha ha"

# game/special_events/halloween 2025.rpy:774
translate english halloween_kate_dream_c8fc9712:

    # Kate "Видишь? Даже твой пик — в моей власти"
    Kate "Thấy chứ？ Ngay cả đỉnh điểm của ngươi — cũng nằm trong quyền lực của ta"

# game/special_events/halloween 2025.rpy:775
translate english halloween_kate_dream_ab9b9a56:

    # Kate "Я решаю когда и как"
    Kate "Ta quyết định khi nào và thế nào"

# game/special_events/halloween 2025.rpy:777
translate english halloween_kate_dream_d8951333:

    # Kate "А теперь хватит игр"
    Kate "Còn bây giờ, hết trò chơi"

# game/special_events/halloween 2025.rpy:786
translate english halloween_kate_dream_088e1fcf:

    # Kate "Всё, время нежностей кончилось"
    Kate "Được rồi, hết giờ dịu dàng"

# game/special_events/halloween 2025.rpy:789
translate english halloween_kate_dream_d84a2e22:

    # Kate "Молчи и терпи. Это плата за твой глупый интерес"
    Kate "Im lặng và chịu đựng. Đó là cái giá cho sự tò mò ngu ngốc của ngươi"

# game/special_events/halloween 2025.rpy:791
translate english halloween_kate_dream_959b5201:

    # Kate "А-ах . . . Так . . . Глубоко . . ."
    Kate "А-ах . . . Так . . . Глубоко . . ."

# game/special_events/halloween 2025.rpy:795
translate english halloween_kate_dream_ad7fd02e:

    # Kate "Да . . . Вот так"
    Kate "Đúng . . . Cứ như vậy"

# game/special_events/halloween 2025.rpy:796
translate english halloween_kate_dream_e0d93040:

    # Kate "Отдай мне это.{w} Всю свою подавленную тьму.{w} Всю свою скрытую жажду"
    Kate "Đưa nó cho ta.{w} Toàn bộ bóng tối bị kìm nén của ngươi.{w} Toàn bộ khát khao thầm kín của ngươi"

# game/special_events/halloween 2025.rpy:797
translate english halloween_kate_dream_3f099ced:

    # gg "Я . . . я не могу . . ."
    gg "Tôi . . . tôi không thể . . ."

# game/special_events/halloween 2025.rpy:798
translate english halloween_kate_dream_0e94451f:

    # Kate "Можешь. И ты сделаешь.{w} Сейчас"
    Kate "Ngươi làm được. Và ngươi sẽ làm.{w} Ngay bây giờ"

# game/special_events/halloween 2025.rpy:802
translate english halloween_kate_dream_866aa006:

    # Kate "А-ах . . ."
    Kate "A-ah . . ."

# game/special_events/halloween 2025.rpy:804
translate english halloween_kate_dream_25c1049a:

    # Kate "Ха.."
    Kate "Ha.."

# game/special_events/halloween 2025.rpy:806
translate english halloween_kate_dream_c4c58437:

    # Kate "Ритуал завершён. Ты отдал достаточно . . . чтобы я продолжила свой путь"
    Kate "Nghi lễ đã hoàn tất. Ngươi đã trao đủ . . . để ta tiếp tục con đường của mình"

# game/special_events/halloween 2025.rpy:808
translate english halloween_kate_dream_c5ab54b2:

    # Kate "Ты проснёшься пустым.{w} Безнадёжно пустым. И, может быть, снова выползешь ко мне . . ."
    Kate "Ngươi sẽ tỉnh dậy trống rỗng.{w} Trống rỗng vô vọng. Và, có lẽ, ngươi sẽ lại lết đến chỗ ta . . ."

# game/special_events/halloween 2025.rpy:809
translate english halloween_kate_dream_0eb6bd42:

    # Kate "Чтобы снова украсть немного этой полноты"
    Kate "Để một lần nữa đánh cắp một chút viên mãn ấy"

# game/special_events/halloween 2025.rpy:811
translate english halloween_kate_dream_2f7f297c:

    # Kate "Хотя бы на мгновение"
    Kate "Dù chỉ trong một khoảnh khắc"

# game/special_events/halloween 2025.rpy:834
translate english halloween_kate_dream_b989363c:

    # gg ". . ."
    gg ". . ."

# game/special_events/halloween 2025.rpy:835
translate english halloween_kate_dream_5174a63c:

    # gg "Приснится же такое . . ."
    gg "Lại mơ thấy chuyện như thế này . . ."

# game/special_events/halloween 2025.rpy:837
translate english halloween_kate_dream_13dee7c8:

    # "Тыква хранит воспоминания"
    "Quả bí ngô lưu giữ ký ức"

# game/special_events/halloween 2025.rpy:838
translate english halloween_kate_dream_bb8e42de:

    # "Коснись её, чтобы вновь увидеть сцену"
    "Chạm vào nó để xem lại cảnh ấy"

translate english strings:

    # game/special_events/halloween 2025.rpy:15
    old "Сон с Кейт"
    new "Giấc mơ cùng Kate"


