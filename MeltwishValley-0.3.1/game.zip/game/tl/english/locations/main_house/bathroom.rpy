﻿# TODO: Translation updated at 2026-01-21 02:04

# game/locations/main_house/bathroom.rpy:18
translate english bathroom_3da38f85:

    # gg "Я думаю я не так сильно знаком с Маей"
    gg "Tôi nghĩ tôi không thân với Maya lắm"

# game/locations/main_house/bathroom.rpy:23
translate english bathroom_1dae98de:

    # gg "Я думаю я не так сильно знаком с Соней"
    gg "Tôi nghĩ tôi không thân với Sonya lắm"

# TODO: Translation updated at 2026-01-26 03:21

# game/locations/main_house/bathroom.rpy:19
translate english bathroom_8df379f4:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Маей"
    gg "Có lẽ tôi vẫn chưa đủ thân với Maya"

# game/locations/main_house/bathroom.rpy:25
translate english bathroom_675eb9d2:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Соней"
    gg "Có lẽ tôi vẫn chưa đủ thân với Sonya"

