﻿# TODO: Translation updated at 2026-01-21 02:04

# game/locations/main_house/kitchen.rpy:24
translate english kitchen_e44eab80:

    # "Привет, перед началом игры давай быстро разберемся с управлением"
    "Xin chào, trước khi bắt đầu trò chơi, chúng ta hãy nhanh chóng tìm hiểu cách điều khiển nhé."

# game/locations/main_house/kitchen.rpy:25
translate english kitchen_e9ff8856:

    # "Что бы перейти в другую комнату тебе нужно навестись мышкой в правую часть экрана"
    "Để chuyển sang phòng khác, bạn cần di chuột đến phần bên phải màn hình."

# game/locations/main_house/kitchen.rpy:28
translate english kitchen_22e95808:

    # "После выбери комнату в которую хочешь попасть"
    "Sau đó, chọn phòng mà bạn muốn đến."

# game/locations/main_house/kitchen.rpy:29
translate english kitchen_c3e67100:

    # "На иконках комнат будут отображены девушки которые сейчас там находятся"
    "Trên biểu tượng các phòng sẽ hiển thị những cô gái hiện đang ở đó."


# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/kitchen.rpy:30
translate english kitchen_b2963125:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой доступно ключевое действие"
    "Bên cạnh biểu tượng sẽ xuất hiện {color=#fffb27ff}ngôi sao{/color}, nếu có thể thực hiện hành động chính với cô gái."

# game/locations/main_house/kitchen.rpy:31
translate english kitchen_b1f7eb9e:

    # "Попробуй перейти в комнату Маи"
    "Hãy thử chuyển sang phòng của Maya."

