﻿# TODO: Translation updated at 2026-01-21 02:04

# game/locations/main_house/myroom.rpy:22
translate english myroom_c1835e38:

    # "Что бы лечь спать нажмите ночью на кровать"
    "Để đi ngủ, hãy nhấn vào giường vào ban đêm"


# game/locations/main_house/myroom.rpy:28
translate english myroom_1cd5975b:

    # "Нажмите на значок в правом верхнем углу, чтобы изменить время"
    "Nhấn vào biểu tượng ở góc trên bên phải để thay đổi thời gian"

# game/locations/main_house/myroom.rpy:30
translate english myroom_2f1c23a7:

    # "В левом нижнем углу отображаются текущее время суток, день недели и счётчик дней"
    "Ở góc dưới bên trái hiển thị thời gian hiện tại trong ngày, ngày trong tuần và bộ đếm ngày"

# game/locations/main_house/myroom.rpy:33
translate english myroom_4dcc1b35:

    # "Теперь вам доступна книга персонажей"
    "Bây giờ bạn có thể sử dụng sách nhân vật"

# game/locations/main_house/myroom.rpy:36
translate english myroom_f5a7354e:

    # "В ней вы можете посмотреть описание каждой девушки и текущий уровень отношений"
    "Trong đó bạn có thể xem mô tả của từng cô gái và mức độ quan hệ hiện tại"

# game/locations/main_house/myroom.rpy:37
translate english myroom_b927df5c:

    # "Здесь же доступны подсказки к следующему событию и возможность закрепить активный квест"
    "Tại đây cũng có gợi ý cho sự kiện tiếp theo và khả năng ghim nhiệm vụ đang hoạt động"

# TODO: Translation updated at 2026-01-26 03:21

# game/locations/main_house/myroom.rpy:27
translate english myroom_71fb3107:

    # "Теперь вы можете управлять временем суток"
    "Bây giờ bạn có thể điều khiển thời gian trong ngày"

# game/locations/main_house/myroom.rpy:28
translate english myroom_a6aee4e7:

    # "Нажмите на значок в правом верхнем углу, чтобы сменить время"
    "Nhấn vào biểu tượng ở góc trên bên phải để đổi thời gian"

# game/locations/main_house/myroom.rpy:33
translate english myroom_b9554520:

    # "Также вам доступна книга персонажей"
    "Bạn cũng có thể sử dụng sách nhân vật"

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/myroom.rpy:27
translate english myroom_ac4e4f25:

    # "Теперь ты можешь управлять временем суток"
    "Giờ cậu có thể điều khiển thời gian trong ngày"

# game/locations/main_house/myroom.rpy:28
translate english myroom_6784fea3:

    # "Нажми на значок в правом верхнем углу, чтобы сменить время"
    "Nhấn vào biểu tượng ở góc trên bên phải để đổi thời gian"

# game/locations/main_house/myroom.rpy:33
translate english myroom_b3480ee4:

    # "Также тебе доступна книга персонажей"
    "Cậu cũng có thể sử dụng sách nhân vật"

# game/locations/main_house/myroom.rpy:36
translate english myroom_030a80cc:

    # "В ней ты можешь посмотреть описание каждой девушки и текущий уровень отношений"
    "Trong đó cậu có thể xem mô tả của từng cô gái và mức độ quan hệ hiện tại"

