﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/mc_events.rpy:84
translate english gg_intro_57d9b303:

    # gg "Чёрт . . . конец месяца"
    gg "Chết tiệt… cuối tháng rồi"

# game/characters_events_idles/mc_events.rpy:86
translate english gg_intro_fc2b37ea:

    # gg "Скоро платить по долгам . . ."
    gg "Sắp phải trả nợ rồi…"

# game/characters_events_idles/mc_events.rpy:88
translate english gg_intro_a14d12e5:

    # gg "Ладно . . . хоть сегодня выходной"
    gg "Được rồi… ít ra hôm nay là ngày nghỉ"

# game/characters_events_idles/mc_events.rpy:89
translate english gg_intro_76bd858b:

    # gg "Хоть что-то"
    gg "Ít ra cũng được gì đó"

# game/characters_events_idles/mc_events.rpy:91
translate english gg_intro_808930b3:

    # gg "Может, хоть пару часов отдохну. . . {w}просто расслаблюсь"
    gg "Có lẽ ít nhất vài tiếng tôi sẽ được nghỉ… {w}chỉ thư giãn thôi"

# game/characters_events_idles/mc_events.rpy:98
translate english gg_intro_df03d227:

    # gg "Ну хоть здесь кто-то есть . . ."
    gg "À, ít nhất ở đây có ai đó…"

# game/characters_events_idles/mc_events.rpy:102
translate english gg_intro_9b1348ec:

    # gg "Найс, я их разнес"
    gg "Hay đấy, tôi đã đập tan chúng"

# game/characters_events_idles/mc_events.rpy:104
translate english gg_intro_f004ad75:

    # gg "Ладно . . . бывает"
    gg "Được rồi… chuyện thường thôi"

# game/characters_events_idles/mc_events.rpy:105
translate english gg_intro_3aef7ac5:

    # gg "Следующая будет норм"
    gg "Trận sau sẽ ổn"

# game/characters_events_idles/mc_events.rpy:107
translate english gg_intro_f6ebf694:

    # gg "бляя . . ."
    gg "Địt mẹ…"

# game/characters_events_idles/mc_events.rpy:111
translate english gg_intro_e7a753f9:

    # gg "вот суки"
    gg "Lũ khốn"

# game/characters_events_idles/mc_events.rpy:112
translate english gg_intro_3a97b002:

    # gg "Окей ладно супер последняя на победу"
    gg "Được rồi, được rồi, siêu phẩm cuối cùng để thắng"

# game/characters_events_idles/mc_events.rpy:114
translate english gg_intro_94d70a59:

    # gg "{sc}{size=*1.5}СУКА!{/size}{/sc}" with vpunch
    gg "{sc}{size=*1.5}ĐỊT MẸ!{/size}{/sc}" with vpunch

# game/characters_events_idles/mc_events.rpy:118
translate english gg_intro_08de7acc:

    # gg "Да пошло оно всё . . ."
    gg "Mẹ kiếp tất cả…"

# game/characters_events_idles/mc_events.rpy:119
translate english gg_intro_62b01796:

    # gg "Какая же трата времени"
    gg "Thật là phí thời gian"

# game/characters_events_idles/mc_events.rpy:122
translate english gg_intro_55fbce1e:

    # gg "Выходной . . . единственный день . . ."
    gg "Ngày nghỉ… ngày duy nhất…"

# game/characters_events_idles/mc_events.rpy:123
translate english gg_intro_f0abf492:

    # gg "И я просто убил его на эту грёбаную игру"
    gg "Và tôi đã phí nó vào cái trò chơi chết tiệt này"

# game/characters_events_idles/mc_events.rpy:125
translate english gg_intro_d924704e:

    # gg "Экран это единственное с чем я общаюсь последнее время"
    gg "Màn hình là thứ duy nhất tôi giao tiếp dạo gần đây"

# game/characters_events_idles/mc_events.rpy:131
translate english gg_intro_59ed329a:

    # gg "Я живу здесь . . . но эта квартира"
    gg "Tôi sống ở đây… nhưng căn hộ này"

# game/characters_events_idles/mc_events.rpy:132
translate english gg_intro_0d6c2d2c:

    # gg "Просто точка между работой и снова работой"
    gg "Chỉ là một điểm nối giữa công việc và lại công việc"

# game/characters_events_idles/mc_events.rpy:140
translate english gg_intro_7ce95d1c:

    # gg "Только там . . ."
    gg "Chỉ ở đó…"

# game/characters_events_idles/mc_events.rpy:142
translate english gg_intro_fa2b02fe:

    # gg "Я чувствовал себя живым"
    gg "Tôi cảm thấy mình đang sống"

# game/characters_events_idles/mc_events.rpy:144
translate english gg_intro_5a38b375:

    # gg "Я . . . устал так жить"
    gg "Tôi… mệt mỏi vì sống như vậy"

# game/characters_events_idles/mc_events.rpy:164
translate english gg_intro_eb77ecfa:

    # gg "Да иду я, иду . . ."
    gg "Rồi, tôi đang đến, đang đến…"

# game/characters_events_idles/mc_events.rpy:168
translate english gg_intro_565267c5:

    # gg "Кто там?"
    gg "Ai đó？"

# game/characters_events_idles/mc_events.rpy:173
translate english gg_intro_60b12a13:

    # gg "Ты кто?"
    gg "Anh là ai？"

# game/characters_events_idles/mc_events.rpy:175
translate english gg_intro_e00854e1:

    # PostMan "Я почтальон"
    PostMan "Tôi là nhân viên đưa thư"

# game/characters_events_idles/mc_events.rpy:176
translate english gg_intro_0715dd94:

    # gg "Почтальоны теперь так одеваются?"
    gg "Nhân viên đưa thư giờ ăn mặc như này à？"

# game/characters_events_idles/mc_events.rpy:178
translate english gg_intro_0d42e0ef:

    # PostMan "Вот смотри для тебя нарисовали"
    PostMan "Đây, xem này, người ta vẽ cho cậu"

# game/characters_events_idles/mc_events.rpy:180
translate english gg_intro_e75db202:

    # PostMan "А я одеваюсь как хочу"
    PostMan "Còn tôi ăn mặc theo ý tôi"

# game/characters_events_idles/mc_events.rpy:181
translate english gg_intro_615e77bc:

    # gg "Так а посылка?"
    gg "Vậy còn bưu kiện？"

# game/characters_events_idles/mc_events.rpy:183
translate english gg_intro_096cd512:

    # PostMan "А! сейчас"
    PostMan "À! Ngay đây"

# game/characters_events_idles/mc_events.rpy:185
translate english gg_intro_0d3968a6:

    # PostMan "Вот, ты же [povname] правильно?"
    PostMan "Đây, cậu là [povname] đúng không？"

# game/characters_events_idles/mc_events.rpy:187
translate english gg_intro_df24437b:

    # gg "Да, спасибо"
    gg "Đúng, cảm ơn"

# game/characters_events_idles/mc_events.rpy:189
translate english gg_intro_d7f65fd8:

    # PostMan "Доставка уже оплачена, так что до свидания"
    PostMan "Phí giao hàng đã được trả rồi, nên chào nhé"

# game/characters_events_idles/mc_events.rpy:196
translate english gg_intro_94ec24eb:

    # gg_chat "Эта квартира слишком дорого мне обходится"
    gg_chat "Căn hộ này ngốn của tôi quá nhiều tiền"

# game/characters_events_idles/mc_events.rpy:200
translate english gg_intro_083c370e:

    # gg_chat "Эти долги меня скоро сьедят"
    gg_chat "Mấy khoản nợ này sắp nuốt chửng tôi rồi"

# game/characters_events_idles/mc_events.rpy:203
translate english gg_intro_a7a8221e:

    # gg_chat "Что? {w}Линда?"
    gg_chat "Gì？ {w}Linda？"

# game/characters_events_idles/mc_events.rpy:208
translate english gg_intro_98898eb6:

    # gg_chat "От бабушки . . ."
    gg_chat "Từ bà…"

# game/characters_events_idles/mc_events.rpy:210
translate english gg_intro_3341868c:

    # gg_chat "Давно не видел её . . ."
    gg_chat "Lâu rồi không gặp bà…"

# game/characters_events_idles/mc_events.rpy:211
translate english gg_intro_6f756f5d:

    # gg_chat "Зачем она мне это?"
    gg_chat "Sao bà lại gửi cái này cho tôi？"

# game/characters_events_idles/mc_events.rpy:212
translate english gg_intro_9f5ccf2a:

    # "Дорогой мой, [povname]"
    "Cháu yêu quý của bà, [povname]"

# game/characters_events_idles/mc_events.rpy:213
translate english gg_intro_7d8221c5:

    # "Пишу тебе это письмо с особым волнением — не потому, что что-то случилось"
    "Bà viết cho cháu lá thư này với một nỗi xúc động đặc biệt — không phải vì có chuyện gì xảy ra"

# game/characters_events_idles/mc_events.rpy:214
translate english gg_intro_bb3819ba:

    # "А потому, что скоро мне предстоит небольшое, но долгое путешествие"
    "Mà vì sắp tới bà sẽ có một chuyến đi không lớn nhưng kéo dài"

# game/characters_events_idles/mc_events.rpy:215
translate english gg_intro_a901876a:

    # "С тех пор, как ты уехал, тут многое стало тише, спокойнее"
    "Từ khi cháu đi, ở đây nhiều thứ đã trở nên yên tĩnh hơn, bình lặng hơn"

# game/characters_events_idles/mc_events.rpy:216
translate english gg_intro_8aaddaf9:

    # "Но рядом всё ещё живут хорошие люди — кто-то поможет, если нужно, кто-то просто заглянет поболтать"
    "Nhưng xung quanh vẫn còn những người tốt — có người sẽ giúp nếu cần, có người chỉ ghé qua để trò chuyện"

# game/characters_events_idles/mc_events.rpy:217
translate english gg_intro_8049e805:

    # "Дом, в котором ты вырос летом, скоро останется без хозяйки . . ."
    "Ngôi nhà nơi cháu lớn lên vào mùa hè, sắp tới sẽ không còn người chủ…"

# game/characters_events_idles/mc_events.rpy:218
translate english gg_intro_7713047b:

    # "И мне очень бы не хотелось, чтобы он начал ветшать"
    "Và bà rất không muốn nó bắt đầu xuống cấp"

# game/characters_events_idles/mc_events.rpy:220
translate english gg_intro_ce9ad3bf:

    # "Я уезжаю на несколько лет — не волнуйся, здоровье моё в порядке, просто пришло время пожить немного иначе"
    "Bà đi vài năm — cháu đừng lo, sức khỏe bà vẫn ổn, chỉ là đã đến lúc sống một chút theo cách khác"


# game/characters_events_idles/mc_events.rpy:221
translate english gg_intro_56cba277:

    # "Пока меня не будет, хочу тебя попросить заглядывать в дом"
    "Trong lúc bà không có ở đây, bà muốn nhờ cháu ghé qua ngôi nhà"

# game/characters_events_idles/mc_events.rpy:222
translate english gg_intro_9768b114:

    # "Пусть не пустеет, пусть скрипят половицы, пусть греется чайник"
    "Để nó không trống vắng, để sàn nhà vẫn kẽo kẹt, để ấm trà vẫn được hâm nóng"

# game/characters_events_idles/mc_events.rpy:223
translate english gg_intro_040e7339:

    # "Он живой, наш дом — если забросить, начнёт хандрить"
    "Nó sống đấy, ngôi nhà của chúng ta — nếu bị bỏ mặc, nó sẽ bắt đầu buồn rầu"

# game/characters_events_idles/mc_events.rpy:224
translate english gg_intro_581165e6:

    # gg "Она всегда так говорила . . . {w}будто дом — живой"
    gg "Bà ấy luôn nói như vậy… {w}như thể ngôi nhà là một sinh thể sống"

# game/characters_events_idles/mc_events.rpy:226
translate english gg_intro_82ffc349:

    # "И ещё . . . цветы"
    "Và còn nữa… hoa"

# game/characters_events_idles/mc_events.rpy:227
translate english gg_intro_3c7f2026:

    # "Мои две любимые. Они остались"
    "Hai loài hoa bà yêu thích. Chúng vẫn còn đó"

# game/characters_events_idles/mc_events.rpy:228
translate english gg_intro_a2adc801:

    # "Одна крепкая, корнями в землю, упрямая, немного колючая, зато как зацветёт — всем на удивление"
    "Một cây khỏe khoắn, rễ bám chặt vào đất, bướng bỉnh, hơi có gai, nhưng khi nở hoa — khiến mọi người kinh ngạc"

# game/characters_events_idles/mc_events.rpy:229
translate english gg_intro_d1748522:

    # "Вторая — лёгкая, солнечная, смеётся даже в дождь, растёт, куда глянет, и всё ей в радость"
    "Cây còn lại — nhẹ nhàng, rạng rỡ, cười cả trong mưa, mọc theo hướng nó nhìn, và mọi thứ đều làm nó vui"

# game/characters_events_idles/mc_events.rpy:231
translate english gg_intro_5cd83b3b:

    # gg_chat "Причем здесь цветы вообще . . ."
    gg_chat "Hoa thì liên quan gì ở đây chứ…"

# game/characters_events_idles/mc_events.rpy:232
translate english gg_intro_d87a1c8d:

    # "Уход у них разный, но суть одна — внимание"
    "Cách chăm sóc chúng khác nhau, nhưng cốt lõi chỉ một — sự quan tâm"

# game/characters_events_idles/mc_events.rpy:233
translate english gg_intro_0733c9df:

    # "Ты справишься — у тебя ведь моё упрямство и моё сердце"
    "Cháu sẽ làm được — cháu có sự bướng bỉnh và trái tim của bà mà"

# game/characters_events_idles/mc_events.rpy:234
translate english gg_intro_3406a366:

    # "Очень хочу, чтобы ты оказался там пораньше — дом ждёт тебя"
    "Bà rất muốn cháu có mặt ở đó sớm hơn — ngôi nhà đang chờ cháu"

# game/characters_events_idles/mc_events.rpy:235
translate english gg_intro_bfcc2649:

    # "С любовью"
    "Với tình yêu thương"

# game/characters_events_idles/mc_events.rpy:236
translate english gg_intro_3f6a1326:

    # "Твоя бабушка Линда"
    "Bà của cháu, Linda"

# game/characters_events_idles/mc_events.rpy:238
translate english gg_intro_22bce088:

    # gg_chat "Бабушка была всегда рядом, её дом был моим домом"
    gg_chat "Bà luôn ở bên cạnh, nhà của bà là nhà của tôi"

# game/characters_events_idles/mc_events.rpy:240
translate english gg_intro_4164e503:

    # gg_chat "Зачем она меня просит присматривать за домом?"
    gg_chat "Sao bà lại nhờ tôi trông coi ngôi nhà？"

# game/characters_events_idles/mc_events.rpy:242
translate english gg_intro_ad05e118:

    # gg_chat "Просто взять и уехать?"
    gg_chat "Chỉ đơn giản là bỏ đi vậy sao？"

# game/characters_events_idles/mc_events.rpy:244
translate english gg_intro_0ae1f5e0:

    # gg_chat "Будто у меня тут ничего нет"
    gg_chat "Cứ như thể tôi chẳng có gì ở đây vậy"

# game/characters_events_idles/mc_events.rpy:246
translate english gg_intro_e3e17f69:

    # gg_chat "У меня своих проблем по горло"
    gg_chat "Tôi đã có đầy rẫy vấn đề của riêng mình rồi"

# game/characters_events_idles/mc_events.rpy:248
translate english gg_intro_4810f11e:

    # gg_chat "Чёрт я опаздываю"
    gg_chat "Chết tiệt, tôi đang trễ"

# game/characters_events_idles/mc_events.rpy:250
translate english gg_intro_3aa5e105:

    # gg_chat "Потом поем"
    gg_chat "Lát nữa sẽ ăn"

# game/characters_events_idles/mc_events.rpy:254
translate english gg_intro_4a0266b9:

    # gg_chat "Я отвечу бабушка попозже"
    gg_chat "Bà ơi, lát nữa cháu sẽ trả lời"

# game/characters_events_idles/mc_events.rpy:261
translate english gg_intro_9cdabec6:

    # gg_chat "Серьёзно? . . ."
    gg_chat "Thật á？ …"

# game/characters_events_idles/mc_events.rpy:265
translate english gg_intro_7331a474:

    # gg_chat "Блять . . ."
    gg_chat "Địt mẹ…"

# game/characters_events_idles/mc_events.rpy:266
translate english gg_intro_db310e96:

    # gg_chat "Как всегда"
    gg_chat "Như mọi khi"

# game/characters_events_idles/mc_events.rpy:270
translate english gg_intro_4b9afd3e:

    # gg "Я пришел"
    gg "Tôi đến rồi"

# game/characters_events_idles/mc_events.rpy:272
translate english gg_intro_80d3fcff:

    # Assistant "Опоздал. Как всегда"
    Assistant "Trễ rồi. Như mọi khi"

# game/characters_events_idles/mc_events.rpy:274
translate english gg_intro_d3b968fb:

    # Assistant "И напомню: если продолжишь {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "Và tôi nhắc lại: nếu cậu tiếp tục {w}thì chuyện giảm lương chỉ còn là vấn đề thời gian"

# game/characters_events_idles/mc_events.rpy:276
translate english gg_intro_0bd28ad3:

    # gg_chat "Да, конечно"
    gg_chat "Vâng, tất nhiên"

# game/characters_events_idles/mc_events.rpy:285
translate english gg_intro_603b869e:

    # Director "Это срочно"
    Director "Việc này gấp"

# game/characters_events_idles/mc_events.rpy:287
translate english gg_intro_eac333f5:

    # Director "За Петрова сделаешь"
    Director "Làm thay Petrov đi"

# game/characters_events_idles/mc_events.rpy:289
translate english gg_intro_2ccd9b60:

    # gg "Это не мои задачи"
    gg "Đó không phải việc của tôi"

# game/characters_events_idles/mc_events.rpy:290
translate english gg_intro_df8035b4:

    # gg "Почему я должен работать за другого"
    gg "Tại sao tôi phải làm việc thay người khác？"

# game/characters_events_idles/mc_events.rpy:292
translate english gg_intro_e2eb6337:

    # Director "Мне плевать"
    Director "Tao đéo quan tâm"

# game/characters_events_idles/mc_events.rpy:294
translate english gg_intro_66f2f5ce:

    # Director "Сделаешь всё до конца недели"
    Director "Làm xong hết trước cuối tuần"

# game/characters_events_idles/mc_events.rpy:297
translate english gg_intro_b7d7b4b2:

    # Director "Не успеешь — сам знаешь последствия"
    Director "Không kịp thì — mày tự biết hậu quả"

# game/characters_events_idles/mc_events.rpy:303
translate english gg_intro_3d5010f4:

    # gg_chat "Им всегда плевать"
    gg_chat "Bọn họ lúc nào cũng đéo quan tâm"

# game/characters_events_idles/mc_events.rpy:304
translate english gg_intro_1670588b:

    # gg_chat "Я здесь просто расходник"
    gg_chat "Tôi ở đây chỉ là đồ tiêu hao"

# game/characters_events_idles/mc_events.rpy:308
translate english gg_intro_3c056c18:

    # gg_chat "Сколько ни делай — конца нет"
    gg_chat "Làm bao nhiêu cũng không có hồi kết"

# game/characters_events_idles/mc_events.rpy:321
translate english gg_intro_577e1c14:

    # Director "Секретарша сказала"
    Director "Cô thư ký nói rồi"

# game/characters_events_idles/mc_events.rpy:324
translate english gg_intro_e2282b24:

    # Director "Что ты опоздал"
    Director "Rằng mày đến trễ"

# game/characters_events_idles/mc_events.rpy:326
translate english gg_intro_009afbde:

    # Director "Если не сдашь это в срок"
    Director "Nếu không nộp đúng hạn"

# game/characters_events_idles/mc_events.rpy:327
translate english gg_intro_e8f982f1:

    # Director "Можешь искать новую работу"
    Director "Thì cứ tìm việc mới đi"

# game/characters_events_idles/mc_events.rpy:329
translate english gg_intro_5d67e1da:

    # Director "Понял?"
    Director "Hiểu chưa？"

# game/characters_events_idles/mc_events.rpy:330
translate english gg_intro_ef555dd8:

    # gg_chat "Вот сука"
    gg_chat "Đúng là đồ khốn"

# game/characters_events_idles/mc_events.rpy:332
translate english gg_intro_e967e307:

    # gg "Да"
    gg "Vâng"

# game/characters_events_idles/mc_events.rpy:340
translate english gg_intro_aba5df1c:

    # gg_chat "Им всё равно — значит, и мне тоже"
    gg_chat "Bọn họ chẳng bận tâm — vậy thì tôi cũng vậy"

# game/characters_events_idles/mc_events.rpy:342
translate english gg_intro_59df236a:

    # gg_chat "С меня довольно"
    gg_chat "Thế là đủ cho tôi rồi"

# game/characters_events_idles/mc_events.rpy:344
translate english gg_intro_c0a84961:

    # gg_chat "Не поспешил ли я?"
    gg_chat "Có phải tôi đã vội quá không？"

# game/characters_events_idles/mc_events.rpy:346
translate english gg_intro_a632776e:

    # gg_chat "Хватит"
    gg_chat "Đủ rồi"

# game/characters_events_idles/mc_events.rpy:355
translate english gg_intro_14d66a18:

    # Director "Ты вообще, что делаешь"
    Director "Mày đang làm cái quái gì vậy？"

# game/characters_events_idles/mc_events.rpy:357
translate english gg_intro_dfc9c282:

    # gg "Я увольняюсь"
    gg "Tôi nghỉ việc"

# game/characters_events_idles/mc_events.rpy:359
translate english gg_intro_8543ef20:

    # Director "Как ты смеешь??"
    Director "Mày dám à？？"

# game/characters_events_idles/mc_events.rpy:371
translate english gg_intro_1a1334a8:

    # Assistant "Ой"
    Assistant "Ôi"

# game/characters_events_idles/mc_events.rpy:373
translate english gg_intro_11803396:

    # Assistant "Ты что делаешь!?"
    Assistant "Cậu đang làm gì vậy!？"

# game/characters_events_idles/mc_events.rpy:374
translate english gg_intro_b31c2e41:

    # gg "Счастливо оставаться"
    gg "Chúc ở lại vui vẻ"

# game/characters_events_idles/mc_events.rpy:376
translate english gg_intro_96fd98eb:

    # gg_chat "Наконец-то"
    gg_chat "Cuối cùng thì"

# game/characters_events_idles/mc_events.rpy:378
translate english gg_intro_e446a106:

    # gg_chat "Моя привычная жизнь закончилась"
    gg_chat "Cuộc sống quen thuộc của tôi đã kết thúc"

# game/characters_events_idles/mc_events.rpy:382
translate english gg_intro_724c298c:

    # gg_chat "На улице столько парочек гуляет"
    gg_chat "Ngoài phố có bao nhiêu cặp đôi đang đi dạo"

# game/characters_events_idles/mc_events.rpy:383
translate english gg_intro_acc56f85:

    # gg_chat "Жизнь будто проходит мимо"
    gg_chat "Cuộc sống cứ như đang trôi qua bên cạnh"

# game/characters_events_idles/mc_events.rpy:397
translate english gg_intro_a57d47f4:

    # gg_chat "Я даже не заметил"
    gg_chat "Tôi thậm chí còn không nhận ra"

# game/characters_events_idles/mc_events.rpy:399
translate english gg_intro_1ba141ba:

    # gg_chat "Только у моего родного дома был такой ключ"
    gg_chat "Chỉ ngôi nhà thân yêu của tôi mới có chiếc chìa khóa như thế"

# game/characters_events_idles/mc_events.rpy:401
translate english gg_intro_cfb8599b:

    # gg_chat "Это шанс"
    gg_chat "Đây là cơ hội"

# game/characters_events_idles/mc_events.rpy:402
translate english gg_intro_3ce8ccb4:

    # gg_chat "На новую жизнь"
    gg_chat "Cho một cuộc sống mới"

# game/characters_events_idles/mc_events.rpy:404
translate english gg_intro_4db85a28:

    # gg_chat "Это все мне больше не нужно"
    gg_chat "Tôi không cần tất cả những thứ này nữa"

# game/characters_events_idles/mc_events.rpy:414
translate english gg_intro_c3f38f42:

    # gg_chat "Пора начать сначала"
    gg_chat "Đã đến lúc bắt đầu lại từ đầu"

# game/characters_events_idles/mc_events.rpy:422
translate english gg_intro_07728fd6:

    # gg_chat "После города — будто другой мир"
    gg_chat "Sau thành phố — cứ như một thế giới khác"

# game/characters_events_idles/mc_events.rpy:424
translate english gg_intro_fe890fb1:

    # gg_chat "Даже к этому я отвык . . ."
    gg_chat "Ngay cả điều này tôi cũng đã không còn quen…"

# game/characters_events_idles/mc_events.rpy:428
translate english gg_intro_cac1bf85:

    # gg_chat "Мне здесь придётся многому научиться"
    gg_chat "Ở đây tôi sẽ phải học hỏi nhiều thứ"

# game/characters_events_idles/mc_events.rpy:431
translate english gg_intro_a05332c8:

    # gg_chat "Я даже позабыл где дом . . ."
    gg_chat "Tôi thậm chí đã quên mất nhà ở đâu…"

# game/characters_events_idles/mc_events.rpy:433
translate english gg_intro_a4a7b296:

    # gg_chat "Все кого я вижу со мной здороваются"
    gg_chat "Tất cả những người tôi gặp đều chào tôi"

# game/characters_events_idles/mc_events.rpy:434
translate english gg_intro_720fce13:

    # gg_chat "Будто я тут не чужой"
    gg_chat "Cứ như thể tôi không phải người xa lạ ở đây"

# game/characters_events_idles/mc_events.rpy:435
translate english gg_intro_094d1de6:

    # UnknownGirl "Эй парень, постой-ка!"
    UnknownGirl "Này anh bạn, đợi chút!"

# game/characters_events_idles/mc_events.rpy:437
translate english gg_intro_050bbcbc:

    # gg "Здравствуйте"
    gg "Xin chào"

# game/characters_events_idles/mc_events.rpy:439
translate english gg_intro_0e31fcad:

    # UnknownGirl "Давно тут новых лиц не видели"
    UnknownGirl "Lâu lắm rồi ở đây không thấy gương mặt mới"

# game/characters_events_idles/mc_events.rpy:441
translate english gg_intro_0ea7d489:

    # gg "Да только приехал"
    gg "Vâng, tôi vừa mới đến"

# game/characters_events_idles/mc_events.rpy:443
translate english gg_intro_a55c0f0a:

    # UnknownGirl "У нас тут новым людям всегда рады"
    UnknownGirl "Ở đây chúng tôi luôn chào đón người mới"

# game/characters_events_idles/mc_events.rpy:445
translate english gg_intro_096f2b23:

    # UnknownGirl "Только вот"
    UnknownGirl "Chỉ có điều…"

# game/characters_events_idles/mc_events.rpy:446
translate english gg_intro_83909d33:

    # UnknownGirl "Настоящих мужчин не хватает"
    UnknownGirl "Thiếu đàn ông thực sự"

# game/characters_events_idles/mc_events.rpy:448
translate english gg_intro_8ffcdc07:

    # gg_chat "Что она вообще имеет в виду?"
    gg_chat "Cô ấy rốt cuộc muốn nói gì？"

# game/characters_events_idles/mc_events.rpy:450
translate english gg_intro_f312c19f:

    # UnknownGirl "Ладно, не пугайся. Шучу"
    UnknownGirl "Thôi nào, đừng sợ. Tôi đùa thôi"

# game/characters_events_idles/mc_events.rpy:452
translate english gg_intro_af75b79f:

    # UnknownGirl "Если что то нужно будет спрашивай помощь у любого"
    UnknownGirl "Nếu cần gì thì cứ nhờ bất kỳ ai giúp"

# game/characters_events_idles/mc_events.rpy:454
translate english gg_intro_f35a0bb9:

    # UnknownGirl "Удачи тебе"
    UnknownGirl "Chúc anh may mắn"

# game/characters_events_idles/mc_events.rpy:456
translate english gg_intro_6a134ac2:

    # gg "Хорошо и вам отличного дня"
    gg "Được, chúc cô một ngày tốt lành"

# game/characters_events_idles/mc_events.rpy:458
translate english gg_intro_b0f731c4:

    # gg_chat "Какая необычно добрая девушка"
    gg_chat "Một cô gái tốt bụng lạ thường"

# game/characters_events_idles/mc_events.rpy:459
translate english gg_intro_b08ae0cc:

    # gg_chat "Бабушка похоже говорила правду о людях здесь"
    gg_chat "Có vẻ bà đã nói đúng về những người ở đây"

# game/characters_events_idles/mc_events.rpy:463
translate english gg_intro_b07cdeca:

    # gg_chat "А если там уже не так, как я помню?"
    gg_chat "Nhưng nếu ở đó không còn như tôi nhớ thì sao？"

# game/characters_events_idles/mc_events.rpy:465
translate english gg_intro_2c26269d:

    # gg_chat "Но назад пути нет"
    gg_chat "Nhưng không có đường quay lại"

# game/characters_events_idles/mc_events.rpy:474
translate english gg_intro_9b8edceb:

    # gg_chat "Да дом поменялся"
    gg_chat "Đúng, ngôi nhà đã thay đổi"

# game/characters_events_idles/mc_events.rpy:482
translate english gg_intro_766d518e:

    # gg_chat "Кто-то есть?"
    gg_chat "Có ai ở đây không？"

# game/characters_events_idles/mc_events.rpy:492
translate english gg_intro_b989363c:

    # gg ". . ."
    gg ". . ."

# game/characters_events_idles/mc_events.rpy:498
translate english gg_intro_7ad2e1b7:

    # Sonya "АААА!"
    Sonya "АААА!"

# game/characters_events_idles/mc_events.rpy:500
translate english gg_intro_684edc0b:

    # Sonya "МАЯ!"
    Sonya "MAYA!"

# game/characters_events_idles/mc_events.rpy:502
translate english gg_intro_1124aafa:

    # Sonya "МАЯ, ТУТ КТО-ТО ЕСТЬ!!"
    Sonya "MAYA, Ở ĐÂY CÓ NGƯỜI!!"

# game/characters_events_idles/mc_events.rpy:506
translate english gg_intro_cba5cc13:

    # gg_chat "Что это сейчас было? . . ."
    gg_chat "Vừa rồi là cái gì vậy？ …"

# game/characters_events_idles/mc_events.rpy:508
translate english gg_intro_74014e3a:

    # gg_chat "Я . . ."
    gg_chat "Tôi…"

# game/characters_events_idles/mc_events.rpy:510
translate english gg_intro_8b3408ac:

    # gg_chat "Я ничего не понял"
    gg_chat "Tôi chẳng hiểu gì cả"

# game/characters_events_idles/mc_events.rpy:515
translate english gg_intro_18e79df2:

    # Maya "Ты кто такой?"
    Maya "Anh là ai？"

# game/characters_events_idles/mc_events.rpy:517
translate english gg_intro_35cf3bf6:

    # Maya "Убирайся отсюда. Сейчас же"
    Maya "Cút khỏi đây. Ngay lập tức"

# game/characters_events_idles/mc_events.rpy:519
translate english gg_intro_be5ef2a9:

    # gg "Стой подожди"
    gg "Khoan, đợi đã"

# game/characters_events_idles/mc_events.rpy:521
translate english gg_intro_8750b79b:

    # gg "Я внук хозяйки дома"
    gg "Tôi là cháu trai của chủ ngôi nhà"

# game/characters_events_idles/mc_events.rpy:523
translate english gg_intro_eba62b3e:

    # gg "Это дом моей бабушки"
    gg "Đây là nhà của bà tôi"

# game/characters_events_idles/mc_events.rpy:525
translate english gg_intro_d179509d:

    # Maya "Внук?"
    Maya "Cháu trai？"

# game/characters_events_idles/mc_events.rpy:527
translate english gg_intro_cb51aa26:

    # Maya "Что то я такого внука никогда здесь не видела"
    Maya "Thế mà tôi chưa từng thấy đứa cháu trai nào như vậy ở đây"

# game/characters_events_idles/mc_events.rpy:529
translate english gg_intro_fde7546c:

    # Maya "Думаешь я совсем тупая"
    Maya "Anh nghĩ tôi hoàn toàn ngu ngốc à？"

# game/characters_events_idles/mc_events.rpy:531
translate english gg_intro_a41fbef3:

    # gg "Подожди"
    gg "Đợi đã"

# game/characters_events_idles/mc_events.rpy:533
translate english gg_intro_0df5d29f:

    # gg "Я не знал, что здесь кто-то живёт"
    gg "Tôi không biết ở đây có người sống"

# game/characters_events_idles/mc_events.rpy:535
translate english gg_intro_4b24971a:

    # Maya "Конечно не знал"
    Maya "Tất nhiên là không biết rồi"

# game/characters_events_idles/mc_events.rpy:537
translate english gg_intro_4af9c6fc:

    # Maya "А в чужие дома ты тоже «случайно» заходишь?"
    Maya "Còn vào nhà người khác thì anh cũng «vô tình» bước vào chứ？"

# game/characters_events_idles/mc_events.rpy:543
translate english gg_intro_2a307bc4:

    # gg "Вот"
    gg "Đây"

# game/characters_events_idles/mc_events.rpy:545
translate english gg_intro_c9e9dab5:

    # gg "Это письмо от моей бабушки"
    gg "Đây là lá thư của bà tôi"

# game/characters_events_idles/mc_events.rpy:547
translate english gg_intro_4a769d1b:

    # gg "Она попросила меня присмотреть за домом"
    gg "Bà nhờ tôi trông coi ngôi nhà"

# game/characters_events_idles/mc_events.rpy:549
translate english gg_intro_ee0d1154:

    # Maya "И ты думаешь, я просто поверю этой бумажке?"
    Maya "Và anh nghĩ tôi sẽ chỉ tin vào tờ giấy này sao？"

# game/characters_events_idles/mc_events.rpy:551
translate english gg_intro_6d39543d:

    # gg "Я никуда не спешу"
    gg "Tôi không vội đi đâu cả"

# game/characters_events_idles/mc_events.rpy:563
translate english gg_intro_8ea26f73:

    # Maya "Дорогой"
    Maya "Cháu thân yêu"

# game/characters_events_idles/mc_events.rpy:565
translate english gg_intro_9a149321:

    # Maya "[povname]"
    Maya "[povname]"

# game/characters_events_idles/mc_events.rpy:569
translate english gg_intro_6e311c65:

    # Maya "Скоро останется без хозяйки"
    Maya "Sắp không còn bà chủ"

# game/characters_events_idles/mc_events.rpy:571
translate english gg_intro_2d481ec2:

    # Maya "Уезжаю на несколько лет"
    Maya "Bà đi vài năm"

# game/characters_events_idles/mc_events.rpy:573
translate english gg_intro_cada9fb7:

    # Maya "Мои цветы две любимые. Они остались"
    Maya "Hai loài hoa bà yêu thích. Chúng vẫn còn đó"

# game/characters_events_idles/mc_events.rpy:575
translate english gg_intro_4e84a3f6:

    # Maya "Дом ждёт тебя"
    Maya "Ngôi nhà đang chờ cháu"

# game/characters_events_idles/mc_events.rpy:577
translate english gg_intro_a2cdc4ac:

    # Maya "Твоя бабушка Линда"
    Maya "Bà của cháu, Linda"

# game/characters_events_idles/mc_events.rpy:582
translate english gg_intro_dfc10494:

    # Maya "Боже ладно"
    Maya "Trời ạ, được rồi"

# game/characters_events_idles/mc_events.rpy:583
translate english gg_intro_c4340902:

    # Maya "Похоже, на правду"
    Maya "Có vẻ đúng là thật"

# game/characters_events_idles/mc_events.rpy:585
translate english gg_intro_329e21f7:

    # Maya "Но это ничего не меняет"
    Maya "Nhưng điều đó chẳng thay đổi gì cả"

# game/characters_events_idles/mc_events.rpy:587
translate english gg_intro_dd6c3bfe:

    # Maya "Ты здесь чужой"
    Maya "Anh là người xa lạ ở đây"

# game/characters_events_idles/mc_events.rpy:589
translate english gg_intro_69801038:

    # gg "Вообще-то это мой дом"
    gg "Thực ra đây là nhà của tôi"

# game/characters_events_idles/mc_events.rpy:591
translate english gg_intro_9a295059:

    # Maya "Это ты мы с Соней решим!"
    Maya "Chuyện đó để tôi với Sonya quyết định!"

# game/characters_events_idles/mc_events.rpy:593
translate english gg_intro_9839e4df:

    # Maya "{sc}СОНЯ{/sc}" with hpunch
    Maya "{sc}SONYA{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:595
translate english gg_intro_2551f6f7:

    # Maya "Всё нормально, он не опасный"
    Maya "Mọi chuyện ổn, anh ta không nguy hiểm"

# game/characters_events_idles/mc_events.rpy:597
translate english gg_intro_d6a7eefb:

    # gg "Я так и сказал"
    gg "Tôi đã nói vậy mà"

# game/characters_events_idles/mc_events.rpy:599
translate english gg_intro_f3cf760b:

    # Maya "Слушай если ты хоть что-то сделаешь"
    Maya "Nghe đây, nếu anh làm bất cứ điều gì"

# game/characters_events_idles/mc_events.rpy:601
translate english gg_intro_d58555f3:

    # Maya "Я тебя мигом выгоню. Понял?"
    Maya "Tôi sẽ đuổi anh ngay lập tức. Hiểu chưa？"

# game/characters_events_idles/mc_events.rpy:603
translate english gg_intro_d96e5a49:

    # gg "Понял"
    gg "Hiểu rồi"

# game/characters_events_idles/mc_events.rpy:605
translate english gg_intro_a59664de:

    # Maya "Жди на кухне я передам письмо соне"
    Maya "Đợi ở bếp, tôi sẽ đưa lá thư cho Sonya"

# game/characters_events_idles/mc_events.rpy:612
translate english gg_intro_0ac91294:

    # gg_chat "Вот это встреча"
    gg_chat "Đúng là một cuộc gặp gỡ"

# game/characters_events_idles/mc_events.rpy:616
translate english gg_intro_baac99bc:

    # gg_chat "Я не ожидал такого"
    gg_chat "Tôi không ngờ lại như vậy"

# game/characters_events_idles/mc_events.rpy:618
translate english gg_intro_feaa3808:

    # gg_chat "Почему бабушка ничего не сказала?"
    gg_chat "Sao bà lại không nói gì？"

# game/characters_events_idles/mc_events.rpy:627
translate english gg_intro_a070649e:

    # Sonya "Эм . . . привет"
    Sonya "Ờm… chào anh"

# game/characters_events_idles/mc_events.rpy:629
translate english gg_intro_6a2024b3:

    # Sonya "Я . . . я Соня"
    Sonya "Tôi… tôi là Sonya"

# game/characters_events_idles/mc_events.rpy:631
translate english gg_intro_12083d44:

    # Sonya "Я надеюсь ты не обиделся на Маю"
    Sonya "Tôi hy vọng anh không giận Maya"

# game/characters_events_idles/mc_events.rpy:633
translate english gg_intro_dfe04d57:

    # gg "Нет. Всё нормально"
    gg "Không. Mọi chuyện ổn"

# game/characters_events_idles/mc_events.rpy:635
translate english gg_intro_85f8708a:

    # gg "Я [povname]"
    gg "Tôi là [povname]"

# game/characters_events_idles/mc_events.rpy:637
translate english gg_intro_78b27818:

    # Sonya "Мая сказала, что ты внук Линды"
    Sonya "Maya nói anh là cháu trai của Linda"

# game/characters_events_idles/mc_events.rpy:638
translate english gg_intro_b5f632a7:

    # Sonya "Так . . . неожиданно получилось"
    Sonya "Thật… bất ngờ quá"

# game/characters_events_idles/mc_events.rpy:643
translate english gg_intro_053ce261:

    # Sonya "И если честно"
    Sonya "Và nếu thành thật mà nói"

# game/characters_events_idles/mc_events.rpy:645
translate english gg_intro_4bf5a43d:

    # Sonya "Я сначала очень испугалась"
    Sonya "Lúc đầu tôi rất sợ"

# game/characters_events_idles/mc_events.rpy:649
translate english gg_intro_87cb5bde:

    # gg "Извини"
    gg "Xin lỗi"

# game/characters_events_idles/mc_events.rpy:651
translate english gg_intro_1dc14df3:

    # gg "Я правда не хотел тебя пугать, стоило постучать"
    gg "Tôi thật sự không muốn làm em sợ, lẽ ra tôi nên gõ cửa"

# game/characters_events_idles/mc_events.rpy:655
translate english gg_intro_2d8b9c21:

    # Sonya "Нет-нет всё нормально"
    Sonya "Không không, mọi chuyện ổn"

# game/characters_events_idles/mc_events.rpy:657
translate english gg_intro_9587b334:

    # Sonya "Просто не ожидали гостей"
    Sonya "Chỉ là chúng tôi không ngờ có khách"

# game/characters_events_idles/mc_events.rpy:661
translate english gg_intro_9a863e77:

    # Sonya "Я прочла письмо линды"
    Sonya "Tôi đã đọc lá thư của Linda"

# game/characters_events_idles/mc_events.rpy:663
translate english gg_intro_c7d51db6:

    # Sonya "Там про цветы было"
    Sonya "Trong đó có nói về hoa"

# game/characters_events_idles/mc_events.rpy:665
translate english gg_intro_c9e9d0a0:

    # Sonya "Это она так нас описывает"
    Sonya "Đó là cách bà ấy mô tả chúng tôi"

# game/characters_events_idles/mc_events.rpy:669
translate english gg_intro_7b39b9b5:

    # Sonya "Мы с Маей живём здесь вместе"
    Sonya "Tôi và Maya sống ở đây cùng nhau"

# game/characters_events_idles/mc_events.rpy:671
translate english gg_intro_c3003883:

    # Sonya "Линда сначала просто сдавала нам комнаты"
    Sonya "Ban đầu Linda chỉ cho chúng tôi thuê phòng"

# game/characters_events_idles/mc_events.rpy:673
translate english gg_intro_eb14c7b5:

    # Sonya "А потом, когда уехала, сказала, что дом остаётся на нас"
    Sonya "Rồi sau đó, khi đi, bà nói ngôi nhà sẽ để lại cho chúng tôi"

# game/characters_events_idles/mc_events.rpy:675
translate english gg_intro_6dcfd261:

    # gg "То есть вы тут уже давно?"
    gg "Tức là hai người ở đây lâu rồi？"

# game/characters_events_idles/mc_events.rpy:677
translate english gg_intro_c8772e87:

    # Sonya "Да"
    Sonya "Vâng"

# game/characters_events_idles/mc_events.rpy:679
translate english gg_intro_5e85de7c:

    # Sonya "Мы привыкли. Даже кота завели"
    Sonya "Chúng tôi quen rồi. Còn nuôi cả một con mèo"

# game/characters_events_idles/mc_events.rpy:681
translate english gg_intro_0879bf60:

    # Sonya "Для нас это уже дом"
    Sonya "Với chúng tôi, đây đã là nhà"

# game/characters_events_idles/mc_events.rpy:683
translate english gg_intro_dad9ef91:

    # Sonya "Линда иногда о тебе говорила"
    Sonya "Linda thỉnh thoảng có nói về anh"

# game/characters_events_idles/mc_events.rpy:685
translate english gg_intro_a3493fdc:

    # Sonya "Говорила, что ты хороший, по крайнее мерее в дестве"
    Sonya "Bà nói anh tốt bụng, ít nhất là hồi nhỏ"

# game/characters_events_idles/mc_events.rpy:687
translate english gg_intro_0782f2e3:

    # gg "Надеюсь, она не слишком приукрашивала"
    gg "Hy vọng bà không tô hồng quá mức"

# game/characters_events_idles/mc_events.rpy:689
translate english gg_intro_3e3d596e:

    # gg "Сейчас я сам не знаю, кем стал"
    gg "Bây giờ chính tôi cũng không biết mình đã trở thành người thế nào"

# game/characters_events_idles/mc_events.rpy:691
translate english gg_intro_b8032679:

    # Sonya "А ты . . ."
    Sonya "Còn anh…"

# game/characters_events_idles/mc_events.rpy:693
translate english gg_intro_7ad63786:

    # Sonya "Ты надолго?"
    Sonya "Anh ở lâu không？"

# game/characters_events_idles/mc_events.rpy:695
translate english gg_intro_c2f6d189:

    # Sonya "Ну какой у тебя дальше план?"
    Sonya "À, kế hoạch tiếp theo của anh là gì？"

# game/characters_events_idles/mc_events.rpy:697
translate english gg_intro_9f30eca5:

    # gg "Я пока не знаю"
    gg "Tôi chưa biết"

# game/characters_events_idles/mc_events.rpy:699
translate english gg_intro_51f05bc9:

    # gg "Мне нужно время"
    gg "Tôi cần thời gian"

# game/characters_events_idles/mc_events.rpy:701
translate english gg_intro_301f9bbb:

    # gg_chat "Хотя здесь приятно"
    gg_chat "Dù sao ở đây cũng dễ chịu"

# game/characters_events_idles/mc_events.rpy:704
translate english gg_intro_a1c2b87a:

    # gg_chat "И как-то спокойно"
    gg_chat "Và có cảm giác bình yên"

# game/characters_events_idles/mc_events.rpy:706
translate english gg_intro_1043df55:

    # Sonya "Уже поздно"
    Sonya "Muộn rồi"

# game/characters_events_idles/mc_events.rpy:708
translate english gg_intro_f1483558:

    # Sonya "Мы можем поговорить ещё потом"
    Sonya "Chúng ta có thể nói tiếp sau"

# game/characters_events_idles/mc_events.rpy:710
translate english gg_intro_701fa6da:

    # Sonya "Ты можешь лечь в зале"
    Sonya "Anh có thể ngủ ở phòng khách"

# game/characters_events_idles/mc_events.rpy:712
translate english gg_intro_7adf858b:

    # Sonya "Других мест спальных у нас нету"
    Sonya "Chúng tôi không có chỗ ngủ nào khác"

# game/characters_events_idles/mc_events.rpy:714
translate english gg_intro_e6ef238c:

    # gg "Да хорошо"
    gg "Vâng, được"

# game/characters_events_idles/mc_events.rpy:716
translate english gg_intro_18a3c2d6:

    # gg "Спасибо за теплый прием"
    gg "Cảm ơn vì đã tiếp đón nồng nhiệt"

# game/characters_events_idles/mc_events.rpy:718
translate english gg_intro_2857877c:

    # Sonya "Я положу все необходимое на диван"
    Sonya "Tôi sẽ để mọi thứ cần thiết lên ghế sofa"

# game/characters_events_idles/mc_events.rpy:720
translate english gg_intro_f96b8f09:

    # gg_chat "Похоже, пока я могу здесь остаться"
    gg_chat "Có vẻ tạm thời tôi có thể ở lại đây"

# game/characters_events_idles/mc_events.rpy:724
translate english gg_intro_19e97f44:

    # gg_chat "Я так устал за этот день"
    gg_chat "Tôi mệt quá vì ngày hôm nay"

# game/characters_events_idles/mc_events.rpy:725
translate english gg_intro_6f0f1d5a:

    # gg_chat "Пора отдыхать"
    gg_chat "Đến lúc nghỉ ngơi rồi"

# game/characters_events_idles/mc_events.rpy:737
translate english gg_first_morning_8051fd9f:

    # gg_chat "Утро"
    gg_chat "Buổi sáng"

# game/characters_events_idles/mc_events.rpy:739
translate english gg_first_morning_c535b2eb:

    # gg_chat "Давно я так не просыпался"
    gg_chat "Lâu lắm rồi tôi mới thức dậy như thế này"

# game/characters_events_idles/mc_events.rpy:741
translate english gg_first_morning_654f0c17:

    # gg_chat "Никакой работы"
    gg_chat "Không công việc"

# game/characters_events_idles/mc_events.rpy:743
translate english gg_first_morning_81883fea:

    # gg_chat "Никакого давления"
    gg_chat "Không áp lực"

# game/characters_events_idles/mc_events.rpy:745
translate english gg_first_morning_90c39e25:

    # gg_chat "Природа"
    gg_chat "Thiên nhiên"

# game/characters_events_idles/mc_events.rpy:747
translate english gg_first_morning_dbabb2ca:

    # gg_chat "Здесь я свободен"
    gg_chat "Ở đây tôi tự do"

# game/characters_events_idles/mc_events.rpy:749
translate english gg_first_morning_663fb966:

    # gg_chat "В городе я жил как белка в колесе"
    gg_chat "Ở thành phố tôi sống như con sóc trong bánh xe"

# game/characters_events_idles/mc_events.rpy:751
translate english gg_first_morning_bb031547:

    # gg_chat "Не жизнь, а выживание"
    gg_chat "Không phải sống, mà là sinh tồn"

# game/characters_events_idles/mc_events.rpy:753
translate english gg_first_morning_49963596:

    # gg_chat "Мне не хватало этого в городе"
    gg_chat "Tôi đã thiếu điều này ở thành phố"

# game/characters_events_idles/mc_events.rpy:754
translate english gg_first_morning_0af076a7:

    # gg_chat "Кажется я останусь"
    gg_chat "Có vẻ tôi sẽ ở lại"

# game/characters_events_idles/mc_events.rpy:756
translate english gg_first_morning_82a7ff6e:

    # gg_chat "Дорогой бабушке . . ."
    gg_chat "Gửi bà yêu quý…"

# game/characters_events_idles/mc_events.rpy:757
translate english gg_first_morning_4f068f55:

    # gg_chat "Спасибо похоже, я нашёл то, чего мне не хватало"
    gg_chat "Cảm ơn bà, có vẻ con đã tìm thấy điều mình còn thiếu"

# game/characters_events_idles/mc_events.rpy:759
translate english gg_first_morning_88a92574:

    # gg_chat "Моя жизнь меняется"
    gg_chat "Cuộc sống của tôi đang thay đổi"

# game/characters_events_idles/mc_events.rpy:761
translate english gg_first_morning_d67d6049:

    # gg_chat "Посмотрим, что из этого выйдет"
    gg_chat "Xem điều này sẽ dẫn đến đâu"

# game/characters_events_idles/mc_events.rpy:780
translate english gg_first_morning_kitchen_b418e893:

    # gg_chat "Можно просто сидеть"
    gg_chat "Có thể chỉ ngồi yên"

# game/characters_events_idles/mc_events.rpy:781
translate english gg_first_morning_kitchen_820306b2:

    # gg_chat "Никуда не спешить"
    gg_chat "Không vội đi đâu cả"

# game/characters_events_idles/mc_events.rpy:787
translate english gg_first_morning_kitchen_47966b2a:

    # gg_chat "Обычно меня раздражает мытье посуды. А тут даже приятно"
    gg_chat "Bình thường rửa bát làm tôi khó chịu. Mà ở đây lại thấy dễ chịu"

# game/characters_events_idles/mc_events.rpy:789
translate english gg_first_morning_kitchen_2119fa08:

    # gg_chat "Нужно будет всё здесь изучить"
    gg_chat "Sẽ phải tìm hiểu mọi thứ ở đây"

# game/characters_events_idles/mc_events.rpy:791
translate english gg_first_morning_kitchen_52906127:

    # gg_chat "Хочу понять, как здесь живут"
    gg_chat "Tôi muốn hiểu người ở đây sống thế nào"

# game/characters_events_idles/mc_events.rpy:792
translate english gg_first_morning_kitchen_1b6b16db:

    # gg_chat "Как всё устроено"
    gg_chat "Mọi thứ được sắp đặt ra sao"

# game/characters_events_idles/mc_events.rpy:795
translate english gg_first_morning_kitchen_681dfe7b:

    # gg_chat "Это теперь мой новый дом"
    gg_chat "Đây giờ là ngôi nhà mới của tôi"

# game/characters_events_idles/mc_events.rpy:810
translate english gg_first_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "Ôi"

# game/characters_events_idles/mc_events.rpy:812
translate english gg_first_day_bathroom_7b463844:

    # Sonya "Прости, я не думала, что ты сейчас зайдешь"
    Sonya "Xin lỗi, tôi không nghĩ anh sẽ vào lúc này"

# game/characters_events_idles/mc_events.rpy:813
translate english gg_first_day_bathroom_32835352:

    # Sonya "Я хотела прибраться"
    Sonya "Tôi định dọn dẹp"

# game/characters_events_idles/mc_events.rpy:817
translate english gg_first_day_bathroom_826d81cb:

    # Sonya "Я не мешаю тебе?"
    Sonya "Tôi có làm phiền anh không？"

# game/characters_events_idles/mc_events.rpy:819
translate english gg_first_day_bathroom_c012b14a:

    # Sonya "Я сейчас закончу"
    Sonya "Tôi xong ngay đây"

# game/characters_events_idles/mc_events.rpy:821
translate english gg_first_day_bathroom_1c4c4c5a:

    # gg "Нет, всё нормально"
    gg "Không, mọi chuyện ổn"

# game/characters_events_idles/mc_events.rpy:822
translate english gg_first_day_bathroom_bf898b26:

    # gg "Я подожду"
    gg "Tôi sẽ đợi"

# game/characters_events_idles/mc_events.rpy:824
translate english gg_first_day_bathroom_1452bdd4:

    # gg "Если тебе нужна помощь — скажи"
    gg "Nếu em cần giúp thì nói nhé"

# game/characters_events_idles/mc_events.rpy:826
translate english gg_first_day_bathroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "Thật sao？"

# game/characters_events_idles/mc_events.rpy:828
translate english gg_first_day_bathroom_6e75581c:

    # Sonya "Ты не обязан, я просто"
    Sonya "Anh không cần phải làm đâu, tôi chỉ…"

# game/characters_events_idles/mc_events.rpy:830
translate english gg_first_day_bathroom_bad9a3a7:

    # Sonya "Ну, если тебе не сложно"
    Sonya "À, nếu anh không thấy phiền"

# game/characters_events_idles/mc_events.rpy:832
translate english gg_first_day_bathroom_506ec94d:

    # Sonya "Можешь тогда разложить вещи для стирки"
    Sonya "Vậy anh có thể phân loại đồ để giặt"

# game/characters_events_idles/mc_events.rpy:834
translate english gg_first_day_bathroom_1b360134:

    # Sonya "Потом сложи что уже высохло"
    Sonya "Sau đó gấp những thứ đã khô"

# game/characters_events_idles/mc_events.rpy:836
translate english gg_first_day_bathroom_cc2e9c27:

    # Sonya "Отнесу я сама"
    Sonya "Tôi sẽ tự mang đi"

# game/characters_events_idles/mc_events.rpy:856
translate english gg_first_day_bathroom_fb297fd7:

    # gg_chat "Как будто мы тут давно живём"
    gg_chat "Cứ như thể chúng tôi sống ở đây đã lâu"

# game/characters_events_idles/mc_events.rpy:858
translate english gg_first_day_bathroom_adfa1b84:

    # Sonya "Мне чуть чуть осталось"
    Sonya "Tôi còn một chút nữa thôi"

# game/characters_events_idles/mc_events.rpy:860
translate english gg_first_day_bathroom_dc9b9999:

    # Sonya "Обычно в доме только я убираюсь"
    Sonya "Bình thường trong nhà chỉ có tôi dọn dẹp"

# game/characters_events_idles/mc_events.rpy:864
translate english gg_first_day_bathroom_09b9d111:

    # Sonya "А . . ."
    Sonya "À…"

# game/characters_events_idles/mc_events.rpy:865
translate english gg_first_day_bathroom_a741acc1:

    # Sonya "Ты наверное хочешь в душ"
    Sonya "Chắc anh muốn đi tắm"

# game/characters_events_idles/mc_events.rpy:869
translate english gg_first_day_bathroom_9f7316a6:

    # Sonya "Полотенца сейчас у меня в комнате"
    Sonya "Khăn tắm đang ở trong phòng tôi"

# game/characters_events_idles/mc_events.rpy:871
translate english gg_first_day_bathroom_352fa084:

    # Sonya "Мы можем сходить туда, если хочешь"
    Sonya "Chúng ta có thể qua đó nếu anh muốn"

# game/characters_events_idles/mc_events.rpy:873
translate english gg_first_day_bathroom_264ee174:

    # gg "Пойдем"
    gg "Đi thôi"

# game/characters_events_idles/mc_events.rpy:879
translate english gg_first_day_bathroom_a3853f22:

    # gg_chat "Как сильно поменялись комнаты"
    gg_chat "Các căn phòng đã thay đổi nhiều quá"

# game/characters_events_idles/mc_events.rpy:883
translate english gg_first_day_bathroom_1d2f5a17:

    # Sonya "Вот"
    Sonya "Đây"

# game/characters_events_idles/mc_events.rpy:885
translate english gg_first_day_bathroom_33def544:

    # Sonya "Если что, там ещё есть"
    Sonya "Nếu cần thì vẫn còn thêm ở đó"

# game/characters_events_idles/mc_events.rpy:887
translate english gg_first_day_bathroom_5c20aef6:

    # Sonya "Э ну приятного купания"
    Sonya "Ờ, chúc tắm vui vẻ"

# game/characters_events_idles/mc_events.rpy:889
translate english gg_first_day_bathroom_3eec94f5:

    # gg "А да спасибо"
    gg "À, vâng, cảm ơn"

# game/characters_events_idles/mc_events.rpy:892
translate english gg_first_day_bathroom_b774dd45:

    # gg_chat "Оказывается, для уюта нужно совсем немного"
    gg_chat "Hóa ra để có cảm giác ấm cúng chỉ cần rất ít"

# game/characters_events_idles/mc_events.rpy:905
translate english gg_first_morning_mayaroom_ff197092:

    # Maya "Барси!"
    Maya "Barsik!"

# game/characters_events_idles/mc_events.rpy:907
translate english gg_first_morning_mayaroom_de472ed4:

    # Maya "Барсик!"
    Maya "Barsik!"

# game/characters_events_idles/mc_events.rpy:910
translate english gg_first_morning_mayaroom_a4a7667e:

    # gg_chat "Что-то случилось?"
    gg_chat "Có chuyện gì à？"

# game/characters_events_idles/mc_events.rpy:914
translate english gg_first_morning_mayaroom_6f63b0d7:

    # gg_chat "Лучше ей не мешать . . ."
    gg_chat "Tốt hơn là đừng làm phiền cô ấy…"

# game/characters_events_idles/mc_events.rpy:920
translate english gg_first_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "Dừng lại"

# game/characters_events_idles/mc_events.rpy:922
translate english gg_first_morning_mayaroom_857efa08:

    # Maya "Ты кота не видел?"
    Maya "Anh có thấy con mèo không？"

# game/characters_events_idles/mc_events.rpy:924
translate english gg_first_morning_mayaroom_270e2f8c:

    # gg "Нет"
    gg "Không"

# game/characters_events_idles/mc_events.rpy:926
translate english gg_first_morning_mayaroom_def6171d:

    # gg "Но могу помочь"
    gg "Nhưng tôi có thể giúp"

# game/characters_events_idles/mc_events.rpy:928
translate english gg_first_morning_mayaroom_359a75af:

    # Maya "Твоя помощь мне не нужна"
    Maya "Tôi không cần sự giúp đỡ của anh"

# game/characters_events_idles/mc_events.rpy:930
translate english gg_first_morning_mayaroom_785a8355:

    # Maya "Хотя если будешь молчать — помогай"
    Maya "Mặc dù nếu anh im lặng — thì cứ giúp"

# game/characters_events_idles/mc_events.rpy:932
translate english gg_first_morning_mayaroom_929a1d4f:

    # gg_chat "Это так на помощь соглашаются"
    gg_chat "Đó là cách người ta đồng ý cho giúp đấy"

# game/characters_events_idles/mc_events.rpy:937
translate english gg_first_morning_mayaroom_bb6b3842:

    # Maya "Ты где барсииик"
    Maya "Barsiiik, anh ở đâu？"

# game/characters_events_idles/mc_events.rpy:946
translate english gg_first_morning_mayaroom_32a24542:

    # gg_chat "Нашёлся"
    gg_chat "Tìm thấy rồi"

# game/characters_events_idles/mc_events.rpy:950
translate english gg_first_morning_mayaroom_954eaf61:

    # gg_chat "Главное не разбудить"
    gg_chat "Quan trọng là đừng đánh thức nó"

# game/characters_events_idles/mc_events.rpy:952
translate english gg_first_morning_mayaroom_79aa0dff:

    # Maya "Всё хорошо"
    Maya "Mọi chuyện ổn rồi"

# game/characters_events_idles/mc_events.rpy:954
translate english gg_first_morning_mayaroom_831f5c17:

    # Maya "Я здесь барсик"
    Maya "Barsik, tôi ở đây"

# game/characters_events_idles/mc_events.rpy:958
translate english gg_first_morning_mayaroom_f0949f54:

    # Maya "Ты меня напугал"
    Maya "Mày làm tao sợ đấy"

# game/characters_events_idles/mc_events.rpy:959
translate english gg_first_morning_mayaroom_a8d4beb2:

    # Maya "Глупый"
    Maya "Đồ ngốc"

# game/characters_events_idles/mc_events.rpy:962
translate english gg_first_morning_mayaroom_ddc18c67:

    # gg_chat "Она не совсем такая, какой кажется"
    gg_chat "Cô ấy không hoàn toàn như vẻ ngoài"

# game/kitchen.rpy:390
translate english kate_day_kitchen_60e92ce9:

    # Kate "Так, где у вас тут кофе прячут?"
    Kate "Nào, ở đây mấy người giấu cà phê ở đâu？"

# game/kitchen.rpy:391
translate english kate_day_kitchen_077e1944:

    # gg "Ты кто вообще?"
    gg "Cô là ai vậy？"

# game/kitchen.rpy:393
translate english kate_day_kitchen_67f355f0:

    # Kate "О Привет"
    Kate "Ồ, chào"

# game/kitchen.rpy:396
translate english kate_day_kitchen_d81632e3:

    # Kate "Я Кейт"
    Kate "Tôi là Kate"

# game/kitchen.rpy:398
translate english kate_day_kitchen_1e97df81:

    # Kate "Не пугайся, я не вор"
    Kate "Đừng sợ, tôi không phải trộm"

# game/kitchen.rpy:399
translate english kate_day_kitchen_b0950cd9:

    # Kate "Просто кофе мне жизненно необходим"
    Kate "Chỉ là cà phê cần thiết cho sự sống của tôi"

# game/kitchen.rpy:401
translate english kate_day_kitchen_e063e635:

    # gg "Меня [povname] зовут"
    gg "Tôi tên là [povname]"

# game/kitchen.rpy:402
translate english kate_day_kitchen_f0d355f9:

    # gg "Растворимый прям тут"
    gg "Cà phê hòa tan ngay đây"

# game/kitchen.rpy:404
translate english kate_day_kitchen_f2fdab56:

    # Kate "О, спаситель!"
    Kate "Ôi, vị cứu tinh!"

# game/kitchen.rpy:406
translate english kate_day_kitchen_fe62b24d:

    # Kate "Значит, ты и есть тот самый парень, который тут появился недавно?"
    Kate "Vậy anh chính là chàng trai mới xuất hiện gần đây？"

# game/kitchen.rpy:408
translate english kate_day_kitchen_ce5edae1:

    # gg "Судя по слухам — да, я"
    gg "Theo tin đồn thì — đúng, là tôi"

# game/kitchen.rpy:410
translate english kate_day_kitchen_0d1fc413:

    # Kate "Мая рассказывала"
    Kate "Maya đã kể"

# game/kitchen.rpy:412
translate english kate_day_kitchen_7c8bce00:

    # Kate "Живёт с Соней давно, а потом появился ты"
    Kate "Sống với Sonya lâu rồi, rồi sau đó anh xuất hiện"

# game/kitchen.rpy:413
translate english kate_day_kitchen_34985df3:

    # Kate "Интересная компания"
    Kate "Một nhóm thú vị"

# game/kitchen.rpy:415
translate english kate_day_kitchen_2e63aac8:

    # gg "“Интересная” — мягко сказано"
    gg "“Thú vị” — nói nhẹ thôi"

# game/kitchen.rpy:417
translate english kate_day_kitchen_cbdc207c:

    # Kate "Серьёзно? Это растворимый?"
    Kate "Thật á？ Đây là cà phê hòa tan à？"

# game/kitchen.rpy:419
translate english kate_day_kitchen_8937f276:

    # gg "Ага"
    gg "Ừ"

# game/kitchen.rpy:421
translate english kate_day_kitchen_5746fae5:

    # Kate "А ведь вкусно"
    Kate "Mà ngon thật"

# game/kitchen.rpy:422
translate english kate_day_kitchen_796538ef:

    # Kate "Обычно от растворимого хочется заплакать"
    Kate "Bình thường uống cà phê hòa tan chỉ muốn khóc"

# game/kitchen.rpy:424
translate english kate_day_kitchen_3e92b413:

    # gg "Значит, я талантливый бариста"
    gg "Vậy thì tôi là một barista tài năng"

# game/kitchen.rpy:425
translate english kate_day_kitchen_961ab98b:

    # Kate "Или тебе повезло"
    Kate "Hoặc là anh gặp may"

# game/kitchen.rpy:427
translate english kate_day_kitchen_394c86a9:

    # Kate "Ну что, рассказывай, кто ты такой"
    Kate "Nào, kể đi, anh là ai？"

# game/kitchen.rpy:429
translate english kate_day_kitchen_517a6831:

    # gg "Обычно начинают с “как дела?”"
    gg "Bình thường người ta bắt đầu bằng “dạo này thế nào？”"

# game/kitchen.rpy:431
translate english kate_day_kitchen_bb3d7bf1:

    # Kate "Это скучно"
    Kate "Chán lắm"

# game/kitchen.rpy:433
translate english kate_day_kitchen_01155acc:

    # Kate "Я сразу к сути. Ты кто: сосед, ухажёр, постоялец или просто [povname]"
    Kate "Tôi vào thẳng vấn đề. Anh là ai: hàng xóm, người tán tỉnh, người thuê trọ hay chỉ đơn giản là [povname]"

# game/kitchen.rpy:435
translate english kate_day_kitchen_4333516e:

    # gg "Пусть будет просто [povname]"
    gg "Cứ cho là chỉ [povname] thôi"

# game/kitchen.rpy:437
translate english kate_day_kitchen_95199003:

    # Kate "Значит, загадочный. Ладно, оставим интригу"
    Kate "Vậy là bí ẩn. Được, giữ lại chút kịch tính vậy"

# game/kitchen.rpy:440
translate english kate_day_kitchen_eb2b6424:

    # Kate "Тут уютно"
    Kate "Ở đây ấm cúng"

# game/kitchen.rpy:441
translate english kate_day_kitchen_ad0e7b9c:

    # Kate "Не думала, что Мая вообще когда-то научится жить без хаоса"
    Kate "Tôi không nghĩ Maya có ngày học được cách sống không hỗn loạn"

# game/kitchen.rpy:445
translate english kate_day_kitchen_1e4f23c6:

    # Maya "Кейт! Ты тут"
    Maya "Kate! Cậu ở đây"

# game/kitchen.rpy:446
translate english kate_day_kitchen_ecdba904:

    # Maya "Я же сказала подожди меня!"
    Maya "Tớ đã bảo là đợi tớ mà!"

# game/kitchen.rpy:448
translate english kate_day_kitchen_b6371751:

    # Maya "Ага, ты уже познакомилась с этим балбесом"
    Maya "À, cậu đã làm quen với cái tên ngốc này rồi"

# game/kitchen.rpy:450
translate english kate_day_kitchen_9c22616a:

    # Kate "Да! И кофе у него отличный, между прочим"
    Kate "Ừ! Mà nói thật, cà phê của anh ta ngon đấy"

# game/kitchen.rpy:452
translate english kate_day_kitchen_08bc7129:

    # Maya "Хвалить не вздумай, зазнается. Нам пора"
    Maya "Đừng có khen, nó sẽ ảo tưởng mất. Chúng ta đi thôi"

# game/kitchen.rpy:454
translate english kate_day_kitchen_8ab29297:

    # Kate "Спасибо за кофе, бариста"
    Kate "Cảm ơn vì ly cà phê nhé, barista"

# game/kitchen.rpy:455
translate english kate_day_kitchen_11705c38:

    # Kate "Ладно. Ещё увидимся"
    Kate "Được rồi. Lại gặp sau"

translate english strings:

    # game/characters_events_idles/mc_events.rpy:361
    old "Послать нахуй"
    new "Bảo cút mẹ đi"

    # game/characters_events_idles/mc_events.rpy:363
    old "Молча уйти"
    new "Lặng lẽ bỏ đi"


# game/characters_events_idles/mc_events.rpy:295
translate english gg_intro_4402cfd9:

    # gg_chat "Я отвечу попозже бабушка"
    gg_chat "Bà ơi, lát nữa cháu sẽ trả lời"

# game/characters_events_idles/mc_events.rpy:668
translate english gg_intro_0997da9e:

    # Maya "Это мы с Соней решим!"
    Maya "Chuyện đó để tôi với Sonya quyết định!"

# game/characters_events_idles/mc_events.rpy:670
translate english gg_intro_6619e154:

    # Maya "{sc}{size=*1.5}СОНЯ{/sc}" with hpunch
    Maya "{sc}{size=*1.5}SONYA{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:805
translate english gg_intro_fadd240e:

    # "Ночью можно отдохнуть — нажми на кровать, чтобы начать новый день"
    "Ban đêm có thể nghỉ ngơi — nhấn vào giường để bắt đầu ngày mới"

# game/characters_events_idles/mc_events.rpy:895
translate english gg_first_day_bathroom_6c8604ba:

    # Sonya "Я не думала, что ты сейчас зайдешь"
    Sonya "Tôi không nghĩ anh sẽ vào lúc này"

# game/characters_events_idles/mc_events.rpy:896
translate english gg_first_day_bathroom_15c3e23b:

    # Sonya "Хотела прибраться"
    Sonya "Tôi định dọn dẹp"

# game/characters_events_idles/mc_events.rpy:900
translate english gg_first_day_bathroom_94ef9943:

    # Sonya "Ты хотел в душ?"
    Sonya "Anh muốn đi tắm à？"

# game/characters_events_idles/mc_events.rpy:287
translate english gg_intro_21dc756d:

    # gg_chat "Чёрт, я опаздываю"
    gg_chat "Chết tiệt, tôi trễ rồi"

# game/characters_events_idles/mc_events.rpy:295
translate english gg_intro_01ac9e1d:

    # gg_chat "Я отвечу попозже, бабушка"
    gg_chat "Bà ơi, lát nữa cháu sẽ trả lời"

# game/characters_events_idles/mc_events.rpy:325
translate english gg_intro_d5122bca:

    # Assistant "И напомню: если продолжишь, {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "Và tôi nhắc lại: nếu cậu tiếp tục, {w}thì chuyện giảm lương chỉ còn là vấn đề thời gian"

# game/characters_events_idles/mc_events.rpy:361
translate english gg_intro_4e8253d3:

    # gg_chat "Сколько ни работай, этому нет конца"
    gg_chat "Làm việc bao nhiêu cũng không có hồi kết"

# game/characters_events_idles/mc_events.rpy:393
translate english gg_intro_eb3e3aa2:

    # gg_chat "Да пошло оно все"
    gg_chat "Mẹ kiếp tất cả"

# game/characters_events_idles/mc_events.rpy:409
translate english gg_intro_187f7fc4:

    # Director "Ты вообще что делаешь"
    Director "Mày đang làm cái quái gì vậy？"

# game/characters_events_idles/mc_events.rpy:500
translate english gg_intro_bb6264b0:

    # gg_chat "Все, кого я вижу, со мной здороваются"
    gg_chat "Tất cả những người tôi gặp đều chào tôi"

# game/characters_events_idles/mc_events.rpy:520
translate english gg_intro_2c4c4cb8:

    # UnknownGirl "Если что-то нужно будет, спрашивай помощь у любого"
    UnknownGirl "Nếu cần gì thì cứ nhờ bất kỳ ai giúp"

# game/characters_events_idles/mc_events.rpy:524
translate english gg_intro_f654fdee:

    # gg "Хорошо и Вам отличного дня"
    gg "Được, chúc cô một ngày tốt lành"

# game/characters_events_idles/mc_events.rpy:527
translate english gg_intro_87051a07:

    # gg_chat "Бабушка, похоже, говорила правду о людях здесь"
    gg_chat "Có vẻ bà đã nói đúng về những người ở đây"

# game/characters_events_idles/mc_events.rpy:546
translate english gg_intro_95240a3b:

    # gg_chat "Да, дом поменялся"
    gg_chat "Đúng, ngôi nhà đã thay đổi"

# game/characters_events_idles/mc_events.rpy:556
translate english gg_intro_e94b0047:

    # gg_chat "Здесь кто-то есть?"
    gg_chat "Có ai ở đây không？"

# game/characters_events_idles/mc_events.rpy:596
translate english gg_intro_eee07a35:

    # gg "Стой, подожди"
    gg "Khoan, đợi đã"

# game/characters_events_idles/mc_events.rpy:604
translate english gg_intro_ca7cead7:

    # Maya "Что-то я такого внука никогда здесь не видела"
    Maya "Thế mà tôi chưa từng thấy đứa cháu trai nào như vậy ở đây"

# game/characters_events_idles/mc_events.rpy:650
translate english gg_intro_f08474d4:

    # Maya "Мои цветочки любимые. Они остались"
    Maya "Những bông hoa yêu quý của bà. Chúng vẫn còn đó"

# game/characters_events_idles/mc_events.rpy:659
translate english gg_intro_90f291ff:

    # Maya "Боже, ладно"
    Maya "Trời ạ, được rồi"

# game/characters_events_idles/mc_events.rpy:660
translate english gg_intro_7b0b2a04:

    # Maya "Похоже на правду"
    Maya "Có vẻ là thật"

# game/characters_events_idles/mc_events.rpy:676
translate english gg_intro_1b04d04b:

    # Maya "Слушай, если ты хоть что-то сделаешь"
    Maya "Nghe đây, nếu anh làm bất cứ điều gì"

# game/characters_events_idles/mc_events.rpy:734
translate english gg_intro_5834166b:

    # Sonya "Нет-нет, всё нормально"
    Sonya "Không không, mọi chuyện ổn"

# game/characters_events_idles/mc_events.rpy:740
translate english gg_intro_05ceb2ee:

    # Sonya "Я прочла письмо Линды"
    Sonya "Tôi đã đọc lá thư của Linda"

# game/characters_events_idles/mc_events.rpy:744
translate english gg_intro_c73d3bb7:

    # Sonya "Она всегда нас так называла"
    Sonya "Bà ấy luôn gọi chúng tôi như thế"

# game/characters_events_idles/mc_events.rpy:760
translate english gg_intro_d2363caa:

    # Sonya "Это место для нас стало родным"
    Sonya "Nơi này đã trở nên thân thuộc với chúng tôi"

# game/characters_events_idles/mc_events.rpy:764
translate english gg_intro_79c61e5f:

    # Sonya "Говорила, что ты хороший, по крайней мере в детстве"
    Sonya "Bà nói anh tốt bụng, ít nhất là hồi nhỏ"

# game/characters_events_idles/mc_events.rpy:774
translate english gg_intro_7f8fcf55:

    # Sonya "Ну, какой у тебя дальше план?"
    Sonya "À, kế hoạch tiếp theo của anh là gì？"

# game/characters_events_idles/mc_events.rpy:787
translate english gg_intro_d7903980:

    # Sonya "Если захочешь мы еще поговорим"
    Sonya "Nếu anh muốn, chúng ta sẽ nói chuyện thêm"

# game/characters_events_idles/mc_events.rpy:789
translate english gg_intro_7d278239:

    # Sonya "А пока ты можешь лечь в зале"
    Sonya "Còn bây giờ anh có thể ngủ ở phòng khách"

# game/characters_events_idles/mc_events.rpy:793
translate english gg_intro_41b7f3b0:

    # gg "Да, хорошо"
    gg "Vâng, được"

# game/characters_events_idles/mc_events.rpy:835
translate english gg_first_morning_5b301338:

    # gg_chat "Эх, как же мне не хватало свободы"
    gg_chat "Haiz, tôi đã thiếu tự do đến nhường nào"

# game/characters_events_idles/mc_events.rpy:836
translate english gg_first_morning_146ca63e:

    # gg_chat "Кажется, я останусь"
    gg_chat "Có vẻ tôi sẽ ở lại"

# game/characters_events_idles/mc_events.rpy:839
translate english gg_first_morning_9cc6e0e8:

    # gg_chat "Спасибо, похоже, я нашёл то, чего мне не хватало"
    gg_chat "Cảm ơn, có vẻ tôi đã tìm thấy thứ mà mình còn thiếu"

# game/characters_events_idles/mc_events.rpy:917
translate english gg_first_day_bathroom_c3b33eb8:

    # Sonya "Потом сложи, что уже высохло"
    Sonya "Sau đó gấp những gì đã khô lại"

# game/characters_events_idles/mc_events.rpy:970
translate english gg_first_day_bathroom_887d1e72:

    # Sonya "Ээ... нуу приятного купания"
    Sonya "Ơ… ừm, chúc tắm vui vẻ"

# game/characters_events_idles/mc_events.rpy:972
translate english gg_first_day_bathroom_997383a9:

    # gg "А, да, спасибо"
    gg "À, vâng, cảm ơn"

# game/characters_events_idles/mc_events.rpy:1018
translate english gg_first_morning_mayaroom_123ee93a:

    # Maya "Хотя, если будешь молчать — помогай"
    Maya "Dù sao, nếu cậu cứ im lặng — thì giúp đi"

