﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/maya_idles.rpy:7
translate english maya_Idle_day_myroom_scene_5a17c289:

    # gg "А я думал, этот предатель спит только у Сони"
    gg "Mà tôi tưởng tên phản bội này chỉ ngủ ở chỗ Sonya thôi chứ."

# game/characters_events_idles/maya_idles.rpy:9
translate english maya_Idle_day_myroom_scene_67e33434:

    # Maya "Он выбирает по настроению"
    Maya "Nó chọn theo tâm trạng ấy."

# game/characters_events_idles/maya_idles.rpy:10
translate english maya_Idle_day_myroom_scene_d5b84977:

    # Maya "Сегодня, видимо, у меня нужная температура коленей"
    Maya "Hôm nay chắc đầu gối tôi có nhiệt độ vừa ý nó."

# game/characters_events_idles/maya_idles.rpy:11
translate english maya_Idle_day_myroom_scene_60432ccb:

    # gg "Или просто знаешь, чем подкупить"
    gg "Hoặc đơn giản là cô biết cách mua chuộc nó."

# game/characters_events_idles/maya_idles.rpy:13
translate english maya_Idle_day_myroom_scene_e3e70aea:

    # Maya "Конечно"
    Maya "Tất nhiên."

# game/characters_events_idles/maya_idles.rpy:14
translate english maya_Idle_day_myroom_scene_d43eb27c:

    # Maya "Я его нашла - я и лицензированный поставщик любви и корма"
    Maya "Tôi tìm thấy nó mà - tôi cũng là nhà cung cấp tình yêu và thức ăn có giấy phép."

# game/characters_events_idles/maya_idles.rpy:15
translate english maya_Idle_day_myroom_scene_567c8898:

    # gg "Нашла?"
    gg "Cô tìm thấy nó？"

# game/characters_events_idles/maya_idles.rpy:17
translate english maya_Idle_day_myroom_scene_a785c258:

    # Maya "Год назад. Под дождём, под машиной сидел"
    Maya "Một năm trước. Nó ngồi dưới mưa, dưới gầm xe."

# game/characters_events_idles/maya_idles.rpy:18
translate english maya_Idle_day_myroom_scene_81fc3249:

    # Maya "Маленький, грязный, дрожал, а я шла домой с кофе"
    Maya "Nhỏ xíu, bẩn thỉu, run rẩy, còn tôi thì đang đi bộ về nhà với ly cà phê."

# game/characters_events_idles/maya_idles.rpy:19
translate english maya_Idle_day_myroom_scene_f0aa2ab7:

    # Maya "И подумала: “Ладно, кофе подождёт”"
    Maya "Và tôi nghĩ: “Thôi được, cà phê đợi được.”"

# game/characters_events_idles/maya_idles.rpy:21
translate english maya_Idle_day_myroom_scene_8924b2a5:

    # Maya "С тех пор он решил, что я его персональный обогреватель"
    Maya "Từ đó nó quyết định rằng tôi là máy sưởi cá nhân của nó."

# game/characters_events_idles/maya_idles.rpy:23
translate english maya_Idle_day_myroom_scene_38f294e2:

    # gg "Повезло ему"
    gg "Nó may mắn thật."

# game/characters_events_idles/maya_idles.rpy:25
translate english maya_Idle_day_myroom_scene_1538c3c1:

    # Maya "Ага. Только не говори Соне, что я так сказала"
    Maya "Ừ. Chỉ là đừng nói với Sonya là tôi nói thế."

# game/characters_events_idles/maya_idles.rpy:26
translate english maya_Idle_day_myroom_scene_d9ab69f9:

    # Maya "Она делает вид, что ей всё равно, но я видела, как она однажды сушила ему лапы феном"
    Maya "Cô ấy giả vờ không quan tâm, nhưng có lần tôi thấy cô ấy sấy chân cho nó bằng máy sấy tóc."

# game/characters_events_idles/maya_idles.rpy:27
translate english maya_Idle_day_myroom_scene_5e0ad0a7:

    # gg "Правда? Не ожидал"
    gg "Thật à？ Tôi không ngờ đấy."

# game/characters_events_idles/maya_idles.rpy:28
translate english maya_Idle_day_myroom_scene_e31c6d2d:

    # Maya "Ну, она просто не из тех, кто сюсюкает. Но и не выгонит"
    Maya "À, cô ấy không phải kiểu người hay dỗ ngọt. Nhưng cũng không đuổi nó đi."

# game/characters_events_idles/maya_idles.rpy:29
translate english maya_Idle_day_myroom_scene_5e1c1537:

    # Maya "Иногда подкармливает, когда думает, что я не вижу"
    Maya "Thỉnh thoảng cô ấy cho nó ăn thêm khi nghĩ tôi không thấy."

# game/characters_events_idles/maya_idles.rpy:30
translate english maya_Idle_day_myroom_scene_dd7932db:

    # Maya "У нас, знаешь, баланс: я - шум, она - порядок, а Барсик - нейтральная территория"
    Maya "Cậu biết đấy, bọn tôi có một sự cân bằng: tôi là tiếng ồn, cô ấy là trật tự, còn Barsik là vùng trung lập."

# game/characters_events_idles/maya_idles.rpy:31
translate english maya_Idle_day_myroom_scene_ff61f178:

    # gg "И кто из вас лидер?"
    gg "Thế ai trong hai người là thủ lĩnh？"

# game/characters_events_idles/maya_idles.rpy:33
translate english maya_Idle_day_myroom_scene_4579d2be:

    # Maya "Он. Сто процентов"
    Maya "Nó. Một trăm phần trăm."

# game/characters_events_idles/maya_idles.rpy:34
translate english maya_Idle_day_myroom_scene_73c39706:

    # Maya "Ему всё равно, кто орёт, кто убирает - он всё равно получает своё место и миску"
    Maya "Nó chẳng quan tâm ai gào thét, ai dọn dẹp - nó vẫn có chỗ của mình và bát ăn."

# game/characters_events_idles/maya_idles.rpy:36
translate english maya_Idle_day_myroom_scene_c39583ae:

    # Maya "Видишь? {w}Даже в доме с нами двумя кто-то умеет быть по-настоящему счастливым"
    Maya "Thấy chưa？ {w}Ngay cả trong ngôi nhà có hai chúng ta, vẫn có kẻ biết cách thật sự hạnh phúc."

# game/characters_events_idles/maya_idles.rpy:38
translate english maya_Idle_day_myroom_scene_04531df3:

    # gg "Может, секрет в том, чтобы просто мурчать и не спорить"
    gg "Có lẽ bí quyết là chỉ cần gừ gừ và không cãi nhau."

# game/characters_events_idles/maya_idles.rpy:39
translate english maya_Idle_day_myroom_scene_25a0e3ac:

    # Maya "Или в том, чтобы спать на тёплом и не думать"
    Maya "Hoặc là ngủ trên chỗ ấm áp và không nghĩ ngợi gì."

# game/myroom.rpy:387
translate english maya_Idle_morning_myroom_scene_323bf253:

    # gg "Уже читаешь? . . ."
    gg "Cô đọc sách rồi à？ . . ."

# game/myroom.rpy:388
translate english maya_Idle_morning_myroom_scene_92e4f307:

    # Maya "Ага. Утро тихое, редкость"
    Maya "Ừ. Buổi sáng yên tĩnh, hiếm lắm."

# game/myroom.rpy:389
translate english maya_Idle_morning_myroom_scene_43a1c1b0:

    # Maya "Грех не пользоваться, пока никто не шумит и не ищет кружку"
    Maya "Tội gì không tận dụng khi chưa ai ồn ào hay đi tìm cái cốc."

# game/myroom.rpy:390
translate english maya_Idle_morning_myroom_scene_7ac1c8ed:

    # gg "Что на этот раз?"
    gg "Lần này là gì？"

# game/myroom.rpy:392
translate english maya_Idle_morning_myroom_scene_6a78f6bb:

    # Maya "Манга"
    Maya "Manga."

# game/myroom.rpy:393
translate english maya_Idle_morning_myroom_scene_932f7db6:

    # Maya "После Линдиных книг захотелось чего-то полегче"
    Maya "Sau mấy cuốn sách của Linda, tôi muốn thứ gì đó nhẹ nhàng hơn."

# game/myroom.rpy:395
translate english maya_Idle_morning_myroom_scene_cffdb9b8:

    # Maya "Она могла читать про философию даже за ужином"
    Maya "Cô ấy có thể đọc về triết học ngay cả trong bữa tối."

# game/myroom.rpy:396
translate english maya_Idle_morning_myroom_scene_3d9df54a:

    # Maya "Я же за ужином максимум комментирую философию людей в интернете"
    Maya "Còn tôi trong bữa tối cùng lắm chỉ bình luận về triết lý của người ta trên mạng."

# game/myroom.rpy:398
translate english maya_Idle_morning_myroom_scene_c6ff46fa:

    # Maya "Хотя по этой манге не скажешь"
    Maya "Dù nhìn cuốn manga này thì không đoán được đâu."

# game/myroom.rpy:399
translate english maya_Idle_morning_myroom_scene_5ff05dc4:

    # Maya "Автор явно страдал, но красиво"
    Maya "Tác giả rõ ràng đã đau khổ, nhưng đau khổ một cách đẹp đẽ."

# game/myroom.rpy:400
translate english maya_Idle_morning_myroom_scene_f96de996:

    # gg "К картинкам и эмоциям?"
    gg "Cô thích tranh vẽ và cảm xúc à？"

# game/myroom.rpy:402
translate english maya_Idle_morning_myroom_scene_b2396673:

    # Maya "К историям, где герои хотя бы честные"
    Maya "Tôi thích những câu chuyện mà nhân vật ít nhất còn trung thực."

# game/myroom.rpy:404
translate english maya_Idle_morning_myroom_scene_6e6a997d:

    # Maya "Иногда читаю японское или корейское"
    Maya "Thỉnh thoảng tôi đọc truyện Nhật hoặc Hàn."

# game/myroom.rpy:405
translate english maya_Idle_morning_myroom_scene_3aeeaab4:

    # Maya "У них всё немного грустно, но по-тёплому"
    Maya "Truyện của họ hơi buồn, nhưng ấm áp."

# game/myroom.rpy:406
translate english maya_Idle_morning_myroom_scene_d16d1737:

    # Maya "В отличие от наших драм, где все страдают просто из принципа"
    Maya "Khác với phim truyền hình của mình, nơi ai cũng đau khổ chỉ vì nguyên tắc."

# game/myroom.rpy:407
translate english maya_Idle_morning_myroom_scene_0bb250f6:

    # gg "Под настроение, значит"
    gg "Vậy là tùy tâm trạng."

# game/myroom.rpy:409
translate english maya_Idle_morning_myroom_scene_bc0bb57f:

    # Maya "Угу. Когда настроение “оставьте меня в покое, но с уютом”"
    Maya "Ừ. Khi tâm trạng kiểu “để tôi yên, nhưng phải ấm cúng”."

# game/myroom.rpy:410
translate english maya_Idle_morning_myroom_scene_c92c399c:

    # gg "Ты давно здесь?"
    gg "Cô ở đây lâu chưa？"

# game/myroom.rpy:412
translate english maya_Idle_morning_myroom_scene_8b0e76c6:

    # Maya "Год, может чуть больше"
    Maya "Một năm, có lẽ hơn một chút."

# game/myroom.rpy:413
translate english maya_Idle_morning_myroom_scene_924b98a2:

    # Maya "После универа приехала в посёлок работать. Захотелось тишины и воздуха"
    Maya "Sau đại học tôi đến thị trấn nhỏ này làm việc. Tôi muốn sự yên tĩnh và không khí trong lành."

# game/myroom.rpy:415
translate english maya_Idle_morning_myroom_scene_f611f1fe:

    # Maya "Искала жильё - наткнулась на объявление: “Сдам комнату. Дом с садом”"
    Maya "Tôi tìm chỗ ở - rồi vô tình thấy một mẩu tin: “Cho thuê phòng. Nhà có vườn.”"

# game/myroom.rpy:416
translate english maya_Idle_morning_myroom_scene_12f76597:

    # Maya "Открывает дверь Линда и спрашивает: “Ты громкая?”"
    Maya "Linda mở cửa và hỏi: “Cô có ồn ào không？”"

# game/myroom.rpy:417
translate english maya_Idle_morning_myroom_scene_5517b596:

    # Maya "Я ответила: “Только когда думаю.” Она засмеялась и сказала: “Тогда уживайся”"
    Maya "Tôi đáp: “Chỉ khi tôi suy nghĩ thôi.” Cô ấy cười và nói: “Vậy thì sống chung cho hòa thuận đi.”"

# game/myroom.rpy:418
translate english maya_Idle_morning_myroom_scene_20b975de:

    # gg "И Соня уже тут была?"
    gg "Và Sonya đã ở đây rồi à？"

# game/myroom.rpy:420
translate english maya_Idle_morning_myroom_scene_37745fdb:

    # Maya "Да. Мы познакомились на кухне, где я чуть не спалила чайник"
    Maya "Đúng. Bọn tôi làm quen ở bếp, nơi tôi suýt làm cháy cái ấm trà."

# game/myroom.rpy:422
translate english maya_Idle_morning_myroom_scene_f337d502:

    # Maya "Иногда даже чай кипит от ужаса"
    Maya "Đôi khi ngay cả trà cũng sôi lên vì kinh hãi."

# game/myroom.rpy:423
translate english maya_Idle_morning_myroom_scene_b1814b27:

    # Maya "Линда звала нас “шум и тишина”"
    Maya "Linda gọi bọn tôi là “ồn ào và im lặng”."

# game/myroom.rpy:424
translate english maya_Idle_morning_myroom_scene_ab4dac88:

    # Maya "Хотя, скорее, “тишина и источник хаоса”"
    Maya "Dù chính xác hơn thì là “im lặng và nguồn hỗn loạn”."

# game/myroom.rpy:425
translate english maya_Idle_morning_myroom_scene_f2159d17:

    # gg "А теперь ещё и я"
    gg "Và giờ còn có cả tôi nữa."

# game/myroom.rpy:427
translate english maya_Idle_morning_myroom_scene_ecb2ad9f:

    # Maya "Теперь да. Баланс окончательно нарушен, но зато весело"
    Maya "Giờ thì đúng thế. Sự cân bằng cuối cùng đã bị phá vỡ, nhưng bù lại vui."

# game/myroom.rpy:429
translate english maya_Idle_morning_myroom_scene_cea1d0c9:

    # Maya "Вон, слышишь? Она уже с шести на ногах"
    Maya "Kìa, nghe thấy không？ Cô ấy đã dậy từ sáu giờ rồi."

# game/characters_events_idles/maya_idles.rpy:97
translate english maya_Idle_morning_myroom_scene_deefee09:

    # Maya "Я так пробовала - уснула прямо с кружкой в руке"
    Maya "Tôi từng thử thế - rồi ngủ luôn với cái cốc trên tay."

# game/characters_events_idles/maya_idles.rpy:98
translate english maya_Idle_morning_myroom_scene_bd135488:

    # Maya "Зато хоть кто-то следит, чтобы дом не просыпался в хаосе. Я - больше за безделие"
    Maya "Bù lại ít nhất có người trông chừng để ngôi nhà không thức dậy trong hỗn loạn. Còn tôi thì thiên về ăn không ngồi rồi hơn."

translate english maya_Idle_evening_bathroom_scene_d8fba7e0:

    # gg "Ко сну готовишься?"
    gg "Cô chuẩn bị đi ngủ à？"

# game/bathroom.rpy:325
translate english maya_Idle_evening_bathroom_scene_768e9905:

    # Maya "Ага. Осталось немного. Главное, чтобы никто не отвлекал"
    Maya "Ừ. Còn một chút nữa. Quan trọng là đừng ai làm phiền."

# game/bathroom.rpy:326
translate english maya_Idle_evening_bathroom_scene_c84b09d3:

    # Maya "А то всё придётся начинать заново — тут процесс деликатный"
    Maya "Không thì phải làm lại từ đầu hết — quá trình này tinh tế lắm."

# game/bathroom.rpy:327
translate english maya_Idle_evening_bathroom_scene_ff89b4d4:

    # gg "Надеюсь, ты не про стирку опять"
    gg "Hy vọng cô không lại nói về việc giặt giũ."

# game/bathroom.rpy:329
translate english maya_Idle_evening_bathroom_scene_63a219ac:

    # Maya "А что, если и про неё? Не все вещи выдерживают жёсткий режим"
    Maya "Sao nào, nếu đúng là nói về nó thì sao？ Không phải món đồ nào cũng chịu được chế độ mạnh."

# game/bathroom.rpy:330
translate english maya_Idle_evening_bathroom_scene_16a58674:

    # gg "В прошлый раз ты, кажется, не всё достирала"
    gg "Lần trước hình như cô chưa giặt xong hết thì phải."

# game/bathroom.rpy:332
translate english maya_Idle_evening_bathroom_scene_6782c239:

    # Maya "Ха. Ну, издержки ручной работы. Зато результат запомнился, верно?"
    Maya "Ha. À, đó là cái giá của việc làm bằng tay. Nhưng bù lại kết quả đáng nhớ, đúng không？"

# game/bathroom.rpy:333
translate english maya_Idle_evening_bathroom_scene_d25c24db:

    # gg "Даже слишком"
    gg "Thậm chí quá đáng nhớ."

# game/bathroom.rpy:335
translate english maya_Idle_evening_bathroom_scene_a5bb0cfc:

    # Maya "Значит, не зря старалась"
    Maya "Vậy là tôi đã cố gắng không uổng công."

# game/bathroom.rpy:337
translate english maya_Idle_evening_bathroom_scene_91354786:

    # Maya "Правда, немного смущалась. Такое со мной редко бывает"
    Maya "Thật ra tôi hơi ngượng. Chuyện đó hiếm khi xảy ra với tôi."

# game/bathroom.rpy:338
translate english maya_Idle_evening_bathroom_scene_2b597177:

    # gg "Удивительно. Я думал, ты вообще не из тех, кто смущается"
    gg "Đáng ngạc nhiên đấy. Tôi tưởng cô hoàn toàn không phải kiểu người biết ngượng."

# game/bathroom.rpy:340
translate english maya_Idle_evening_bathroom_scene_aa3db339:

    # Maya "Все когда-то ошибаются. Но не переживай, в следующий раз я компенсирую моральный ущерб"
    Maya "Ai cũng có lúc sai. Nhưng đừng lo, lần sau tôi sẽ bù đắp tổn thất tinh thần."

# game/bathroom.rpy:341
translate english maya_Idle_evening_bathroom_scene_ed2cbd06:

    # gg "Это угроза или обещание?"
    gg "Đó là lời đe dọa hay lời hứa？"

# game/bathroom.rpy:343
translate english maya_Idle_evening_bathroom_scene_0f1383f3:

    # Maya "Назови это приглашением на повторный эксперимент"
    Maya "Cứ gọi đó là lời mời làm lại thí nghiệm đi."

translate english maya_Idle_morning_kitchen_scene_ff259315:

    # gg "Это так теперь готовят яищницу?"
    gg "Giờ người ta làm trứng tráng kiểu đó à？"

# game/kitchen.rpy:519
translate english maya_Idle_morning_kitchen_scene_2a72a3a2:

    # Maya "Умник. Не все рождаются с магией кулинарии, ладно?"
    Maya "Đồ thông thái. Không phải ai sinh ra cũng có phép thuật nấu ăn, được chứ？"

# game/kitchen.rpy:520
translate english maya_Idle_morning_kitchen_scene_5c70bf26:

    # Maya "Обычно Соня этим занимается"
    Maya "Thường thì Sonya lo việc này."

# game/kitchen.rpy:522
translate english maya_Idle_morning_kitchen_scene_602f32f7:

    # Maya "Вот, видишь? Сковородка меня ненавидит"
    Maya "Đấy, thấy chưa？ Cái chảo ghét tôi."

# game/kitchen.rpy:523
translate english maya_Idle_morning_kitchen_scene_6441a501:

    # gg "Ага, ты с ней просто не разговариваешь достаточно вежливо"
    gg "Ừ, chỉ là cô không nói chuyện với nó đủ lễ phép thôi."

# game/kitchen.rpy:525
translate english maya_Idle_morning_kitchen_scene_92534113:

    # Maya "Серьёзно? Может, ей ещё комплимент сказать?"
    Maya "Thật à？ Có khi còn phải khen nó một câu nữa ấy chứ？"

# game/kitchen.rpy:526
translate english maya_Idle_morning_kitchen_scene_9a46a58c:

    # gg "Можешь попробовать. Я подстрахую, если начнёт мстить"
    gg "Cô có thể thử. Tôi sẽ trông chừng nếu nó bắt đầu trả thù."

# game/kitchen.rpy:528
translate english maya_Idle_morning_kitchen_scene_f6d334fe:

    # Maya "Вот именно поэтому я по утрам не встаю"
    Maya "Chính vì thế mà buổi sáng tôi không dậy nổi."

# game/kitchen.rpy:530
translate english maya_Idle_morning_kitchen_scene_b8a73fc6:

    # Maya "Мир в это время суток явно против меня"
    Maya "Thế giới vào giờ đó rõ ràng chống lại tôi."

# game/kitchen.rpy:531
translate english maya_Idle_morning_kitchen_scene_92828b86:

    # gg "А я думал, это просто твой ритуал - проспать завтрак и появиться к обеду"
    gg "Mà tôi tưởng đó chỉ là nghi thức của cô - ngủ quên bữa sáng và xuất hiện vào bữa trưa."

# game/kitchen.rpy:533
translate english maya_Idle_morning_kitchen_scene_2d194bcc:

    # Maya "Был"
    Maya "Từng là thế."

# game/kitchen.rpy:534
translate english maya_Idle_morning_kitchen_scene_06f3f849:

    # Maya "Но с твоим появлением режим сбился"
    Maya "Nhưng từ khi cậu xuất hiện, chế độ sinh hoạt bị lệch hết."

# game/kitchen.rpy:536
translate english maya_Idle_morning_kitchen_scene_c5cd9bdc:

    # Maya "Знаешь . . . {w}странно, когда в доме появился кто-то третий"
    Maya "Cậu biết đấy . . . {w}thật kỳ lạ khi trong nhà xuất hiện người thứ ba."

# game/kitchen.rpy:538
translate english maya_Idle_morning_kitchen_scene_0f114d52:

    # gg "“Странно” — в хорошем смысле?"
    gg "“Kỳ lạ” — theo nghĩa tốt chứ？"

# game/kitchen.rpy:540
translate english maya_Idle_morning_kitchen_scene_0392e6e1:

    # Maya "Скорее . . . непривычно."
    Maya "Đúng hơn là . . . không quen."

# game/kitchen.rpy:541
translate english maya_Idle_morning_kitchen_scene_a491b788:

    # Maya "Мы с Соней как будто уже притёрлись. У неё — тишина, у меня — беспорядок"
    Maya "Tôi với Sonya dường như đã quen khớp với nhau rồi. Cô ấy — yên tĩnh, tôi — bừa bộn."

# game/kitchen.rpy:542
translate english maya_Idle_morning_kitchen_scene_f70c520e:

    # Maya "А теперь добавился ты. И вроде ничего не изменилось, но стало . . . другое"
    Maya "Còn giờ có thêm cậu. Và coi như chẳng có gì thay đổi, nhưng lại thành . . . khác đi."

# game/kitchen.rpy:544
translate english maya_Idle_morning_kitchen_scene_ac44cc52:

    # gg "Надеюсь, не хуже"
    gg "Hy vọng là không tệ hơn."

# game/kitchen.rpy:545
translate english maya_Idle_morning_kitchen_scene_7331e581:

    # Maya "Пока нет"
    Maya "Hiện tại thì chưa."

# game/kitchen.rpy:546
translate english maya_Idle_morning_kitchen_scene_a84e22a5:

    # Maya "Иногда даже спокойнее . . . а иногда бесишь"
    Maya "Đôi khi còn yên bình hơn . . . mà đôi khi cậu làm tôi phát điên."

# game/characters_events_idles/maya_idles.rpy:190
translate english maya_Idle_day_kitchen_scene_1cdbaa35:

    # gg "Не верится"
    gg "Không tin được."

# game/characters_events_idles/maya_idles.rpy:191
translate english maya_Idle_day_kitchen_scene_286ac20b:

    # gg "Ты с чаем? Где же твоя коллекция вредных газировок?"
    gg "Cô uống trà à？ Bộ sưu tập nước ngọt có hại của cô đâu rồi？"

# game/characters_events_idles/maya_idles.rpy:193
translate english maya_Idle_day_kitchen_scene_158529f9:

    # Maya "Иногда организм хочет чай и все"
    Maya "Đôi khi cơ thể chỉ muốn trà thế thôi."

# game/characters_events_idles/maya_idles.rpy:194
translate english maya_Idle_day_kitchen_scene_61e5a4a1:

    # Maya "И не хочу, чтобы Соня опять читала лекцию о “здоровом балансе”"
    Maya "Và tôi không muốn Sonya lại giảng bài về “cân bằng lành mạnh”."

# game/characters_events_idles/maya_idles.rpy:195
translate english maya_Idle_day_kitchen_scene_0a361203:

    # gg "О, значит, это не просто чай - это акт самопожертвования"
    gg "Ồ, vậy đây không chỉ là trà - mà là hành động tự hiến thân."

# game/characters_events_idles/maya_idles.rpy:197
translate english maya_Idle_day_kitchen_scene_d1dbd3ae:

    # Maya "Ага. Пью и страдаю"
    Maya "Ừ. Tôi uống và đau khổ."

# game/characters_events_idles/maya_idles.rpy:199
translate english maya_Idle_day_kitchen_scene_8b4629d0:

    # Maya "Ладно, раз уж ты сам подошёл - что планируешь делать?"
    Maya "Thôi được, cậu tự đến đây rồi - cậu định làm gì？"

# game/characters_events_idles/maya_idles.rpy:200
translate english maya_Idle_day_kitchen_scene_51392b4e:

    # gg "В смысле?"
    gg "Ý cô là sao？"

# game/characters_events_idles/maya_idles.rpy:202
translate english maya_Idle_day_kitchen_scene_e2d10f18:

    # Maya "Ну, в целом"
    Maya "À, nói chung ấy."

# game/characters_events_idles/maya_idles.rpy:203
translate english maya_Idle_day_kitchen_scene_3b447692:

    # Maya "Сидеть, отдыхать, страдать или притворяться, что у тебя есть план?"
    Maya "Ngồi không, nghỉ ngơi, đau khổ hay giả vờ rằng cậu có kế hoạch？"

# game/characters_events_idles/maya_idles.rpy:204
translate english maya_Idle_day_kitchen_scene_ba096a56:

    # gg "План есть - не иметь плана. Хотя, если честно, я просто устал от города"
    gg "Kế hoạch là không có kế hoạch. Dù thật lòng thì tôi chỉ mệt mỏi vì thành phố."

# game/characters_events_idles/maya_idles.rpy:205
translate english maya_Idle_day_kitchen_scene_a341feee:

    # gg "Хотел отдохнуть, помочь бабушке с домом . . . {w}ну, а теперь, похоже, пора искать работу"
    gg "Tôi muốn nghỉ ngơi, giúp bà với việc nhà . . . {w}à, còn giờ có vẻ đã đến lúc phải tìm việc."

# game/characters_events_idles/maya_idles.rpy:207
translate english maya_Idle_day_kitchen_scene_226b1041:

    # Maya "Добро пожаловать в реальность"
    Maya "Chào mừng đến với thực tại."

# game/characters_events_idles/maya_idles.rpy:208
translate english maya_Idle_day_kitchen_scene_a886fda9:

    # Maya "И где ищут работу люди, которые сбежали от людей?"
    Maya "Thế người chạy trốn khỏi con người thì tìm việc ở đâu？"

# game/characters_events_idles/maya_idles.rpy:210
translate english maya_Idle_day_kitchen_scene_a73a3597:

    # gg "Пока не знаю. Может, в посёлке что-то найду"
    gg "Chưa biết nữa. Có lẽ tôi sẽ tìm được gì đó trong thị trấn."

# game/characters_events_idles/maya_idles.rpy:211
translate english maya_Idle_day_kitchen_scene_a04c7319:

    # gg "Мне и ритм нравится - медленный, настоящий"
    gg "Tôi cũng thích nhịp sống ở đây - chậm rãi, thật."

# game/characters_events_idles/maya_idles.rpy:212
translate english maya_Idle_day_kitchen_scene_4dc705a2:

    # Maya "Настоящий?"
    Maya "Thật á？"

# game/characters_events_idles/maya_idles.rpy:213
translate english maya_Idle_day_kitchen_scene_57978980:

    # Maya "Это пока ты не застрянешь тут зимой"
    Maya "Đó là cho đến khi cậu bị kẹt ở đây vào mùa đông."

# game/characters_events_idles/maya_idles.rpy:214
translate english maya_Idle_day_kitchen_scene_25de1f66:

    # gg "Зато не метро и не толпы"
    gg "Bù lại không có tàu điện ngầm và đám đông."

# game/characters_events_idles/maya_idles.rpy:216
translate english maya_Idle_day_kitchen_scene_f04c48a5:

    # Maya "Ну да. Только мы и Барсик, который судя по всему - местный депутат"
    Maya "Ừ nhỉ. Chỉ có chúng ta và Barsik, mà xem ra là nghị viên địa phương."

# game/characters_events_idles/maya_idles.rpy:217
translate english maya_Idle_day_kitchen_scene_9b820f0a:

    # gg "Главное, чтобы не требовал отчёта о проделанной работе"
    gg "Quan trọng là nó đừng đòi báo cáo công việc đã làm."

# game/characters_events_idles/maya_idles.rpy:219
translate english maya_Idle_day_kitchen_scene_67b66e53:

    # Maya "Ага. Хотя Соня могла бы - она бы тебе график расписала"
    Maya "Ừ. Dù Sonya thì có thể đấy - cô ấy sẽ vạch lịch trình cho cậu ngay."

# game/characters_events_idles/maya_idles.rpy:220
translate english maya_Idle_day_kitchen_scene_d9d4e1ed:

    # gg "Я замечал. У неё всё как по часам"
    gg "Tôi để ý rồi. Mọi thứ của cô ấy đều như theo đồng hồ."

# game/characters_events_idles/maya_idles.rpy:222
translate english maya_Idle_day_kitchen_scene_8841e92a:

    # Maya "Потому что кто-то в этом доме должен компенсировать мой хаос"
    Maya "Bởi vì ai đó trong ngôi nhà này phải bù đắp cho sự hỗn loạn của tôi."

# game/characters_events_idles/maya_idles.rpy:224
translate english maya_Idle_day_kitchen_scene_962fec54:

    # Maya "Так что, если решишь остаться надолго, готовься привыкать к контрастам"
    Maya "Nên nếu cậu định ở lâu dài thì chuẩn bị tập quen với những mâu thuẫn tương phản đi."

# game/characters_events_idles/maya_idles.rpy:225
translate english maya_Idle_day_kitchen_scene_5401d48b:

    # gg "Мне кажется, я уже начинаю"
    gg "Tôi nghĩ là tôi bắt đầu quen rồi."

# game/characters_events_idles/maya_idles.rpy:226
translate english maya_Idle_day_kitchen_scene_a207aba8:

    # Maya "Осторожнее"
    Maya "Cẩn thận đấy."

# game/characters_events_idles/maya_idles.rpy:227
translate english maya_Idle_day_kitchen_scene_2fbe2d88:

    # Maya "Это затягивает"
    Maya "Cái này gây nghiện."

# game/mayaroom.rpy:377
translate english maya_Idle_morning_mayaroom_scene_f8fe1494:

    # gg ". . . "
    gg ". . . "

# game/mayaroom.rpy:378
translate english maya_Idle_morning_mayaroom_scene_7e0bd9fb:

    # gg "Так сладко спит"
    gg "Ngủ ngon thật."

# game/characters_events_idles/maya_idles.rpy:253
translate english maya_Idle_day_mayaroom_scene_94873986:

    # gg "Серьёзный вид"
    gg "Vẻ mặt nghiêm túc ghê."

# game/characters_events_idles/maya_idles.rpy:254
translate english maya_Idle_day_mayaroom_scene_80d9437f:

    # gg "Ты что, музыку миксуешь?"
    gg "Cô đang mix nhạc à？"

# game/characters_events_idles/maya_idles.rpy:256
translate english maya_Idle_day_mayaroom_scene_f4b03c23:

    # Maya "Ха, мечтай. Работаю"
    Maya "Ha, mơ đi. Tôi đang làm việc."

# game/characters_events_idles/maya_idles.rpy:257
translate english maya_Idle_day_mayaroom_scene_f8277c64:

    # gg "Звучит опасно. А я думал, ты против дисциплины"
    gg "Nghe nguy hiểm đấy. Mà tôi tưởng cô phản đối kỷ luật."

# game/characters_events_idles/maya_idles.rpy:259
translate english maya_Idle_day_mayaroom_scene_7888996f:

    # Maya "Я против бессмысленной дисциплины"
    Maya "Tôi phản đối kỷ luật vô nghĩa."

# game/characters_events_idles/maya_idles.rpy:260
translate english maya_Idle_day_mayaroom_scene_927b0fd4:

    # Maya "Но если платят - можно и притвориться взрослой"
    Maya "Nhưng nếu có tiền thì cũng có thể giả làm người lớn."

# game/characters_events_idles/maya_idles.rpy:261
translate english maya_Idle_day_mayaroom_scene_d96b72a5:

    # gg "И что за работа?"
    gg "Thế công việc gì？"

# game/characters_events_idles/maya_idles.rpy:263
translate english maya_Idle_day_mayaroom_scene_c6edbdd9:

    # Maya "Связано с проектами. Неинтересно"
    Maya "Liên quan đến dự án. Chẳng thú vị đâu."

# game/characters_events_idles/maya_idles.rpy:264
translate english maya_Idle_day_mayaroom_scene_3908c185:

    # Maya "Раньше приходилось ездить в офис, а теперь могу делать всё из дома"
    Maya "Trước đây phải đến văn phòng, còn giờ tôi có thể làm mọi thứ từ nhà."

# game/characters_events_idles/maya_idles.rpy:266
translate english maya_Idle_day_mayaroom_scene_0fc56267:

    # Maya "Так что не мешай моей продуктивности"
    Maya "Nên đừng cản trở năng suất của tôi."

# game/characters_events_idles/maya_idles.rpy:267
translate english maya_Idle_day_mayaroom_scene_77dec125:

    # gg "Не мешаю"
    gg "Tôi có cản đâu."

# game/characters_events_idles/maya_idles.rpy:268
translate english maya_Idle_day_mayaroom_scene_585ed193:

    # gg "Просто проверяю, не заснула ли ты с открытым документом"
    gg "Chỉ kiểm tra xem cô có ngủ gật với tài liệu còn mở không thôi."

# game/characters_events_idles/maya_idles.rpy:270
translate english maya_Idle_day_mayaroom_scene_e95f31f8:

    # Maya "Ещё нет"
    Maya "Chưa đâu."

# game/characters_events_idles/maya_idles.rpy:271
translate english maya_Idle_day_mayaroom_scene_4d0580f6:

    # Maya "Но если будешь стоять и таращиться, это ускорит процесс"
    Maya "Nhưng nếu cậu cứ đứng đó trợn mắt nhìn thì sẽ đẩy nhanh quá trình đấy."

# game/characters_events_idles/maya_idles.rpy:274
translate english maya_Idle_day_mayaroom_scene_d2135720:

    # Maya "И да, на будущее . . ."
    Maya "Và này, từ giờ về sau . . ."

# game/characters_events_idles/maya_idles.rpy:275
translate english maya_Idle_day_mayaroom_scene_8af163bc:

    # Maya "Стучи, когда входишь"
    Maya "Gõ cửa khi vào nhé."

# game/characters_events_idles/maya_idles.rpy:276
translate english maya_Idle_day_mayaroom_scene_9797f5b6:

    # gg "А ты дверь закрывай, если хочешь секретности"
    gg "Thế thì cô đóng cửa đi nếu muốn riêng tư."

# game/characters_events_idles/maya_idles.rpy:278
translate english maya_Idle_day_mayaroom_scene_7d229fff:

    # Maya "Закрытая дверь - это скучно"
    Maya "Cửa đóng thì chán lắm."

# game/characters_events_idles/maya_idles.rpy:279
translate english maya_Idle_day_mayaroom_scene_6d90d8fb:

    # Maya "Мне нравится знать, что кто-то может ввалиться в самый неподходящий момент. Добавляет адреналина"
    Maya "Tôi thích biết rằng ai đó có thể xộc vào đúng lúc không thích hợp nhất. Nó tăng adrenaline."

# game/characters_events_idles/maya_idles.rpy:280
translate english maya_Idle_day_mayaroom_scene_5348c7b0:

    # gg "Опасное хобби"
    gg "Sở thích nguy hiểm."

# game/characters_events_idles/maya_idles.rpy:295
translate english maya_Idle_evening_mayaroom_scene_c74a33fe:

    # gg "Опять зависла?"
    gg "Lại treo máy à？"

# game/characters_events_idles/maya_idles.rpy:297
translate english maya_Idle_evening_mayaroom_scene_66aa8fb0:

    # Maya "Называется “отдыхаю”"
    Maya "Cái này gọi là “đang nghỉ ngơi”."

# game/characters_events_idles/maya_idles.rpy:298
translate english maya_Idle_evening_mayaroom_scene_29fea123:

    # Maya "Иногда даже без музыки"
    Maya "Đôi khi thậm chí không có nhạc."

# game/characters_events_idles/maya_idles.rpy:299
translate english maya_Idle_evening_mayaroom_scene_bbc28184:

    # gg "Опасный эксперимент"
    gg "Thí nghiệm nguy hiểm."

# game/characters_events_idles/maya_idles.rpy:300
translate english maya_Idle_evening_mayaroom_scene_cc606e86:

    # Maya "Ага. Учёные уже фиксируют первые побочные эффекты - мысли начали возвращаться"
    Maya "Ừ. Các nhà khoa học đã ghi nhận những tác dụng phụ đầu tiên - suy nghĩ bắt đầu quay trở lại."

# game/characters_events_idles/maya_idles.rpy:301
translate english maya_Idle_evening_mayaroom_scene_a4eb2f4d:

    # gg "О чём думаешь?"
    gg "Cô đang nghĩ gì？"

# game/characters_events_idles/maya_idles.rpy:303
translate english maya_Idle_evening_mayaroom_scene_f963639a:

    # Maya "Ни о чём особенном. Просто день какой-то неспокойный"
    Maya "Không có gì đặc biệt. Chỉ là hôm nay có vẻ không yên ổn."

# game/mayaroom.rpy:442
translate english maya_Idle_evening_mayaroom_scene_9622db09:

    # Maya "Иногда мне кажется, что этот дом дышит"
    Maya "Đôi khi tôi thấy ngôi nhà này đang thở."

# game/mayaroom.rpy:443
translate english maya_Idle_evening_mayaroom_scene_0a637ee0:

    # Maya "Когда все расходятся по комнатам, он будто вздыхает - типа “наконец-то”"
    Maya "Khi mọi người tản về phòng, nó như thở phào - kiểu “cuối cùng cũng xong”."

# game/mayaroom.rpy:444
translate english maya_Idle_evening_mayaroom_scene_c4190f3c:

    # gg "Может, он просто устал от нас"
    gg "Có lẽ nó chỉ mệt vì chúng ta."

# game/mayaroom.rpy:446
translate english maya_Idle_evening_mayaroom_scene_9a1cfc06:

    # Maya "Или от тебя"
    Maya "Hoặc mệt vì cậu."

# game/mayaroom.rpy:447
translate english maya_Idle_evening_mayaroom_scene_9ca1630b:

    # Maya "Ты ж теперь главный источник событий"
    Maya "Giờ cậu là nguồn sự kiện chính mà."

# game/mayaroom.rpy:448
translate english maya_Idle_evening_mayaroom_scene_4618c7f3:

    # gg "Ну спасибо"
    gg "Thôi cảm ơn nhé."

# game/mayaroom.rpy:449
translate english maya_Idle_evening_mayaroom_scene_9314e70f:

    # gg "Хоть не шумовой загрязнитель"
    gg "Ít nhất không phải kẻ gây ô nhiễm tiếng ồn."

# game/mayaroom.rpy:451
translate english maya_Idle_evening_mayaroom_scene_1c9556b7:

    # Maya "Не переживай, ты в двух шагах от этого звания"
    Maya "Đừng lo, cậu chỉ còn hai bước nữa là đạt danh hiệu đó."

# game/mayaroom.rpy:454
translate english maya_Idle_evening_mayaroom_scene_3ece4663:

    # gg "Ладно, не мешаю твоему “отдыханию”"
    gg "Được rồi, tôi không làm phiền việc “nghỉ ngơi” của cô nữa."

# game/mayaroom.rpy:455
translate english maya_Idle_evening_mayaroom_scene_c8d80171:

    # Maya "Уже поздно. Ты в моём поле общения, это необратимо"
    Maya "Muộn rồi. Cậu đang ở trong vùng giao tiếp của tôi, không thể đảo ngược."

# game/mayaroom.rpy:456
translate english maya_Idle_evening_mayaroom_scene_52424bb1:

    # gg "Тогда я официально заражён"
    gg "Vậy là tôi chính thức bị lây nhiễm."

# game/mayaroom.rpy:446
translate english maya_Idle_night_mayaroom_scene_f715f6b4:

    # gg "Спит без задних ног . . ."
    gg "Ngủ say như chết . . ."

# game/mayaroom.rpy:447
translate english maya_Idle_night_mayaroom_scene_fd8d0a8c:

    # gg "Хоть будильник под ухом взрывай — не проснётся"
    gg "Có cho nổ cả đồng hồ báo thức bên tai — chắc cũng không dậy."

# game/myroom.rpy:521
translate english maya_Idle_evening_myroom_scene_f6ddbad8:

    # gg "Засыпаешь?"
    gg "Cô buồn ngủ à？"

# game/myroom.rpy:523
translate english maya_Idle_evening_myroom_scene_60b26d3f:

    # Maya "Нет. Просто отдыхаю в позе ленивой медитации"
    Maya "Không. Chỉ là đang nghỉ ngơi trong tư thế thiền lười."

# game/myroom.rpy:524
translate english maya_Idle_evening_myroom_scene_5197b7fb:

    # gg "Выглядит как битва с подушкой на выживание"
    gg "Trông như đang đấu vật sinh tồn với cái gối."

# game/myroom.rpy:526
translate english maya_Idle_evening_myroom_scene_ef00b824:

    # Maya "Ха. Не завидуй"
    Maya "Ha. Đừng ghen tị."

# game/myroom.rpy:528
translate english maya_Idle_evening_myroom_scene_87bfdb57:

    # gg "Соня говорила что спала раньше на этом диване. Он удобный"
    gg "Sonya nói trước đây cô ấy từng ngủ trên chiếc sofa này. Nó êm lắm."

# game/myroom.rpy:529
translate english maya_Idle_evening_myroom_scene_b9e42dcf:

    # Maya "Ага. Она любила здесь засыпать под телевизор"
    Maya "Ừ. Cô ấy thích ngủ thiếp đi ở đây trước ti vi."

# game/myroom.rpy:530
translate english maya_Idle_evening_myroom_scene_01c1b004:

    # Maya "Говорила, что этот гул помогает думать"
    Maya "Cô ấy nói tiếng ù ù đó giúp suy nghĩ."

# game/myroom.rpy:533
translate english maya_Idle_evening_myroom_scene_69ea4813:

    # Maya "А теперь вот ты"
    Maya "Còn giờ là cậu."

# game/myroom.rpy:534
translate english maya_Idle_evening_myroom_scene_1c914aec:

    # Maya "И диван как будто сменил хозяина"
    Maya "Và cái sofa như đổi chủ."

# game/myroom.rpy:535
translate english maya_Idle_evening_myroom_scene_c99ae1d2:

    # gg "Ничего, я постараюсь не испортить его репутацию"
    gg "Không sao, tôi sẽ cố không làm hỏng danh tiếng của nó."

# game/myroom.rpy:536
translate english maya_Idle_evening_myroom_scene_4ed4ce95:

    # Maya "Да уж, будь добр"
    Maya "Ừ đấy, làm ơn đi."

# game/myroom.rpy:537
translate english maya_Idle_evening_myroom_scene_a777aa23:

    # Maya "У него длинная история, он видел больше ссор и сериалов, чем мы оба вместе"
    Maya "Nó có lịch sử dài, nó đã chứng kiến nhiều cãi vã và phim truyền hình hơn cả hai chúng ta cộng lại."

# game/myroom.rpy:538
translate english maya_Idle_evening_myroom_scene_3f329134:

    # gg "Кстати, а вы вообще платите Линде за жильё? Или это всё “по знакомству”?"
    gg "Mà tiện thể, các cô có trả tiền cho Linda để ở không？ Hay tất cả là “nhờ quen biết”？"

# game/myroom.rpy:540
translate english maya_Idle_evening_myroom_scene_ac2bb573:

    # Maya "Платим . . . {w}Ну как “платим” - скорее благодарим"
    Maya "Bọn tôi trả . . . {w}À, “trả” theo kiểu - đúng hơn là cảm ơn."

# game/myroom.rpy:541
translate english maya_Idle_evening_myroom_scene_b48308d4:

    # Maya "Сумма символическая, Линда больше из принципа берёт, чем из необходимости"
    Maya "Số tiền chỉ mang tính tượng trưng, Linda nhận vì nguyên tắc nhiều hơn là vì cần."

# game/myroom.rpy:542
translate english maya_Idle_evening_myroom_scene_361a0566:

    # Maya "Её это, кажется, успокаивает: типа дом не стоит пустой и приносит пользу"
    Maya "Có vẻ điều đó làm cô ấy yên tâm: kiểu ngôi nhà không bị bỏ trống và vẫn có ích."

# game/myroom.rpy:543
translate english maya_Idle_evening_myroom_scene_e9782332:

    # gg "Узнаю свою бабушку"
    gg "Tôi nhận ra bà mình rồi."

# game/myroom.rpy:545
translate english maya_Idle_evening_myroom_scene_5822e6c1:

    # Maya "Ага. Только вот было бы ещё хорошо, если бы она хотя бы предупредила, что внучок вот-вот приедет"
    Maya "Ừ. Chỉ có điều sẽ tốt hơn nếu cô ấy ít nhất báo trước rằng cháu trai sắp đến."

# game/myroom.rpy:546
translate english maya_Idle_evening_myroom_scene_3f1ab8b6:

    # Maya "Я чуть не упала тогда, когда ты появился в дверях"
    Maya "Lúc cậu xuất hiện ở cửa, tôi suýt ngã."

# game/myroom.rpy:547
translate english maya_Idle_evening_myroom_scene_1bd89a55:

    # Maya "Уже чего только не думала"
    Maya "Tôi đã nghĩ đủ thứ rồi."

# game/myroom.rpy:548
translate english maya_Idle_evening_myroom_scene_5d3dcdb5:

    # gg "Извини, я тоже не ожидал, что в доме будут люди"
    gg "Xin lỗi, tôi cũng không ngờ trong nhà lại có người."

# game/myroom.rpy:549
translate english maya_Idle_evening_myroom_scene_43ff1f8d:

    # Maya "Вот и замечательно"
    Maya "Thế thì tuyệt."

# game/myroom.rpy:550
translate english maya_Idle_evening_myroom_scene_6c224d29:

    # Maya "Никто ничего не ожидал - поэтому всё как обычно"
    Maya "Chẳng ai ngờ gì cả - nên mọi thứ vẫn như bình thường."

# game/myroom.rpy:553
translate english maya_Idle_evening_myroom_scene_cbdc658c:

    # Maya "Знаешь, может, это и к лучшему"
    Maya "Cậu biết đấy, có lẽ thế lại tốt hơn."

# game/myroom.rpy:554
translate english maya_Idle_evening_myroom_scene_10ae6709:

    # gg "Я стараюсь как лучше"
    gg "Tôi đang cố làm điều tốt nhất."

# game/myroom.rpy:555
translate english maya_Idle_evening_myroom_scene_2738bbdd:

    # Maya "Ладно, ты уже часть декора"
    Maya "Thôi được, cậu đã là một phần của đồ trang trí rồi."

# game/myroom.rpy:556
translate english maya_Idle_evening_myroom_scene_a3e55433:

    # Maya "Даже телевизор теперь включается по тебе"
    Maya "Đến cái ti vi giờ cũng bật theo cậu."

# game/myroom.rpy:557
translate english maya_Idle_evening_myroom_scene_51392b4e:

    # gg "В смысле?"
    gg "Ý cô là sao？"

# game/myroom.rpy:558
translate english maya_Idle_evening_myroom_scene_6214a218:

    # Maya "Стоит тебе появиться - сразу что-то происходит. Иногда полезное, иногда нет"
    Maya "Hễ cậu xuất hiện là có chuyện gì đó xảy ra ngay. Đôi khi có ích, đôi khi không."

# game/myroom.rpy:559
translate english maya_Idle_evening_myroom_scene_a17c73ec:

    # Maya "Но скучно с тобой не бывает"
    Maya "Nhưng ở cạnh cậu không bao giờ buồn."

# game/myroom.rpy:561
translate english maya_Idle_evening_myroom_scene_3edde83f:

    # Maya "Всё, вечер окончен"
    Maya "Thôi, buổi tối kết thúc rồi."

# game/myroom.rpy:562
translate english maya_Idle_evening_myroom_scene_2082f32a:

    # Maya "Телевизор устал смотреть на нас"
    Maya "Cái ti vi mệt vì nhìn chúng ta rồi."

# game/myroom.rpy:563
translate english maya_Idle_evening_myroom_scene_3c45ded0:

    # gg "Тогда спокойной ночи"
    gg "Vậy chúc ngủ ngon."

# game/myroom.rpy:564
translate english maya_Idle_evening_myroom_scene_9adb5a5c:

    # Maya "Ага. И не растяни диван - он к тебе уже привязался"
    Maya "Ừ. Và đừng có làm giãn cái sofa - nó đã gắn bó với cậu rồi."

translate english strings:

    # game/characters_events_idles/maya_idles.rpy:5
    old "Барсик у тебя?"
    new "Barsik đang ở chỗ cậu à？"

    # game/characters_events_idles/maya_idles.rpy:43
    old "Позже зайду"
    new "Lát nữa tôi qua."

    # game/characters_events_idles/maya_idles.rpy:52
    old "С книжкой с утра?"
    new "Đọc sách từ sáng à？"

    # game/characters_events_idles/maya_idles.rpy:102
    old "Не мешаю"
    new "Không làm phiền."

    # game/characters_events_idles/maya_idles.rpy:111
    old "Ко сну готовишься?"
    new "Chuẩn bị đi ngủ à？"

    # game/characters_events_idles/maya_idles.rpy:136
    old "Не буду мешать"
    new "Tôi sẽ không làm phiền."

    # game/characters_events_idles/maya_idles.rpy:145
    old "Новый рецепт?"
    new "Công thức mới à？"

    # game/characters_events_idles/maya_idles.rpy:188
    old "Газировка кончилась?"
    new "Hết nước ngọt rồi à？"

    # game/characters_events_idles/maya_idles.rpy:231
    old "Пойду"
    new "Tôi đi đây."

    # game/characters_events_idles/maya_idles.rpy:240
    old "Не беспокоить"
    new "Đừng làm phiền."

    # game/characters_events_idles/maya_idles.rpy:251
    old "Музыку миксуешь?"
    new "Đang mix nhạc à？"

    # game/characters_events_idles/maya_idles.rpy:284
    old "Уйти"
    new "Rời đi."

    # game/characters_events_idles/maya_idles.rpy:293
    old "Опять зависла?"
    new "Lại treo máy à？"

    # game/characters_events_idles/maya_idles.rpy:343
    old "Засыпаешь?"
    new "Buồn ngủ à？"

# TODO: Translation updated at 2026-01-27 22:55

# game/characters_events_idles/maya_idles.rpy:88
translate english maya_Idle_morning_myroom_scene_4e7209b5:

    # Maya "С тех пор она - порядок, я - импровизация"
    Maya "Từ đó, cô ấy - trật tự, tôi - ngẫu hứng."

# game/characters_events_idles/maya_idles.rpy:167
translate english maya_Idle_morning_kitchen_scene_2d60322d:

    # gg "“Странно” - в хорошем смысле?"
    gg "“Kỳ lạ” - theo nghĩa tốt chứ？"

# game/characters_events_idles/maya_idles.rpy:170
translate english maya_Idle_morning_kitchen_scene_09dca06f:

    # Maya "Мы с Соней как будто уже притёрлись. У неё - тишина, у меня - беспорядок"
    Maya "Tôi với Sonya dường như đã quen khớp với nhau rồi. Cô ấy - yên tĩnh, tôi - bừa bộn."

