﻿# TODO: Translation updated at 2026-01-21 02:04

# game/bathroom.rpy:81
translate english sonya_Idle_morning_bathroom_scene_26477ebd:

    # Sonya "О, кто-то перестал стучаться?"
    Sonya "Ồ, có người thôi gõ cửa rồi à？"

# game/bathroom.rpy:82
translate english sonya_Idle_morning_bathroom_scene_e490c24b:

    # gg "А смысл, если дверь открыта . . ."
    gg "Còn ý nghĩa gì nữa nếu cửa đã mở . . ."

# game/bathroom.rpy:84
translate english sonya_Idle_morning_bathroom_scene_2e0a6a8c:

    # Sonya "Смелый стал с утра . . ."
    Sonya "Sáng sớm đã táo bạo lên rồi . . ."

# game/bathroom.rpy:86
translate english sonya_Idle_morning_bathroom_scene_f7e61e71:

    # gg "Просто решил не терять привычку к риску"
    gg "Chỉ là quyết định không đánh mất thói quen mạo hiểm"

# game/bathroom.rpy:87
translate english sonya_Idle_morning_bathroom_scene_31735247:

    # gg_chat "Она даже в такие моменты выглядит так, будто специально проверяет, насколько далеко можно зайти"
    gg_chat "Cô ấy ngay cả trong những lúc như vậy trông cứ như thể cố tình thử xem có thể đi xa đến đâu"

# game/bathroom.rpy:89
translate english sonya_Idle_morning_bathroom_scene_43fc63bc:

    # Sonya "Хочешь полюбоваться видом?"
    Sonya "Muốn ngắm cảnh không？"

# game/bathroom.rpy:91
translate english sonya_Idle_morning_bathroom_scene_274bd888:

    # Sonya "Я не против"
    Sonya "Tôi không phản đối"

# game/bathroom.rpy:92
translate english sonya_Idle_morning_bathroom_scene_e8a5a241:

    # gg "С таким предложением даже утренний кофе станет лишним"
    gg "Với lời đề nghị như vậy thì cả cà phê sáng cũng thành thừa"

# game/bathroom.rpy:94
translate english sonya_Idle_morning_bathroom_scene_14ae5b75:

    # Sonya "Ну хоть кто-то ценит мой вклад в твое утро"
    Sonya "Ít nhất thì cũng có người trân trọng đóng góp của tôi vào buổi sáng của anh"

# game/bathroom.rpy:96
translate english sonya_Idle_morning_bathroom_scene_daf8e8db:

    # gg "Смотря, что ты предложишь взамен"
    gg "Còn tùy em sẽ đề nghị gì để đáp lại"

# game/bathroom.rpy:98
translate english sonya_Idle_morning_bathroom_scene_2ff9a6da:

    # Sonya "Знаешь, я бы тоже не отказалась провести утро поинтереснее"
    Sonya "Biết không, tôi cũng không ngại dành buổi sáng một cách thú vị hơn"

# game/bathroom.rpy:100
translate english sonya_Idle_morning_bathroom_scene_e6700bf3:

    # Sonya "Особенно с тобой"
    Sonya "Đặc biệt là với anh"

# game/bathroom.rpy:101
translate english sonya_Idle_morning_bathroom_scene_9a24ffbd:

    # gg "Звучит как приглашение"
    gg "Nghe như một lời mời"

# game/bathroom.rpy:103
translate english sonya_Idle_morning_bathroom_scene_818d5283:

    # Sonya "Да это оно. Но, увы, у меня дела"
    Sonya "Đúng, chính là nó. Nhưng tiếc là tôi có việc"

# game/bathroom.rpy:104
translate english sonya_Idle_morning_bathroom_scene_82d60fb2:

    # gg "Ты знаешь это нечестно"
    gg "Em biết điều đó không công bằng mà"

# game/bathroom.rpy:106
translate english sonya_Idle_morning_bathroom_scene_0d7eca0c:

    # Sonya "Я просто оставляю десерт на потом"
    Sonya "Tôi chỉ để dành món tráng miệng cho sau này thôi"

# game/bathroom.rpy:108
translate english sonya_Idle_morning_bathroom_scene_0d86f13a:

    # Sonya "Ну что ж, герой, ванная вся твоя"
    Sonya "Vậy thì, anh hùng, phòng tắm là của anh cả"

# game/bathroom.rpy:109
translate english sonya_Idle_morning_bathroom_scene_3e148853:

    # Sonya "Главное, когда будешь мыться не забудь, кто тебя вдохновил"
    Sonya "Điều quan trọng là khi tắm đừng quên ai đã truyền cảm hứng cho anh"

# game/bathroom.rpy:288
translate english sonya_Idle_evening_bathroom_scene_247f83e8:

    # gg "Не думал, что можно так красиво мыться под душем"
    gg "Không nghĩ là có thể tắm dưới vòi sen đẹp đến vậy"

# game/bathroom.rpy:289
translate english sonya_Idle_evening_bathroom_scene_361d1da4:

    # Sonya "Я знала, что ты заглянешь"
    Sonya "Tôi biết là anh sẽ ghé qua"

# game/bathroom.rpy:290
translate english sonya_Idle_evening_bathroom_scene_dd689906:

    # Sonya "У тебя шаги узнаются ещё до двери"
    Sonya "Bước chân của anh được nhận ra từ trước cả khi tới cửa"

# game/bathroom.rpy:292
translate english sonya_Idle_evening_bathroom_scene_69f260a8:

    # gg "Хотел убедиться, что ты не уплыла в параллельную реальность"
    gg "Muốn chắc chắn rằng em không trôi dạt sang thực tại song song"

# game/bathroom.rpy:293
translate english sonya_Idle_evening_bathroom_scene_81769a4a:

    # Sonya "Ещё нет. Хотя, если бы там было потеплее — можно было бы и остаться"
    Sonya "Chưa đâu. Dù nếu ở đó ấm hơn — có khi tôi đã ở lại rồi"

# game/bathroom.rpy:295
translate english sonya_Idle_evening_bathroom_scene_1517ae3e:

    # Sonya "Знаешь, если бы я захотела — могла бы тебя соблазнить прямо сейчас"
    Sonya "Biết không, nếu tôi muốn — tôi có thể quyến rũ anh ngay bây giờ"

# game/bathroom.rpy:296
translate english sonya_Idle_evening_bathroom_scene_1371ca10:

    # Sonya "Только чтобы забрать себе"
    Sonya "Chỉ để giữ anh cho riêng mình"

# game/bathroom.rpy:298
translate english sonya_Idle_evening_bathroom_scene_21c8c83c:

    # Sonya "Но ты ведь тогда точно не ушёл бы, да?"
    Sonya "Nhưng khi đó anh chắc chắn sẽ không rời đi, phải không？"

# game/bathroom.rpy:299
translate english sonya_Idle_evening_bathroom_scene_e75862b1:

    # gg "Вряд ли бы смог"
    gg "Chắc khó mà đi được"

# game/bathroom.rpy:302
translate english sonya_Idle_evening_bathroom_scene_6b3e3f56:

    # Sonya "Вот именно, поэтому уходи"
    Sonya "Đúng thế, nên là đi đi"

# game/bathroom.rpy:303
translate english sonya_Idle_evening_bathroom_scene_0c771583:

    # Sonya "Пока Мая не заглянула и не устроила мне лекцию на тему “личных границ”"
    Sonya "Trước khi Maya ghé vào và giảng cho tôi một bài về “ranh giới cá nhân”"

# game/bathroom.rpy:305
translate english sonya_Idle_evening_bathroom_scene_7782c9fd:

    # gg "Значит, спасаю нас обоих"
    gg "Vậy là tôi đang cứu cả hai chúng ta"

# game/bathroom.rpy:306
translate english sonya_Idle_evening_bathroom_scene_61bc67e7:

    # Sonya "Спасай. Но не надолго"
    Sonya "Cứu đi. Nhưng đừng lâu quá"

# game/bathroom.rpy:307
translate english sonya_Idle_evening_bathroom_scene_b8d4595f:

    # gg_chat "Её слова звучали полушуткой, но от этого не становилось легче"
    gg_chat "Những lời cô ấy nghe như nửa đùa, nhưng điều đó không làm mọi chuyện dễ chịu hơn"

# game/bathroom.rpy:308
translate english sonya_Idle_evening_bathroom_scene_0892a9fc:

    # gg_chat "В каждой улыбке Сони теперь пряталось что-то большее, чем просто игра"
    gg_chat "Trong mỗi nụ cười của Sonya giờ đây ẩn giấu điều gì đó nhiều hơn là chỉ một cuộc chơi"

# game/characters_events_idles/sonya_idles.rpy:85
translate english sonya_Idle_morning_girlroom_scene_5a6cf65f:

    # gg "Доброе утро. Ты уже с рассветом на работе?"
    gg "Chào buổi sáng. Em đã làm việc từ lúc bình minh rồi à？"

# game/characters_events_idles/sonya_idles.rpy:87
translate english sonya_Idle_morning_girlroom_scene_782b60a4:

    # Sonya "Почти. У меня тут урожай созрел, не могу бросить"
    Sonya "Gần như vậy. Ở đây vụ mùa của tôi đã chín, không thể bỏ mặc"

# game/characters_events_idles/sonya_idles.rpy:88
translate english sonya_Idle_morning_girlroom_scene_a3c52931:

    # gg "А я думал, ты в такие игры не играешь"
    gg "Còn tôi tưởng em không chơi mấy trò này"

# game/characters_events_idles/sonya_idles.rpy:90
translate english sonya_Idle_morning_girlroom_scene_bbda1d39:

    # Sonya "А зря, это лучшая медитация"
    Sonya "Vậy thì nhầm rồi, đây là cách thiền tốt nhất"

# game/characters_events_idles/sonya_idles.rpy:91
translate english sonya_Idle_morning_girlroom_scene_afc574c1:

    # Sonya "Никакой спешки, просто строишь, выращиваешь, приручаешь кошек"
    Sonya "Không vội vã gì, chỉ xây dựng, trồng trọt, thuần hóa mèo"

# game/characters_events_idles/sonya_idles.rpy:93
translate english sonya_Idle_morning_girlroom_scene_2c50640e:

    # Sonya "Вот, видишь? Мой котик"
    Sonya "Đây, thấy không？ Mèo của tôi"

# game/characters_events_idles/sonya_idles.rpy:94
translate english sonya_Idle_morning_girlroom_scene_4c464678:

    # Sonya "Зовут Барсик"
    Sonya "Tên nó là Barsik"

# game/characters_events_idles/sonya_idles.rpy:95
translate english sonya_Idle_morning_girlroom_scene_cabe3537:

    # gg "Конечно. Даже тут он с тобой"
    gg "Tất nhiên rồi. Ngay cả ở đây nó cũng ở bên em"

# game/characters_events_idles/sonya_idles.rpy:96
translate english sonya_Idle_morning_girlroom_scene_d4be7bb4:

    # Sonya "Да не совсем того цвета, хотя бы не ворует еду"
    Sonya "Ừ, không đúng màu lắm, ít nhất thì nó không ăn trộm đồ ăn"

# game/characters_events_idles/sonya_idles.rpy:97
translate english sonya_Idle_morning_girlroom_scene_725c6cbd:

    # Sonya "И на клавиатуру не ложится"
    Sonya "Và không nằm lên bàn phím"

# game/characters_events_idles/sonya_idles.rpy:98
translate english sonya_Idle_morning_girlroom_scene_fbf5b42b:

    # Sonya "Я построила ему дом. Маленький, но уютный"
    Sonya "Tôi đã xây cho nó một ngôi nhà. Nhỏ nhưng ấm cúng"

# game/characters_events_idles/sonya_idles.rpy:100
translate english sonya_Idle_morning_girlroom_scene_cfe34a6f:

    # gg "Как и в жизни"
    gg "Giống như ngoài đời vậy"

# game/characters_events_idles/sonya_idles.rpy:101
translate english sonya_Idle_morning_girlroom_scene_de0ba10f:

    # Sonya "Возможно. Я люблю, когда всё на своих местах. Даже в пикселях"
    Sonya "Có thể. Tôi thích mọi thứ ở đúng vị trí của nó. Ngay cả trong từng pixel"

# game/characters_events_idles/sonya_idles.rpy:102
translate english sonya_Idle_morning_girlroom_scene_c16cc569:

    # gg "А с монстрами что делаешь?"
    gg "Còn với quái vật thì em làm gì？"

# game/characters_events_idles/sonya_idles.rpy:104
translate english sonya_Idle_morning_girlroom_scene_c08d01fe:

    # Sonya "Ну избегаю. Я не про битвы, я про порядок"
    Sonya "Thì tránh đi. Tôi không nói về chiến đấu, tôi nói về trật tự"

# game/characters_events_idles/sonya_idles.rpy:105
translate english sonya_Idle_morning_girlroom_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "Tôi thích khi mọi thứ đều trong tầm kiểm soát"

# game/characters_events_idles/sonya_idles.rpy:107
translate english sonya_Idle_morning_girlroom_scene_740206dd:

    # gg "Даже кот в игре слушается. Везёт тебе"
    gg "Ngay cả con mèo trong game cũng nghe lời. Em may mắn thật"

# game/characters_events_idles/sonya_idles.rpy:108
translate english sonya_Idle_morning_girlroom_scene_fb402d59:

    # Sonya "А ты попробуй приручи кого-нибудь - узнаешь, что это целая наука"
    Sonya "Còn anh thử thuần hóa ai đó xem - sẽ biết đó là cả một môn khoa học"

# game/characters_events_idles/sonya_idles.rpy:109
translate english sonya_Idle_morning_girlroom_scene_1b49be1f:

    # gg "Думаешь, справлюсь?"
    gg "Em nghĩ tôi sẽ làm được chứ？"

# game/characters_events_idles/sonya_idles.rpy:111
translate english sonya_Idle_morning_girlroom_scene_228ee7fd:

    # Sonya "Сомневаюсь"
    Sonya "Tôi nghi lắm"

# game/characters_events_idles/sonya_idles.rpy:112
translate english sonya_Idle_morning_girlroom_scene_e99c47d3:

    # Sonya "Ты не тот тип, кто строит. Скорее тот, кто случайно всё ломает"
    Sonya "Anh không phải kiểu người xây dựng. Đúng hơn là kiểu vô tình làm hỏng mọi thứ"

# game/characters_events_idles/sonya_idles.rpy:113
translate english sonya_Idle_morning_girlroom_scene_382eac3e:

    # gg "Эй, я в детстве играл. Даже базу под землёй сделал"
    gg "Này, hồi nhỏ tôi có chơi mà. Còn làm cả một căn cứ dưới lòng đất"

# game/characters_events_idles/sonya_idles.rpy:115
translate english sonya_Idle_morning_girlroom_scene_0d62bf92:

    # Sonya "Ага, и подорвал через пять минут?"
    Sonya "Ừ nhỉ, rồi cho nổ tung sau năm phút chứ gì？"

# game/characters_events_idles/sonya_idles.rpy:116
translate english sonya_Idle_morning_girlroom_scene_81cf123c:

    # gg "Через десять. Но всё по плану"
    gg "Sau mười phút. Nhưng mọi thứ đều theo kế hoạch"

# game/characters_events_idles/sonya_idles.rpy:118
translate english sonya_Idle_morning_girlroom_scene_24c0b733:

    # Sonya "Тогда аккуратнее с моим миром"
    Sonya "Vậy thì cẩn thận với thế giới của tôi"

# game/characters_events_idles/sonya_idles.rpy:119
translate english sonya_Idle_morning_girlroom_scene_3938ea91:

    # Sonya "Тут всё с любовью и без взрывчатки"
    Sonya "Ở đây mọi thứ đều bằng tình yêu và không có thuốc nổ"

# game/characters_events_idles/sonya_idles.rpy:120
translate english sonya_Idle_morning_girlroom_scene_5664d0ac:

    # gg "Учту. Буду только наблюдать"
    gg "Tôi sẽ ghi nhớ. Sẽ chỉ quan sát thôi"

# game/characters_events_idles/sonya_idles.rpy:121
translate english sonya_Idle_morning_girlroom_scene_af4f45a5:

    # Sonya "Если хочешь, потом покажу тебе свой сад"
    Sonya "Nếu muốn, lát nữa tôi sẽ cho anh xem khu vườn của tôi"

# game/characters_events_idles/sonya_idles.rpy:122
translate english sonya_Idle_morning_girlroom_scene_91498926:

    # Sonya "Там столько цветов и пчелок"
    Sonya "Ở đó có bao nhiêu là hoa và ong"

# game/characters_events_idles/sonya_idles.rpy:123
translate english sonya_Idle_morning_girlroom_scene_89b49bad:

    # gg "Звучит как место, где тебе действительно спокойно"
    gg "Nghe như một nơi mà em thực sự thấy bình yên"

# game/characters_events_idles/sonya_idles.rpy:124
translate english sonya_Idle_morning_girlroom_scene_4a30e5b0:

    # Sonya "Наверное да, думаю нам стоит поиграть в будущем вместе!"
    Sonya "Chắc là vậy, tôi nghĩ sau này chúng ta nên chơi cùng nhau!"

# game/characters_events_idles/sonya_idles.rpy:125
translate english sonya_Idle_morning_girlroom_scene_c8df07f1:

    # gg "Обязательно . . ."
    gg "Nhất định rồi . . ."

# game/characters_events_idles/sonya_idles.rpy:139
translate english sonya_Idle_day_girlroom_scene_a20a3fae:

    # gg "Привет как дела?"
    gg "Chào, em thế nào？"

# game/characters_events_idles/sonya_idles.rpy:141
translate english sonya_Idle_day_girlroom_scene_9dc60813:

    # Sonya "Эти таблицы просто издеваются надо мной . . ."
    Sonya "Mấy cái bảng này cứ như đang trêu ngươi tôi . . ."

# game/characters_events_idles/sonya_idles.rpy:142
translate english sonya_Idle_day_girlroom_scene_92df120a:

    # Sonya "Хоть бросай всё и иди пасти коров"
    Sonya "Đến mức muốn bỏ hết mà đi chăn bò"

# game/characters_events_idles/sonya_idles.rpy:144
translate english sonya_Idle_day_girlroom_scene_e2f61865:

    # gg "Похоже, у тебя с ними война"
    gg "Có vẻ em đang có một cuộc chiến với chúng"

# game/characters_events_idles/sonya_idles.rpy:146
translate english sonya_Idle_day_girlroom_scene_053f0179:

    # Sonya "Война, да. И я проигрываю с первого дня"
    Sonya "Chiến tranh, đúng vậy. Và tôi thua ngay từ ngày đầu"

# game/characters_events_idles/sonya_idles.rpy:147
translate english sonya_Idle_day_girlroom_scene_d3cbfb79:

    # Sonya "Не знаю, почему все эти цифры так упрямо меня не слушаются"
    Sonya "Không biết vì sao mấy con số này cứ ngoan cố không chịu nghe lời tôi"

# game/characters_events_idles/sonya_idles.rpy:150
translate english sonya_Idle_day_girlroom_scene_8d39ea32:

    # Sonya "Знаешь, я ведь здесь выросла"
    Sonya "Biết không, tôi lớn lên ở đây đấy"

# game/characters_events_idles/sonya_idles.rpy:151
translate english sonya_Idle_day_girlroom_scene_65c67f0f:

    # Sonya "Ну, не прямо в этом доме, но в этом посёлке"
    Sonya "À, không phải ngay trong ngôi nhà này, nhưng là trong khu làng này"

# game/characters_events_idles/sonya_idles.rpy:152
translate english sonya_Idle_day_girlroom_scene_4c34bce3:

    # gg "Правда?"
    gg "Thật à？"

# game/characters_events_idles/sonya_idles.rpy:154
translate english sonya_Idle_day_girlroom_scene_70dec560:

    # Sonya "Да. Тогда всё казалось больше - и улицы, и дома, и даже небо"
    Sonya "Ừ. Hồi đó mọi thứ dường như lớn hơn - cả đường phố, nhà cửa, và cả bầu trời"

# game/characters_events_idles/sonya_idles.rpy:155
translate english sonya_Idle_day_girlroom_scene_d0fea2c7:

    # Sonya "Потом я уехала, думала, найду место получше, что-то новое"
    Sonya "Sau đó tôi rời đi, nghĩ rằng sẽ tìm được một nơi tốt hơn, một điều gì đó mới"

# game/characters_events_idles/sonya_idles.rpy:157
translate english sonya_Idle_day_girlroom_scene_4acb46e4:

    # Sonya "А в итоге вернулась туда, где мне и было хорошо с самого начала"
    Sonya "Rốt cuộc lại quay về nơi mà tôi đã thấy tốt ngay từ đầu"

# game/characters_events_idles/sonya_idles.rpy:158
translate english sonya_Idle_day_girlroom_scene_e5c60ec3:

    # gg "А как ты познакомилась с Линдой?"
    gg "Còn em làm quen với Linda thế nào？"

# game/characters_events_idles/sonya_idles.rpy:160
translate english sonya_Idle_day_girlroom_scene_b9747f5f:

    # Sonya "О, это было случайно"
    Sonya "Ồ, chuyện đó tình cờ lắm"

# game/characters_events_idles/sonya_idles.rpy:161
translate english sonya_Idle_day_girlroom_scene_4203728c:

    # Sonya "Я тогда снимала комнату в соседнем доме, а она как-то увидела, что я таскаю тяжелые коробки и просто подошла помочь"
    Sonya "Hồi đó tôi thuê một căn phòng ở ngôi nhà bên cạnh, còn cô ấy tình cờ thấy tôi đang khiêng mấy cái hộp nặng và chỉ bước đến giúp"

# game/characters_events_idles/sonya_idles.rpy:163
translate english sonya_Idle_day_girlroom_scene_6c6eaa0a:

    # Sonya "С тех пор мы начали общаться"
    Sonya "Từ đó chúng tôi bắt đầu trò chuyện"

# game/characters_events_idles/sonya_idles.rpy:164
translate english sonya_Idle_day_girlroom_scene_a7d57230:

    # Sonya "Она часто звала меня на чай, а потом сказала, что у неё всё равно пустует комната - и я переехала"
    Sonya "Cô ấy thường mời tôi uống trà, rồi sau đó nói rằng phòng của cô ấy vẫn đang trống - và tôi chuyển đến"

# game/characters_events_idles/sonya_idles.rpy:166
translate english sonya_Idle_day_girlroom_scene_d72f25aa:

    # gg "То есть Линда тебя приютила?"
    gg "Tức là Linda đã cho em chỗ ở？"

# game/characters_events_idles/sonya_idles.rpy:168
translate english sonya_Idle_day_girlroom_scene_181e70fe:

    # Sonya "Можно и так сказать"
    Sonya "Có thể nói như vậy"

# game/characters_events_idles/sonya_idles.rpy:169
translate english sonya_Idle_day_girlroom_scene_c5827422:

    # Sonya "Она никогда не делала из этого что-то большое, просто . . . {w}была рядом"
    Sonya "Cô ấy chưa bao giờ làm to chuyện đó, chỉ là . . . {w}ở bên cạnh"

# game/characters_events_idles/sonya_idles.rpy:170
translate english sonya_Idle_day_girlroom_scene_967e2aa8:

    # Sonya "Знаешь, таких людей немного"
    Sonya "Biết không, những người như vậy không nhiều"

# game/characters_events_idles/sonya_idles.rpy:172
translate english sonya_Idle_day_girlroom_scene_6ab10a33:

    # Sonya "А теперь вот я за ее столом"
    Sonya "Còn giờ thì tôi ở ngay bàn làm việc của cô ấy"

# game/characters_events_idles/sonya_idles.rpy:173
translate english sonya_Idle_day_girlroom_scene_75e4a1ee:

    # Sonya "Иногда кажется, что она всё ещё где-то рядом, наблюдает и тихо подсказывает, что делать"
    Sonya "Đôi khi tôi cảm thấy như cô ấy vẫn ở đâu đó quanh đây, quan sát và lặng lẽ mách bảo tôi nên làm gì"

# game/characters_events_idles/sonya_idles.rpy:174
translate english sonya_Idle_day_girlroom_scene_842a9d6c:

    # gg "Может, поэтому тебе так важно всё довести до идеала"
    gg "Có lẽ vì thế mà em thấy việc đưa mọi thứ đến mức hoàn hảo lại quan trọng với em đến vậy"

# game/characters_events_idles/sonya_idles.rpy:176
translate english sonya_Idle_day_girlroom_scene_e1ccf1c4:

    # Sonya "Возможно. Только вот с таблицами идеала точно не получится"
    Sonya "Có thể. Chỉ là với mấy cái bảng thì chắc chắn chẳng đạt được mức hoàn hảo"

# game/characters_events_idles/sonya_idles.rpy:178
translate english sonya_Idle_day_girlroom_scene_cb6d8969:

    # Sonya "Спасибо, что подошёл"
    Sonya "Cảm ơn vì đã ghé qua"

# game/characters_events_idles/sonya_idles.rpy:179
translate english sonya_Idle_day_girlroom_scene_45ba29af:

    # Sonya "Без тебя я бы и дальше злилась на эти несчастные ячейки"
    Sonya "Không có anh thì tôi sẽ tiếp tục tức giận với mấy cái ô đáng thương này"

# game/characters_events_idles/sonya_idles.rpy:180
translate english sonya_Idle_day_girlroom_scene_c55fced7:

    # gg "Рад помочь"
    gg "Rất vui được giúp"

# game/characters_events_idles/sonya_idles.rpy:181
translate english sonya_Idle_day_girlroom_scene_c59d3a8e:

    # gg "Иногда лучший способ справиться с работой - просто отвлечься"
    gg "Đôi khi cách tốt nhất để xử lý công việc là chỉ cần sao nhãng một chút"

# game/characters_events_idles/sonya_idles.rpy:183
translate english sonya_Idle_day_girlroom_scene_dc01f949:

    # Sonya "Ты прав. А можешь мне чаек сделать пожалуйста . . ."
    Sonya "Anh nói đúng. Mà anh có thể pha cho tôi chút trà được không . . ."

# game/characters_events_idles/sonya_idles.rpy:184
translate english sonya_Idle_day_girlroom_scene_307a264f:

    # gg "Да конечно"
    gg "Được, tất nhiên"

# game/characters_events_idles/sonya_idles.rpy:186
translate english sonya_Idle_day_girlroom_scene_b0fc80b8:

    # Sonya "Спасибо огромное"
    Sonya "Cảm ơn rất nhiều"

# game/characters_events_idles/sonya_idles.rpy:187
translate english sonya_Idle_day_girlroom_scene_11813a95:

    # gg_chat "В ней было что-то от Линды - то же спокойствие и мягкость, только моложе, живее"
    gg_chat "Ở cô ấy có điều gì đó của Linda - cũng sự bình thản và dịu dàng ấy, chỉ là trẻ hơn, sống động hơn"

# game/characters_events_idles/sonya_idles.rpy:188
translate english sonya_Idle_day_girlroom_scene_660cc2e9:

    # gg_chat "И, пожалуй, даже теплее"
    gg_chat "Và, có lẽ, thậm chí còn ấm áp hơn"

# game/characters_events_idles/sonya_idles.rpy:203
translate english sonya_Idle_evening_girlroom_scene_42feeaf6:

    # gg "Можно присесть?"
    gg "Tôi ngồi được không？"

# game/characters_events_idles/sonya_idles.rpy:205
translate english sonya_Idle_evening_girlroom_scene_8460369c:

    # Sonya "Можно . . . {w}но с тебя - плата"
    Sonya "Được . . . {w}nhưng anh phải trả phí"

# game/characters_events_idles/sonya_idles.rpy:206
translate english sonya_Idle_evening_girlroom_scene_a599bb6d:

    # gg "Какая?"
    gg "Phí gì？"

# game/characters_events_idles/sonya_idles.rpy:208
translate english sonya_Idle_evening_girlroom_scene_81b816f5:

    # Sonya "Остаться до конца вечера"
    Sonya "Ở lại đến cuối buổi tối"

# game/characters_events_idles/sonya_idles.rpy:209
translate english sonya_Idle_evening_girlroom_scene_e27a7e82:

    # Sonya "И не сбежать"
    Sonya "Và không được bỏ trốn"

# game/characters_events_idles/sonya_idles.rpy:210
translate english sonya_Idle_evening_girlroom_scene_7f2d6628:

    # gg "Если ты обещаешь не гнать - я и до утра не уйду"
    gg "Nếu em hứa không đuổi - tôi sẽ ở lại đến sáng cũng không đi"

# game/characters_events_idles/sonya_idles.rpy:212
translate english sonya_Idle_evening_girlroom_scene_1cdd78f4:

    # Sonya "Тогда, может, и расскажу что-нибудь . . . {w}личное"
    Sonya "Vậy thì, có lẽ, tôi sẽ kể cho anh điều gì đó . . . {w}riêng tư"

# game/characters_events_idles/sonya_idles.rpy:215
translate english sonya_Idle_evening_girlroom_scene_9eb3b8ed:

    # Sonya "Забавно, получилось"
    Sonya "Buồn cười thật, hóa ra lại thành ra thế"

# game/characters_events_idles/sonya_idles.rpy:216
translate english sonya_Idle_evening_girlroom_scene_8bb9cddd:

    # Sonya "Мы с Маей обе любим тишину, но по-разному"
    Sonya "Tôi và Maya đều thích sự im lặng, nhưng theo cách khác nhau"

# game/characters_events_idles/sonya_idles.rpy:217
translate english sonya_Idle_evening_girlroom_scene_fb1f6848:

    # gg "В каком смысле?"
    gg "Theo nghĩa nào？"

# game/characters_events_idles/sonya_idles.rpy:219
translate english sonya_Idle_evening_girlroom_scene_a5d3ae91:

    # Sonya "Она включает музыку, чтобы заглушить всё вокруг"
    Sonya "Cô ấy bật nhạc lên để át đi mọi thứ xung quanh"

# game/characters_events_idles/sonya_idles.rpy:220
translate english sonya_Idle_evening_girlroom_scene_b0cd0795:

    # Sonya "А я наоборот - выключаю, чтобы услышать хоть что-то своё"
    Sonya "Còn tôi thì ngược lại - tắt đi để có thể nghe được chút gì đó của riêng mình"

# game/characters_events_idles/sonya_idles.rpy:221
translate english sonya_Idle_evening_girlroom_scene_7162f44d:

    # gg "Тогда у тебя получается лучше"
    gg "Vậy thì em làm tốt hơn đấy"

# game/characters_events_idles/sonya_idles.rpy:223
translate english sonya_Idle_evening_girlroom_scene_b5b15ec8:

    # Sonya "Ну не знаю"
    Sonya "Ừ thì tôi không biết"

# game/characters_events_idles/sonya_idles.rpy:224
translate english sonya_Idle_evening_girlroom_scene_03522836:

    # Sonya "Просто по-другому"
    Sonya "Chỉ là theo cách khác thôi"

# game/characters_events_idles/sonya_idles.rpy:238
translate english sonya_Idle_night_girlroom_scene_559d1944:

    # gg "Улыбается во сне . . ."
    gg "Cô ấy mỉm cười trong giấc ngủ . . ."

# game/characters_events_idles/sonya_idles.rpy:239
translate english sonya_Idle_night_girlroom_scene_5651af4c:

    # gg "Интересно, что ей снится, раз выглядит такой довольной"
    gg "Không biết cô ấy mơ thấy gì mà trông hài lòng đến vậy"

# game/kitchen.rpy:485
translate english sonya_Idle_morning_kitchen_scene_0b8a14be:

    # gg "Доброе утро, командир чистоты"
    gg "Chào buổi sáng, chỉ huy của sự sạch sẽ"

# game/kitchen.rpy:486
translate english sonya_Idle_morning_kitchen_scene_ed136649:

    # Sonya "Кто-то же должен следить, чтобы кухня не превратилась в поле боя"
    Sonya "Phải có ai đó theo dõi để nhà bếp không biến thành chiến trường chứ"

# game/kitchen.rpy:488
translate english sonya_Idle_morning_kitchen_scene_d094394a:

    # gg "А вдруг Мая проснётся и решит помочь?"
    gg "Lỡ Maya thức dậy và quyết định giúp thì sao？"

# game/kitchen.rpy:490
translate english sonya_Idle_morning_kitchen_scene_c681883f:

    # Sonya "Тогда я просто вымою всё заново"
    Sonya "Vậy thì tôi sẽ chỉ rửa lại mọi thứ từ đầu"

# game/kitchen.rpy:492
translate english sonya_Idle_morning_kitchen_scene_f2c9c474:

    # gg "Значит, тебе нравится, когда всё блестит"
    gg "Vậy là em thích khi mọi thứ đều sáng bóng"

# game/kitchen.rpy:494
translate english sonya_Idle_morning_kitchen_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "Tôi thích khi mọi thứ trong tầm kiểm soát"

# game/kitchen.rpy:495
translate english sonya_Idle_morning_kitchen_scene_86bbbfde:

    # gg "Даже люди?"
    gg "Cả con người nữa à？"

# game/kitchen.rpy:498
translate english sonya_Idle_morning_kitchen_scene_655f980e:

    # Sonya "С людьми сложнее"
    Sonya "Với con người thì khó hơn"

# game/kitchen.rpy:499
translate english sonya_Idle_morning_kitchen_scene_6ae7acf8:

    # Sonya "Они, в отличие от кухни, редко слушаются"
    Sonya "Họ, khác với nhà bếp, hiếm khi nghe lời"

# game/kitchen.rpy:500
translate english sonya_Idle_morning_kitchen_scene_efabb06d:

    # gg "Может, им просто не хватает твоего руководства"
    gg "Có lẽ họ chỉ thiếu sự lãnh đạo của em"

# game/kitchen.rpy:502
translate english sonya_Idle_morning_kitchen_scene_59bb1b63:

    # Sonya "Осторожнее с комплиментами, а то решу, что ты тоже хочешь быть чистеньким"
    Sonya "Cẩn thận với lời khen, không thì tôi sẽ nghĩ anh cũng muốn được sạch sẽ tinh tươm đấy"

# game/kitchen.rpy:503
translate english sonya_Idle_morning_kitchen_scene_19086387:

    # gg "Обещаю быть примерным"
    gg "Tôi hứa sẽ ngoan ngoãn gương mẫu"

# game/kitchen.rpy:504
translate english sonya_Idle_morning_kitchen_scene_de5751f7:

    # gg "Хотя недолго"
    gg "Dù không được lâu"

# game/kitchen.rpy:613
translate english sonya_Idle_evening_kitchen_scene_74d26ab6:

    # gg "Пахнет так, будто кто-то очень старается"
    gg "Mùi thơm cứ như ai đó đang rất cố gắng"

# game/kitchen.rpy:615
translate english sonya_Idle_evening_kitchen_scene_38676ac8:

    # Sonya "А я и стараюсь"
    Sonya "Tôi đang cố gắng thật mà"

# game/kitchen.rpy:616
translate english sonya_Idle_evening_kitchen_scene_adfdb6f3:

    # Sonya "Без рецепта между прочем, просто . . . {w}хочется, чтобы получилось как дома"
    Sonya "Nhân tiện là không có công thức đâu, chỉ là . . . {w}muốn làm sao cho ra vị như ở nhà"

# game/kitchen.rpy:617
translate english sonya_Idle_evening_kitchen_scene_c3970015:

    # gg "Ты часто так готовишь?"
    gg "Em thường nấu như vậy à？"

# game/kitchen.rpy:619
translate english sonya_Idle_evening_kitchen_scene_2d72af39:

    # Sonya "Почти каждый день. С детства так привыкла"
    Sonya "Gần như mỗi ngày. Từ nhỏ tôi đã quen như vậy"

# game/kitchen.rpy:620
translate english sonya_Idle_evening_kitchen_scene_1cbd5882:

    # Sonya "Мне нравилось видеть, как люди садятся за стол и вдруг становятся добрее"
    Sonya "Tôi thích nhìn thấy mọi người ngồi vào bàn và bỗng trở nên tử tế hơn"

# game/kitchen.rpy:622
translate english sonya_Idle_evening_kitchen_scene_33b06e3d:

    # Sonya "Еда делает людей мягче"
    Sonya "Đồ ăn làm con người dịu lại"

# game/kitchen.rpy:623
translate english sonya_Idle_evening_kitchen_scene_4347abfd:

    # Sonya "Даже тех, кто обычно каменные"
    Sonya "Ngay cả những người thường ngày cứng như đá"

# game/kitchen.rpy:625
translate english sonya_Idle_evening_kitchen_scene_3116970e:

    # gg "Может, потому что через неё ты делишься теплом"
    gg "Có lẽ vì qua đó em chia sẻ sự ấm áp"

# game/kitchen.rpy:626
translate english sonya_Idle_evening_kitchen_scene_158f9e29:

    # Sonya "Наверное"
    Sonya "Chắc vậy"

# game/kitchen.rpy:627
translate english sonya_Idle_evening_kitchen_scene_2af7df75:

    # Sonya "Готовить - это ведь не просто накормить"
    Sonya "Nấu ăn - đâu chỉ là cho ăn no"

# game/kitchen.rpy:628
translate english sonya_Idle_evening_kitchen_scene_668b4e51:

    # Sonya "Это сказать: “ты можешь остаться”"
    Sonya "Đó là nói rằng: “bạn có thể ở lại”"

# game/kitchen.rpy:630
translate english sonya_Idle_evening_kitchen_scene_8f974346:

    # Sonya "Помню, в детстве всё время помогала на кухне"
    Sonya "Tôi nhớ hồi nhỏ lúc nào cũng giúp việc trong bếp"

# game/kitchen.rpy:631
translate english sonya_Idle_evening_kitchen_scene_970899ee:

    # Sonya "Мама только улыбалась - говорила, что из меня выйдет не повар, а “дом в человеческом виде”"
    Sonya "Mẹ chỉ mỉm cười - nói rằng tôi sẽ không thành đầu bếp, mà thành “một ngôi nhà trong hình hài con người”"

# game/kitchen.rpy:633
translate english sonya_Idle_evening_kitchen_scene_22f1390f:

    # gg "Звучит будто про тебя"
    gg "Nghe cứ như nói về em vậy"

# game/kitchen.rpy:635
translate english sonya_Idle_evening_kitchen_scene_36c5520f:

    # Sonya "Ну вот, ужин готов"
    Sonya "Vậy đó, bữa tối xong rồi"

# game/kitchen.rpy:636
translate english sonya_Idle_evening_kitchen_scene_03998218:

    # Sonya "Без изысков, но с душой"
    Sonya "Không cầu kỳ, nhưng có tâm"

# game/kitchen.rpy:638
translate english sonya_Idle_evening_kitchen_scene_44b18404:

    # gg "Это вкуснее, чем изысканно"
    gg "Món này còn ngon hơn cả sự cầu kỳ"

# game/kitchen.rpy:639
translate english sonya_Idle_evening_kitchen_scene_16a4231c:

    # Sonya "Вот и хорошо"
    Sonya "Vậy thì tốt"

# game/kitchen.rpy:640
translate english sonya_Idle_evening_kitchen_scene_2c2fc2a4:

    # Sonya "Значит, не зря старалась"
    Sonya "Tức là đã cố gắng không uổng công"

# game/kitchen.rpy:642
translate english sonya_Idle_evening_kitchen_scene_c6bde83f:

    # Sonya "Знаешь, мне нравится кормить людей"
    Sonya "Biết không, tôi thích nấu ăn cho mọi người"

# game/kitchen.rpy:643
translate english sonya_Idle_evening_kitchen_scene_d763faf1:

    # Sonya "Это самое простое, но честное, что я умею делать"
    Sonya "Đó là điều đơn giản nhất, nhưng chân thành nhất mà tôi biết làm"

# game/kitchen.rpy:645
translate english sonya_Idle_evening_kitchen_scene_2b0e2ee7:

    # Sonya "Когда кто - то ест то, что ты приготовил, - он словно доверяет тебе"
    Sonya "Khi ai đó ăn món bạn nấu, - họ dường như đang tin tưởng bạn"

# game/characters_events_idles/sonya_idles.rpy:332
translate english sonya_Idle_day_kitchen_scene_ad913161:

    # gg "Всё ещё ждёшь, пока чайник закипит?"
    gg "Vẫn đang đợi ấm nước sôi à？"

# game/characters_events_idles/sonya_idles.rpy:334
translate english sonya_Idle_day_kitchen_scene_7f0755b3:

    # Sonya "Этот чайник кипит только если чувствует внимание. И настроение"
    Sonya "Cái ấm này chỉ sôi khi cảm thấy được sự chú ý. Và tâm trạng"

# game/characters_events_idles/sonya_idles.rpy:336
translate english sonya_Idle_day_kitchen_scene_f15d06fa:

    # gg "У него характер как у людей здесь"
    gg "Nó có tính cách như con người ở đây vậy"

# game/characters_events_idles/sonya_idles.rpy:337
translate english sonya_Idle_day_kitchen_scene_da15dc83:

    # Sonya "Точно. Кстати чтобы узнать получше людей здесь"
    Sonya "Chính xác. Nhân tiện, để hiểu rõ hơn về con người ở đây"

# game/characters_events_idles/sonya_idles.rpy:340
translate english sonya_Idle_day_kitchen_scene_d5290e36:

    # Sonya "Тут есть пара мест для прогулок"
    Sonya "Ở đây có vài nơi để đi dạo"

# game/characters_events_idles/sonya_idles.rpy:341
translate english sonya_Idle_day_kitchen_scene_9f4c3048:

    # Sonya "Парк — небольшой, но с лавками, где можно застрять на час"
    Sonya "Công viên — nhỏ thôi, nhưng có những chiếc ghế dài mà người ta có thể mắc kẹt cả tiếng đồng hồ"

# game/characters_events_idles/sonya_idles.rpy:343
translate english sonya_Idle_day_kitchen_scene_5b433dab:

    # gg "И всё?"
    gg "Vậy thôi à？"

# game/characters_events_idles/sonya_idles.rpy:345
translate english sonya_Idle_day_kitchen_scene_35184686:

    # Sonya "Ещё озеро. Маленькое, но красивое, особенно вечером"
    Sonya "Còn có hồ nữa. Nhỏ nhưng đẹp, đặc biệt là buổi tối"

# game/characters_events_idles/sonya_idles.rpy:346
translate english sonya_Idle_day_kitchen_scene_f7d54fda:

    # Sonya "Только вода бодрит так, что потом спать не хочется"
    Sonya "Chỉ là nước làm tỉnh táo đến mức sau đó chẳng muốn ngủ"

# game/characters_events_idles/sonya_idles.rpy:348
translate english sonya_Idle_day_kitchen_scene_95b73bc9:

    # Sonya "По субботам базар. Там продают всё — от мёда до слухов"
    Sonya "Thứ Bảy có chợ. Ở đó người ta bán đủ thứ — từ mật ong đến tin đồn"

# game/characters_events_idles/sonya_idles.rpy:349
translate english sonya_Idle_day_kitchen_scene_957c11d8:

    # gg "А многоэтажка — это правда?"
    gg "Còn tòa nhà nhiều tầng — là thật à？"

# game/characters_events_idles/sonya_idles.rpy:351
translate english sonya_Idle_day_kitchen_scene_13cd2649:

    # Sonya "Правда. Наш “город в одном доме”"
    Sonya "Thật. “Thành phố trong một ngôi nhà” của chúng tôi"

# game/characters_events_idles/sonya_idles.rpy:352
translate english sonya_Idle_day_kitchen_scene_c3a65cd2:

    # Sonya "Там почта, офис и девушка, которая считает себя айтишником"
    Sonya "Ở đó có bưu điện, văn phòng và một cô gái tự nhận mình là dân IT"

# game/characters_events_idles/sonya_idles.rpy:354
translate english sonya_Idle_day_kitchen_scene_ed9dc13a:

    # Sonya "Вот и всё веселье. Но если смотреть внимательно — здесь больше жизни, чем кажется"
    Sonya "Vui vẻ chỉ có vậy. Nhưng nếu nhìn kỹ — ở đây có nhiều sức sống hơn vẻ ngoài"

# game/myroom.rpy:332
translate english sonya_Idle_morning_myroom_scene_3520e1f4:

    # Sonya "Ой . . . не разбудила?"
    Sonya "Ôi . . . không đánh thức anh đấy chứ？"

# game/myroom.rpy:333
translate english sonya_Idle_morning_myroom_scene_672ee57f:

    # gg "Нет, просто не привык, что по утрам кто-то сражается с пылью"
    gg "Không, chỉ là không quen việc buổi sáng có người chiến đấu với bụi bẩn"

# game/myroom.rpy:335
translate english sonya_Idle_morning_myroom_scene_7bcfcbe4:

    # Sonya "У каждого своё утро"
    Sonya "Mỗi người có buổi sáng của riêng mình"

# game/myroom.rpy:336
translate english sonya_Idle_morning_myroom_scene_125e44ff:

    # Sonya "Моё - с уборки"
    Sonya "Của tôi - bắt đầu bằng dọn dẹp"

# game/myroom.rpy:338
translate english sonya_Idle_morning_myroom_scene_00768c69:

    # gg "Не думал, что ты одна из тех, кто так любит уборку"
    gg "Không nghĩ em là một trong những người thích dọn dẹp đến vậy"

# game/myroom.rpy:340
translate english sonya_Idle_morning_myroom_scene_05d695dc:

    # Sonya "Не люблю. {w}Просто, если не я, никто не сделает"
    Sonya "Tôi không thích. {w}Chỉ là, nếu không phải tôi, thì chẳng ai làm"

# game/myroom.rpy:341
translate english sonya_Idle_morning_myroom_scene_8b5d8733:

    # Sonya "Когда я сюда приехала, дом был знаешь . . . {w}какой-то пустой"
    Sonya "Khi tôi đến đây, ngôi nhà, anh biết đấy . . . {w}kiểu trống trải"

# game/myroom.rpy:342
translate english sonya_Idle_morning_myroom_scene_6e4588f3:

    # Sonya "Линда тогда часто уезжала, а Мая только въехала"
    Sonya "Hồi đó Linda thường xuyên đi vắng, còn Maya mới chuyển vào"

# game/myroom.rpy:343
translate english sonya_Idle_morning_myroom_scene_b07f6cab:

    # Sonya "Всё было вверх дном"
    Sonya "Mọi thứ đều lộn xộn"

# game/myroom.rpy:344
translate english sonya_Idle_morning_myroom_scene_c3dd8e50:

    # Sonya "Я осталась - просто чтобы стало немного тише"
    Sonya "Tôi ở lại - chỉ để mọi thứ trở nên yên tĩnh hơn một chút"

# game/myroom.rpy:345
translate english sonya_Idle_morning_myroom_scene_58c3d544:

    # gg "И осталась до сих пор?"
    gg "Và ở lại cho đến tận bây giờ？"

# game/myroom.rpy:347
translate english sonya_Idle_morning_myroom_scene_1e7a7a2e:

    # Sonya "Ага. Потом привыкла"
    Sonya "Ừ. Sau đó thì quen"

# game/myroom.rpy:348
translate english sonya_Idle_morning_myroom_scene_ce824a84:

    # Sonya "Линда как-то сказала, что дом любит, когда в нём кто-то есть"
    Sonya "Linda có lần nói rằng ngôi nhà thích khi có ai đó ở trong"

# game/myroom.rpy:350
translate english sonya_Idle_morning_myroom_scene_80a846d0:

    # Sonya "Может, я просто не смогла уехать"
    Sonya "Có lẽ tôi chỉ không thể rời đi"

# game/myroom.rpy:352
translate english sonya_Idle_morning_myroom_scene_db2e4457:

    # gg "А Мая? Вы ведь такие разные"
    gg "Còn Maya？ Hai người khác nhau đến vậy mà"

# game/myroom.rpy:354
translate english sonya_Idle_morning_myroom_scene_55479aec:

    # Sonya "Очень"
    Sonya "Rất khác"

# game/myroom.rpy:356
translate english sonya_Idle_morning_myroom_scene_e017f5bc:

    # Sonya "Я - про порядок, она - про хаос. Но в этом и суть"
    Sonya "Tôi - thiên về trật tự, cô ấy - về hỗn loạn. Nhưng mấu chốt là ở đó"

# game/myroom.rpy:359
translate english sonya_Idle_morning_myroom_scene_ef1d94c6:

    # Sonya "Знаешь, иногда кажется, что мы друг друга уравновешиваем"
    Sonya "Biết không, đôi khi tôi cảm thấy chúng tôi cân bằng lẫn nhau"

# game/myroom.rpy:360
translate english sonya_Idle_morning_myroom_scene_77666d07:

    # Sonya "Я заставляю её остановиться, а она - меня жить чуть громче"
    Sonya "Tôi khiến cô ấy dừng lại, còn cô ấy khiến tôi sống ồn ào hơn một chút"

# game/myroom.rpy:361
translate english sonya_Idle_morning_myroom_scene_686dcb6d:

    # gg "Похоже, вы нашли баланс"
    gg "Có vẻ hai người đã tìm được sự cân bằng"

# game/myroom.rpy:363
translate english sonya_Idle_morning_myroom_scene_8d1d6292:

    # Sonya "Баланс - вещь хрупкая"
    Sonya "Cân bằng - là thứ mong manh"

# game/myroom.rpy:365
translate english sonya_Idle_morning_myroom_scene_6e252d73:

    # Sonya "Но, кажется, с тобой он только крепче стал"
    Sonya "Nhưng có vẻ với anh nó còn trở nên vững chắc hơn"

# game/myroom.rpy:367
translate english sonya_Idle_morning_myroom_scene_2e6e7590:

    # Sonya "В смысле . . . просто в доме стало уютнее"
    Sonya "Ý tôi là . . . chỉ là trong nhà trở nên ấm cúng hơn"

# game/myroom.rpy:369
translate english sonya_Idle_morning_myroom_scene_6bf72907:

    # Sonya "Вот и всё"
    Sonya "Chỉ vậy thôi"

# game/myroom.rpy:370
translate english sonya_Idle_morning_myroom_scene_98ba9030:

    # gg "Конечно. Только уют"
    gg "Tất nhiên. Chỉ là ấm cúng"

# game/myroom.rpy:371
translate english sonya_Idle_morning_myroom_scene_af3920fa:

    # Sonya "Вот именно. Только уют"
    Sonya "Đúng thế. Chỉ là ấm cúng"

# game/characters_events_idles/sonya_idles.rpy:422
translate english sonya_Idle_day_myroom_scene_de06330f:

    # gg "Привет за цветами ухаживаешь?"
    gg "Chào, em đang chăm hoa à？"

# game/characters_events_idles/sonya_idles.rpy:424
translate english sonya_Idle_day_myroom_scene_c76f7e91:

    # Sonya "Знаешь, за цветами нужно постоянно следить"
    Sonya "Biết không, hoa cần được theo dõi thường xuyên"

# game/characters_events_idles/sonya_idles.rpy:426
translate english sonya_Idle_day_myroom_scene_95b1f24a:

    # Sonya "Не слишком много воды, не слишком мало. . . иначе начинают вянуть"
    Sonya "Không quá nhiều nước, không quá ít. . . nếu không chúng bắt đầu héo"

# game/characters_events_idles/sonya_idles.rpy:427
translate english sonya_Idle_day_myroom_scene_ae18780a:

    # gg "Значит, всё дело в балансе"
    gg "Vậy là mấu chốt nằm ở sự cân bằng"

# game/characters_events_idles/sonya_idles.rpy:429
translate english sonya_Idle_day_myroom_scene_0e80b509:

    # Sonya "Внимание и время - вот что им действительно нужно"
    Sonya "Sự chú ý và thời gian - đó là điều chúng thực sự cần"

# game/characters_events_idles/sonya_idles.rpy:430
translate english sonya_Idle_day_myroom_scene_37400bc6:

    # Sonya "Не полил день - и всё, сразу обижаются"
    Sonya "Không tưới một ngày - là xong, chúng giận ngay"

# game/characters_events_idles/sonya_idles.rpy:432
translate english sonya_Idle_day_myroom_scene_b6abea2a:

    # Sonya "У каждого из них свой характер"
    Sonya "Mỗi cây đều có tính cách riêng"

# game/characters_events_idles/sonya_idles.rpy:434
translate english sonya_Idle_day_myroom_scene_2c042e81:

    # Sonya "Один тянется к свету, другой прячется в тень"
    Sonya "Cây này vươn về phía ánh sáng, cây khác lại trốn vào bóng râm"

# game/characters_events_idles/sonya_idles.rpy:435
translate english sonya_Idle_day_myroom_scene_bffbba77:

    # Sonya "Есть те, кто растёт быстро, а есть, кому нужно просто больше терпения"
    Sonya "Có những cây lớn nhanh, và có những cây chỉ cần thêm kiên nhẫn"

# game/characters_events_idles/sonya_idles.rpy:436
translate english sonya_Idle_day_myroom_scene_97f84296:

    # gg "Звучит как целая наука"
    gg "Nghe như cả một môn khoa học"

# game/characters_events_idles/sonya_idles.rpy:438
translate english sonya_Idle_day_myroom_scene_bc327c51:

    # Sonya "Может, и так. Только всё приходится чувствовать"
    Sonya "Có thể vậy. Chỉ là mọi thứ đều phải cảm nhận"

# game/characters_events_idles/sonya_idles.rpy:440
translate english sonya_Idle_day_myroom_scene_16d43fdb:

    # Sonya "Иногда они долго не цветут, и кажется, что всё зря"
    Sonya "Đôi khi chúng lâu không nở hoa, và tưởng như mọi thứ đều vô ích"

# game/characters_events_idles/sonya_idles.rpy:441
translate english sonya_Idle_day_myroom_scene_df3dcafe:

    # Sonya "А потом вдруг - один день, и раскрывается бутон"
    Sonya "Rồi đột nhiên - một ngày, và nụ hoa bung nở"

# game/characters_events_idles/sonya_idles.rpy:443
translate english sonya_Idle_day_myroom_scene_3ee4994e:

    # Sonya "Линда всегда говорила, что цветы живут там, где им хорошо"
    Sonya "Linda luôn nói rằng hoa sống ở nơi chúng thấy tốt"

# game/characters_events_idles/sonya_idles.rpy:444
translate english sonya_Idle_day_myroom_scene_bfd85b59:

    # Sonya "Не потому что солнце ярче, а потому что рядом кто-то заботится"
    Sonya "Không phải vì mặt trời sáng hơn, mà vì có ai đó ở bên chăm sóc"

# game/characters_events_idles/sonya_idles.rpy:445
translate english sonya_Idle_day_myroom_scene_d2c9efc2:

    # gg "Наверное, это правда"
    gg "Chắc đó là sự thật"

# game/characters_events_idles/sonya_idles.rpy:447
translate english sonya_Idle_day_myroom_scene_21a29e18:

    # Sonya "Думаю, да"
    Sonya "Tôi nghĩ là vậy"

# game/characters_events_idles/sonya_idles.rpy:448
translate english sonya_Idle_day_myroom_scene_ea189aa5:

    # Sonya "Просто не все замечают, как это важно"
    Sonya "Chỉ là không phải ai cũng nhận ra điều đó quan trọng đến mức nào"

# game/characters_events_idles/sonya_idles.rpy:449
translate english sonya_Idle_day_myroom_scene_98f80f6a:

    # Sonya "Иногда достаточно совсем немного - тепла, слова, присутствия"
    Sonya "Đôi khi chỉ cần rất ít - hơi ấm, một lời nói, sự hiện diện"

# game/characters_events_idles/sonya_idles.rpy:451
translate english sonya_Idle_day_myroom_scene_c2d87ad5:

    # Sonya "Главное - не перекормить заботой"
    Sonya "Điều chính là - đừng cho quá nhiều sự quan tâm"

# game/myroom.rpy:578
translate english sonya_Idle_evening_myroom_scene_21cb43a6:

    # Sonya "Так, у нас есть романтика, комедия, и . . . хоррор"
    Sonya "Vậy, chúng ta có phim lãng mạn, hài, và . . . kinh dị"

# game/myroom.rpy:580
translate english sonya_Idle_evening_myroom_scene_fd380690:

    # gg "Хоррор? Ты же потом не заснёшь"
    gg "Kinh dị？ Lát nữa em sẽ không ngủ được đâu"

# game/myroom.rpy:582
translate english sonya_Idle_evening_myroom_scene_f65cd8c3:

    # Sonya "Ну тогда разбужу тебя и будем болтать до утра . . ."
    Sonya "Vậy thì tôi sẽ đánh thức anh dậy và chúng ta sẽ trò chuyện đến sáng . . ."

# game/myroom.rpy:583
translate english sonya_Idle_evening_myroom_scene_0f687ebc:

    # Sonya "Вместе страдать от бессонницы"
    Sonya "Cùng nhau chịu đựng chứng mất ngủ"

# game/myroom.rpy:584
translate english sonya_Idle_evening_myroom_scene_4fc2999c:

    # gg "Ну если ты вдруг случайно начнёшь засыпать - я тебе не дам"
    gg "Nếu em đột nhiên buồn ngủ - tôi sẽ không để em ngủ đâu"

# game/myroom.rpy:586
translate english sonya_Idle_evening_myroom_scene_d472f3eb:

    # Sonya "Просто люблю, когда немного страшно"
    Sonya "Chỉ là tôi thích khi hơi đáng sợ"

# game/myroom.rpy:587
translate english sonya_Idle_evening_myroom_scene_53e63a45:

    # Sonya "В таких фильмах хоть что-то происходит по-настоящему"
    Sonya "Trong những bộ phim như vậy, ít nhất có điều gì đó thực sự xảy ra"

# game/myroom.rpy:589
translate english sonya_Idle_evening_myroom_scene_80cdfb7b:

    # gg "А ты не боишься?"
    gg "Em không sợ à？"

# game/myroom.rpy:591
translate english sonya_Idle_evening_myroom_scene_562977d2:

    # Sonya "Боюсь. {w}Но мне нравится, когда страшно только снаружи, а внутри спокойно"
    Sonya "Có sợ. {w}Nhưng tôi thích khi chỉ bên ngoài đáng sợ, còn bên trong thì bình yên"

# game/myroom.rpy:593
translate english sonya_Idle_evening_myroom_scene_ca77da12:

    # Sonya "Хотя, если вдруг будет слишком жутко - я, может, чуть-чуть прижмусь. Для науки"
    Sonya "Dù sao, nếu tự nhiên quá đáng sợ - có lẽ tôi sẽ nép vào một chút. Vì khoa học"

# game/myroom.rpy:594
translate english sonya_Idle_evening_myroom_scene_c7a5bb2e:

    # gg "Чисто научный эксперимент?"
    gg "Một thí nghiệm thuần khoa học？"

# game/myroom.rpy:595
translate english sonya_Idle_evening_myroom_scene_96d1eac0:

    # Sonya "Конечно. Проверим, снижается ли уровень паники при тесном контакте"
    Sonya "Tất nhiên. Chúng ta sẽ kiểm tra xem mức độ hoảng loạn có giảm khi tiếp xúc gần không"

# game/myroom.rpy:599
translate english sonya_Idle_evening_myroom_scene_0a9cd91f:

    # Sonya "Вот видишь, уже началось"
    Sonya "Thấy chưa, đã bắt đầu rồi"

# game/myroom.rpy:600
translate english sonya_Idle_evening_myroom_scene_4b16a16b:

    # gg "И как результаты эксперимента?"
    gg "Kết quả thí nghiệm thế nào？"

# game/myroom.rpy:602
translate english sonya_Idle_evening_myroom_scene_1d60fbd7:

    # Sonya "Пока эффект положительный"
    Sonya "Hiện tại hiệu ứng là tích cực"

# game/myroom.rpy:603
translate english sonya_Idle_evening_myroom_scene_c404867c:

    # Sonya "Но для точности нужно дождаться кульминации"
    Sonya "Nhưng để chính xác thì cần đợi đến cao trào"

# game/myroom.rpy:604
translate english sonya_Idle_evening_myroom_scene_24bf4b87:

    # Sonya "В такие вечера даже страх кажется уютным"
    Sonya "Trong những buổi tối như vậy, ngay cả nỗi sợ cũng trở nên ấm áp"

# game/myroom.rpy:605
translate english sonya_Idle_evening_myroom_scene_741f04d1:

    # gg "Только если есть кому его разделить"
    gg "Chỉ khi có ai đó để chia sẻ nó"

# game/myroom.rpy:606
translate english sonya_Idle_evening_myroom_scene_cf08afaa:

    # Sonya "Думаю, у нас с этим всё в порядке"
    Sonya "Tôi nghĩ chúng ta ổn với chuyện đó"

translate english strings:

    # game/characters_events_idles/sonya_idles.rpy:5
    old "Доброе утро"
    new "Chào buổi sáng"

    # game/characters_events_idles/sonya_idles.rpy:48
    old "Потрясающе выглядишь"
    new "Trông tuyệt lắm"

    # game/characters_events_idles/sonya_idles.rpy:74
    old "Мне пора"
    new "Tôi phải đi rồi"

    # game/characters_events_idles/sonya_idles.rpy:138
    old "Привет"
    new "Chào"

    # game/characters_events_idles/sonya_idles.rpy:192
    old "Не мешать"
    new "Đừng làm phiền"

    # game/characters_events_idles/sonya_idles.rpy:201
    old "Присесть рядом"
    new "Ngồi xuống bên cạnh"

    # game/characters_events_idles/sonya_idles.rpy:237
    old "Не тревожить"
    new "Đừng quấy rầy"

    # game/characters_events_idles/sonya_idles.rpy:249
    old "С добрым утром"
    new "Chào buổi sáng tốt lành"

    # game/characters_events_idles/sonya_idles.rpy:274
    old "Позже загляну"
    new "Lát nữa ghé qua"

    # game/characters_events_idles/sonya_idles.rpy:283
    old "Вкусно пахнет"
    new "Mùi thơm quá"

    # game/characters_events_idles/sonya_idles.rpy:330
    old "Ждешь чайник?"
    new "Đang đợi ấm nước à？"

    # game/characters_events_idles/sonya_idles.rpy:367
    old "Опять с тряпкой?"
    new "Lại cầm giẻ à？"

    # game/characters_events_idles/sonya_idles.rpy:464
    old "Что смотрим?"
    new "Chúng ta xem gì？"

