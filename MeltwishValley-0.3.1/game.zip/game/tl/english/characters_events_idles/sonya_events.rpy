﻿# game/characters_events_idles/sonya_events.rpy:6
translate english sonya_scene1_morning_kitchen_a756dbc0:

    # gg "Утречко"
    gg "Chào buổi sáng"

# game/characters_events_idles/sonya_events.rpy:12
translate english sonya_scene1_morning_kitchen_2641e2c9:

    # Sonya "Доброе утро"
    Sonya "Chào buổi sáng"

# game/characters_events_idles/sonya_events.rpy:14
translate english sonya_scene1_morning_kitchen_50dcebad:

    # Sonya "Как тебе спалось?"
    Sonya "Anh ngủ ngon không？"

# game/characters_events_idles/sonya_events.rpy:16
translate english sonya_scene1_morning_kitchen_9fdea20a:

    # gg "Нормально"
    gg "Bình thường"

# game/characters_events_idles/sonya_events.rpy:18
translate english sonya_scene1_morning_kitchen_c923e04f:

    # gg "Тихо"
    gg "Yên tĩnh"

# game/characters_events_idles/sonya_events.rpy:20
translate english sonya_scene1_morning_kitchen_367f1af9:

    # Sonya "Там диван конечно старый"
    Sonya "Cái ghế sofa đó dĩ nhiên là cũ rồi"

# game/characters_events_idles/sonya_events.rpy:22
translate english sonya_scene1_morning_kitchen_0a0eba96:

    # Sonya "Но удобный"
    Sonya "Nhưng mà thoải mái"

# game/characters_events_idles/sonya_events.rpy:24
translate english sonya_scene1_morning_kitchen_0f37c26d:

    # gg "Я заметил"
    gg "Anh để ý rồi"

# game/characters_events_idles/sonya_events.rpy:26
translate english sonya_scene1_morning_kitchen_93b6fb71:

    # Sonya "Ты уже успел пройтись по деревне?"
    Sonya "Anh đã kịp đi dạo quanh làng chưa？"

# game/characters_events_idles/sonya_events.rpy:28
translate english sonya_scene1_morning_kitchen_0839a090:

    # Sonya "Или пока только дом вспоминаешь?"
    Sonya "Hay vẫn chỉ đang nhớ lại ngôi nhà thôi？"

# game/characters_events_idles/sonya_events.rpy:30
translate english sonya_scene1_morning_kitchen_12aa0f18:

    # gg "Немного посмотрел"
    gg "Anh xem một chút rồi"

# game/characters_events_idles/sonya_events.rpy:32
translate english sonya_scene1_morning_kitchen_c33e58bc:

    # gg "Тут . . . Хорошие люди"
    gg "Ở đây . . . Những người tốt"

# game/characters_events_idles/sonya_events.rpy:34
translate english sonya_scene1_morning_kitchen_c8772e87:

    # Sonya "Да"
    Sonya "Ừ"

# game/characters_events_idles/sonya_events.rpy:36
translate english sonya_scene1_morning_kitchen_ed137d91:

    # Sonya "Ты к этому быстро привыкаешь"
    Sonya "Anh sẽ nhanh quen với điều đó thôi"

# game/characters_events_idles/sonya_events.rpy:48
translate english sonya_scene1_morning_kitchen_e45ac0f2:

    # Sonya "Если вдруг проголодаешься — бери что хочешь"
    Sonya "Nếu bỗng thấy đói — cứ lấy thứ anh muốn"

# game/characters_events_idles/sonya_events.rpy:50
translate english sonya_scene1_morning_kitchen_947178ba:

    # Sonya "У нас обычно никто особо не спрашивает"
    Sonya "Ở chỗ bọn em thường chẳng ai hỏi nhiều"

# game/characters_events_idles/sonya_events.rpy:56
translate english sonya_scene1_morning_kitchen_04c6c53d:

    # gg "Спасибо"
    gg "Cảm ơn"

# game/characters_events_idles/sonya_events.rpy:60
translate english sonya_scene1_morning_kitchen_77469d65:

    # Sonya "А вообще"
    Sonya "Mà nói chung"

# game/characters_events_idles/sonya_events.rpy:62
translate english sonya_scene1_morning_kitchen_ebb5bb0f:

    # Sonya "Как тебе здесь?"
    Sonya "Anh thấy ở đây thế nào？"

# game/characters_events_idles/sonya_events.rpy:66
translate english sonya_scene1_morning_kitchen_77102205:

    # Sonya "В смысле . . . жить вместе"
    Sonya "Ý là . . . sống cùng nhau"

# game/characters_events_idles/sonya_events.rpy:70
translate english sonya_scene1_morning_kitchen_dcf6ae5e:

    # gg "Непривычно"
    gg "Lạ"

# game/characters_events_idles/sonya_events.rpy:72
translate english sonya_scene1_morning_kitchen_0dd94278:

    # gg "Но нормально"
    gg "Nhưng mà ổn"

# game/characters_events_idles/sonya_events.rpy:74
translate english sonya_scene1_morning_kitchen_c8772e87_1:

    # Sonya "Да"
    Sonya "Ừ"

# game/characters_events_idles/sonya_events.rpy:76
translate english sonya_scene1_morning_kitchen_8aa7b1fd:

    # Sonya "Мы тоже не сразу привыкли"
    Sonya "Bọn em cũng không quen ngay được"

# game/characters_events_idles/sonya_events.rpy:78
translate english sonya_scene1_morning_kitchen_270848f3:

    # Sonya "Когда людей в доме становится больше"
    Sonya "Khi trong nhà có nhiều người hơn"

# game/characters_events_idles/sonya_events.rpy:80
translate english sonya_scene1_morning_kitchen_816d8504:

    # Sonya "Всё немного меняется"
    Sonya "Mọi thứ thay đổi một chút"

# game/characters_events_idles/sonya_events.rpy:99
translate english sonya_scene1_morning_kitchen_7b099c93:

    # gg_chat "Мае — завтрак"
    gg_chat "Maya — bữa sáng"

# game/characters_events_idles/sonya_events.rpy:100
translate english sonya_scene1_morning_kitchen_fcffc8ef:

    # gg_chat "Если не успею — купи, пожалуйста, продукты"
    gg_chat "Nếu tôi không kịp — làm ơn mua đồ ăn nhé"

# game/characters_events_idles/sonya_events.rpy:109
translate english sonya_scene1_morning_kitchen_7158ba01:

    # gg "Ладно, я пойду"
    gg "Được rồi, anh đi đây"

# game/characters_events_idles/sonya_events.rpy:111
translate english sonya_scene1_morning_kitchen_fbb535a1:

    # gg "Не буду мешать"
    gg "Không làm phiền nữa"

# game/characters_events_idles/sonya_events.rpy:113
translate english sonya_scene1_morning_kitchen_98963b02:

    # Sonya "Да ты и не мешаешь"
    Sonya "Có mà anh đâu có làm phiền"

# game/characters_events_idles/sonya_events.rpy:117
translate english sonya_scene1_morning_kitchen_d24f6aaf:

    # Sonya "Но . . . хорошо"
    Sonya "Nhưng . . . được thôi"

# game/characters_events_idles/sonya_events.rpy:133
translate english sonya_scene2_day_girlroom_68c12557:

    # gg "Сонь"
    gg "Sonya à"

# game/characters_events_idles/sonya_events.rpy:137
translate english sonya_scene2_day_girlroom_d3ca52ed:

    # gg "Ты не знаешь, где у вас аптечка?"
    gg "Em có biết hộp sơ cứu ở đâu không？"

# game/characters_events_idles/sonya_events.rpy:139
translate english sonya_scene2_day_girlroom_fb949c9e:

    # Sonya "Аптечка?"
    Sonya "Hộp sơ cứu？"

# game/characters_events_idles/sonya_events.rpy:141
translate english sonya_scene2_day_girlroom_695184c3:

    # Sonya "А что случилось?"
    Sonya "Có chuyện gì thế？"

# game/characters_events_idles/sonya_events.rpy:143
translate english sonya_scene2_day_girlroom_55820831:

    # gg "Да так"
    gg "À không có gì"

# game/characters_events_idles/sonya_events.rpy:145
translate english sonya_scene2_day_girlroom_41aa37fb:

    # gg "Поцарапался.{w} Ерунда"
    gg "Bị xước thôi.{w} Chuyện nhỏ"

# game/characters_events_idles/sonya_events.rpy:149
translate english sonya_scene2_day_girlroom_06e5075f:

    # Sonya "Подожди"
    Sonya "Đợi đã"

# game/characters_events_idles/sonya_events.rpy:151
translate english sonya_scene2_day_girlroom_b43c4c5e:

    # Sonya "Сейчас все сделаем"
    Sonya "Để em xử lý ngay"

# game/characters_events_idles/sonya_events.rpy:155
translate english sonya_scene2_day_girlroom_7cc8260f:

    # Sonya "А ты почти без вещей приехал"
    Sonya "Mà anh đến gần như chẳng mang theo đồ đạc gì"

# game/characters_events_idles/sonya_events.rpy:157
translate english sonya_scene2_day_girlroom_b1f32e8a:

    # Sonya "Так и планировал"
    Sonya "Định vậy từ đầu à"

# game/characters_events_idles/sonya_events.rpy:158
translate english sonya_scene2_day_girlroom_06e860df:

    # Sonya "Или просто не успел собрать?"
    Sonya "Hay chỉ là không kịp thu dọn？"

# game/characters_events_idles/sonya_events.rpy:164
translate english sonya_scene2_day_girlroom_cc881b3b:

    # gg "Скорее второе"
    gg "Có lẽ là vế sau"

# game/characters_events_idles/sonya_events.rpy:166
translate english sonya_scene2_day_girlroom_72e0315a:

    # gg "Решил не тащить за собой старое"
    gg "Anh quyết định không mang theo quá khứ"

# game/characters_events_idles/sonya_events.rpy:169
translate english sonya_scene2_day_girlroom_fef188e6:

    # gg "Посмотреть, как будет"
    gg "Để xem nó sẽ thế nào"

# game/characters_events_idles/sonya_events.rpy:171
translate english sonya_scene2_day_girlroom_4b248478:

    # Sonya "Будто новая жизнь"
    Sonya "Cứ như một cuộc đời mới"

# game/characters_events_idles/sonya_events.rpy:173
translate english sonya_scene2_day_girlroom_84c6a1f8:

    # Sonya "Ты получается больше утренний человек?"
    Sonya "Vậy ra anh là người thuộc về buổi sáng hơn？"

# game/characters_events_idles/sonya_events.rpy:175
translate english sonya_scene2_day_girlroom_e550b517:

    # Sonya "Или нет?"
    Sonya "Hay không phải？"

# game/characters_events_idles/sonya_events.rpy:177
translate english sonya_scene2_day_girlroom_254f159a:

    # gg "Раньше — скорее вечерний"
    gg "Trước đây — thiên về buổi tối hơn"

# game/characters_events_idles/sonya_events.rpy:179
translate english sonya_scene2_day_girlroom_bf5f3aef:

    # gg "А здесь почему-то весь день на ногах"
    gg "Mà ở đây không hiểu sao cả ngày cứ hoạt động không ngừng"

# game/characters_events_idles/sonya_events.rpy:181
translate english sonya_scene2_day_girlroom_633d56a5:

    # gg "Сам удивляюсь"
    gg "Chính anh cũng ngạc nhiên"

# game/characters_events_idles/sonya_events.rpy:183
translate english sonya_scene2_day_girlroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "Thật à？"

# game/characters_events_idles/sonya_events.rpy:185
translate english sonya_scene2_day_girlroom_7e52f22d:

    # Sonya "Значит, деревня на тебя хорошо действует"
    Sonya "Vậy là ngôi làng có tác động tốt đến anh"

# game/characters_events_idles/sonya_events.rpy:187
translate english sonya_scene2_day_girlroom_d0a33041:

    # Sonya "И часто ты так . . ."
    Sonya "Anh thường xuyên như vậy . . ."

# game/characters_events_idles/sonya_events.rpy:189
translate english sonya_scene2_day_girlroom_25b95c9d:

    # Sonya "Царапаешься?"
    Sonya "Bị xước à？"

# game/characters_events_idles/sonya_events.rpy:191
translate english sonya_scene2_day_girlroom_8f76c3f1:

    # gg "Не особо"
    gg "Không hẳn"

# game/characters_events_idles/sonya_events.rpy:193
translate english sonya_scene2_day_girlroom_2171a9af:

    # gg "Просто ещё не привык к местной фауне"
    gg "Chỉ là chưa quen với hệ động vật ở đây"

# game/characters_events_idles/sonya_events.rpy:195
translate english sonya_scene2_day_girlroom_09b9d111:

    # Sonya "А . . ."
    Sonya "À . . ."

# game/characters_events_idles/sonya_events.rpy:196
translate english sonya_scene2_day_girlroom_521ff667:

    # Sonya "Тогда понятно"
    Sonya "Vậy thì hiểu rồi"

# game/characters_events_idles/sonya_events.rpy:203
translate english sonya_scene2_day_girlroom_6b068d33:

    # gg "Ты так аккуратно всё делаешь . . ."
    gg "Em làm mọi thứ cẩn thận thật . . ."

# game/characters_events_idles/sonya_events.rpy:205
translate english sonya_scene2_day_girlroom_bbcf86fd:

    # gg "Это привычка?"
    gg "Đó là thói quen à？"

# game/characters_events_idles/sonya_events.rpy:207
translate english sonya_scene2_day_girlroom_a174002e:

    # Sonya "Ага"
    Sonya "Ừ"

# game/characters_events_idles/sonya_events.rpy:208
translate english sonya_scene2_day_girlroom_5e6a7fb2:

    # Sonya "Мне так спокойнее"
    Sonya "Như vậy em thấy yên tâm hơn"

# game/characters_events_idles/sonya_events.rpy:210
translate english sonya_scene2_day_girlroom_ea7be3c1:

    # Sonya "Когда всё сделано как надо"
    Sonya "Khi mọi thứ được làm đúng cách"

# game/characters_events_idles/sonya_events.rpy:212
translate english sonya_scene2_day_girlroom_d9f6fc3a:

    # Sonya "Готово"
    Sonya "Xong rồi"

# game/characters_events_idles/sonya_events.rpy:216
translate english sonya_scene2_day_girlroom_04c6c53d:

    # gg "Спасибо"
    gg "Cảm ơn"

# game/characters_events_idles/sonya_events.rpy:218
translate english sonya_scene2_day_girlroom_1c0e0b38:

    # Sonya "А у тебя . . ."
    Sonya "Còn anh . . ."

# game/characters_events_idles/sonya_events.rpy:220
translate english sonya_scene2_day_girlroom_041495e8:

    # Sonya "Там, в городе . . ."
    Sonya "Ở đó, trong thành phố . . ."

# game/characters_events_idles/sonya_events.rpy:222
translate english sonya_scene2_day_girlroom_ec4c11a0:

    # Sonya "Кто-нибудь остался?"
    Sonya "Có ai còn lại không？"

# game/characters_events_idles/sonya_events.rpy:224
translate english sonya_scene2_day_girlroom_d26255df:

    # gg "Был один человек"
    gg "Từng có một người"

# game/characters_events_idles/sonya_events.rpy:226
translate english sonya_scene2_day_girlroom_5319b6ee:

    # gg "Мы давно разошлись"
    gg "Bọn anh chia tay lâu rồi"

# game/characters_events_idles/sonya_events.rpy:228
translate english sonya_scene2_day_girlroom_48254a12:

    # gg "Сейчас . . .{w} скорее нет, чем да"
    gg "Bây giờ . . .{w} có lẽ là không hơn là có"

# game/characters_events_idles/sonya_events.rpy:230
translate english sonya_scene2_day_girlroom_93bf8783:

    # Sonya "Понятно"
    Sonya "Hiểu rồi"

# game/characters_events_idles/sonya_events.rpy:232
translate english sonya_scene2_day_girlroom_bfbf3b82:

    # Sonya "Я просто спросила"
    Sonya "Em chỉ hỏi thôi"

# game/characters_events_idles/sonya_events.rpy:238
translate english sonya_scene2_day_girlroom_bde02200:

    # Sonya "Тогда я наверно . . ."
    Sonya "Vậy chắc em . . ."

# game/characters_events_idles/sonya_events.rpy:240
translate english sonya_scene2_day_girlroom_230ea232:

    # Sonya "Буду дальше убираться, пыль быстро собирается"
    Sonya "Sẽ tiếp tục dọn dẹp, bụi bám nhanh lắm"

# game/characters_events_idles/sonya_events.rpy:243
translate english sonya_scene2_day_girlroom_944c14eb:

    # gg "Спасибо еще раз"
    gg "Cảm ơn em lần nữa"

# game/characters_events_idles/sonya_events.rpy:245
translate english sonya_scene2_day_girlroom_3735a72e:

    # Sonya "Угу"
    Sonya "Ừm"

# game/characters_events_idles/sonya_events.rpy:247
translate english sonya_scene2_day_girlroom_ccc766ff:

    # Sonya "Если что аптечка всегда здесь"
    Sonya "Nếu cần thì hộp sơ cứu luôn ở đây"

# game/characters_events_idles/sonya_events.rpy:273
translate english sonya_scene3_day_bathroom_03e250ee:

    # gg "Эмм Соня, я тут"
    gg "Ờm Sonya, anh ở đây"

# game/characters_events_idles/sonya_events.rpy:281
translate english sonya_scene3_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "Ôi"

# game/characters_events_idles/sonya_events.rpy:294
translate english sonya_scene3_day_bathroom_b3aa243a:

    # Sonya "Прости"
    Sonya "Xin lỗi"

# game/characters_events_idles/sonya_events.rpy:296
translate english sonya_scene3_day_bathroom_ea2e53f8:

    # Sonya "Я думала, ванная свободна"
    Sonya "Em tưởng phòng tắm trống"

# game/characters_events_idles/sonya_events.rpy:298
translate english sonya_scene3_day_bathroom_7f3525bd:

    # Sonya "Это моя ошибка"
    Sonya "Đó là lỗi của em"

# game/characters_events_idles/sonya_events.rpy:300
translate english sonya_scene3_day_bathroom_b8f5eb09:

    # gg "Всё нормально"
    gg "Không sao"

# game/characters_events_idles/sonya_events.rpy:302
translate english sonya_scene3_day_bathroom_623f3607:

    # gg "Ничего страшного"
    gg "Không có gì nghiêm trọng"

# game/characters_events_idles/sonya_events.rpy:304
translate english sonya_scene3_day_bathroom_7fce0f16:

    # Sonya "{size=*1.3}Нет"
    Sonya "{size=*1.3}Không"

# game/characters_events_idles/sonya_events.rpy:306
translate english sonya_scene3_day_bathroom_c2e17951:

    # Sonya "Я просто сделаю вид"
    Sonya "Em sẽ giả vờ"

# game/characters_events_idles/sonya_events.rpy:308
translate english sonya_scene3_day_bathroom_1a86b367:

    # Sonya "Что этого не было"
    Sonya "Rằng chuyện đó chưa xảy ra"

# game/characters_events_idles/sonya_events.rpy:325
translate english sonya_scene3_day_bathroom_475b14a6:

    # Sonya "Я оставила тебе чай на кухне"
    Sonya "Em để trà cho anh ở bếp"

# game/characters_events_idles/sonya_events.rpy:327
translate english sonya_scene3_day_bathroom_c0c28f24:

    # Sonya "Горячий аккуратнее"
    Sonya "Nóng đấy, cẩn thận"

# game/characters_events_idles/sonya_events.rpy:330
translate english sonya_scene3_day_bathroom_04c6c53d:

    # gg "Спасибо"
    gg "Cảm ơn"

# game/characters_events_idles/sonya_events.rpy:351
translate english sonya_scene4_morning_bathroom_db34cd4c:

    # gg "Эм . . ."
    gg "Ờm . . ."

# game/characters_events_idles/sonya_events.rpy:353
translate english sonya_scene4_morning_bathroom_f18372c4:

    # Sonya "Ой . . ." with hpunch
    Sonya "Ôi . . ." with hpunch

# game/characters_events_idles/sonya_events.rpy:354
translate english sonya_scene4_morning_bathroom_d5441823:

    # gg "Наверно, я зайду попозже"
    gg "Chắc anh vào sau vậy"

# game/characters_events_idles/sonya_events.rpy:356
translate english sonya_scene4_morning_bathroom_b9dc4392:

    # Sonya "Стой"
    Sonya "Đứng lại"

# game/characters_events_idles/sonya_events.rpy:358
translate english sonya_scene4_morning_bathroom_e21251db:

    # Sonya "Не стесняйся. Чисти зубы, я уже заканчиваю"
    Sonya "Đừng ngại. Đánh răng đi, em sắp xong rồi"

# game/characters_events_idles/sonya_events.rpy:360
translate english sonya_scene4_morning_bathroom_0d97ff86:

    # gg_chat "Ого . . ."
    gg_chat "Ồ . . ."

# game/characters_events_idles/sonya_events.rpy:364
translate english sonya_scene4_morning_bathroom_7f534b36:

    # Sonya "Тут раньше жили только мы с Маей"
    Sonya "Trước đây chỉ có em với Maya sống ở đây"

# game/characters_events_idles/sonya_events.rpy:366
translate english sonya_scene4_morning_bathroom_8e74c8b9:

    # Sonya "Девушки"
    Sonya "Con gái"

# game/characters_events_idles/sonya_events.rpy:368
translate english sonya_scene4_morning_bathroom_822105aa:

    # Sonya "Я привыкла ходить"
    Sonya "Em quen đi lại"

# game/characters_events_idles/sonya_events.rpy:370
translate english sonya_scene4_morning_bathroom_759d9a83:

    # Sonya "Так"
    Sonya "Như vậy"

# game/characters_events_idles/sonya_events.rpy:373
translate english sonya_scene4_morning_bathroom_893810bd:

    # Sonya "Никого это не смущало . . ."
    Sonya "Chẳng ai thấy ngại vì chuyện đó . . ."

# game/characters_events_idles/sonya_events.rpy:375
translate english sonya_scene4_morning_bathroom_2d618e7e:

    # gg "Да где-то я уже такое видел"
    gg "Ừ, anh đã thấy cảnh này ở đâu đó rồi"

# game/characters_events_idles/sonya_events.rpy:377
translate english sonya_scene4_morning_bathroom_26a90d56:

    # Sonya "Ты смотришь"
    Sonya "Anh đang nhìn"

# game/characters_events_idles/sonya_events.rpy:379
translate english sonya_scene4_morning_bathroom_62a5f760:

    # Sonya "Даже не пытаешься отвернуться"
    Sonya "Thậm chí không cố quay đi"

# game/characters_events_idles/sonya_events.rpy:382
translate english sonya_scene4_morning_bathroom_1c65dff9:

    # Sonya "И знаешь . . ."
    Sonya "Và anh biết không . . ."

# game/characters_events_idles/sonya_events.rpy:384
translate english sonya_scene4_morning_bathroom_7516d68e:

    # Sonya "Мне это нравится . . ."
    Sonya "Em thích điều đó . . ."

# game/characters_events_idles/sonya_events.rpy:388
translate english sonya_scene4_morning_bathroom_6911a69b:

    # Sonya "Всё"
    Sonya "Thôi"

# game/characters_events_idles/sonya_events.rpy:390
translate english sonya_scene4_morning_bathroom_bc7d5f86:

    # Sonya "Хватит тебе утренней зарядки для глаз"
    Sonya "Đủ bài tập thể dục buổi sáng cho mắt rồi"

# game/characters_events_idles/sonya_events.rpy:395
translate english sonya_scene4_morning_bathroom_9bf5f0cd:

    # Sonya "Но всё же . . ."
    Sonya "Nhưng mà . . ."

# game/characters_events_idles/sonya_events.rpy:397
translate english sonya_scene4_morning_bathroom_3780446f:

    # extend " Как ты можешь смотреть"
    extend "Sao anh có thể nhìn"

# game/characters_events_idles/sonya_events.rpy:401
translate english sonya_scene4_morning_bathroom_1f146f5f:

    # Sonya "И не трогать?"
    Sonya "Mà không chạm vào？"

# game/characters_events_idles/sonya_events.rpy:416
translate english sonya_scene5_night_girlroom_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/characters_events_idles/sonya_events.rpy:418
translate english sonya_scene5_night_girlroom_f0ccb195:

    # Sonya "[povname] . . ."
    Sonya "[povname] . . ."

# game/characters_events_idles/sonya_events.rpy:422
translate english sonya_scene5_night_girlroom_f0ccb195_1:

    # Sonya "[povname] . . ."
    Sonya "[povname] . . ."

# game/characters_events_idles/sonya_events.rpy:425
translate english sonya_scene5_night_girlroom_6c32fa14:

    # gg "А что . . ."
    gg "Thì sao . . ."

# game/characters_events_idles/sonya_events.rpy:427
translate english sonya_scene5_night_girlroom_b3aa243a:

    # Sonya "Прости"
    Sonya "Xin lỗi"

# game/characters_events_idles/sonya_events.rpy:428
translate english sonya_scene5_night_girlroom_4aff93e9:

    # Sonya "Я не хотела тебя резко будить"
    Sonya "Em không muốn đánh thức anh đột ngột"

# game/characters_events_idles/sonya_events.rpy:431
translate english sonya_scene5_night_girlroom_cbd4343b:

    # Sonya "Просто . . . не могу заснуть"
    Sonya "Chỉ là . . . em không ngủ được"

# game/characters_events_idles/sonya_events.rpy:433
translate english sonya_scene5_night_girlroom_873c4360:

    # Sonya "Ты спишь так спокойно"
    Sonya "Anh ngủ bình yên quá"

# game/characters_events_idles/sonya_events.rpy:435
translate english sonya_scene5_night_girlroom_988f1304:

    # Sonya "Посидишь со мной немного?"
    Sonya "Ngồi với em một chút được không？"

# game/characters_events_idles/sonya_events.rpy:437
translate english sonya_scene5_night_girlroom_2970a146:

    # Sonya "Пока не отпустит"
    Sonya "Cho đến khi em bình tĩnh lại"

# game/characters_events_idles/sonya_events.rpy:439
translate english sonya_scene5_night_girlroom_a9b332b7:

    # gg "Ты устала?"
    gg "Em mệt à？"

# game/characters_events_idles/sonya_events.rpy:441
translate english sonya_scene5_night_girlroom_0fb040eb:

    # Sonya "Нет,{w} не совсем"
    Sonya "Không,{w} không hẳn"

# game/characters_events_idles/sonya_events.rpy:443
translate english sonya_scene5_night_girlroom_5527f93e:

    # Sonya "Просто думала"
    Sonya "Chỉ là em đang nghĩ"

# game/characters_events_idles/sonya_events.rpy:446
translate english sonya_scene5_night_girlroom_72ba6d47:

    # gg "О чём?"
    gg "Nghĩ gì？"

# game/characters_events_idles/sonya_events.rpy:448
translate english sonya_scene5_night_girlroom_69179d28:

    # Sonya "Да не важно"
    Sonya "Không quan trọng"

# game/characters_events_idles/sonya_events.rpy:452
translate english sonya_scene5_night_girlroom_589ad1ec:

    # gg "Ты всё время так?"
    gg "Lúc nào em cũng vậy à？"

# game/characters_events_idles/sonya_events.rpy:453
translate english sonya_scene5_night_girlroom_6f30ec91:

    # gg "Или бывает, что расслабляешься?"
    gg "Hay có lúc em thư giãn？"

# game/characters_events_idles/sonya_events.rpy:455
translate english sonya_scene5_night_girlroom_fda29abb:

    # Sonya "Раньше было легче"
    Sonya "Trước đây dễ hơn"

# game/characters_events_idles/sonya_events.rpy:457
translate english sonya_scene5_night_girlroom_1684e2b6:

    # Sonya "Просто я"
    Sonya "Chỉ là em"

# game/characters_events_idles/sonya_events.rpy:459
translate english sonya_scene5_night_girlroom_09ea6a66:

    # Sonya "Привыкла держать всё под контролем"
    Sonya "Đã quen kiểm soát mọi thứ"

# game/characters_events_idles/sonya_events.rpy:462
translate english sonya_scene5_night_girlroom_27fc4b94:

    # Sonya "Ладно . . ."
    Sonya "Được rồi . . ."

# game/characters_events_idles/sonya_events.rpy:465
translate english sonya_scene5_night_girlroom_04a163be:

    # Sonya "Вот видишь"
    Sonya "Thấy chưa"

# game/characters_events_idles/sonya_events.rpy:467
translate english sonya_scene5_night_girlroom_1825b5d8:

    # Sonya "Даже это нормально не могу"
    Sonya "Đến cả việc này em cũng không làm nổi"

# game/characters_events_idles/sonya_events.rpy:473
translate english sonya_scene5_night_girlroom_4706c7d6:

    # Sonya "Давай просто полежим"
    Sonya "Mình chỉ nằm thôi nhé"

# game/characters_events_idles/sonya_events.rpy:475
translate english sonya_scene5_night_girlroom_dd04d853:

    # Sonya "Я не хочу думать сейчас"
    Sonya "Em không muốn nghĩ gì bây giờ"

# game/characters_events_idles/sonya_events.rpy:493
translate english sonya_scene5_night_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "Cảm ơn . . ."

# game/characters_events_idles/sonya_events.rpy:495
translate english sonya_scene5_night_girlroom_7edcc3c4:

    # Sonya "Я давно так нормально не спала"
    Sonya "Lâu lắm rồi em mới ngủ ngon như vậy"

# game/characters_events_idles/sonya_events.rpy:503
translate english sonya_scene5_night_girlroom_a9d8faa5:

    # Sonya "Если Мая увидит нас, будет много вопросов"
    Sonya "Nếu Maya thấy chúng ta, sẽ có nhiều câu hỏi đấy"

# game/characters_events_idles/sonya_events.rpy:505
translate english sonya_scene5_night_girlroom_2c86168e:

    # Sonya "Я сделаю тебе завтрак"
    Sonya "Em sẽ làm bữa sáng cho anh"

# game/characters_events_idles/sonya_events.rpy:507
translate english sonya_scene5_night_girlroom_9663ea36:

    # Sonya "Он будет вкусным, не переживай"
    Sonya "Nó sẽ ngon, đừng lo"

# game/characters_events_idles/sonya_events.rpy:525
translate english sonya_scene6_evening_myroom_1d152ede:

    # gg "Привет!"
    gg "Chào!"

# game/characters_events_idles/sonya_events.rpy:527
translate english sonya_scene6_evening_myroom_4979c711:

    # Sonya "Эй, ты аниме смотришь?"
    Sonya "Này, anh đang xem anime à？"

# game/characters_events_idles/sonya_events.rpy:529
translate english sonya_scene6_evening_myroom_8dbdedb7:

    # Sonya "Тут только началось"
    Sonya "Ở đây mới bắt đầu thôi"

# game/characters_events_idles/sonya_events.rpy:531
translate english sonya_scene6_evening_myroom_a94af5bd:

    # gg "Ага, почему бы и нет"
    gg "Ừ, sao lại không nhỉ"

# game/characters_events_idles/sonya_events.rpy:538
translate english sonya_scene6_evening_myroom_4fa070d4:

    # gg "Забавно . . ."
    gg "Buồn cười thật . . ."

# game/characters_events_idles/sonya_events.rpy:540
translate english sonya_scene6_evening_myroom_2e5cd401:

    # extend "Теперь этот диван - моя кровать"
    extend "Giờ cái ghế sofa này là giường của anh"

# game/characters_events_idles/sonya_events.rpy:542
translate english sonya_scene6_evening_myroom_a3f8d8b5:

    # gg "Я привык на нём фильмы смотреть, а теперь ещё и сплю здесь"
    gg "Anh quen xem phim trên đó, giờ còn ngủ ở đây nữa"

# game/characters_events_idles/sonya_events.rpy:543
translate english sonya_scene6_evening_myroom_8d9b5058:

    # Sonya "Вообще - то"
    Sonya "Thật ra thì"

# game/characters_events_idles/sonya_events.rpy:547
translate english sonya_scene6_evening_myroom_8bf7cd77:

    # extend " раньше это была моя кровать"
    extend "trước đây đây là giường của em"

# game/characters_events_idles/sonya_events.rpy:549
translate english sonya_scene6_evening_myroom_4b9b63e3:

    # Sonya "До ухода Линды"
    Sonya "Trước khi Linda rời đi"

# game/characters_events_idles/sonya_events.rpy:551
translate english sonya_scene6_evening_myroom_2c51288e:

    # Sonya "А она тогда жила в моей комнатe"
    Sonya "Hồi đó cô ấy sống trong phòng của em"

# game/characters_events_idles/sonya_events.rpy:553
translate english sonya_scene6_evening_myroom_3467de90:

    # gg "Серьёзно?"
    gg "Thật á？"

# game/characters_events_idles/sonya_events.rpy:555
translate english sonya_scene6_evening_myroom_80955fa4:

    # Sonya "Да, но потом мы сделали ремонт, чтобы всё было по - нашему"
    Sonya "Ừ, nhưng sau đó bọn em sửa sang lại để mọi thứ hợp ý mình"

# game/characters_events_idles/sonya_events.rpy:557
translate english sonya_scene6_evening_myroom_3d5a6534:

    # gg "Красиво получилось . . . {w}и дом где провел детство все еще чувствуется"
    gg "Đẹp thật . . . {w}và vẫn còn cảm nhận được ngôi nhà của tuổi thơ"

# game/characters_events_idles/sonya_events.rpy:562
translate english sonya_scene6_evening_myroom_0bab6ed7:

    # "Ты мог бы идти один. Я бы справилась"
    "Anh có thể đi một mình. Em sẽ xoay xở được"

# game/characters_events_idles/sonya_events.rpy:564
translate english sonya_scene6_evening_myroom_e09cf293:

    # "Ты слишком спокоен. Обычно люди стараются понравиться"
    "Anh quá bình tĩnh. Thường thì người ta cố gắng làm hài lòng"

# game/characters_events_idles/sonya_events.rpy:566
translate english sonya_scene6_evening_myroom_93462049:

    # "А я не хочу «стараться». Хочу, чтобы ты узнала меня настоящего"
    "Còn anh không muốn «cố gắng». Anh muốn em biết con người thật của anh"

# game/characters_events_idles/sonya_events.rpy:568
translate english sonya_scene6_evening_myroom_25dcefcc:

    # "Знаешь, у меня есть и более интересные дела"
    "Biết không, anh còn có những việc thú vị hơn"

# game/characters_events_idles/sonya_events.rpy:570
translate english sonya_scene6_evening_myroom_fda89b59:

    # "Тогда почему ты всё ещё здесь?"
    "Vậy tại sao anh vẫn ở đây？"

# game/characters_events_idles/sonya_events.rpy:573
translate english sonya_scene6_evening_myroom_7f029619:

    # Sonya "Вот смотри . . ."
    Sonya "Nhìn này . . ."

# game/characters_events_idles/sonya_events.rpy:575
translate english sonya_scene6_evening_myroom_6f549ff9:

    # extend " она играет „недоступную“"
    extend "cô ta đang đóng vai „khó gần“"

# game/characters_events_idles/sonya_events.rpy:577
translate english sonya_scene6_evening_myroom_beb1c184:

    # Sonya "Хотя видно, что сохнет по нему . . ."
    Sonya "Dù rõ ràng là cô ta đang tương tư hắn . . ."

# game/characters_events_idles/sonya_events.rpy:580
translate english sonya_scene6_evening_myroom_766aa28c:

    # gg "Может, в этом и драма?"
    gg "Có lẽ bi kịch nằm ở đó？"

# game/characters_events_idles/sonya_events.rpy:582
translate english sonya_scene6_evening_myroom_ae35e350:

    # Sonya "Драма в том, что тянет резину"
    Sonya "Bi kịch là cô ta cứ kéo dài lê thê"

# game/characters_events_idles/sonya_events.rpy:584
translate english sonya_scene6_evening_myroom_70feb79f:

    # Sonya "Зачем, если всё ясно?"
    Sonya "Để làm gì khi mọi thứ đã rõ ràng？"

# game/characters_events_idles/sonya_events.rpy:585
translate english sonya_scene6_evening_myroom_b291874f:

    # Sonya "{sc}Это раздражает{/sc}" with hpunch
    Sonya "{sc}Thật bực mình{/sc}" with hpunch

# game/characters_events_idles/sonya_events.rpy:587
translate english sonya_scene6_evening_myroom_6ef8cdd4:

    # gg "Ты бы решила быстрее?"
    gg "Em sẽ giải quyết nhanh hơn à？"

# game/characters_events_idles/sonya_events.rpy:589
translate english sonya_scene6_evening_myroom_2db4fbf2:

    # Sonya "Намного быстрее . . ."
    Sonya "Nhanh hơn nhiều . . ."

# game/characters_events_idles/sonya_events.rpy:591
translate english sonya_scene6_evening_myroom_c5704027:

    # Sonya "Скучное аниме"
    Sonya "Anime chán ngắt"

# game/characters_events_idles/sonya_events.rpy:593
translate english sonya_scene6_evening_myroom_9be82b23:

    # Sonya "Я не могу сидеть спокойно"
    Sonya "Em không thể ngồi yên được"

# game/characters_events_idles/sonya_events.rpy:595
translate english sonya_scene6_evening_myroom_13513f79:

    # gg "Тогда ложись, может, так будет легче"
    gg "Vậy nằm xuống đi, có khi sẽ dễ chịu hơn"

# game/characters_events_idles/sonya_events.rpy:597
translate english sonya_scene6_evening_myroom_0d9cdeae:

    # Sonya "Лечь говоришь?"
    Sonya "Nằm xuống à？"

# game/characters_events_idles/sonya_events.rpy:605
translate english sonya_scene6_evening_myroom_448d2ea3:

    # Sonya "Да так спокойнее . . ."
    Sonya "Ừ, như vậy yên tâm hơn . . ."

# game/characters_events_idles/sonya_events.rpy:610
translate english sonya_scene6_evening_myroom_75e70e12:

    # Sonya "{sc}Ах . . .{/sc}"
    Sonya "{sc}Á . . .{/sc}"

# game/characters_events_idles/sonya_events.rpy:613
translate english sonya_scene6_evening_myroom_376482db:

    # Sonya "Вот так . . ."
    Sonya "Như thế . . ."

# game/characters_events_idles/sonya_events.rpy:614
translate english sonya_scene6_evening_myroom_28a0cb64:

    # Sonya "Наконец - то"
    Sonya "Cuối cùng thì"

# game/characters_events_idles/sonya_events.rpy:616
translate english sonya_scene6_evening_myroom_2157c7a2:

    # Sonya "Не бойся, мне нравится"
    Sonya "Đừng sợ, em thích mà"

# game/characters_events_idles/sonya_events.rpy:619
translate english sonya_scene6_evening_myroom_e0c310ab:

    # Sonya "В ванной ты только смотрел"
    Sonya "Trong phòng tắm anh chỉ nhìn thôi"

# game/characters_events_idles/sonya_events.rpy:621
translate english sonya_scene6_evening_myroom_23073e11:

    # Sonya "Тут я тебе помогу"
    Sonya "Ở đây em sẽ giúp anh"

# game/characters_events_idles/sonya_events.rpy:623
translate english sonya_scene6_evening_myroom_77e32f3e:

    # Sonya "Я знаю, что ты хочешь"
    Sonya "Em biết anh muốn gì"

# game/characters_events_idles/sonya_events.rpy:625
translate english sonya_scene6_evening_myroom_314984e9:

    # Sonya "Просто помогаю"
    Sonya "Chỉ là giúp thôi"

# game/characters_events_idles/sonya_events.rpy:629
translate english sonya_scene6_evening_myroom_70da84e8:

    # Sonya "Мне приятно . . . {w}даже больше, чем я ожидала"
    Sonya "Em thấy dễ chịu . . . {w}thậm chí hơn cả em tưởng"

# game/characters_events_idles/sonya_events.rpy:630
translate english sonya_scene6_evening_myroom_42733475:

    # gg "У тебя прекрасная грудь . . . {w}мягкая и тёплая"
    gg "Em có bộ ngực tuyệt đẹp . . . {w}mềm và ấm"

# game/characters_events_idles/sonya_events.rpy:631
translate english sonya_scene6_evening_myroom_ae3a5ec7:

    # gg "Идеальная"
    gg "Hoàn hảo"

# game/characters_events_idles/sonya_events.rpy:632
translate english sonya_scene6_evening_myroom_ec947a50:

    # Sonya "Хитрый . . ."
    Sonya "Đồ ranh mãnh . . ."

# game/characters_events_idles/sonya_events.rpy:633
translate english sonya_scene6_evening_myroom_9e059832:

    # Sonya "Знаешь ведь, что я краснею от таких слов"
    Sonya "Anh biết mà, em đỏ mặt vì những lời như thế"

# game/characters_events_idles/sonya_events.rpy:635
translate english sonya_scene6_evening_myroom_9a2913c4:

    # Sonya "Но продолжай"
    Sonya "Nhưng cứ tiếp đi"

# game/characters_events_idles/sonya_events.rpy:644
translate english sonya_scene6_evening_myroom_394ba447:

    # Maya "А что это вы тут . . ."
    Maya "Mà hai người ở đây . . ."

# game/characters_events_idles/sonya_events.rpy:646
translate english sonya_scene6_evening_myroom_f2d7a854:

    # Maya "В обнимку сидите?"
    Maya "Ngồi ôm nhau à？"

# game/characters_events_idles/sonya_events.rpy:648
translate english sonya_scene6_evening_myroom_a3e76380:

    # Sonya "Аниме смотрим. {w}Но он скучный"
    Sonya "Bọn mình đang xem anime. {w}Nhưng nó chán"

# game/characters_events_idles/sonya_events.rpy:649
translate english sonya_scene6_evening_myroom_28afd6ea:

    # gg "Да, просто аниме"
    gg "Ừ, chỉ là anime thôi"

# game/characters_events_idles/sonya_events.rpy:651
translate english sonya_scene6_evening_myroom_aa558823:

    # Maya "Не думайте что я этого не видела . . ."
    Maya "Đừng tưởng tớ không thấy nhé . . ."

# game/characters_events_idles/sonya_events.rpy:654
translate english sonya_scene6_evening_myroom_eba4c233:

    # Sonya "Спасибо за вечер"
    Sonya "Cảm ơn vì buổi tối"

# game/characters_events_idles/sonya_events.rpy:656
translate english sonya_scene6_evening_myroom_e7128efe:

    # Sonya "Было . . . {w} приятно"
    Sonya "Thật . . . {w} dễ chịu"

# game/characters_events_idles/sonya_events.rpy:660
translate english sonya_scene6_evening_myroom_222b7c49:

    # Sonya "Давай оставим аниме на завтра"
    Sonya "Mình để anime đến mai nhé"

# game/characters_events_idles/sonya_events.rpy:661
translate english sonya_scene6_evening_myroom_be1b9cb9:

    # Sonya "Закончим на этом, а то я и сама не остановлюсь"
    Sonya "Kết thúc ở đây thôi, không thì chính em cũng không dừng lại được"

# game/characters_events_idles/sonya_events.rpy:663
translate english sonya_scene6_evening_myroom_b989363c:

    # gg ". . ."
    gg ". . ."

# game/characters_events_idles/sonya_events.rpy:678
translate english sonya_scene7_evening_girlroom_0262890b:

    # Sonya "Зайдёшь ко мне?"
    Sonya "Anh ghé phòng em không？"

# game/characters_events_idles/sonya_events.rpy:680
translate english sonya_scene7_evening_girlroom_cf65688b:

    # Sonya "Просто . . . {w}хочу поговорить "
    Sonya "Chỉ là . . . {w}em muốn nói chuyện "

# game/characters_events_idles/sonya_events.rpy:682
translate english sonya_scene7_evening_girlroom_0609085f:

    # gg "Конечно"
    gg "Tất nhiên"

# game/characters_events_idles/sonya_events.rpy:684
translate english sonya_scene7_evening_girlroom_fe1b6c78:

    # gg "Ты какая-то задумчивая"
    gg "Em có vẻ trầm tư"

# game/characters_events_idles/sonya_events.rpy:686
translate english sonya_scene7_evening_girlroom_24fe6265:

    # Sonya "Да . . ."
    Sonya "Ừ . . ."

# game/characters_events_idles/sonya_events.rpy:688
translate english sonya_scene7_evening_girlroom_546a584b:

    # Sonya "Просто не могу всё выкинуть из головы"
    Sonya "Chỉ là em không thể gạt mọi thứ ra khỏi đầu"

# game/characters_events_idles/sonya_events.rpy:690
translate english sonya_scene7_evening_girlroom_7ff0eaf1:

    # Sonya "Всё как-то закрутилось слишком быстро"
    Sonya "Mọi thứ cứ rối lên quá nhanh"

# game/characters_events_idles/sonya_events.rpy:692
translate english sonya_scene7_evening_girlroom_fb1f6848:

    # gg "В каком смысле?"
    gg "Ý em là sao？"

# game/characters_events_idles/sonya_events.rpy:694
translate english sonya_scene7_evening_girlroom_b7dadb54:

    # Sonya "Ну . . . {w}обычно я держусь спокойно"
    Sonya "Thì . . . {w}thường thì em giữ được bình tĩnh"

# game/characters_events_idles/sonya_events.rpy:696
translate english sonya_scene7_evening_girlroom_8a221fed:

    # Sonya "Всё у меня под контролем"
    Sonya "Mọi thứ đều trong tầm kiểm soát của em"

# game/characters_events_idles/sonya_events.rpy:698
translate english sonya_scene7_evening_girlroom_afb359d5:

    # Sonya "Но рядом с тобой . . . {w}всё иначе"
    Sonya "Nhưng ở bên anh . . . {w}mọi thứ khác đi"

# game/characters_events_idles/sonya_events.rpy:700
translate english sonya_scene7_evening_girlroom_486c8325:

    # gg "Иначе - это плохо?"
    gg "Khác đi — là không tốt à？"

# game/characters_events_idles/sonya_events.rpy:702
translate english sonya_scene7_evening_girlroom_6f2ad814:

    # Sonya "Иногда кажется, что я делаю глупости"
    Sonya "Đôi khi em thấy mình đang làm những chuyện ngốc nghếch"

# game/characters_events_idles/sonya_events.rpy:704
translate english sonya_scene7_evening_girlroom_b81ca64b:

    # Sonya "Такие . . . {w}нелепые"
    Sonya "Những chuyện . . . {w}ngớ ngẩn"

# game/characters_events_idles/sonya_events.rpy:706
translate english sonya_scene7_evening_girlroom_716ea2d0:

    # Sonya "Будто я снова подросток"
    Sonya "Cứ như em lại là một cô bé tuổi teen"

# game/characters_events_idles/sonya_events.rpy:708
translate english sonya_scene7_evening_girlroom_c3165439:

    # gg " . . ."
    gg ". . ."

# game/characters_events_idles/sonya_events.rpy:710
translate english sonya_scene7_evening_girlroom_43cc3ee5:

    # Sonya "Я не уверена в своём поведении"
    Sonya "Em không chắc về cách hành xử của mình"

# game/characters_events_idles/sonya_events.rpy:711
translate english sonya_scene7_evening_girlroom_bf81f51b:

    # Sonya "Может, я слишком тороплюсь"
    Sonya "Có lẽ em đang quá vội vàng"

# game/characters_events_idles/sonya_events.rpy:713
translate english sonya_scene7_evening_girlroom_7263e949:

    # Sonya "Может, выгляжу смешно"
    Sonya "Có lẽ em trông buồn cười"

# game/characters_events_idles/sonya_events.rpy:715
translate english sonya_scene7_evening_girlroom_5c74b5ea:

    # gg "Мне так не кажется"
    gg "Anh không thấy vậy"

# game/characters_events_idles/sonya_events.rpy:717
translate english sonya_scene7_evening_girlroom_9d42851b:

    # Sonya "А если вдруг?"
    Sonya "Nhỡ đâu thì sao？"

# game/characters_events_idles/sonya_events.rpy:718
translate english sonya_scene7_evening_girlroom_6fb3c26c:

    # Sonya "Если я правда не такая, какой должна быть?"
    Sonya "Nếu em thật sự không phải người mà em nên trở thành？"

# game/characters_events_idles/sonya_events.rpy:720
translate english sonya_scene7_evening_girlroom_5c8cc88c:

    # Sonya "Ты всё равно примешь меня?"
    Sonya "Anh vẫn sẽ chấp nhận em chứ？"

# game/characters_events_idles/sonya_events.rpy:727
translate english sonya_scene7_evening_girlroom_ca1ff0ec:

    # gg "Мне нравишься настоящая ты"
    gg "Anh thích con người thật của em"

# game/characters_events_idles/sonya_events.rpy:730
translate english sonya_scene7_evening_girlroom_495fe1ef:

    # gg "Мне не нужно, чтобы ты была какой-то другой"
    gg "Anh không cần em phải là ai khác"

# game/characters_events_idles/sonya_events.rpy:746
translate english sonya_scene7_evening_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "Cảm ơn . . ."

# game/characters_events_idles/sonya_events.rpy:747
translate english sonya_scene7_evening_girlroom_860f4d16:

    # Sonya "Это именно то что я хотела"
    Sonya "Đó chính là điều em muốn"

# game/characters_events_idles/sonya_events.rpy:753
translate english sonya_scene7_evening_girlroom_489479bc:

    # Sonya "{sc}Да . . . Так . . .{/sc}"
    Sonya "{sc}Đúng . . . Như thế . . .{/sc}"

# game/characters_events_idles/sonya_events.rpy:759
translate english sonya_scene7_evening_girlroom_2d94ee37:

    # Sonya "На диване ты меня трогал"
    Sonya "Trên ghế sofa anh đã chạm vào em"

# game/characters_events_idles/sonya_events.rpy:760
translate english sonya_scene7_evening_girlroom_fc982615:

    # Sonya "Теперь - моя очередь"
    Sonya "Giờ — đến lượt em"

# game/characters_events_idles/sonya_events.rpy:767
translate english sonya_scene7_evening_girlroom_7b973257:

    # Sonya "Смотри на меня"
    Sonya "Nhìn em này"

# game/characters_events_idles/sonya_events.rpy:775
translate english sonya_scene7_evening_girlroom_1b8740c5:

    # Sonya "Всё - ты теперь мой!"
    Sonya "Xong rồi — giờ anh là của em!"

# game/characters_events_idles/sonya_events.rpy:783
translate english sonya_scene7_evening_girlroom_2da445da:

    # Sonya "Подожди тут"
    Sonya "Đợi ở đây"

# game/characters_events_idles/sonya_events.rpy:785
translate english sonya_scene7_evening_girlroom_250fe814:

    # Sonya "Я быстро"
    Sonya "Em xong nhanh thôi"

# game/characters_events_idles/sonya_events.rpy:791
translate english sonya_scene7_evening_girlroom_dadabf98:

    # gg_chat "Это случилось так быстро . . . "
    gg_chat "Chuyện đó xảy ra nhanh quá . . . "

# game/characters_events_idles/sonya_events.rpy:798
translate english sonya_scene7_evening_girlroom_e844ad84:

    # Sonya "Останься"
    Sonya "Ở lại đi"

# game/characters_events_idles/sonya_events.rpy:800
translate english sonya_scene7_evening_girlroom_1d2efc6a:

    # Sonya "Посиди со мной"
    Sonya "Ngồi với em"

# game/characters_events_idles/sonya_events.rpy:802
translate english sonya_scene7_evening_girlroom_b435d332:

    # Sonya "И посмотрим, куда это нас приведёт."
    Sonya "Và xem chuyện này sẽ đưa chúng ta đến đâu."

# game/characters_events_idles/sonya_events.rpy:805
translate english sonya_scene7_evening_girlroom_ca91d43d:

    # gg_chat "Было тепло"
    gg_chat "Thật ấm áp"

# game/characters_events_idles/sonya_events.rpy:806
translate english sonya_scene7_evening_girlroom_899d5485:

    # gg_chat "Я хотел остаться рядом"
    gg_chat "Anh muốn ở lại bên cạnh"

translate english strings:

    # game/characters_events_idles/sonya_events.rpy:516
    old "Утро"
    new "Buổi sáng"

    # game/characters_events_idles/sonya_events.rpy:608
    old "Играешь со мной?"
    new "Chơi với em không？"

    # game/characters_events_idles/sonya_events.rpy:618
    old "Мне так хорошо"
    new "Em thấy thật tuyệt"

    # game/characters_events_idles/sonya_events.rpy:725
    old "Такой ты и нужна"
    new "Em nên như vậy"

    # game/characters_events_idles/sonya_events.rpy:734
    old "Поцеловать"
    new "Hôn"

# game/characters_events_idles/sonya_events.rpy:20
translate english sonya_scene1_morning_kitchen_c92bc08a:

    # Sonya "Там диван, конечно, старый"
    Sonya "Cái ghế sofa đó dĩ nhiên là cũ"

# game/characters_events_idles/sonya_events.rpy:50
translate english sonya_scene1_morning_kitchen_12302e27:

    # Sonya "У нас, обычно, никто особо не спрашивает"
    Sonya "Ở chỗ bọn em, thường chẳng ai hỏi nhiều"

# game/characters_events_idles/sonya_events.rpy:161
translate english sonya_scene2_day_girlroom_9c553288:

    # Sonya "Так и планировал . . ."
    Sonya "Anh định vậy từ đầu . . ."

# game/characters_events_idles/sonya_events.rpy:177
translate english sonya_scene2_day_girlroom_c5761118:

    # Sonya "Ты, получается, больше утренний человек?"
    Sonya "Vậy ra anh là người thiên về buổi sáng hơn？"

# game/characters_events_idles/sonya_events.rpy:335
translate english sonya_scene3_day_bathroom_21f8234f:

    # Sonya "Горячий, аккуратнее"
    Sonya "Nóng đấy, cẩn thận"

# game/characters_events_idles/sonya_events.rpy:383
translate english sonya_scene4_morning_bathroom_0d2b005c:

    # gg "Да, где-то я уже такое видел"
    gg "Ừ, anh đã thấy cảnh này ở đâu đó rồi"

# game/characters_events_idles/sonya_events.rpy:385
translate english sonya_scene4_morning_bathroom_11b14ed3:

    # Sonya "Ты смотришь . . ."
    Sonya "Anh đang nhìn . . ."

# game/characters_events_idles/sonya_events.rpy:486
translate english sonya_scene5_night_girlroom_44967887:

    # Sonya "Я не хочу ни о чем думать . . ."
    Sonya "Em không muốn nghĩ về bất cứ điều gì . . ."
# game/characters_events_idles/sonya_events.rpy:835
translate english sonya_scene8_morning_kitchen_a482bb49:

    # gg "Утречка"
    gg "Chào buổi sáng"

# game/characters_events_idles/sonya_events.rpy:837
translate english sonya_scene8_morning_kitchen_ce42d6cf:

    # Sonya "Доброе утро . . ."
    Sonya "Chào buổi sáng . . ."

# game/characters_events_idles/sonya_events.rpy:839
translate english sonya_scene8_morning_kitchen_72c13c11:

    # Sonya "Я . . . почти закончила готовить, садись"
    Sonya "Em . . . gần nấu xong rồi, ngồi đi"

# game/characters_events_idles/sonya_events.rpy:842
translate english sonya_scene8_morning_kitchen_bb1eb7c8:

    # gg "Ты рано встала"
    gg "Em dậy sớm thế"

# game/characters_events_idles/sonya_events.rpy:844
translate english sonya_scene8_morning_kitchen_42ef4d92:

    # Sonya "Не спалось"
    Sonya "Không ngủ được"

# game/characters_events_idles/sonya_events.rpy:846
translate english sonya_scene8_morning_kitchen_a756dcde:

    # Sonya "Подумала . . ."
    Sonya "Em nghĩ là . . ."

# game/characters_events_idles/sonya_events.rpy:848
translate english sonya_scene8_morning_kitchen_381d05fd:

    # Sonya "Раз ты всё равно проснёшься . . ."
    Sonya "Vì kiểu gì anh cũng sẽ thức dậy . . ."

# game/characters_events_idles/sonya_events.rpy:850
translate english sonya_scene8_morning_kitchen_13f1fe10:

    # Sonya "Будет хорошо, заранее приготовить тебе"
    Sonya "Chuẩn bị sẵn cho anh sẽ tốt hơn"

# game/characters_events_idles/sonya_events.rpy:861
translate english sonya_scene8_morning_kitchen_c3201521:

    # Sonya "Можно?"
    Sonya "Được không？"

# game/characters_events_idles/sonya_events.rpy:865
translate english sonya_scene8_morning_kitchen_0609085f:

    # gg "Конечно"
    gg "Tất nhiên"

# game/characters_events_idles/sonya_events.rpy:870
translate english sonya_scene8_morning_kitchen_f49db0d9:

    # gg "Очень вкусно"
    gg "Rất ngon"

# game/characters_events_idles/sonya_events.rpy:872
translate english sonya_scene8_morning_kitchen_6f15bff0:

    # Sonya "Я рада"
    Sonya "Em mừng"

# game/characters_events_idles/sonya_events.rpy:874
translate english sonya_scene8_morning_kitchen_8bd5d020:

    # Sonya "Мне важно, чтобы тебе было хорошо"
    Sonya "Em quan tâm đến việc anh thấy thoải mái"

# game/characters_events_idles/sonya_events.rpy:882
translate english sonya_scene8_morning_kitchen_41dbce33:

    # Sonya "Я всю ночь думала . . ."
    Sonya "Cả đêm em đã nghĩ . . ."

# game/characters_events_idles/sonya_events.rpy:885
translate english sonya_scene8_morning_kitchen_f519c6fc:

    # Sonya "Раньше я беспокоилась"
    Sonya "Trước đây em hay lo lắng"

# game/characters_events_idles/sonya_events.rpy:887
translate english sonya_scene8_morning_kitchen_b0e09a72:

    # Sonya "А сегодня . . ."
    Sonya "Còn hôm nay . . ."

# game/characters_events_idles/sonya_events.rpy:889
translate english sonya_scene8_morning_kitchen_814991c8:

    # Sonya "Мне спокойно"
    Sonya "Em thấy bình yên"

# game/characters_events_idles/sonya_events.rpy:898
translate english sonya_scene8_morning_kitchen_d0794f94:

    # Sonya "Если ты не против . . ."
    Sonya "Nếu anh không phiền . . ."

# game/characters_events_idles/sonya_events.rpy:900
translate english sonya_scene8_morning_kitchen_9c748c84:

    # Sonya "Я могу . . ."
    Sonya "Em có thể . . ."

# game/characters_events_idles/sonya_events.rpy:904
translate english sonya_scene8_morning_kitchen_a877578e:

    # Sonya "Быть чуть ближе"
    Sonya "Gần hơn một chút"

# game/characters_events_idles/sonya_events.rpy:926
translate english sonya_scene8_morning_kitchen_1b7d05a8:

    # Sonya "Чувствовать, как ты становишься твёрже . . ."
    Sonya "Cảm nhận anh trở nên cứng hơn . . ."

# game/characters_events_idles/sonya_events.rpy:927
translate english sonya_scene8_morning_kitchen_b85aacb1:

    # Sonya "От моего прикосновения . . . {w}это так . . ."
    Sonya "Từ cái chạm của em . . . {w}điều đó thật . . ."

# game/characters_events_idles/sonya_events.rpy:928
translate english sonya_scene8_morning_kitchen_9213f2a8:

    # Sonya ". . . Заводит. {w}Сильнее, чем я думала"
    Sonya ". . . Kích thích. {w}Mạnh hơn em tưởng"

# game/characters_events_idles/sonya_events.rpy:929
translate english sonya_scene8_morning_kitchen_9bc062d5:

    # Sonya "Смотри на меня . . . только на меня . . ."
    Sonya "Nhìn em . . . chỉ nhìn em thôi . . ."

# game/characters_events_idles/sonya_events.rpy:940
translate english sonya_scene8_morning_kitchen_55a277bb:

    # Sonya "Я . . . не знаю, как правильно это сказать . . ."
    Sonya "Em . . . không biết nên nói điều này thế nào cho đúng . . ."

# game/characters_events_idles/sonya_events.rpy:942
translate english sonya_scene8_morning_kitchen_beb08d03:

    # Sonya "Но мне хорошо, когда ты рядом"
    Sonya "Nhưng em thấy dễ chịu khi anh ở bên"


# game/characters_events_idles/sonya_events.rpy:961
translate english sonya_scene9_night_myroom_9a8b0be2:

    # gg "Привет"
    gg "Chào"

# game/characters_events_idles/sonya_events.rpy:963
translate english sonya_scene9_night_myroom_b3a2b8a1:

    # Sonya "Привет ты ещё не ложишься?"
    Sonya "Chào, anh chưa đi ngủ à？"

# game/characters_events_idles/sonya_events.rpy:965
translate english sonya_scene9_night_myroom_bb3c3085:

    # Sonya "Тогда пойдём вместе в ванную?"
    Sonya "Vậy mình cùng vào phòng tắm nhé？"

# game/characters_events_idles/sonya_events.rpy:967
translate english sonya_scene9_night_myroom_9afefc8e:

    # Sonya "Я хочу голову помыть . . ."
    Sonya "Em muốn gội đầu . . ."

# game/characters_events_idles/sonya_events.rpy:969
translate english sonya_scene9_night_myroom_b4639877:

    # Sonya "И тебе тоже"
    Sonya "Và cho anh nữa"

# game/characters_events_idles/sonya_events.rpy:971
translate english sonya_scene9_night_myroom_66416cc5:

    # gg "Ну пойдем"
    gg "Ừ, đi thôi"

# game/characters_events_idles/sonya_events.rpy:981
translate english sonya_scene9_night_myroom_c5d3f2b1:

    # Sonya "Ты тоже раздевайся давай"
    Sonya "Anh cũng cởi đồ đi"

# game/characters_events_idles/sonya_events.rpy:987
translate english sonya_scene9_night_myroom_ebd2cc14:

    # Sonya "Подожди . . ."
    Sonya "Đợi đã . . ."

# game/characters_events_idles/sonya_events.rpy:989
translate english sonya_scene9_night_myroom_abb56970:

    # Sonya "У тебя молния заела"
    Sonya "Khóa kéo của anh bị kẹt rồi"

# game/characters_events_idles/sonya_events.rpy:996
translate english sonya_scene9_night_myroom_3672b0c0:

    # Sonya "Быстро ты . . ."
    Sonya "Anh nhanh thật . . ."

# game/characters_events_idles/sonya_events.rpy:998
translate english sonya_scene9_night_myroom_ba83a14c:

    # Sonya "Давай садись"
    Sonya "Ngồi xuống đi"

# game/characters_events_idles/sonya_events.rpy:1000
translate english sonya_scene9_night_myroom_674bc70f:

    # Sonya "Стой . . . не двигайся"
    Sonya "Đứng yên . . . đừng cử động"

# game/characters_events_idles/sonya_events.rpy:1002
translate english sonya_scene9_night_myroom_dc365125:

    # Sonya "Я хочу сама"
    Sonya "Em muốn tự làm"

# game/characters_events_idles/sonya_events.rpy:1006
translate english sonya_scene9_night_myroom_9c274529:

    # gg "У меня отличный вид"
    gg "Anh có tầm nhìn tuyệt đẹp"

# game/characters_events_idles/sonya_events.rpy:1008
translate english sonya_scene9_night_myroom_4af82ab0:

    # Sonya "Я знаю"
    Sonya "Em biết"

# game/characters_events_idles/sonya_events.rpy:1010
translate english sonya_scene9_night_myroom_d339691d:

    # Sonya "Мне просто приятно, что ты смотришь"
    Sonya "Em chỉ thấy vui vì anh đang nhìn"

# game/characters_events_idles/sonya_events.rpy:1012
translate english sonya_scene9_night_myroom_98944675:

    # Sonya "Теперь ты меня"
    Sonya "Giờ đến lượt anh nhìn em"

# game/characters_events_idles/sonya_events.rpy:1016
translate english sonya_scene9_night_myroom_06da4938:

    # Sonya "Ты точно будешь пахнуть как я"
    Sonya "Chắc chắn anh sẽ có mùi giống em"

# game/characters_events_idles/sonya_events.rpy:1018
translate english sonya_scene9_night_myroom_aa254d79:

    # Sonya "Ты такой тёплый сейчас . . . мне это нравится"
    Sonya "Anh ấm quá . . . em thích điều đó"

# game/characters_events_idles/sonya_events.rpy:1020
translate english sonya_scene9_night_myroom_908db179:

    # Sonya "Пойдём спать вместе"
    Sonya "Mình đi ngủ cùng nhau nhé"

# game/characters_events_idles/sonya_events.rpy:1022
translate english sonya_scene9_night_myroom_e190b45e:

    # Sonya "Я не хочу сегодня одна"
    Sonya "Hôm nay em không muốn một mình"

# game/characters_events_idles/sonya_events.rpy:1024
translate english sonya_scene9_night_myroom_dd09f522:

    # Sonya "Но на сегодня приключений хватит . . . а то я завтра вообще не проснусь"
    Sonya "Nhưng hôm nay đủ phiêu lưu rồi . . . không thì mai em không dậy nổi mất"

# game/characters_events_idles/sonya_events.rpy:1031
translate english sonya_scene9_night_myroom_654cb5b3:

    # Sonya "Спокойной ночи"
    Sonya "Chúc ngủ ngon"

# game/characters_events_idles/sonya_events.rpy:1032
translate english sonya_scene9_night_myroom_5e65cbb1:

    # Sonya "{bt=a3-p2.0-s3.0}Любимый"
    Sonya "{bt=a3-p2.0-s3.0}Người yêu"

# game/characters_events_idles/sonya_events.rpy:1038
translate english sonya_scene9_night_myroom_7f924e87:

    # gg "Спокойной"
    gg "Chúc ngủ ngon"

# game/characters_events_idles/sonya_events.rpy:1039
translate english sonya_scene9_night_myroom_02749544:

    # gg "Я правда рад, что я с тобой"
    gg "Anh thật sự vui vì được ở bên em"


