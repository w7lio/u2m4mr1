﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/maya_events.rpy:24
translate english maya_scene1_evening_myroom_ef5d982a:

    # Maya "Да ты издеваешься"
    Maya "Cậu đang trêu tớ đấy à"

# game/characters_events_idles/maya_events.rpy:37
translate english maya_scene1_evening_myroom_905d33c0:

    # Maya "Где они блин"
    Maya "Chúng nó đâu rồi, trời ạ"

# game/characters_events_idles/maya_events.rpy:50
translate english maya_scene1_evening_myroom_bd666787:

    # Maya "Тьфу"
    Maya "Xì"

# game/characters_events_idles/maya_events.rpy:56
translate english maya_scene1_evening_myroom_481be515:

    # Maya "Чё смотришь?"
    Maya "Nhìn gì？"

# game/characters_events_idles/maya_events.rpy:57
translate english maya_scene1_evening_myroom_2ca818a6:

    # gg "Проверь плюс и минус"
    gg "Kiểm tra cực dương và cực âm đi"

# game/characters_events_idles/maya_events.rpy:58
translate english maya_scene1_evening_myroom_4bbab9f1:

    # Maya "Проверяла"
    Maya "Kiểm tra rồi"

# game/characters_events_idles/maya_events.rpy:94
translate english maya_scene2_day_mayaroom_5bb53a51:

    # Maya "Кто там?"
    Maya "Ai đó？"

# game/characters_events_idles/maya_events.rpy:96
translate english maya_scene2_day_mayaroom_14a18d19:

    # gg "Это я. Можно зайти по делу?"
    gg "Tớ đây. Vào có việc được không？"

# game/characters_events_idles/maya_events.rpy:97
translate english maya_scene2_day_mayaroom_1c4734b1:

    # Maya "Входи"
    Maya "Vào đi"

# game/characters_events_idles/maya_events.rpy:105
translate english maya_scene2_day_mayaroom_ab7fedad:

    # gg "Музыку слушаешь?"
    gg "Đang nghe nhạc à？"

# game/characters_events_idles/maya_events.rpy:107
translate english maya_scene2_day_mayaroom_3884c669:

    # Maya "Нет, для соседей включила"
    Maya "Không, bật cho hàng xóm nghe đấy"

# game/characters_events_idles/maya_events.rpy:111
translate english maya_scene2_day_mayaroom_837eef0f:

    # gg "Я решил, что останусь тут"
    gg "Tớ quyết định sẽ ở lại đây"

# game/characters_events_idles/maya_events.rpy:113
translate english maya_scene2_day_mayaroom_95020588:

    # gg "Буду жить здесь"
    gg "Tớ sẽ sống ở đây"

# game/characters_events_idles/maya_events.rpy:115
translate english maya_scene2_day_mayaroom_bca52f7e:

    # Maya "Ну"
    Maya "Ờ"

# game/characters_events_idles/maya_events.rpy:117
translate english maya_scene2_day_mayaroom_705e10f4:

    # Maya "Соболезную"
    Maya "Chia buồn"

# game/characters_events_idles/maya_events.rpy:125
translate english maya_scene2_day_mayaroom_27c60573:

    # Maya "Эй"
    Maya "Này"

# game/characters_events_idles/maya_events.rpy:127
translate english maya_scene2_day_mayaroom_40785e40:

    # Maya "Дальше не надо"
    Maya "Khỏi nói tiếp"

# game/characters_events_idles/maya_events.rpy:129
translate english maya_scene2_day_mayaroom_5f49e73a:

    # gg "Я просто хотел"
    gg "Tớ chỉ muốn"

# game/characters_events_idles/maya_events.rpy:131
translate english maya_scene2_day_mayaroom_16e0a365:

    # Maya "Я всё услышала"
    Maya "Tớ nghe hết rồi"

# game/characters_events_idles/maya_events.rpy:133
translate english maya_scene2_day_mayaroom_c48134de:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "Tớ chẳng quan tâm cậu sống ở đây"

# game/characters_events_idles/maya_events.rpy:135
translate english maya_scene2_day_mayaroom_df1954ea:

    # Maya "Честно"
    Maya "Thật đấy"

# game/characters_events_idles/maya_events.rpy:139
translate english maya_scene2_day_mayaroom_df3a4321:

    # Maya "Но давай без этого"
    Maya "Nhưng đừng có kiểu đó"

# game/characters_events_idles/maya_events.rpy:141
translate english maya_scene2_day_mayaroom_e6c85abf:

    # gg "Без чего?"
    gg "Kiểu gì？"

# game/characters_events_idles/maya_events.rpy:143
translate english maya_scene2_day_mayaroom_d4ddd213:

    # Maya "Без контроля"
    Maya "Đừng có kiểm soát"

# game/characters_events_idles/maya_events.rpy:145
translate english maya_scene2_day_mayaroom_bc54c15e:

    # Maya "Без «я помогу»"
    Maya "Đừng có kiểu “tớ sẽ giúp”"

# game/characters_events_idles/maya_events.rpy:147
translate english maya_scene2_day_mayaroom_7a220c2f:

    # gg "Я не про контроль"
    gg "Tớ không nói chuyện kiểm soát"

# game/characters_events_idles/maya_events.rpy:148
translate english maya_scene2_day_mayaroom_dabe88df:

    # gg "Если по дому что-то"
    gg "Nếu trong nhà có gì đó"

# game/characters_events_idles/maya_events.rpy:152
translate english maya_scene2_day_mayaroom_723b85d3:

    # Maya "Мне не нужна опека"
    Maya "Tớ không cần được chăm chút"

# game/characters_events_idles/maya_events.rpy:154
translate english maya_scene2_day_mayaroom_cad2c7d3:

    # gg "Я не это имел в виду"
    gg "Tớ không có ý đó"

# game/characters_events_idles/maya_events.rpy:156
translate english maya_scene2_day_mayaroom_e9decfdb:

    # Maya "А звучит именно так"
    Maya "Nhưng nghe cứ như thế"

# game/characters_events_idles/maya_events.rpy:158
translate english maya_scene2_day_mayaroom_c48134de_1:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "Tớ chẳng quan tâm cậu sống ở đây"

# game/characters_events_idles/maya_events.rpy:160
translate english maya_scene2_day_mayaroom_3e5d6dd4:

    # Maya "Просто"
    Maya "Chỉ là"

# game/characters_events_idles/maya_events.rpy:162
translate english maya_scene2_day_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "Đừng xen vào"

# game/characters_events_idles/maya_events.rpy:164
translate english maya_scene2_day_mayaroom_9727ea24:

    # Maya "В личное"
    Maya "Chuyện riêng"

# game/characters_events_idles/maya_events.rpy:166
translate english maya_scene2_day_mayaroom_44696bee:

    # gg "Я понял"
    gg "Tớ hiểu rồi"

# game/characters_events_idles/maya_events.rpy:168
translate english maya_scene2_day_mayaroom_97fa7b2b:

    # Maya "И дверь закрывай"
    Maya "Và đóng cửa lại"

# game/characters_events_idles/maya_events.rpy:170
translate english maya_scene2_day_mayaroom_367b11d8:

    # Maya "Я не фанат"
    Maya "Tớ không thích"

# game/characters_events_idles/maya_events.rpy:171
translate english maya_scene2_day_mayaroom_5e882c77:

    # Maya "Открытых пространств"
    Maya "Không gian mở"

# game/characters_events_idles/maya_events.rpy:198
translate english maya_scene3_evening_kitchen_9a8b0be2:

    # gg "Привет"
    gg "Chào cậu"

# game/characters_events_idles/maya_events.rpy:211
translate english maya_scene3_evening_kitchen_a356674e:

    # gg "Тебе еще кофе принести?"
    gg "Cậu có muốn tớ mang thêm cà phê không？"

# game/characters_events_idles/maya_events.rpy:213
translate english maya_scene3_evening_kitchen_9a5dd35b:

    # Maya "Нет"
    Maya "Không"

# game/characters_events_idles/maya_events.rpy:225
translate english maya_scene3_evening_kitchen_00c41c60:

    # Maya "Не . . ."
    Maya "Đừng . . ."

# game/characters_events_idles/maya_events.rpy:227
translate english maya_scene3_evening_kitchen_059eb6da:

    # gg "Что?"
    gg "Sao？"

# game/characters_events_idles/maya_events.rpy:229
translate english maya_scene3_evening_kitchen_5c02f51f:

    # Maya "Ты вообще"
    Maya "Cậu thật là"

# game/characters_events_idles/maya_events.rpy:231
translate english maya_scene3_evening_kitchen_c954c369:

    # Maya "Ты зачем так близко?"
    Maya "Sao cậu lại gần thế？"

# game/characters_events_idles/maya_events.rpy:233
translate english maya_scene3_evening_kitchen_7de3a2ef:

    # gg "Я просто"
    gg "Tớ chỉ"

# game/characters_events_idles/maya_events.rpy:235
translate english maya_scene3_evening_kitchen_25f0ffea:

    # Maya "Я сказала, не надо"
    Maya "Tớ đã nói là không cần"

# game/characters_events_idles/maya_events.rpy:237
translate english maya_scene3_evening_kitchen_91d73b20:

    # Maya "И не звала"
    Maya "Và tớ có gọi đâu"

# game/characters_events_idles/maya_events.rpy:241
translate english maya_scene3_evening_kitchen_e10a0eab:

    # Maya "Мне нужно было просто кофе"
    Maya "Tớ chỉ cần cà phê thôi"

# game/characters_events_idles/maya_events.rpy:243
translate english maya_scene3_evening_kitchen_a41fbef3:

    # gg "Подожди"
    gg "Đợi đã"

# game/characters_events_idles/maya_events.rpy:245
translate english maya_scene3_evening_kitchen_c8225194:

    # Maya "Не сейчас"
    Maya "Không phải bây giờ"

# game/characters_events_idles/maya_events.rpy:252
translate english maya_scene3_evening_kitchen_0d9a221f:

    # gg_chat "Как бы мне с ней поговорить"
    gg_chat "Làm sao để nói chuyện với cô ấy đây"

# game/characters_events_idles/maya_events.rpy:263
translate english maya_scene4_morning_mayaroom_d3734f64:

    # Maya "Да что ж"
    Maya "Trời ạ"

# game/characters_events_idles/maya_events.rpy:265
translate english maya_scene4_morning_mayaroom_fa8ea266:

    # Maya "Ну давай же"
    Maya "Thôi nào"

# game/characters_events_idles/maya_events.rpy:271
translate english maya_scene4_morning_mayaroom_d944481b:

    # gg "Опять воюешь с техникой?"
    gg "Lại chiến đấu với máy móc à？"

# game/characters_events_idles/maya_events.rpy:273
translate english maya_scene4_morning_mayaroom_b6f44dea:

    # Maya "Все работало час назад"
    Maya "Một tiếng trước còn chạy ổn"

# game/characters_events_idles/maya_events.rpy:275
translate english maya_scene4_morning_mayaroom_743f87c9:

    # gg "На вид, пауза — у меня была похожая проблема"
    gg "Nhìn như bị treo ấy — tớ từng gặp vấn đề tương tự"

# game/characters_events_idles/maya_events.rpy:277
translate english maya_scene4_morning_mayaroom_5b9f31c5:

    # Maya "Конечно. У нашего местного игромана, разумеется, был подобный опыт"
    Maya "Tất nhiên rồi. Gamer bản địa của chúng ta thì đương nhiên có kinh nghiệm kiểu đó"

# game/characters_events_idles/maya_events.rpy:279
translate english maya_scene4_morning_mayaroom_d67e684e:

    # gg "Это решается проще, чем кажется"
    gg "Cái này giải quyết dễ hơn tưởng"

# game/characters_events_idles/maya_events.rpy:281
translate english maya_scene4_morning_mayaroom_6ac6687a:

    # Maya "Я разберусь"
    Maya "Tớ tự lo được"

# game/characters_events_idles/maya_events.rpy:285
translate english maya_scene4_morning_mayaroom_ef21c62b:

    # Maya "Ладно поскольку ты уже встал тут в позу спасителя"
    Maya "Được rồi, vì cậu đã làm ra vẻ người cứu thế rồi"

# game/characters_events_idles/maya_events.rpy:287
translate english maya_scene4_morning_mayaroom_e4eef199:

    # Maya "Смотри"
    Maya "Xem đây"

# game/characters_events_idles/maya_events.rpy:289
translate english maya_scene4_morning_mayaroom_b05b1e64:

    # Maya "Но если сломаешь новый купишь"
    Maya "Nhưng nếu làm hỏng thì cậu mua cái mới"

# game/characters_events_idles/maya_events.rpy:291
translate english maya_scene4_morning_mayaroom_2406a76f:

    # gg_chat "Так посмотрим"
    gg_chat "Để xem nào"

# game/characters_events_idles/maya_events.rpy:293
translate english maya_scene4_morning_mayaroom_3eccec99:

    # Maya "Только давай без «я же говорил»"
    Maya "Chỉ là đừng có kiểu “tớ đã bảo rồi”"

# game/characters_events_idles/maya_events.rpy:295
translate english maya_scene4_morning_mayaroom_edca7a30:

    # gg "Хорошо Не собирался"
    gg "Được. Tớ không định thế"

# game/characters_events_idles/maya_events.rpy:300
translate english maya_scene4_morning_mayaroom_33712776:

    # Maya "Главное делай вид, что понимаешь"
    Maya "Quan trọng là cứ làm ra vẻ hiểu"

# game/characters_events_idles/maya_events.rpy:306
translate english maya_scene4_morning_mayaroom_726d3183:

    # Maya "Ты что сделал?"
    Maya "Cậu làm gì thế？"

# game/characters_events_idles/maya_events.rpy:309
translate english maya_scene4_morning_mayaroom_5de5e399:

    # Maya "Показывай"
    Maya "Cho xem đi"

# game/characters_events_idles/maya_events.rpy:311
translate english maya_scene4_morning_mayaroom_4572bfad:

    # Maya "Я уже готовлюсь к разочарованию"
    Maya "Tớ đang chuẩn bị tinh thần thất vọng rồi"

# game/characters_events_idles/maya_events.rpy:313
translate english maya_scene4_morning_mayaroom_6c571b22:

    # gg "Пока ничего критичного"
    gg "Chưa có gì nghiêm trọng"

# game/characters_events_idles/maya_events.rpy:315
translate english maya_scene4_morning_mayaroom_eab0c0bf:

    # Maya "Угу"
    Maya "Ừ"

# game/characters_events_idles/maya_events.rpy:319
translate english maya_scene4_morning_mayaroom_4506bcc5:

    # Maya "Эй!"
    Maya "Này!"

# game/characters_events_idles/maya_events.rpy:321
translate english maya_scene4_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "Dừng"

# game/characters_events_idles/maya_events.rpy:323
translate english maya_scene4_morning_mayaroom_5144b708:

    # gg "Что"
    gg "Gì？"

# game/characters_events_idles/maya_events.rpy:325
translate english maya_scene4_morning_mayaroom_cfa517d6:

    # Maya "Не надо ко мне лезть"
    Maya "Đừng có xen vào chuyện của tớ"

# game/characters_events_idles/maya_events.rpy:327
translate english maya_scene4_morning_mayaroom_1400ea9e:

    # gg "Ты сама"
    gg "Cậu tự"

# game/characters_events_idles/maya_events.rpy:329
translate english maya_scene4_morning_mayaroom_fd37247c:

    # Maya "Цыц"
    Maya "Suỵt"

# game/characters_events_idles/maya_events.rpy:333
translate english maya_scene4_morning_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "Kệ đi"

# game/characters_events_idles/maya_events.rpy:337
translate english maya_scene4_morning_mayaroom_d09026b0:

    # Maya "Уже не важно"
    Maya "Không quan trọng nữa"

# game/characters_events_idles/maya_events.rpy:339
translate english maya_scene4_morning_mayaroom_98444aa5:

    # Maya "Я разберусь потом"
    Maya "Tớ sẽ tự lo sau"

# game/characters_events_idles/maya_events.rpy:341
translate english maya_scene4_morning_mayaroom_d2acc454:

    # gg "Я же просто"
    gg "Tớ chỉ là"

# game/characters_events_idles/maya_events.rpy:343
translate english maya_scene4_morning_mayaroom_e0da4bdd:

    # Maya "Я сказала потом"
    Maya "Tớ đã nói là để sau"

# game/characters_events_idles/maya_events.rpy:349
translate english maya_scene4_morning_mayaroom_d821f777:

    # gg_chat "Нужно дать ей время"
    gg_chat "Cần cho cô ấy thời gian"

# game/characters_events_idles/maya_events.rpy:360
translate english maya_scene5_night_mayaroom_63a0d7ed:

    # gg "Я зайду"
    gg "Tớ vào nhé"

# game/characters_events_idles/maya_events.rpy:364
translate english maya_scene5_night_mayaroom_6c5edc69:

    # gg "Слушай . . ."
    gg "Nghe này . . ."

# game/characters_events_idles/maya_events.rpy:366
translate english maya_scene5_night_mayaroom_68ee26d9:

    # gg "Я хочу понять"
    gg "Tớ muốn hiểu"

# game/characters_events_idles/maya_events.rpy:368
translate english maya_scene5_night_mayaroom_bc1e3bb5:

    # gg "Ты всё время"
    gg "Cậu lúc nào cũng"

# game/characters_events_idles/maya_events.rpy:369
translate english maya_scene5_night_mayaroom_024d1c74:

    # gg "Отталкиваешь"
    gg "Đẩy tớ ra xa"

# game/characters_events_idles/maya_events.rpy:370
translate english maya_scene5_night_mayaroom_8f03bb39:

    # gg "Резко"
    gg "Một cách gay gắt"

# game/characters_events_idles/maya_events.rpy:372
translate english maya_scene5_night_mayaroom_e92f63ca:

    # gg "Я не всегда понимаю"
    gg "Tớ không phải lúc nào cũng hiểu"

# game/characters_events_idles/maya_events.rpy:373
translate english maya_scene5_night_mayaroom_fc49f049:

    # gg "Где именно граница"
    gg "Ranh giới chính xác ở đâu"

# game/characters_events_idles/maya_events.rpy:375
translate english maya_scene5_night_mayaroom_6d2d9756:

    # Maya "Да нигде"
    Maya "Chẳng ở đâu cả"

# game/characters_events_idles/maya_events.rpy:377
translate english maya_scene5_night_mayaroom_5c27dae4:

    # Maya "Хочешь границы -"
    Maya "Muốn ranh giới hả -"

# game/characters_events_idles/maya_events.rpy:378
translate english maya_scene5_night_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "Đừng xen vào"

# game/characters_events_idles/maya_events.rpy:379
translate english maya_scene5_night_mayaroom_71b4348e:

    # gg "Я не . . .{nw=0.3}"
    gg "Tớ không . . .{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:381
translate english maya_scene5_night_mayaroom_3a7c36e6:

    # Maya "Не надо"
    Maya "Đừng"

# game/characters_events_idles/maya_events.rpy:383
translate english maya_scene5_night_mayaroom_11f3acdb:

    # Maya "Не делай вид"
    Maya "Đừng làm ra vẻ"

# game/characters_events_idles/maya_events.rpy:384
translate english maya_scene5_night_mayaroom_e9a71e8d:

    # Maya "Что ты тут ни при чём"
    Maya "Như thể cậu không liên quan"

# game/characters_events_idles/maya_events.rpy:386
translate english maya_scene5_night_mayaroom_734313d9:

    # gg "Я не пытаюсь давить"
    gg "Tớ không cố gây áp lực"

# game/characters_events_idles/maya_events.rpy:387
translate english maya_scene5_night_mayaroom_e3709e94:

    # gg "Я просто . . .{nw=0.3}"
    gg "Tớ chỉ . . .{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:389
translate english maya_scene5_night_mayaroom_76c878d4:

    # Maya "Ты всегда «просто»"
    Maya "Cậu lúc nào cũng “chỉ là”"

# game/characters_events_idles/maya_events.rpy:391
translate english maya_scene5_night_mayaroom_7125aff8:

    # Maya "Просто заходишь"
    Maya "Chỉ là ghé vào"

# game/characters_events_idles/maya_events.rpy:392
translate english maya_scene5_night_mayaroom_8803de0c:

    # Maya "Просто начинаешь разговор"
    Maya "Chỉ là bắt chuyện"

# game/characters_events_idles/maya_events.rpy:394
translate english maya_scene5_night_mayaroom_30ca9380:

    # Maya "Просто помогаешь"
    Maya "Chỉ là giúp đỡ"

# game/characters_events_idles/maya_events.rpy:396
translate english maya_scene5_night_mayaroom_a04f159c:

    # Maya "{sc}Это бесит{/sc}"
    Maya "{sc}Thế mới bực mình{/sc}"

# game/characters_events_idles/maya_events.rpy:398
translate english maya_scene5_night_mayaroom_3a8f909d:

    # Maya "Всё"
    Maya "Thôi"

# game/characters_events_idles/maya_events.rpy:400
translate english maya_scene5_night_mayaroom_4d5d0603:

    # Maya "Разговор окончен"
    Maya "Cuộc nói chuyện kết thúc"

# game/characters_events_idles/maya_events.rpy:404
translate english maya_scene5_night_mayaroom_37d7c2ce:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Прости"
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Xin lỗi"

# game/characters_events_idles/maya_events.rpy:410
translate english maya_scene5_night_mayaroom_2336b49e:

    # Maya "Хотя нет"
    Maya "À không"

# game/characters_events_idles/maya_events.rpy:412
translate english maya_scene5_night_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "Kệ đi"

# game/characters_events_idles/maya_events.rpy:426
translate english maya_scene5_night_mayaroom_74fb972d:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Я . . ."
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Tớ . . ."

# game/characters_events_idles/maya_events.rpy:428
translate english maya_scene5_night_mayaroom_922caaa0:

    # Maya "Не это имела в виду"
    Maya "Không phải ý đó"

# game/characters_events_idles/maya_events.rpy:430
translate english maya_scene5_night_mayaroom_3a8f909d_1:

    # Maya "Всё"
    Maya "Thôi"

# game/characters_events_idles/maya_events.rpy:432
translate english maya_scene5_night_mayaroom_00c0f420:

    # Maya "Иди"
    Maya "Đi đi"

# game/characters_events_idles/maya_events.rpy:435
translate english maya_scene5_night_mayaroom_d0668ccb:

    # Maya "Я сказала — иди{nw=2}"
    Maya "Tớ đã nói rồi — đi đi{nw=2}"

# game/characters_events_idles/maya_events.rpy:463
translate english maya_scene6_evening_myroom_8846d5d4:

    # Maya "Ты сидишь будто"
    Maya "Cậu ngồi cứ như"

# game/characters_events_idles/maya_events.rpy:465
translate english maya_scene6_evening_myroom_c3936052:

    # Maya "Ничего не было"
    Maya "Chưa có chuyện gì xảy ra"

# game/characters_events_idles/maya_events.rpy:467
translate english maya_scene6_evening_myroom_ba188167:

    # gg "Я не делаю вид"
    gg "Tớ không làm ra vẻ"

# game/characters_events_idles/maya_events.rpy:469
translate english maya_scene6_evening_myroom_4dd50b6c:

    # Maya "Ладно, не важно"
    Maya "Được rồi, không quan trọng"

# game/characters_events_idles/maya_events.rpy:471
translate english maya_scene6_evening_myroom_7eaa97d1:

    # Maya "Залипай дальше"
    Maya "Cứ dán mắt tiếp đi"

# game/characters_events_idles/maya_events.rpy:479
translate english maya_scene6_evening_myroom_3c725bc9:

    # Maya "Слушай"
    Maya "Này"

# game/characters_events_idles/maya_events.rpy:480
translate english maya_scene6_evening_myroom_250ec1e3:

    # Maya "А ты сейчас сильно занят?"
    Maya "Cậu đang bận lắm không？"

# game/characters_events_idles/maya_events.rpy:482
translate english maya_scene6_evening_myroom_5ea33f12:

    # gg "Если честно — нет"
    gg "Thành thật mà nói — không"

# game/characters_events_idles/maya_events.rpy:486
translate english maya_scene6_evening_myroom_f9cfb58e:

    # Maya "Я просто спросила"
    Maya "Tớ chỉ hỏi thôi"

# game/characters_events_idles/maya_events.rpy:488
translate english maya_scene6_evening_myroom_70c7e32f:

    # gg "А я просто отвечаю"
    gg "Còn tớ chỉ trả lời"

# game/characters_events_idles/maya_events.rpy:489
translate english maya_scene6_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya ". . ."

# game/characters_events_idles/maya_events.rpy:491
translate english maya_scene6_evening_myroom_a2fcb33c:

    # Maya "Поможешь мне кое с чем"
    Maya "Giúp tớ một việc được không"

# game/characters_events_idles/maya_events.rpy:493
translate english maya_scene6_evening_myroom_19d648ec:

    # Maya "Это быстро"
    Maya "Nhanh thôi"

# game/characters_events_idles/maya_events.rpy:497
translate english maya_scene6_evening_myroom_9619af02:

    # gg "С чем?"
    gg "Việc gì？"

# game/characters_events_idles/maya_events.rpy:499
translate english maya_scene6_evening_myroom_0b3abc75:

    # Maya "Потом увидишь"
    Maya "Lát cậu sẽ thấy"

# game/characters_events_idles/maya_events.rpy:510
translate english maya_scene6_evening_myroom_5529e2cd:

    # Maya "Только без лишней заботы"
    Maya "Chỉ là đừng có chăm chút quá mức"

# game/characters_events_idles/maya_events.rpy:512
translate english maya_scene6_evening_myroom_52df9211:

    # gg "Как скажешь"
    gg "Cậu muốn sao cũng được"

# game/characters_events_idles/maya_events.rpy:514
translate english maya_scene6_evening_myroom_3226a25c:

    # Maya "Посмотрим на что ты способен"
    Maya "Để xem cậu có thể làm được gì"

# game/characters_events_idles/maya_events.rpy:516
translate english maya_scene6_evening_myroom_bca52f7e:

    # Maya "Ну"
    Maya "Nào"

# game/characters_events_idles/maya_events.rpy:518
translate english maya_scene6_evening_myroom_1771af09:

    # Maya "Вот"
    Maya "Đây"

# game/characters_events_idles/maya_events.rpy:520
translate english maya_scene6_evening_myroom_ba718844:

    # Maya "Что застыл"
    Maya "Sao đứng đờ ra thế"

# game/characters_events_idles/maya_events.rpy:522
translate english maya_scene6_evening_myroom_806872f9:

    # gg "О и давно у тебя это?"
    gg "Ồ, cậu bị cái này lâu chưa？"

# game/characters_events_idles/maya_events.rpy:524
translate english maya_scene6_evening_myroom_7d6ca25f:

    # Maya "Очень"
    Maya "Lâu lắm rồi"

# game/characters_events_idles/maya_events.rpy:525
translate english maya_scene6_evening_myroom_40562848:

    # Maya "Ещё когда я делала вид"
    Maya "Từ khi tớ còn làm ra vẻ"

# game/characters_events_idles/maya_events.rpy:527
translate english maya_scene6_evening_myroom_0b5a891a:

    # Maya "Что у меня есть дисциплина"
    Maya "Rằng tớ có kỷ luật"

# game/characters_events_idles/maya_events.rpy:529
translate english maya_scene6_evening_myroom_51392b4e:

    # gg "В смысле?"
    gg "Ý cậu là sao？"

# game/characters_events_idles/maya_events.rpy:531
translate english maya_scene6_evening_myroom_4a4b36f7:

    # Maya "Спорт"
    Maya "Thể thao"

# game/characters_events_idles/maya_events.rpy:533
translate english maya_scene6_evening_myroom_bec9192a:

    # Maya "Секции, график, «надо»"
    Maya "Lớp học, lịch trình, “phải làm”"

# game/characters_events_idles/maya_events.rpy:535
translate english maya_scene6_evening_myroom_201efa03:

    # Maya "Потом одна удачная травма"
    Maya "Rồi một lần chấn thương “may mắn”"

# game/characters_events_idles/maya_events.rpy:537
translate english maya_scene6_evening_myroom_c633060c:

    # Maya "И всё"
    Maya "Thế là hết"

# game/characters_events_idles/maya_events.rpy:539
translate english maya_scene6_evening_myroom_46291e24:

    # Maya "Цирк закрылся"
    Maya "Rạp xiếc đóng cửa"

# game/characters_events_idles/maya_events.rpy:541
translate english maya_scene6_evening_myroom_d39d8973:

    # gg "И ты бросила?"
    gg "Và cậu bỏ à？"

# game/characters_events_idles/maya_events.rpy:543
translate english maya_scene6_evening_myroom_9d7ad38f:

    # Maya "Я бы назвала это"
    Maya "Tớ sẽ gọi đó là"

# game/characters_events_idles/maya_events.rpy:545
translate english maya_scene6_evening_myroom_ceee3b55:

    # Maya "«Энергосберегающий режим»"
    Maya "“Chế độ tiết kiệm năng lượng”"

# game/characters_events_idles/maya_events.rpy:549
translate english maya_scene6_evening_myroom_9a044748:

    # gg "Теперь понятно почему ты так реагируешь"
    gg "Giờ thì hiểu vì sao cậu phản ứng thế rồi"

# game/characters_events_idles/maya_events.rpy:551
translate english maya_scene6_evening_myroom_5a3ffd6f:

    # Maya "Я просто не люблю"
    Maya "Tớ chỉ không thích"

# game/characters_events_idles/maya_events.rpy:552
translate english maya_scene6_evening_myroom_2b6fd943:

    # Maya "Когда кто-то начинает"
    Maya "Khi ai đó bắt đầu"

# game/characters_events_idles/maya_events.rpy:554
translate english maya_scene6_evening_myroom_8f57b276:

    # Maya "Объяснять мне как жить"
    Maya "Giảng cho tớ cách sống"

# game/characters_events_idles/maya_events.rpy:557
translate english maya_scene6_evening_myroom_55d8d51b:

    # Maya "Вообщем нужно нанести крем и забинтовать"
    Maya "Nói chung là cần bôi kem rồi băng lại"

# game/characters_events_idles/maya_events.rpy:559
translate english maya_scene6_evening_myroom_a23c1350:

    # gg "А к Соне почему не пошла?"
    gg "Sao không đến chỗ Sonya？"

# game/characters_events_idles/maya_events.rpy:561
translate english maya_scene6_evening_myroom_17ee92c5:

    # Maya "По той же причине, а еще"
    Maya "Vì lý do tương tự, và còn nữa"

# game/characters_events_idles/maya_events.rpy:562
translate english maya_scene6_evening_myroom_6a81a1e1:

    # Maya "Это всегда превращается"
    Maya "Nó lúc nào cũng biến thành"

# game/characters_events_idles/maya_events.rpy:564
translate english maya_scene6_evening_myroom_f5a6f373:

    # Maya "В «давай я»"
    Maya "Kiểu “để tớ”"

# game/characters_events_idles/maya_events.rpy:566
translate english maya_scene6_evening_myroom_5d26e27b:

    # Maya "Она начинает суетиться"
    Maya "Cô ấy bắt đầu cuống lên"

# game/characters_events_idles/maya_events.rpy:567
translate english maya_scene6_evening_myroom_c1824ee1:

    # Maya "Делать больше, чем надо"
    Maya "Làm quá mức cần thiết"

# game/characters_events_idles/maya_events.rpy:569
translate english maya_scene6_evening_myroom_9ad0074f:

    # Maya "А потом я виноватой себя чувствую"
    Maya "Rồi sau đó tớ thấy mình có lỗi"

# game/characters_events_idles/maya_events.rpy:571
translate english maya_scene6_evening_myroom_ae8589c0:

    # gg "Кажется это называется забота"
    gg "Hình như cái đó gọi là quan tâm"

# game/characters_events_idles/maya_events.rpy:573
translate english maya_scene6_evening_myroom_a240282b:

    # Maya "Тогда давай посмотрим на твою заботу"
    Maya "Vậy thì để xem cậu quan tâm thế nào"

# game/characters_events_idles/maya_events.rpy:575
translate english maya_scene6_evening_myroom_29c79ddd:

    # Maya "Надеюсь только без драм"
    Maya "Hy vọng là không có kịch tính"

# game/characters_events_idles/maya_events.rpy:577
translate english maya_scene6_evening_myroom_63c1dadc:

    # gg "Не собирался"
    gg "Tớ không định thế"

# game/characters_events_idles/maya_events.rpy:582
translate english maya_scene6_evening_myroom_41f1b09f:

    # gg "Можно?"
    gg "Được không？"

# game/characters_events_idles/maya_events.rpy:590
translate english maya_scene6_evening_myroom_43813c59:

    # Maya "Не бойся"
    Maya "Đừng sợ"

# game/characters_events_idles/maya_events.rpy:591
translate english maya_scene6_evening_myroom_d139c2b0:

    # Maya "Я не из хрусталя"
    Maya "Tớ đâu phải làm bằng pha lê"

# game/characters_events_idles/maya_events.rpy:594
translate english maya_scene6_evening_myroom_590f3ec6:

    # Maya "Ты всегда такой спокойный?"
    Maya "Cậu lúc nào cũng bình tĩnh thế à？"

# game/characters_events_idles/maya_events.rpy:595
translate english maya_scene6_evening_myroom_79f7b16f:

    # gg "Не всегда"
    gg "Không phải lúc nào"

# game/characters_events_idles/maya_events.rpy:597
translate english maya_scene6_evening_myroom_481c4421:

    # gg "Просто сейчас{w} нет смысла психовать"
    gg "Chỉ là bây giờ{w} không có lý do gì để phát điên"

# game/characters_events_idles/maya_events.rpy:599
translate english maya_scene6_evening_myroom_d38be043:

    # Maya "Понятно"
    Maya "Hiểu rồi"

# game/characters_events_idles/maya_events.rpy:600
translate english maya_scene6_evening_myroom_41f6003e:

    # Maya "Экономишь нервы"
    Maya "Tiết kiệm thần kinh nhỉ"

# game/characters_events_idles/maya_events.rpy:601
translate english maya_scene6_evening_myroom_9ea43bc7:

    # Maya "Умно"
    Maya "Khôn đấy"

# game/characters_events_idles/maya_events.rpy:603
translate english maya_scene6_evening_myroom_b413e8d5:

    # gg "Можно сказать и так"
    gg "Có thể nói thế cũng được"

# game/characters_events_idles/maya_events.rpy:606
translate english maya_scene6_evening_myroom_ea2de26b:

    # Maya "Теперь бинтуй"
    Maya "Giờ băng đi"

# game/characters_events_idles/maya_events.rpy:614
translate english maya_scene6_evening_myroom_69d52a38:

    # Maya "Левее"
    Maya "Sang trái chút"

# game/characters_events_idles/maya_events.rpy:618
translate english maya_scene6_evening_myroom_a9d70df9:

    # Maya "Нет{w} стой"
    Maya "Không{w} đứng lại"

# game/characters_events_idles/maya_events.rpy:620
translate english maya_scene6_evening_myroom_4b3bbffe:

    # Maya "Вот так"
    Maya "Đúng rồi"

# game/characters_events_idles/maya_events.rpy:624
translate english maya_scene6_evening_myroom_9ee64c2c:

    # Maya "Ты вообще смотришь, что делаешь?"
    Maya "Cậu có nhìn cái mình đang làm không đấy？"

# game/characters_events_idles/maya_events.rpy:626
translate english maya_scene6_evening_myroom_d39f0951:

    # gg "Мая"
    gg "Maya"

# game/characters_events_idles/maya_events.rpy:628
translate english maya_scene6_evening_myroom_4e31a75d:

    # Maya "Нет, серьёзно"
    Maya "Không, nghiêm túc đấy"

# game/characters_events_idles/maya_events.rpy:629
translate english maya_scene6_evening_myroom_6049c785:

    # Maya "Ты сейчас наугад это бинтуешь"
    Maya "Cậu đang băng bừa đấy à"

# game/characters_events_idles/maya_events.rpy:631
translate english maya_scene6_evening_myroom_7e1fd344:

    # Maya "Или делаешь вид"
    Maya "Hay là đang làm ra vẻ"

# game/characters_events_idles/maya_events.rpy:632
translate english maya_scene6_evening_myroom_84eb66b2:

    # Maya "Что уверен"
    Maya "Rằng mình chắc chắn"

# game/characters_events_idles/maya_events.rpy:637
translate english maya_scene6_evening_myroom_d39f0951_1:

    # gg "Мая"
    gg "Maya"

# game/characters_events_idles/maya_events.rpy:639
translate english maya_scene6_evening_myroom_9db87034:

    # gg "Если тебе так проще - я выйду"
    gg "Nếu cậu thấy vậy dễ hơn - tớ ra ngoài"

# game/characters_events_idles/maya_events.rpy:641
translate english maya_scene6_evening_myroom_eb8fc374:

    # Maya "Подожди"
    Maya "Đợi đã"

# game/characters_events_idles/maya_events.rpy:647
translate english maya_scene6_evening_myroom_43dc5209:

    # Maya "Я . . .{w} не это имела в виду"
    Maya "Tớ . . .{w} không phải ý đó"

# game/characters_events_idles/maya_events.rpy:649
translate english maya_scene6_evening_myroom_e89a435e:

    # Maya "Просто . . ."
    Maya "Chỉ là . . ."

# game/characters_events_idles/maya_events.rpy:651
translate english maya_scene6_evening_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "Đừng đi"

# game/characters_events_idles/maya_events.rpy:661
translate english maya_scene6_evening_myroom_0e9018a1:

    # gg "Иии"
    gg "Và…"

# game/characters_events_idles/maya_events.rpy:663
translate english maya_scene6_evening_myroom_15ebc100:

    # gg "Операция закончена"
    gg "Ca mổ kết thúc"

# game/characters_events_idles/maya_events.rpy:667
translate english maya_scene6_evening_myroom_1ceba70d:

    # Maya "Спасибо"
    Maya "Cảm ơn"

# game/characters_events_idles/maya_events.rpy:680
translate english maya_scene6_evening_myroom_6fdd6424:

    # Maya "Не привыкай"
    Maya "Đừng quen nhé"

# game/characters_events_idles/maya_events.rpy:683
translate english maya_scene6_evening_myroom_63c1dadc_1:

    # gg "Не собирался"
    gg "Tớ không định"

# game/characters_events_idles/maya_events.rpy:705
translate english maya_scene7_night_mayaroom_fec75b67:

    # gg "Ты до сих пор за ноутом?"
    gg "Cậu vẫn còn ngồi với laptop à？"

# game/characters_events_idles/maya_events.rpy:706
translate english maya_scene7_night_mayaroom_762dfc55:

    # gg "Уже за полночь"
    gg "Quá nửa đêm rồi"

# game/characters_events_idles/maya_events.rpy:708
translate english maya_scene7_night_mayaroom_0d6d9e7f:

    # Maya "И что?"
    Maya "Thì sao？"

# game/characters_events_idles/maya_events.rpy:709
translate english maya_scene7_night_mayaroom_f874de68:

    # Maya "У меня дела в отличие от некоторых"
    Maya "Tớ có việc, khác với vài người"

# game/characters_events_idles/maya_events.rpy:711
translate english maya_scene7_night_mayaroom_6b992d2b:

    # gg "Уже ночь"
    gg "Khuya rồi"

# game/characters_events_idles/maya_events.rpy:713
translate english maya_scene7_night_mayaroom_730b6969:

    # gg "А переписка это работа?"
    gg "Mà nhắn tin là công việc à？"

# game/characters_events_idles/maya_events.rpy:716
translate english maya_scene7_night_mayaroom_ca9eb87e:

    # Maya "Да мои дела"
    Maya "Đúng, việc của tớ"

# game/characters_events_idles/maya_events.rpy:718
translate english maya_scene7_night_mayaroom_e1a35225:

    # Maya "Вечно лезешь туда, куда не зовут"
    Maya "Lúc nào cũng xen vào chỗ không ai gọi"

# game/characters_events_idles/maya_events.rpy:720
translate english maya_scene7_night_mayaroom_54c856a0:

    # gg "А дверь открытая{w}, значит ждала"
    gg "Mà cửa mở{w}, nghĩa là cậu đợi"

# game/characters_events_idles/maya_events.rpy:722
translate english maya_scene7_night_mayaroom_5ebc71c5:

    # Maya "Ждала?"
    Maya "Đợi？"

# game/characters_events_idles/maya_events.rpy:724
translate english maya_scene7_night_mayaroom_ab53ee69:

    # Maya "Только если дурака, чтобы под руку мешался"
    Maya "Chỉ đợi thằng ngốc nào đó để vướng tay thôi"

# game/characters_events_idles/maya_events.rpy:725
translate english maya_scene7_night_mayaroom_e04cd055:

    # gg_chat "На вид она слишком устала для настоящей злости"
    gg_chat "Nhìn cô ấy có vẻ quá mệt để thực sự giận"

# game/characters_events_idles/maya_events.rpy:730
translate english maya_scene7_night_mayaroom_8876fd31:

    # Maya "ЭЭ"
    Maya "Này này"

# game/characters_events_idles/maya_events.rpy:733
translate english maya_scene7_night_mayaroom_588c8161:

    # Maya "Не смей! Это моё!" with hpunch
    Maya "Đừng có! Cái đó của tớ!" with hpunch

# game/characters_events_idles/maya_events.rpy:735
translate english maya_scene7_night_mayaroom_30b1c14e:

    # gg "Да я и не собирался читать"
    gg "Tớ có định đọc đâu"

# game/characters_events_idles/maya_events.rpy:736
translate english maya_scene7_night_mayaroom_4d7029b4:

    # gg "Просто . . . {w}ты могла бы не прятать"
    gg "Chỉ là . . . {w}cậu không cần phải giấu"

# game/characters_events_idles/maya_events.rpy:738
translate english maya_scene7_night_mayaroom_43898c08:

    # Maya "Потому что . . ."
    Maya "Bởi vì . . ."

# game/characters_events_idles/maya_events.rpy:740
translate english maya_scene7_night_mayaroom_7673a52d:

    # Maya "C тобой я . . ."
    Maya "Với cậu tớ . . ."

# game/characters_events_idles/maya_events.rpy:747
translate english maya_scene7_night_mayaroom_d57c47f7:

    # Maya ". . . "
    Maya ". . . "

# game/characters_events_idles/maya_events.rpy:748
translate english maya_scene7_night_mayaroom_8b57d927:

    # Maya ". . . {w}Я не своя . . ."
    Maya ". . . {w}Tớ không còn là chính mình . . ."

# game/characters_events_idles/maya_events.rpy:749
translate english maya_scene7_night_mayaroom_6f9409ff:

    # Maya "Я всё время о тебе думаю"
    Maya "Tớ lúc nào cũng nghĩ về cậu"

# game/characters_events_idles/maya_events.rpy:754
translate english maya_scene7_night_mayaroom_df75b7f4:

    # Maya "С тобой я только и делаю, что тупею!"
    Maya "Ở cạnh cậu tớ chỉ toàn trở nên ngốc nghếch!"

# game/characters_events_idles/maya_events.rpy:756
translate english maya_scene7_night_mayaroom_578ec278:

    # Maya "Вот и всё"
    Maya "Thế đấy"

# game/characters_events_idles/maya_events.rpy:761
translate english maya_scene7_night_mayaroom_b56e467a:

    # gg "Ты прячешься за словами, но глаза выдают всё"
    gg "Cậu trốn sau lời nói, nhưng ánh mắt thì tố cáo tất cả"

# game/characters_events_idles/maya_events.rpy:769
translate english maya_scene7_night_mayaroom_b0f630ba:

    # Maya "{size=*0.8}. . . Дурак . . .{/size}"
    Maya "{size=*0.8}. . . Đồ ngốc . . .{/size}"

# game/characters_events_idles/maya_events.rpy:770
translate english maya_scene7_night_mayaroom_8e74b6e2:

    # Maya "Если кому-то скажешь - я тебя прибью" with hpunch
    Maya "Nếu cậu nói với ai - tớ sẽ giết cậu" with hpunch

# game/characters_events_idles/maya_events.rpy:774
translate english maya_scene7_night_mayaroom_03506582:

    # gg "Угрожаешь после такого? {w}Смелая"
    gg "Sau chuyện đó mà còn đe dọa à？ {w}Gan đấy"

# game/characters_events_idles/maya_events.rpy:777
translate english maya_scene7_night_mayaroom_991c3acc:

    # gg "Никому {w}только между нами"
    gg "Không nói với ai {w}chỉ giữa chúng ta"

# game/characters_events_idles/maya_events.rpy:792
translate english maya_scene8_morning_mayaroom_3ccef67b:

    # gg_chat "Она выглядит . . . спокойно {w}Никакой злости {w} даже странно"
    gg_chat "Cô ấy trông . . . bình tĩnh {w}Không chút giận dữ {w}thậm chí lạ thật"

# game/characters_events_idles/maya_events.rpy:794
translate english maya_scene8_morning_mayaroom_8e119e79:

    # Maya "Ты чё . . . {w}уже встал?.."
    Maya "Cậu gì thế . . . {w}dậy rồi à？.."

# game/characters_events_idles/maya_events.rpy:796
translate english maya_scene8_morning_mayaroom_fb3f31cf:

    # gg "Эм . . . да. Я не хотел мешать. Просто заглянул"
    gg "Ừm . . . đúng. Tớ không muốn làm phiền. Chỉ ghé xem thôi"

# game/characters_events_idles/maya_events.rpy:798
translate english maya_scene8_morning_mayaroom_0a978bde:

    # Maya "Не уходи . . ."
    Maya "Đừng đi . . ."

# game/characters_events_idles/maya_events.rpy:800
translate english maya_scene8_morning_mayaroom_3a0bea4a:

    # Maya "Сядь"
    Maya "Ngồi đi"

# game/characters_events_idles/maya_events.rpy:805
translate english maya_scene8_morning_mayaroom_970fe7c6:

    # Maya "Спала ужасно . . ."
    Maya "Tớ ngủ dở tệ . . ."

# game/characters_events_idles/maya_events.rpy:807
translate english maya_scene8_morning_mayaroom_4ada6f49:

    # Maya "Всё крутилось в голове"
    Maya "Mọi thứ cứ quay cuồng trong đầu"

# game/characters_events_idles/maya_events.rpy:808
translate english maya_scene8_morning_mayaroom_ee85048c:

    # Maya "Не выспалась"
    Maya "Không ngủ đủ giấc"

# game/characters_events_idles/maya_events.rpy:810
translate english maya_scene8_morning_mayaroom_30004a57:

    # gg "А у тебя будто энергии с утра через край"
    gg "Mà trông cậu như tràn đầy năng lượng từ sáng ấy"

# game/characters_events_idles/maya_events.rpy:812
translate english maya_scene8_morning_mayaroom_c4e0d6af:

    # Maya "Очень смешно . . . "
    Maya "Buồn cười ghê . . . "

# game/characters_events_idles/maya_events.rpy:814
translate english maya_scene8_morning_mayaroom_c574ca14:

    # Maya "Я лентяйка {w}просто иногда притворяюсь"
    Maya "Tớ là đứa lười {w}chỉ là đôi khi giả vờ thôi"

# game/characters_events_idles/maya_events.rpy:816
translate english maya_scene8_morning_mayaroom_42c46aa1:

    # Maya "Ляг"
    Maya "Nằm đi"

# game/characters_events_idles/maya_events.rpy:817
translate english maya_scene8_morning_mayaroom_9e620d29:

    # Maya "Просто . . . {w}чтоб теплее было"
    Maya "Chỉ là . . . {w}để ấm hơn"

# game/characters_events_idles/maya_events.rpy:821
translate english maya_scene8_morning_mayaroom_d012bf21:

    # gg "Ты не заболела случайно?"
    gg "Cậu không bị ốm đấy chứ？"

# game/characters_events_idles/maya_events.rpy:824
translate english maya_scene8_morning_mayaroom_06609c2f:

    # Maya "Убью, если кому-то расскажешь"
    Maya "Tớ sẽ giết cậu nếu cậu kể với ai"

# game/characters_events_idles/maya_events.rpy:827
translate english maya_scene8_morning_mayaroom_aed6c2f3:

    # gg_chat "Может это мой шанс . . ."
    gg_chat "Có lẽ đây là cơ hội của mình . . ."

# game/characters_events_idles/maya_events.rpy:833
translate english maya_scene8_morning_mayaroom_7f5f7cbf:

    # Maya "Дурак . . ."
    Maya "Đồ ngốc . . ."

# game/characters_events_idles/maya_events.rpy:837
translate english maya_scene8_morning_mayaroom_f7f3b708:

    # gg_chat "Слишком спокойно . . ."
    gg_chat "Bình tĩnh quá mức . . ."

# game/characters_events_idles/maya_events.rpy:838
translate english maya_scene8_morning_mayaroom_fc2580e2:

    # gg_chat "Значит, самое время тихо уйти"
    gg_chat "Vậy thì đã đến lúc lặng lẽ rời đi"

# game/characters_events_idles/maya_events.rpy:841
translate english maya_scene8_morning_mayaroom_4b32219f:

    # gg_chat "Никогда бы не подумал, что первый поцелуй с ней будет таким"
    gg_chat "Chưa từng nghĩ nụ hôn đầu với cô ấy sẽ như thế này"

# game/characters_events_idles/maya_events.rpy:845
translate english maya_scene8_morning_mayaroom_31bdebc7:

    # gg_chat "Вот бы всегда так . . ."
    gg_chat "Ước gì lúc nào cũng được thế này . . ."

# game/characters_events_idles/maya_events.rpy:846
translate english maya_scene8_morning_mayaroom_7d3e081f:

    # gg_chat "Но, зная её, лучше не задерживаться"
    gg_chat "Nhưng biết cô ấy thì tốt hơn là đừng nán lại"

# game/characters_events_idles/maya_events.rpy:851
translate english maya_scene8_morning_mayaroom_f57b1e37:

    # gg_chat "Мягкость её груди всё ещё чувствовалась . . ."
    gg_chat "Cảm giác mềm mại nơi ngực cô ấy vẫn còn đọng lại . . ."

# game/characters_events_idles/maya_events.rpy:852
translate english maya_scene8_morning_mayaroom_ba3923be:

    # gg_chat "И отпускать не хотелось"
    gg_chat "Và tớ không muốn buông ra"

# game/characters_events_idles/maya_events.rpy:872
translate english maya_scene9_day_kitchen_b483553f:

    # Maya "О ты тут, помоги посыпать соль"
    Maya "Ồ cậu ở đây à, giúp rắc muối đi"

# game/characters_events_idles/maya_events.rpy:874
translate english maya_scene9_day_kitchen_564e6225:

    # gg "Окей"
    gg "Được"

# game/characters_events_idles/maya_events.rpy:877
translate english maya_scene9_day_kitchen_7d928982:

    # Maya "И аккуратней, а то пересолишь"
    Maya "Và cẩn thận đấy, không thì mặn quá"

# game/characters_events_idles/maya_events.rpy:887
translate english maya_scene9_day_kitchen_29721060:

    # Maya "Так . . . {w}вот теперь оно прилипло к сковородке"
    Maya "Được rồi . . . {w}giờ thì nó dính vào chảo rồi"

# game/characters_events_idles/maya_events.rpy:888
translate english maya_scene9_day_kitchen_11cbabe0:

    # Maya "Прям не оторвать"
    Maya "Gần như không gỡ ra được"

# game/characters_events_idles/maya_events.rpy:889
translate english maya_scene9_day_kitchen_927dfd8a:

    # gg "Тогда надо поддеть снизу, чтобы не пригорело"
    gg "Vậy phải luồn từ dưới lên để khỏi bị cháy"

# game/characters_events_idles/maya_events.rpy:892
translate english maya_scene9_day_kitchen_b2073f58:

    # Maya "Главное - не давить слишком резко"
    Maya "Quan trọng là đừng ấn quá mạnh"

# game/characters_events_idles/maya_events.rpy:893
translate english maya_scene9_day_kitchen_e7cb36e7:

    # Maya "Иначе желток лопнет"
    Maya "Không thì lòng đỏ sẽ vỡ"

# game/characters_events_idles/maya_events.rpy:894
translate english maya_scene9_day_kitchen_23aa5a43:

    # gg "Но если аккуратно, всё останется целым"
    gg "Nhưng nếu nhẹ nhàng, mọi thứ sẽ còn nguyên"

# game/characters_events_idles/maya_events.rpy:895
translate english maya_scene9_day_kitchen_0c33c9a7:

    # Maya "Угу . . . {w}мягче перемешивай"
    Maya "Ừ . . . {w}trộn nhẹ hơn"

# game/characters_events_idles/maya_events.rpy:896
translate english maya_scene9_day_kitchen_7c4d7305:

    # Maya "Тогда всё прожарится равномерно"
    Maya "Vậy thì mọi thứ sẽ chín đều"

# game/characters_events_idles/maya_events.rpy:899
translate english maya_scene9_day_kitchen_b067ff5d:

    # Maya "Всё, почти готово . . ."
    Maya "Được rồi, gần xong . . ."

# game/characters_events_idles/maya_events.rpy:900
translate english maya_scene9_day_kitchen_5805bb78:

    # Maya "Ещё чуть-чуть, и можно снимать с огня"
    Maya "Một chút nữa là có thể bắc xuống"

# game/characters_events_idles/maya_events.rpy:901
translate english maya_scene9_day_kitchen_c61ed5a8:

    # gg "Думаю, будет очень вкусно"
    gg "Tớ nghĩ sẽ ngon lắm"

# game/characters_events_idles/maya_events.rpy:905
translate english maya_scene9_day_kitchen_152dc2f3:

    # Maya "Всё {w}a то сейчас пережарим"
    Maya "Thôi {w}không thì chín quá mất"

# game/characters_events_idles/maya_events.rpy:907
translate english maya_scene9_day_kitchen_d98d84da:

    # Maya "Дальше сам себе готовь"
    Maya "Sau đó tự nấu cho mình đi"

# game/characters_events_idles/maya_events.rpy:909
translate english maya_scene9_day_kitchen_c00c68f7:

    # gg_chat "Она подыгрывала"
    gg_chat "Cô ấy đã phối hợp đùa theo"

# game/characters_events_idles/maya_events.rpy:910
translate english maya_scene9_day_kitchen_8e86ab7e:

    # gg_chat "Но в конце всё равно сбежала . . ."
    gg_chat "Nhưng cuối cùng cô ấy vẫn chạy mất . . ."

# game/characters_events_idles/maya_events.rpy:928
translate english maya_scene10_evening_myroom_b792031e:

    # Maya "Я дома"
    Maya "Tớ về rồi"

# game/characters_events_idles/maya_events.rpy:930
translate english maya_scene10_evening_myroom_4c632d43:

    # Maya "О, ты тут"
    Maya "Ồ, cậu ở đây"

# game/characters_events_idles/maya_events.rpy:932
translate english maya_scene10_evening_myroom_e37dbd39:

    # gg "Привет. Как работа?"
    gg "Chào. Công việc thế nào？"

# game/characters_events_idles/maya_events.rpy:934
translate english maya_scene10_evening_myroom_92ca482a:

    # Maya "Словно вечность. Эта долбаные люди"
    Maya "Như cả một thế kỷ. Lũ người chết tiệt ấy"

# game/characters_events_idles/maya_events.rpy:936
translate english maya_scene10_evening_myroom_d1b85968:

    # gg "Хочешь чай? Или просто вырубиться?"
    gg "Muốn uống trà không？ Hay chỉ muốn gục luôn？"

# game/characters_events_idles/maya_events.rpy:938
translate english maya_scene10_evening_myroom_a28c5657:

    # Maya "Чай?{w} Ты решил внезапно заботиться?"
    Maya "Trà à？{w} Tự nhiên cậu quyết định quan tâm đấy à？"

# game/characters_events_idles/maya_events.rpy:940
translate english maya_scene10_evening_myroom_ffaaaddc:

    # Maya "Ладно . . . да, пожалуй. И два сахара"
    Maya "Được rồi . . . ừ, chắc vậy. Và hai viên đường"

# game/characters_events_idles/maya_events.rpy:944
translate english maya_scene10_evening_myroom_fc470a50:

    # Maya "Уфф устала"
    Maya "Phù, mệt quá"

# game/characters_events_idles/maya_events.rpy:946
translate english maya_scene10_evening_myroom_d751ae58:

    # gg "Может, поговорим?"
    gg "Hay là mình nói chuyện nhé？"

# game/characters_events_idles/maya_events.rpy:948
translate english maya_scene10_evening_myroom_dd61a1d4:

    # Maya "О чём?"
    Maya "Về cái gì？"

# game/characters_events_idles/maya_events.rpy:950
translate english maya_scene10_evening_myroom_cb7be281:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Уволь"
    Maya "Về việc tớ lại bỏ dọn dẹp à？{w} {bt=a3-p2.0-s3.0}Thôi đi"

# game/characters_events_idles/maya_events.rpy:952
translate english maya_scene10_evening_myroom_49e84409:

    # gg "Необязательно. Можно просто помолчать"
    gg "Không cần đâu. Có thể chỉ im lặng thôi"

# game/characters_events_idles/maya_events.rpy:954
translate english maya_scene10_evening_myroom_963962a9:

    # Maya "Ты странный. Сидишь тут . . . как будто ждёшь чего-то"
    Maya "Cậu lạ thật. Ngồi đây . . . cứ như đang đợi gì đó"

# game/characters_events_idles/maya_events.rpy:958
translate english maya_scene10_evening_myroom_31f86790:

    # gg "Может, и жду"
    gg "Có lẽ đang đợi thật"

# game/characters_events_idles/maya_events.rpy:960
translate english maya_scene10_evening_myroom_7f342626:

    # Maya "Ты же знаешь, что я . . . колючая"
    Maya "Cậu biết mà, tớ . . . gai góc"

# game/characters_events_idles/maya_events.rpy:962
translate english maya_scene10_evening_myroom_27989031:

    # gg "Знаю"
    gg "Tớ biết"

# game/characters_events_idles/maya_events.rpy:964
translate english maya_scene10_evening_myroom_91a19161:

    # Maya "И что я всё испорчу"
    Maya "Và rằng tớ sẽ làm hỏng mọi thứ"

# game/characters_events_idles/maya_events.rpy:966
translate english maya_scene10_evening_myroom_d6704538:

    # Maya "Обязательно ляпну какую-нибудь чушь"
    Maya "Thế nào cũng buột miệng nói mấy câu vớ vẩn"

# game/characters_events_idles/maya_events.rpy:968
translate english maya_scene10_evening_myroom_489ce109:

    # gg "{bt=a3-p2.0-s3.0}{size=*0.8}Привык уже"
    gg "{bt=a3-p2.0-s3.0}{size=*0.8}Quen rồi"

# game/characters_events_idles/maya_events.rpy:974
translate english maya_scene10_evening_myroom_c0ac8816:

    # Maya "Ну конечно. Самое время для этого"
    Maya "Tất nhiên rồi. Đúng lúc lắm"

# game/characters_events_idles/maya_events.rpy:976
translate english maya_scene10_evening_myroom_ec57c0d1:

    # gg "Май . . ."
    gg "Maya . . ."

# game/characters_events_idles/maya_events.rpy:978
translate english maya_scene10_evening_myroom_16a831f4:

    # Maya "Заткнись"
    Maya "Im đi"

# game/characters_events_idles/maya_events.rpy:980
translate english maya_scene10_evening_myroom_71044ba9:

    # Maya "Просто . . . заткнись"
    Maya "Chỉ là . . . im đi"

# game/characters_events_idles/maya_events.rpy:990
translate english maya_scene10_evening_myroom_742929c8:

    # Maya "Тише . . . Осторожно. Я не . . .{w} Я не готова ко всему сразу"
    Maya "Nhẹ thôi . . . Cẩn thận. Tớ không . . .{w} Tớ chưa sẵn sàng cho mọi thứ cùng lúc"

# game/characters_events_idles/maya_events.rpy:996
translate english maya_scene10_evening_myroom_66b26945:

    # Maya "Ох . . . боже . . ."
    Maya "Ôi . . . trời ơi . . ."

# game/characters_events_idles/maya_events.rpy:1008
translate english maya_scene10_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya ". . ."

# game/characters_events_idles/maya_events.rpy:1010
translate english maya_scene10_evening_myroom_71253d69:

    # Maya "Вот это да . . ."
    Maya "Chà . . ."

# game/characters_events_idles/maya_events.rpy:1012
translate english maya_scene10_evening_myroom_22f5a5a6:

    # Maya "Ты это . . . там всё время носил?"
    Maya "Cậu . . . lúc nào cũng mang cái đó ở đó à？"

# game/characters_events_idles/maya_events.rpy:1018
translate english maya_scene10_evening_myroom_c014a37d:

    # Maya "Нет . . ."
    Maya "Không . . ."

# game/characters_events_idles/maya_events.rpy:1020
translate english maya_scene10_evening_myroom_2d2f095f:

    # Maya "Нет, стоп"
    Maya "Không, dừng lại"

# game/characters_events_idles/maya_events.rpy:1022
translate english maya_scene10_evening_myroom_6b00b07b:

    # Maya "Стоп, блядь"
    Maya "Dừng lại, mẹ kiếp"

# game/characters_events_idles/maya_events.rpy:1024
translate english maya_scene10_evening_myroom_f3f9fdab:

    # gg "Майя?"
    gg "Maya？"

# game/characters_events_idles/maya_events.rpy:1026
translate english maya_scene10_evening_myroom_b9eafd1f:

    # Maya "Выйди. Пожалуйста.{w} Просто . . . выйди"
    Maya "Ra ngoài đi. Làm ơn.{w} Chỉ là . . . ra ngoài"

# game/characters_events_idles/maya_events.rpy:1028
translate english maya_scene10_evening_myroom_92d5f1bf:

    # gg "Я . . .{w} Я не хотел . . ."
    gg "Tớ . . .{w} Tớ không muốn . . ."

# game/characters_events_idles/maya_events.rpy:1030
translate english maya_scene10_evening_myroom_e6bbb658:

    # Maya "{sc}{size=*1.2}Я ЗНАЮ{/size}{/sc}, что не хотел!"
    Maya "{sc}{size=*1.2}TỚ BIẾT{/size}{/sc}, rằng cậu không muốn!"

# game/characters_events_idles/maya_events.rpy:1032
translate english maya_scene10_evening_myroom_9ef6f711:

    # Maya "Именно поэтому — ВЫЙДИ!"
    Maya "Chính vì thế — RA NGOÀI!"

# game/characters_events_idles/maya_events.rpy:1034
translate english maya_scene10_evening_myroom_85e3ca37:

    # Maya "Не сейчас . . .{w} Я не могу{w} Это слишком . . . реально"
    Maya "Không phải bây giờ . . .{w} Tớ không thể{w} Chuyện này quá . . . thật"

# game/characters_events_idles/maya_events.rpy:1036
translate english maya_scene10_evening_myroom_a4abe766:

    # gg "Хорошо. Я . . .{w} Я ушёл"
    gg "Được. Tớ . . .{w} Tớ đi đây"

# game/characters_events_idles/maya_events.rpy:1040
translate english maya_scene10_evening_myroom_8454737d:

    # Maya "{size=*0.8}Чёрт . . . Чёрт . . . Чёрт . . ."
    Maya "{size=*0.8}Chết tiệt . . . Chết tiệt . . . Chết tiệt . . ."

# game/characters_events_idles/maya_events.rpy:1041
translate english maya_scene10_evening_myroom_c2f04aea:

    # Maya "{size=*0.8}Он такой . . . большой . . ."
    Maya "{size=*0.8}Của cậu ấy thật . . . to . . ."

# game/characters_events_idles/maya_events.rpy:1043
translate english maya_scene10_evening_myroom_828ad43f:

    # Maya "{size=*0.8}И мне . . ."
    Maya "{size=*0.8}Và tớ . . ."

# game/characters_events_idles/maya_events.rpy:1044
translate english maya_scene10_evening_myroom_b4c5d69e:

    # Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Понравилось"
    Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Thấy thích"

# game/characters_events_idles/maya_events.rpy:1061
translate english maya_scene11_morning_bathroom_bd1a48b9:

    # gg "Ты с утра за стиркой"
    gg "Cậu giặt giũ từ sáng à"

# game/characters_events_idles/maya_events.rpy:1062
translate english maya_scene11_morning_bathroom_17ad5908:

    # gg "Это что то мифическое"
    gg "Chuyện này đúng là thần thoại"

# game/characters_events_idles/maya_events.rpy:1064
translate english maya_scene11_morning_bathroom_2998d6f9:

    # Maya "Миф"
    Maya "Thần thoại"

# game/characters_events_idles/maya_events.rpy:1066
translate english maya_scene11_morning_bathroom_fa12fc4b:

    # Maya "Это если бы ты сам что-то постирал"
    Maya "Đó là nếu cậu tự giặt cái gì đó"

# game/characters_events_idles/maya_events.rpy:1071
translate english maya_scene11_morning_bathroom_10404fc0:

    # gg "Я хотя бы свои вещи складываю"
    gg "Ít nhất tớ còn gấp đồ của mình"

# game/characters_events_idles/maya_events.rpy:1073
translate english maya_scene11_morning_bathroom_cfff324a:

    # gg "А твои валялись по всей комнате"
    gg "Còn đồ của cậu vương khắp phòng"

# game/characters_events_idles/maya_events.rpy:1075
translate english maya_scene11_morning_bathroom_67c05e6d:

    # Maya "И кто же их собрал? Не ты"
    Maya "Thế ai nhặt chúng？ Không phải cậu"

# game/characters_events_idles/maya_events.rpy:1077
translate english maya_scene11_morning_bathroom_b4e5e9ee:

    # gg "Ещё чуть-чуть, и я подумаю, что ты скрытая трудяга"
    gg "Thêm chút nữa là tớ nghĩ cậu là người chăm chỉ thầm kín đấy"

# game/characters_events_idles/maya_events.rpy:1079
translate english maya_scene11_morning_bathroom_4907bae2:

    # Maya "Чего говоришь!"
    Maya "Cậu nói gì thế!"

# game/characters_events_idles/maya_events.rpy:1081
translate english maya_scene11_morning_bathroom_eaaef249:

    # Maya "Думаешь я настолько лентяйка?"
    Maya "Cậu nghĩ tớ lười đến thế à？"

# game/characters_events_idles/maya_events.rpy:1083
translate english maya_scene11_morning_bathroom_062411d1:

    # gg "Думаю"
    gg "Tớ nghĩ thế"

# game/characters_events_idles/maya_events.rpy:1088
translate english maya_scene11_morning_bathroom_b708dc2c:

    # gg "Ты кое что забыла поставить на стирку"
    gg "Cậu quên cho thứ gì đó vào máy giặt rồi"

# game/characters_events_idles/maya_events.rpy:1096
translate english maya_scene11_morning_bathroom_8c8070f2:

    # Maya "Ах так?"
    Maya "À, thế à？"

# game/characters_events_idles/maya_events.rpy:1098
translate english maya_scene11_morning_bathroom_cb35be97:

    # Maya "Тогда стираем всё"
    Maya "Vậy thì giặt hết"

# game/characters_events_idles/maya_events.rpy:1104
translate english maya_scene11_morning_bathroom_cf4d3425:

    # Maya "Ага . . ."
    Maya "Ừ nhỉ . . ."

# game/characters_events_idles/maya_events.rpy:1106
translate english maya_scene11_morning_bathroom_fa661e9f:

    # Maya "Похоже ЭТО нужно будет стирать деликатно"
    Maya "Có vẻ CÁI NÀY phải giặt nhẹ"

# game/characters_events_idles/maya_events.rpy:1108
translate english maya_scene11_morning_bathroom_9cd0adf2:

    # Maya "Думаю мы можем продолжить на чем закончили?"
    Maya "Tớ nghĩ mình có thể tiếp tục chỗ đã dừng？"

# game/characters_events_idles/maya_events.rpy:1112
translate english maya_scene11_morning_bathroom_84b09d0d:

    # Maya "Стиралка работает . . . {w}но тут жарче, чем должно быть"
    Maya "Máy giặt đang chạy . . . {w}nhưng ở đây nóng hơn mức cần thiết"

# game/characters_events_idles/maya_events.rpy:1113
translate english maya_scene11_morning_bathroom_6df3a5e2:

    # gg "Главное - достирай до конца"
    gg "Quan trọng là giặt đến cùng"

# game/characters_events_idles/maya_events.rpy:1114
translate english maya_scene11_morning_bathroom_d0b88dcb:

    # gg "Если оставишь придется домывать . . ."
    gg "Nếu bỏ dở sẽ phải giặt nốt . . ."

# game/characters_events_idles/maya_events.rpy:1119
translate english maya_scene11_morning_bathroom_0467b855:

    # Maya "Так я думаю стиралка сама справится"
    Maya "Tớ nghĩ máy giặt tự lo được"

# game/characters_events_idles/maya_events.rpy:1122
translate english maya_scene11_morning_bathroom_542d4b95:

    # Maya "А ты . . . {w}сам достирай свое"
    Maya "Còn cậu . . . {w}tự giặt nốt đồ của cậu đi"

# game/characters_events_idles/maya_events.rpy:1123
translate english maya_scene11_morning_bathroom_83b51400:

    # Maya "Белье . . ."
    Maya "Đồ lót . . ."

# game/characters_events_idles/maya_events.rpy:1129
translate english maya_scene11_morning_bathroom_eb975221:

    # gg_chat "Она ушла . . ."
    gg_chat "Cô ấy đi rồi . . ."

# game/characters_events_idles/maya_events.rpy:1130
translate english maya_scene11_morning_bathroom_3188cfc5:

    # gg_chat "В следующий раз ее нельзя отпускать . . ."
    gg_chat "Lần sau không thể để cô ấy đi . . ."

# game/characters_events_idles/maya_events.rpy:1147
translate english maya_scene12_evening_myroom_bb653a62:

    # Maya "Ха, так вот где ты спрятался"
    Maya "Ha, thì ra cậu trốn ở đây"

# game/characters_events_idles/maya_events.rpy:1149
translate english maya_scene12_evening_myroom_4ca35500:

    # Maya "И что ты смотришь?"
    Maya "Và cậu đang xem gì？"

# game/characters_events_idles/maya_events.rpy:1151
translate english maya_scene12_evening_myroom_7e8ca4c6:

    # gg "Подожди я в матче"
    gg "Đợi đã, tớ đang trong trận"

# game/characters_events_idles/maya_events.rpy:1152
translate english maya_scene12_evening_myroom_5ed608a5:

    # gg "Если отвлекусь - проиграю"
    gg "Nếu mất tập trung - tớ sẽ thua"

# game/characters_events_idles/maya_events.rpy:1154
translate english maya_scene12_evening_myroom_8f98104b:

    # Maya "И это, по-твоему, веселье?"
    Maya "Và cậu nghĩ đó là vui à？"

# game/characters_events_idles/maya_events.rpy:1156
translate english maya_scene12_evening_myroom_336dd03a:

    # gg "Когда сам играешь намного веселее . . ."
    gg "Khi tự chơi thì vui hơn nhiều . . ."

# game/characters_events_idles/maya_events.rpy:1158
translate english maya_scene12_evening_myroom_3a2af852:

    # Maya "А по мне, как будто трата времени"
    Maya "Còn tớ thấy cứ như phí thời gian"

# game/characters_events_idles/maya_events.rpy:1160
translate english maya_scene12_evening_myroom_814660f9:

    # gg "Эй!" with hpunch
    gg "Này!" with hpunch

# game/characters_events_idles/maya_events.rpy:1161
translate english maya_scene12_evening_myroom_a589a29a:

    # gg "Я ничего не вижу!"
    gg "Tớ chẳng thấy gì cả!"

# game/characters_events_idles/maya_events.rpy:1162
translate english maya_scene12_evening_myroom_6d7f26d1:

    # Maya "Ну и что?"
    Maya "Thì sao？"

# game/characters_events_idles/maya_events.rpy:1164
translate english maya_scene12_evening_myroom_8bb854aa:

    # Maya "Почему перестал играть?"
    Maya "Sao lại ngừng chơi？"

# game/characters_events_idles/maya_events.rpy:1166
translate english maya_scene12_evening_myroom_9c0bce5d:

    # gg "Я же сказал"
    gg "Tớ nói rồi mà"

# game/characters_events_idles/maya_events.rpy:1168
translate english maya_scene12_evening_myroom_4430c970:

    # gg "Теперь только тебя и вижу"
    gg "Giờ tớ chỉ thấy mỗi cậu"

# game/characters_events_idles/maya_events.rpy:1170
translate english maya_scene12_evening_myroom_e1ca96ab:

    # Maya "Вот и отлично!"
    Maya "Tốt quá rồi!"

# game/characters_events_idles/maya_events.rpy:1172
translate english maya_scene12_evening_myroom_e638502a:

    # Maya "Я теперь главный игрок"
    Maya "Giờ tớ là người chơi chính"

# game/characters_events_idles/maya_events.rpy:1174
translate english maya_scene12_evening_myroom_1751458f:

    # gg "Ты щас мне рейтинг сольешь"
    gg "Cậu sẽ làm tớ rớt rank mất"

# game/characters_events_idles/maya_events.rpy:1176
translate english maya_scene12_evening_myroom_ce7e136c:

    # Maya "Да ну, я просто проверяю"
    Maya "Thôi nào, tớ chỉ đang thử"

# game/characters_events_idles/maya_events.rpy:1178
translate english maya_scene12_evening_myroom_81a51f30:

    # Maya "Как тут . . . прыгает!"
    Maya "Cái này . . . nhảy kiểu gì thế!"

# game/characters_events_idles/maya_events.rpy:1180
translate english maya_scene12_evening_myroom_c46a67aa:

    # Maya "Ой, а это что делает?"
    Maya "Ôi, còn cái này làm gì？"

# game/characters_events_idles/maya_events.rpy:1181
translate english maya_scene12_evening_myroom_9260e289:

    # gg "Стой, не так"
    gg "Dừng, không phải thế"

# game/characters_events_idles/maya_events.rpy:1183
translate english maya_scene12_evening_myroom_16a342c4:

    # gg "Вот эта - стрелять, эта - использовать"
    gg "Cái này - bắn, cái này - sử dụng"

# game/characters_events_idles/maya_events.rpy:1185
translate english maya_scene12_evening_myroom_c634457f:

    # gg "Держи крепче, смотри в экран"
    gg "Cầm chắc vào, nhìn màn hình"

# game/characters_events_idles/maya_events.rpy:1188
translate english maya_scene12_evening_myroom_b18fd1da:

    # Maya "Мм . . ."
    Maya "Mm . . ."

# game/characters_events_idles/maya_events.rpy:1189
translate english maya_scene12_evening_myroom_3f637927:

    # Maya "Тут у тебя геймпад немного неудобный . . ."
    Maya "Tay cầm của cậu ở đây hơi bất tiện . . ."

# game/characters_events_idles/maya_events.rpy:1190
translate english maya_scene12_evening_myroom_8351e9a2:

    # gg "Нет . . . {w}я про . . ."
    gg "Không . . . {w}tớ nói về . . ."

# game/characters_events_idles/maya_events.rpy:1193
translate english maya_scene12_evening_myroom_c16d1061:

    # gg "Целься и стреляй"
    gg "Ngắm và bắn"

# game/characters_events_idles/maya_events.rpy:1197
translate english maya_scene12_evening_myroom_cbd60b88:

    # Maya "А! Я попала по нему!"
    Maya "A! Tớ bắn trúng nó rồi!"

# game/characters_events_idles/maya_events.rpy:1198
translate english maya_scene12_evening_myroom_15447830:

    # Maya "Но всё равно проиграла . . ."
    Maya "Nhưng vẫn thua . . ."

# game/characters_events_idles/maya_events.rpy:1199
translate english maya_scene12_evening_myroom_9b0188df:

    # gg "Нужно время, чтобы научиться"
    gg "Cần thời gian để học"

# game/characters_events_idles/maya_events.rpy:1201
translate english maya_scene12_evening_myroom_3a4b5fe2:

    # Maya "Время?"
    Maya "Thời gian？"

# game/characters_events_idles/maya_events.rpy:1202
translate english maya_scene12_evening_myroom_7be2116f:

    # Maya "У меня терпения не хватит"
    Maya "Tớ không đủ kiên nhẫn"

# game/characters_events_idles/maya_events.rpy:1207
translate english maya_scene12_evening_myroom_502ea205:

    # Maya "Я лучше найду другой способ с тобой поиграть"
    Maya "Tớ thà tìm cách khác để chơi với cậu"

# game/characters_events_idles/maya_events.rpy:1209
translate english maya_scene12_evening_myroom_d76b3a67:

    # gg "Похоже, тебе важнее сбить меня с толку . . ."
    gg "Có vẻ cậu thấy làm tớ rối trí quan trọng hơn . . ."

# game/characters_events_idles/maya_events.rpy:1212
translate english maya_scene12_evening_myroom_9a170cb1:

    # Maya "Экран-то видишь ещё?"
    Maya "Cậu còn thấy màn hình không？"

# game/characters_events_idles/maya_events.rpy:1214
translate english maya_scene12_evening_myroom_7c6d2d03:

    # Maya "А это"
    Maya "Còn cái này"

# game/characters_events_idles/maya_events.rpy:1216
translate english maya_scene12_evening_myroom_b1427dbd:

    # Maya "Не интереснее?"
    Maya "Không thú vị hơn à？"

# game/characters_events_idles/maya_events.rpy:1219
translate english maya_scene12_evening_myroom_2fd00100:

    # gg "Интереснее, но я хочу выиграть"
    gg "Thú vị hơn, nhưng tớ muốn thắng"

# game/characters_events_idles/maya_events.rpy:1222
translate english maya_scene12_evening_myroom_161fdfc3:

    # Maya "Ну-ну"
    Maya "Vậy à"

# game/characters_events_idles/maya_events.rpy:1223
translate english maya_scene12_evening_myroom_270d46ae:

    # Maya "Тогда держи удар"
    Maya "Vậy thì chịu đòn đi"

# game/characters_events_idles/maya_events.rpy:1227
translate english maya_scene12_evening_myroom_38cb6e8b:

    # Maya "Геймер"
    Maya "Gamer"

# game/characters_events_idles/maya_events.rpy:1229
translate english maya_scene12_evening_myroom_a093b46d:

    # gg_chat "Она решила так играть? . . ."
    gg_chat "Cô ấy quyết định chơi kiểu này à？ . . ."

# game/characters_events_idles/maya_events.rpy:1233
translate english maya_scene12_evening_myroom_5f58be75:

    # Maya "Давай, продолжай выигрывать"
    Maya "Nào, tiếp tục thắng đi"

# game/characters_events_idles/maya_events.rpy:1234
translate english maya_scene12_evening_myroom_6c6c4f14:

    # Maya "Интересно, надолго ли тебя хватит"
    Maya "Không biết cậu trụ được bao lâu"

# game/characters_events_idles/maya_events.rpy:1235
translate english maya_scene12_evening_myroom_cc2a1c48:

    # gg "Мая . . ."
    gg "Maya . . ."

# game/characters_events_idles/maya_events.rpy:1236
translate english maya_scene12_evening_myroom_a757aa6b:

    # gg "Ты . . ."
    gg "Cậu . . ."

# game/characters_events_idles/maya_events.rpy:1237
translate english maya_scene12_evening_myroom_2ca54e92:

    # Maya "Тише, я разбираюсь с управлением"
    Maya "Suỵt, tớ đang mò cách điều khiển"

# game/characters_events_idles/maya_events.rpy:1243
translate english maya_scene12_evening_myroom_60a36ddd:

    # Maya "Ну что?"
    Maya "Thế nào？"

# game/characters_events_idles/maya_events.rpy:1244
translate english maya_scene12_evening_myroom_6ab6d9ce:

    # Maya "Поражение засчитано?"
    Maya "Đã tính là thua chưa？"

# game/characters_events_idles/maya_events.rpy:1245
translate english maya_scene12_evening_myroom_c6558b58:

    # gg "Это вообще нечестная игра"
    gg "Đây rõ ràng là trò chơi không công bằng"

# game/characters_events_idles/maya_events.rpy:1247
translate english maya_scene12_evening_myroom_c6b0e67a:

    # Maya "Нечестные победы самые сладкие"
    Maya "Chiến thắng không công bằng mới ngọt nhất"

# game/characters_events_idles/maya_events.rpy:1248
translate english maya_scene12_evening_myroom_6e151f9e:

    # Maya "Теперь ты мой должник"
    Maya "Giờ cậu nợ tớ"

translate english strings:

    # game/characters_events_idles/maya_events.rpy:742
    old "Договаривай"
    new "Nói nốt đi"

    # game/characters_events_idles/maya_events.rpy:752
    old ". . ."
    new ". . ."

    # game/characters_events_idles/maya_events.rpy:772
    old "Угрожаешь?"
    new "Đe dọa à？"

    # game/characters_events_idles/maya_events.rpy:775
    old "Никому"
    new "Không cho ai"

    # game/characters_events_idles/maya_events.rpy:829
    old "Тихо поцеловать её"
    new "Nhẹ nhàng hôn cô ấy"

    # game/characters_events_idles/maya_events.rpy:842
    old "Уткнуться в ее грудь"
    new "Áp mặt vào ngực cô ấy"

# TODO: Translation updated at 2026-01-26 03:21

# game/characters_events_idles/maya_events.rpy:248
translate english maya_scene3_evening_kitchen_2c2f92cd:

    # Maya "Зачем так близко?"
    Maya "Sao lại gần thế？"

# game/characters_events_idles/maya_events.rpy:314
translate english maya_scene4_morning_mayaroom_0d36d4ee:

    # gg "Хорошо, не собирался"
    gg "Được, tớ không định"

# game/characters_events_idles/maya_events.rpy:402
translate english maya_scene5_night_mayaroom_979f77d5:

    # Maya "{size=*1.3}Не надо"
    Maya "{size=*1.3}Đừng"

# game/characters_events_idles/maya_events.rpy:410
translate english maya_scene5_night_mayaroom_8fb3b4e0:

    # Maya "{size=*1.3}Ты всегда «просто»"
    Maya "{size=*1.3}Cậu lúc nào cũng “chỉ là”"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/maya_events.rpy:42
translate english maya_scene1_evening_myroom_82e75b03:

    # Maya "Где они, блин"
    Maya "Chúng nó đâu rồi, trời ạ"

# game/characters_events_idles/maya_events.rpy:182
translate english maya_scene2_day_mayaroom_64552e65:

    # Maya "В мои дела"
    Maya "Vào chuyện của tớ"

# game/characters_events_idles/maya_events.rpy:293
translate english maya_scene4_morning_mayaroom_aea30766:

    # gg "Погоди, у меня была похожая проблема"
    gg "Đợi đã, tớ từng gặp vấn đề tương tự"

# game/characters_events_idles/maya_events.rpy:304
translate english maya_scene4_morning_mayaroom_c677d050:

    # Maya "Ладно, поскольку ты уже встал тут в позу спасителя"
    Maya "Được rồi, vì cậu đã làm ra vẻ người cứu thế rồi"

# game/characters_events_idles/maya_events.rpy:308
translate english maya_scene4_morning_mayaroom_c7e3f4c3:

    # Maya "Но если сломаешь, новый купишь"
    Maya "Nhưng nếu làm hỏng, cậu mua cái mới"

# game/characters_events_idles/maya_events.rpy:398
translate english maya_scene5_night_mayaroom_24e10eb1:

    # Maya "Хочешь границы"
    Maya "Muốn ranh giới"

# game/characters_events_idles/maya_events.rpy:521
translate english maya_scene6_evening_myroom_8447de22:

    # Maya "Увидишь"
    Maya "Cậu sẽ thấy"

# game/characters_events_idles/maya_events.rpy:580
translate english maya_scene6_evening_myroom_8974d68b:

    # Maya "В общем, нужно нанести крем и забинтовать"
    Maya "Nói chung là cần bôi kem rồi băng lại"

# game/characters_events_idles/maya_events.rpy:594
translate english maya_scene6_evening_myroom_94783c90:

    # gg "Кажется, это называется забота"
    gg "Hình như cái đó gọi là quan tâm"

# game/characters_events_idles/maya_events.rpy:620
translate english maya_scene6_evening_myroom_b0f0812d:

    # gg "Просто сейчас . . .{w} нет смысла психовать"
    gg "Chỉ là bây giờ . . .{w} không có lý do gì để phát điên"

# game/characters_events_idles/maya_events.rpy:662
translate english maya_scene6_evening_myroom_98eb68ec:

    # gg "Если тебе так проще — я выйду"
    gg "Nếu cậu thấy vậy dễ hơn — tớ ra ngoài"

# game/characters_events_idles/maya_events.rpy:957
translate english maya_scene10_evening_myroom_e458abf1:

    # Maya "Словно вечность. Эти долбаные люди"
    Maya "Như cả một thế kỷ. Lũ người chết tiệt ấy"

# game/characters_events_idles/maya_events.rpy:967
translate english maya_scene10_evening_myroom_39f98df4:

    # Maya "Уфф, устала"
    Maya "Phù, mệt quá"

# game/characters_events_idles/maya_events.rpy:973
translate english maya_scene10_evening_myroom_b1651980:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Отстань"
    Maya "Về chuyện em lại bỏ bê việc dọn dẹp à？{w} {bt=a3-p2.0-s3.0}Đừng làm phiền."

# game/characters_events_idles/maya_events.rpy:975
translate english maya_scene10_evening_myroom_cd61d42f:

    # gg "Да ладно тебе, можно просто помолчать"
    gg "Thôi nào, chỉ cần im lặng thôi cũng được mà."# TODO: Translation updated at 2026-02-13 11:40

# TODO: Translation updated at 2026-02-16 03:29

# game/characters_events_idles/maya_events.rpy:1300
translate english maya_scene13_morning_girlroom_4a56a987:

    # gg_chat "Так, Cоня просила заказать новый шнур и заодно батарейки"
    gg_chat "Được rồi, Sonya nhờ đặt một sợi dây mới và tiện thể cả pin nữa."

# game/characters_events_idles/maya_events.rpy:1312
translate english maya_scene13_morning_girlroom_f5a72472:

    # gg "Ты чего?"
    gg "Sao vậy？"

# game/characters_events_idles/maya_events.rpy:1314
translate english maya_scene13_morning_girlroom_d958422f:

    # Maya "Ничего. Делай своё дело"
    Maya "Không có gì. Làm việc của anh đi."

# game/characters_events_idles/maya_events.rpy:1318
translate english maya_scene13_morning_girlroom_6b37e39c:

    # Maya "Не отвлекайся"
    Maya "Đừng mất tập trung."

# game/characters_events_idles/maya_events.rpy:1324
translate english maya_scene13_morning_girlroom_36d1af18:

    # gg "Мая одну секунду . . ."
    gg "Maya, một giây thôi . . ."

# game/characters_events_idles/maya_events.rpy:1325
translate english maya_scene13_morning_girlroom_df56cad2:

    # Maya "Я же сказала, делай свое дело"
    Maya "Em đã bảo rồi, làm việc của anh đi."

# game/characters_events_idles/maya_events.rpy:1328
translate english maya_scene13_morning_girlroom_3fa97e8a:

    # gg "Готово"
    gg "Xong rồi."

# game/characters_events_idles/maya_events.rpy:1351
translate english maya_scene13_morning_girlroom_d5360aaa:

    # Maya "Ну как тебе такое спокойное утро?"
    Maya "Thấy buổi sáng yên bình thế này thế nào？"

# game/characters_events_idles/maya_events.rpy:1353
translate english maya_scene13_morning_girlroom_337e1de0:

    # gg "Замечательно"
    gg "Tuyệt vời."

# game/characters_events_idles/maya_events.rpy:1382
translate english maya_scene14_afternoon_myroom_72791318:

    # Sonya "Эй . . . [povname] можешь помочь с коробками?"
    Sonya "Này . . . [povname], cậu giúp với mấy cái hộp được không？"

# game/characters_events_idles/maya_events.rpy:1384
translate english maya_scene14_afternoon_myroom_dce97add:

    # Maya "Ой. Тебя зовут"
    Maya "Ồ. Có người gọi anh kìa."

# game/characters_events_idles/maya_events.rpy:1386
translate english maya_scene14_afternoon_myroom_650d8ae1:

    # Maya "Беги. Не заставляй даму ждать"
    Maya "Chạy đi. Đừng để quý cô phải chờ."

# game/characters_events_idles/maya_events.rpy:1397
translate english maya_scene14_afternoon_myroom_134f9600:

    # Maya "Слушай . . ."
    Maya "Nghe này . . ."

# game/characters_events_idles/maya_events.rpy:1399
translate english maya_scene14_afternoon_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "Đừng đi."

# game/characters_events_idles/maya_events.rpy:1401
translate english maya_scene14_afternoon_myroom_6e0b7c57:

    # gg "Это из-за Сони?"
    gg "Là vì Sonya à？"

# game/characters_events_idles/maya_events.rpy:1403
translate english maya_scene14_afternoon_myroom_b380699d:

    # Maya "Ты правда думаешь, что я буду это обсуждать?"
    Maya "Anh thật sự nghĩ em sẽ bàn chuyện này sao？"

# game/characters_events_idles/maya_events.rpy:1406
translate english maya_scene14_afternoon_myroom_0ea54924:

    # Maya "Мне не нравится, как легко ты вскакиваешь"
    Maya "Em không thích việc anh vùng dậy dễ dàng như vậy."

# game/characters_events_idles/maya_events.rpy:1408
translate english maya_scene14_afternoon_myroom_e1764fab:

    # Maya "Как будто меня тут нет"
    Maya "Cứ như thể em không có mặt ở đây vậy."

# game/characters_events_idles/maya_events.rpy:1410
translate english maya_scene14_afternoon_myroom_1d844383:

    # Maya "Пять минут"
    Maya "Năm phút."

# game/characters_events_idles/maya_events.rpy:1415
translate english maya_scene14_afternoon_myroom_cab2c2bb:

    # Maya "Пять"
    Maya "Năm."

# game/characters_events_idles/maya_events.rpy:1417
translate english maya_scene14_afternoon_myroom_b4e47535:

    # Maya "И потом делай что хочешь"
    Maya "Rồi sau đó anh muốn làm gì thì làm."

# game/characters_events_idles/maya_events.rpy:1419
translate english maya_scene14_afternoon_myroom_9b6c39fb:

    # Maya "Только не думай, что это признание"
    Maya "Nhưng đừng nghĩ đây là lời tỏ tình."

# game/characters_events_idles/maya_events.rpy:1426
translate english maya_scene14_afternoon_myroom_93de4523:

    # Maya "Чeрт . . . каждый раз будто в первый"
    Maya "Chết tiệt . . . lần nào cũng như lần đầu."

# game/characters_events_idles/maya_events.rpy:1433
translate english maya_scene14_afternoon_myroom_3179047f:

    # Maya "Неужели всё это . . . мне?"
    Maya "Không lẽ tất cả chuyện này . . . là dành cho em？"

# game/characters_events_idles/maya_events.rpy:1439
translate english maya_scene14_afternoon_myroom_8135a08f:

    # Maya "Такой . . . наглый"
    Maya "Thật là . . . láo xược."

# game/characters_events_idles/maya_events.rpy:1441
translate english maya_scene14_afternoon_myroom_b3c83659:

    # Maya "И такой тeплый . . ."
    Maya "Và còn ấm áp đến thế . . ."

# game/characters_events_idles/maya_events.rpy:1449
translate english maya_scene14_afternoon_myroom_6a11d281:

    # Maya "Держись . . ."
    Maya "Bám chặt vào . . ."

# game/characters_events_idles/maya_events.rpy:1455
translate english maya_scene14_afternoon_myroom_53e2be3e:

    # Maya ". . . Всe"
    Maya ". . . Mọi thứ"

# game/characters_events_idles/maya_events.rpy:1459
translate english maya_scene14_afternoon_myroom_1f177920:

    # Maya "Моe"
    Maya "Của em"

# game/characters_events_idles/maya_events.rpy:1463
translate english maya_scene14_afternoon_myroom_9f7300e6:

    # Maya "Все"
    Maya "Tất cả"

# game/characters_events_idles/maya_events.rpy:1465
translate english maya_scene14_afternoon_myroom_00c0f420:

    # Maya "Иди"
    Maya "Đi đi"

# game/characters_events_idles/maya_events.rpy:1467
translate english maya_scene14_afternoon_myroom_0efb861b:

    # gg "Ты уверена?"
    gg "Em chắc chứ？"

# game/characters_events_idles/maya_events.rpy:1469
translate english maya_scene14_afternoon_myroom_362d3834:

    # Maya "Ага"
    Maya "Ừ."

# game/characters_events_idles/maya_events.rpy:1471
translate english maya_scene14_afternoon_myroom_31d3f8e7:

    # Maya "Только не пропадай"
    Maya "Chỉ là đừng biến mất nhé."

# game/characters_events_idles/maya_events.rpy:1473
translate english maya_scene14_afternoon_myroom_baa7f0c3:

    # Maya "Ты всё равно вернешься"
    Maya "Anh kiểu gì cũng sẽ quay lại thôi."