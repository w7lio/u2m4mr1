﻿# TODO: Translation updated at 2026-01-21 02:04

# game/characters_events_idles/kate_events.rpy:8
translate english kate_day_myroom_66ca7b58:

    # Kate "О, живой человек"
    Kate "Ồ, một người sống đây rồi"

# game/characters_events_idles/kate_events.rpy:9
translate english kate_day_myroom_b8813bdd:

    # Kate "Я уже начала думать, что вы тут все в спячке"
    Kate "Tôi còn tưởng mọi người ở đây đều đang ngủ đông rồi"

# game/characters_events_idles/kate_events.rpy:10
translate english kate_day_myroom_930c1443:

    # gg "Просто тихий день"
    gg "Chỉ là một ngày yên ắng"

# game/characters_events_idles/kate_events.rpy:11
translate english kate_day_myroom_53322b78:

    # gg "Мая опять заставила ждать?"
    gg "Maya lại bắt chờ à？"

# game/characters_events_idles/kate_events.rpy:13
translate english kate_day_myroom_995097d0:

    # Kate "Конечно. Я даже не удивляюсь"
    Kate "Đương nhiên. Tôi còn chẳng buồn ngạc nhiên nữa"

# game/characters_events_idles/kate_events.rpy:15
translate english kate_day_myroom_10cad415:

    # Kate "Знаешь"
    Kate "Cậu biết không"

# game/characters_events_idles/kate_events.rpy:17
translate english kate_day_myroom_c22e07fd:

    # Kate "Я тут недавно проезжала мимо старого бассейна, который возле рощи"
    Kate "Mới đây tôi đi ngang qua bể bơi cũ ở gần khu rừng nhỏ"

# game/characters_events_idles/kate_events.rpy:19
translate english kate_day_myroom_6a0c7cc1:

    # gg "Того, что сейчас с облупленной плиткой и заросшей дорожкой?"
    gg "Cái bể mà giờ gạch lát bị bong tróc và lối đi mọc đầy cỏ ấy hả？"

# game/characters_events_idles/kate_events.rpy:20
translate english kate_day_myroom_28bfe61b:

    # Kate "Ага. Ты его знаешь?"
    Kate "Ừ. Cậu biết nó à？"

# game/characters_events_idles/kate_events.rpy:21
translate english kate_day_myroom_70967ed9:

    # gg "Осталось воспоминание"
    gg "Còn lại một ký ức"

# game/characters_events_idles/kate_events.rpy:22
translate english kate_day_myroom_f3840668:

    # gg "В детстве бабушка туда водила меня, интересно что же с ним случилось"
    gg "Hồi nhỏ bà tôi dẫn tôi đến đó, không biết chuyện gì đã xảy ra với nó"

# game/characters_events_idles/kate_events.rpy:24
translate english kate_day_myroom_7d5745ab:

    # Kate "Я случилась"
    Kate "Tôi đã xảy ra đấy"

# game/characters_events_idles/kate_events.rpy:26
translate english kate_day_myroom_1c84b7f9:

    # Kate "Это был бассейн моего деда"
    Kate "Đó là bể bơi của ông tôi"

# game/characters_events_idles/kate_events.rpy:27
translate english kate_day_myroom_d7e25aaf:

    # Kate "Когда он умер, всё просто оставили. Я была маленькой"
    Kate "Khi ông ấy mất, mọi thứ cứ thế bị bỏ lại. Lúc đó tôi còn nhỏ"

# game/characters_events_idles/kate_events.rpy:29
translate english kate_day_myroom_f2aff5b8:

    # Kate "Тогда я часто туда ходила"
    Kate "Hồi đó tôi thường đến đó"

# game/characters_events_idles/kate_events.rpy:30
translate english kate_day_myroom_678d9c75:

    # Kate "Не знаю почему . . . {w}просто сидела, слушала, как эхо по плитке гуляет"
    Kate "Không biết vì sao . . . {w}chỉ ngồi đó, nghe tiếng vang vọng trên gạch lát"

# game/characters_events_idles/kate_events.rpy:32
translate english kate_day_myroom_a3778e4f:

    # gg "Я помню, там вода была — чистая, голубая"
    gg "Tôi nhớ nước ở đó hồi ấy — trong veo, xanh biếc"

# game/characters_events_idles/kate_events.rpy:34
translate english kate_day_myroom_43319b98:

    # Kate "Да. А сейчас трещины пошли"
    Kate "Đúng. Còn bây giờ thì nứt hết ra rồi"

# game/characters_events_idles/kate_events.rpy:36
translate english kate_day_myroom_1917ed73:

    # Kate "И трава пробилась через бетон"
    Kate "Và cỏ đã mọc xuyên qua bê tông"

# game/characters_events_idles/kate_events.rpy:37
translate english kate_day_myroom_3128d351:

    # Kate "Но место до сих пор . . . родное, понимаешь?"
    Kate "Nhưng nơi đó đến giờ vẫn . . . thân thuộc, cậu hiểu chứ？"

# game/characters_events_idles/kate_events.rpy:39
translate english kate_day_myroom_fe5606ef:

    # gg "Можно было бы восстановить"
    gg "Có thể khôi phục lại được"

# game/characters_events_idles/kate_events.rpy:41
translate english kate_day_myroom_cd6d5961:

    # Kate "Ха, говоришь, как будто это просто"
    Kate "Ha, cậu nói cứ như thể chuyện đó đơn giản lắm"

# game/characters_events_idles/kate_events.rpy:42
translate english kate_day_myroom_5397ef5f:

    # gg "Ну . . . {w}если там не обрушено дно — это реально"
    gg "Chà . . . {w}nếu đáy ở đó không bị sụp — thì làm được thật"

# game/characters_events_idles/kate_events.rpy:43
translate english kate_day_myroom_4ad2a7d6:

    # gg " Я могу помочь, если хочешь"
    gg "Tôi có thể giúp, nếu cậu muốn"

# game/characters_events_idles/kate_events.rpy:45
translate english kate_day_myroom_2d06e21d:

    # Kate "Ты это серьёзно?"
    Kate "Cậu nói thật à？"

# game/characters_events_idles/kate_events.rpy:46
translate english kate_day_myroom_9b243b4f:

    # gg "Почему нет. Место стоящее"
    gg "Sao lại không. Chỗ đó đáng làm mà"

# game/characters_events_idles/kate_events.rpy:47
translate english kate_day_myroom_7abebe15:

    # gg "И . . . {w} как будто жалко, что всё так осталось"
    gg "Và . . . {w} cứ thấy tiếc sao đó khi mọi thứ bị bỏ lại thế này"

# game/characters_events_idles/kate_events.rpy:49
translate english kate_day_myroom_ba8f7539:

    # Kate "Подожди, подожди!"
    Kate "Khoan, khoan đã!"

# game/characters_events_idles/kate_events.rpy:50
translate english kate_day_myroom_1b5ecaea:

    # Kate "То есть, если я найду цемент, кисти, старый насос — ты реально поможешь это оживить?"
    Kate "Tức là, nếu tôi tìm được xi măng, cọ, máy bơm cũ — cậu thật sự sẽ giúp làm nó sống lại chứ？"

# game/characters_events_idles/kate_events.rpy:52
translate english kate_day_myroom_29e07d4d:

    # gg "Похоже, я только что подписался на летний ремонт"
    gg "Có vẻ tôi vừa ký vào vụ sửa chữa mùa hè rồi"

# game/characters_events_idles/kate_events.rpy:54
translate english kate_day_myroom_23062701:

    # Kate "Господи, ты не понимаешь!"
    Kate "Trời ơi, cậu không hiểu đâu!"

# game/characters_events_idles/kate_events.rpy:55
translate english kate_day_myroom_0f27478e:

    # Kate "Там же можно сделать всё заново!"
    Kate "Ở đó có thể làm lại mọi thứ mà!"

# game/characters_events_idles/kate_events.rpy:58
translate english kate_day_myroom_f8a1991c:

    # Kate "Подсветку включить, бортики покрасить . . ."
    Kate "Bật đèn chiếu sáng, sơn lại thành bể . . ."

# game/characters_events_idles/kate_events.rpy:59
translate english kate_day_myroom_9fa28628:

    # Kate "Я даже помню, где лежала старая лестница!"
    Kate "Tôi còn nhớ cái thang cũ từng nằm ở đâu nữa!"

# game/characters_events_idles/kate_events.rpy:61
translate english kate_day_myroom_01599462:

    # Kate "Можем даже вывеску повесить — “Бассейн №1 Возрождён при участии безумцев”!"
    Kate "Thậm chí có thể treo biển — “Bể bơi №1 Hồi sinh với sự tham gia của những kẻ điên”!"

# game/characters_events_idles/kate_events.rpy:63
translate english kate_day_myroom_65417f70:

    # gg "Безумцев?"
    gg "Những kẻ điên？"

# game/characters_events_idles/kate_events.rpy:65
translate english kate_day_myroom_37a114e4:

    # Kate "Ну, а кто ещё решит копаться в полузаброшенном дворе ради детской мечты?"
    Kate "Chứ còn ai khác lại quyết định bới móc trong một cái sân gần như bị bỏ hoang vì giấc mơ thời thơ ấu chứ？"

# game/characters_events_idles/kate_events.rpy:68
translate english kate_day_myroom_fb47222b:

    # Kate "Если получится . . . я, наверное, наконец перестану чувствовать, что всё хорошее осталось “там”, в прошлом"
    Kate "Nếu thành công . . . có lẽ cuối cùng tôi sẽ thôi cảm thấy rằng mọi điều tốt đẹp đã ở lại “đằng kia”, trong quá khứ"

# game/characters_events_idles/kate_events.rpy:69
translate english kate_day_myroom_9e4c9fbd:

    # gg "Значит, начнём с настоящего"
    gg "Vậy thì bắt đầu từ hiện tại nhé"

# game/characters_events_idles/kate_events.rpy:71
translate english kate_day_myroom_2d334a18:

    # Kate "Серьёзно!?"
    Kate "Thật sao!？"

# game/characters_events_idles/kate_events.rpy:72
translate english kate_day_myroom_756e6836:

    # Kate "Спасибо. Ты первый, кто не сказал “забей”"
    Kate "Cảm ơn. Cậu là người đầu tiên không nói “kệ đi”"

# game/characters_events_idles/kate_events.rpy:73
translate english kate_day_myroom_651bc331:

    # gg "Я не умею “забивать”"
    gg "Tôi không biết “mặc kệ”"

# game/characters_events_idles/kate_events.rpy:79
translate english kate_day_myroom_7ace6d42:

    # Maya "Кейт! Я готова!"
    Maya "Kate! Tôi sẵn sàng rồi!"

# game/characters_events_idles/kate_events.rpy:81
translate english kate_day_myroom_d05a36ed:

    # Kate "Опять вовремя"
    Kate "Lại đúng giờ"

# game/characters_events_idles/kate_events.rpy:83
translate english kate_day_myroom_be210218:

    # Kate "Тогда Увидимся у бассейна [povname], строитель мечтаний"
    Kate "Vậy thì hẹn gặp ở bể bơi nhé [povname], người xây dựng những giấc mơ"

