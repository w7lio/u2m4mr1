﻿# TODO: Translation updated at 2026-01-21 02:04

# game/script.rpy:25
translate english start_fe40380a:

    # "Вы уже играли в нашу игру раньше?"
    "Bạn đã từng chơi trò chơi của chúng tôi trước đây chưa？"

# game/script.rpy:26
translate english start_dc363420:

    # "Интро содержит важные сюжетные события и знакомство с миром игры"
    "Phần giới thiệu chứa các sự kiện cốt truyện quan trọng và giúp làm quen với thế giới của trò chơi"

# game/script.rpy:27
translate english start_96a117ce:

    # "Если пропустить его при первом прохождении, вы рискуете упустить значительную часть истории и контента"
    "Nếu bỏ qua nó trong lần chơi đầu tiên, bạn có nguy cơ bỏ lỡ một phần đáng kể của câu chuyện và nội dung"

translate english strings:

    # game/script.rpy:15
    old "И как же вас зовут"
    new "Và bạn tên là gì nhỉ"

    # game/script.rpy:17
    old "Дэн"
    new "Dan"

    # game/script.rpy:29
    old "Начать игру"
    new "Bắt đầu trò chơi"

    # game/script.rpy:31
    old "Пропустить интро"
    new "Bỏ qua phần giới thiệu"

