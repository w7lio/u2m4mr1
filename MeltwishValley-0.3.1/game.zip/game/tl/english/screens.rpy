﻿# TODO: Translation updated at 2026-01-21 02:04

translate english strings:

    # game/screens.rpy:427
    old "Назад"
    new "Quay lại"

    # game/screens.rpy:429
    old "Пропуск"
    new "Bỏ qua"

    # game/screens.rpy:430
    old "Авто"
    new "Tự động"

    # game/screens.rpy:431
    old "Сохранить"
    new "Lưu"

    # game/screens.rpy:432
    old "Б.Сохр"
    new "Lưu nhanh"

    # game/screens.rpy:433
    old "Б.Загр"
    new "Tải nhanh"

    # game/screens.rpy:434
    old "Настройки"
    new "Cài đặt"

    # game/screens.rpy:583
    old "НОВАЯ ИГРА"
    new "TRÒ CHƠI MỚI"

    # game/screens.rpy:584
    old "ЗАГРУЗИТЬ"
    new "TẢI"

    # game/screens.rpy:585
    old "НАСТРОЙКИ"
    new "CÀI ĐẶT"

    # game/screens.rpy:586
    old "О ИГРЕ"
    new "VỀ TRÒ CHƠI"

    # game/screens.rpy:593
    old "ИСТОРИЯ"
    new "LỊCH SỬ"

    # game/screens.rpy:594
    old "СОХРАНИТЬ"
    new "LƯU"

    # game/screens.rpy:599
    old "ЗАВЕРШИТЬ ПОВТОР"
    new "KẾT THÚC LẶP LẠI"

    # game/screens.rpy:601
    old "МЕНЮ"
    new "MENU"

    # game/screens.rpy:606
    old "ВЫХОД"
    new "THOÁT"

    # game/screens.rpy:758
    old "Вернуться"
    new "Quay lại"

    # game/screens.rpy:912
    old "Версия [config.version!t]\n"
    new "Phiên bản [config.version!t]\n"

    # game/screens.rpy:951
    old "{} страница"
    new "{} trang"

    # game/screens.rpy:951
    old "Автосохранения"
    new "Lưu tự động"

    # game/screens.rpy:951
    old "Быстрые сохранения"
    new "Lưu nhanh"

    # game/screens.rpy:999
    old "{#file_time}%A, %d %B %Y, %H:%M"
    new "{#file_time}%A, %d %B %Y, %H:%M"

    # game/screens.rpy:999
    old "Пустой слот"
    new "Ô trống"

    # game/screens.rpy:1020
    old "<"
    new "<"

    # game/screens.rpy:1024
    old "{#auto_page}А"
    new "{#auto_page}А"

    # game/screens.rpy:1027
    old "{#quick_page}Б"
    new "{#quick_page}Б"

    # game/screens.rpy:1033
    old ">"
    new ">"

    # game/screens.rpy:1105
    old "Всего текста"
    new "Tổng số chữ"

    # game/screens.rpy:1106
    old "После выборов"
    new "Sau lựa chọn"

    # game/screens.rpy:1112
    old "Режим экрана"
    new "Chế độ màn hình"

    # game/screens.rpy:1113
    old "Оконный"
    new "Cửa sổ"

    # game/screens.rpy:1114
    old "Полный"
    new "Toàn màn hình"

    # game/screens.rpy:1118
    old "Язык"
    new "Ngôn ngữ"

    # game/screens.rpy:1151
    old "Скорость текста"
    new "Tốc độ chữ"

    # game/screens.rpy:1155
    old "Скорость авточтения"
    new "Tốc độ tự động đọc"

    # game/screens.rpy:1159
    old "Прозрачность окна"
    new "Độ trong suốt cửa sổ"

    # game/screens.rpy:1165
    old "Громкость музыки"
    new "Âm lượng nhạc"

    # game/screens.rpy:1172
    old "Громкость звуков"
    new "Âm lượng âm thanh"

    # game/screens.rpy:1178
    old "Тест"
    new "Thử"

    # game/screens.rpy:1182
    old "Громкость голоса"
    new "Âm lượng giọng nói"

    # game/screens.rpy:1193
    old "Без звука"
    new "Tắt tiếng"

    # game/screens.rpy:1378
    old "История диалогов пуста."
    new "Lịch sử hội thoại trống."

    # game/screens.rpy:1621
    old "Ты правда хочешь выйти"
    new "Bạn thật sự muốn thoát？"

    # game/screens.rpy:1628
    old "Да"
    new "Có"

    # game/screens.rpy:1632
    old "Нет"
    new "Không"

    # game/screens.rpy:1686
    old "Пропускаю"
    new "Đang bỏ qua"

    # game/screens.rpy:1997
    old "Меню"
    new "Menu"

    # game/screens.rpy:2362
    old "д"
    new "д"

    # game/screens.rpy:2488
    old "Персонажи"
    new "Nhân vật"

    # game/screens.rpy:2608
    old "Подсказка"
    new "Gợi ý"

    # game/screens.rpy:2627
    old "Отслеживать квест"
    new "Theo dõi nhiệm vụ"

    # game/screens.rpy:2636
    old "Перестать отслеживать"
    new "Ngừng theo dõi"

    # game/screens.rpy:2657
    old "Продвигайтесь по сюжету"
    new "Hãy tiến theo cốt truyện"# TODO: Translation updated at 2026-01-27 02:10

translate english strings:

    # game/screens.rpy:574
    old "ИГРАЙ РАНЬШЕ ДРУГИХ"
    new "CHƠI TRƯỚC NGƯỜI KHÁC"

# TODO: Translation updated at 2026-01-27 02:14

translate english strings:

    # game/screens.rpy:602
    old "Бесплатные девлоги"
    new "Devlog miễn phí"

