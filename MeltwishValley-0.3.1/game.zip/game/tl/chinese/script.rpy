﻿# TODO: Translation updated at 2026-01-21 02:05

# game/script.rpy:25
translate chinese start_fe40380a:

    # "Вы уже играли в нашу игру раньше?"
    "你以前玩过我们的游戏吗？"

# game/script.rpy:26
translate chinese start_dc363420:

    # "Интро содержит важные сюжетные события и знакомство с миром игры"
    "简介包含重要的情节事件和游戏世界的介绍"

# game/script.rpy:27
translate chinese start_96a117ce:

    # "Если пропустить его при первом прохождении, вы рискуете упустить значительную часть истории и контента"
    "如果您在第一次玩游戏时跳过它，您可能会错过故事和内容的很大一部分"

translate chinese strings:

    # game/script.rpy:15
    old "И как же вас зовут"
    new "你叫什么名字？"

    # game/script.rpy:17
    old "Дэн"
    new "担"

    # game/script.rpy:29
    old "Начать игру"
    new "开始游戏"

    # game/script.rpy:31
    old "Пропустить интро"
    new "跳过介绍"

