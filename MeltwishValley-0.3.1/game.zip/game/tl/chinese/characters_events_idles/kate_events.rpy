﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/kate_events.rpy:8
translate chinese kate_day_myroom_66ca7b58:

    # Kate "О, живой человек"
    Kate "哦，活着的人"

# game/characters_events_idles/kate_events.rpy:9
translate chinese kate_day_myroom_b8813bdd:

    # Kate "Я уже начала думать, что вы тут все в спячке"
    Kate "我已经开始认为你们都在这里冬眠了。"

# game/characters_events_idles/kate_events.rpy:10
translate chinese kate_day_myroom_930c1443:

    # gg "Просто тихий день"
    gg "只是安静的一天"

# game/characters_events_idles/kate_events.rpy:11
translate chinese kate_day_myroom_53322b78:

    # gg "Мая опять заставила ждать?"
    gg "让玛雅又等了？"

# game/characters_events_idles/kate_events.rpy:13
translate chinese kate_day_myroom_995097d0:

    # Kate "Конечно. Я даже не удивляюсь"
    Kate "当然。我一点也不惊讶"

# game/characters_events_idles/kate_events.rpy:15
translate chinese kate_day_myroom_10cad415:

    # Kate "Знаешь"
    Kate "你知道"

# game/characters_events_idles/kate_events.rpy:17
translate chinese kate_day_myroom_c22e07fd:

    # Kate "Я тут недавно проезжала мимо старого бассейна, который возле рощи"
    Kate "我最近开车经过小树林附近的旧游泳池"

# game/characters_events_idles/kate_events.rpy:19
translate chinese kate_day_myroom_6a0c7cc1:

    # gg "Того, что сейчас с облупленной плиткой и заросшей дорожкой?"
    gg "是现在瓷砖剥落、小路杂草丛生的那条吗？"

# game/characters_events_idles/kate_events.rpy:20
translate chinese kate_day_myroom_28bfe61b:

    # Kate "Ага. Ты его знаешь?"
    Kate "是的。你认识他吗？"

# game/characters_events_idles/kate_events.rpy:21
translate chinese kate_day_myroom_70967ed9:

    # gg "Осталось воспоминание"
    gg "留下一段记忆"

# game/characters_events_idles/kate_events.rpy:22
translate chinese kate_day_myroom_f3840668:

    # gg "В детстве бабушка туда водила меня, интересно что же с ним случилось"
    gg "小时候我奶奶带我去那里，我想知道那里发生了什么"

# game/characters_events_idles/kate_events.rpy:24
translate chinese kate_day_myroom_7d5745ab:

    # Kate "Я случилась"
    Kate "我发生了"

# game/characters_events_idles/kate_events.rpy:26
translate chinese kate_day_myroom_1c84b7f9:

    # Kate "Это был бассейн моего деда"
    Kate "这是我祖父的游泳池"

# game/characters_events_idles/kate_events.rpy:27
translate chinese kate_day_myroom_d7e25aaf:

    # Kate "Когда он умер, всё просто оставили. Я была маленькой"
    Kate "当他去世时，一切都被抛在脑后。我还小"

# game/characters_events_idles/kate_events.rpy:29
translate chinese kate_day_myroom_f2aff5b8:

    # Kate "Тогда я часто туда ходила"
    Kate "然后我就经常去那里"

# game/characters_events_idles/kate_events.rpy:30
translate chinese kate_day_myroom_678d9c75:

    # Kate "Не знаю почему . . . {w}просто сидела, слушала, как эхо по плитке гуляет"
    Kate "我不知道为什么。 。 。 {w}只是坐下来聆听穿过瓷砖的回声"

# game/characters_events_idles/kate_events.rpy:32
translate chinese kate_day_myroom_a3778e4f:

    # gg "Я помню, там вода была — чистая, голубая"
    gg "我记得那里的水清澈碧蓝"

# game/characters_events_idles/kate_events.rpy:34
translate chinese kate_day_myroom_43319b98:

    # Kate "Да. А сейчас трещины пошли"
    Kate "是的。现在裂缝已经开始"

# game/characters_events_idles/kate_events.rpy:36
translate chinese kate_day_myroom_1917ed73:

    # Kate "И трава пробилась через бетон"
    Kate "草冲破了混凝土"

# game/characters_events_idles/kate_events.rpy:37
translate chinese kate_day_myroom_3128d351:

    # Kate "Но место до сих пор . . . родное, понимаешь?"
    Kate "但那个地方还在。 。 。亲爱的，你明白吗？"

# game/characters_events_idles/kate_events.rpy:39
translate chinese kate_day_myroom_fe5606ef:

    # gg "Можно было бы восстановить"
    gg "可以恢复"

# game/characters_events_idles/kate_events.rpy:41
translate chinese kate_day_myroom_cd6d5961:

    # Kate "Ха, говоришь, как будто это просто"
    Kate "哈，你说得好像很容易一样"

# game/characters_events_idles/kate_events.rpy:42
translate chinese kate_day_myroom_5397ef5f:

    # gg "Ну . . . {w}если там не обрушено дно — это реально"
    gg "出色地 。 。 。 {w}如果底部没有塌陷，那就是真的"

# game/characters_events_idles/kate_events.rpy:43
translate chinese kate_day_myroom_4ad2a7d6:

    # gg " Я могу помочь, если хочешь"
    gg "如果你愿意的话我可以帮忙"

# game/characters_events_idles/kate_events.rpy:45
translate chinese kate_day_myroom_2d06e21d:

    # Kate "Ты это серьёзно?"
    Kate "你是认真的？"

# game/characters_events_idles/kate_events.rpy:46
translate chinese kate_day_myroom_9b243b4f:

    # gg "Почему нет. Место стоящее"
    gg "为什么不呢？值得去的地方"

# game/characters_events_idles/kate_events.rpy:47
translate chinese kate_day_myroom_7abebe15:

    # gg "И . . . {w} как будто жалко, что всё так осталось"
    gg "和 。 。 。 {w}可惜一切还是这样"

# game/characters_events_idles/kate_events.rpy:49
translate chinese kate_day_myroom_ba8f7539:

    # Kate "Подожди, подожди!"
    Kate "等等，等等！"

# game/characters_events_idles/kate_events.rpy:50
translate chinese kate_day_myroom_1b5ecaea:

    # Kate "То есть, если я найду цемент, кисти, старый насос — ты реально поможешь это оживить?"
    Kate "也就是说，如果我找到水泥、刷子、旧泵，你真的能帮助它复活吗？"

# game/characters_events_idles/kate_events.rpy:52
translate chinese kate_day_myroom_29e07d4d:

    # gg "Похоже, я только что подписался на летний ремонт"
    gg "看起来我刚刚报名参加了夏季装修。"

# game/characters_events_idles/kate_events.rpy:54
translate chinese kate_day_myroom_23062701:

    # Kate "Господи, ты не понимаешь!"
    Kate "主啊，你不明白！"

# game/characters_events_idles/kate_events.rpy:55
translate chinese kate_day_myroom_0f27478e:

    # Kate "Там же можно сделать всё заново!"
    Kate "在那里你可以再次做一切！"

# game/characters_events_idles/kate_events.rpy:58
translate chinese kate_day_myroom_f8a1991c:

    # Kate "Подсветку включить, бортики покрасить . . ."
    Kate "打开灯光，给侧面涂漆。 。 。"

# game/characters_events_idles/kate_events.rpy:59
translate chinese kate_day_myroom_9fa28628:

    # Kate "Я даже помню, где лежала старая лестница!"
    Kate "我什至记得旧梯子在哪里！"

# game/characters_events_idles/kate_events.rpy:61
translate chinese kate_day_myroom_01599462:

    # Kate "Можем даже вывеску повесить — “Бассейн №1 Возрождён при участии безумцев”!"
    Kate "我们甚至可以挂一个牌子——“一号池在狂人的参与下复活”！"

# game/characters_events_idles/kate_events.rpy:63
translate chinese kate_day_myroom_65417f70:

    # gg "Безумцев?"
    gg "狂人？"

# game/characters_events_idles/kate_events.rpy:65
translate chinese kate_day_myroom_37a114e4:

    # Kate "Ну, а кто ещё решит копаться в полузаброшенном дворе ради детской мечты?"
    Kate "那么，还有谁会为了儿时的梦想而决定在一个半废弃的院子里挖掘呢？"

# game/characters_events_idles/kate_events.rpy:68
translate chinese kate_day_myroom_fb47222b:

    # Kate "Если получится . . . я, наверное, наконец перестану чувствовать, что всё хорошее осталось “там”, в прошлом"
    Kate "如果成功的话。 。 。我可能最终不再觉得所有美好的事物都被留在了过去"

# game/characters_events_idles/kate_events.rpy:69
translate chinese kate_day_myroom_9e4c9fbd:

    # gg "Значит, начнём с настоящего"
    gg "那么让我们从现在开始"

# game/characters_events_idles/kate_events.rpy:71
translate chinese kate_day_myroom_2d334a18:

    # Kate "Серьёзно!?"
    Kate "严重地！？"

# game/characters_events_idles/kate_events.rpy:72
translate chinese kate_day_myroom_756e6836:

    # Kate "Спасибо. Ты первый, кто не сказал “забей”"
    Kate "谢谢。你是第一个没有说“杀了它”的人"

# game/characters_events_idles/kate_events.rpy:73
translate chinese kate_day_myroom_651bc331:

    # gg "Я не умею “забивать”"
    gg "我不知道如何得分"

# game/characters_events_idles/kate_events.rpy:79
translate chinese kate_day_myroom_7ace6d42:

    # Maya "Кейт! Я готова!"
    Maya "凯特！我准备好了！"

# game/characters_events_idles/kate_events.rpy:81
translate chinese kate_day_myroom_d05a36ed:

    # Kate "Опять вовремя"
    Kate "又准时了"

# game/characters_events_idles/kate_events.rpy:83
translate chinese kate_day_myroom_be210218:

    # Kate "Тогда Увидимся у бассейна [povname], строитель мечтаний"
    Kate "那么我们在泳池边见 [povname]，梦想缔造者"

