﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/sonya_idles.rpy:7
translate chinese sonya_Idle_morning_bathroom_scene_26477ebd:

    # Sonya "О, кто-то перестал стучаться?"
    Sonya "哦，有人停止敲门了吗？"

# game/characters_events_idles/sonya_idles.rpy:8
translate chinese sonya_Idle_morning_bathroom_scene_e490c24b:

    # gg "А смысл, если дверь открыта . . ."
    gg "如果门开着有什么意义呢？ 。 。"

# game/characters_events_idles/sonya_idles.rpy:10
translate chinese sonya_Idle_morning_bathroom_scene_2e0a6a8c:

    # Sonya "Смелый стал с утра . . ."
    Sonya "早上起来就变得大胆起来。 。 。"

# game/characters_events_idles/sonya_idles.rpy:12
translate chinese sonya_Idle_morning_bathroom_scene_f7e61e71:

    # gg "Просто решил не терять привычку к риску"
    gg "我只是决定不要失去冒险的习惯"

# game/characters_events_idles/sonya_idles.rpy:13
translate chinese sonya_Idle_morning_bathroom_scene_31735247:

    # gg_chat "Она даже в такие моменты выглядит так, будто специально проверяет, насколько далеко можно зайти"
    gg_chat "即使在这样的时刻，她看起来也像是在专门测试自己能走多远"

# game/characters_events_idles/sonya_idles.rpy:15
translate chinese sonya_Idle_morning_bathroom_scene_43fc63bc:

    # Sonya "Хочешь полюбоваться видом?"
    Sonya "你想欣赏美景吗？"

# game/characters_events_idles/sonya_idles.rpy:17
translate chinese sonya_Idle_morning_bathroom_scene_274bd888:

    # Sonya "Я не против"
    Sonya "我不介意"

# game/characters_events_idles/sonya_idles.rpy:18
translate chinese sonya_Idle_morning_bathroom_scene_e8a5a241:

    # gg "С таким предложением даже утренний кофе станет лишним"
    gg "有了这个优惠，连早上的咖啡都变得不必要了"

# game/characters_events_idles/sonya_idles.rpy:20
translate chinese sonya_Idle_morning_bathroom_scene_14ae5b75:

    # Sonya "Ну хоть кто-то ценит мой вклад в твое утро"
    Sonya "好吧，至少有人感谢我为你的早晨所做的贡献"

# game/characters_events_idles/sonya_idles.rpy:22
translate chinese sonya_Idle_morning_bathroom_scene_daf8e8db:

    # gg "Смотря, что ты предложишь взамен"
    gg "这取决于你提供什么回报。"

# game/characters_events_idles/sonya_idles.rpy:24
translate chinese sonya_Idle_morning_bathroom_scene_2ff9a6da:

    # Sonya "Знаешь, я бы тоже не отказалась провести утро поинтереснее"
    Sonya "你知道，我也不介意度过一个更有趣的早晨。"

# game/characters_events_idles/sonya_idles.rpy:26
translate chinese sonya_Idle_morning_bathroom_scene_e6700bf3:

    # Sonya "Особенно с тобой"
    Sonya "尤其是和你在一起"

# game/characters_events_idles/sonya_idles.rpy:27
translate chinese sonya_Idle_morning_bathroom_scene_9a24ffbd:

    # gg "Звучит как приглашение"
    gg "听起来像是邀请"

# game/characters_events_idles/sonya_idles.rpy:29
translate chinese sonya_Idle_morning_bathroom_scene_818d5283:

    # Sonya "Да это оно. Но, увы, у меня дела"
    Sonya "是的，就是这样。但是，唉，我还有事要做"

# game/characters_events_idles/sonya_idles.rpy:30
translate chinese sonya_Idle_morning_bathroom_scene_82d60fb2:

    # gg "Ты знаешь это нечестно"
    gg "你知道这不公平"

# game/characters_events_idles/sonya_idles.rpy:32
translate chinese sonya_Idle_morning_bathroom_scene_0d7eca0c:

    # Sonya "Я просто оставляю десерт на потом"
    Sonya "我只是把甜点留到以后用"

# game/characters_events_idles/sonya_idles.rpy:34
translate chinese sonya_Idle_morning_bathroom_scene_0d86f13a:

    # Sonya "Ну что ж, герой, ванная вся твоя"
    Sonya "好吧，英雄，浴室都是你的了。"

# game/characters_events_idles/sonya_idles.rpy:35
translate chinese sonya_Idle_morning_bathroom_scene_3e148853:

    # Sonya "Главное, когда будешь мыться не забудь, кто тебя вдохновил"
    Sonya "最重要的是，当你洗澡的时候，不要忘记是谁启发了你"

# game/characters_events_idles/sonya_idles.rpy:50
translate chinese sonya_Idle_evening_bathroom_scene_247f83e8:

    # gg "Не думал, что можно так красиво мыться под душем"
    gg "没想到洗澡可以这么美"

# game/characters_events_idles/sonya_idles.rpy:51
translate chinese sonya_Idle_evening_bathroom_scene_361d1da4:

    # Sonya "Я знала, что ты заглянешь"
    Sonya "我知道你会过来"

# game/characters_events_idles/sonya_idles.rpy:52
translate chinese sonya_Idle_evening_bathroom_scene_dd689906:

    # Sonya "У тебя шаги узнаются ещё до двери"
    Sonya "门前就能识别您的脚步"

# game/characters_events_idles/sonya_idles.rpy:54
translate chinese sonya_Idle_evening_bathroom_scene_69f260a8:

    # gg "Хотел убедиться, что ты не уплыла в параллельную реальность"
    gg "我想确保你不会飘入平行现实。"

# game/characters_events_idles/sonya_idles.rpy:55
translate chinese sonya_Idle_evening_bathroom_scene_81769a4a:

    # Sonya "Ещё нет. Хотя, если бы там было потеплее — можно было бы и остаться"
    Sonya "还没有。不过，如果那里暖和一点，我们就可以留下来"

# game/characters_events_idles/sonya_idles.rpy:57
translate chinese sonya_Idle_evening_bathroom_scene_1517ae3e:

    # Sonya "Знаешь, если бы я захотела — могла бы тебя соблазнить прямо сейчас"
    Sonya "你知道，如果我愿意，我现在就可以引诱你"

# game/characters_events_idles/sonya_idles.rpy:58
translate chinese sonya_Idle_evening_bathroom_scene_1371ca10:

    # Sonya "Только чтобы забрать себе"
    Sonya "只为自己拿走"

# game/characters_events_idles/sonya_idles.rpy:60
translate chinese sonya_Idle_evening_bathroom_scene_21c8c83c:

    # Sonya "Но ты ведь тогда точно не ушёл бы, да?"
    Sonya "但你当时肯定不会离开，不是吗？"

# game/characters_events_idles/sonya_idles.rpy:61
translate chinese sonya_Idle_evening_bathroom_scene_e75862b1:

    # gg "Вряд ли бы смог"
    gg "我怀疑我可以"

# game/characters_events_idles/sonya_idles.rpy:64
translate chinese sonya_Idle_evening_bathroom_scene_6b3e3f56:

    # Sonya "Вот именно, поэтому уходи"
    Sonya "就这样了，所以走吧"

# game/characters_events_idles/sonya_idles.rpy:65
translate chinese sonya_Idle_evening_bathroom_scene_0c771583:

    # Sonya "Пока Мая не заглянула и не устроила мне лекцию на тему “личных границ”"
    Sonya "直到玛雅过来给我做了一场关于“个人界限”的讲座"

# game/characters_events_idles/sonya_idles.rpy:67
translate chinese sonya_Idle_evening_bathroom_scene_7782c9fd:

    # gg "Значит, спасаю нас обоих"
    gg "所以我要拯救我们俩"

# game/characters_events_idles/sonya_idles.rpy:68
translate chinese sonya_Idle_evening_bathroom_scene_61bc67e7:

    # Sonya "Спасай. Но не надолго"
    Sonya "节省。但不会长久"

# game/characters_events_idles/sonya_idles.rpy:69
translate chinese sonya_Idle_evening_bathroom_scene_b8d4595f:

    # gg_chat "Её слова звучали полушуткой, но от этого не становилось легче"
    gg_chat "她的话听起来像是半个玩笑，但这并没有让事情变得更容易。"

# game/characters_events_idles/sonya_idles.rpy:70
translate chinese sonya_Idle_evening_bathroom_scene_0892a9fc:

    # gg_chat "В каждой улыбке Сони теперь пряталось что-то большее, чем просто игра"
    gg_chat "索尼娅的每一个微笑现在都不仅仅包含着游戏"

# game/characters_events_idles/sonya_idles.rpy:85
translate chinese sonya_Idle_morning_girlroom_scene_5a6cf65f:

    # gg "Доброе утро. Ты уже с рассветом на работе?"
    gg "早上好。天一亮你就已经上班了吗？"

# game/characters_events_idles/sonya_idles.rpy:87
translate chinese sonya_Idle_morning_girlroom_scene_782b60a4:

    # Sonya "Почти. У меня тут урожай созрел, не могу бросить"
    Sonya "几乎。我的收获已经成熟，我不能放弃"

# game/characters_events_idles/sonya_idles.rpy:88
translate chinese sonya_Idle_morning_girlroom_scene_a3c52931:

    # gg "А я думал, ты в такие игры не играешь"
    gg "我以为你不玩这样的游戏"

# game/characters_events_idles/sonya_idles.rpy:90
translate chinese sonya_Idle_morning_girlroom_scene_bbda1d39:

    # Sonya "А зря, это лучшая медитация"
    Sonya "但这是徒劳的，这是最好的冥想"

# game/characters_events_idles/sonya_idles.rpy:91
translate chinese sonya_Idle_morning_girlroom_scene_afc574c1:

    # Sonya "Никакой спешки, просто строишь, выращиваешь, приручаешь кошек"
    Sonya "不着急，只管建造、饲养、驯服猫"

# game/characters_events_idles/sonya_idles.rpy:93
translate chinese sonya_Idle_morning_girlroom_scene_2c50640e:

    # Sonya "Вот, видишь? Мой котик"
    Sonya "看到这里了吗？我的猫"

# game/characters_events_idles/sonya_idles.rpy:94
translate chinese sonya_Idle_morning_girlroom_scene_4c464678:

    # Sonya "Зовут Барсик"
    Sonya "名字叫巴尔西克"

# game/characters_events_idles/sonya_idles.rpy:95
translate chinese sonya_Idle_morning_girlroom_scene_cabe3537:

    # gg "Конечно. Даже тут он с тобой"
    gg "当然。即使在这里他也和你在一起"

# game/characters_events_idles/sonya_idles.rpy:96
translate chinese sonya_Idle_morning_girlroom_scene_d4be7bb4:

    # Sonya "Да не совсем того цвета, хотя бы не ворует еду"
    Sonya "是啊，颜色不太一样，至少不偷吃的"

# game/characters_events_idles/sonya_idles.rpy:97
translate chinese sonya_Idle_morning_girlroom_scene_725c6cbd:

    # Sonya "И на клавиатуру не ложится"
    Sonya "而且它不适合键盘"

# game/characters_events_idles/sonya_idles.rpy:98
translate chinese sonya_Idle_morning_girlroom_scene_fbf5b42b:

    # Sonya "Я построила ему дом. Маленький, но уютный"
    Sonya "我给他建了一座房子。小而温馨"

# game/characters_events_idles/sonya_idles.rpy:100
translate chinese sonya_Idle_morning_girlroom_scene_cfe34a6f:

    # gg "Как и в жизни"
    gg "就像生活中一样"

# game/characters_events_idles/sonya_idles.rpy:101
translate chinese sonya_Idle_morning_girlroom_scene_de0ba10f:

    # Sonya "Возможно. Я люблю, когда всё на своих местах. Даже в пикселях"
    Sonya "或许。我喜欢一切都各就各位。即使以像素为单位"

# game/characters_events_idles/sonya_idles.rpy:102
translate chinese sonya_Idle_morning_girlroom_scene_c16cc569:

    # gg "А с монстрами что делаешь?"
    gg "你对怪物做什么？"

# game/characters_events_idles/sonya_idles.rpy:104
translate chinese sonya_Idle_morning_girlroom_scene_c08d01fe:

    # Sonya "Ну избегаю. Я не про битвы, я про порядок"
    Sonya "嗯，我在回避它。我不是在谈论战斗，我是在谈论秩序"

# game/characters_events_idles/sonya_idles.rpy:105
translate chinese sonya_Idle_morning_girlroom_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "我喜欢一切都在掌控之中"

# game/characters_events_idles/sonya_idles.rpy:107
translate chinese sonya_Idle_morning_girlroom_scene_740206dd:

    # gg "Даже кот в игре слушается. Везёт тебе"
    gg "就连猫也在游戏中倾听。你很幸运"

# game/characters_events_idles/sonya_idles.rpy:108
translate chinese sonya_Idle_morning_girlroom_scene_fb402d59:

    # Sonya "А ты попробуй приручи кого-нибудь - узнаешь, что это целая наука"
    Sonya "如果你尝试驯服某人，你会发现这是一门完整的科学"

# game/characters_events_idles/sonya_idles.rpy:109
translate chinese sonya_Idle_morning_girlroom_scene_1b49be1f:

    # gg "Думаешь, справлюсь?"
    gg "你觉得我能应付得来吗？"

# game/characters_events_idles/sonya_idles.rpy:111
translate chinese sonya_Idle_morning_girlroom_scene_228ee7fd:

    # Sonya "Сомневаюсь"
    Sonya "我怀疑"

# game/characters_events_idles/sonya_idles.rpy:112
translate chinese sonya_Idle_morning_girlroom_scene_e99c47d3:

    # Sonya "Ты не тот тип, кто строит. Скорее тот, кто случайно всё ломает"
    Sonya "你不是那种适合建造的人。更像是一个不小心破坏了一切的人"

# game/characters_events_idles/sonya_idles.rpy:113
translate chinese sonya_Idle_morning_girlroom_scene_382eac3e:

    # gg "Эй, я в детстве играл. Даже базу под землёй сделал"
    gg "嘿嘿，我小时候也玩过。我什至在地下建了一个基地"

# game/characters_events_idles/sonya_idles.rpy:115
translate chinese sonya_Idle_morning_girlroom_scene_0d62bf92:

    # Sonya "Ага, и подорвал через пять минут?"
    Sonya "是啊，五分钟后就把它炸了？"

# game/characters_events_idles/sonya_idles.rpy:116
translate chinese sonya_Idle_morning_girlroom_scene_81cf123c:

    # gg "Через десять. Но всё по плану"
    gg "十点后。但一切都按计划进行"

# game/characters_events_idles/sonya_idles.rpy:118
translate chinese sonya_Idle_morning_girlroom_scene_24c0b733:

    # Sonya "Тогда аккуратнее с моим миром"
    Sonya "那么请小心我的世界"

# game/characters_events_idles/sonya_idles.rpy:119
translate chinese sonya_Idle_morning_girlroom_scene_3938ea91:

    # Sonya "Тут всё с любовью и без взрывчатки"
    Sonya "这里的一切都是用爱完成的，没有爆炸物。"

# game/characters_events_idles/sonya_idles.rpy:120
translate chinese sonya_Idle_morning_girlroom_scene_5664d0ac:

    # gg "Учту. Буду только наблюдать"
    gg "我会考虑的。我就看看"

# game/characters_events_idles/sonya_idles.rpy:121
translate chinese sonya_Idle_morning_girlroom_scene_af4f45a5:

    # Sonya "Если хочешь, потом покажу тебе свой сад"
    Sonya "如果你愿意的话，我稍后带你参观我的花园。"

# game/characters_events_idles/sonya_idles.rpy:122
translate chinese sonya_Idle_morning_girlroom_scene_91498926:

    # Sonya "Там столько цветов и пчелок"
    Sonya "这里有很多花和蜜蜂"

# game/characters_events_idles/sonya_idles.rpy:123
translate chinese sonya_Idle_morning_girlroom_scene_89b49bad:

    # gg "Звучит как место, где тебе действительно спокойно"
    gg "听起来像是一个让你真正平静的地方。"

# game/characters_events_idles/sonya_idles.rpy:124
translate chinese sonya_Idle_morning_girlroom_scene_4a30e5b0:

    # Sonya "Наверное да, думаю нам стоит поиграть в будущем вместе!"
    Sonya "大概是的，我想以后我们应该一起玩！"

# game/characters_events_idles/sonya_idles.rpy:125
translate chinese sonya_Idle_morning_girlroom_scene_c8df07f1:

    # gg "Обязательно . . ."
    gg "必然的。 。 。"

# game/characters_events_idles/sonya_idles.rpy:139
translate chinese sonya_Idle_day_girlroom_scene_a20a3fae:

    # gg "Привет как дела?"
    gg "你好你好吗？"

# game/characters_events_idles/sonya_idles.rpy:141
translate chinese sonya_Idle_day_girlroom_scene_9dc60813:

    # Sonya "Эти таблицы просто издеваются надо мной . . ."
    Sonya "这些桌子只是在取笑我。 。 。"

# game/characters_events_idles/sonya_idles.rpy:142
translate chinese sonya_Idle_day_girlroom_scene_92df120a:

    # Sonya "Хоть бросай всё и иди пасти коров"
    Sonya "至少放下一切去放牛吧"

# game/characters_events_idles/sonya_idles.rpy:144
translate chinese sonya_Idle_day_girlroom_scene_e2f61865:

    # gg "Похоже, у тебя с ними война"
    gg "看来你正在与他们交战"

# game/characters_events_idles/sonya_idles.rpy:146
translate chinese sonya_Idle_day_girlroom_scene_053f0179:

    # Sonya "Война, да. И я проигрываю с первого дня"
    Sonya "战争，是的。从第一天起我就一直在失败"

# game/characters_events_idles/sonya_idles.rpy:147
translate chinese sonya_Idle_day_girlroom_scene_d3cbfb79:

    # Sonya "Не знаю, почему все эти цифры так упрямо меня не слушаются"
    Sonya "我不知道为什么所有这些数字都这么固执地不听我的话"

# game/characters_events_idles/sonya_idles.rpy:150
translate chinese sonya_Idle_day_girlroom_scene_8d39ea32:

    # Sonya "Знаешь, я ведь здесь выросла"
    Sonya "你知道，我在这里长大"

# game/characters_events_idles/sonya_idles.rpy:151
translate chinese sonya_Idle_day_girlroom_scene_65c67f0f:

    # Sonya "Ну, не прямо в этом доме, но в этом посёлке"
    Sonya "嗯，不是在这所房子里，而是在这个村庄里"

# game/characters_events_idles/sonya_idles.rpy:152
translate chinese sonya_Idle_day_girlroom_scene_4c34bce3:

    # gg "Правда?"
    gg "这是真的吗？"

# game/characters_events_idles/sonya_idles.rpy:154
translate chinese sonya_Idle_day_girlroom_scene_70dec560:

    # Sonya "Да. Тогда всё казалось больше - и улицы, и дома, и даже небо"
    Sonya "是的。然后一切都显得更大了——街道、房屋，甚至天空。"

# game/characters_events_idles/sonya_idles.rpy:155
translate chinese sonya_Idle_day_girlroom_scene_d0fea2c7:

    # Sonya "Потом я уехала, думала, найду место получше, что-то новое"
    Sonya "然后我离开了，我想我会找到一个更好的地方，一些新的东西"

# game/characters_events_idles/sonya_idles.rpy:157
translate chinese sonya_Idle_day_girlroom_scene_4acb46e4:

    # Sonya "А в итоге вернулась туда, где мне и было хорошо с самого начала"
    Sonya "最后我又回到了从一开始就感觉良好的地方"

# game/characters_events_idles/sonya_idles.rpy:158
translate chinese sonya_Idle_day_girlroom_scene_e5c60ec3:

    # gg "А как ты познакомилась с Линдой?"
    gg "你是怎么认识琳达的？"

# game/characters_events_idles/sonya_idles.rpy:160
translate chinese sonya_Idle_day_girlroom_scene_b9747f5f:

    # Sonya "О, это было случайно"
    Sonya "哦，这是一个意外"

# game/characters_events_idles/sonya_idles.rpy:161
translate chinese sonya_Idle_day_girlroom_scene_4203728c:

    # Sonya "Я тогда снимала комнату в соседнем доме, а она как-то увидела, что я таскаю тяжелые коробки и просто подошла помочь"
    Sonya "当时我在隔壁的房子里租了一个房间，她不知怎么看到我拎着很重的箱子，就过来帮忙。"

# game/characters_events_idles/sonya_idles.rpy:163
translate chinese sonya_Idle_day_girlroom_scene_6c6eaa0a:

    # Sonya "С тех пор мы начали общаться"
    Sonya "从那时起我们就开始交往"

# game/characters_events_idles/sonya_idles.rpy:164
translate chinese sonya_Idle_day_girlroom_scene_a7d57230:

    # Sonya "Она часто звала меня на чай, а потом сказала, что у неё всё равно пустует комната - и я переехала"
    Sonya "她经常叫我喝茶，然后她说反正她的房间是空的——所以我就搬家了"

# game/characters_events_idles/sonya_idles.rpy:166
translate chinese sonya_Idle_day_girlroom_scene_d72f25aa:

    # gg "То есть Линда тебя приютила?"
    gg "所以琳达收留了你？"

# game/characters_events_idles/sonya_idles.rpy:168
translate chinese sonya_Idle_day_girlroom_scene_181e70fe:

    # Sonya "Можно и так сказать"
    Sonya "你可以这么说"

# game/characters_events_idles/sonya_idles.rpy:169
translate chinese sonya_Idle_day_girlroom_scene_c5827422:

    # Sonya "Она никогда не делала из этого что-то большое, просто . . . {w}была рядом"
    Sonya "她从来没有小题大做，只是…… 。 。 {w}就在附近"

# game/characters_events_idles/sonya_idles.rpy:170
translate chinese sonya_Idle_day_girlroom_scene_967e2aa8:

    # Sonya "Знаешь, таких людей немного"
    Sonya "要知道这样的人很少"

# game/characters_events_idles/sonya_idles.rpy:172
translate chinese sonya_Idle_day_girlroom_scene_6ab10a33:

    # Sonya "А теперь вот я за ее столом"
    Sonya "现在我在她的餐桌旁"

# game/characters_events_idles/sonya_idles.rpy:173
translate chinese sonya_Idle_day_girlroom_scene_75e4a1ee:

    # Sonya "Иногда кажется, что она всё ещё где-то рядом, наблюдает и тихо подсказывает, что делать"
    Sonya "有时她似乎还在附近的某个地方，注视着她，静静地告诉她该怎么做。"

# game/characters_events_idles/sonya_idles.rpy:174
translate chinese sonya_Idle_day_girlroom_scene_842a9d6c:

    # gg "Может, поэтому тебе так важно всё довести до идеала"
    gg "也许这就是为什么让一切变得完美对你来说如此重要"

# game/characters_events_idles/sonya_idles.rpy:176
translate chinese sonya_Idle_day_girlroom_scene_e1ccf1c4:

    # Sonya "Возможно. Только вот с таблицами идеала точно не получится"
    Sonya "或许。但对于理想的桌子来说，这肯定行不通"

# game/characters_events_idles/sonya_idles.rpy:178
translate chinese sonya_Idle_day_girlroom_scene_cb6d8969:

    # Sonya "Спасибо, что подошёл"
    Sonya "谢谢你的到来"

# game/characters_events_idles/sonya_idles.rpy:179
translate chinese sonya_Idle_day_girlroom_scene_45ba29af:

    # Sonya "Без тебя я бы и дальше злилась на эти несчастные ячейки"
    Sonya "没有你，我仍然会对这些可怜的牢房感到愤怒。"

# game/characters_events_idles/sonya_idles.rpy:180
translate chinese sonya_Idle_day_girlroom_scene_c55fced7:

    # gg "Рад помочь"
    gg "很高兴提供帮助"

# game/characters_events_idles/sonya_idles.rpy:181
translate chinese sonya_Idle_day_girlroom_scene_c59d3a8e:

    # gg "Иногда лучший способ справиться с работой - просто отвлечься"
    gg "有时完成工作的最好方法就是分散自己的注意力"

# game/characters_events_idles/sonya_idles.rpy:183
translate chinese sonya_Idle_day_girlroom_scene_dc01f949:

    # Sonya "Ты прав. А можешь мне чаек сделать пожалуйста . . ."
    Sonya "你是对的。你能给我泡杯茶吗？ 。 。"

# game/characters_events_idles/sonya_idles.rpy:184
translate chinese sonya_Idle_day_girlroom_scene_307a264f:

    # gg "Да конечно"
    gg "是的，当然"

# game/characters_events_idles/sonya_idles.rpy:186
translate chinese sonya_Idle_day_girlroom_scene_b0fc80b8:

    # Sonya "Спасибо огромное"
    Sonya "多谢"

# game/characters_events_idles/sonya_idles.rpy:187
translate chinese sonya_Idle_day_girlroom_scene_11813a95:

    # gg_chat "В ней было что-то от Линды - то же спокойствие и мягкость, только моложе, живее"
    gg_chat "她身上有一些琳达的影子——同样的冷静和温柔，只是更年轻，更活泼"

# game/characters_events_idles/sonya_idles.rpy:188
translate chinese sonya_Idle_day_girlroom_scene_660cc2e9:

    # gg_chat "И, пожалуй, даже теплее"
    gg_chat "也许甚至更温暖"

# game/characters_events_idles/sonya_idles.rpy:203
translate chinese sonya_Idle_evening_girlroom_scene_42feeaf6:

    # gg "Можно присесть?"
    gg "我可以坐下吗？"

# game/characters_events_idles/sonya_idles.rpy:205
translate chinese sonya_Idle_evening_girlroom_scene_8460369c:

    # Sonya "Можно . . . {w}но с тебя - плата"
    Sonya "能 。 。 。 {w}但您必须付费"

# game/characters_events_idles/sonya_idles.rpy:206
translate chinese sonya_Idle_evening_girlroom_scene_a599bb6d:

    # gg "Какая?"
    gg "哪个？"

# game/characters_events_idles/sonya_idles.rpy:208
translate chinese sonya_Idle_evening_girlroom_scene_81b816f5:

    # Sonya "Остаться до конца вечера"
    Sonya "一直呆到晚上结束"

# game/characters_events_idles/sonya_idles.rpy:209
translate chinese sonya_Idle_evening_girlroom_scene_e27a7e82:

    # Sonya "И не сбежать"
    Sonya "并且不要逃跑"

# game/characters_events_idles/sonya_idles.rpy:210
translate chinese sonya_Idle_evening_girlroom_scene_7f2d6628:

    # gg "Если ты обещаешь не гнать - я и до утра не уйду"
    gg "如果你答应不赶我走的话，我要到早上才走"

# game/characters_events_idles/sonya_idles.rpy:212
translate chinese sonya_Idle_evening_girlroom_scene_1cdd78f4:

    # Sonya "Тогда, может, и расскажу что-нибудь . . . {w}личное"
    Sonya "然后也许我会告诉你一些事情。 。 。 {w}个人"

# game/characters_events_idles/sonya_idles.rpy:215
translate chinese sonya_Idle_evening_girlroom_scene_9eb3b8ed:

    # Sonya "Забавно, получилось"
    Sonya "很有趣，它起作用了"

# game/characters_events_idles/sonya_idles.rpy:216
translate chinese sonya_Idle_evening_girlroom_scene_8bb9cddd:

    # Sonya "Мы с Маей обе любим тишину, но по-разному"
    Sonya "玛雅和我都喜欢沉默，但方式不同。"

# game/characters_events_idles/sonya_idles.rpy:217
translate chinese sonya_Idle_evening_girlroom_scene_fb1f6848:

    # gg "В каком смысле?"
    gg "从什么意义上说？"

# game/characters_events_idles/sonya_idles.rpy:219
translate chinese sonya_Idle_evening_girlroom_scene_a5d3ae91:

    # Sonya "Она включает музыку, чтобы заглушить всё вокруг"
    Sonya "她打开音乐淹没周围的一切"

# game/characters_events_idles/sonya_idles.rpy:220
translate chinese sonya_Idle_evening_girlroom_scene_b0cd0795:

    # Sonya "А я наоборот - выключаю, чтобы услышать хоть что-то своё"
    Sonya "相反，我把它关掉，至少能听到一些我自己的声音。"

# game/characters_events_idles/sonya_idles.rpy:221
translate chinese sonya_Idle_evening_girlroom_scene_7162f44d:

    # gg "Тогда у тебя получается лучше"
    gg "那么你可以做得更好"

# game/characters_events_idles/sonya_idles.rpy:223
translate chinese sonya_Idle_evening_girlroom_scene_b5b15ec8:

    # Sonya "Ну не знаю"
    Sonya "好吧，我不知道"

# game/characters_events_idles/sonya_idles.rpy:224
translate chinese sonya_Idle_evening_girlroom_scene_03522836:

    # Sonya "Просто по-другому"
    Sonya "只是不同"

# game/characters_events_idles/sonya_idles.rpy:238
translate chinese sonya_Idle_night_girlroom_scene_559d1944:

    # gg "Улыбается во сне . . ."
    gg "睡梦中微笑着。 。 。"

# game/characters_events_idles/sonya_idles.rpy:239
translate chinese sonya_Idle_night_girlroom_scene_5651af4c:

    # gg "Интересно, что ей снится, раз выглядит такой довольной"
    gg "我不知道她在做什么梦，因为她看起来很高兴"

# game/characters_events_idles/sonya_idles.rpy:251
translate chinese sonya_Idle_morning_kitchen_scene_0b8a14be:

    # gg "Доброе утро, командир чистоты"
    gg "早上好，纯洁指挥官"

# game/characters_events_idles/sonya_idles.rpy:252
translate chinese sonya_Idle_morning_kitchen_scene_ed136649:

    # Sonya "Кто-то же должен следить, чтобы кухня не превратилась в поле боя"
    Sonya "必须有人确保厨房不会变成战场。"

# game/characters_events_idles/sonya_idles.rpy:254
translate chinese sonya_Idle_morning_kitchen_scene_d094394a:

    # gg "А вдруг Мая проснётся и решит помочь?"
    gg "如果玛雅醒来并决定提供帮助怎么办？"

# game/characters_events_idles/sonya_idles.rpy:256
translate chinese sonya_Idle_morning_kitchen_scene_c681883f:

    # Sonya "Тогда я просто вымою всё заново"
    Sonya "那我就再洗一遍"

# game/characters_events_idles/sonya_idles.rpy:258
translate chinese sonya_Idle_morning_kitchen_scene_f2c9c474:

    # gg "Значит, тебе нравится, когда всё блестит"
    gg "所以你喜欢一切都闪闪发光"

# game/characters_events_idles/sonya_idles.rpy:260
translate chinese sonya_Idle_morning_kitchen_scene_67c74c56:

    # Sonya "Мне нравится, когда всё под контролем"
    Sonya "我喜欢一切都在掌控之中"

# game/characters_events_idles/sonya_idles.rpy:261
translate chinese sonya_Idle_morning_kitchen_scene_86bbbfde:

    # gg "Даже люди?"
    gg "甚至人？"

# game/characters_events_idles/sonya_idles.rpy:264
translate chinese sonya_Idle_morning_kitchen_scene_655f980e:

    # Sonya "С людьми сложнее"
    Sonya "与人相处更困难"

# game/characters_events_idles/sonya_idles.rpy:265
translate chinese sonya_Idle_morning_kitchen_scene_6ae7acf8:

    # Sonya "Они, в отличие от кухни, редко слушаются"
    Sonya "与厨房不同，他们很少服从"

# game/characters_events_idles/sonya_idles.rpy:266
translate chinese sonya_Idle_morning_kitchen_scene_efabb06d:

    # gg "Может, им просто не хватает твоего руководства"
    gg "也许他们只是需要你的指导。"

# game/characters_events_idles/sonya_idles.rpy:268
translate chinese sonya_Idle_morning_kitchen_scene_59bb1b63:

    # Sonya "Осторожнее с комплиментами, а то решу, что ты тоже хочешь быть чистеньким"
    Sonya "恭维的话要小心，不然我就认定你也想干净"

# game/characters_events_idles/sonya_idles.rpy:269
translate chinese sonya_Idle_morning_kitchen_scene_19086387:

    # gg "Обещаю быть примерным"
    gg "我保证成为模范"

# game/characters_events_idles/sonya_idles.rpy:270
translate chinese sonya_Idle_morning_kitchen_scene_de5751f7:

    # gg "Хотя недолго"
    gg "虽然时间不长"

# game/characters_events_idles/sonya_idles.rpy:285
translate chinese sonya_Idle_evening_kitchen_scene_74d26ab6:

    # gg "Пахнет так, будто кто-то очень старается"
    gg "闻起来就像有人很努力"

# game/characters_events_idles/sonya_idles.rpy:287
translate chinese sonya_Idle_evening_kitchen_scene_38676ac8:

    # Sonya "А я и стараюсь"
    Sonya "我正在努力"

# game/characters_events_idles/sonya_idles.rpy:288
translate chinese sonya_Idle_evening_kitchen_scene_adfdb6f3:

    # Sonya "Без рецепта между прочем, просто . . . {w}хочется, чтобы получилось как дома"
    Sonya "顺便说一句，没有处方，只需...... 。 {w}我希望它看起来像家一样"

# game/characters_events_idles/sonya_idles.rpy:289
translate chinese sonya_Idle_evening_kitchen_scene_c3970015:

    # gg "Ты часто так готовишь?"
    gg "你经常这样做饭吗？"

# game/characters_events_idles/sonya_idles.rpy:291
translate chinese sonya_Idle_evening_kitchen_scene_2d72af39:

    # Sonya "Почти каждый день. С детства так привыкла"
    Sonya "几乎每天。我从小就习惯了"

# game/characters_events_idles/sonya_idles.rpy:292
translate chinese sonya_Idle_evening_kitchen_scene_1cbd5882:

    # Sonya "Мне нравилось видеть, как люди садятся за стол и вдруг становятся добрее"
    Sonya "我喜欢看到人们坐下来突然变得更加友善。"

# game/characters_events_idles/sonya_idles.rpy:294
translate chinese sonya_Idle_evening_kitchen_scene_33b06e3d:

    # Sonya "Еда делает людей мягче"
    Sonya "食物使人变得柔和"

# game/characters_events_idles/sonya_idles.rpy:295
translate chinese sonya_Idle_evening_kitchen_scene_4347abfd:

    # Sonya "Даже тех, кто обычно каменные"
    Sonya "即使那些平时是石头的人"

# game/characters_events_idles/sonya_idles.rpy:297
translate chinese sonya_Idle_evening_kitchen_scene_3116970e:

    # gg "Может, потому что через неё ты делишься теплом"
    gg "也许是因为通过它你分享了温暖"

# game/characters_events_idles/sonya_idles.rpy:298
translate chinese sonya_Idle_evening_kitchen_scene_158f9e29:

    # Sonya "Наверное"
    Sonya "或许"

# game/characters_events_idles/sonya_idles.rpy:299
translate chinese sonya_Idle_evening_kitchen_scene_2af7df75:

    # Sonya "Готовить - это ведь не просто накормить"
    Sonya "做饭不只是喂食"

# game/characters_events_idles/sonya_idles.rpy:300
translate chinese sonya_Idle_evening_kitchen_scene_668b4e51:

    # Sonya "Это сказать: “ты можешь остаться”"
    Sonya "这就是说：“你可以留下来”"

# game/characters_events_idles/sonya_idles.rpy:302
translate chinese sonya_Idle_evening_kitchen_scene_8f974346:

    # Sonya "Помню, в детстве всё время помогала на кухне"
    Sonya "我记得当我还是个孩子的时候，我一直在厨房里帮忙。"

# game/characters_events_idles/sonya_idles.rpy:303
translate chinese sonya_Idle_evening_kitchen_scene_970899ee:

    # Sonya "Мама только улыбалась - говорила, что из меня выйдет не повар, а “дом в человеческом виде”"
    Sonya "妈妈只是微笑着说，我不会成为一名厨师，而是成为“人形的房子”。"

# game/characters_events_idles/sonya_idles.rpy:305
translate chinese sonya_Idle_evening_kitchen_scene_22f1390f:

    # gg "Звучит будто про тебя"
    gg "听起来好像是关于你的"

# game/characters_events_idles/sonya_idles.rpy:307
translate chinese sonya_Idle_evening_kitchen_scene_36c5520f:

    # Sonya "Ну вот, ужин готов"
    Sonya "好了，晚餐准备好了"

# game/characters_events_idles/sonya_idles.rpy:308
translate chinese sonya_Idle_evening_kitchen_scene_03998218:

    # Sonya "Без изысков, но с душой"
    Sonya "没有多余的装饰，但有灵魂"

# game/characters_events_idles/sonya_idles.rpy:310
translate chinese sonya_Idle_evening_kitchen_scene_44b18404:

    # gg "Это вкуснее, чем изысканно"
    gg "它比想象的更美味"

# game/characters_events_idles/sonya_idles.rpy:311
translate chinese sonya_Idle_evening_kitchen_scene_16a4231c:

    # Sonya "Вот и хорошо"
    Sonya "那挺好的"

# game/characters_events_idles/sonya_idles.rpy:312
translate chinese sonya_Idle_evening_kitchen_scene_2c2fc2a4:

    # Sonya "Значит, не зря старалась"
    Sonya "所以我的努力并没有白费"

# game/characters_events_idles/sonya_idles.rpy:314
translate chinese sonya_Idle_evening_kitchen_scene_c6bde83f:

    # Sonya "Знаешь, мне нравится кормить людей"
    Sonya "你知道，我喜欢给人喂食"

# game/characters_events_idles/sonya_idles.rpy:315
translate chinese sonya_Idle_evening_kitchen_scene_d763faf1:

    # Sonya "Это самое простое, но честное, что я умею делать"
    Sonya "这是我知道如何做的最简单但最诚实的事情。"

# game/characters_events_idles/sonya_idles.rpy:317
translate chinese sonya_Idle_evening_kitchen_scene_2b0e2ee7:

    # Sonya "Когда кто - то ест то, что ты приготовил, - он словно доверяет тебе"
    Sonya "当有人吃你准备的东西时，就好像他们信任你"

# game/characters_events_idles/sonya_idles.rpy:332
translate chinese sonya_Idle_day_kitchen_scene_ad913161:

    # gg "Всё ещё ждёшь, пока чайник закипит?"
    gg "还在等水壶烧开吗？"

# game/characters_events_idles/sonya_idles.rpy:334
translate chinese sonya_Idle_day_kitchen_scene_7f0755b3:

    # Sonya "Этот чайник кипит только если чувствует внимание. И настроение"
    Sonya "这个水壶只有在感觉到注意时才会沸腾。还有心情"

# game/characters_events_idles/sonya_idles.rpy:336
translate chinese sonya_Idle_day_kitchen_scene_f15d06fa:

    # gg "У него характер как у людей здесь"
    gg "他的性格和这里的人一样"

# game/characters_events_idles/sonya_idles.rpy:337
translate chinese sonya_Idle_day_kitchen_scene_da15dc83:

    # Sonya "Точно. Кстати чтобы узнать получше людей здесь"
    Sonya "确切地。顺便说一句，为了更好地了解这里的人"

# game/characters_events_idles/sonya_idles.rpy:340
translate chinese sonya_Idle_day_kitchen_scene_d5290e36:

    # Sonya "Тут есть пара мест для прогулок"
    Sonya "有几个地方可以步行"

# game/characters_events_idles/sonya_idles.rpy:341
translate chinese sonya_Idle_day_kitchen_scene_9f4c3048:

    # Sonya "Парк — небольшой, но с лавками, где можно застрять на час"
    Sonya "公园虽小，但有长椅，可以坐一个小时"

# game/characters_events_idles/sonya_idles.rpy:343
translate chinese sonya_Idle_day_kitchen_scene_5b433dab:

    # gg "И всё?"
    gg "就这样？"

# game/characters_events_idles/sonya_idles.rpy:345
translate chinese sonya_Idle_day_kitchen_scene_35184686:

    # Sonya "Ещё озеро. Маленькое, но красивое, особенно вечером"
    Sonya "另一个湖。小而美丽，尤其是在晚上"

# game/characters_events_idles/sonya_idles.rpy:346
translate chinese sonya_Idle_day_kitchen_scene_f7d54fda:

    # Sonya "Только вода бодрит так, что потом спать не хочется"
    Sonya "只有水能让你精力充沛，让你睡不着觉"

# game/characters_events_idles/sonya_idles.rpy:348
translate chinese sonya_Idle_day_kitchen_scene_95b73bc9:

    # Sonya "По субботам базар. Там продают всё — от мёда до слухов"
    Sonya "周六有市场。他们在那里卖一切东西——从蜂蜜到谣言"

# game/characters_events_idles/sonya_idles.rpy:349
translate chinese sonya_Idle_day_kitchen_scene_957c11d8:

    # gg "А многоэтажка — это правда?"
    gg "高层建筑是真的吗？"

# game/characters_events_idles/sonya_idles.rpy:351
translate chinese sonya_Idle_day_kitchen_scene_13cd2649:

    # Sonya "Правда. Наш “город в одном доме”"
    Sonya "是真的吗。我们的“一屋之城”"

# game/characters_events_idles/sonya_idles.rpy:352
translate chinese sonya_Idle_day_kitchen_scene_c3a65cd2:

    # Sonya "Там почта, офис и девушка, которая считает себя айтишником"
    Sonya "这里有一个邮局、一个办公室和一个自认为是 IT 专家的女孩。"

# game/characters_events_idles/sonya_idles.rpy:354
translate chinese sonya_Idle_day_kitchen_scene_ed9dc13a:

    # Sonya "Вот и всё веселье. Но если смотреть внимательно — здесь больше жизни, чем кажется"
    Sonya "这就是所有的乐趣。但如果你仔细观察，这里的生命力比看上去的要多"

# game/characters_events_idles/sonya_idles.rpy:369
translate chinese sonya_Idle_morning_myroom_scene_3520e1f4:

    # Sonya "Ой . . . не разбудила?"
    Sonya "哦 。 。 。你没有叫醒我吗？"

# game/characters_events_idles/sonya_idles.rpy:370
translate chinese sonya_Idle_morning_myroom_scene_672ee57f:

    # gg "Нет, просто не привык, что по утрам кто-то сражается с пылью"
    gg "不，我只是不习惯有人在早上与灰尘作斗争"

# game/characters_events_idles/sonya_idles.rpy:372
translate chinese sonya_Idle_morning_myroom_scene_7bcfcbe4:

    # Sonya "У каждого своё утро"
    Sonya "每个人都有属于自己的早晨"

# game/characters_events_idles/sonya_idles.rpy:373
translate chinese sonya_Idle_morning_myroom_scene_125e44ff:

    # Sonya "Моё - с уборки"
    Sonya "我的是清洁后的"

# game/characters_events_idles/sonya_idles.rpy:375
translate chinese sonya_Idle_morning_myroom_scene_00768c69:

    # gg "Не думал, что ты одна из тех, кто так любит уборку"
    gg "我没想到你是那些如此热爱清洁的人之一。"

# game/characters_events_idles/sonya_idles.rpy:377
translate chinese sonya_Idle_morning_myroom_scene_05d695dc:

    # Sonya "Не люблю. {w}Просто, если не я, никто не сделает"
    Sonya "我不喜欢它。 {w}只是如果我不做，就没有人会做"

# game/characters_events_idles/sonya_idles.rpy:378
translate chinese sonya_Idle_morning_myroom_scene_8b5d8733:

    # Sonya "Когда я сюда приехала, дом был знаешь . . . {w}какой-то пустой"
    Sonya "当我来到这里时，这所房子就是你知道的。 。 。 {w}有点空虚"

# game/characters_events_idles/sonya_idles.rpy:379
translate chinese sonya_Idle_morning_myroom_scene_6e4588f3:

    # Sonya "Линда тогда часто уезжала, а Мая только въехала"
    Sonya "那时琳达经常离开，玛雅刚刚搬进来"

# game/characters_events_idles/sonya_idles.rpy:380
translate chinese sonya_Idle_morning_myroom_scene_b07f6cab:

    # Sonya "Всё было вверх дном"
    Sonya "一切都颠倒了"

# game/characters_events_idles/sonya_idles.rpy:381
translate chinese sonya_Idle_morning_myroom_scene_c3dd8e50:

    # Sonya "Я осталась - просто чтобы стало немного тише"
    Sonya "我留下来——只是为了让它安静一点"

# game/characters_events_idles/sonya_idles.rpy:382
translate chinese sonya_Idle_morning_myroom_scene_58c3d544:

    # gg "И осталась до сих пор?"
    gg "它还在吗？"

# game/characters_events_idles/sonya_idles.rpy:384
translate chinese sonya_Idle_morning_myroom_scene_1e7a7a2e:

    # Sonya "Ага. Потом привыкла"
    Sonya "是的。然后我就习惯了"

# game/characters_events_idles/sonya_idles.rpy:385
translate chinese sonya_Idle_morning_myroom_scene_ce824a84:

    # Sonya "Линда как-то сказала, что дом любит, когда в нём кто-то есть"
    Sonya "琳达曾经说过，当有人在里面时，房子就会充满爱"

# game/characters_events_idles/sonya_idles.rpy:387
translate chinese sonya_Idle_morning_myroom_scene_80a846d0:

    # Sonya "Может, я просто не смогла уехать"
    Sonya "也许我只是无法离开"

# game/characters_events_idles/sonya_idles.rpy:389
translate chinese sonya_Idle_morning_myroom_scene_db2e4457:

    # gg "А Мая? Вы ведь такие разные"
    gg "玛雅呢？你是如此不同"

# game/characters_events_idles/sonya_idles.rpy:391
translate chinese sonya_Idle_morning_myroom_scene_55479aec:

    # Sonya "Очень"
    Sonya "非常"

# game/characters_events_idles/sonya_idles.rpy:393
translate chinese sonya_Idle_morning_myroom_scene_e017f5bc:

    # Sonya "Я - про порядок, она - про хаос. Но в этом и суть"
    Sonya "我注重秩序，她注重混乱。但这就是重点"

# game/characters_events_idles/sonya_idles.rpy:396
translate chinese sonya_Idle_morning_myroom_scene_ef1d94c6:

    # Sonya "Знаешь, иногда кажется, что мы друг друга уравновешиваем"
    Sonya "你知道，有时我们似乎互相平衡"

# game/characters_events_idles/sonya_idles.rpy:397
translate chinese sonya_Idle_morning_myroom_scene_77666d07:

    # Sonya "Я заставляю её остановиться, а она - меня жить чуть громче"
    Sonya "我让她停下来，她让我生活得大声一点"

# game/characters_events_idles/sonya_idles.rpy:398
translate chinese sonya_Idle_morning_myroom_scene_686dcb6d:

    # gg "Похоже, вы нашли баланс"
    gg "看来你已经找到了平衡点"

# game/characters_events_idles/sonya_idles.rpy:400
translate chinese sonya_Idle_morning_myroom_scene_8d1d6292:

    # Sonya "Баланс - вещь хрупкая"
    Sonya "平衡是一个脆弱的东西"

# game/characters_events_idles/sonya_idles.rpy:402
translate chinese sonya_Idle_morning_myroom_scene_6e252d73:

    # Sonya "Но, кажется, с тобой он только крепче стал"
    Sonya "但似乎有了你他只会变得更强"

# game/characters_events_idles/sonya_idles.rpy:404
translate chinese sonya_Idle_morning_myroom_scene_2e6e7590:

    # Sonya "В смысле . . . просто в доме стало уютнее"
    Sonya "按照 。 。 。房子变得更舒适了"

# game/characters_events_idles/sonya_idles.rpy:406
translate chinese sonya_Idle_morning_myroom_scene_6bf72907:

    # Sonya "Вот и всё"
    Sonya "就是这样"

# game/characters_events_idles/sonya_idles.rpy:407
translate chinese sonya_Idle_morning_myroom_scene_98ba9030:

    # gg "Конечно. Только уют"
    gg "当然。唯有舒适"

# game/characters_events_idles/sonya_idles.rpy:408
translate chinese sonya_Idle_morning_myroom_scene_af3920fa:

    # Sonya "Вот именно. Только уют"
    Sonya "就是这样。唯有舒适"

# game/characters_events_idles/sonya_idles.rpy:422
translate chinese sonya_Idle_day_myroom_scene_de06330f:

    # gg "Привет за цветами ухаживаешь?"
    gg "你好，请问你养花吗？"

# game/characters_events_idles/sonya_idles.rpy:424
translate chinese sonya_Idle_day_myroom_scene_c76f7e91:

    # Sonya "Знаешь, за цветами нужно постоянно следить"
    Sonya "你知道，你需要经常看花"

# game/characters_events_idles/sonya_idles.rpy:426
translate chinese sonya_Idle_day_myroom_scene_95b1f24a:

    # Sonya "Не слишком много воды, не слишком мало. . . иначе начинают вянуть"
    Sonya "水不能太多，也不能太少。 。 。否则它们就会开始枯萎"

# game/characters_events_idles/sonya_idles.rpy:427
translate chinese sonya_Idle_day_myroom_scene_ae18780a:

    # gg "Значит, всё дело в балансе"
    gg "所以一切都与平衡有关。"

# game/characters_events_idles/sonya_idles.rpy:429
translate chinese sonya_Idle_day_myroom_scene_0e80b509:

    # Sonya "Внимание и время - вот что им действительно нужно"
    Sonya "注意力和时间才是他们真正需要的"

# game/characters_events_idles/sonya_idles.rpy:430
translate chinese sonya_Idle_day_myroom_scene_37400bc6:

    # Sonya "Не полил день - и всё, сразу обижаются"
    Sonya "一天没浇水——就这样，他们立刻就生气了"

# game/characters_events_idles/sonya_idles.rpy:432
translate chinese sonya_Idle_day_myroom_scene_b6abea2a:

    # Sonya "У каждого из них свой характер"
    Sonya "他们每个人都有自己的性格"

# game/characters_events_idles/sonya_idles.rpy:434
translate chinese sonya_Idle_day_myroom_scene_2c042e81:

    # Sonya "Один тянется к свету, другой прячется в тень"
    Sonya "一个伸手寻找光明，另一个隐藏在阴影中"

# game/characters_events_idles/sonya_idles.rpy:435
translate chinese sonya_Idle_day_myroom_scene_bffbba77:

    # Sonya "Есть те, кто растёт быстро, а есть, кому нужно просто больше терпения"
    Sonya "有些人成长得很快，有些人则需要更多耐心。"

# game/characters_events_idles/sonya_idles.rpy:436
translate chinese sonya_Idle_day_myroom_scene_97f84296:

    # gg "Звучит как целая наука"
    gg "听起来像是一门完整的科学"

# game/characters_events_idles/sonya_idles.rpy:438
translate chinese sonya_Idle_day_myroom_scene_bc327c51:

    # Sonya "Может, и так. Только всё приходится чувствовать"
    Sonya "也许是这样。你只需要感受一切"

# game/characters_events_idles/sonya_idles.rpy:440
translate chinese sonya_Idle_day_myroom_scene_16d43fdb:

    # Sonya "Иногда они долго не цветут, и кажется, что всё зря"
    Sonya "有时很久不开花，仿佛一切都是徒然"

# game/characters_events_idles/sonya_idles.rpy:441
translate chinese sonya_Idle_day_myroom_scene_df3dcafe:

    # Sonya "А потом вдруг - один день, и раскрывается бутон"
    Sonya "然后突然间——有一天，一朵花蕾绽放"

# game/characters_events_idles/sonya_idles.rpy:443
translate chinese sonya_Idle_day_myroom_scene_3ee4994e:

    # Sonya "Линда всегда говорила, что цветы живут там, где им хорошо"
    Sonya "琳达总是说花朵生长在感觉良好的地方"

# game/characters_events_idles/sonya_idles.rpy:444
translate chinese sonya_Idle_day_myroom_scene_bfd85b59:

    # Sonya "Не потому что солнце ярче, а потому что рядом кто-то заботится"
    Sonya "不是因为阳光更亮，而是因为附近有人在乎"

# game/characters_events_idles/sonya_idles.rpy:445
translate chinese sonya_Idle_day_myroom_scene_d2c9efc2:

    # gg "Наверное, это правда"
    gg "这可能是真的"

# game/characters_events_idles/sonya_idles.rpy:447
translate chinese sonya_Idle_day_myroom_scene_21a29e18:

    # Sonya "Думаю, да"
    Sonya "我想是的"

# game/characters_events_idles/sonya_idles.rpy:448
translate chinese sonya_Idle_day_myroom_scene_ea189aa5:

    # Sonya "Просто не все замечают, как это важно"
    Sonya "只是并不是每个人都注意到它有多重要"

# game/characters_events_idles/sonya_idles.rpy:449
translate chinese sonya_Idle_day_myroom_scene_98f80f6a:

    # Sonya "Иногда достаточно совсем немного - тепла, слова, присутствия"
    Sonya "有时只需一点点就足够了——温暖、言语、存在"

# game/characters_events_idles/sonya_idles.rpy:451
translate chinese sonya_Idle_day_myroom_scene_c2d87ad5:

    # Sonya "Главное - не перекормить заботой"
    Sonya "最主要的是小心不要过量喂食"

# game/characters_events_idles/sonya_idles.rpy:466
translate chinese sonya_Idle_evening_myroom_scene_21cb43a6:

    # Sonya "Так, у нас есть романтика, комедия, и . . . хоррор"
    Sonya "所以，我们有爱情、喜剧等等。 。恐怖"

# game/characters_events_idles/sonya_idles.rpy:468
translate chinese sonya_Idle_evening_myroom_scene_fd380690:

    # gg "Хоррор? Ты же потом не заснёшь"
    gg "恐怖？以后你就睡不着了"

# game/characters_events_idles/sonya_idles.rpy:470
translate chinese sonya_Idle_evening_myroom_scene_f65cd8c3:

    # Sonya "Ну тогда разбужу тебя и будем болтать до утра . . ."
    Sonya "好吧，我会叫醒你，我们会聊到早上。 。 。"

# game/characters_events_idles/sonya_idles.rpy:471
translate chinese sonya_Idle_evening_myroom_scene_0f687ebc:

    # Sonya "Вместе страдать от бессонницы"
    Sonya "一起失眠"

# game/characters_events_idles/sonya_idles.rpy:472
translate chinese sonya_Idle_evening_myroom_scene_4fc2999c:

    # gg "Ну если ты вдруг случайно начнёшь засыпать - я тебе не дам"
    gg "好吧，如果你突然不小心睡着了，我不会让你"

# game/characters_events_idles/sonya_idles.rpy:474
translate chinese sonya_Idle_evening_myroom_scene_d472f3eb:

    # Sonya "Просто люблю, когда немного страшно"
    Sonya "我只是喜欢它有点可怕的时候"

# game/characters_events_idles/sonya_idles.rpy:475
translate chinese sonya_Idle_evening_myroom_scene_53e63a45:

    # Sonya "В таких фильмах хоть что-то происходит по-настоящему"
    Sonya "至少这些电影中确实发生了一些事情。"

# game/characters_events_idles/sonya_idles.rpy:477
translate chinese sonya_Idle_evening_myroom_scene_80cdfb7b:

    # gg "А ты не боишься?"
    gg "你不害怕吗？"

# game/characters_events_idles/sonya_idles.rpy:479
translate chinese sonya_Idle_evening_myroom_scene_562977d2:

    # Sonya "Боюсь. {w}Но мне нравится, когда страшно только снаружи, а внутри спокойно"
    Sonya "害怕的。 {w}但我喜欢外表吓人但内心平静的感觉"

# game/characters_events_idles/sonya_idles.rpy:481
translate chinese sonya_Idle_evening_myroom_scene_ca77da12:

    # Sonya "Хотя, если вдруг будет слишком жутко - я, может, чуть-чуть прижмусь. Для науки"
    Sonya "不过，如果它突然变得太令人毛骨悚然，也许我会依偎一下。为了科学"

# game/characters_events_idles/sonya_idles.rpy:482
translate chinese sonya_Idle_evening_myroom_scene_c7a5bb2e:

    # gg "Чисто научный эксперимент?"
    gg "纯粹的科学实验？"

# game/characters_events_idles/sonya_idles.rpy:483
translate chinese sonya_Idle_evening_myroom_scene_96d1eac0:

    # Sonya "Конечно. Проверим, снижается ли уровень паники при тесном контакте"
    Sonya "当然。让我们看看恐慌程度是否会随着密切接触而降低"

# game/characters_events_idles/sonya_idles.rpy:487
translate chinese sonya_Idle_evening_myroom_scene_0a9cd91f:

    # Sonya "Вот видишь, уже началось"
    Sonya "你看，已经开始了"

# game/characters_events_idles/sonya_idles.rpy:488
translate chinese sonya_Idle_evening_myroom_scene_4b16a16b:

    # gg "И как результаты эксперимента?"
    gg "实验的结果是什么？"

# game/characters_events_idles/sonya_idles.rpy:490
translate chinese sonya_Idle_evening_myroom_scene_1d60fbd7:

    # Sonya "Пока эффект положительный"
    Sonya "目前来看效果是积极的"

# game/characters_events_idles/sonya_idles.rpy:491
translate chinese sonya_Idle_evening_myroom_scene_c404867c:

    # Sonya "Но для точности нужно дождаться кульминации"
    Sonya "但为了准确，你需要等待高潮"

# game/characters_events_idles/sonya_idles.rpy:492
translate chinese sonya_Idle_evening_myroom_scene_24bf4b87:

    # Sonya "В такие вечера даже страх кажется уютным"
    Sonya "在这样的夜晚，即使是恐惧也显得舒适"

# game/characters_events_idles/sonya_idles.rpy:493
translate chinese sonya_Idle_evening_myroom_scene_741f04d1:

    # gg "Только если есть кому его разделить"
    gg "只要有人可以分享"

# game/characters_events_idles/sonya_idles.rpy:494
translate chinese sonya_Idle_evening_myroom_scene_cf08afaa:

    # Sonya "Думаю, у нас с этим всё в порядке"
    Sonya "我想我们对此没问题"

translate chinese strings:

    # game/characters_events_idles/sonya_idles.rpy:5
    old "Доброе утро"
    new "早上好"

    # game/characters_events_idles/sonya_idles.rpy:48
    old "Потрясающе выглядишь"
    new "你看起来好美"

    # game/characters_events_idles/sonya_idles.rpy:74
    old "Мне пора"
    new "我得走了"

    # game/characters_events_idles/sonya_idles.rpy:138
    old "Привет"
    new "你好"

    # game/characters_events_idles/sonya_idles.rpy:192
    old "Не мешать"
    new "不要干涉"

    # game/characters_events_idles/sonya_idles.rpy:201
    old "Присесть рядом"
    new "坐在我旁边"

    # game/characters_events_idles/sonya_idles.rpy:237
    old "Не тревожить"
    new "请勿打扰"

    # game/characters_events_idles/sonya_idles.rpy:249
    old "С добрым утром"
    new "早上好"

    # game/characters_events_idles/sonya_idles.rpy:274
    old "Позже загляну"
    new "我稍后再回来查看"

    # game/characters_events_idles/sonya_idles.rpy:283
    old "Вкусно пахнет"
    new "闻起来很香"

    # game/characters_events_idles/sonya_idles.rpy:330
    old "Ждешь чайник?"
    new "你在等水壶吗？"

    # game/characters_events_idles/sonya_idles.rpy:367
    old "Опять с тряпкой?"
    new "又用抹布？"

    # game/characters_events_idles/sonya_idles.rpy:464
    old "Что смотрим?"
    new "我们在看什么？"

