﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/maya_events.rpy:24
translate chinese maya_scene1_evening_myroom_ef5d982a:

    # Maya "Да ты издеваешься"
    Maya "你在开玩笑吧"

# game/characters_events_idles/maya_events.rpy:37
translate chinese maya_scene1_evening_myroom_905d33c0:

    # Maya "Где они блин"
    Maya "他们到底在哪里"

# game/characters_events_idles/maya_events.rpy:50
translate chinese maya_scene1_evening_myroom_bd666787:

    # Maya "Тьфу"
    Maya "啊"

# game/characters_events_idles/maya_events.rpy:56
translate chinese maya_scene1_evening_myroom_481be515:

    # Maya "Чё смотришь?"
    Maya "你在看什么？"

# game/characters_events_idles/maya_events.rpy:57
translate chinese maya_scene1_evening_myroom_2ca818a6:

    # gg "Проверь плюс и минус"
    gg "检查正负"

# game/characters_events_idles/maya_events.rpy:58
translate chinese maya_scene1_evening_myroom_4bbab9f1:

    # Maya "Проверяла"
    Maya "我查了一下"

# game/characters_events_idles/maya_events.rpy:94
translate chinese maya_scene2_day_mayaroom_5bb53a51:

    # Maya "Кто там?"
    Maya "谁在那里？"

# game/characters_events_idles/maya_events.rpy:96
translate chinese maya_scene2_day_mayaroom_14a18d19:

    # gg "Это я. Можно зайти по делу?"
    gg "这就是我。我可以进来出差吗？"

# game/characters_events_idles/maya_events.rpy:97
translate chinese maya_scene2_day_mayaroom_1c4734b1:

    # Maya "Входи"
    Maya "进来"

# game/characters_events_idles/maya_events.rpy:105
translate chinese maya_scene2_day_mayaroom_ab7fedad:

    # gg "Музыку слушаешь?"
    gg "你听音乐吗？"

# game/characters_events_idles/maya_events.rpy:107
translate chinese maya_scene2_day_mayaroom_3884c669:

    # Maya "Нет, для соседей включила"
    Maya "不，我为邻居打开了它"

# game/characters_events_idles/maya_events.rpy:111
translate chinese maya_scene2_day_mayaroom_837eef0f:

    # gg "Я решил, что останусь тут"
    gg "我决定留在这里"

# game/characters_events_idles/maya_events.rpy:113
translate chinese maya_scene2_day_mayaroom_95020588:

    # gg "Буду жить здесь"
    gg "我会住在这里"

# game/characters_events_idles/maya_events.rpy:115
translate chinese maya_scene2_day_mayaroom_bca52f7e:

    # Maya "Ну"
    Maya "出色地"

# game/characters_events_idles/maya_events.rpy:117
translate chinese maya_scene2_day_mayaroom_705e10f4:

    # Maya "Соболезную"
    Maya "我的哀悼"

# game/characters_events_idles/maya_events.rpy:125
translate chinese maya_scene2_day_mayaroom_27c60573:

    # Maya "Эй"
    Maya "嘿"

# game/characters_events_idles/maya_events.rpy:127
translate chinese maya_scene2_day_mayaroom_40785e40:

    # Maya "Дальше не надо"
    Maya "不再需要"

# game/characters_events_idles/maya_events.rpy:129
translate chinese maya_scene2_day_mayaroom_5f49e73a:

    # gg "Я просто хотел"
    gg "我只是想要"

# game/characters_events_idles/maya_events.rpy:131
translate chinese maya_scene2_day_mayaroom_16e0a365:

    # Maya "Я всё услышала"
    Maya "我听到了一切"

# game/characters_events_idles/maya_events.rpy:133
translate chinese maya_scene2_day_mayaroom_c48134de:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "我不在乎你住在这里"

# game/characters_events_idles/maya_events.rpy:135
translate chinese maya_scene2_day_mayaroom_df1954ea:

    # Maya "Честно"
    Maya "诚实地"

# game/characters_events_idles/maya_events.rpy:139
translate chinese maya_scene2_day_mayaroom_df3a4321:

    # Maya "Но давай без этого"
    Maya "但我们还是不要它吧"

# game/characters_events_idles/maya_events.rpy:141
translate chinese maya_scene2_day_mayaroom_e6c85abf:

    # gg "Без чего?"
    gg "没有什么？"

# game/characters_events_idles/maya_events.rpy:143
translate chinese maya_scene2_day_mayaroom_d4ddd213:

    # Maya "Без контроля"
    Maya "无法控制"

# game/characters_events_idles/maya_events.rpy:145
translate chinese maya_scene2_day_mayaroom_bc54c15e:

    # Maya "Без «я помогу»"
    Maya "没有“我会帮忙”"

# game/characters_events_idles/maya_events.rpy:147
translate chinese maya_scene2_day_mayaroom_7a220c2f:

    # gg "Я не про контроль"
    gg "我不是在谈论控制"

# game/characters_events_idles/maya_events.rpy:148
translate chinese maya_scene2_day_mayaroom_dabe88df:

    # gg "Если по дому что-то"
    gg "如果房子周围有什么东西"

# game/characters_events_idles/maya_events.rpy:152
translate chinese maya_scene2_day_mayaroom_723b85d3:

    # Maya "Мне не нужна опека"
    Maya "我不需要监护"

# game/characters_events_idles/maya_events.rpy:154
translate chinese maya_scene2_day_mayaroom_cad2c7d3:

    # gg "Я не это имел в виду"
    gg "我不是那个意思"

# game/characters_events_idles/maya_events.rpy:156
translate chinese maya_scene2_day_mayaroom_e9decfdb:

    # Maya "А звучит именно так"
    Maya "这正是它听起来的样子"

# game/characters_events_idles/maya_events.rpy:158
translate chinese maya_scene2_day_mayaroom_c48134de_1:

    # Maya "Мне пофиг, что ты тут живёшь"
    Maya "我不在乎你住在这里"

# game/characters_events_idles/maya_events.rpy:160
translate chinese maya_scene2_day_mayaroom_3e5d6dd4:

    # Maya "Просто"
    Maya "只是"

# game/characters_events_idles/maya_events.rpy:162
translate chinese maya_scene2_day_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "不要干涉"

# game/characters_events_idles/maya_events.rpy:164
translate chinese maya_scene2_day_mayaroom_9727ea24:

    # Maya "В личное"
    Maya "就个人而言"

# game/characters_events_idles/maya_events.rpy:166
translate chinese maya_scene2_day_mayaroom_44696bee:

    # gg "Я понял"
    gg "我明白"

# game/characters_events_idles/maya_events.rpy:168
translate chinese maya_scene2_day_mayaroom_97fa7b2b:

    # Maya "И дверь закрывай"
    Maya "并关上门"

# game/characters_events_idles/maya_events.rpy:170
translate chinese maya_scene2_day_mayaroom_367b11d8:

    # Maya "Я не фанат"
    Maya "我不是粉丝"

# game/characters_events_idles/maya_events.rpy:171
translate chinese maya_scene2_day_mayaroom_5e882c77:

    # Maya "Открытых пространств"
    Maya "开放空间"

# game/characters_events_idles/maya_events.rpy:198
translate chinese maya_scene3_evening_kitchen_9a8b0be2:

    # gg "Привет"
    gg "你好"

# game/characters_events_idles/maya_events.rpy:211
translate chinese maya_scene3_evening_kitchen_a356674e:

    # gg "Тебе еще кофе принести?"
    gg "我需要再给你拿点咖啡吗？"

# game/characters_events_idles/maya_events.rpy:213
translate chinese maya_scene3_evening_kitchen_9a5dd35b:

    # Maya "Нет"
    Maya "不"

# game/characters_events_idles/maya_events.rpy:225
translate chinese maya_scene3_evening_kitchen_00c41c60:

    # Maya "Не . . ."
    Maya "不是 。 。 。"

# game/characters_events_idles/maya_events.rpy:227
translate chinese maya_scene3_evening_kitchen_059eb6da:

    # gg "Что?"
    gg "什么？"

# game/characters_events_idles/maya_events.rpy:229
translate chinese maya_scene3_evening_kitchen_5c02f51f:

    # Maya "Ты вообще"
    Maya "你到底是不是"

# game/characters_events_idles/maya_events.rpy:231
translate chinese maya_scene3_evening_kitchen_c954c369:

    # Maya "Ты зачем так близко?"
    Maya "为什么你们离得这么近？"

# game/characters_events_idles/maya_events.rpy:233
translate chinese maya_scene3_evening_kitchen_7de3a2ef:

    # gg "Я просто"
    gg "我只是"

# game/characters_events_idles/maya_events.rpy:235
translate chinese maya_scene3_evening_kitchen_25f0ffea:

    # Maya "Я сказала, не надо"
    Maya "我说不需要"

# game/characters_events_idles/maya_events.rpy:237
translate chinese maya_scene3_evening_kitchen_91d73b20:

    # Maya "И не звала"
    Maya "而且我没有打电话"

# game/characters_events_idles/maya_events.rpy:241
translate chinese maya_scene3_evening_kitchen_e10a0eab:

    # Maya "Мне нужно было просто кофе"
    Maya "我只需要咖啡"

# game/characters_events_idles/maya_events.rpy:243
translate chinese maya_scene3_evening_kitchen_a41fbef3:

    # gg "Подожди"
    gg "等待"

# game/characters_events_idles/maya_events.rpy:245
translate chinese maya_scene3_evening_kitchen_c8225194:

    # Maya "Не сейчас"
    Maya "现在不要"

# game/characters_events_idles/maya_events.rpy:252
translate chinese maya_scene3_evening_kitchen_0d9a221f:

    # gg_chat "Как бы мне с ней поговорить"
    gg_chat "我怎样才能和她说话呢？"

# game/characters_events_idles/maya_events.rpy:263
translate chinese maya_scene4_morning_mayaroom_d3734f64:

    # Maya "Да что ж"
    Maya "那好吧"

# game/characters_events_idles/maya_events.rpy:265
translate chinese maya_scene4_morning_mayaroom_fa8ea266:

    # Maya "Ну давай же"
    Maya "那就来吧"

# game/characters_events_idles/maya_events.rpy:271
translate chinese maya_scene4_morning_mayaroom_d944481b:

    # gg "Опять воюешь с техникой?"
    gg "你又跟科技较量了吗？"

# game/characters_events_idles/maya_events.rpy:273
translate chinese maya_scene4_morning_mayaroom_b6f44dea:

    # Maya "Все работало час назад"
    Maya "一小时前一切正常"

# game/characters_events_idles/maya_events.rpy:275
translate chinese maya_scene4_morning_mayaroom_743f87c9:

    # gg "На вид, пауза — у меня была похожая проблема"
    gg "看起来像是暂停 - 我也遇到了类似的问题"

# game/characters_events_idles/maya_events.rpy:277
translate chinese maya_scene4_morning_mayaroom_5b9f31c5:

    # Maya "Конечно. У нашего местного игромана, разумеется, был подобный опыт"
    Maya "当然。当然，我们当地的赌瘾者也有类似的经历"

# game/characters_events_idles/maya_events.rpy:279
translate chinese maya_scene4_morning_mayaroom_d67e684e:

    # gg "Это решается проще, чем кажется"
    gg "这比看起来更容易解决"

# game/characters_events_idles/maya_events.rpy:281
translate chinese maya_scene4_morning_mayaroom_6ac6687a:

    # Maya "Я разберусь"
    Maya "我会弄清楚的"

# game/characters_events_idles/maya_events.rpy:285
translate chinese maya_scene4_morning_mayaroom_ef21c62b:

    # Maya "Ладно поскольку ты уже встал тут в позу спасителя"
    Maya "好吧，既然你已经摆出救世主的姿势了"

# game/characters_events_idles/maya_events.rpy:287
translate chinese maya_scene4_morning_mayaroom_e4eef199:

    # Maya "Смотри"
    Maya "看"

# game/characters_events_idles/maya_events.rpy:289
translate chinese maya_scene4_morning_mayaroom_b05b1e64:

    # Maya "Но если сломаешь новый купишь"
    Maya "但如果坏了就买一个新的"

# game/characters_events_idles/maya_events.rpy:291
translate chinese maya_scene4_morning_mayaroom_2406a76f:

    # gg_chat "Так посмотрим"
    gg_chat "那么让我们看看"

# game/characters_events_idles/maya_events.rpy:293
translate chinese maya_scene4_morning_mayaroom_3eccec99:

    # Maya "Только давай без «я же говорил»"
    Maya "只是不要说“我告诉过你了”"

# game/characters_events_idles/maya_events.rpy:295
translate chinese maya_scene4_morning_mayaroom_edca7a30:

    # gg "Хорошо Не собирался"
    gg "好吧我不是故意的"

# game/characters_events_idles/maya_events.rpy:300
translate chinese maya_scene4_morning_mayaroom_33712776:

    # Maya "Главное делай вид, что понимаешь"
    Maya "最重要的是假装你明白"

# game/characters_events_idles/maya_events.rpy:306
translate chinese maya_scene4_morning_mayaroom_726d3183:

    # Maya "Ты что сделал?"
    Maya "你做了什么？"

# game/characters_events_idles/maya_events.rpy:309
translate chinese maya_scene4_morning_mayaroom_5de5e399:

    # Maya "Показывай"
    Maya "给我看看"

# game/characters_events_idles/maya_events.rpy:311
translate chinese maya_scene4_morning_mayaroom_4572bfad:

    # Maya "Я уже готовлюсь к разочарованию"
    Maya "我已经做好失望的准备了"

# game/characters_events_idles/maya_events.rpy:313
translate chinese maya_scene4_morning_mayaroom_6c571b22:

    # gg "Пока ничего критичного"
    gg "还没有什么关键的事情"

# game/characters_events_idles/maya_events.rpy:315
translate chinese maya_scene4_morning_mayaroom_eab0c0bf:

    # Maya "Угу"
    Maya "是的"

# game/characters_events_idles/maya_events.rpy:319
translate chinese maya_scene4_morning_mayaroom_4506bcc5:

    # Maya "Эй!"
    Maya "嘿！"

# game/characters_events_idles/maya_events.rpy:321
translate chinese maya_scene4_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "停止"

# game/characters_events_idles/maya_events.rpy:323
translate chinese maya_scene4_morning_mayaroom_5144b708:

    # gg "Что"
    gg "什么"

# game/characters_events_idles/maya_events.rpy:325
translate chinese maya_scene4_morning_mayaroom_cfa517d6:

    # Maya "Не надо ко мне лезть"
    Maya "别来找我"

# game/characters_events_idles/maya_events.rpy:327
translate chinese maya_scene4_morning_mayaroom_1400ea9e:

    # gg "Ты сама"
    gg "你自己"

# game/characters_events_idles/maya_events.rpy:329
translate chinese maya_scene4_morning_mayaroom_fd37247c:

    # Maya "Цыц"
    Maya "齐茨"

# game/characters_events_idles/maya_events.rpy:333
translate chinese maya_scene4_morning_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "忘了它"

# game/characters_events_idles/maya_events.rpy:337
translate chinese maya_scene4_morning_mayaroom_d09026b0:

    # Maya "Уже не важно"
    Maya "已经不重要了"

# game/characters_events_idles/maya_events.rpy:339
translate chinese maya_scene4_morning_mayaroom_98444aa5:

    # Maya "Я разберусь потом"
    Maya "我稍后会弄清楚"

# game/characters_events_idles/maya_events.rpy:341
translate chinese maya_scene4_morning_mayaroom_d2acc454:

    # gg "Я же просто"
    gg "我只是"

# game/characters_events_idles/maya_events.rpy:343
translate chinese maya_scene4_morning_mayaroom_e0da4bdd:

    # Maya "Я сказала потом"
    Maya "我后来说"

# game/characters_events_idles/maya_events.rpy:349
translate chinese maya_scene4_morning_mayaroom_d821f777:

    # gg_chat "Нужно дать ей время"
    gg_chat "我们需要给她时间"

# game/characters_events_idles/maya_events.rpy:360
translate chinese maya_scene5_night_mayaroom_63a0d7ed:

    # gg "Я зайду"
    gg "我会过来"

# game/characters_events_idles/maya_events.rpy:364
translate chinese maya_scene5_night_mayaroom_6c5edc69:

    # gg "Слушай . . ."
    gg "听 。 。 。"

# game/characters_events_idles/maya_events.rpy:366
translate chinese maya_scene5_night_mayaroom_68ee26d9:

    # gg "Я хочу понять"
    gg "我想了解"

# game/characters_events_idles/maya_events.rpy:368
translate chinese maya_scene5_night_mayaroom_bc1e3bb5:

    # gg "Ты всё время"
    gg "时时刻刻的你"

# game/characters_events_idles/maya_events.rpy:369
translate chinese maya_scene5_night_mayaroom_024d1c74:

    # gg "Отталкиваешь"
    gg "你推开"

# game/characters_events_idles/maya_events.rpy:370
translate chinese maya_scene5_night_mayaroom_8f03bb39:

    # gg "Резко"
    gg "锋利的"

# game/characters_events_idles/maya_events.rpy:372
translate chinese maya_scene5_night_mayaroom_e92f63ca:

    # gg "Я не всегда понимаю"
    gg "我总是不明白"

# game/characters_events_idles/maya_events.rpy:373
translate chinese maya_scene5_night_mayaroom_fc49f049:

    # gg "Где именно граница"
    gg "边界到底在哪里"

# game/characters_events_idles/maya_events.rpy:375
translate chinese maya_scene5_night_mayaroom_6d2d9756:

    # Maya "Да нигде"
    Maya "无处"

# game/characters_events_idles/maya_events.rpy:377
translate chinese maya_scene5_night_mayaroom_5c27dae4:

    # Maya "Хочешь границы -"
    Maya "你想要界限吗——"

# game/characters_events_idles/maya_events.rpy:378
translate chinese maya_scene5_night_mayaroom_bf517861:

    # Maya "Не лезь"
    Maya "不要干涉"

# game/characters_events_idles/maya_events.rpy:379
translate chinese maya_scene5_night_mayaroom_71b4348e:

    # gg "Я не . . .{nw=0.3}"
    gg "我不知道。 。 .{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:381
translate chinese maya_scene5_night_mayaroom_3a7c36e6:

    # Maya "Не надо"
    Maya "不需要"

# game/characters_events_idles/maya_events.rpy:383
translate chinese maya_scene5_night_mayaroom_11f3acdb:

    # Maya "Не делай вид"
    Maya "别假装"

# game/characters_events_idles/maya_events.rpy:384
translate chinese maya_scene5_night_mayaroom_e9a71e8d:

    # Maya "Что ты тут ни при чём"
    Maya "与你无关"

# game/characters_events_idles/maya_events.rpy:386
translate chinese maya_scene5_night_mayaroom_734313d9:

    # gg "Я не пытаюсь давить"
    gg "我并不想推动"

# game/characters_events_idles/maya_events.rpy:387
translate chinese maya_scene5_night_mayaroom_e3709e94:

    # gg "Я просто . . .{nw=0.3}"
    gg "我只是。 。 .{nw=0.3}"

# game/characters_events_idles/maya_events.rpy:389
translate chinese maya_scene5_night_mayaroom_76c878d4:

    # Maya "Ты всегда «просто»"
    Maya "你总是“简单”"

# game/characters_events_idles/maya_events.rpy:391
translate chinese maya_scene5_night_mayaroom_7125aff8:

    # Maya "Просто заходишь"
    Maya "刚进来"

# game/characters_events_idles/maya_events.rpy:392
translate chinese maya_scene5_night_mayaroom_8803de0c:

    # Maya "Просто начинаешь разговор"
    Maya "刚刚开始对话"

# game/characters_events_idles/maya_events.rpy:394
translate chinese maya_scene5_night_mayaroom_30ca9380:

    # Maya "Просто помогаешь"
    Maya "你只是帮忙而已"

# game/characters_events_idles/maya_events.rpy:396
translate chinese maya_scene5_night_mayaroom_a04f159c:

    # Maya "{sc}Это бесит{/sc}"
    Maya "{sc}这很烦人{/sc}"

# game/characters_events_idles/maya_events.rpy:398
translate chinese maya_scene5_night_mayaroom_3a8f909d:

    # Maya "Всё"
    Maya "全部"

# game/characters_events_idles/maya_events.rpy:400
translate chinese maya_scene5_night_mayaroom_4d5d0603:

    # Maya "Разговор окончен"
    Maya "谈话结束了"

# game/characters_events_idles/maya_events.rpy:404
translate chinese maya_scene5_night_mayaroom_37d7c2ce:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Прости"
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}抱歉"

# game/characters_events_idles/maya_events.rpy:410
translate chinese maya_scene5_night_mayaroom_2336b49e:

    # Maya "Хотя нет"
    Maya "虽然没有"

# game/characters_events_idles/maya_events.rpy:412
translate chinese maya_scene5_night_mayaroom_9761ec25:

    # Maya "Забей"
    Maya "忘了它"

# game/characters_events_idles/maya_events.rpy:426
translate chinese maya_scene5_night_mayaroom_74fb972d:

    # Maya "{bt=a3-p2.0-s3.0}{size=*0.8}Я . . ."
    Maya "{bt=a3-p2.0-s3.0}{size=*0.8}我是。 。 。"

# game/characters_events_idles/maya_events.rpy:428
translate chinese maya_scene5_night_mayaroom_922caaa0:

    # Maya "Не это имела в виду"
    Maya "我不是那个意思"

# game/characters_events_idles/maya_events.rpy:430
translate chinese maya_scene5_night_mayaroom_3a8f909d_1:

    # Maya "Всё"
    Maya "全部"

# game/characters_events_idles/maya_events.rpy:432
translate chinese maya_scene5_night_mayaroom_00c0f420:

    # Maya "Иди"
    Maya "去"

# game/characters_events_idles/maya_events.rpy:435
translate chinese maya_scene5_night_mayaroom_d0668ccb:

    # Maya "Я сказала — иди{nw=2}"
    Maya "我说走{nw=2}"

# game/characters_events_idles/maya_events.rpy:463
translate chinese maya_scene6_evening_myroom_8846d5d4:

    # Maya "Ты сидишь будто"
    Maya "你坐着，仿佛"

# game/characters_events_idles/maya_events.rpy:465
translate chinese maya_scene6_evening_myroom_c3936052:

    # Maya "Ничего не было"
    Maya "什么也没有"

# game/characters_events_idles/maya_events.rpy:467
translate chinese maya_scene6_evening_myroom_ba188167:

    # gg "Я не делаю вид"
    gg "我不假装"

# game/characters_events_idles/maya_events.rpy:469
translate chinese maya_scene6_evening_myroom_4dd50b6c:

    # Maya "Ладно, не важно"
    Maya "好吧，没关系"

# game/characters_events_idles/maya_events.rpy:471
translate chinese maya_scene6_evening_myroom_7eaa97d1:

    # Maya "Залипай дальше"
    Maya "继续坚持"

# game/characters_events_idles/maya_events.rpy:479
translate chinese maya_scene6_evening_myroom_3c725bc9:

    # Maya "Слушай"
    Maya "听"

# game/characters_events_idles/maya_events.rpy:480
translate chinese maya_scene6_evening_myroom_250ec1e3:

    # Maya "А ты сейчас сильно занят?"
    Maya "你现在很忙吗？"

# game/characters_events_idles/maya_events.rpy:482
translate chinese maya_scene6_evening_myroom_5ea33f12:

    # gg "Если честно — нет"
    gg "老实说——不"

# game/characters_events_idles/maya_events.rpy:486
translate chinese maya_scene6_evening_myroom_f9cfb58e:

    # Maya "Я просто спросила"
    Maya "我刚问"

# game/characters_events_idles/maya_events.rpy:488
translate chinese maya_scene6_evening_myroom_70c7e32f:

    # gg "А я просто отвечаю"
    gg "而我只是回答"

# game/characters_events_idles/maya_events.rpy:489
translate chinese maya_scene6_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya "。 。 。"

# game/characters_events_idles/maya_events.rpy:491
translate chinese maya_scene6_evening_myroom_a2fcb33c:

    # Maya "Поможешь мне кое с чем"
    Maya "你能帮我做点什么吗？"

# game/characters_events_idles/maya_events.rpy:493
translate chinese maya_scene6_evening_myroom_19d648ec:

    # Maya "Это быстро"
    Maya "速度很快"

# game/characters_events_idles/maya_events.rpy:497
translate chinese maya_scene6_evening_myroom_9619af02:

    # gg "С чем?"
    gg "用什么？"

# game/characters_events_idles/maya_events.rpy:499
translate chinese maya_scene6_evening_myroom_0b3abc75:

    # Maya "Потом увидишь"
    Maya "然后你会看到"

# game/characters_events_idles/maya_events.rpy:510
translate chinese maya_scene6_evening_myroom_5529e2cd:

    # Maya "Только без лишней заботы"
    Maya "只是没有不必要的担心"

# game/characters_events_idles/maya_events.rpy:512
translate chinese maya_scene6_evening_myroom_52df9211:

    # gg "Как скажешь"
    gg "正如你所说"

# game/characters_events_idles/maya_events.rpy:514
translate chinese maya_scene6_evening_myroom_3226a25c:

    # Maya "Посмотрим на что ты способен"
    Maya "让我们看看你能做什么"

# game/characters_events_idles/maya_events.rpy:516
translate chinese maya_scene6_evening_myroom_bca52f7e:

    # Maya "Ну"
    Maya "出色地"

# game/characters_events_idles/maya_events.rpy:518
translate chinese maya_scene6_evening_myroom_1771af09:

    # Maya "Вот"
    Maya "这里"

# game/characters_events_idles/maya_events.rpy:520
translate chinese maya_scene6_evening_myroom_ba718844:

    # Maya "Что застыл"
    Maya "什么冻结了"

# game/characters_events_idles/maya_events.rpy:522
translate chinese maya_scene6_evening_myroom_806872f9:

    # gg "О и давно у тебя это?"
    gg "哦，你这样多久了？"

# game/characters_events_idles/maya_events.rpy:524
translate chinese maya_scene6_evening_myroom_7d6ca25f:

    # Maya "Очень"
    Maya "非常"

# game/characters_events_idles/maya_events.rpy:525
translate chinese maya_scene6_evening_myroom_40562848:

    # Maya "Ещё когда я делала вид"
    Maya "即使我假装"

# game/characters_events_idles/maya_events.rpy:527
translate chinese maya_scene6_evening_myroom_0b5a891a:

    # Maya "Что у меня есть дисциплина"
    Maya "我有纪律"

# game/characters_events_idles/maya_events.rpy:529
translate chinese maya_scene6_evening_myroom_51392b4e:

    # gg "В смысле?"
    gg "按照？"

# game/characters_events_idles/maya_events.rpy:531
translate chinese maya_scene6_evening_myroom_4a4b36f7:

    # Maya "Спорт"
    Maya "运动"

# game/characters_events_idles/maya_events.rpy:533
translate chinese maya_scene6_evening_myroom_bec9192a:

    # Maya "Секции, график, «надо»"
    Maya "章节、时间表、“必须”"

# game/characters_events_idles/maya_events.rpy:535
translate chinese maya_scene6_evening_myroom_201efa03:

    # Maya "Потом одна удачная травма"
    Maya "然后幸运的受伤了"

# game/characters_events_idles/maya_events.rpy:537
translate chinese maya_scene6_evening_myroom_c633060c:

    # Maya "И всё"
    Maya "就这样"

# game/characters_events_idles/maya_events.rpy:539
translate chinese maya_scene6_evening_myroom_46291e24:

    # Maya "Цирк закрылся"
    Maya "马戏团已经关门了"

# game/characters_events_idles/maya_events.rpy:541
translate chinese maya_scene6_evening_myroom_d39d8973:

    # gg "И ты бросила?"
    gg "然后你就放弃了？"

# game/characters_events_idles/maya_events.rpy:543
translate chinese maya_scene6_evening_myroom_9d7ad38f:

    # Maya "Я бы назвала это"
    Maya "我会称之为"

# game/characters_events_idles/maya_events.rpy:545
translate chinese maya_scene6_evening_myroom_ceee3b55:

    # Maya "«Энергосберегающий режим»"
    Maya "“节能模式”"

# game/characters_events_idles/maya_events.rpy:549
translate chinese maya_scene6_evening_myroom_9a044748:

    # gg "Теперь понятно почему ты так реагируешь"
    gg "现在我明白你为什么会有这样的反应"

# game/characters_events_idles/maya_events.rpy:551
translate chinese maya_scene6_evening_myroom_5a3ffd6f:

    # Maya "Я просто не люблю"
    Maya "我只是不喜欢"

# game/characters_events_idles/maya_events.rpy:552
translate chinese maya_scene6_evening_myroom_2b6fd943:

    # Maya "Когда кто-то начинает"
    Maya "当有人开始"

# game/characters_events_idles/maya_events.rpy:554
translate chinese maya_scene6_evening_myroom_8f57b276:

    # Maya "Объяснять мне как жить"
    Maya "向我解释如何生活"

# game/characters_events_idles/maya_events.rpy:557
translate chinese maya_scene6_evening_myroom_55d8d51b:

    # Maya "Вообщем нужно нанести крем и забинтовать"
    Maya "一般来说，需要涂抹药膏并包扎起来"

# game/characters_events_idles/maya_events.rpy:559
translate chinese maya_scene6_evening_myroom_a23c1350:

    # gg "А к Соне почему не пошла?"
    gg "你为什么不去找索尼娅？"

# game/characters_events_idles/maya_events.rpy:561
translate chinese maya_scene6_evening_myroom_17ee92c5:

    # Maya "По той же причине, а еще"
    Maya "出于同样的原因，也"

# game/characters_events_idles/maya_events.rpy:562
translate chinese maya_scene6_evening_myroom_6a81a1e1:

    # Maya "Это всегда превращается"
    Maya "总是会转"

# game/characters_events_idles/maya_events.rpy:564
translate chinese maya_scene6_evening_myroom_f5a6f373:

    # Maya "В «давай я»"
    Maya "在“让我”中"

# game/characters_events_idles/maya_events.rpy:566
translate chinese maya_scene6_evening_myroom_5d26e27b:

    # Maya "Она начинает суетиться"
    Maya "她开始大惊小怪"

# game/characters_events_idles/maya_events.rpy:567
translate chinese maya_scene6_evening_myroom_c1824ee1:

    # Maya "Делать больше, чем надо"
    Maya "做超出必要的事情"

# game/characters_events_idles/maya_events.rpy:569
translate chinese maya_scene6_evening_myroom_9ad0074f:

    # Maya "А потом я виноватой себя чувствую"
    Maya "然后我感到内疚"

# game/characters_events_idles/maya_events.rpy:571
translate chinese maya_scene6_evening_myroom_ae8589c0:

    # gg "Кажется это называется забота"
    gg "我想这才叫关怀"

# game/characters_events_idles/maya_events.rpy:573
translate chinese maya_scene6_evening_myroom_a240282b:

    # Maya "Тогда давай посмотрим на твою заботу"
    Maya "那我们就看看你有多在乎"

# game/characters_events_idles/maya_events.rpy:575
translate chinese maya_scene6_evening_myroom_29c79ddd:

    # Maya "Надеюсь только без драм"
    Maya "希望没有剧情"

# game/characters_events_idles/maya_events.rpy:577
translate chinese maya_scene6_evening_myroom_63c1dadc:

    # gg "Не собирался"
    gg "我不是故意的"

# game/characters_events_idles/maya_events.rpy:582
translate chinese maya_scene6_evening_myroom_41f1b09f:

    # gg "Можно?"
    gg "能？"

# game/characters_events_idles/maya_events.rpy:590
translate chinese maya_scene6_evening_myroom_43813c59:

    # Maya "Не бойся"
    Maya "别害怕"

# game/characters_events_idles/maya_events.rpy:591
translate chinese maya_scene6_evening_myroom_d139c2b0:

    # Maya "Я не из хрусталя"
    Maya "我不是水晶做的"

# game/characters_events_idles/maya_events.rpy:594
translate chinese maya_scene6_evening_myroom_590f3ec6:

    # Maya "Ты всегда такой спокойный?"
    Maya "你总是这么冷静吗？"

# game/characters_events_idles/maya_events.rpy:595
translate chinese maya_scene6_evening_myroom_79f7b16f:

    # gg "Не всегда"
    gg "并不总是"

# game/characters_events_idles/maya_events.rpy:597
translate chinese maya_scene6_evening_myroom_481c4421:

    # gg "Просто сейчас{w} нет смысла психовать"
    gg "现在没有必要惊慌{w}"

# game/characters_events_idles/maya_events.rpy:599
translate chinese maya_scene6_evening_myroom_d38be043:

    # Maya "Понятно"
    Maya "天气晴朗"

# game/characters_events_idles/maya_events.rpy:600
translate chinese maya_scene6_evening_myroom_41f6003e:

    # Maya "Экономишь нервы"
    Maya "拯救你的神经"

# game/characters_events_idles/maya_events.rpy:601
translate chinese maya_scene6_evening_myroom_9ea43bc7:

    # Maya "Умно"
    Maya "聪明的"

# game/characters_events_idles/maya_events.rpy:603
translate chinese maya_scene6_evening_myroom_b413e8d5:

    # gg "Можно сказать и так"
    gg "你可以这样说"

# game/characters_events_idles/maya_events.rpy:606
translate chinese maya_scene6_evening_myroom_ea2de26b:

    # Maya "Теперь бинтуй"
    Maya "现在绷带"

# game/characters_events_idles/maya_events.rpy:614
translate chinese maya_scene6_evening_myroom_69d52a38:

    # Maya "Левее"
    Maya "向左转"

# game/characters_events_idles/maya_events.rpy:618
translate chinese maya_scene6_evening_myroom_a9d70df9:

    # Maya "Нет{w} стой"
    Maya "无需{w}等待"

# game/characters_events_idles/maya_events.rpy:620
translate chinese maya_scene6_evening_myroom_4b3bbffe:

    # Maya "Вот так"
    Maya "像这样"

# game/characters_events_idles/maya_events.rpy:624
translate chinese maya_scene6_evening_myroom_9ee64c2c:

    # Maya "Ты вообще смотришь, что делаешь?"
    Maya "你甚至注意自己在做什么吗？"

# game/characters_events_idles/maya_events.rpy:626
translate chinese maya_scene6_evening_myroom_d39f0951:

    # gg "Мая"
    gg "可能"

# game/characters_events_idles/maya_events.rpy:628
translate chinese maya_scene6_evening_myroom_4e31a75d:

    # Maya "Нет, серьёзно"
    Maya "不，说真的"

# game/characters_events_idles/maya_events.rpy:629
translate chinese maya_scene6_evening_myroom_6049c785:

    # Maya "Ты сейчас наугад это бинтуешь"
    Maya "现在你随意地包扎它"

# game/characters_events_idles/maya_events.rpy:631
translate chinese maya_scene6_evening_myroom_7e1fd344:

    # Maya "Или делаешь вид"
    Maya "还是你在假装"

# game/characters_events_idles/maya_events.rpy:632
translate chinese maya_scene6_evening_myroom_84eb66b2:

    # Maya "Что уверен"
    Maya "我确信"

# game/characters_events_idles/maya_events.rpy:637
translate chinese maya_scene6_evening_myroom_d39f0951_1:

    # gg "Мая"
    gg "可能"

# game/characters_events_idles/maya_events.rpy:639
translate chinese maya_scene6_evening_myroom_9db87034:

    # gg "Если тебе так проще - я выйду"
    gg "如果你方便的话我就出去"

# game/characters_events_idles/maya_events.rpy:641
translate chinese maya_scene6_evening_myroom_eb8fc374:

    # Maya "Подожди"
    Maya "等待"

# game/characters_events_idles/maya_events.rpy:647
translate chinese maya_scene6_evening_myroom_43dc5209:

    # Maya "Я . . .{w} не это имела в виду"
    Maya "我 。 。 .{w}不是这个意思"

# game/characters_events_idles/maya_events.rpy:649
translate chinese maya_scene6_evening_myroom_e89a435e:

    # Maya "Просто . . ."
    Maya "只是 。 。 。"

# game/characters_events_idles/maya_events.rpy:651
translate chinese maya_scene6_evening_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "别走"

# game/characters_events_idles/maya_events.rpy:661
translate chinese maya_scene6_evening_myroom_0e9018a1:

    # gg "Иии"
    gg "Ⅲ"

# game/characters_events_idles/maya_events.rpy:663
translate chinese maya_scene6_evening_myroom_15ebc100:

    # gg "Операция закончена"
    gg "操作完成"

# game/characters_events_idles/maya_events.rpy:667
translate chinese maya_scene6_evening_myroom_1ceba70d:

    # Maya "Спасибо"
    Maya "谢谢"

# game/characters_events_idles/maya_events.rpy:680
translate chinese maya_scene6_evening_myroom_6fdd6424:

    # Maya "Не привыкай"
    Maya "不习惯"

# game/characters_events_idles/maya_events.rpy:683
translate chinese maya_scene6_evening_myroom_63c1dadc_1:

    # gg "Не собирался"
    gg "我不是故意的"

# game/characters_events_idles/maya_events.rpy:705
translate chinese maya_scene7_night_mayaroom_fec75b67:

    # gg "Ты до сих пор за ноутом?"
    gg "您还在使用笔记本电脑吗？"

# game/characters_events_idles/maya_events.rpy:706
translate chinese maya_scene7_night_mayaroom_762dfc55:

    # gg "Уже за полночь"
    gg "已经过了半夜了"

# game/characters_events_idles/maya_events.rpy:708
translate chinese maya_scene7_night_mayaroom_0d6d9e7f:

    # Maya "И что?"
    Maya "还有什么？"

# game/characters_events_idles/maya_events.rpy:709
translate chinese maya_scene7_night_mayaroom_f874de68:

    # Maya "У меня дела в отличие от некоторых"
    Maya "我做事的方式与某些人不同"

# game/characters_events_idles/maya_events.rpy:711
translate chinese maya_scene7_night_mayaroom_6b992d2b:

    # gg "Уже ночь"
    gg "已经是晚上了"

# game/characters_events_idles/maya_events.rpy:713
translate chinese maya_scene7_night_mayaroom_730b6969:

    # gg "А переписка это работа?"
    gg "函电工作吗？"

# game/characters_events_idles/maya_events.rpy:716
translate chinese maya_scene7_night_mayaroom_ca9eb87e:

    # Maya "Да мои дела"
    Maya "是的，我的事"

# game/characters_events_idles/maya_events.rpy:718
translate chinese maya_scene7_night_mayaroom_e1a35225:

    # Maya "Вечно лезешь туда, куда не зовут"
    Maya "你总是去不被邀请的地方"

# game/characters_events_idles/maya_events.rpy:720
translate chinese maya_scene7_night_mayaroom_54c856a0:

    # gg "А дверь открытая{w}, значит ждала"
    gg "门开着{w}，这意味着她正在等待"

# game/characters_events_idles/maya_events.rpy:722
translate chinese maya_scene7_night_mayaroom_5ebc71c5:

    # Maya "Ждала?"
    Maya "你等了吗？"

# game/characters_events_idles/maya_events.rpy:724
translate chinese maya_scene7_night_mayaroom_ab53ee69:

    # Maya "Только если дурака, чтобы под руку мешался"
    Maya "只有当它是个傻瓜时，才会妨碍它"

# game/characters_events_idles/maya_events.rpy:725
translate chinese maya_scene7_night_mayaroom_e04cd055:

    # gg_chat "На вид она слишком устала для настоящей злости"
    gg_chat "她看起来太累了，无法真正生气。"

# game/characters_events_idles/maya_events.rpy:730
translate chinese maya_scene7_night_mayaroom_8876fd31:

    # Maya "ЭЭ"
    Maya "电子工程"

# game/characters_events_idles/maya_events.rpy:733
translate chinese maya_scene7_night_mayaroom_588c8161:

    # Maya "Не смей! Это моё!" with hpunch
    Maya "你不敢！这是我的！" with hpunch

# game/characters_events_idles/maya_events.rpy:735
translate chinese maya_scene7_night_mayaroom_30b1c14e:

    # gg "Да я и не собирался читать"
    gg "我根本就没打算读它"

# game/characters_events_idles/maya_events.rpy:736
translate chinese maya_scene7_night_mayaroom_4d7029b4:

    # gg "Просто . . . {w}ты могла бы не прятать"
    gg "只是 。 。 。 {w}你无法隐藏"

# game/characters_events_idles/maya_events.rpy:738
translate chinese maya_scene7_night_mayaroom_43898c08:

    # Maya "Потому что . . ."
    Maya "因为 。 。 。"

# game/characters_events_idles/maya_events.rpy:740
translate chinese maya_scene7_night_mayaroom_7673a52d:

    # Maya "C тобой я . . ."
    Maya "我和你在一起。 。 。"

# game/characters_events_idles/maya_events.rpy:747
translate chinese maya_scene7_night_mayaroom_d57c47f7:

    # Maya ". . . "
    Maya "。 。 。"

# game/characters_events_idles/maya_events.rpy:748
translate chinese maya_scene7_night_mayaroom_8b57d927:

    # Maya ". . . {w}Я не своя . . ."
    Maya "。 。 。 {w}我不是我自己。 。 。"

# game/characters_events_idles/maya_events.rpy:749
translate chinese maya_scene7_night_mayaroom_6f9409ff:

    # Maya "Я всё время о тебе думаю"
    Maya "我无时无刻都在想你"

# game/characters_events_idles/maya_events.rpy:754
translate chinese maya_scene7_night_mayaroom_df75b7f4:

    # Maya "С тобой я только и делаю, что тупею!"
    Maya "我对你所做的一切就是让自己变得更愚蠢！"

# game/characters_events_idles/maya_events.rpy:756
translate chinese maya_scene7_night_mayaroom_578ec278:

    # Maya "Вот и всё"
    Maya "就是这样"

# game/characters_events_idles/maya_events.rpy:761
translate chinese maya_scene7_night_mayaroom_b56e467a:

    # gg "Ты прячешься за словами, но глаза выдают всё"
    gg "你隐藏在言语背后，但你的眼睛却泄露了一切"

# game/characters_events_idles/maya_events.rpy:769
translate chinese maya_scene7_night_mayaroom_b0f630ba:

    # Maya "{size=*0.8}. . . Дурак . . .{/size}"
    Maya "{size=*0.8}。 。 。傻瓜。 。 .{/size}"

# game/characters_events_idles/maya_events.rpy:770
translate chinese maya_scene7_night_mayaroom_8e74b6e2:

    # Maya "Если кому-то скажешь - я тебя прибью" with hpunch
    Maya "如果你告诉任何人，我会杀了你" with hpunch

# game/characters_events_idles/maya_events.rpy:774
translate chinese maya_scene7_night_mayaroom_03506582:

    # gg "Угрожаешь после такого? {w}Смелая"
    gg "这之后你还威胁吗？ {w}勇敢"

# game/characters_events_idles/maya_events.rpy:777
translate chinese maya_scene7_night_mayaroom_991c3acc:

    # gg "Никому {w}только между нами"
    gg "我们之间{w}没有人"

# game/characters_events_idles/maya_events.rpy:792
translate chinese maya_scene8_morning_mayaroom_3ccef67b:

    # gg_chat "Она выглядит . . . спокойно {w}Никакой злости {w} даже странно"
    gg_chat "她看起来。 。 。平静{w}没有愤怒{w}甚至奇怪"

# game/characters_events_idles/maya_events.rpy:794
translate chinese maya_scene8_morning_mayaroom_8e119e79:

    # Maya "Ты чё . . . {w}уже встал?.."
    Maya "你在干什么？ 。 。 {w}你起床了吗？.."

# game/characters_events_idles/maya_events.rpy:796
translate chinese maya_scene8_morning_mayaroom_fb3f31cf:

    # gg "Эм . . . да. Я не хотел мешать. Просто заглянул"
    gg "嗯。 。 。是的。我不想干涉。刚刚路过"

# game/characters_events_idles/maya_events.rpy:798
translate chinese maya_scene8_morning_mayaroom_0a978bde:

    # Maya "Не уходи . . ."
    Maya "别走。 。 。"

# game/characters_events_idles/maya_events.rpy:800
translate chinese maya_scene8_morning_mayaroom_3a0bea4a:

    # Maya "Сядь"
    Maya "坐下"

# game/characters_events_idles/maya_events.rpy:805
translate chinese maya_scene8_morning_mayaroom_970fe7c6:

    # Maya "Спала ужасно . . ."
    Maya "我睡得很糟糕。 。 。"

# game/characters_events_idles/maya_events.rpy:807
translate chinese maya_scene8_morning_mayaroom_4ada6f49:

    # Maya "Всё крутилось в голове"
    Maya "一切都在我脑海中旋转"

# game/characters_events_idles/maya_events.rpy:808
translate chinese maya_scene8_morning_mayaroom_ee85048c:

    # Maya "Не выспалась"
    Maya "睡眠不足"

# game/characters_events_idles/maya_events.rpy:810
translate chinese maya_scene8_morning_mayaroom_30004a57:

    # gg "А у тебя будто энергии с утра через край"
    gg "而且早上的你似乎精力充沛"

# game/characters_events_idles/maya_events.rpy:812
translate chinese maya_scene8_morning_mayaroom_c4e0d6af:

    # Maya "Очень смешно . . . "
    Maya "很搞笑。 。 。"

# game/characters_events_idles/maya_events.rpy:814
translate chinese maya_scene8_morning_mayaroom_c574ca14:

    # Maya "Я лентяйка {w}просто иногда притворяюсь"
    Maya "我很懒{w}有时我只是假装"

# game/characters_events_idles/maya_events.rpy:816
translate chinese maya_scene8_morning_mayaroom_42c46aa1:

    # Maya "Ляг"
    Maya "放下"

# game/characters_events_idles/maya_events.rpy:817
translate chinese maya_scene8_morning_mayaroom_9e620d29:

    # Maya "Просто . . . {w}чтоб теплее было"
    Maya "只是 。 。 。 {w}让天气变暖"

# game/characters_events_idles/maya_events.rpy:821
translate chinese maya_scene8_morning_mayaroom_d012bf21:

    # gg "Ты не заболела случайно?"
    gg "你生病了吗？"

# game/characters_events_idles/maya_events.rpy:824
translate chinese maya_scene8_morning_mayaroom_06609c2f:

    # Maya "Убью, если кому-то расскажешь"
    Maya "如果你告诉任何人我就会杀了你"

# game/characters_events_idles/maya_events.rpy:827
translate chinese maya_scene8_morning_mayaroom_aed6c2f3:

    # gg_chat "Может это мой шанс . . ."
    gg_chat "也许这是我的机会。 。 。"

# game/characters_events_idles/maya_events.rpy:833
translate chinese maya_scene8_morning_mayaroom_7f5f7cbf:

    # Maya "Дурак . . ."
    Maya "傻瓜。 。 。"

# game/characters_events_idles/maya_events.rpy:837
translate chinese maya_scene8_morning_mayaroom_f7f3b708:

    # gg_chat "Слишком спокойно . . ."
    gg_chat "太冷静了。 。 。"

# game/characters_events_idles/maya_events.rpy:838
translate chinese maya_scene8_morning_mayaroom_fc2580e2:

    # gg_chat "Значит, самое время тихо уйти"
    gg_chat "所以是时候悄悄离开了"

# game/characters_events_idles/maya_events.rpy:841
translate chinese maya_scene8_morning_mayaroom_4b32219f:

    # gg_chat "Никогда бы не подумал, что первый поцелуй с ней будет таким"
    gg_chat "我没想到我和她的初吻会是这样"

# game/characters_events_idles/maya_events.rpy:845
translate chinese maya_scene8_morning_mayaroom_31bdebc7:

    # gg_chat "Вот бы всегда так . . ."
    gg_chat "要是一直这样就好了。 。 。"

# game/characters_events_idles/maya_events.rpy:846
translate chinese maya_scene8_morning_mayaroom_7d3e081f:

    # gg_chat "Но, зная её, лучше не задерживаться"
    gg_chat "但了解她，最好不要徘徊"

# game/characters_events_idles/maya_events.rpy:851
translate chinese maya_scene8_morning_mayaroom_f57b1e37:

    # gg_chat "Мягкость её груди всё ещё чувствовалась . . ."
    gg_chat "依然能感觉到她乳房的柔软。 。 。"

# game/characters_events_idles/maya_events.rpy:852
translate chinese maya_scene8_morning_mayaroom_ba3923be:

    # gg_chat "И отпускать не хотелось"
    gg_chat "我不想放手"

# game/characters_events_idles/maya_events.rpy:872
translate chinese maya_scene9_day_kitchen_b483553f:

    # Maya "О ты тут, помоги посыпать соль"
    Maya "哦，你来了，帮我撒盐"

# game/characters_events_idles/maya_events.rpy:874
translate chinese maya_scene9_day_kitchen_564e6225:

    # gg "Окей"
    gg "好的"

# game/characters_events_idles/maya_events.rpy:877
translate chinese maya_scene9_day_kitchen_7d928982:

    # Maya "И аккуратней, а то пересолишь"
    Maya "并且要小心，否则你会加盐过多"

# game/characters_events_idles/maya_events.rpy:887
translate chinese maya_scene9_day_kitchen_29721060:

    # Maya "Так . . . {w}вот теперь оно прилипло к сковородке"
    Maya "所以 。 。 。 {w}现在它粘在煎锅上了"

# game/characters_events_idles/maya_events.rpy:888
translate chinese maya_scene9_day_kitchen_11cbabe0:

    # Maya "Прям не оторвать"
    Maya "撕不下来"

# game/characters_events_idles/maya_events.rpy:889
translate chinese maya_scene9_day_kitchen_927dfd8a:

    # gg "Тогда надо поддеть снизу, чтобы не пригорело"
    gg "然后你需要从下面撬它，这样它就不会燃烧。"

# game/characters_events_idles/maya_events.rpy:892
translate chinese maya_scene9_day_kitchen_b2073f58:

    # Maya "Главное - не давить слишком резко"
    Maya "最主要的是不要太用力"

# game/characters_events_idles/maya_events.rpy:893
translate chinese maya_scene9_day_kitchen_e7cb36e7:

    # Maya "Иначе желток лопнет"
    Maya "不然蛋黄会爆"

# game/characters_events_idles/maya_events.rpy:894
translate chinese maya_scene9_day_kitchen_23aa5a43:

    # gg "Но если аккуратно, всё останется целым"
    gg "但如果你小心的话，一切都会完好无损"

# game/characters_events_idles/maya_events.rpy:895
translate chinese maya_scene9_day_kitchen_0c33c9a7:

    # Maya "Угу . . . {w}мягче перемешивай"
    Maya "是的 。 。 。 {w}轻轻混合"

# game/characters_events_idles/maya_events.rpy:896
translate chinese maya_scene9_day_kitchen_7c4d7305:

    # Maya "Тогда всё прожарится равномерно"
    Maya "然后一切都会均匀地煮熟"

# game/characters_events_idles/maya_events.rpy:899
translate chinese maya_scene9_day_kitchen_b067ff5d:

    # Maya "Всё, почти готово . . ."
    Maya "一切都差不多准备好了。 。 。"

# game/characters_events_idles/maya_events.rpy:900
translate chinese maya_scene9_day_kitchen_5805bb78:

    # Maya "Ещё чуть-чуть, и можно снимать с огня"
    Maya "只要多一点，你就可以把它从火上取下来。"

# game/characters_events_idles/maya_events.rpy:901
translate chinese maya_scene9_day_kitchen_c61ed5a8:

    # gg "Думаю, будет очень вкусно"
    gg "我觉得会很好吃"

# game/characters_events_idles/maya_events.rpy:905
translate chinese maya_scene9_day_kitchen_152dc2f3:

    # Maya "Всё {w}a то сейчас пережарим"
    Maya "所有的东西{w}否则我们现在就会煮过头了"

# game/characters_events_idles/maya_events.rpy:907
translate chinese maya_scene9_day_kitchen_d98d84da:

    # Maya "Дальше сам себе готовь"
    Maya "然后自己做饭"

# game/characters_events_idles/maya_events.rpy:909
translate chinese maya_scene9_day_kitchen_c00c68f7:

    # gg_chat "Она подыгрывала"
    gg_chat "她一起演奏"

# game/characters_events_idles/maya_events.rpy:910
translate chinese maya_scene9_day_kitchen_8e86ab7e:

    # gg_chat "Но в конце всё равно сбежала . . ."
    gg_chat "但最终她还是逃走了。 。 。"

# game/characters_events_idles/maya_events.rpy:928
translate chinese maya_scene10_evening_myroom_b792031e:

    # Maya "Я дома"
    Maya "我到家了"

# game/characters_events_idles/maya_events.rpy:930
translate chinese maya_scene10_evening_myroom_4c632d43:

    # Maya "О, ты тут"
    Maya "哦，你在这里"

# game/characters_events_idles/maya_events.rpy:932
translate chinese maya_scene10_evening_myroom_e37dbd39:

    # gg "Привет. Как работа?"
    gg "你好。工作怎么样？"

# game/characters_events_idles/maya_events.rpy:934
translate chinese maya_scene10_evening_myroom_92ca482a:

    # Maya "Словно вечность. Эта долбаные люди"
    Maya "就像永恒一样。这些该死的人"

# game/characters_events_idles/maya_events.rpy:936
translate chinese maya_scene10_evening_myroom_d1b85968:

    # gg "Хочешь чай? Или просто вырубиться?"
    gg "您想喝点茶吗？或者只是昏倒了？"

# game/characters_events_idles/maya_events.rpy:938
translate chinese maya_scene10_evening_myroom_a28c5657:

    # Maya "Чай?{w} Ты решил внезапно заботиться?"
    Maya "茶？{w}您突然决定关心吗？"

# game/characters_events_idles/maya_events.rpy:940
translate chinese maya_scene10_evening_myroom_ffaaaddc:

    # Maya "Ладно . . . да, пожалуй. И два сахара"
    Maya "好的 。 。 。是的，也许吧。还有两颗糖"

# game/characters_events_idles/maya_events.rpy:944
translate chinese maya_scene10_evening_myroom_fc470a50:

    # Maya "Уфф устала"
    Maya "呃我累了"

# game/characters_events_idles/maya_events.rpy:946
translate chinese maya_scene10_evening_myroom_d751ae58:

    # gg "Может, поговорим?"
    gg "也许我们可以谈谈？"

# game/characters_events_idles/maya_events.rpy:948
translate chinese maya_scene10_evening_myroom_dd61a1d4:

    # Maya "О чём?"
    Maya "关于什么？"

# game/characters_events_idles/maya_events.rpy:950
translate chinese maya_scene10_evening_myroom_cb7be281:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Уволь"
    Maya "关于我如何再次放弃清洁工作？{w}{bt=a3-p2.0-s3.0}被解雇了"

# game/characters_events_idles/maya_events.rpy:952
translate chinese maya_scene10_evening_myroom_49e84409:

    # gg "Необязательно. Можно просто помолчать"
    gg "选修的。你可以保持安静"

# game/characters_events_idles/maya_events.rpy:954
translate chinese maya_scene10_evening_myroom_963962a9:

    # Maya "Ты странный. Сидишь тут . . . как будто ждёшь чего-то"
    Maya "你很奇怪。你坐在这里。 。 。就像你在等待某事"

# game/characters_events_idles/maya_events.rpy:958
translate chinese maya_scene10_evening_myroom_31f86790:

    # gg "Может, и жду"
    gg "也许我在等待"

# game/characters_events_idles/maya_events.rpy:960
translate chinese maya_scene10_evening_myroom_7f342626:

    # Maya "Ты же знаешь, что я . . . колючая"
    Maya "你知道我是。 。 。多刺的"

# game/characters_events_idles/maya_events.rpy:962
translate chinese maya_scene10_evening_myroom_27989031:

    # gg "Знаю"
    gg "我知道"

# game/characters_events_idles/maya_events.rpy:964
translate chinese maya_scene10_evening_myroom_91a19161:

    # Maya "И что я всё испорчу"
    Maya "我会毁掉一切"

# game/characters_events_idles/maya_events.rpy:966
translate chinese maya_scene10_evening_myroom_d6704538:

    # Maya "Обязательно ляпну какую-нибудь чушь"
    Maya "我肯定会脱口而出一些废话"

# game/characters_events_idles/maya_events.rpy:968
translate chinese maya_scene10_evening_myroom_489ce109:

    # gg "{bt=a3-p2.0-s3.0}{size=*0.8}Привык уже"
    gg "{bt=a3-p2.0-s3.0}{size=*0.8}我已经习惯了"

# game/characters_events_idles/maya_events.rpy:974
translate chinese maya_scene10_evening_myroom_c0ac8816:

    # Maya "Ну конечно. Самое время для этого"
    Maya "嗯，当然。是时候做这个了"

# game/characters_events_idles/maya_events.rpy:976
translate chinese maya_scene10_evening_myroom_ec57c0d1:

    # gg "Май . . ."
    gg "可能。 。 。"

# game/characters_events_idles/maya_events.rpy:978
translate chinese maya_scene10_evening_myroom_16a831f4:

    # Maya "Заткнись"
    Maya "住口"

# game/characters_events_idles/maya_events.rpy:980
translate chinese maya_scene10_evening_myroom_71044ba9:

    # Maya "Просто . . . заткнись"
    Maya "只是 。 。 。住口"

# game/characters_events_idles/maya_events.rpy:990
translate chinese maya_scene10_evening_myroom_742929c8:

    # Maya "Тише . . . Осторожно. Я не . . .{w} Я не готова ко всему сразу"
    Maya "安静的 。 。 。小心。我不知道。 。 .{w}我还没有立即做好一切准备"

# game/characters_events_idles/maya_events.rpy:996
translate chinese maya_scene10_evening_myroom_66b26945:

    # Maya "Ох . . . боже . . ."
    Maya "哦 。 。 。上帝 。 。 。"

# game/characters_events_idles/maya_events.rpy:1008
translate chinese maya_scene10_evening_myroom_7da8b255:

    # Maya ". . ."
    Maya "。 。 。"

# game/characters_events_idles/maya_events.rpy:1010
translate chinese maya_scene10_evening_myroom_71253d69:

    # Maya "Вот это да . . ."
    Maya "哇 。 。 。"

# game/characters_events_idles/maya_events.rpy:1012
translate chinese maya_scene10_evening_myroom_22f5a5a6:

    # Maya "Ты это . . . там всё время носил?"
    Maya "你就是它。 。 。一直戴着它吗？"

# game/characters_events_idles/maya_events.rpy:1018
translate chinese maya_scene10_evening_myroom_c014a37d:

    # Maya "Нет . . ."
    Maya "不 。 。 。"

# game/characters_events_idles/maya_events.rpy:1020
translate chinese maya_scene10_evening_myroom_2d2f095f:

    # Maya "Нет, стоп"
    Maya "不，停下来"

# game/characters_events_idles/maya_events.rpy:1022
translate chinese maya_scene10_evening_myroom_6b00b07b:

    # Maya "Стоп, блядь"
    Maya "停下来，妓女"

# game/characters_events_idles/maya_events.rpy:1024
translate chinese maya_scene10_evening_myroom_f3f9fdab:

    # gg "Майя?"
    gg "玛雅？"

# game/characters_events_idles/maya_events.rpy:1026
translate chinese maya_scene10_evening_myroom_b9eafd1f:

    # Maya "Выйди. Пожалуйста.{w} Просто . . . выйди"
    Maya "出去。拜托。{w}就这样。 。 。出来"

# game/characters_events_idles/maya_events.rpy:1028
translate chinese maya_scene10_evening_myroom_92d5f1bf:

    # gg "Я . . .{w} Я не хотел . . ."
    gg "我 。 。 .{w}我不想。 。 。"

# game/characters_events_idles/maya_events.rpy:1030
translate chinese maya_scene10_evening_myroom_e6bbb658:

    # Maya "{sc}{size=*1.2}Я ЗНАЮ{/size}{/sc}, что не хотел!"
    Maya "{sc}{size=*1.2}我知道{/size}{/sc}我不是故意的！"

# game/characters_events_idles/maya_events.rpy:1032
translate chinese maya_scene10_evening_myroom_9ef6f711:

    # Maya "Именно поэтому — ВЫЙДИ!"
    Maya "这就是为什么 - 出去！"

# game/characters_events_idles/maya_events.rpy:1034
translate chinese maya_scene10_evening_myroom_85e3ca37:

    # Maya "Не сейчас . . .{w} Я не могу{w} Это слишком . . . реально"
    Maya "现在不要 。 。 .{w}我不能{w}这太多了。 。 。真的"

# game/characters_events_idles/maya_events.rpy:1036
translate chinese maya_scene10_evening_myroom_a4abe766:

    # gg "Хорошо. Я . . .{w} Я ушёл"
    gg "美好的。我 。 。 .{w}我离开了"

# game/characters_events_idles/maya_events.rpy:1040
translate chinese maya_scene10_evening_myroom_8454737d:

    # Maya "{size=*0.8}Чёрт . . . Чёрт . . . Чёрт . . ."
    Maya "{size=*0.8}该死。 。 。废话。 。 。废话。 。 。"

# game/characters_events_idles/maya_events.rpy:1041
translate chinese maya_scene10_evening_myroom_c2f04aea:

    # Maya "{size=*0.8}Он такой . . . большой . . ."
    Maya "{size=*0.8}他就是这样的人。 。 。大的 。 。 。"

# game/characters_events_idles/maya_events.rpy:1043
translate chinese maya_scene10_evening_myroom_828ad43f:

    # Maya "{size=*0.8}И мне . . ."
    Maya "{size=*0.8}我也是。 。 。"

# game/characters_events_idles/maya_events.rpy:1044
translate chinese maya_scene10_evening_myroom_b4c5d69e:

    # Maya "{size=*0.8}{bt=a3-p2.0-s3.0}Понравилось"
    Maya "{size=*0.8}{bt=a3-p2.0-s3.0}喜欢"

# game/characters_events_idles/maya_events.rpy:1061
translate chinese maya_scene11_morning_bathroom_bd1a48b9:

    # gg "Ты с утра за стиркой"
    gg "你早上一直在洗衣服"

# game/characters_events_idles/maya_events.rpy:1062
translate chinese maya_scene11_morning_bathroom_17ad5908:

    # gg "Это что то мифическое"
    gg "这是一个神话般的东西"

# game/characters_events_idles/maya_events.rpy:1064
translate chinese maya_scene11_morning_bathroom_2998d6f9:

    # Maya "Миф"
    Maya "神话"

# game/characters_events_idles/maya_events.rpy:1066
translate chinese maya_scene11_morning_bathroom_fa12fc4b:

    # Maya "Это если бы ты сам что-то постирал"
    Maya "这是如果你自己洗东西的话"

# game/characters_events_idles/maya_events.rpy:1071
translate chinese maya_scene11_morning_bathroom_10404fc0:

    # gg "Я хотя бы свои вещи складываю"
    gg "至少我收拾好东西"

# game/characters_events_idles/maya_events.rpy:1073
translate chinese maya_scene11_morning_bathroom_cfff324a:

    # gg "А твои валялись по всей комнате"
    gg "房间里到处都是你的"

# game/characters_events_idles/maya_events.rpy:1075
translate chinese maya_scene11_morning_bathroom_67c05e6d:

    # Maya "И кто же их собрал? Не ты"
    Maya "谁收集了它们？不是你"

# game/characters_events_idles/maya_events.rpy:1077
translate chinese maya_scene11_morning_bathroom_b4e5e9ee:

    # gg "Ещё чуть-чуть, и я подумаю, что ты скрытая трудяга"
    gg "只要再多一点，我就会认为你是一个隐藏的勤奋者"

# game/characters_events_idles/maya_events.rpy:1079
translate chinese maya_scene11_morning_bathroom_4907bae2:

    # Maya "Чего говоришь!"
    Maya "你在说什么？"

# game/characters_events_idles/maya_events.rpy:1081
translate chinese maya_scene11_morning_bathroom_eaaef249:

    # Maya "Думаешь я настолько лентяйка?"
    Maya "你以为我有那么懒吗？"

# game/characters_events_idles/maya_events.rpy:1083
translate chinese maya_scene11_morning_bathroom_062411d1:

    # gg "Думаю"
    gg "思考"

# game/characters_events_idles/maya_events.rpy:1088
translate chinese maya_scene11_morning_bathroom_b708dc2c:

    # gg "Ты кое что забыла поставить на стирку"
    gg "你忘记在洗衣机里放东西了"

# game/characters_events_idles/maya_events.rpy:1096
translate chinese maya_scene11_morning_bathroom_8c8070f2:

    # Maya "Ах так?"
    Maya "哦，是吗？"

# game/characters_events_idles/maya_events.rpy:1098
translate chinese maya_scene11_morning_bathroom_cb35be97:

    # Maya "Тогда стираем всё"
    Maya "然后我们删除一切"

# game/characters_events_idles/maya_events.rpy:1104
translate chinese maya_scene11_morning_bathroom_cf4d3425:

    # Maya "Ага . . ."
    Maya "是的。 。 。"

# game/characters_events_idles/maya_events.rpy:1106
translate chinese maya_scene11_morning_bathroom_fa661e9f:

    # Maya "Похоже ЭТО нужно будет стирать деликатно"
    Maya "看起来这个需要仔细清洗"

# game/characters_events_idles/maya_events.rpy:1108
translate chinese maya_scene11_morning_bathroom_9cd0adf2:

    # Maya "Думаю мы можем продолжить на чем закончили?"
    Maya "我想我们可以从上次中断的地方继续吗？"

# game/characters_events_idles/maya_events.rpy:1112
translate chinese maya_scene11_morning_bathroom_84b09d0d:

    # Maya "Стиралка работает . . . {w}но тут жарче, чем должно быть"
    Maya "洗衣机正在工作。 。 。 {w}但温度比应有的温度高"

# game/characters_events_idles/maya_events.rpy:1113
translate chinese maya_scene11_morning_bathroom_6df3a5e2:

    # gg "Главное - достирай до конца"
    gg "最主要的是把它完成到底"

# game/characters_events_idles/maya_events.rpy:1114
translate chinese maya_scene11_morning_bathroom_d0b88dcb:

    # gg "Если оставишь придется домывать . . ."
    gg "如果你留下它，你将不得不清洗它。 。 。"

# game/characters_events_idles/maya_events.rpy:1119
translate chinese maya_scene11_morning_bathroom_0467b855:

    # Maya "Так я думаю стиралка сама справится"
    Maya "所以我认为洗衣机会自己处理的"

# game/characters_events_idles/maya_events.rpy:1122
translate chinese maya_scene11_morning_bathroom_542d4b95:

    # Maya "А ты . . . {w}сам достирай свое"
    Maya "你呢 。 。 。 {w}自己进行清洁"

# game/characters_events_idles/maya_events.rpy:1123
translate chinese maya_scene11_morning_bathroom_83b51400:

    # Maya "Белье . . ."
    Maya "亚麻布。 。 。"

# game/characters_events_idles/maya_events.rpy:1129
translate chinese maya_scene11_morning_bathroom_eb975221:

    # gg_chat "Она ушла . . ."
    gg_chat "她离开了。 。 。"

# game/characters_events_idles/maya_events.rpy:1130
translate chinese maya_scene11_morning_bathroom_3188cfc5:

    # gg_chat "В следующий раз ее нельзя отпускать . . ."
    gg_chat "下次你不能再放开她了。 。 。"

# game/characters_events_idles/maya_events.rpy:1147
translate chinese maya_scene12_evening_myroom_bb653a62:

    # Maya "Ха, так вот где ты спрятался"
    Maya "哈，所以这就是你藏身的地方"

# game/characters_events_idles/maya_events.rpy:1149
translate chinese maya_scene12_evening_myroom_4ca35500:

    # Maya "И что ты смотришь?"
    Maya "你在看什么？"

# game/characters_events_idles/maya_events.rpy:1151
translate chinese maya_scene12_evening_myroom_7e8ca4c6:

    # gg "Подожди я в матче"
    gg "等我参加比赛"

# game/characters_events_idles/maya_events.rpy:1152
translate chinese maya_scene12_evening_myroom_5ed608a5:

    # gg "Если отвлекусь - проиграю"
    gg "如果我分心，我就会输"

# game/characters_events_idles/maya_events.rpy:1154
translate chinese maya_scene12_evening_myroom_8f98104b:

    # Maya "И это, по-твоему, веселье?"
    Maya "这就是你认为有趣的事情？"

# game/characters_events_idles/maya_events.rpy:1156
translate chinese maya_scene12_evening_myroom_336dd03a:

    # gg "Когда сам играешь намного веселее . . ."
    gg "当你自己玩的时候会更有趣。 。 。"

# game/characters_events_idles/maya_events.rpy:1158
translate chinese maya_scene12_evening_myroom_3a2af852:

    # Maya "А по мне, как будто трата времени"
    Maya "对我来说这似乎是浪费时间"

# game/characters_events_idles/maya_events.rpy:1160
translate chinese maya_scene12_evening_myroom_814660f9:

    # gg "Эй!" with hpunch
    gg "嘿！" with hpunch

# game/characters_events_idles/maya_events.rpy:1161
translate chinese maya_scene12_evening_myroom_a589a29a:

    # gg "Я ничего не вижу!"
    gg "我什么也没看到！"

# game/characters_events_idles/maya_events.rpy:1162
translate chinese maya_scene12_evening_myroom_6d7f26d1:

    # Maya "Ну и что?"
    Maya "所以呢？"

# game/characters_events_idles/maya_events.rpy:1164
translate chinese maya_scene12_evening_myroom_8bb854aa:

    # Maya "Почему перестал играть?"
    Maya "你为什么不玩了？"

# game/characters_events_idles/maya_events.rpy:1166
translate chinese maya_scene12_evening_myroom_9c0bce5d:

    # gg "Я же сказал"
    gg "我告诉你了"

# game/characters_events_idles/maya_events.rpy:1168
translate chinese maya_scene12_evening_myroom_4430c970:

    # gg "Теперь только тебя и вижу"
    gg "现在我只看到你"

# game/characters_events_idles/maya_events.rpy:1170
translate chinese maya_scene12_evening_myroom_e1ca96ab:

    # Maya "Вот и отлично!"
    Maya "那太棒了！"

# game/characters_events_idles/maya_events.rpy:1172
translate chinese maya_scene12_evening_myroom_e638502a:

    # Maya "Я теперь главный игрок"
    Maya "我现在是主角"

# game/characters_events_idles/maya_events.rpy:1174
translate chinese maya_scene12_evening_myroom_1751458f:

    # gg "Ты щас мне рейтинг сольешь"
    gg "你现在会毁了我的评价"

# game/characters_events_idles/maya_events.rpy:1176
translate chinese maya_scene12_evening_myroom_ce7e136c:

    # Maya "Да ну, я просто проверяю"
    Maya "是的，我只是在检查"

# game/characters_events_idles/maya_events.rpy:1178
translate chinese maya_scene12_evening_myroom_81a51f30:

    # Maya "Как тут . . . прыгает!"
    Maya "就像这里一样。 。 。跳跃！"

# game/characters_events_idles/maya_events.rpy:1180
translate chinese maya_scene12_evening_myroom_c46a67aa:

    # Maya "Ой, а это что делает?"
    Maya "哦，这个有什么作用呢？"

# game/characters_events_idles/maya_events.rpy:1181
translate chinese maya_scene12_evening_myroom_9260e289:

    # gg "Стой, не так"
    gg "等等，事情不是这样的"

# game/characters_events_idles/maya_events.rpy:1183
translate chinese maya_scene12_evening_myroom_16a342c4:

    # gg "Вот эта - стрелять, эта - использовать"
    gg "这个是拍摄用的，这个是使用用的"

# game/characters_events_idles/maya_events.rpy:1185
translate chinese maya_scene12_evening_myroom_c634457f:

    # gg "Держи крепче, смотри в экран"
    gg "握紧，看屏幕"

# game/characters_events_idles/maya_events.rpy:1188
translate chinese maya_scene12_evening_myroom_b18fd1da:

    # Maya "Мм . . ."
    Maya "毫米 。 。 。"

# game/characters_events_idles/maya_events.rpy:1189
translate chinese maya_scene12_evening_myroom_3f637927:

    # Maya "Тут у тебя геймпад немного неудобный . . ."
    Maya "这里你的游戏手柄有点不舒服。 。 。"

# game/characters_events_idles/maya_events.rpy:1190
translate chinese maya_scene12_evening_myroom_8351e9a2:

    # gg "Нет . . . {w}я про . . ."
    gg "不 。 。 。 {w}我说的是。 。 。"

# game/characters_events_idles/maya_events.rpy:1193
translate chinese maya_scene12_evening_myroom_c16d1061:

    # gg "Целься и стреляй"
    gg "瞄准并射击"

# game/characters_events_idles/maya_events.rpy:1197
translate chinese maya_scene12_evening_myroom_cbd60b88:

    # Maya "А! Я попала по нему!"
    Maya "一个！我打他了！"

# game/characters_events_idles/maya_events.rpy:1198
translate chinese maya_scene12_evening_myroom_15447830:

    # Maya "Но всё равно проиграла . . ."
    Maya "但她还是输了。 。 。"

# game/characters_events_idles/maya_events.rpy:1199
translate chinese maya_scene12_evening_myroom_9b0188df:

    # gg "Нужно время, чтобы научиться"
    gg "需要时间学习"

# game/characters_events_idles/maya_events.rpy:1201
translate chinese maya_scene12_evening_myroom_3a4b5fe2:

    # Maya "Время?"
    Maya "时间？"

# game/characters_events_idles/maya_events.rpy:1202
translate chinese maya_scene12_evening_myroom_7be2116f:

    # Maya "У меня терпения не хватит"
    Maya "我没有足够的耐心"

# game/characters_events_idles/maya_events.rpy:1207
translate chinese maya_scene12_evening_myroom_502ea205:

    # Maya "Я лучше найду другой способ с тобой поиграть"
    Maya "我宁愿找另一种方式和你一起玩"

# game/characters_events_idles/maya_events.rpy:1209
translate chinese maya_scene12_evening_myroom_d76b3a67:

    # gg "Похоже, тебе важнее сбить меня с толку . . ."
    gg "看来你迷惑我更重要。 。 。"

# game/characters_events_idles/maya_events.rpy:1212
translate chinese maya_scene12_evening_myroom_9a170cb1:

    # Maya "Экран-то видишь ещё?"
    Maya "您还能看到屏幕吗？"

# game/characters_events_idles/maya_events.rpy:1214
translate chinese maya_scene12_evening_myroom_7c6d2d03:

    # Maya "А это"
    Maya "还有这个"

# game/characters_events_idles/maya_events.rpy:1216
translate chinese maya_scene12_evening_myroom_b1427dbd:

    # Maya "Не интереснее?"
    Maya "不是更有趣吗？"

# game/characters_events_idles/maya_events.rpy:1219
translate chinese maya_scene12_evening_myroom_2fd00100:

    # gg "Интереснее, но я хочу выиграть"
    gg "更有趣，但我想赢"

# game/characters_events_idles/maya_events.rpy:1222
translate chinese maya_scene12_evening_myroom_161fdfc3:

    # Maya "Ну-ну"
    Maya "好吧，好吧"

# game/characters_events_idles/maya_events.rpy:1223
translate chinese maya_scene12_evening_myroom_270d46ae:

    # Maya "Тогда держи удар"
    Maya "然后接受打击"

# game/characters_events_idles/maya_events.rpy:1227
translate chinese maya_scene12_evening_myroom_38cb6e8b:

    # Maya "Геймер"
    Maya "游戏玩家"

# game/characters_events_idles/maya_events.rpy:1229
translate chinese maya_scene12_evening_myroom_a093b46d:

    # gg_chat "Она решила так играть? . . ."
    gg_chat "她决定就这样玩吗？ 。 。 。"

# game/characters_events_idles/maya_events.rpy:1233
translate chinese maya_scene12_evening_myroom_5f58be75:

    # Maya "Давай, продолжай выигрывать"
    Maya "加油，继续胜利"

# game/characters_events_idles/maya_events.rpy:1234
translate chinese maya_scene12_evening_myroom_6c6c4f14:

    # Maya "Интересно, надолго ли тебя хватит"
    Maya "我想知道你能坚持多久"

# game/characters_events_idles/maya_events.rpy:1235
translate chinese maya_scene12_evening_myroom_cc2a1c48:

    # gg "Мая . . ."
    gg "可能。 。 。"

# game/characters_events_idles/maya_events.rpy:1236
translate chinese maya_scene12_evening_myroom_a757aa6b:

    # gg "Ты . . ."
    gg "你 。 。 。"

# game/characters_events_idles/maya_events.rpy:1237
translate chinese maya_scene12_evening_myroom_2ca54e92:

    # Maya "Тише, я разбираюсь с управлением"
    Maya "嘘，我正在掌握控制的窍门。"

# game/characters_events_idles/maya_events.rpy:1243
translate chinese maya_scene12_evening_myroom_60a36ddd:

    # Maya "Ну что?"
    Maya "出色地？"

# game/characters_events_idles/maya_events.rpy:1244
translate chinese maya_scene12_evening_myroom_6ab6d9ce:

    # Maya "Поражение засчитано?"
    Maya "失败算不算？"

# game/characters_events_idles/maya_events.rpy:1245
translate chinese maya_scene12_evening_myroom_c6558b58:

    # gg "Это вообще нечестная игра"
    gg "这根本不是一场公平的游戏。"

# game/characters_events_idles/maya_events.rpy:1247
translate chinese maya_scene12_evening_myroom_c6b0e67a:

    # Maya "Нечестные победы самые сладкие"
    Maya "不公平的胜利是最甜蜜的"

# game/characters_events_idles/maya_events.rpy:1248
translate chinese maya_scene12_evening_myroom_6e151f9e:

    # Maya "Теперь ты мой должник"
    Maya "现在你欠我的"

translate chinese strings:

    # game/characters_events_idles/maya_events.rpy:742
    old "Договаривай"
    new "谈判"

    # game/characters_events_idles/maya_events.rpy:752
    old ". . ."
    new "。 。 。"

    # game/characters_events_idles/maya_events.rpy:772
    old "Угрожаешь?"
    new "你在威胁吗？"

    # game/characters_events_idles/maya_events.rpy:775
    old "Никому"
    new "没有人"

    # game/characters_events_idles/maya_events.rpy:829
    old "Тихо поцеловать её"
    new "静静地吻她"

    # game/characters_events_idles/maya_events.rpy:842
    old "Уткнуться в ее грудь"
    new "把自己埋进她的胸膛"

# TODO: Translation updated at 2026-01-26 03:22

# game/characters_events_idles/maya_events.rpy:248
translate chinese maya_scene3_evening_kitchen_2c2f92cd:

    # Maya "Зачем так близко?"
    Maya "为什么这么近？"

# game/characters_events_idles/maya_events.rpy:314
translate chinese maya_scene4_morning_mayaroom_0d36d4ee:

    # gg "Хорошо, не собирался"
    gg "好吧，我不是故意的"

# game/characters_events_idles/maya_events.rpy:402
translate chinese maya_scene5_night_mayaroom_979f77d5:

    # Maya "{size=*1.3}Не надо"
    Maya "{size=*1.3}不需要"

# game/characters_events_idles/maya_events.rpy:410
translate chinese maya_scene5_night_mayaroom_8fb3b4e0:

    # Maya "{size=*1.3}Ты всегда «просто»"
    Maya "{size=*1.3}你总是“简单”"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/maya_events.rpy:42
translate chinese maya_scene1_evening_myroom_82e75b03:

    # Maya "Где они, блин"
    Maya "他们到底在哪里"

# game/characters_events_idles/maya_events.rpy:182
translate chinese maya_scene2_day_mayaroom_64552e65:

    # Maya "В мои дела"
    Maya "在我的事情上"

# game/characters_events_idles/maya_events.rpy:293
translate chinese maya_scene4_morning_mayaroom_aea30766:

    # gg "Погоди, у меня была похожая проблема"
    gg "等等，我也遇到了类似的问题"

# game/characters_events_idles/maya_events.rpy:304
translate chinese maya_scene4_morning_mayaroom_c677d050:

    # Maya "Ладно, поскольку ты уже встал тут в позу спасителя"
    Maya "好吧，既然你已经摆出救世主的姿势了"

# game/characters_events_idles/maya_events.rpy:308
translate chinese maya_scene4_morning_mayaroom_c7e3f4c3:

    # Maya "Но если сломаешь, новый купишь"
    Maya "但如果坏了就买一个新的"

# game/characters_events_idles/maya_events.rpy:398
translate chinese maya_scene5_night_mayaroom_24e10eb1:

    # Maya "Хочешь границы"
    Maya "你想要界限吗？"

# game/characters_events_idles/maya_events.rpy:521
translate chinese maya_scene6_evening_myroom_8447de22:

    # Maya "Увидишь"
    Maya "你会看到"

# game/characters_events_idles/maya_events.rpy:580
translate chinese maya_scene6_evening_myroom_8974d68b:

    # Maya "В общем, нужно нанести крем и забинтовать"
    Maya "一般来说，需要涂抹药膏并包扎起来"

# game/characters_events_idles/maya_events.rpy:594
translate chinese maya_scene6_evening_myroom_94783c90:

    # gg "Кажется, это называется забота"
    gg "我想这才叫关怀"

# game/characters_events_idles/maya_events.rpy:620
translate chinese maya_scene6_evening_myroom_b0f0812d:

    # gg "Просто сейчас . . .{w} нет смысла психовать"
    gg "现在。 。 .{w}没有必要惊慌失措"

# game/characters_events_idles/maya_events.rpy:662
translate chinese maya_scene6_evening_myroom_98eb68ec:

    # gg "Если тебе так проще — я выйду"
    gg "如果你方便的话我就出去"

# game/characters_events_idles/maya_events.rpy:957
translate chinese maya_scene10_evening_myroom_e458abf1:

    # Maya "Словно вечность. Эти долбаные люди"
    Maya "就像永恒一样。这些该死的人"

# game/characters_events_idles/maya_events.rpy:967
translate chinese maya_scene10_evening_myroom_39f98df4:

    # Maya "Уфф, устала"
    Maya "呃，我累了"

# game/characters_events_idles/maya_events.rpy:973
translate chinese maya_scene10_evening_myroom_b1651980:

    # Maya "О том, как я снова забила на уборку?{w} {bt=a3-p2.0-s3.0}Отстань"
    Maya "我是如何再次放弃清洁工作的？{w}{bt=a3-p2.0-s3.0}别打扰我"

# game/characters_events_idles/maya_events.rpy:975
translate chinese maya_scene10_evening_myroom_cd61d42f:

    # gg "Да ладно тебе, можно просто помолчать"
    gg "来吧，你可以闭嘴了"

# TODO: Translation updated at 2026-02-16 03:29

# game/characters_events_idles/maya_events.rpy:1300
translate chinese maya_scene13_morning_girlroom_4a56a987:

    # gg_chat "Так, Cоня просила заказать новый шнур и заодно батарейки"
    gg_chat "那么，索尼亚让我订购一个新的电缆和一些电池"

# game/characters_events_idles/maya_events.rpy:1312
translate chinese maya_scene13_morning_girlroom_f5a72472:

    # gg "Ты чего?"
    gg "怎么了？"

# game/characters_events_idles/maya_events.rpy:1314
translate chinese maya_scene13_morning_girlroom_d958422f:

    # Maya "Ничего. Делай своё дело"
    Maya "没事。做你的事"

# game/characters_events_idles/maya_events.rpy:1318
translate chinese maya_scene13_morning_girlroom_6b37e39c:

    # Maya "Не отвлекайся"
    Maya "别分心"

# game/characters_events_idles/maya_events.rpy:1324
translate chinese maya_scene13_morning_girlroom_36d1af18:

    # gg "Мая одну секунду . . ."
    gg "稍等一下，玛雅。。。"

# game/characters_events_idles/maya_events.rpy:1325
translate chinese maya_scene13_morning_girlroom_df56cad2:

    # Maya "Я же сказала, делай свое дело"
    Maya "我说了，做你的事"

# game/characters_events_idles/maya_events.rpy:1328
translate chinese maya_scene13_morning_girlroom_3fa97e8a:

    # gg "Готово"
    gg "好了"

# game/characters_events_idles/maya_events.rpy:1351
translate chinese maya_scene13_morning_girlroom_d5360aaa:

    # Maya "Ну как тебе такое спокойное утро?"
    Maya "那你觉得这个安静的早晨怎么样？"

# game/characters_events_idles/maya_events.rpy:1353
translate chinese maya_scene13_morning_girlroom_337e1de0:

    # gg "Замечательно"
    gg "太好了"

# game/characters_events_idles/maya_events.rpy:1382
translate chinese maya_scene14_afternoon_myroom_72791318:

    # Sonya "Эй . . . [povname] можешь помочь с коробками?"
    Sonya "嘿。。。[povname]，你能帮我搬箱子吗？"

# game/characters_events_idles/maya_events.rpy:1384
translate chinese maya_scene14_afternoon_myroom_dce97add:

    # Maya "Ой. Тебя зовут"
    Maya "哦，叫你了"

# game/characters_events_idles/maya_events.rpy:1386
translate chinese maya_scene14_afternoon_myroom_650d8ae1:

    # Maya "Беги. Не заставляй даму ждать"
    Maya "快跑，别让女士等了"

# game/characters_events_idles/maya_events.rpy:1397
translate chinese maya_scene14_afternoon_myroom_134f9600:

    # Maya "Слушай . . ."
    Maya "听着。。。"

# game/characters_events_idles/maya_events.rpy:1399
translate chinese maya_scene14_afternoon_myroom_fd56b7a3:

    # Maya "Не уходи"
    Maya "别走"

# game/characters_events_idles/maya_events.rpy:1401
translate chinese maya_scene14_afternoon_myroom_6e0b7c57:

    # gg "Это из-за Сони?"
    gg "是因为索尼亚吗？"

# game/characters_events_idles/maya_events.rpy:1403
translate chinese maya_scene14_afternoon_myroom_b380699d:

    # Maya "Ты правда думаешь, что я буду это обсуждать?"
    Maya "你真觉得我会讨论这个吗？"

# game/characters_events_idles/maya_events.rpy:1406
translate chinese maya_scene14_afternoon_myroom_0ea54924:

    # Maya "Мне не нравится, как легко ты вскакиваешь"
    Maya "我不喜欢你这么轻松地起床"

# game/characters_events_idles/maya_events.rpy:1408
translate chinese maya_scene14_afternoon_myroom_e1764fab:

    # Maya "Как будто меня тут нет"
    Maya "好像我根本不在这里"

# game/characters_events_idles/maya_events.rpy:1410
translate chinese maya_scene14_afternoon_myroom_1d844383:

    # Maya "Пять минут"
    Maya "五分钟"

# game/characters_events_idles/maya_events.rpy:1415
translate chinese maya_scene14_afternoon_myroom_cab2c2bb:

    # Maya "Пять"
    Maya "五"

# game/characters_events_idles/maya_events.rpy:1417
translate chinese maya_scene14_afternoon_myroom_b4e47535:

    # Maya "И потом делай что хочешь"
    Maya "然后做你想做的"

# game/characters_events_idles/maya_events.rpy:1419
translate chinese maya_scene14_afternoon_myroom_9b6c39fb:

    # Maya "Только не думай, что это признание"
    Maya "只是不想让你以为这是表白"

# game/characters_events_idles/maya_events.rpy:1426
translate chinese maya_scene14_afternoon_myroom_93de4523:

    # Maya "Чeрт . . . каждый раз будто в первый"
    Maya "该死。。。每次都像是第一次"

# game/characters_events_idles/maya_events.rpy:1433
translate chinese maya_scene14_afternoon_myroom_3179047f:

    # Maya "Неужели всё это . . . мне?"
    Maya "这一切。。。是给我的吗？"

# game/characters_events_idles/maya_events.rpy:1439
translate chinese maya_scene14_afternoon_myroom_8135a08f:

    # Maya "Такой . . . наглый"
    Maya "如此。。。厚颜无耻"

# game/characters_events_idles/maya_events.rpy:1441
translate chinese maya_scene14_afternoon_myroom_b3c83659:

    # Maya "И такой тeплый . . ."
    Maya "如此温暖。。。"

# game/characters_events_idles/maya_events.rpy:1449
translate chinese maya_scene14_afternoon_myroom_6a11d281:

    # Maya "Держись . . ."
    Maya "坚持住。。。"

# game/characters_events_idles/maya_events.rpy:1455
translate chinese maya_scene14_afternoon_myroom_53e2be3e:

    # Maya ". . . Всe"
    Maya ". . . 一切"

# game/characters_events_idles/maya_events.rpy:1459
translate chinese maya_scene14_afternoon_myroom_1f177920:

    # Maya "Моe"
    Maya "我的"

# game/characters_events_idles/maya_events.rpy:1463
translate chinese maya_scene14_afternoon_myroom_9f7300e6:

    # Maya "Все"
    Maya "一切"

# game/characters_events_idles/maya_events.rpy:1465
translate chinese maya_scene14_afternoon_myroom_00c0f420:

    # Maya "Иди"
    Maya "走"

# game/characters_events_idles/maya_events.rpy:1467
translate chinese maya_scene14_afternoon_myroom_0efb861b:

    # gg "Ты уверена?"
    gg "你确定吗？"

# game/characters_events_idles/maya_events.rpy:1469
translate chinese maya_scene14_afternoon_myroom_362d3834:

    # Maya "Ага"
    Maya "嗯"

# game/characters_events_idles/maya_events.rpy:1471
translate chinese maya_scene14_afternoon_myroom_31d3f8e7:

    # Maya "Только не пропадай"
    Maya "只是不许消失"

# game/characters_events_idles/maya_events.rpy:1473
translate chinese maya_scene14_afternoon_myroom_baa7f0c3:

    # Maya "Ты всё равно вернешься"
    Maya "你总会回来的"
