﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/maya_idles.rpy:7
translate chinese maya_Idle_day_myroom_scene_5a17c289:

    # gg "А я думал, этот предатель спит только у Сони"
    gg "我以为这个叛徒只睡在索尼娅家"

# game/characters_events_idles/maya_idles.rpy:9
translate chinese maya_Idle_day_myroom_scene_67e33434:

    # Maya "Он выбирает по настроению"
    Maya "他根据自己的心情来选择"

# game/characters_events_idles/maya_idles.rpy:10
translate chinese maya_Idle_day_myroom_scene_d5b84977:

    # Maya "Сегодня, видимо, у меня нужная температура коленей"
    Maya "今天，显然我的膝盖温度合适"

# game/characters_events_idles/maya_idles.rpy:11
translate chinese maya_Idle_day_myroom_scene_60432ccb:

    # gg "Или просто знаешь, чем подкупить"
    gg "或者你只是知道如何行贿"

# game/characters_events_idles/maya_idles.rpy:13
translate chinese maya_Idle_day_myroom_scene_e3e70aea:

    # Maya "Конечно"
    Maya "当然"

# game/characters_events_idles/maya_idles.rpy:14
translate chinese maya_Idle_day_myroom_scene_d43eb27c:

    # Maya "Я его нашла - я и лицензированный поставщик любви и корма"
    Maya "我找到了——我和一个有执照的爱和食物供应商"

# game/characters_events_idles/maya_idles.rpy:15
translate chinese maya_Idle_day_myroom_scene_567c8898:

    # gg "Нашла?"
    gg "你找到了吗？"

# game/characters_events_idles/maya_idles.rpy:17
translate chinese maya_Idle_day_myroom_scene_a785c258:

    # Maya "Год назад. Под дождём, под машиной сидел"
    Maya "一年前。雨中，坐在车底下"

# game/characters_events_idles/maya_idles.rpy:18
translate chinese maya_Idle_day_myroom_scene_81fc3249:

    # Maya "Маленький, грязный, дрожал, а я шла домой с кофе"
    Maya "又小又脏又颤抖，我拿着咖啡走回家"

# game/characters_events_idles/maya_idles.rpy:19
translate chinese maya_Idle_day_myroom_scene_f0aa2ab7:

    # Maya "И подумала: “Ладно, кофе подождёт”"
    Maya "我想：“好吧，咖啡可以等一等。”"

# game/characters_events_idles/maya_idles.rpy:21
translate chinese maya_Idle_day_myroom_scene_8924b2a5:

    # Maya "С тех пор он решил, что я его персональный обогреватель"
    Maya "从此他就认定我就是他的私人暖气"

# game/characters_events_idles/maya_idles.rpy:23
translate chinese maya_Idle_day_myroom_scene_38f294e2:

    # gg "Повезло ему"
    gg "他很幸运"

# game/characters_events_idles/maya_idles.rpy:25
translate chinese maya_Idle_day_myroom_scene_1538c3c1:

    # Maya "Ага. Только не говори Соне, что я так сказала"
    Maya "是的。只是别告诉索尼娅是我这么说的"

# game/characters_events_idles/maya_idles.rpy:26
translate chinese maya_Idle_day_myroom_scene_d9ab69f9:

    # Maya "Она делает вид, что ей всё равно, но я видела, как она однажды сушила ему лапы феном"
    Maya "她假装不在乎，但我看到她有一次吹干他的爪子"

# game/characters_events_idles/maya_idles.rpy:27
translate chinese maya_Idle_day_myroom_scene_5e0ad0a7:

    # gg "Правда? Не ожидал"
    gg "这是真的吗？没想到"

# game/characters_events_idles/maya_idles.rpy:28
translate chinese maya_Idle_day_myroom_scene_e31c6d2d:

    # Maya "Ну, она просто не из тех, кто сюсюкает. Но и не выгонит"
    Maya "好吧，她不是一个口齿不清的人。但他也不会把我赶出去"

# game/characters_events_idles/maya_idles.rpy:29
translate chinese maya_Idle_day_myroom_scene_5e1c1537:

    # Maya "Иногда подкармливает, когда думает, что я не вижу"
    Maya "有时当他认为我看不见时他就会喂我"

# game/characters_events_idles/maya_idles.rpy:30
translate chinese maya_Idle_day_myroom_scene_dd7932db:

    # Maya "У нас, знаешь, баланс: я - шум, она - порядок, а Барсик - нейтральная территория"
    Maya "你知道，我们有一个平衡：我是噪音，她是秩序，而巴尔西克是中立领土"

# game/characters_events_idles/maya_idles.rpy:31
translate chinese maya_Idle_day_myroom_scene_ff61f178:

    # gg "И кто из вас лидер?"
    gg "你们中哪一位是领导者？"

# game/characters_events_idles/maya_idles.rpy:33
translate chinese maya_Idle_day_myroom_scene_4579d2be:

    # Maya "Он. Сто процентов"
    Maya "他。百分之一百"

# game/characters_events_idles/maya_idles.rpy:34
translate chinese maya_Idle_day_myroom_scene_73c39706:

    # Maya "Ему всё равно, кто орёт, кто убирает - он всё равно получает своё место и миску"
    Maya "他不在乎谁喊叫或谁打扫——他仍然得到他的位置和碗。"

# game/characters_events_idles/maya_idles.rpy:36
translate chinese maya_Idle_day_myroom_scene_c39583ae:

    # Maya "Видишь? {w}Даже в доме с нами двумя кто-то умеет быть по-настоящему счастливым"
    Maya "你看到了吗？ {w}即使是我们两个人住在一间房子里，也有人知道如何真正快乐"

# game/characters_events_idles/maya_idles.rpy:38
translate chinese maya_Idle_day_myroom_scene_04531df3:

    # gg "Может, секрет в том, чтобы просто мурчать и не спорить"
    gg "也许秘密就是只咕噜咕噜而不是争论。"

# game/characters_events_idles/maya_idles.rpy:39
translate chinese maya_Idle_day_myroom_scene_25a0e3ac:

    # Maya "Или в том, чтобы спать на тёплом и не думать"
    Maya "或者是睡得暖和而不去想"

# game/characters_events_idles/maya_idles.rpy:54
translate chinese maya_Idle_morning_myroom_scene_323bf253:

    # gg "Уже читаешь? . . ."
    gg "已经在读了吗？ 。 。 。"

# game/characters_events_idles/maya_idles.rpy:55
translate chinese maya_Idle_morning_myroom_scene_92e4f307:

    # Maya "Ага. Утро тихое, редкость"
    Maya "是的。安静的早晨是难得的"

# game/characters_events_idles/maya_idles.rpy:56
translate chinese maya_Idle_morning_myroom_scene_43a1c1b0:

    # Maya "Грех не пользоваться, пока никто не шумит и не ищет кружку"
    Maya "当没有人制造噪音或寻找杯子时不使用它是一种罪过。"

# game/characters_events_idles/maya_idles.rpy:57
translate chinese maya_Idle_morning_myroom_scene_7ac1c8ed:

    # gg "Что на этот раз?"
    gg "这次是什么时候？"

# game/characters_events_idles/maya_idles.rpy:59
translate chinese maya_Idle_morning_myroom_scene_6a78f6bb:

    # Maya "Манга"
    Maya "漫画"

# game/characters_events_idles/maya_idles.rpy:60
translate chinese maya_Idle_morning_myroom_scene_932f7db6:

    # Maya "После Линдиных книг захотелось чего-то полегче"
    Maya "在琳达的书之后我想要一些更轻松的东西"

# game/characters_events_idles/maya_idles.rpy:62
translate chinese maya_Idle_morning_myroom_scene_cffdb9b8:

    # Maya "Она могла читать про философию даже за ужином"
    Maya "她甚至在晚餐时也能阅读哲学书籍"

# game/characters_events_idles/maya_idles.rpy:63
translate chinese maya_Idle_morning_myroom_scene_3d9df54a:

    # Maya "Я же за ужином максимум комментирую философию людей в интернете"
    Maya "吃饭的时候最多评论一下网上人家的哲学。"

# game/characters_events_idles/maya_idles.rpy:65
translate chinese maya_Idle_morning_myroom_scene_c6ff46fa:

    # Maya "Хотя по этой манге не скажешь"
    Maya "虽然从漫画中看不出来"

# game/characters_events_idles/maya_idles.rpy:66
translate chinese maya_Idle_morning_myroom_scene_5ff05dc4:

    # Maya "Автор явно страдал, но красиво"
    Maya "作者明显受苦了，但是很美"

# game/characters_events_idles/maya_idles.rpy:67
translate chinese maya_Idle_morning_myroom_scene_f96de996:

    # gg "К картинкам и эмоциям?"
    gg "为了图片和情感？"

# game/characters_events_idles/maya_idles.rpy:69
translate chinese maya_Idle_morning_myroom_scene_b2396673:

    # Maya "К историям, где герои хотя бы честные"
    Maya "英雄们至少是诚实的故事"

# game/characters_events_idles/maya_idles.rpy:71
translate chinese maya_Idle_morning_myroom_scene_6e6a997d:

    # Maya "Иногда читаю японское или корейское"
    Maya "有时我读日语或韩语"

# game/characters_events_idles/maya_idles.rpy:72
translate chinese maya_Idle_morning_myroom_scene_3aeeaab4:

    # Maya "У них всё немного грустно, но по-тёплому"
    Maya "他们的一切都有点悲伤，但又很温暖"

# game/characters_events_idles/maya_idles.rpy:73
translate chinese maya_Idle_morning_myroom_scene_d16d1737:

    # Maya "В отличие от наших драм, где все страдают просто из принципа"
    Maya "不像我们的戏剧，每个人都只是出于原则而受苦"

# game/characters_events_idles/maya_idles.rpy:74
translate chinese maya_Idle_morning_myroom_scene_0bb250f6:

    # gg "Под настроение, значит"
    gg "心情上，就是"

# game/characters_events_idles/maya_idles.rpy:76
translate chinese maya_Idle_morning_myroom_scene_bc0bb57f:

    # Maya "Угу. Когда настроение “оставьте меня в покое, но с уютом”"
    Maya "是的。当心情是“别管我，但要安慰”"

# game/characters_events_idles/maya_idles.rpy:77
translate chinese maya_Idle_morning_myroom_scene_c92c399c:

    # gg "Ты давно здесь?"
    gg "你来这里多久了？"

# game/characters_events_idles/maya_idles.rpy:79
translate chinese maya_Idle_morning_myroom_scene_8b0e76c6:

    # Maya "Год, может чуть больше"
    Maya "一年，也许还有一点"

# game/characters_events_idles/maya_idles.rpy:80
translate chinese maya_Idle_morning_myroom_scene_924b98a2:

    # Maya "После универа приехала в посёлок работать. Захотелось тишины и воздуха"
    Maya "大学毕业后，我来到村里打工。我想要安静和空气"

# game/characters_events_idles/maya_idles.rpy:82
translate chinese maya_Idle_morning_myroom_scene_f611f1fe:

    # Maya "Искала жильё - наткнулась на объявление: “Сдам комнату. Дом с садом”"
    Maya "我在找房子时看到一则广告：“房间出租。带花园的房子。”"

# game/characters_events_idles/maya_idles.rpy:83
translate chinese maya_Idle_morning_myroom_scene_12f76597:

    # Maya "Открывает дверь Линда и спрашивает: “Ты громкая?”"
    Maya "琳达打开门，问道：“你声音大吗？”"

# game/characters_events_idles/maya_idles.rpy:84
translate chinese maya_Idle_morning_myroom_scene_5517b596:

    # Maya "Я ответила: “Только когда думаю.” Она засмеялась и сказала: “Тогда уживайся”"
    Maya "我回答：“只有当我想的时候。”她笑道：“那就一起来吧。”"

# game/characters_events_idles/maya_idles.rpy:85
translate chinese maya_Idle_morning_myroom_scene_20b975de:

    # gg "И Соня уже тут была?"
    gg "索尼娅已经来了？"

# game/characters_events_idles/maya_idles.rpy:87
translate chinese maya_Idle_morning_myroom_scene_37745fdb:

    # Maya "Да. Мы познакомились на кухне, где я чуть не спалила чайник"
    Maya "是的。我们在厨房见面，我差点烧了水壶"

# game/characters_events_idles/maya_idles.rpy:88
translate chinese maya_Idle_morning_myroom_scene_4e7209b5:

    # Maya "С тех пор она - порядок, я - импровизация"
    Maya "从此她是命令，我是即兴"

# game/characters_events_idles/maya_idles.rpy:89
translate chinese maya_Idle_morning_myroom_scene_f337d502:

    # Maya "Иногда даже чай кипит от ужаса"
    Maya "有时连茶都沸腾了"

# game/characters_events_idles/maya_idles.rpy:90
translate chinese maya_Idle_morning_myroom_scene_b1814b27:

    # Maya "Линда звала нас “шум и тишина”"
    Maya "琳达称我们为“噪音和沉默”"

# game/characters_events_idles/maya_idles.rpy:91
translate chinese maya_Idle_morning_myroom_scene_ab4dac88:

    # Maya "Хотя, скорее, “тишина и источник хаоса”"
    Maya "尽管，更确切地说，“沉默和混乱的根源”"

# game/characters_events_idles/maya_idles.rpy:92
translate chinese maya_Idle_morning_myroom_scene_f2159d17:

    # gg "А теперь ещё и я"
    gg "现在我也是"

# game/characters_events_idles/maya_idles.rpy:94
translate chinese maya_Idle_morning_myroom_scene_ecb2ad9f:

    # Maya "Теперь да. Баланс окончательно нарушен, но зато весело"
    Maya "现在是的。平衡完全被打破了，但是很有趣"

# game/characters_events_idles/maya_idles.rpy:96
translate chinese maya_Idle_morning_myroom_scene_cea1d0c9:

    # Maya "Вон, слышишь? Она уже с шести на ногах"
    Maya "看，你听到了吗？她从六岁起就已经站起来了"

# game/characters_events_idles/maya_idles.rpy:97
translate chinese maya_Idle_morning_myroom_scene_deefee09:

    # Maya "Я так пробовала - уснула прямо с кружкой в руке"
    Maya "我试过了 - 我手里拿着杯子睡着了"

# game/characters_events_idles/maya_idles.rpy:98
translate chinese maya_Idle_morning_myroom_scene_bd135488:

    # Maya "Зато хоть кто-то следит, чтобы дом не просыпался в хаосе. Я - больше за безделие"
    Maya "但至少有人在确保房子不会在混乱中醒来。我比较喜欢闲着"

# game/characters_events_idles/maya_idles.rpy:113
translate chinese maya_Idle_evening_bathroom_scene_d8fba7e0:

    # gg "Ко сну готовишься?"
    gg "你准备好睡觉了吗？"

# game/characters_events_idles/maya_idles.rpy:114
translate chinese maya_Idle_evening_bathroom_scene_768e9905:

    # Maya "Ага. Осталось немного. Главное, чтобы никто не отвлекал"
    Maya "是的。所剩无几了。最主要的是没人打扰"

# game/characters_events_idles/maya_idles.rpy:115
translate chinese maya_Idle_evening_bathroom_scene_c84b09d3:

    # Maya "А то всё придётся начинать заново — тут процесс деликатный"
    Maya "否则，一切都得重新开始——这是一个微妙的过程"

# game/characters_events_idles/maya_idles.rpy:116
translate chinese maya_Idle_evening_bathroom_scene_ff89b4d4:

    # gg "Надеюсь, ты не про стирку опять"
    gg "我希望你不要再谈论洗衣服的事了"

# game/characters_events_idles/maya_idles.rpy:118
translate chinese maya_Idle_evening_bathroom_scene_63a219ac:

    # Maya "А что, если и про неё? Не все вещи выдерживают жёсткий режим"
    Maya "如果是关于她呢？并不是所有的东西都能经受住恶劣的条件"

# game/characters_events_idles/maya_idles.rpy:119
translate chinese maya_Idle_evening_bathroom_scene_16a58674:

    # gg "В прошлый раз ты, кажется, не всё достирала"
    gg "上次你好像还没有完成所有事情"

# game/characters_events_idles/maya_idles.rpy:121
translate chinese maya_Idle_evening_bathroom_scene_6782c239:

    # Maya "Ха. Ну, издержки ручной работы. Зато результат запомнился, верно?"
    Maya "哈。嗯，手工作业的成本。但结果令人难忘，对吧？"

# game/characters_events_idles/maya_idles.rpy:122
translate chinese maya_Idle_evening_bathroom_scene_d25c24db:

    # gg "Даже слишком"
    gg "甚至太多"

# game/characters_events_idles/maya_idles.rpy:124
translate chinese maya_Idle_evening_bathroom_scene_a5bb0cfc:

    # Maya "Значит, не зря старалась"
    Maya "所以我的努力并没有白费"

# game/characters_events_idles/maya_idles.rpy:126
translate chinese maya_Idle_evening_bathroom_scene_91354786:

    # Maya "Правда, немного смущалась. Такое со мной редко бывает"
    Maya "确实，我有点尴尬。这很少发生在我身上"

# game/characters_events_idles/maya_idles.rpy:127
translate chinese maya_Idle_evening_bathroom_scene_2b597177:

    # gg "Удивительно. Я думал, ты вообще не из тех, кто смущается"
    gg "奇妙。我以为你根本不是那种会害羞的人"

# game/characters_events_idles/maya_idles.rpy:129
translate chinese maya_Idle_evening_bathroom_scene_aa3db339:

    # Maya "Все когда-то ошибаются. Но не переживай, в следующий раз я компенсирую моральный ущерб"
    Maya "每个人都有犯错误的时候。不过放心吧，下次我会赔偿精神损失的"

# game/characters_events_idles/maya_idles.rpy:130
translate chinese maya_Idle_evening_bathroom_scene_ed2cbd06:

    # gg "Это угроза или обещание?"
    gg "这是威胁还是承诺？"

# game/characters_events_idles/maya_idles.rpy:132
translate chinese maya_Idle_evening_bathroom_scene_0f1383f3:

    # Maya "Назови это приглашением на повторный эксперимент"
    Maya "称之为重试邀请"

# game/characters_events_idles/maya_idles.rpy:147
translate chinese maya_Idle_morning_kitchen_scene_ff259315:

    # gg "Это так теперь готовят яищницу?"
    gg "现在炒鸡蛋都是这样炒的吗？"

# game/characters_events_idles/maya_idles.rpy:148
translate chinese maya_Idle_morning_kitchen_scene_2a72a3a2:

    # Maya "Умник. Не все рождаются с магией кулинарии, ладно?"
    Maya "聪明的家伙。不是每个人天生就有烹饪魔法，好吗？"

# game/characters_events_idles/maya_idles.rpy:149
translate chinese maya_Idle_morning_kitchen_scene_5c70bf26:

    # Maya "Обычно Соня этим занимается"
    Maya "索尼娅通常这样做"

# game/characters_events_idles/maya_idles.rpy:151
translate chinese maya_Idle_morning_kitchen_scene_602f32f7:

    # Maya "Вот, видишь? Сковородка меня ненавидит"
    Maya "看到这里了吗？煎锅讨厌我"

# game/characters_events_idles/maya_idles.rpy:152
translate chinese maya_Idle_morning_kitchen_scene_6441a501:

    # gg "Ага, ты с ней просто не разговариваешь достаточно вежливо"
    gg "是的，你只是不够礼貌地和她说话。"

# game/characters_events_idles/maya_idles.rpy:154
translate chinese maya_Idle_morning_kitchen_scene_92534113:

    # Maya "Серьёзно? Может, ей ещё комплимент сказать?"
    Maya "严重地？也许我应该再夸奖她一次？"

# game/characters_events_idles/maya_idles.rpy:155
translate chinese maya_Idle_morning_kitchen_scene_9a46a58c:

    # gg "Можешь попробовать. Я подстрахую, если начнёт мстить"
    gg "你可以尝试一下。如果他开始报复我会支持你"

# game/characters_events_idles/maya_idles.rpy:157
translate chinese maya_Idle_morning_kitchen_scene_f6d334fe:

    # Maya "Вот именно поэтому я по утрам не встаю"
    Maya "这就是我早上起不来的原因"

# game/characters_events_idles/maya_idles.rpy:159
translate chinese maya_Idle_morning_kitchen_scene_b8a73fc6:

    # Maya "Мир в это время суток явно против меня"
    Maya "世界在一天中的这个时候显然与我作对"

# game/characters_events_idles/maya_idles.rpy:160
translate chinese maya_Idle_morning_kitchen_scene_92828b86:

    # gg "А я думал, это просто твой ритуал - проспать завтрак и появиться к обеду"
    gg "我以为睡过早餐然后出来吃午饭只是你的习惯"

# game/characters_events_idles/maya_idles.rpy:162
translate chinese maya_Idle_morning_kitchen_scene_2d194bcc:

    # Maya "Был"
    Maya "曾是"

# game/characters_events_idles/maya_idles.rpy:163
translate chinese maya_Idle_morning_kitchen_scene_06f3f849:

    # Maya "Но с твоим появлением режим сбился"
    Maya "但随着你的出现，政权误入歧途"

# game/characters_events_idles/maya_idles.rpy:165
translate chinese maya_Idle_morning_kitchen_scene_c5cd9bdc:

    # Maya "Знаешь . . . {w}странно, когда в доме появился кто-то третий"
    Maya "你知道 。 。 。 {w}当房子里出现其他人时，感觉很奇怪"

# game/characters_events_idles/maya_idles.rpy:167
translate chinese maya_Idle_morning_kitchen_scene_2d60322d:

    # gg "“Странно” - в хорошем смысле?"
    gg "“奇怪”——以一种好的方式？"

# game/characters_events_idles/maya_idles.rpy:169
translate chinese maya_Idle_morning_kitchen_scene_0392e6e1:

    # Maya "Скорее . . . непривычно."
    Maya "快一点。 。 。异常。"

# game/characters_events_idles/maya_idles.rpy:170
translate chinese maya_Idle_morning_kitchen_scene_09dca06f:

    # Maya "Мы с Соней как будто уже притёрлись. У неё - тишина, у меня - беспорядок"
    Maya "我和索尼娅似乎已经习惯了。她有沉默，我有混乱"

# game/characters_events_idles/maya_idles.rpy:171
translate chinese maya_Idle_morning_kitchen_scene_f70c520e:

    # Maya "А теперь добавился ты. И вроде ничего не изменилось, но стало . . . другое"
    Maya "现在您已被添加。看起来一切都没有改变，但事实确实如此。 。 。其他"

# game/characters_events_idles/maya_idles.rpy:173
translate chinese maya_Idle_morning_kitchen_scene_ac44cc52:

    # gg "Надеюсь, не хуже"
    gg "我希望情况不会更糟"

# game/characters_events_idles/maya_idles.rpy:174
translate chinese maya_Idle_morning_kitchen_scene_7331e581:

    # Maya "Пока нет"
    Maya "还没有"

# game/characters_events_idles/maya_idles.rpy:175
translate chinese maya_Idle_morning_kitchen_scene_a84e22a5:

    # Maya "Иногда даже спокойнее . . . а иногда бесишь"
    Maya "有时甚至更平静。 。 。有时你会激怒"

# game/characters_events_idles/maya_idles.rpy:190
translate chinese maya_Idle_day_kitchen_scene_1cdbaa35:

    # gg "Не верится"
    gg "我简直不敢相信"

# game/characters_events_idles/maya_idles.rpy:191
translate chinese maya_Idle_day_kitchen_scene_286ac20b:

    # gg "Ты с чаем? Где же твоя коллекция вредных газировок?"
    gg "你有茶吗？您收集的有害苏打水在哪里？"

# game/characters_events_idles/maya_idles.rpy:193
translate chinese maya_Idle_day_kitchen_scene_158529f9:

    # Maya "Иногда организм хочет чай и все"
    Maya "有时身体需要茶，仅此而已"

# game/characters_events_idles/maya_idles.rpy:194
translate chinese maya_Idle_day_kitchen_scene_61e5a4a1:

    # Maya "И не хочу, чтобы Соня опять читала лекцию о “здоровом балансе”"
    Maya "我不想让索尼娅再次发表有关“健康平衡”的演讲。"

# game/characters_events_idles/maya_idles.rpy:195
translate chinese maya_Idle_day_kitchen_scene_0a361203:

    # gg "О, значит, это не просто чай - это акт самопожертвования"
    gg "哦，所以这不仅仅是茶——这是一种自我牺牲的行为"

# game/characters_events_idles/maya_idles.rpy:197
translate chinese maya_Idle_day_kitchen_scene_d1dbd3ae:

    # Maya "Ага. Пью и страдаю"
    Maya "是的。我喝酒并受苦"

# game/characters_events_idles/maya_idles.rpy:199
translate chinese maya_Idle_day_kitchen_scene_8b4629d0:

    # Maya "Ладно, раз уж ты сам подошёл - что планируешь делать?"
    Maya "好吧，既然你已经上来了，那么你打算做什么呢？"

# game/characters_events_idles/maya_idles.rpy:200
translate chinese maya_Idle_day_kitchen_scene_51392b4e:

    # gg "В смысле?"
    gg "按照？"

# game/characters_events_idles/maya_idles.rpy:202
translate chinese maya_Idle_day_kitchen_scene_e2d10f18:

    # Maya "Ну, в целом"
    Maya "嗯，一般来说"

# game/characters_events_idles/maya_idles.rpy:203
translate chinese maya_Idle_day_kitchen_scene_3b447692:

    # Maya "Сидеть, отдыхать, страдать или притворяться, что у тебя есть план?"
    Maya "坐下、放松、受苦，还是假装你有计划？"

# game/characters_events_idles/maya_idles.rpy:204
translate chinese maya_Idle_day_kitchen_scene_ba096a56:

    # gg "План есть - не иметь плана. Хотя, если честно, я просто устал от города"
    gg "有计划——没有计划。虽然说实话，我只是厌倦了这座城市"

# game/characters_events_idles/maya_idles.rpy:205
translate chinese maya_Idle_day_kitchen_scene_a341feee:

    # gg "Хотел отдохнуть, помочь бабушке с домом . . . {w}ну, а теперь, похоже, пора искать работу"
    gg "我想放松一下，帮奶奶做家务。 。 。 {w}嗯，现在看来是时候找份工作了"

# game/characters_events_idles/maya_idles.rpy:207
translate chinese maya_Idle_day_kitchen_scene_226b1041:

    # Maya "Добро пожаловать в реальность"
    Maya "欢迎来到现实"

# game/characters_events_idles/maya_idles.rpy:208
translate chinese maya_Idle_day_kitchen_scene_a886fda9:

    # Maya "И где ищут работу люди, которые сбежали от людей?"
    Maya "而那些逃离人群的人到哪里去找工作呢？"

# game/characters_events_idles/maya_idles.rpy:210
translate chinese maya_Idle_day_kitchen_scene_a73a3597:

    # gg "Пока не знаю. Может, в посёлке что-то найду"
    gg "我还不知道。也许我会在村里找到一些东西"

# game/characters_events_idles/maya_idles.rpy:211
translate chinese maya_Idle_day_kitchen_scene_a04c7319:

    # gg "Мне и ритм нравится - медленный, настоящий"
    gg "我也喜欢节奏——缓慢、真实"

# game/characters_events_idles/maya_idles.rpy:212
translate chinese maya_Idle_day_kitchen_scene_4dc705a2:

    # Maya "Настоящий?"
    Maya "真实的？"

# game/characters_events_idles/maya_idles.rpy:213
translate chinese maya_Idle_day_kitchen_scene_57978980:

    # Maya "Это пока ты не застрянешь тут зимой"
    Maya "直到冬天你被困在这里。"

# game/characters_events_idles/maya_idles.rpy:214
translate chinese maya_Idle_day_kitchen_scene_25de1f66:

    # gg "Зато не метро и не толпы"
    gg "但不是地铁，不是人群"

# game/characters_events_idles/maya_idles.rpy:216
translate chinese maya_Idle_day_kitchen_scene_f04c48a5:

    # Maya "Ну да. Только мы и Барсик, который судя по всему - местный депутат"
    Maya "嗯，是的。只有我们和巴尔西克，他显然是当地的一名代表"

# game/characters_events_idles/maya_idles.rpy:217
translate chinese maya_Idle_day_kitchen_scene_9b820f0a:

    # gg "Главное, чтобы не требовал отчёта о проделанной работе"
    gg "最主要的是不需要报告已完成的工作"

# game/characters_events_idles/maya_idles.rpy:219
translate chinese maya_Idle_day_kitchen_scene_67b66e53:

    # Maya "Ага. Хотя Соня могла бы - она бы тебе график расписала"
    Maya "是的。虽然索尼娅可以 - 她会为你写出一个时间表"

# game/characters_events_idles/maya_idles.rpy:220
translate chinese maya_Idle_day_kitchen_scene_d9d4e1ed:

    # gg "Я замечал. У неё всё как по часам"
    gg "我注意到了。她做的一切都像发条一样"

# game/characters_events_idles/maya_idles.rpy:222
translate chinese maya_Idle_day_kitchen_scene_8841e92a:

    # Maya "Потому что кто-то в этом доме должен компенсировать мой хаос"
    Maya "因为这所房子里有人需要弥补我的混乱"

# game/characters_events_idles/maya_idles.rpy:224
translate chinese maya_Idle_day_kitchen_scene_962fec54:

    # Maya "Так что, если решишь остаться надолго, готовься привыкать к контрастам"
    Maya "因此，如果您决定长期停留，请准备好适应对比"

# game/characters_events_idles/maya_idles.rpy:225
translate chinese maya_Idle_day_kitchen_scene_5401d48b:

    # gg "Мне кажется, я уже начинаю"
    gg "我想我已经开始了"

# game/characters_events_idles/maya_idles.rpy:226
translate chinese maya_Idle_day_kitchen_scene_a207aba8:

    # Maya "Осторожнее"
    Maya "当心"

# game/characters_events_idles/maya_idles.rpy:227
translate chinese maya_Idle_day_kitchen_scene_2fbe2d88:

    # Maya "Это затягивает"
    Maya "很容易上瘾"

# game/characters_events_idles/maya_idles.rpy:241
translate chinese maya_Idle_morning_mayaroom_scene_f8fe1494:

    # gg ". . . "
    gg "。 。 。"

# game/characters_events_idles/maya_idles.rpy:242
translate chinese maya_Idle_morning_mayaroom_scene_7e0bd9fb:

    # gg "Так сладко спит"
    gg "睡得真香甜"

# game/characters_events_idles/maya_idles.rpy:253
translate chinese maya_Idle_day_mayaroom_scene_94873986:

    # gg "Серьёзный вид"
    gg "严肃的表情"

# game/characters_events_idles/maya_idles.rpy:254
translate chinese maya_Idle_day_mayaroom_scene_80d9437f:

    # gg "Ты что, музыку миксуешь?"
    gg "你在混合音乐吗？"

# game/characters_events_idles/maya_idles.rpy:256
translate chinese maya_Idle_day_mayaroom_scene_f4b03c23:

    # Maya "Ха, мечтай. Работаю"
    Maya "哈，做梦吧。在职的"

# game/characters_events_idles/maya_idles.rpy:257
translate chinese maya_Idle_day_mayaroom_scene_f8277c64:

    # gg "Звучит опасно. А я думал, ты против дисциплины"
    gg "听起来很危险。我以为你违反纪律"

# game/characters_events_idles/maya_idles.rpy:259
translate chinese maya_Idle_day_mayaroom_scene_7888996f:

    # Maya "Я против бессмысленной дисциплины"
    Maya "我反对毫无意义的纪律"

# game/characters_events_idles/maya_idles.rpy:260
translate chinese maya_Idle_day_mayaroom_scene_927b0fd4:

    # Maya "Но если платят - можно и притвориться взрослой"
    Maya "但如果他们付钱，你就可以假装成成年人"

# game/characters_events_idles/maya_idles.rpy:261
translate chinese maya_Idle_day_mayaroom_scene_d96b72a5:

    # gg "И что за работа?"
    gg "以及什么样的工作？"

# game/characters_events_idles/maya_idles.rpy:263
translate chinese maya_Idle_day_mayaroom_scene_c6edbdd9:

    # Maya "Связано с проектами. Неинтересно"
    Maya "与项目相关。没兴趣"

# game/characters_events_idles/maya_idles.rpy:264
translate chinese maya_Idle_day_mayaroom_scene_3908c185:

    # Maya "Раньше приходилось ездить в офис, а теперь могу делать всё из дома"
    Maya "以前我必须去办公室，但现在我可以在家做所有事情"

# game/characters_events_idles/maya_idles.rpy:266
translate chinese maya_Idle_day_mayaroom_scene_0fc56267:

    # Maya "Так что не мешай моей продуктивности"
    Maya "所以不要影响我的工作效率"

# game/characters_events_idles/maya_idles.rpy:267
translate chinese maya_Idle_day_mayaroom_scene_77dec125:

    # gg "Не мешаю"
    gg "我不干涉"

# game/characters_events_idles/maya_idles.rpy:268
translate chinese maya_Idle_day_mayaroom_scene_585ed193:

    # gg "Просто проверяю, не заснула ли ты с открытым документом"
    gg "只是检查一下您是否在打开文档的情况下睡着了"

# game/characters_events_idles/maya_idles.rpy:270
translate chinese maya_Idle_day_mayaroom_scene_e95f31f8:

    # Maya "Ещё нет"
    Maya "还没有"

# game/characters_events_idles/maya_idles.rpy:271
translate chinese maya_Idle_day_mayaroom_scene_4d0580f6:

    # Maya "Но если будешь стоять и таращиться, это ускорит процесс"
    Maya "但如果你站着凝视，就会加速这个过程"

# game/characters_events_idles/maya_idles.rpy:274
translate chinese maya_Idle_day_mayaroom_scene_d2135720:

    # Maya "И да, на будущее . . ."
    Maya "是的，为了未来。 。 。"

# game/characters_events_idles/maya_idles.rpy:275
translate chinese maya_Idle_day_mayaroom_scene_8af163bc:

    # Maya "Стучи, когда входишь"
    Maya "进入时请敲门"

# game/characters_events_idles/maya_idles.rpy:276
translate chinese maya_Idle_day_mayaroom_scene_9797f5b6:

    # gg "А ты дверь закрывай, если хочешь секретности"
    gg "如果你想要保密就关上门"

# game/characters_events_idles/maya_idles.rpy:278
translate chinese maya_Idle_day_mayaroom_scene_7d229fff:

    # Maya "Закрытая дверь - это скучно"
    Maya "关上门很无聊"

# game/characters_events_idles/maya_idles.rpy:279
translate chinese maya_Idle_day_mayaroom_scene_6d90d8fb:

    # Maya "Мне нравится знать, что кто-то может ввалиться в самый неподходящий момент. Добавляет адреналина"
    Maya "我喜欢知道有人可能会在最不合时宜的时刻闯入。添加肾上腺素"

# game/characters_events_idles/maya_idles.rpy:280
translate chinese maya_Idle_day_mayaroom_scene_5348c7b0:

    # gg "Опасное хобби"
    gg "危险的爱好"

# game/characters_events_idles/maya_idles.rpy:295
translate chinese maya_Idle_evening_mayaroom_scene_c74a33fe:

    # gg "Опять зависла?"
    gg "又冻结了？"

# game/characters_events_idles/maya_idles.rpy:297
translate chinese maya_Idle_evening_mayaroom_scene_66aa8fb0:

    # Maya "Называется “отдыхаю”"
    Maya "这就是所谓的“休息”"

# game/characters_events_idles/maya_idles.rpy:298
translate chinese maya_Idle_evening_mayaroom_scene_29fea123:

    # Maya "Иногда даже без музыки"
    Maya "有时甚至没有音乐"

# game/characters_events_idles/maya_idles.rpy:299
translate chinese maya_Idle_evening_mayaroom_scene_bbc28184:

    # gg "Опасный эксперимент"
    gg "危险的实验"

# game/characters_events_idles/maya_idles.rpy:300
translate chinese maya_Idle_evening_mayaroom_scene_cc606e86:

    # Maya "Ага. Учёные уже фиксируют первые побочные эффекты - мысли начали возвращаться"
    Maya "是的。科学家们已经记录了第一个副作用——思想已经开始回归"

# game/characters_events_idles/maya_idles.rpy:301
translate chinese maya_Idle_evening_mayaroom_scene_a4eb2f4d:

    # gg "О чём думаешь?"
    gg "你在想什么？"

# game/characters_events_idles/maya_idles.rpy:303
translate chinese maya_Idle_evening_mayaroom_scene_f963639a:

    # Maya "Ни о чём особенном. Просто день какой-то неспокойный"
    Maya "没什么特别的。这只是不安的一天"

# game/characters_events_idles/maya_idles.rpy:305
translate chinese maya_Idle_evening_mayaroom_scene_9622db09:

    # Maya "Иногда мне кажется, что этот дом дышит"
    Maya "有时我觉得这座房子正在呼吸"

# game/characters_events_idles/maya_idles.rpy:306
translate chinese maya_Idle_evening_mayaroom_scene_0a637ee0:

    # Maya "Когда все расходятся по комнатам, он будто вздыхает - типа “наконец-то”"
    Maya "当每个人都回到自己的房间时，他似乎叹了口气——就像“终于”"

# game/characters_events_idles/maya_idles.rpy:307
translate chinese maya_Idle_evening_mayaroom_scene_c4190f3c:

    # gg "Может, он просто устал от нас"
    gg "也许他只是厌倦了我们"

# game/characters_events_idles/maya_idles.rpy:309
translate chinese maya_Idle_evening_mayaroom_scene_9a1cfc06:

    # Maya "Или от тебя"
    Maya "或者来自你"

# game/characters_events_idles/maya_idles.rpy:310
translate chinese maya_Idle_evening_mayaroom_scene_9ca1630b:

    # Maya "Ты ж теперь главный источник событий"
    Maya "你现在是事件的主要来源"

# game/characters_events_idles/maya_idles.rpy:311
translate chinese maya_Idle_evening_mayaroom_scene_4618c7f3:

    # gg "Ну спасибо"
    gg "嗯，谢谢你"

# game/characters_events_idles/maya_idles.rpy:312
translate chinese maya_Idle_evening_mayaroom_scene_9314e70f:

    # gg "Хоть не шумовой загрязнитель"
    gg "至少不是噪音污染者"

# game/characters_events_idles/maya_idles.rpy:314
translate chinese maya_Idle_evening_mayaroom_scene_1c9556b7:

    # Maya "Не переживай, ты в двух шагах от этого звания"
    Maya "别担心，你距离这个称号只有两步之遥"

# game/characters_events_idles/maya_idles.rpy:317
translate chinese maya_Idle_evening_mayaroom_scene_3ece4663:

    # gg "Ладно, не мешаю твоему “отдыханию”"
    gg "好吧，我不会打扰你的“休息”"

# game/characters_events_idles/maya_idles.rpy:318
translate chinese maya_Idle_evening_mayaroom_scene_c8d80171:

    # Maya "Уже поздно. Ты в моём поле общения, это необратимо"
    Maya "已经很晚了。你在我的交往范围内是不可逆转的"

# game/characters_events_idles/maya_idles.rpy:319
translate chinese maya_Idle_evening_mayaroom_scene_52424bb1:

    # gg "Тогда я официально заражён"
    gg "然后我就正式被感染了"

# game/characters_events_idles/maya_idles.rpy:333
translate chinese maya_Idle_night_mayaroom_scene_f715f6b4:

    # gg "Спит без задних ног . . ."
    gg "睡觉时没有后腿。 。 。"

# game/characters_events_idles/maya_idles.rpy:334
translate chinese maya_Idle_night_mayaroom_scene_fd8d0a8c:

    # gg "Хоть будильник под ухом взрывай — не проснётся"
    gg "就算你炸掉耳边的闹钟，你也不会醒来"

# game/characters_events_idles/maya_idles.rpy:345
translate chinese maya_Idle_evening_myroom_scene_f6ddbad8:

    # gg "Засыпаешь?"
    gg "你睡着了吗？"

# game/characters_events_idles/maya_idles.rpy:347
translate chinese maya_Idle_evening_myroom_scene_60b26d3f:

    # Maya "Нет. Просто отдыхаю в позе ленивой медитации"
    Maya "不，只是以懒惰的冥想姿势放松"

# game/characters_events_idles/maya_idles.rpy:348
translate chinese maya_Idle_evening_myroom_scene_5197b7fb:

    # gg "Выглядит как битва с подушкой на выживание"
    gg "看起来像是一场生存枕头战"

# game/characters_events_idles/maya_idles.rpy:350
translate chinese maya_Idle_evening_myroom_scene_ef00b824:

    # Maya "Ха. Не завидуй"
    Maya "哈。别嫉妒"

# game/characters_events_idles/maya_idles.rpy:352
translate chinese maya_Idle_evening_myroom_scene_87bfdb57:

    # gg "Соня говорила что спала раньше на этом диване. Он удобный"
    gg "索尼娅说她以前睡过这张沙发。很舒服"

# game/characters_events_idles/maya_idles.rpy:353
translate chinese maya_Idle_evening_myroom_scene_b9e42dcf:

    # Maya "Ага. Она любила здесь засыпать под телевизор"
    Maya "是的。她喜欢在这里看电视入睡"

# game/characters_events_idles/maya_idles.rpy:354
translate chinese maya_Idle_evening_myroom_scene_01c1b004:

    # Maya "Говорила, что этот гул помогает думать"
    Maya "她说这种嗡嗡声可以帮助我思考"

# game/characters_events_idles/maya_idles.rpy:357
translate chinese maya_Idle_evening_myroom_scene_69ea4813:

    # Maya "А теперь вот ты"
    Maya "现在你在这里"

# game/characters_events_idles/maya_idles.rpy:358
translate chinese maya_Idle_evening_myroom_scene_1c914aec:

    # Maya "И диван как будто сменил хозяина"
    Maya "而且沙发好像换了主人"

# game/characters_events_idles/maya_idles.rpy:359
translate chinese maya_Idle_evening_myroom_scene_c99ae1d2:

    # gg "Ничего, я постараюсь не испортить его репутацию"
    gg "没关系，我会尽量不败坏他的名声的"

# game/characters_events_idles/maya_idles.rpy:360
translate chinese maya_Idle_evening_myroom_scene_4ed4ce95:

    # Maya "Да уж, будь добр"
    Maya "是的，请友善一点"

# game/characters_events_idles/maya_idles.rpy:361
translate chinese maya_Idle_evening_myroom_scene_a777aa23:

    # Maya "У него длинная история, он видел больше ссор и сериалов, чем мы оба вместе"
    Maya "他历史悠久，看过的打斗和电视剧比我们俩加起来还多"

# game/characters_events_idles/maya_idles.rpy:362
translate chinese maya_Idle_evening_myroom_scene_3f329134:

    # gg "Кстати, а вы вообще платите Линде за жильё? Или это всё “по знакомству”?"
    gg "顺便问一下，你付琳达的房租吗？还是都是“认识”？"

# game/characters_events_idles/maya_idles.rpy:364
translate chinese maya_Idle_evening_myroom_scene_ac2bb573:

    # Maya "Платим . . . {w}Ну как “платим” - скорее благодарим"
    Maya "我们付钱。 。 。 {w}那么，我们如何“付款” - 谢谢"

# game/characters_events_idles/maya_idles.rpy:365
translate chinese maya_Idle_evening_myroom_scene_b48308d4:

    # Maya "Сумма символическая, Линда больше из принципа берёт, чем из необходимости"
    Maya "这个数额只是象征性的，琳达拿的更多是出于原则，而不是出于必要。"

# game/characters_events_idles/maya_idles.rpy:366
translate chinese maya_Idle_evening_myroom_scene_361a0566:

    # Maya "Её это, кажется, успокаивает: типа дом не стоит пустой и приносит пользу"
    Maya "这似乎让她平静下来：就像房子不是空的而且很有用"

# game/characters_events_idles/maya_idles.rpy:367
translate chinese maya_Idle_evening_myroom_scene_e9782332:

    # gg "Узнаю свою бабушку"
    gg "我认得我奶奶"

# game/characters_events_idles/maya_idles.rpy:369
translate chinese maya_Idle_evening_myroom_scene_5822e6c1:

    # Maya "Ага. Только вот было бы ещё хорошо, если бы она хотя бы предупредила, что внучок вот-вот приедет"
    Maya "是的。但如果她至少警告一下她的孙子即将到来，那就太好了"

# game/characters_events_idles/maya_idles.rpy:370
translate chinese maya_Idle_evening_myroom_scene_3f1ab8b6:

    # Maya "Я чуть не упала тогда, когда ты появился в дверях"
    Maya "当你出现在门口时我差点摔倒"

# game/characters_events_idles/maya_idles.rpy:371
translate chinese maya_Idle_evening_myroom_scene_1bd89a55:

    # Maya "Уже чего только не думала"
    Maya "我还没有考虑过任何事情"

# game/characters_events_idles/maya_idles.rpy:372
translate chinese maya_Idle_evening_myroom_scene_5d3dcdb5:

    # gg "Извини, я тоже не ожидал, что в доме будут люди"
    gg "抱歉，我也没想到家里会有人"

# game/characters_events_idles/maya_idles.rpy:373
translate chinese maya_Idle_evening_myroom_scene_43ff1f8d:

    # Maya "Вот и замечательно"
    Maya "那太棒了"

# game/characters_events_idles/maya_idles.rpy:374
translate chinese maya_Idle_evening_myroom_scene_6c224d29:

    # Maya "Никто ничего не ожидал - поэтому всё как обычно"
    Maya "没有人期待任何事情 - 所以一切都如常"

# game/characters_events_idles/maya_idles.rpy:377
translate chinese maya_Idle_evening_myroom_scene_cbdc658c:

    # Maya "Знаешь, может, это и к лучшему"
    Maya "你知道，也许这是最好的"

# game/characters_events_idles/maya_idles.rpy:378
translate chinese maya_Idle_evening_myroom_scene_10ae6709:

    # gg "Я стараюсь как лучше"
    gg "我尽力"

# game/characters_events_idles/maya_idles.rpy:379
translate chinese maya_Idle_evening_myroom_scene_2738bbdd:

    # Maya "Ладно, ты уже часть декора"
    Maya "好吧，你已经是装饰的一部分了。"

# game/characters_events_idles/maya_idles.rpy:380
translate chinese maya_Idle_evening_myroom_scene_a3e55433:

    # Maya "Даже телевизор теперь включается по тебе"
    Maya "甚至电视现在也为你打开"

# game/characters_events_idles/maya_idles.rpy:381
translate chinese maya_Idle_evening_myroom_scene_51392b4e:

    # gg "В смысле?"
    gg "按照？"

# game/characters_events_idles/maya_idles.rpy:382
translate chinese maya_Idle_evening_myroom_scene_6214a218:

    # Maya "Стоит тебе появиться - сразу что-то происходит. Иногда полезное, иногда нет"
    Maya "你一出现，就会立即发生一些事情。有时有用有时没用"

# game/characters_events_idles/maya_idles.rpy:383
translate chinese maya_Idle_evening_myroom_scene_a17c73ec:

    # Maya "Но скучно с тобой не бывает"
    Maya "但和你在一起永远不会无聊"

# game/characters_events_idles/maya_idles.rpy:385
translate chinese maya_Idle_evening_myroom_scene_3edde83f:

    # Maya "Всё, вечер окончен"
    Maya "就这样，晚上结束了"

# game/characters_events_idles/maya_idles.rpy:386
translate chinese maya_Idle_evening_myroom_scene_2082f32a:

    # Maya "Телевизор устал смотреть на нас"
    Maya "电视看腻了我们"

# game/characters_events_idles/maya_idles.rpy:387
translate chinese maya_Idle_evening_myroom_scene_3c45ded0:

    # gg "Тогда спокойной ночи"
    gg "然后晚安"

# game/characters_events_idles/maya_idles.rpy:388
translate chinese maya_Idle_evening_myroom_scene_9adb5a5c:

    # Maya "Ага. И не растяни диван - он к тебе уже привязался"
    Maya "是的。不要伸展沙发——他已经依附在你身上了"

translate chinese strings:

    # game/characters_events_idles/maya_idles.rpy:5
    old "Барсик у тебя?"
    new "你有巴西克吗？"

    # game/characters_events_idles/maya_idles.rpy:43
    old "Позже зайду"
    new "我稍后过来"

    # game/characters_events_idles/maya_idles.rpy:52
    old "С книжкой с утра?"
    new "早上看书吗？"

    # game/characters_events_idles/maya_idles.rpy:102
    old "Не мешаю"
    new "我不干涉"

    # game/characters_events_idles/maya_idles.rpy:111
    old "Ко сну готовишься?"
    new "你准备好睡觉了吗？"

    # game/characters_events_idles/maya_idles.rpy:136
    old "Не буду мешать"
    new "我不会干涉"

    # game/characters_events_idles/maya_idles.rpy:145
    old "Новый рецепт?"
    new "新食谱？"

    # game/characters_events_idles/maya_idles.rpy:188
    old "Газировка кончилась?"
    new "苏打水用完了吗？"

    # game/characters_events_idles/maya_idles.rpy:231
    old "Пойду"
    new "我去"

    # game/characters_events_idles/maya_idles.rpy:240
    old "Не беспокоить"
    new "请勿打扰"

    # game/characters_events_idles/maya_idles.rpy:251
    old "Музыку миксуешь?"
    new "你会混合音乐吗？"

    # game/characters_events_idles/maya_idles.rpy:284
    old "Уйти"
    new "离开"

    # game/characters_events_idles/maya_idles.rpy:293
    old "Опять зависла?"
    new "又冻结了？"

    # game/characters_events_idles/maya_idles.rpy:343
    old "Засыпаешь?"
    new "你睡着了吗？"

