﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/mc_events.rpy:84
translate chinese gg_intro_57d9b303:

    # gg "Чёрт . . . конец месяца"
    gg "废话。 。 。月底"

# game/characters_events_idles/mc_events.rpy:86
translate chinese gg_intro_fc2b37ea:

    # gg "Скоро платить по долгам . . ."
    gg "很快就还清了债务。 。 。"

# game/characters_events_idles/mc_events.rpy:88
translate chinese gg_intro_a14d12e5:

    # gg "Ладно . . . хоть сегодня выходной"
    gg "好的 。 。 。至少今天休息一天"

# game/characters_events_idles/mc_events.rpy:89
translate chinese gg_intro_76bd858b:

    # gg "Хоть что-то"
    gg "至少有一些东西"

# game/characters_events_idles/mc_events.rpy:91
translate chinese gg_intro_808930b3:

    # gg "Может, хоть пару часов отдохну. . . {w}просто расслаблюсь"
    gg "也许我会休息至少几个小时。 。 。 {w}放松一下"

# game/characters_events_idles/mc_events.rpy:98
translate chinese gg_intro_df03d227:

    # gg "Ну хоть здесь кто-то есть . . ."
    gg "好吧，至少有人在这里。 。 。"

# game/characters_events_idles/mc_events.rpy:102
translate chinese gg_intro_9b1348ec:

    # gg "Найс, я их разнес"
    gg "太好了，我把它们打碎了"

# game/characters_events_idles/mc_events.rpy:104
translate chinese gg_intro_f004ad75:

    # gg "Ладно . . . бывает"
    gg "好的 。 。 。它发生了"

# game/characters_events_idles/mc_events.rpy:105
translate chinese gg_intro_3aef7ac5:

    # gg "Следующая будет норм"
    gg "下一篇一定会好起来的"

# game/characters_events_idles/mc_events.rpy:107
translate chinese gg_intro_f6ebf694:

    # gg "бляя . . ."
    gg "他妈的。 。 。"

# game/characters_events_idles/mc_events.rpy:111
translate chinese gg_intro_e7a753f9:

    # gg "вот суки"
    gg "给你，婊子们"

# game/characters_events_idles/mc_events.rpy:112
translate chinese gg_intro_3a97b002:

    # gg "Окей ладно супер последняя на победу"
    gg "好吧好吧超级最后一位获胜"

# game/characters_events_idles/mc_events.rpy:114
translate chinese gg_intro_94d70a59:

    # gg "{sc}{size=*1.5}СУКА!{/size}{/sc}" with vpunch
    gg "{sc}{size=*1.5}该死！{/size}{/sc}" with vpunch

# game/characters_events_idles/mc_events.rpy:118
translate chinese gg_intro_08de7acc:

    # gg "Да пошло оно всё . . ."
    gg "去他妈的这一切。 。 。"

# game/characters_events_idles/mc_events.rpy:119
translate chinese gg_intro_62b01796:

    # gg "Какая же трата времени"
    gg "多么浪费时间"

# game/characters_events_idles/mc_events.rpy:122
translate chinese gg_intro_55fbce1e:

    # gg "Выходной . . . единственный день . . ."
    gg "休息日。 。 。仅有一天。 。 。"

# game/characters_events_idles/mc_events.rpy:123
translate chinese gg_intro_f0abf492:

    # gg "И я просто убил его на эту грёбаную игру"
    gg "我只是为了这个该死的游戏杀了他"

# game/characters_events_idles/mc_events.rpy:125
translate chinese gg_intro_d924704e:

    # gg "Экран это единственное с чем я общаюсь последнее время"
    gg "屏幕是我最近唯一交流的东西"

# game/characters_events_idles/mc_events.rpy:131
translate chinese gg_intro_59ed329a:

    # gg "Я живу здесь . . . но эта квартира"
    gg "我住在这里。 。 。但这间公寓"

# game/characters_events_idles/mc_events.rpy:132
translate chinese gg_intro_0d6c2d2c:

    # gg "Просто точка между работой и снова работой"
    gg "只是工作和再次工作之间的一个点"

# game/characters_events_idles/mc_events.rpy:140
translate chinese gg_intro_7ce95d1c:

    # gg "Только там . . ."
    gg "只有那里。 。 。"

# game/characters_events_idles/mc_events.rpy:142
translate chinese gg_intro_fa2b02fe:

    # gg "Я чувствовал себя живым"
    gg "我感觉自己还活着"

# game/characters_events_idles/mc_events.rpy:144
translate chinese gg_intro_5a38b375:

    # gg "Я . . . устал так жить"
    gg "我 。 。 。厌倦了这样的生活"

# game/characters_events_idles/mc_events.rpy:164
translate chinese gg_intro_eb77ecfa:

    # gg "Да иду я, иду . . ."
    gg "是的，我来了，我来了。 。 。"

# game/characters_events_idles/mc_events.rpy:168
translate chinese gg_intro_565267c5:

    # gg "Кто там?"
    gg "谁在那里？"

# game/characters_events_idles/mc_events.rpy:173
translate chinese gg_intro_60b12a13:

    # gg "Ты кто?"
    gg "你是谁？"

# game/characters_events_idles/mc_events.rpy:175
translate chinese gg_intro_e00854e1:

    # PostMan "Я почтальон"
    PostMan "我是一名邮递员"

# game/characters_events_idles/mc_events.rpy:176
translate chinese gg_intro_0715dd94:

    # gg "Почтальоны теперь так одеваются?"
    gg "现在邮递员都这么穿了吗？"

# game/characters_events_idles/mc_events.rpy:178
translate chinese gg_intro_0d42e0ef:

    # PostMan "Вот смотри для тебя нарисовали"
    PostMan "看，他们为你画的"

# game/characters_events_idles/mc_events.rpy:180
translate chinese gg_intro_e75db202:

    # PostMan "А я одеваюсь как хочу"
    PostMan "我按照我想要的方式穿着"

# game/characters_events_idles/mc_events.rpy:181
translate chinese gg_intro_615e77bc:

    # gg "Так а посылка?"
    gg "那么包裹呢？"

# game/characters_events_idles/mc_events.rpy:183
translate chinese gg_intro_096cd512:

    # PostMan "А! сейчас"
    PostMan "一个！现在"

# game/characters_events_idles/mc_events.rpy:185
translate chinese gg_intro_0d3968a6:

    # PostMan "Вот, ты же [povname] правильно?"
    PostMan "在这里，你[povname]对吧？"

# game/characters_events_idles/mc_events.rpy:187
translate chinese gg_intro_df24437b:

    # gg "Да, спасибо"
    gg "是的，谢谢"

# game/characters_events_idles/mc_events.rpy:189
translate chinese gg_intro_d7f65fd8:

    # PostMan "Доставка уже оплачена, так что до свидания"
    PostMan "运费已经付了，再见"

# game/characters_events_idles/mc_events.rpy:196
translate chinese gg_intro_94ec24eb:

    # gg_chat "Эта квартира слишком дорого мне обходится"
    gg_chat "这间公寓花了我太多钱"

# game/characters_events_idles/mc_events.rpy:200
translate chinese gg_intro_083c370e:

    # gg_chat "Эти долги меня скоро сьедят"
    gg_chat "这些债务很快就会吞噬我"

# game/characters_events_idles/mc_events.rpy:203
translate chinese gg_intro_a7a8221e:

    # gg_chat "Что? {w}Линда?"
    gg_chat "什么？ {w}琳达？"

# game/characters_events_idles/mc_events.rpy:208
translate chinese gg_intro_98898eb6:

    # gg_chat "От бабушки . . ."
    gg_chat "来自奶奶。 。 。"

# game/characters_events_idles/mc_events.rpy:210
translate chinese gg_intro_3341868c:

    # gg_chat "Давно не видел её . . ."
    gg_chat "我已经很久没见到她了。 。 。"

# game/characters_events_idles/mc_events.rpy:211
translate chinese gg_intro_6f756f5d:

    # gg_chat "Зачем она мне это?"
    gg_chat "她为什么需要这个？"

# game/characters_events_idles/mc_events.rpy:212
translate chinese gg_intro_9f5ccf2a:

    # "Дорогой мой, [povname]"
    "亲爱的，[povname]"

# game/characters_events_idles/mc_events.rpy:213
translate chinese gg_intro_7d8221c5:

    # "Пишу тебе это письмо с особым волнением — не потому, что что-то случилось"
    "我怀着特别兴奋的心情给你写这封信——并不是因为发生了什么事"

# game/characters_events_idles/mc_events.rpy:214
translate chinese gg_intro_bb3819ba:

    # "А потому, что скоро мне предстоит небольшое, но долгое путешествие"
    "但因为很快我就有一段短暂而漫长的旅程"

# game/characters_events_idles/mc_events.rpy:215
translate chinese gg_intro_a901876a:

    # "С тех пор, как ты уехал, тут многое стало тише, спокойнее"
    "自从你走了之后，这里变得安静、平静了。"

# game/characters_events_idles/mc_events.rpy:216
translate chinese gg_intro_8aaddaf9:

    # "Но рядом всё ещё живут хорошие люди — кто-то поможет, если нужно, кто-то просто заглянет поболтать"
    "但附近仍然住着好人——如果需要的话，有人会提供帮助，有人会顺便过来聊天"

# game/characters_events_idles/mc_events.rpy:217
translate chinese gg_intro_8049e805:

    # "Дом, в котором ты вырос летом, скоро останется без хозяйки . . ."
    "你夏天长大的房子很快就会失去情妇。 。 。"

# game/characters_events_idles/mc_events.rpy:218
translate chinese gg_intro_7713047b:

    # "И мне очень бы не хотелось, чтобы он начал ветшать"
    "我真的不希望它开始恶化。"

# game/characters_events_idles/mc_events.rpy:220
translate chinese gg_intro_ce9ad3bf:

    # "Я уезжаю на несколько лет — не волнуйся, здоровье моё в порядке, просто пришло время пожить немного иначе"
    "我要离开几年 - 别担心，我的健康状况很好，只是该过一种不同的生活了"

# game/characters_events_idles/mc_events.rpy:221
translate chinese gg_intro_56cba277:

    # "Пока меня не будет, хочу тебя попросить заглядывать в дом"
    "我走的时候，我想请你看看房子"

# game/characters_events_idles/mc_events.rpy:222
translate chinese gg_intro_9768b114:

    # "Пусть не пустеет, пусть скрипят половицы, пусть греется чайник"
    "别让它空着，让地板吱吱作响，让水壶暖和起来"

# game/characters_events_idles/mc_events.rpy:223
translate chinese gg_intro_040e7339:

    # "Он живой, наш дом — если забросить, начнёт хандрить"
    "他还活着，我们的房子——如果被遗弃，他会开始闷闷不乐"

# game/characters_events_idles/mc_events.rpy:224
translate chinese gg_intro_581165e6:

    # gg "Она всегда так говорила . . . {w}будто дом — живой"
    gg "她总是这么说。 。 。 {w}就像房子还活着一样"

# game/characters_events_idles/mc_events.rpy:226
translate chinese gg_intro_82ffc349:

    # "И ещё . . . цветы"
    "还有一件事。 。 。花朵"

# game/characters_events_idles/mc_events.rpy:227
translate chinese gg_intro_3c7f2026:

    # "Мои две любимые. Они остались"
    "我最喜欢的两个。他们留下来"

# game/characters_events_idles/mc_events.rpy:228
translate chinese gg_intro_a2adc801:

    # "Одна крепкая, корнями в землю, упрямая, немного колючая, зато как зацветёт — всем на удивление"
    "一个是坚强的，根扎在地里，固执的，有点带刺，但是当它绽放的时候，让所有人都惊讶不已"

# game/characters_events_idles/mc_events.rpy:229
translate chinese gg_intro_d1748522:

    # "Вторая — лёгкая, солнечная, смеётся даже в дождь, растёт, куда глянет, и всё ей в радость"
    "第二个是轻盈的，阳光明媚的，即使在雨中也会笑，它看到哪里就生长，一切都让她开心"

# game/characters_events_idles/mc_events.rpy:231
translate chinese gg_intro_5cd83b3b:

    # gg_chat "Причем здесь цветы вообще . . ."
    gg_chat "这是一般的花。 。 。"

# game/characters_events_idles/mc_events.rpy:232
translate chinese gg_intro_d87a1c8d:

    # "Уход у них разный, но суть одна — внимание"
    "他们的关怀不同，但本质是一样的——关注"

# game/characters_events_idles/mc_events.rpy:233
translate chinese gg_intro_0733c9df:

    # "Ты справишься — у тебя ведь моё упрямство и моё сердце"
    "你可以应付的——你有我的固执和我的心"

# game/characters_events_idles/mc_events.rpy:234
translate chinese gg_intro_3406a366:

    # "Очень хочу, чтобы ты оказался там пораньше — дом ждёт тебя"
    "我真的希望你早点到那里——房子在等你"

# game/characters_events_idles/mc_events.rpy:235
translate chinese gg_intro_bfcc2649:

    # "С любовью"
    "有爱"

# game/characters_events_idles/mc_events.rpy:236
translate chinese gg_intro_3f6a1326:

    # "Твоя бабушка Линда"
    "你的祖母琳达"

# game/characters_events_idles/mc_events.rpy:238
translate chinese gg_intro_22bce088:

    # gg_chat "Бабушка была всегда рядом, её дом был моим домом"
    gg_chat "奶奶一直都在，她的家就是我的家"

# game/characters_events_idles/mc_events.rpy:240
translate chinese gg_intro_4164e503:

    # gg_chat "Зачем она меня просит присматривать за домом?"
    gg_chat "她为什么要我看家？"

# game/characters_events_idles/mc_events.rpy:242
translate chinese gg_intro_ad05e118:

    # gg_chat "Просто взять и уехать?"
    gg_chat "直接拿起就走吗？"

# game/characters_events_idles/mc_events.rpy:244
translate chinese gg_intro_0ae1f5e0:

    # gg_chat "Будто у меня тут ничего нет"
    gg_chat "好像我这里什么都没有"

# game/characters_events_idles/mc_events.rpy:246
translate chinese gg_intro_e3e17f69:

    # gg_chat "У меня своих проблем по горло"
    gg_chat "我自己的问题已经够多了"

# game/characters_events_idles/mc_events.rpy:248
translate chinese gg_intro_4810f11e:

    # gg_chat "Чёрт я опаздываю"
    gg_chat "妈的我迟到了"

# game/characters_events_idles/mc_events.rpy:250
translate chinese gg_intro_3aa5e105:

    # gg_chat "Потом поем"
    gg_chat "然后我们就吃饭"

# game/characters_events_idles/mc_events.rpy:254
translate chinese gg_intro_4a0266b9:

    # gg_chat "Я отвечу бабушка попозже"
    gg_chat "稍后我会回复奶奶"

# game/characters_events_idles/mc_events.rpy:261
translate chinese gg_intro_9cdabec6:

    # gg_chat "Серьёзно? . . ."
    gg_chat "严重地？ 。 。 。"

# game/characters_events_idles/mc_events.rpy:265
translate chinese gg_intro_7331a474:

    # gg_chat "Блять . . ."
    gg_chat "他妈的。 。 。"

# game/characters_events_idles/mc_events.rpy:266
translate chinese gg_intro_db310e96:

    # gg_chat "Как всегда"
    gg_chat "一如既往"

# game/characters_events_idles/mc_events.rpy:270
translate chinese gg_intro_4b9afd3e:

    # gg "Я пришел"
    gg "我在这里"

# game/characters_events_idles/mc_events.rpy:272
translate chinese gg_intro_80d3fcff:

    # Assistant "Опоздал. Как всегда"
    Assistant "我来晚了。一如既往"

# game/characters_events_idles/mc_events.rpy:274
translate chinese gg_intro_d3b968fb:

    # Assistant "И напомню: если продолжишь {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "让我提醒您：如果您继续{w}谈论减薪就已经是时间问题了"

# game/characters_events_idles/mc_events.rpy:276
translate chinese gg_intro_0bd28ad3:

    # gg_chat "Да, конечно"
    gg_chat "是的，当然"

# game/characters_events_idles/mc_events.rpy:285
translate chinese gg_intro_603b869e:

    # Director "Это срочно"
    Director "事情紧急"

# game/characters_events_idles/mc_events.rpy:287
translate chinese gg_intro_eac333f5:

    # Director "За Петрова сделаешь"
    Director "你会为彼得罗夫做这件事"

# game/characters_events_idles/mc_events.rpy:289
translate chinese gg_intro_2ccd9b60:

    # gg "Это не мои задачи"
    gg "这些不是我的任务"

# game/characters_events_idles/mc_events.rpy:290
translate chinese gg_intro_df8035b4:

    # gg "Почему я должен работать за другого"
    gg "我为什么要为别人工作？"

# game/characters_events_idles/mc_events.rpy:292
translate chinese gg_intro_e2eb6337:

    # Director "Мне плевать"
    Director "我不在乎"

# game/characters_events_idles/mc_events.rpy:294
translate chinese gg_intro_66f2f5ce:

    # Director "Сделаешь всё до конца недели"
    Director "你将在本周末完成所有事情"

# game/characters_events_idles/mc_events.rpy:297
translate chinese gg_intro_b7d7b4b2:

    # Director "Не успеешь — сам знаешь последствия"
    Director "如果你没有时间，你知道后果"

# game/characters_events_idles/mc_events.rpy:303
translate chinese gg_intro_3d5010f4:

    # gg_chat "Им всегда плевать"
    gg_chat "他们总是不在乎"

# game/characters_events_idles/mc_events.rpy:304
translate chinese gg_intro_1670588b:

    # gg_chat "Я здесь просто расходник"
    gg_chat "我在这里只是一个消耗品"

# game/characters_events_idles/mc_events.rpy:308
translate chinese gg_intro_3c056c18:

    # gg_chat "Сколько ни делай — конца нет"
    gg_chat "无论你做了多少，都没有尽头"

# game/characters_events_idles/mc_events.rpy:321
translate chinese gg_intro_577e1c14:

    # Director "Секретарша сказала"
    Director "秘书说"

# game/characters_events_idles/mc_events.rpy:324
translate chinese gg_intro_e2282b24:

    # Director "Что ты опоздал"
    Director "你为什么迟到"

# game/characters_events_idles/mc_events.rpy:326
translate chinese gg_intro_009afbde:

    # Director "Если не сдашь это в срок"
    Director "如果你没有按时上交"

# game/characters_events_idles/mc_events.rpy:327
translate chinese gg_intro_e8f982f1:

    # Director "Можешь искать новую работу"
    Director "你可以找一份新工作"

# game/characters_events_idles/mc_events.rpy:329
translate chinese gg_intro_5d67e1da:

    # Director "Понял?"
    Director "明白了吗？"

# game/characters_events_idles/mc_events.rpy:330
translate chinese gg_intro_ef555dd8:

    # gg_chat "Вот сука"
    gg_chat "那是个母狗"

# game/characters_events_idles/mc_events.rpy:332
translate chinese gg_intro_e967e307:

    # gg "Да"
    gg "是的"

# game/characters_events_idles/mc_events.rpy:340
translate chinese gg_intro_aba5df1c:

    # gg_chat "Им всё равно — значит, и мне тоже"
    gg_chat "他们不在乎，这意味着我也不在乎"

# game/characters_events_idles/mc_events.rpy:342
translate chinese gg_intro_59df236a:

    # gg_chat "С меня довольно"
    gg_chat "我已经受够了"

# game/characters_events_idles/mc_events.rpy:344
translate chinese gg_intro_c0a84961:

    # gg_chat "Не поспешил ли я?"
    gg_chat "我是不是太急了？"

# game/characters_events_idles/mc_events.rpy:346
translate chinese gg_intro_a632776e:

    # gg_chat "Хватит"
    gg_chat "足够的"

# game/characters_events_idles/mc_events.rpy:355
translate chinese gg_intro_14d66a18:

    # Director "Ты вообще, что делаешь"
    Director "你到底在做什么？"

# game/characters_events_idles/mc_events.rpy:357
translate chinese gg_intro_dfc9c282:

    # gg "Я увольняюсь"
    gg "我要戒了"

# game/characters_events_idles/mc_events.rpy:359
translate chinese gg_intro_8543ef20:

    # Director "Как ты смеешь??"
    Director "你怎么敢？？"

# game/characters_events_idles/mc_events.rpy:371
translate chinese gg_intro_1a1334a8:

    # Assistant "Ой"
    Assistant "哦"

# game/characters_events_idles/mc_events.rpy:373
translate chinese gg_intro_11803396:

    # Assistant "Ты что делаешь!?"
    Assistant "你在干什么！？"

# game/characters_events_idles/mc_events.rpy:374
translate chinese gg_intro_b31c2e41:

    # gg "Счастливо оставаться"
    gg "住得愉快"

# game/characters_events_idles/mc_events.rpy:376
translate chinese gg_intro_96fd98eb:

    # gg_chat "Наконец-то"
    gg_chat "最后"

# game/characters_events_idles/mc_events.rpy:378
translate chinese gg_intro_e446a106:

    # gg_chat "Моя привычная жизнь закончилась"
    gg_chat "我的正常生活结束了"

# game/characters_events_idles/mc_events.rpy:382
translate chinese gg_intro_724c298c:

    # gg_chat "На улице столько парочек гуляет"
    gg_chat "街上有很多情侣在散步"

# game/characters_events_idles/mc_events.rpy:383
translate chinese gg_intro_acc56f85:

    # gg_chat "Жизнь будто проходит мимо"
    gg_chat "生命似乎与你擦肩而过"

# game/characters_events_idles/mc_events.rpy:397
translate chinese gg_intro_a57d47f4:

    # gg_chat "Я даже не заметил"
    gg_chat "我什至没有注意到"

# game/characters_events_idles/mc_events.rpy:399
translate chinese gg_intro_1ba141ba:

    # gg_chat "Только у моего родного дома был такой ключ"
    gg_chat "只有我家有这样的钥匙。"

# game/characters_events_idles/mc_events.rpy:401
translate chinese gg_intro_cfb8599b:

    # gg_chat "Это шанс"
    gg_chat "这是一个机会"

# game/characters_events_idles/mc_events.rpy:402
translate chinese gg_intro_3ce8ccb4:

    # gg_chat "На новую жизнь"
    gg_chat "为了新的生活"

# game/characters_events_idles/mc_events.rpy:404
translate chinese gg_intro_4db85a28:

    # gg_chat "Это все мне больше не нужно"
    gg_chat "我不再需要这一切了"

# game/characters_events_idles/mc_events.rpy:414
translate chinese gg_intro_c3f38f42:

    # gg_chat "Пора начать сначала"
    gg_chat "是时候重新开始了"

# game/characters_events_idles/mc_events.rpy:422
translate chinese gg_intro_07728fd6:

    # gg_chat "После города — будто другой мир"
    gg_chat "离开城市就像另一个世界"

# game/characters_events_idles/mc_events.rpy:424
translate chinese gg_intro_fe890fb1:

    # gg_chat "Даже к этому я отвык . . ."
    gg_chat "我什至对此感到不习惯。 。 。"

# game/characters_events_idles/mc_events.rpy:428
translate chinese gg_intro_cac1bf85:

    # gg_chat "Мне здесь придётся многому научиться"
    gg_chat "我在这里有很多东西要学"

# game/characters_events_idles/mc_events.rpy:431
translate chinese gg_intro_a05332c8:

    # gg_chat "Я даже позабыл где дом . . ."
    gg_chat "我什至忘记了家在哪里。 。 。"

# game/characters_events_idles/mc_events.rpy:433
translate chinese gg_intro_a4a7b296:

    # gg_chat "Все кого я вижу со мной здороваются"
    gg_chat "我看到的每个人都跟我打招呼"

# game/characters_events_idles/mc_events.rpy:434
translate chinese gg_intro_720fce13:

    # gg_chat "Будто я тут не чужой"
    gg_chat "好像我在这里并不陌生"

# game/characters_events_idles/mc_events.rpy:435
translate chinese gg_intro_094d1de6:

    # UnknownGirl "Эй парень, постой-ка!"
    UnknownGirl "嘿家伙，等一下！"

# game/characters_events_idles/mc_events.rpy:437
translate chinese gg_intro_050bbcbc:

    # gg "Здравствуйте"
    gg "你好"

# game/characters_events_idles/mc_events.rpy:439
translate chinese gg_intro_0e31fcad:

    # UnknownGirl "Давно тут новых лиц не видели"
    UnknownGirl "我们已经很久没有在这里看到新面孔了"

# game/characters_events_idles/mc_events.rpy:441
translate chinese gg_intro_0ea7d489:

    # gg "Да только приехал"
    gg "是的，我刚到"

# game/characters_events_idles/mc_events.rpy:443
translate chinese gg_intro_a55c0f0a:

    # UnknownGirl "У нас тут новым людям всегда рады"
    UnknownGirl "这里永远欢迎新人"

# game/characters_events_idles/mc_events.rpy:445
translate chinese gg_intro_096f2b23:

    # UnknownGirl "Только вот"
    UnknownGirl "只有现在"

# game/characters_events_idles/mc_events.rpy:446
translate chinese gg_intro_83909d33:

    # UnknownGirl "Настоящих мужчин не хватает"
    UnknownGirl "真正的男人还不够多"

# game/characters_events_idles/mc_events.rpy:448
translate chinese gg_intro_8ffcdc07:

    # gg_chat "Что она вообще имеет в виду?"
    gg_chat "她究竟是什么意思？"

# game/characters_events_idles/mc_events.rpy:450
translate chinese gg_intro_f312c19f:

    # UnknownGirl "Ладно, не пугайся. Шучу"
    UnknownGirl "好吧，别害怕。开玩笑"

# game/characters_events_idles/mc_events.rpy:452
translate chinese gg_intro_af75b79f:

    # UnknownGirl "Если что то нужно будет спрашивай помощь у любого"
    UnknownGirl "如果您需要任何帮助，请向任何人寻求帮助。"

# game/characters_events_idles/mc_events.rpy:454
translate chinese gg_intro_f35a0bb9:

    # UnknownGirl "Удачи тебе"
    UnknownGirl "祝你好运"

# game/characters_events_idles/mc_events.rpy:456
translate chinese gg_intro_6a134ac2:

    # gg "Хорошо и вам отличного дня"
    gg "好吧，也祝你有美好的一天"

# game/characters_events_idles/mc_events.rpy:458
translate chinese gg_intro_b0f731c4:

    # gg_chat "Какая необычно добрая девушка"
    gg_chat "真是一个异常善良的女孩"

# game/characters_events_idles/mc_events.rpy:459
translate chinese gg_intro_b08ae0cc:

    # gg_chat "Бабушка похоже говорила правду о людях здесь"
    gg_chat "奶奶说的似乎是这里的人的真实情况"

# game/characters_events_idles/mc_events.rpy:463
translate chinese gg_intro_b07cdeca:

    # gg_chat "А если там уже не так, как я помню?"
    gg_chat "如果它不再像我记忆中的那样怎么办？"

# game/characters_events_idles/mc_events.rpy:465
translate chinese gg_intro_2c26269d:

    # gg_chat "Но назад пути нет"
    gg_chat "但没有回头路"

# game/characters_events_idles/mc_events.rpy:474
translate chinese gg_intro_9b8edceb:

    # gg_chat "Да дом поменялся"
    gg_chat "是的，房子变了"

# game/characters_events_idles/mc_events.rpy:482
translate chinese gg_intro_766d518e:

    # gg_chat "Кто-то есть?"
    gg_chat "有人吗?"

# game/characters_events_idles/mc_events.rpy:492
translate chinese gg_intro_b989363c:

    # gg ". . ."
    gg "。 。 。"

# game/characters_events_idles/mc_events.rpy:498
translate chinese gg_intro_7ad2e1b7:

    # Sonya "АААА!"
    Sonya "啊啊啊！"

# game/characters_events_idles/mc_events.rpy:500
translate chinese gg_intro_684edc0b:

    # Sonya "МАЯ!"
    Sonya "可能！"

# game/characters_events_idles/mc_events.rpy:502
translate chinese gg_intro_1124aafa:

    # Sonya "МАЯ, ТУТ КТО-ТО ЕСТЬ!!"
    Sonya "五月，有人在这里！！"

# game/characters_events_idles/mc_events.rpy:506
translate chinese gg_intro_cba5cc13:

    # gg_chat "Что это сейчас было? . . ."
    gg_chat "那是什么？ 。 。 。"

# game/characters_events_idles/mc_events.rpy:508
translate chinese gg_intro_74014e3a:

    # gg_chat "Я . . ."
    gg_chat "我 。 。 。"

# game/characters_events_idles/mc_events.rpy:510
translate chinese gg_intro_8b3408ac:

    # gg_chat "Я ничего не понял"
    gg_chat "我什么都没明白"

# game/characters_events_idles/mc_events.rpy:515
translate chinese gg_intro_18e79df2:

    # Maya "Ты кто такой?"
    Maya "你是谁？"

# game/characters_events_idles/mc_events.rpy:517
translate chinese gg_intro_35cf3bf6:

    # Maya "Убирайся отсюда. Сейчас же"
    Maya "离开这里。现在"

# game/characters_events_idles/mc_events.rpy:519
translate chinese gg_intro_be5ef2a9:

    # gg "Стой подожди"
    gg "等等等等"

# game/characters_events_idles/mc_events.rpy:521
translate chinese gg_intro_8750b79b:

    # gg "Я внук хозяйки дома"
    gg "我是女主人的孙子"

# game/characters_events_idles/mc_events.rpy:523
translate chinese gg_intro_eba62b3e:

    # gg "Это дом моей бабушки"
    gg "这是我祖母的房子"

# game/characters_events_idles/mc_events.rpy:525
translate chinese gg_intro_d179509d:

    # Maya "Внук?"
    Maya "孙子？"

# game/characters_events_idles/mc_events.rpy:527
translate chinese gg_intro_cb51aa26:

    # Maya "Что то я такого внука никогда здесь не видела"
    Maya "我在这里从未见过这样的孙子"

# game/characters_events_idles/mc_events.rpy:529
translate chinese gg_intro_fde7546c:

    # Maya "Думаешь я совсем тупая"
    Maya "你觉得我完全傻吗"

# game/characters_events_idles/mc_events.rpy:531
translate chinese gg_intro_a41fbef3:

    # gg "Подожди"
    gg "等待"

# game/characters_events_idles/mc_events.rpy:533
translate chinese gg_intro_0df5d29f:

    # gg "Я не знал, что здесь кто-то живёт"
    gg "我不知道有人住在这里"

# game/characters_events_idles/mc_events.rpy:535
translate chinese gg_intro_4b24971a:

    # Maya "Конечно не знал"
    Maya "我当然不知道"

# game/characters_events_idles/mc_events.rpy:537
translate chinese gg_intro_4af9c6fc:

    # Maya "А в чужие дома ты тоже «случайно» заходишь?"
    Maya "你是否也“不小心”进过别人家？"

# game/characters_events_idles/mc_events.rpy:543
translate chinese gg_intro_2a307bc4:

    # gg "Вот"
    gg "这里"

# game/characters_events_idles/mc_events.rpy:545
translate chinese gg_intro_c9e9dab5:

    # gg "Это письмо от моей бабушки"
    gg "这封信是我祖母写的"

# game/characters_events_idles/mc_events.rpy:547
translate chinese gg_intro_4a769d1b:

    # gg "Она попросила меня присмотреть за домом"
    gg "她让我照顾房子"

# game/characters_events_idles/mc_events.rpy:549
translate chinese gg_intro_ee0d1154:

    # Maya "И ты думаешь, я просто поверю этой бумажке?"
    Maya "你认为我会相信这张纸吗？"

# game/characters_events_idles/mc_events.rpy:551
translate chinese gg_intro_6d39543d:

    # gg "Я никуда не спешу"
    gg "我不着急"

# game/characters_events_idles/mc_events.rpy:563
translate chinese gg_intro_8ea26f73:

    # Maya "Дорогой"
    Maya "昂贵的"

# game/characters_events_idles/mc_events.rpy:565
translate chinese gg_intro_9a149321:

    # Maya "[povname]"
    Maya "[povname]"

# game/characters_events_idles/mc_events.rpy:569
translate chinese gg_intro_6e311c65:

    # Maya "Скоро останется без хозяйки"
    Maya "很快他就会失去情妇"

# game/characters_events_idles/mc_events.rpy:571
translate chinese gg_intro_2d481ec2:

    # Maya "Уезжаю на несколько лет"
    Maya "我要离开几年"

# game/characters_events_idles/mc_events.rpy:573
translate chinese gg_intro_cada9fb7:

    # Maya "Мои цветы две любимые. Они остались"
    Maya "我最喜欢的两朵花。他们留下来"

# game/characters_events_idles/mc_events.rpy:575
translate chinese gg_intro_4e84a3f6:

    # Maya "Дом ждёт тебя"
    Maya "家在等你"

# game/characters_events_idles/mc_events.rpy:577
translate chinese gg_intro_a2cdc4ac:

    # Maya "Твоя бабушка Линда"
    Maya "你的祖母琳达"

# game/characters_events_idles/mc_events.rpy:582
translate chinese gg_intro_dfc10494:

    # Maya "Боже ладно"
    Maya "天哪好吧"

# game/characters_events_idles/mc_events.rpy:583
translate chinese gg_intro_c4340902:

    # Maya "Похоже, на правду"
    Maya "看来是真的"

# game/characters_events_idles/mc_events.rpy:585
translate chinese gg_intro_329e21f7:

    # Maya "Но это ничего не меняет"
    Maya "但这并不能改变什么"

# game/characters_events_idles/mc_events.rpy:587
translate chinese gg_intro_dd6c3bfe:

    # Maya "Ты здесь чужой"
    Maya "你是这里的陌生人"

# game/characters_events_idles/mc_events.rpy:589
translate chinese gg_intro_69801038:

    # gg "Вообще-то это мой дом"
    gg "其实这是我的家"

# game/characters_events_idles/mc_events.rpy:591
translate chinese gg_intro_9a295059:

    # Maya "Это ты мы с Соней решим!"
    Maya "你和索尼娅将决定这一切！"

# game/characters_events_idles/mc_events.rpy:593
translate chinese gg_intro_9839e4df:

    # Maya "{sc}СОНЯ{/sc}" with hpunch
    Maya "{sc}索尼娅{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:595
translate chinese gg_intro_2551f6f7:

    # Maya "Всё нормально, он не опасный"
    Maya "没关系，他没有危险"

# game/characters_events_idles/mc_events.rpy:597
translate chinese gg_intro_d6a7eefb:

    # gg "Я так и сказал"
    gg "这就是我说的"

# game/characters_events_idles/mc_events.rpy:599
translate chinese gg_intro_f3cf760b:

    # Maya "Слушай если ты хоть что-то сделаешь"
    Maya "如果你做任何事，请听听"

# game/characters_events_idles/mc_events.rpy:601
translate chinese gg_intro_d58555f3:

    # Maya "Я тебя мигом выгоню. Понял?"
    Maya "我会立即把你踢出去。明白了吗？"

# game/characters_events_idles/mc_events.rpy:603
translate chinese gg_intro_d96e5a49:

    # gg "Понял"
    gg "明白了"

# game/characters_events_idles/mc_events.rpy:605
translate chinese gg_intro_a59664de:

    # Maya "Жди на кухне я передам письмо соне"
    Maya "在厨房等一下，我会把信交给索尼娅"

# game/characters_events_idles/mc_events.rpy:612
translate chinese gg_intro_0ac91294:

    # gg_chat "Вот это встреча"
    gg_chat "这是会议"

# game/characters_events_idles/mc_events.rpy:616
translate chinese gg_intro_baac99bc:

    # gg_chat "Я не ожидал такого"
    gg_chat "我没想到这个"

# game/characters_events_idles/mc_events.rpy:618
translate chinese gg_intro_feaa3808:

    # gg_chat "Почему бабушка ничего не сказала?"
    gg_chat "奶奶怎么不说话？"

# game/characters_events_idles/mc_events.rpy:627
translate chinese gg_intro_a070649e:

    # Sonya "Эм . . . привет"
    Sonya "嗯。 。 。你好"

# game/characters_events_idles/mc_events.rpy:629
translate chinese gg_intro_6a2024b3:

    # Sonya "Я . . . я Соня"
    Sonya "我 。 。 。我是索尼娅"

# game/characters_events_idles/mc_events.rpy:631
translate chinese gg_intro_12083d44:

    # Sonya "Я надеюсь ты не обиделся на Маю"
    Sonya "我希望你没有被玛雅冒犯"

# game/characters_events_idles/mc_events.rpy:633
translate chinese gg_intro_dfe04d57:

    # gg "Нет. Всё нормально"
    gg "不，一切都很好"

# game/characters_events_idles/mc_events.rpy:635
translate chinese gg_intro_85f8708a:

    # gg "Я [povname]"
    gg "我[povname]"

# game/characters_events_idles/mc_events.rpy:637
translate chinese gg_intro_78b27818:

    # Sonya "Мая сказала, что ты внук Линды"
    Sonya "玛雅说你是琳达的孙子"

# game/characters_events_idles/mc_events.rpy:638
translate chinese gg_intro_b5f632a7:

    # Sonya "Так . . . неожиданно получилось"
    Sonya "所以 。 。 。出乎意料地发生了"

# game/characters_events_idles/mc_events.rpy:643
translate chinese gg_intro_053ce261:

    # Sonya "И если честно"
    Sonya "老实说"

# game/characters_events_idles/mc_events.rpy:645
translate chinese gg_intro_4bf5a43d:

    # Sonya "Я сначала очень испугалась"
    Sonya "一开始我很害怕"

# game/characters_events_idles/mc_events.rpy:649
translate chinese gg_intro_87cb5bde:

    # gg "Извини"
    gg "对不起"

# game/characters_events_idles/mc_events.rpy:651
translate chinese gg_intro_1dc14df3:

    # gg "Я правда не хотел тебя пугать, стоило постучать"
    gg "我真的不是故意吓唬你的，我应该敲门的"

# game/characters_events_idles/mc_events.rpy:655
translate chinese gg_intro_2d8b9c21:

    # Sonya "Нет-нет всё нормально"
    Sonya "不不不，一切都好"

# game/characters_events_idles/mc_events.rpy:657
translate chinese gg_intro_9587b334:

    # Sonya "Просто не ожидали гостей"
    Sonya "他们只是没想到会有客人"

# game/characters_events_idles/mc_events.rpy:661
translate chinese gg_intro_9a863e77:

    # Sonya "Я прочла письмо линды"
    Sonya "我读了琳达的信"

# game/characters_events_idles/mc_events.rpy:663
translate chinese gg_intro_c7d51db6:

    # Sonya "Там про цветы было"
    Sonya "这是关于花的"

# game/characters_events_idles/mc_events.rpy:665
translate chinese gg_intro_c9e9d0a0:

    # Sonya "Это она так нас описывает"
    Sonya "她是这样描述我们的"

# game/characters_events_idles/mc_events.rpy:669
translate chinese gg_intro_7b39b9b5:

    # Sonya "Мы с Маей живём здесь вместе"
    Sonya "玛雅和我一起住在这里"

# game/characters_events_idles/mc_events.rpy:671
translate chinese gg_intro_c3003883:

    # Sonya "Линда сначала просто сдавала нам комнаты"
    Sonya "起初琳达只是把房间租给我们"

# game/characters_events_idles/mc_events.rpy:673
translate chinese gg_intro_eb14c7b5:

    # Sonya "А потом, когда уехала, сказала, что дом остаётся на нас"
    Sonya "然后，当她离开时，她说房子仍然归我们所有"

# game/characters_events_idles/mc_events.rpy:675
translate chinese gg_intro_6dcfd261:

    # gg "То есть вы тут уже давно?"
    gg "那么你已经在这里呆了很长时间了？"

# game/characters_events_idles/mc_events.rpy:677
translate chinese gg_intro_c8772e87:

    # Sonya "Да"
    Sonya "是的"

# game/characters_events_idles/mc_events.rpy:679
translate chinese gg_intro_5e85de7c:

    # Sonya "Мы привыкли. Даже кота завели"
    Sonya "我们已经习惯了。他们甚至养了一只猫"

# game/characters_events_idles/mc_events.rpy:681
translate chinese gg_intro_0879bf60:

    # Sonya "Для нас это уже дом"
    Sonya "这已经是我们的家了"

# game/characters_events_idles/mc_events.rpy:683
translate chinese gg_intro_dad9ef91:

    # Sonya "Линда иногда о тебе говорила"
    Sonya "琳达有时会谈论你"

# game/characters_events_idles/mc_events.rpy:685
translate chinese gg_intro_a3493fdc:

    # Sonya "Говорила, что ты хороший, по крайнее мерее в дестве"
    Sonya "她说你很好，至少小时候"

# game/characters_events_idles/mc_events.rpy:687
translate chinese gg_intro_0782f2e3:

    # gg "Надеюсь, она не слишком приукрашивала"
    gg "希望她不要修饰太多"

# game/characters_events_idles/mc_events.rpy:689
translate chinese gg_intro_3e3d596e:

    # gg "Сейчас я сам не знаю, кем стал"
    gg "现在我不知道我变成了谁"

# game/characters_events_idles/mc_events.rpy:691
translate chinese gg_intro_b8032679:

    # Sonya "А ты . . ."
    Sonya "你呢 。 。 。"

# game/characters_events_idles/mc_events.rpy:693
translate chinese gg_intro_7ad63786:

    # Sonya "Ты надолго?"
    Sonya "你会待多久？"

# game/characters_events_idles/mc_events.rpy:695
translate chinese gg_intro_c2f6d189:

    # Sonya "Ну какой у тебя дальше план?"
    Sonya "那么你的下一步计划是什么？"

# game/characters_events_idles/mc_events.rpy:697
translate chinese gg_intro_9f30eca5:

    # gg "Я пока не знаю"
    gg "我还不知道"

# game/characters_events_idles/mc_events.rpy:699
translate chinese gg_intro_51f05bc9:

    # gg "Мне нужно время"
    gg "我需要时间"

# game/characters_events_idles/mc_events.rpy:701
translate chinese gg_intro_301f9bbb:

    # gg_chat "Хотя здесь приятно"
    gg_chat "不过这里很好"

# game/characters_events_idles/mc_events.rpy:704
translate chinese gg_intro_a1c2b87a:

    # gg_chat "И как-то спокойно"
    gg_chat "又有些平静"

# game/characters_events_idles/mc_events.rpy:706
translate chinese gg_intro_1043df55:

    # Sonya "Уже поздно"
    Sonya "已经很晚了"

# game/characters_events_idles/mc_events.rpy:708
translate chinese gg_intro_f1483558:

    # Sonya "Мы можем поговорить ещё потом"
    Sonya "我们可以稍后再谈"

# game/characters_events_idles/mc_events.rpy:710
translate chinese gg_intro_701fa6da:

    # Sonya "Ты можешь лечь в зале"
    Sonya "你可以躺在大厅里"

# game/characters_events_idles/mc_events.rpy:712
translate chinese gg_intro_7adf858b:

    # Sonya "Других мест спальных у нас нету"
    Sonya "我们没有其他睡觉的地方"

# game/characters_events_idles/mc_events.rpy:714
translate chinese gg_intro_e6ef238c:

    # gg "Да хорошо"
    gg "是的，好的"

# game/characters_events_idles/mc_events.rpy:716
translate chinese gg_intro_18a3c2d6:

    # gg "Спасибо за теплый прием"
    gg "谢谢你们的热情欢迎"

# game/characters_events_idles/mc_events.rpy:718
translate chinese gg_intro_2857877c:

    # Sonya "Я положу все необходимое на диван"
    Sonya "我会把你需要的东西放在沙发上"

# game/characters_events_idles/mc_events.rpy:720
translate chinese gg_intro_f96b8f09:

    # gg_chat "Похоже, пока я могу здесь остаться"
    gg_chat "看来我暂时可以留在这里了"

# game/characters_events_idles/mc_events.rpy:724
translate chinese gg_intro_19e97f44:

    # gg_chat "Я так устал за этот день"
    gg_chat "我今天好累"

# game/characters_events_idles/mc_events.rpy:725
translate chinese gg_intro_6f0f1d5a:

    # gg_chat "Пора отдыхать"
    gg_chat "是时候休息了"

# game/characters_events_idles/mc_events.rpy:737
translate chinese gg_first_morning_8051fd9f:

    # gg_chat "Утро"
    gg_chat "早晨"

# game/characters_events_idles/mc_events.rpy:739
translate chinese gg_first_morning_c535b2eb:

    # gg_chat "Давно я так не просыпался"
    gg_chat "我已经很久没有这样醒来了"

# game/characters_events_idles/mc_events.rpy:741
translate chinese gg_first_morning_654f0c17:

    # gg_chat "Никакой работы"
    gg_chat "没有工作"

# game/characters_events_idles/mc_events.rpy:743
translate chinese gg_first_morning_81883fea:

    # gg_chat "Никакого давления"
    gg_chat "无压力"

# game/characters_events_idles/mc_events.rpy:745
translate chinese gg_first_morning_90c39e25:

    # gg_chat "Природа"
    gg_chat "自然"

# game/characters_events_idles/mc_events.rpy:747
translate chinese gg_first_morning_dbabb2ca:

    # gg_chat "Здесь я свободен"
    gg_chat "我在这里自由自在"

# game/characters_events_idles/mc_events.rpy:749
translate chinese gg_first_morning_663fb966:

    # gg_chat "В городе я жил как белка в колесе"
    gg_chat "在城市里我像轮子里的松鼠一样生活"

# game/characters_events_idles/mc_events.rpy:751
translate chinese gg_first_morning_bb031547:

    # gg_chat "Не жизнь, а выживание"
    gg_chat "不是生活，而是生存"

# game/characters_events_idles/mc_events.rpy:753
translate chinese gg_first_morning_49963596:

    # gg_chat "Мне не хватало этого в городе"
    gg_chat "我在城市里错过了这个"

# game/characters_events_idles/mc_events.rpy:754
translate chinese gg_first_morning_0af076a7:

    # gg_chat "Кажется я останусь"
    gg_chat "看来我会留下来"

# game/characters_events_idles/mc_events.rpy:756
translate chinese gg_first_morning_82a7ff6e:

    # gg_chat "Дорогой бабушке . . ."
    gg_chat "亲爱的奶奶。 。 。"

# game/characters_events_idles/mc_events.rpy:757
translate chinese gg_first_morning_4f068f55:

    # gg_chat "Спасибо похоже, я нашёл то, чего мне не хватало"
    gg_chat "谢谢，看来我找到了我丢失的东西"

# game/characters_events_idles/mc_events.rpy:759
translate chinese gg_first_morning_88a92574:

    # gg_chat "Моя жизнь меняется"
    gg_chat "我的生活正在改变"

# game/characters_events_idles/mc_events.rpy:761
translate chinese gg_first_morning_d67d6049:

    # gg_chat "Посмотрим, что из этого выйдет"
    gg_chat "让我们看看会发生什么"

# game/characters_events_idles/mc_events.rpy:780
translate chinese gg_first_morning_kitchen_b418e893:

    # gg_chat "Можно просто сидеть"
    gg_chat "你可以坐"

# game/characters_events_idles/mc_events.rpy:781
translate chinese gg_first_morning_kitchen_820306b2:

    # gg_chat "Никуда не спешить"
    gg_chat "不要急于去任何地方"

# game/characters_events_idles/mc_events.rpy:787
translate chinese gg_first_morning_kitchen_47966b2a:

    # gg_chat "Обычно меня раздражает мытье посуды. А тут даже приятно"
    gg_chat "洗碗通常让我很恼火。这里也很好"

# game/characters_events_idles/mc_events.rpy:789
translate chinese gg_first_morning_kitchen_2119fa08:

    # gg_chat "Нужно будет всё здесь изучить"
    gg_chat "你需要学习这里的一切"

# game/characters_events_idles/mc_events.rpy:791
translate chinese gg_first_morning_kitchen_52906127:

    # gg_chat "Хочу понять, как здесь живут"
    gg_chat "我想了解他们在这里如何生活"

# game/characters_events_idles/mc_events.rpy:792
translate chinese gg_first_morning_kitchen_1b6b16db:

    # gg_chat "Как всё устроено"
    gg_chat "一切如何运作"

# game/characters_events_idles/mc_events.rpy:795
translate chinese gg_first_morning_kitchen_681dfe7b:

    # gg_chat "Это теперь мой новый дом"
    gg_chat "现在这是我的新家"

# game/characters_events_idles/mc_events.rpy:810
translate chinese gg_first_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "哦"

# game/characters_events_idles/mc_events.rpy:812
translate chinese gg_first_day_bathroom_7b463844:

    # Sonya "Прости, я не думала, что ты сейчас зайдешь"
    Sonya "抱歉，我没想到你现在会进来"

# game/characters_events_idles/mc_events.rpy:813
translate chinese gg_first_day_bathroom_32835352:

    # Sonya "Я хотела прибраться"
    Sonya "我想要清理"

# game/characters_events_idles/mc_events.rpy:817
translate chinese gg_first_day_bathroom_826d81cb:

    # Sonya "Я не мешаю тебе?"
    Sonya "我打扰您了吗？"

# game/characters_events_idles/mc_events.rpy:819
translate chinese gg_first_day_bathroom_c012b14a:

    # Sonya "Я сейчас закончу"
    Sonya "我现在就完成"

# game/characters_events_idles/mc_events.rpy:821
translate chinese gg_first_day_bathroom_1c4c4c5a:

    # gg "Нет, всё нормально"
    gg "不，没关系"

# game/characters_events_idles/mc_events.rpy:822
translate chinese gg_first_day_bathroom_bf898b26:

    # gg "Я подожду"
    gg "我会等待"

# game/characters_events_idles/mc_events.rpy:824
translate chinese gg_first_day_bathroom_1452bdd4:

    # gg "Если тебе нужна помощь — скажи"
    gg "如果您需要帮助，请告诉我"

# game/characters_events_idles/mc_events.rpy:826
translate chinese gg_first_day_bathroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "这是真的吗？"

# game/characters_events_idles/mc_events.rpy:828
translate chinese gg_first_day_bathroom_6e75581c:

    # Sonya "Ты не обязан, я просто"
    Sonya "你不必这么做，我只是"

# game/characters_events_idles/mc_events.rpy:830
translate chinese gg_first_day_bathroom_bad9a3a7:

    # Sonya "Ну, если тебе не сложно"
    Sonya "好吧，如果这对你来说不困难的话"

# game/characters_events_idles/mc_events.rpy:832
translate chinese gg_first_day_bathroom_506ec94d:

    # Sonya "Можешь тогда разложить вещи для стирки"
    Sonya "然后你就可以把衣服放起来洗了。"

# game/characters_events_idles/mc_events.rpy:834
translate chinese gg_first_day_bathroom_1b360134:

    # Sonya "Потом сложи что уже высохло"
    Sonya "然后将已经干的部分折叠起来"

# game/characters_events_idles/mc_events.rpy:836
translate chinese gg_first_day_bathroom_cc2e9c27:

    # Sonya "Отнесу я сама"
    Sonya "我自己来扛"

# game/characters_events_idles/mc_events.rpy:856
translate chinese gg_first_day_bathroom_fb297fd7:

    # gg_chat "Как будто мы тут давно живём"
    gg_chat "好像我们已经在这里住了很长时间了"

# game/characters_events_idles/mc_events.rpy:858
translate chinese gg_first_day_bathroom_adfa1b84:

    # Sonya "Мне чуть чуть осталось"
    Sonya "我还剩一点点"

# game/characters_events_idles/mc_events.rpy:860
translate chinese gg_first_day_bathroom_dc9b9999:

    # Sonya "Обычно в доме только я убираюсь"
    Sonya "通常只有我一个人打扫房子。"

# game/characters_events_idles/mc_events.rpy:864
translate chinese gg_first_day_bathroom_09b9d111:

    # Sonya "А . . ."
    Sonya "A. 。 。"

# game/characters_events_idles/mc_events.rpy:865
translate chinese gg_first_day_bathroom_a741acc1:

    # Sonya "Ты наверное хочешь в душ"
    Sonya "你可能想洗澡"

# game/characters_events_idles/mc_events.rpy:869
translate chinese gg_first_day_bathroom_9f7316a6:

    # Sonya "Полотенца сейчас у меня в комнате"
    Sonya "毛巾现在在我的房间里"

# game/characters_events_idles/mc_events.rpy:871
translate chinese gg_first_day_bathroom_352fa084:

    # Sonya "Мы можем сходить туда, если хочешь"
    Sonya "如果你愿意的话我们可以去那里"

# game/characters_events_idles/mc_events.rpy:873
translate chinese gg_first_day_bathroom_264ee174:

    # gg "Пойдем"
    gg "我们走吧"

# game/characters_events_idles/mc_events.rpy:879
translate chinese gg_first_day_bathroom_a3853f22:

    # gg_chat "Как сильно поменялись комнаты"
    gg_chat "房间改变了多少"

# game/characters_events_idles/mc_events.rpy:883
translate chinese gg_first_day_bathroom_1d2f5a17:

    # Sonya "Вот"
    Sonya "这里"

# game/characters_events_idles/mc_events.rpy:885
translate chinese gg_first_day_bathroom_33def544:

    # Sonya "Если что, там ещё есть"
    Sonya "如果有的话还有更多吗"

# game/characters_events_idles/mc_events.rpy:887
translate chinese gg_first_day_bathroom_5c20aef6:

    # Sonya "Э ну приятного купания"
    Sonya "哦，好吧，祝你游得愉快"

# game/characters_events_idles/mc_events.rpy:889
translate chinese gg_first_day_bathroom_3eec94f5:

    # gg "А да спасибо"
    gg "哦，是的，谢谢"

# game/characters_events_idles/mc_events.rpy:892
translate chinese gg_first_day_bathroom_b774dd45:

    # gg_chat "Оказывается, для уюта нужно совсем немного"
    gg_chat "事实证明你只需要很少的东西就能感到舒适"

# game/characters_events_idles/mc_events.rpy:905
translate chinese gg_first_morning_mayaroom_ff197092:

    # Maya "Барси!"
    Maya "巴尔西！"

# game/characters_events_idles/mc_events.rpy:907
translate chinese gg_first_morning_mayaroom_de472ed4:

    # Maya "Барсик!"
    Maya "巴尔西克！"

# game/characters_events_idles/mc_events.rpy:910
translate chinese gg_first_morning_mayaroom_a4a7667e:

    # gg_chat "Что-то случилось?"
    gg_chat "发生什么事了吗？"

# game/characters_events_idles/mc_events.rpy:914
translate chinese gg_first_morning_mayaroom_6f63b0d7:

    # gg_chat "Лучше ей не мешать . . ."
    gg_chat "最好不要打扰她。 。 。"

# game/characters_events_idles/mc_events.rpy:920
translate chinese gg_first_morning_mayaroom_8e71c9f9:

    # Maya "Стоп"
    Maya "停止"

# game/characters_events_idles/mc_events.rpy:922
translate chinese gg_first_morning_mayaroom_857efa08:

    # Maya "Ты кота не видел?"
    Maya "你见过那只猫吗？"

# game/characters_events_idles/mc_events.rpy:924
translate chinese gg_first_morning_mayaroom_270e2f8c:

    # gg "Нет"
    gg "不"

# game/characters_events_idles/mc_events.rpy:926
translate chinese gg_first_morning_mayaroom_def6171d:

    # gg "Но могу помочь"
    gg "但我可以帮忙"

# game/characters_events_idles/mc_events.rpy:928
translate chinese gg_first_morning_mayaroom_359a75af:

    # Maya "Твоя помощь мне не нужна"
    Maya "我不需要你的帮助"

# game/characters_events_idles/mc_events.rpy:930
translate chinese gg_first_morning_mayaroom_785a8355:

    # Maya "Хотя если будешь молчать — помогай"
    Maya "尽管如果你保持沉默，帮助"

# game/characters_events_idles/mc_events.rpy:932
translate chinese gg_first_morning_mayaroom_929a1d4f:

    # gg_chat "Это так на помощь соглашаются"
    gg_chat "这就是他们同意提供帮助的方式"

# game/characters_events_idles/mc_events.rpy:937
translate chinese gg_first_morning_mayaroom_bb6b3842:

    # Maya "Ты где барсииик"
    Maya "亲爱的，你在哪里？"

# game/characters_events_idles/mc_events.rpy:946
translate chinese gg_first_morning_mayaroom_32a24542:

    # gg_chat "Нашёлся"
    gg_chat "成立"

# game/characters_events_idles/mc_events.rpy:950
translate chinese gg_first_morning_mayaroom_954eaf61:

    # gg_chat "Главное не разбудить"
    gg_chat "最主要的是还没醒"

# game/characters_events_idles/mc_events.rpy:952
translate chinese gg_first_morning_mayaroom_79aa0dff:

    # Maya "Всё хорошо"
    Maya "一切都很好"

# game/characters_events_idles/mc_events.rpy:954
translate chinese gg_first_morning_mayaroom_831f5c17:

    # Maya "Я здесь барсик"
    Maya "我是这里的獾"

# game/characters_events_idles/mc_events.rpy:958
translate chinese gg_first_morning_mayaroom_f0949f54:

    # Maya "Ты меня напугал"
    Maya "你吓到我了"

# game/characters_events_idles/mc_events.rpy:959
translate chinese gg_first_morning_mayaroom_a8d4beb2:

    # Maya "Глупый"
    Maya "愚蠢的"

# game/characters_events_idles/mc_events.rpy:962
translate chinese gg_first_morning_mayaroom_ddc18c67:

    # gg_chat "Она не совсем такая, какой кажется"
    gg_chat "她并不完全是她看起来的那样"

# game/characters_events_idles/mc_events.rpy:974
translate chinese kate_day_kitchen_60e92ce9:

    # Kate "Так, где у вас тут кофе прячут?"
    Kate "那么，你把咖啡藏在哪里呢？"

# game/characters_events_idles/mc_events.rpy:975
translate chinese kate_day_kitchen_077e1944:

    # gg "Ты кто вообще?"
    gg "你到底是谁？"

# game/characters_events_idles/mc_events.rpy:977
translate chinese kate_day_kitchen_67f355f0:

    # Kate "О Привет"
    Kate "哦你好"

# game/characters_events_idles/mc_events.rpy:980
translate chinese kate_day_kitchen_d81632e3:

    # Kate "Я Кейт"
    Kate "我是凯特"

# game/characters_events_idles/mc_events.rpy:982
translate chinese kate_day_kitchen_1e97df81:

    # Kate "Не пугайся, я не вор"
    Kate "别害怕，我不是小偷"

# game/characters_events_idles/mc_events.rpy:983
translate chinese kate_day_kitchen_b0950cd9:

    # Kate "Просто кофе мне жизненно необходим"
    Kate "我只需要咖啡"

# game/characters_events_idles/mc_events.rpy:985
translate chinese kate_day_kitchen_e063e635:

    # gg "Меня [povname] зовут"
    gg "我的名字是[povname]"

# game/characters_events_idles/mc_events.rpy:986
translate chinese kate_day_kitchen_f0d355f9:

    # gg "Растворимый прям тут"
    gg "即时就在这里"

# game/characters_events_idles/mc_events.rpy:988
translate chinese kate_day_kitchen_f2fdab56:

    # Kate "О, спаситель!"
    Kate "救世主啊！"

# game/characters_events_idles/mc_events.rpy:990
translate chinese kate_day_kitchen_fe62b24d:

    # Kate "Значит, ты и есть тот самый парень, который тут появился недавно?"
    Kate "那么，你就是最近出现在这里的那个人吗？"

# game/characters_events_idles/mc_events.rpy:992
translate chinese kate_day_kitchen_ce5edae1:

    # gg "Судя по слухам — да, я"
    gg "据传言 - 是的，我是"

# game/characters_events_idles/mc_events.rpy:994
translate chinese kate_day_kitchen_0d1fc413:

    # Kate "Мая рассказывала"
    Kate "玛雅告诉"

# game/characters_events_idles/mc_events.rpy:996
translate chinese kate_day_kitchen_7c8bce00:

    # Kate "Живёт с Соней давно, а потом появился ты"
    Kate "和索尼娅一起生活了很长一段时间，然后你出现了"

# game/characters_events_idles/mc_events.rpy:997
translate chinese kate_day_kitchen_34985df3:

    # Kate "Интересная компания"
    Kate "有趣的公司"

# game/characters_events_idles/mc_events.rpy:999
translate chinese kate_day_kitchen_2e63aac8:

    # gg "“Интересная” — мягко сказано"
    gg "“有趣”是温和地说"

# game/characters_events_idles/mc_events.rpy:1001
translate chinese kate_day_kitchen_cbdc207c:

    # Kate "Серьёзно? Это растворимый?"
    Kate "严重地？它可以溶解吗？"

# game/characters_events_idles/mc_events.rpy:1003
translate chinese kate_day_kitchen_8937f276:

    # gg "Ага"
    gg "是的"

# game/characters_events_idles/mc_events.rpy:1005
translate chinese kate_day_kitchen_5746fae5:

    # Kate "А ведь вкусно"
    Kate "但很好吃"

# game/characters_events_idles/mc_events.rpy:1006
translate chinese kate_day_kitchen_796538ef:

    # Kate "Обычно от растворимого хочется заплакать"
    Kate "通常瞬间就会让你想哭"

# game/characters_events_idles/mc_events.rpy:1008
translate chinese kate_day_kitchen_3e92b413:

    # gg "Значит, я талантливый бариста"
    gg "所以我是一个有才华的咖啡师"

# game/characters_events_idles/mc_events.rpy:1009
translate chinese kate_day_kitchen_961ab98b:

    # Kate "Или тебе повезло"
    Kate "或者你很幸运"

# game/characters_events_idles/mc_events.rpy:1011
translate chinese kate_day_kitchen_394c86a9:

    # Kate "Ну что, рассказывай, кто ты такой"
    Kate "好吧，告诉我你是谁"

# game/characters_events_idles/mc_events.rpy:1013
translate chinese kate_day_kitchen_517a6831:

    # gg "Обычно начинают с “как дела?”"
    gg "通常他们会以“你好吗？”开始。"

# game/characters_events_idles/mc_events.rpy:1015
translate chinese kate_day_kitchen_bb3d7bf1:

    # Kate "Это скучно"
    Kate "很无聊"

# game/characters_events_idles/mc_events.rpy:1017
translate chinese kate_day_kitchen_01155acc:

    # Kate "Я сразу к сути. Ты кто: сосед, ухажёр, постоялец или просто [povname]"
    Kate "我就开门见山吧。您是谁：邻居、男朋友、客人或只是 [povname]"

# game/characters_events_idles/mc_events.rpy:1019
translate chinese kate_day_kitchen_4333516e:

    # gg "Пусть будет просто [povname]"
    gg "保持简单[povname]"

# game/characters_events_idles/mc_events.rpy:1021
translate chinese kate_day_kitchen_95199003:

    # Kate "Значит, загадочный. Ладно, оставим интригу"
    Kate "所以它很神秘。好吧，让我们留下阴谋"

# game/characters_events_idles/mc_events.rpy:1024
translate chinese kate_day_kitchen_eb2b6424:

    # Kate "Тут уютно"
    Kate "这里很温馨"

# game/characters_events_idles/mc_events.rpy:1025
translate chinese kate_day_kitchen_ad0e7b9c:

    # Kate "Не думала, что Мая вообще когда-то научится жить без хаоса"
    Kate "我不认为玛雅人会学会在没有混乱的情况下生活"

# game/characters_events_idles/mc_events.rpy:1029
translate chinese kate_day_kitchen_1e4f23c6:

    # Maya "Кейт! Ты тут"
    Maya "凯特！你在这里"

# game/characters_events_idles/mc_events.rpy:1030
translate chinese kate_day_kitchen_ecdba904:

    # Maya "Я же сказала подожди меня!"
    Maya "我说等我一下！"

# game/characters_events_idles/mc_events.rpy:1032
translate chinese kate_day_kitchen_b6371751:

    # Maya "Ага, ты уже познакомилась с этим балбесом"
    Maya "是的，你已经见过这个笨蛋了"

# game/characters_events_idles/mc_events.rpy:1034
translate chinese kate_day_kitchen_9c22616a:

    # Kate "Да! И кофе у него отличный, между прочим"
    Kate "是的！顺便说一句，他的咖啡很棒。"

# game/characters_events_idles/mc_events.rpy:1036
translate chinese kate_day_kitchen_08bc7129:

    # Maya "Хвалить не вздумай, зазнается. Нам пора"
    Maya "别想赞美，他就是傲慢。我们的时间到了"

# game/characters_events_idles/mc_events.rpy:1038
translate chinese kate_day_kitchen_8ab29297:

    # Kate "Спасибо за кофе, бариста"
    Kate "谢谢咖啡师的咖啡"

# game/characters_events_idles/mc_events.rpy:1039
translate chinese kate_day_kitchen_11705c38:

    # Kate "Ладно. Ещё увидимся"
    Kate "好的。再见"

translate chinese strings:

    # game/characters_events_idles/mc_events.rpy:361
    old "Послать нахуй"
    new "告诉我操你"

    # game/characters_events_idles/mc_events.rpy:363
    old "Молча уйти"
    new "默默离开"

# TODO: Translation updated at 2026-01-26 03:22

# game/characters_events_idles/mc_events.rpy:295
translate chinese gg_intro_4402cfd9:

    # gg_chat "Я отвечу попозже бабушка"
    gg_chat "稍后我会回复奶奶"

# game/characters_events_idles/mc_events.rpy:668
translate chinese gg_intro_0997da9e:

    # Maya "Это мы с Соней решим!"
    Maya "索尼娅和我会决定这个！"

# game/characters_events_idles/mc_events.rpy:670
translate chinese gg_intro_6619e154:

    # Maya "{sc}{size=*1.5}СОНЯ{/sc}" with hpunch
    Maya "{sc}{size=*1.5}索尼娅{/sc}" with hpunch

# game/characters_events_idles/mc_events.rpy:805
translate chinese gg_intro_fadd240e:

    # "Ночью можно отдохнуть — нажми на кровать, чтобы начать новый день"
    "晚上可以休息——点击床开始新的一天"

# game/characters_events_idles/mc_events.rpy:895
translate chinese gg_first_day_bathroom_6c8604ba:

    # Sonya "Я не думала, что ты сейчас зайдешь"
    Sonya "我没想到你现在就进来了"

# game/characters_events_idles/mc_events.rpy:896
translate chinese gg_first_day_bathroom_15c3e23b:

    # Sonya "Хотела прибраться"
    Sonya "我想要清理"

# game/characters_events_idles/mc_events.rpy:900
translate chinese gg_first_day_bathroom_94ef9943:

    # Sonya "Ты хотел в душ?"
    Sonya "你想洗澡吗？"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/mc_events.rpy:287
translate chinese gg_intro_21dc756d:

    # gg_chat "Чёрт, я опаздываю"
    gg_chat "妈的我迟到了"

# game/characters_events_idles/mc_events.rpy:295
translate chinese gg_intro_01ac9e1d:

    # gg_chat "Я отвечу попозже, бабушка"
    gg_chat "奶奶，我稍后再回答"

# game/characters_events_idles/mc_events.rpy:325
translate chinese gg_intro_d5122bca:

    # Assistant "И напомню: если продолжишь, {w}то разговор о снижении зарплаты — это уже вопрос времени"
    Assistant "让我提醒您：如果您继续，{w}有关减薪的讨论已经是时间问题"

# game/characters_events_idles/mc_events.rpy:361
translate chinese gg_intro_4e8253d3:

    # gg_chat "Сколько ни работай, этому нет конца"
    gg_chat "无论你付出多少努力，都没有尽头"

# game/characters_events_idles/mc_events.rpy:393
translate chinese gg_intro_eb3e3aa2:

    # gg_chat "Да пошло оно все"
    gg_chat "他妈的这一切"

# game/characters_events_idles/mc_events.rpy:409
translate chinese gg_intro_187f7fc4:

    # Director "Ты вообще что делаешь"
    Director "你到底在做什么"

# game/characters_events_idles/mc_events.rpy:500
translate chinese gg_intro_bb6264b0:

    # gg_chat "Все, кого я вижу, со мной здороваются"
    gg_chat "我看到的每个人都跟我打招呼"

# game/characters_events_idles/mc_events.rpy:520
translate chinese gg_intro_2c4c4cb8:

    # UnknownGirl "Если что-то нужно будет, спрашивай помощь у любого"
    UnknownGirl "如果您需要任何帮助，请向任何人寻求帮助"

# game/characters_events_idles/mc_events.rpy:524
translate chinese gg_intro_f654fdee:

    # gg "Хорошо и Вам отличного дня"
    gg "好吧，也祝你有美好的一天"

# game/characters_events_idles/mc_events.rpy:527
translate chinese gg_intro_87051a07:

    # gg_chat "Бабушка, похоже, говорила правду о людях здесь"
    gg_chat "奶奶说的似乎是这里的人的真实情况"

# game/characters_events_idles/mc_events.rpy:546
translate chinese gg_intro_95240a3b:

    # gg_chat "Да, дом поменялся"
    gg_chat "是的，房子变了"

# game/characters_events_idles/mc_events.rpy:556
translate chinese gg_intro_e94b0047:

    # gg_chat "Здесь кто-то есть?"
    gg_chat "这里有人吗？"

# game/characters_events_idles/mc_events.rpy:596
translate chinese gg_intro_eee07a35:

    # gg "Стой, подожди"
    gg "等等，等等"

# game/characters_events_idles/mc_events.rpy:604
translate chinese gg_intro_ca7cead7:

    # Maya "Что-то я такого внука никогда здесь не видела"
    Maya "我在这里从未见过这样的孙子"

# game/characters_events_idles/mc_events.rpy:650
translate chinese gg_intro_f08474d4:

    # Maya "Мои цветочки любимые. Они остались"
    Maya "我最喜欢的花。他们留下来"

# game/characters_events_idles/mc_events.rpy:659
translate chinese gg_intro_90f291ff:

    # Maya "Боже, ладно"
    Maya "天哪，好吧"

# game/characters_events_idles/mc_events.rpy:660
translate chinese gg_intro_7b0b2a04:

    # Maya "Похоже на правду"
    Maya "看起来像事实"

# game/characters_events_idles/mc_events.rpy:676
translate chinese gg_intro_1b04d04b:

    # Maya "Слушай, если ты хоть что-то сделаешь"
    Maya "听着，如果你做了什么"

# game/characters_events_idles/mc_events.rpy:734
translate chinese gg_intro_5834166b:

    # Sonya "Нет-нет, всё нормально"
    Sonya "不不不，一切都好"

# game/characters_events_idles/mc_events.rpy:740
translate chinese gg_intro_05ceb2ee:

    # Sonya "Я прочла письмо Линды"
    Sonya "我读了琳达的信"

# game/characters_events_idles/mc_events.rpy:744
translate chinese gg_intro_c73d3bb7:

    # Sonya "Она всегда нас так называла"
    Sonya "她总是这样称呼我们"

# game/characters_events_idles/mc_events.rpy:760
translate chinese gg_intro_d2363caa:

    # Sonya "Это место для нас стало родным"
    Sonya "这个地方已经成为我们的家"

# game/characters_events_idles/mc_events.rpy:764
translate chinese gg_intro_79c61e5f:

    # Sonya "Говорила, что ты хороший, по крайней мере в детстве"
    Sonya "她说你很好，至少小时候是这样。"

# game/characters_events_idles/mc_events.rpy:774
translate chinese gg_intro_7f8fcf55:

    # Sonya "Ну, какой у тебя дальше план?"
    Sonya "嗯，你的下一步计划是什么？"

# game/characters_events_idles/mc_events.rpy:787
translate chinese gg_intro_d7903980:

    # Sonya "Если захочешь мы еще поговорим"
    Sonya "如果你愿意我们可以再聊"

# game/characters_events_idles/mc_events.rpy:789
translate chinese gg_intro_7d278239:

    # Sonya "А пока ты можешь лечь в зале"
    Sonya "在此期间，你可以在大厅里躺下"

# game/characters_events_idles/mc_events.rpy:793
translate chinese gg_intro_41b7f3b0:

    # gg "Да, хорошо"
    gg "是的，好的"

# game/characters_events_idles/mc_events.rpy:835
translate chinese gg_first_morning_5b301338:

    # gg_chat "Эх, как же мне не хватало свободы"
    gg_chat "哦，我多么怀念自由"

# game/characters_events_idles/mc_events.rpy:836
translate chinese gg_first_morning_146ca63e:

    # gg_chat "Кажется, я останусь"
    gg_chat "看来我会留下来"

# game/characters_events_idles/mc_events.rpy:839
translate chinese gg_first_morning_9cc6e0e8:

    # gg_chat "Спасибо, похоже, я нашёл то, чего мне не хватало"
    gg_chat "谢谢，看来我找到了我丢失的东西"

# game/characters_events_idles/mc_events.rpy:917
translate chinese gg_first_day_bathroom_c3b33eb8:

    # Sonya "Потом сложи, что уже высохло"
    Sonya "然后将已经干的部分折叠起来"

# game/characters_events_idles/mc_events.rpy:970
translate chinese gg_first_day_bathroom_887d1e72:

    # Sonya "Ээ... нуу приятного купания"
    Sonya "呃……好吧，祝你游得愉快"

# game/characters_events_idles/mc_events.rpy:972
translate chinese gg_first_day_bathroom_997383a9:

    # gg "А, да, спасибо"
    gg "哦，是的，谢谢"

# game/characters_events_idles/mc_events.rpy:1018
translate chinese gg_first_morning_mayaroom_123ee93a:

    # Maya "Хотя, если будешь молчать — помогай"
    Maya "虽然，如果你保持沉默，帮助"

