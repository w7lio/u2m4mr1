﻿# TODO: Translation updated at 2026-01-21 02:05

# game/characters_events_idles/sonya_events.rpy:6
translate chinese sonya_scene1_morning_kitchen_a756dbc0:

    # gg "Утречко"
    gg "乌特雷奇科"

# game/characters_events_idles/sonya_events.rpy:12
translate chinese sonya_scene1_morning_kitchen_2641e2c9:

    # Sonya "Доброе утро"
    Sonya "早上好"

# game/characters_events_idles/sonya_events.rpy:14
translate chinese sonya_scene1_morning_kitchen_50dcebad:

    # Sonya "Как тебе спалось?"
    Sonya "你睡得怎么样？"

# game/characters_events_idles/sonya_events.rpy:16
translate chinese sonya_scene1_morning_kitchen_9fdea20a:

    # gg "Нормально"
    gg "美好的"

# game/characters_events_idles/sonya_events.rpy:18
translate chinese sonya_scene1_morning_kitchen_c923e04f:

    # gg "Тихо"
    gg "安静的"

# game/characters_events_idles/sonya_events.rpy:20
translate chinese sonya_scene1_morning_kitchen_367f1af9:

    # Sonya "Там диван конечно старый"
    Sonya "那里的沙发肯定很旧"

# game/characters_events_idles/sonya_events.rpy:22
translate chinese sonya_scene1_morning_kitchen_0a0eba96:

    # Sonya "Но удобный"
    Sonya "但方便"

# game/characters_events_idles/sonya_events.rpy:24
translate chinese sonya_scene1_morning_kitchen_0f37c26d:

    # gg "Я заметил"
    gg "我注意到"

# game/characters_events_idles/sonya_events.rpy:26
translate chinese sonya_scene1_morning_kitchen_93b6fb71:

    # Sonya "Ты уже успел пройтись по деревне?"
    Sonya "你已经在村子里走了一圈了吗？"

# game/characters_events_idles/sonya_events.rpy:28
translate chinese sonya_scene1_morning_kitchen_0839a090:

    # Sonya "Или пока только дом вспоминаешь?"
    Sonya "或者你只是想念家乡？"

# game/characters_events_idles/sonya_events.rpy:30
translate chinese sonya_scene1_morning_kitchen_12aa0f18:

    # gg "Немного посмотрел"
    gg "看了一点"

# game/characters_events_idles/sonya_events.rpy:32
translate chinese sonya_scene1_morning_kitchen_c33e58bc:

    # gg "Тут . . . Хорошие люди"
    gg "这里 。 。 。好人"

# game/characters_events_idles/sonya_events.rpy:34
translate chinese sonya_scene1_morning_kitchen_c8772e87:

    # Sonya "Да"
    Sonya "是的"

# game/characters_events_idles/sonya_events.rpy:36
translate chinese sonya_scene1_morning_kitchen_ed137d91:

    # Sonya "Ты к этому быстро привыкаешь"
    Sonya "你很快就会习惯的"

# game/characters_events_idles/sonya_events.rpy:48
translate chinese sonya_scene1_morning_kitchen_e45ac0f2:

    # Sonya "Если вдруг проголодаешься — бери что хочешь"
    Sonya "如果你突然饿了，就吃你想要的东西"

# game/characters_events_idles/sonya_events.rpy:50
translate chinese sonya_scene1_morning_kitchen_947178ba:

    # Sonya "У нас обычно никто особо не спрашивает"
    Sonya "通常没有人问我们太多"

# game/characters_events_idles/sonya_events.rpy:56
translate chinese sonya_scene1_morning_kitchen_04c6c53d:

    # gg "Спасибо"
    gg "谢谢"

# game/characters_events_idles/sonya_events.rpy:60
translate chinese sonya_scene1_morning_kitchen_77469d65:

    # Sonya "А вообще"
    Sonya "一般来说"

# game/characters_events_idles/sonya_events.rpy:62
translate chinese sonya_scene1_morning_kitchen_ebb5bb0f:

    # Sonya "Как тебе здесь?"
    Sonya "你觉得这里怎么样？"

# game/characters_events_idles/sonya_events.rpy:66
translate chinese sonya_scene1_morning_kitchen_77102205:

    # Sonya "В смысле . . . жить вместе"
    Sonya "按照 。 。 。住在一起"

# game/characters_events_idles/sonya_events.rpy:70
translate chinese sonya_scene1_morning_kitchen_dcf6ae5e:

    # gg "Непривычно"
    gg "异常"

# game/characters_events_idles/sonya_events.rpy:72
translate chinese sonya_scene1_morning_kitchen_0dd94278:

    # gg "Но нормально"
    gg "但没关系"

# game/characters_events_idles/sonya_events.rpy:74
translate chinese sonya_scene1_morning_kitchen_c8772e87_1:

    # Sonya "Да"
    Sonya "是的"

# game/characters_events_idles/sonya_events.rpy:76
translate chinese sonya_scene1_morning_kitchen_8aa7b1fd:

    # Sonya "Мы тоже не сразу привыкли"
    Sonya "我们也花了一段时间才习惯。"

# game/characters_events_idles/sonya_events.rpy:78
translate chinese sonya_scene1_morning_kitchen_270848f3:

    # Sonya "Когда людей в доме становится больше"
    Sonya "当家里人多的时候"

# game/characters_events_idles/sonya_events.rpy:80
translate chinese sonya_scene1_morning_kitchen_816d8504:

    # Sonya "Всё немного меняется"
    Sonya "事情发生了一些变化"

# game/characters_events_idles/sonya_events.rpy:99
translate chinese sonya_scene1_morning_kitchen_7b099c93:

    # gg_chat "Мае — завтрак"
    gg_chat "五月 - 早餐"

# game/characters_events_idles/sonya_events.rpy:100
translate chinese sonya_scene1_morning_kitchen_fcffc8ef:

    # gg_chat "Если не успею — купи, пожалуйста, продукты"
    gg_chat "如果我没时间，请去买菜"

# game/characters_events_idles/sonya_events.rpy:109
translate chinese sonya_scene1_morning_kitchen_7158ba01:

    # gg "Ладно, я пойду"
    gg "好的，我这就去"

# game/characters_events_idles/sonya_events.rpy:111
translate chinese sonya_scene1_morning_kitchen_fbb535a1:

    # gg "Не буду мешать"
    gg "我不会干涉"

# game/characters_events_idles/sonya_events.rpy:113
translate chinese sonya_scene1_morning_kitchen_98963b02:

    # Sonya "Да ты и не мешаешь"
    Sonya "是的，你不干涉"

# game/characters_events_idles/sonya_events.rpy:117
translate chinese sonya_scene1_morning_kitchen_d24f6aaf:

    # Sonya "Но . . . хорошо"
    Sonya "但 。 。 。美好的"

# game/characters_events_idles/sonya_events.rpy:133
translate chinese sonya_scene2_day_girlroom_68c12557:

    # gg "Сонь"
    gg "索尼娅"

# game/characters_events_idles/sonya_events.rpy:137
translate chinese sonya_scene2_day_girlroom_d3ca52ed:

    # gg "Ты не знаешь, где у вас аптечка?"
    gg "你不知道你的急救箱在哪里吗？"

# game/characters_events_idles/sonya_events.rpy:139
translate chinese sonya_scene2_day_girlroom_fb949c9e:

    # Sonya "Аптечка?"
    Sonya "急救箱？"

# game/characters_events_idles/sonya_events.rpy:141
translate chinese sonya_scene2_day_girlroom_695184c3:

    # Sonya "А что случилось?"
    Sonya "发生了什么？"

# game/characters_events_idles/sonya_events.rpy:143
translate chinese sonya_scene2_day_girlroom_55820831:

    # gg "Да так"
    gg "是的，所以"

# game/characters_events_idles/sonya_events.rpy:145
translate chinese sonya_scene2_day_girlroom_41aa37fb:

    # gg "Поцарапался.{w} Ерунда"
    gg "划伤了。{w}废话"

# game/characters_events_idles/sonya_events.rpy:149
translate chinese sonya_scene2_day_girlroom_06e5075f:

    # Sonya "Подожди"
    Sonya "等待"

# game/characters_events_idles/sonya_events.rpy:151
translate chinese sonya_scene2_day_girlroom_b43c4c5e:

    # Sonya "Сейчас все сделаем"
    Sonya "现在我们会做一切"

# game/characters_events_idles/sonya_events.rpy:155
translate chinese sonya_scene2_day_girlroom_7cc8260f:

    # Sonya "А ты почти без вещей приехал"
    Sonya "而你几乎什么都没带"

# game/characters_events_idles/sonya_events.rpy:157
translate chinese sonya_scene2_day_girlroom_b1f32e8a:

    # Sonya "Так и планировал"
    Sonya "这就是我的计划"

# game/characters_events_idles/sonya_events.rpy:158
translate chinese sonya_scene2_day_girlroom_06e860df:

    # Sonya "Или просто не успел собрать?"
    Sonya "或者只是没有时间收集？"

# game/characters_events_idles/sonya_events.rpy:164
translate chinese sonya_scene2_day_girlroom_cc881b3b:

    # gg "Скорее второе"
    gg "更有可能是第二个"

# game/characters_events_idles/sonya_events.rpy:166
translate chinese sonya_scene2_day_girlroom_72e0315a:

    # gg "Решил не тащить за собой старое"
    gg "我决定不再拖着旧的"

# game/characters_events_idles/sonya_events.rpy:169
translate chinese sonya_scene2_day_girlroom_fef188e6:

    # gg "Посмотреть, как будет"
    gg "看看进展如何"

# game/characters_events_idles/sonya_events.rpy:171
translate chinese sonya_scene2_day_girlroom_4b248478:

    # Sonya "Будто новая жизнь"
    Sonya "就像新的生活一样"

# game/characters_events_idles/sonya_events.rpy:173
translate chinese sonya_scene2_day_girlroom_84c6a1f8:

    # Sonya "Ты получается больше утренний человек?"
    Sonya "你是一个比较喜欢早起的人吗？"

# game/characters_events_idles/sonya_events.rpy:175
translate chinese sonya_scene2_day_girlroom_e550b517:

    # Sonya "Или нет?"
    Sonya "或不？"

# game/characters_events_idles/sonya_events.rpy:177
translate chinese sonya_scene2_day_girlroom_254f159a:

    # gg "Раньше — скорее вечерний"
    gg "早些时候 - 更像是晚上"

# game/characters_events_idles/sonya_events.rpy:179
translate chinese sonya_scene2_day_girlroom_bf5f3aef:

    # gg "А здесь почему-то весь день на ногах"
    gg "出于某种原因我整天都站着"

# game/characters_events_idles/sonya_events.rpy:181
translate chinese sonya_scene2_day_girlroom_633d56a5:

    # gg "Сам удивляюсь"
    gg "我自己也很惊讶"

# game/characters_events_idles/sonya_events.rpy:183
translate chinese sonya_scene2_day_girlroom_53fa6f98:

    # Sonya "Правда?"
    Sonya "这是真的吗？"

# game/characters_events_idles/sonya_events.rpy:185
translate chinese sonya_scene2_day_girlroom_7e52f22d:

    # Sonya "Значит, деревня на тебя хорошо действует"
    Sonya "所以村庄对你有很好的影响"

# game/characters_events_idles/sonya_events.rpy:187
translate chinese sonya_scene2_day_girlroom_d0a33041:

    # Sonya "И часто ты так . . ."
    Sonya "你经常这样做。 。 。"

# game/characters_events_idles/sonya_events.rpy:189
translate chinese sonya_scene2_day_girlroom_25b95c9d:

    # Sonya "Царапаешься?"
    Sonya "你在抓自己吗？"

# game/characters_events_idles/sonya_events.rpy:191
translate chinese sonya_scene2_day_girlroom_8f76c3f1:

    # gg "Не особо"
    gg "并不真地"

# game/characters_events_idles/sonya_events.rpy:193
translate chinese sonya_scene2_day_girlroom_2171a9af:

    # gg "Просто ещё не привык к местной фауне"
    gg "我只是还不习惯当地的动物群"

# game/characters_events_idles/sonya_events.rpy:195
translate chinese sonya_scene2_day_girlroom_09b9d111:

    # Sonya "А . . ."
    Sonya "A. 。 。"

# game/characters_events_idles/sonya_events.rpy:196
translate chinese sonya_scene2_day_girlroom_521ff667:

    # Sonya "Тогда понятно"
    Sonya "那么就清楚了"

# game/characters_events_idles/sonya_events.rpy:203
translate chinese sonya_scene2_day_girlroom_6b068d33:

    # gg "Ты так аккуратно всё делаешь . . ."
    gg "你做每件事都那么仔细。 。 。"

# game/characters_events_idles/sonya_events.rpy:205
translate chinese sonya_scene2_day_girlroom_bbcf86fd:

    # gg "Это привычка?"
    gg "这是一种习惯吗？"

# game/characters_events_idles/sonya_events.rpy:207
translate chinese sonya_scene2_day_girlroom_a174002e:

    # Sonya "Ага"
    Sonya "是的"

# game/characters_events_idles/sonya_events.rpy:208
translate chinese sonya_scene2_day_girlroom_5e6a7fb2:

    # Sonya "Мне так спокойнее"
    Sonya "这样我感觉更平静"

# game/characters_events_idles/sonya_events.rpy:210
translate chinese sonya_scene2_day_girlroom_ea7be3c1:

    # Sonya "Когда всё сделано как надо"
    Sonya "当一切都做对了"

# game/characters_events_idles/sonya_events.rpy:212
translate chinese sonya_scene2_day_girlroom_d9f6fc3a:

    # Sonya "Готово"
    Sonya "准备好"

# game/characters_events_idles/sonya_events.rpy:216
translate chinese sonya_scene2_day_girlroom_04c6c53d:

    # gg "Спасибо"
    gg "谢谢"

# game/characters_events_idles/sonya_events.rpy:218
translate chinese sonya_scene2_day_girlroom_1c0e0b38:

    # Sonya "А у тебя . . ."
    Sonya "你呢 。 。 。"

# game/characters_events_idles/sonya_events.rpy:220
translate chinese sonya_scene2_day_girlroom_041495e8:

    # Sonya "Там, в городе . . ."
    Sonya "在那里，在城市里。 。 。"

# game/characters_events_idles/sonya_events.rpy:222
translate chinese sonya_scene2_day_girlroom_ec4c11a0:

    # Sonya "Кто-нибудь остался?"
    Sonya "有人还剩吗？"

# game/characters_events_idles/sonya_events.rpy:224
translate chinese sonya_scene2_day_girlroom_d26255df:

    # gg "Был один человек"
    gg "曾经有一个人"

# game/characters_events_idles/sonya_events.rpy:226
translate chinese sonya_scene2_day_girlroom_5319b6ee:

    # gg "Мы давно разошлись"
    gg "我们很久以前就分开了"

# game/characters_events_idles/sonya_events.rpy:228
translate chinese sonya_scene2_day_girlroom_48254a12:

    # gg "Сейчас . . .{w} скорее нет, чем да"
    gg "现在 。 。 .{w} 与其说“是”，不如说“不”"

# game/characters_events_idles/sonya_events.rpy:230
translate chinese sonya_scene2_day_girlroom_93bf8783:

    # Sonya "Понятно"
    Sonya "天气晴朗"

# game/characters_events_idles/sonya_events.rpy:232
translate chinese sonya_scene2_day_girlroom_bfbf3b82:

    # Sonya "Я просто спросила"
    Sonya "我刚问"

# game/characters_events_idles/sonya_events.rpy:238
translate chinese sonya_scene2_day_girlroom_bde02200:

    # Sonya "Тогда я наверно . . ."
    Sonya "那我猜。 。 。"

# game/characters_events_idles/sonya_events.rpy:240
translate chinese sonya_scene2_day_girlroom_230ea232:

    # Sonya "Буду дальше убираться, пыль быстро собирается"
    Sonya "我会继续打扫，灰尘很快就会积聚"

# game/characters_events_idles/sonya_events.rpy:243
translate chinese sonya_scene2_day_girlroom_944c14eb:

    # gg "Спасибо еще раз"
    gg "再次感谢"

# game/characters_events_idles/sonya_events.rpy:245
translate chinese sonya_scene2_day_girlroom_3735a72e:

    # Sonya "Угу"
    Sonya "是的"

# game/characters_events_idles/sonya_events.rpy:247
translate chinese sonya_scene2_day_girlroom_ccc766ff:

    # Sonya "Если что аптечка всегда здесь"
    Sonya "如果有的话，急救箱总是在这里"

# game/characters_events_idles/sonya_events.rpy:273
translate chinese sonya_scene3_day_bathroom_03e250ee:

    # gg "Эмм Соня, я тут"
    gg "嗯，索尼娅，我在这里"

# game/characters_events_idles/sonya_events.rpy:281
translate chinese sonya_scene3_day_bathroom_9c4277f2:

    # Sonya "Ой"
    Sonya "哦"

# game/characters_events_idles/sonya_events.rpy:294
translate chinese sonya_scene3_day_bathroom_b3aa243a:

    # Sonya "Прости"
    Sonya "对不起"

# game/characters_events_idles/sonya_events.rpy:296
translate chinese sonya_scene3_day_bathroom_ea2e53f8:

    # Sonya "Я думала, ванная свободна"
    Sonya "我以为浴室是免费的"

# game/characters_events_idles/sonya_events.rpy:298
translate chinese sonya_scene3_day_bathroom_7f3525bd:

    # Sonya "Это моя ошибка"
    Sonya "那是我的错"

# game/characters_events_idles/sonya_events.rpy:300
translate chinese sonya_scene3_day_bathroom_b8f5eb09:

    # gg "Всё нормально"
    gg "一切都很好"

# game/characters_events_idles/sonya_events.rpy:302
translate chinese sonya_scene3_day_bathroom_623f3607:

    # gg "Ничего страшного"
    gg "没关系"

# game/characters_events_idles/sonya_events.rpy:304
translate chinese sonya_scene3_day_bathroom_7fce0f16:

    # Sonya "{size=*1.3}Нет"
    Sonya "{size=*1.3}否"

# game/characters_events_idles/sonya_events.rpy:306
translate chinese sonya_scene3_day_bathroom_c2e17951:

    # Sonya "Я просто сделаю вид"
    Sonya "我就假装"

# game/characters_events_idles/sonya_events.rpy:308
translate chinese sonya_scene3_day_bathroom_1a86b367:

    # Sonya "Что этого не было"
    Sonya "以为这事没有发生"

# game/characters_events_idles/sonya_events.rpy:325
translate chinese sonya_scene3_day_bathroom_475b14a6:

    # Sonya "Я оставила тебе чай на кухне"
    Sonya "我在厨房给你留了一些茶"

# game/characters_events_idles/sonya_events.rpy:327
translate chinese sonya_scene3_day_bathroom_c0c28f24:

    # Sonya "Горячий аккуратнее"
    Sonya "热的要小心"

# game/characters_events_idles/sonya_events.rpy:330
translate chinese sonya_scene3_day_bathroom_04c6c53d:

    # gg "Спасибо"
    gg "谢谢"

# game/characters_events_idles/sonya_events.rpy:351
translate chinese sonya_scene4_morning_bathroom_db34cd4c:

    # gg "Эм . . ."
    gg "嗯。 。 。"

# game/characters_events_idles/sonya_events.rpy:353
translate chinese sonya_scene4_morning_bathroom_f18372c4:

    # Sonya "Ой . . ." with hpunch
    Sonya "哦 。 。 。" with hpunch

# game/characters_events_idles/sonya_events.rpy:354
translate chinese sonya_scene4_morning_bathroom_d5441823:

    # gg "Наверно, я зайду попозже"
    gg "我可能会稍后回来"

# game/characters_events_idles/sonya_events.rpy:356
translate chinese sonya_scene4_morning_bathroom_b9dc4392:

    # Sonya "Стой"
    Sonya "停止"

# game/characters_events_idles/sonya_events.rpy:358
translate chinese sonya_scene4_morning_bathroom_e21251db:

    # Sonya "Не стесняйся. Чисти зубы, я уже заканчиваю"
    Sonya "别害羞。刷牙吧，我已经刷完了"

# game/characters_events_idles/sonya_events.rpy:360
translate chinese sonya_scene4_morning_bathroom_0d97ff86:

    # gg_chat "Ого . . ."
    gg_chat "哇 。 。 。"

# game/characters_events_idles/sonya_events.rpy:364
translate chinese sonya_scene4_morning_bathroom_7f534b36:

    # Sonya "Тут раньше жили только мы с Маей"
    Sonya "以前只有我和玛雅住在这里。"

# game/characters_events_idles/sonya_events.rpy:366
translate chinese sonya_scene4_morning_bathroom_8e74c8b9:

    # Sonya "Девушки"
    Sonya "女孩们"

# game/characters_events_idles/sonya_events.rpy:368
translate chinese sonya_scene4_morning_bathroom_822105aa:

    # Sonya "Я привыкла ходить"
    Sonya "我习惯走路"

# game/characters_events_idles/sonya_events.rpy:370
translate chinese sonya_scene4_morning_bathroom_759d9a83:

    # Sonya "Так"
    Sonya "所以"

# game/characters_events_idles/sonya_events.rpy:373
translate chinese sonya_scene4_morning_bathroom_893810bd:

    # Sonya "Никого это не смущало . . ."
    Sonya "这并没有打扰任何人。 。 。"

# game/characters_events_idles/sonya_events.rpy:375
translate chinese sonya_scene4_morning_bathroom_2d618e7e:

    # gg "Да где-то я уже такое видел"
    gg "是的，我以前在某处见过这个"

# game/characters_events_idles/sonya_events.rpy:377
translate chinese sonya_scene4_morning_bathroom_26a90d56:

    # Sonya "Ты смотришь"
    Sonya "你在寻找吗"

# game/characters_events_idles/sonya_events.rpy:379
translate chinese sonya_scene4_morning_bathroom_62a5f760:

    # Sonya "Даже не пытаешься отвернуться"
    Sonya "你甚至不尝试将目光移开"

# game/characters_events_idles/sonya_events.rpy:382
translate chinese sonya_scene4_morning_bathroom_1c65dff9:

    # Sonya "И знаешь . . ."
    Sonya "你知道。 。 。"

# game/characters_events_idles/sonya_events.rpy:384
translate chinese sonya_scene4_morning_bathroom_7516d68e:

    # Sonya "Мне это нравится . . ."
    Sonya "我喜欢它。 。 。"

# game/characters_events_idles/sonya_events.rpy:388
translate chinese sonya_scene4_morning_bathroom_6911a69b:

    # Sonya "Всё"
    Sonya "全部"

# game/characters_events_idles/sonya_events.rpy:390
translate chinese sonya_scene4_morning_bathroom_bc7d5f86:

    # Sonya "Хватит тебе утренней зарядки для глаз"
    Sonya "早上锻炼足够眼睛"

# game/characters_events_idles/sonya_events.rpy:395
translate chinese sonya_scene4_morning_bathroom_9bf5f0cd:

    # Sonya "Но всё же . . ."
    Sonya "但仍然。 。 。"

# game/characters_events_idles/sonya_events.rpy:397
translate chinese sonya_scene4_morning_bathroom_3780446f:

    # extend " Как ты можешь смотреть"
    extend "你怎么能看"

# game/characters_events_idles/sonya_events.rpy:401
translate chinese sonya_scene4_morning_bathroom_1f146f5f:

    # Sonya "И не трогать?"
    Sonya "而且不碰？"

# game/characters_events_idles/sonya_events.rpy:416
translate chinese sonya_scene5_night_girlroom_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/characters_events_idles/sonya_events.rpy:418
translate chinese sonya_scene5_night_girlroom_f0ccb195:

    # Sonya "[povname] . . ."
    Sonya "[povname] . 。 。"

# game/characters_events_idles/sonya_events.rpy:422
translate chinese sonya_scene5_night_girlroom_f0ccb195_1:

    # Sonya "[povname] . . ."
    Sonya "[povname] . 。 。"

# game/characters_events_idles/sonya_events.rpy:425
translate chinese sonya_scene5_night_girlroom_6c32fa14:

    # gg "А что . . ."
    gg "还有什么。 。 。"

# game/characters_events_idles/sonya_events.rpy:427
translate chinese sonya_scene5_night_girlroom_b3aa243a:

    # Sonya "Прости"
    Sonya "对不起"

# game/characters_events_idles/sonya_events.rpy:428
translate chinese sonya_scene5_night_girlroom_4aff93e9:

    # Sonya "Я не хотела тебя резко будить"
    Sonya "我不是故意要突然叫醒你的"

# game/characters_events_idles/sonya_events.rpy:431
translate chinese sonya_scene5_night_girlroom_cbd4343b:

    # Sonya "Просто . . . не могу заснуть"
    Sonya "只是 。 。 。我睡不着"

# game/characters_events_idles/sonya_events.rpy:433
translate chinese sonya_scene5_night_girlroom_873c4360:

    # Sonya "Ты спишь так спокойно"
    Sonya "你睡得那么安详"

# game/characters_events_idles/sonya_events.rpy:435
translate chinese sonya_scene5_night_girlroom_988f1304:

    # Sonya "Посидишь со мной немного?"
    Sonya "你愿意陪我坐一会儿吗？"

# game/characters_events_idles/sonya_events.rpy:437
translate chinese sonya_scene5_night_girlroom_2970a146:

    # Sonya "Пока не отпустит"
    Sonya "直到他放手"

# game/characters_events_idles/sonya_events.rpy:439
translate chinese sonya_scene5_night_girlroom_a9b332b7:

    # gg "Ты устала?"
    gg "你累了吗？"

# game/characters_events_idles/sonya_events.rpy:441
translate chinese sonya_scene5_night_girlroom_0fb040eb:

    # Sonya "Нет,{w} не совсем"
    Sonya "不，{w} 不完全是"

# game/characters_events_idles/sonya_events.rpy:443
translate chinese sonya_scene5_night_girlroom_5527f93e:

    # Sonya "Просто думала"
    Sonya "我只是在想"

# game/characters_events_idles/sonya_events.rpy:446
translate chinese sonya_scene5_night_girlroom_72ba6d47:

    # gg "О чём?"
    gg "关于什么？"

# game/characters_events_idles/sonya_events.rpy:448
translate chinese sonya_scene5_night_girlroom_69179d28:

    # Sonya "Да не важно"
    Sonya "没关系"

# game/characters_events_idles/sonya_events.rpy:452
translate chinese sonya_scene5_night_girlroom_589ad1ec:

    # gg "Ты всё время так?"
    gg "你一直这样吗？"

# game/characters_events_idles/sonya_events.rpy:453
translate chinese sonya_scene5_night_girlroom_6f30ec91:

    # gg "Или бывает, что расслабляешься?"
    gg "或者你是否放松了？"

# game/characters_events_idles/sonya_events.rpy:455
translate chinese sonya_scene5_night_girlroom_fda29abb:

    # Sonya "Раньше было легче"
    Sonya "以前比较容易"

# game/characters_events_idles/sonya_events.rpy:457
translate chinese sonya_scene5_night_girlroom_1684e2b6:

    # Sonya "Просто я"
    Sonya "只有我"

# game/characters_events_idles/sonya_events.rpy:459
translate chinese sonya_scene5_night_girlroom_09ea6a66:

    # Sonya "Привыкла держать всё под контролем"
    Sonya "我习惯了一切都在掌控之中"

# game/characters_events_idles/sonya_events.rpy:462
translate chinese sonya_scene5_night_girlroom_27fc4b94:

    # Sonya "Ладно . . ."
    Sonya "好的 。 。 。"

# game/characters_events_idles/sonya_events.rpy:465
translate chinese sonya_scene5_night_girlroom_04a163be:

    # Sonya "Вот видишь"
    Sonya "你看"

# game/characters_events_idles/sonya_events.rpy:467
translate chinese sonya_scene5_night_girlroom_1825b5d8:

    # Sonya "Даже это нормально не могу"
    Sonya "我什至无法正常地做到这一点"

# game/characters_events_idles/sonya_events.rpy:473
translate chinese sonya_scene5_night_girlroom_4706c7d6:

    # Sonya "Давай просто полежим"
    Sonya "我们就躺着吧"

# game/characters_events_idles/sonya_events.rpy:475
translate chinese sonya_scene5_night_girlroom_dd04d853:

    # Sonya "Я не хочу думать сейчас"
    Sonya "我现在不想去想"

# game/characters_events_idles/sonya_events.rpy:493
translate chinese sonya_scene5_night_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "谢谢 。 。 。"

# game/characters_events_idles/sonya_events.rpy:495
translate chinese sonya_scene5_night_girlroom_7edcc3c4:

    # Sonya "Я давно так нормально не спала"
    Sonya "我已经很久没有睡得这么好了"

# game/characters_events_idles/sonya_events.rpy:503
translate chinese sonya_scene5_night_girlroom_a9d8faa5:

    # Sonya "Если Мая увидит нас, будет много вопросов"
    Sonya "如果玛雅看到我们，会有很多问题"

# game/characters_events_idles/sonya_events.rpy:505
translate chinese sonya_scene5_night_girlroom_2c86168e:

    # Sonya "Я сделаю тебе завтрак"
    Sonya "我给你做早餐"

# game/characters_events_idles/sonya_events.rpy:507
translate chinese sonya_scene5_night_girlroom_9663ea36:

    # Sonya "Он будет вкусным, не переживай"
    Sonya "一定会很好吃的，不用担心"

# game/characters_events_idles/sonya_events.rpy:525
translate chinese sonya_scene6_evening_myroom_1d152ede:

    # gg "Привет!"
    gg "你好！"

# game/characters_events_idles/sonya_events.rpy:527
translate chinese sonya_scene6_evening_myroom_4979c711:

    # Sonya "Эй, ты аниме смотришь?"
    Sonya "嘿嘿，你看动漫吗？"

# game/characters_events_idles/sonya_events.rpy:529
translate chinese sonya_scene6_evening_myroom_8dbdedb7:

    # Sonya "Тут только началось"
    Sonya "一切才刚刚开始"

# game/characters_events_idles/sonya_events.rpy:531
translate chinese sonya_scene6_evening_myroom_a94af5bd:

    # gg "Ага, почему бы и нет"
    gg "是啊，为什么不呢"

# game/characters_events_idles/sonya_events.rpy:538
translate chinese sonya_scene6_evening_myroom_4fa070d4:

    # gg "Забавно . . ."
    gg "很有趣。 。 。"

# game/characters_events_idles/sonya_events.rpy:540
translate chinese sonya_scene6_evening_myroom_2e5cd401:

    # extend "Теперь этот диван - моя кровать"
    extend "现在这张沙发是我的床"

# game/characters_events_idles/sonya_events.rpy:542
translate chinese sonya_scene6_evening_myroom_a3f8d8b5:

    # gg "Я привык на нём фильмы смотреть, а теперь ещё и сплю здесь"
    gg "习惯了在上面看电影，现在也睡在这里"

# game/characters_events_idles/sonya_events.rpy:543
translate chinese sonya_scene6_evening_myroom_8d9b5058:

    # Sonya "Вообще - то"
    Sonya "实际上"

# game/characters_events_idles/sonya_events.rpy:547
translate chinese sonya_scene6_evening_myroom_8bf7cd77:

    # extend " раньше это была моя кровать"
    extend "这曾经是我的床"

# game/characters_events_idles/sonya_events.rpy:549
translate chinese sonya_scene6_evening_myroom_4b9b63e3:

    # Sonya "До ухода Линды"
    Sonya "琳达离开前"

# game/characters_events_idles/sonya_events.rpy:551
translate chinese sonya_scene6_evening_myroom_2c51288e:

    # Sonya "А она тогда жила в моей комнатe"
    Sonya "然后她就住进了我的房间"

# game/characters_events_idles/sonya_events.rpy:553
translate chinese sonya_scene6_evening_myroom_3467de90:

    # gg "Серьёзно?"
    gg "严重地？"

# game/characters_events_idles/sonya_events.rpy:555
translate chinese sonya_scene6_evening_myroom_80955fa4:

    # Sonya "Да, но потом мы сделали ремонт, чтобы всё было по - нашему"
    Sonya "是的，但后来我们进行了翻新，以便一切都按照我们的方式进行"

# game/characters_events_idles/sonya_events.rpy:557
translate chinese sonya_scene6_evening_myroom_3d5a6534:

    # gg "Красиво получилось . . . {w}и дом где провел детство все еще чувствуется"
    gg "结果很漂亮。 。 。 {w}你度过童年的房子仍然让人感觉"

# game/characters_events_idles/sonya_events.rpy:562
translate chinese sonya_scene6_evening_myroom_0bab6ed7:

    # "Ты мог бы идти один. Я бы справилась"
    "你可以一个人去。我可以应付"

# game/characters_events_idles/sonya_events.rpy:564
translate chinese sonya_scene6_evening_myroom_e09cf293:

    # "Ты слишком спокоен. Обычно люди стараются понравиться"
    "你太冷静了。人们通常会试图取悦"

# game/characters_events_idles/sonya_events.rpy:566
translate chinese sonya_scene6_evening_myroom_93462049:

    # "А я не хочу «стараться». Хочу, чтобы ты узнала меня настоящего"
    "但我不想“尝试”。我想让你认识真实的我"

# game/characters_events_idles/sonya_events.rpy:568
translate chinese sonya_scene6_evening_myroom_25dcefcc:

    # "Знаешь, у меня есть и более интересные дела"
    "你知道，我还有更有趣的事情要做"

# game/characters_events_idles/sonya_events.rpy:570
translate chinese sonya_scene6_evening_myroom_fda89b59:

    # "Тогда почему ты всё ещё здесь?"
    "那你为什么还在这里？"

# game/characters_events_idles/sonya_events.rpy:573
translate chinese sonya_scene6_evening_myroom_7f029619:

    # Sonya "Вот смотри . . ."
    Sonya "看这里。 。 。"

# game/characters_events_idles/sonya_events.rpy:575
translate chinese sonya_scene6_evening_myroom_6f549ff9:

    # extend " она играет „недоступную“"
    extend "她扮演“难以接近”"

# game/characters_events_idles/sonya_events.rpy:577
translate chinese sonya_scene6_evening_myroom_beb1c184:

    # Sonya "Хотя видно, что сохнет по нему . . ."
    Sonya "虽然很明显上面已经干了。 。 。"

# game/characters_events_idles/sonya_events.rpy:580
translate chinese sonya_scene6_evening_myroom_766aa28c:

    # gg "Может, в этом и драма?"
    gg "也许这就是剧情？"

# game/characters_events_idles/sonya_events.rpy:582
translate chinese sonya_scene6_evening_myroom_ae35e350:

    # Sonya "Драма в том, что тянет резину"
    Sonya "剧情是拖拖拉拉的"

# game/characters_events_idles/sonya_events.rpy:584
translate chinese sonya_scene6_evening_myroom_70feb79f:

    # Sonya "Зачем, если всё ясно?"
    Sonya "如果一切都清楚了，为什么呢？"

# game/characters_events_idles/sonya_events.rpy:585
translate chinese sonya_scene6_evening_myroom_b291874f:

    # Sonya "{sc}Это раздражает{/sc}" with hpunch
    Sonya "{sc}这很烦人{/sc}" with hpunch

# game/characters_events_idles/sonya_events.rpy:587
translate chinese sonya_scene6_evening_myroom_6ef8cdd4:

    # gg "Ты бы решила быстрее?"
    gg "你会更快做出决定吗？"

# game/characters_events_idles/sonya_events.rpy:589
translate chinese sonya_scene6_evening_myroom_2db4fbf2:

    # Sonya "Намного быстрее . . ."
    Sonya "快得多。 。 。"

# game/characters_events_idles/sonya_events.rpy:591
translate chinese sonya_scene6_evening_myroom_c5704027:

    # Sonya "Скучное аниме"
    Sonya "无聊的动漫"

# game/characters_events_idles/sonya_events.rpy:593
translate chinese sonya_scene6_evening_myroom_9be82b23:

    # Sonya "Я не могу сидеть спокойно"
    Sonya "我坐不住了"

# game/characters_events_idles/sonya_events.rpy:595
translate chinese sonya_scene6_evening_myroom_13513f79:

    # gg "Тогда ложись, может, так будет легче"
    gg "然后躺下，也许会容易一些"

# game/characters_events_idles/sonya_events.rpy:597
translate chinese sonya_scene6_evening_myroom_0d9cdeae:

    # Sonya "Лечь говоришь?"
    Sonya "你说的是躺着吗？"

# game/characters_events_idles/sonya_events.rpy:605
translate chinese sonya_scene6_evening_myroom_448d2ea3:

    # Sonya "Да так спокойнее . . ."
    Sonya "心情平静多了。 。 。"

# game/characters_events_idles/sonya_events.rpy:610
translate chinese sonya_scene6_evening_myroom_75e70e12:

    # Sonya "{sc}Ах . . .{/sc}"
    Sonya "{sc}啊。 。 .{/sc}"

# game/characters_events_idles/sonya_events.rpy:613
translate chinese sonya_scene6_evening_myroom_376482db:

    # Sonya "Вот так . . ."
    Sonya "像这样 。 。 。"

# game/characters_events_idles/sonya_events.rpy:614
translate chinese sonya_scene6_evening_myroom_28a0cb64:

    # Sonya "Наконец - то"
    Sonya "最后"

# game/characters_events_idles/sonya_events.rpy:616
translate chinese sonya_scene6_evening_myroom_2157c7a2:

    # Sonya "Не бойся, мне нравится"
    Sonya "别害怕，我喜欢"

# game/characters_events_idles/sonya_events.rpy:619
translate chinese sonya_scene6_evening_myroom_e0c310ab:

    # Sonya "В ванной ты только смотрел"
    Sonya "你刚才在浴室里看了看"

# game/characters_events_idles/sonya_events.rpy:621
translate chinese sonya_scene6_evening_myroom_23073e11:

    # Sonya "Тут я тебе помогу"
    Sonya "在这里我会帮助你"

# game/characters_events_idles/sonya_events.rpy:623
translate chinese sonya_scene6_evening_myroom_77e32f3e:

    # Sonya "Я знаю, что ты хочешь"
    Sonya "我知道你想要什么"

# game/characters_events_idles/sonya_events.rpy:625
translate chinese sonya_scene6_evening_myroom_314984e9:

    # Sonya "Просто помогаю"
    Sonya "我只是帮忙"

# game/characters_events_idles/sonya_events.rpy:629
translate chinese sonya_scene6_evening_myroom_70da84e8:

    # Sonya "Мне приятно . . . {w}даже больше, чем я ожидала"
    Sonya "我很高兴。 。 。 {w}甚至超出我的预期"

# game/characters_events_idles/sonya_events.rpy:630
translate chinese sonya_scene6_evening_myroom_42733475:

    # gg "У тебя прекрасная грудь . . . {w}мягкая и тёплая"
    gg "你有美妙的乳房。 。 。 {w}柔软温暖"

# game/characters_events_idles/sonya_events.rpy:631
translate chinese sonya_scene6_evening_myroom_ae3a5ec7:

    # gg "Идеальная"
    gg "完美的"

# game/characters_events_idles/sonya_events.rpy:632
translate chinese sonya_scene6_evening_myroom_ec947a50:

    # Sonya "Хитрый . . ."
    Sonya "狡猾的。 。 。"

# game/characters_events_idles/sonya_events.rpy:633
translate chinese sonya_scene6_evening_myroom_9e059832:

    # Sonya "Знаешь ведь, что я краснею от таких слов"
    Sonya "你知道我因为这些话而脸红"

# game/characters_events_idles/sonya_events.rpy:635
translate chinese sonya_scene6_evening_myroom_9a2913c4:

    # Sonya "Но продолжай"
    Sonya "但继续"

# game/characters_events_idles/sonya_events.rpy:644
translate chinese sonya_scene6_evening_myroom_394ba447:

    # Maya "А что это вы тут . . ."
    Maya "你为什么在这里？ 。 。"

# game/characters_events_idles/sonya_events.rpy:646
translate chinese sonya_scene6_evening_myroom_f2d7a854:

    # Maya "В обнимку сидите?"
    Maya "你坐在怀抱里吗？"

# game/characters_events_idles/sonya_events.rpy:648
translate chinese sonya_scene6_evening_myroom_a3e76380:

    # Sonya "Аниме смотрим. {w}Но он скучный"
    Sonya "我们看动漫。 {w}但他很无聊"

# game/characters_events_idles/sonya_events.rpy:649
translate chinese sonya_scene6_evening_myroom_28afd6ea:

    # gg "Да, просто аниме"
    gg "是的，只是动漫"

# game/characters_events_idles/sonya_events.rpy:651
translate chinese sonya_scene6_evening_myroom_aa558823:

    # Maya "Не думайте что я этого не видела . . ."
    Maya "别以为我没看到这个。 。 。"

# game/characters_events_idles/sonya_events.rpy:654
translate chinese sonya_scene6_evening_myroom_eba4c233:

    # Sonya "Спасибо за вечер"
    Sonya "感谢晚上的陪伴"

# game/characters_events_idles/sonya_events.rpy:656
translate chinese sonya_scene6_evening_myroom_e7128efe:

    # Sonya "Было . . . {w} приятно"
    Sonya "曾是 。 。 。 {w}不错"

# game/characters_events_idles/sonya_events.rpy:660
translate chinese sonya_scene6_evening_myroom_222b7c49:

    # Sonya "Давай оставим аниме на завтра"
    Sonya "动画留到明天吧"

# game/characters_events_idles/sonya_events.rpy:661
translate chinese sonya_scene6_evening_myroom_be1b9cb9:

    # Sonya "Закончим на этом, а то я и сама не остановлюсь"
    Sonya "让我们结束这一切吧，否则我不会阻止自己。"

# game/characters_events_idles/sonya_events.rpy:663
translate chinese sonya_scene6_evening_myroom_b989363c:

    # gg ". . ."
    gg "。 。 。"

# game/characters_events_idles/sonya_events.rpy:678
translate chinese sonya_scene7_evening_girlroom_0262890b:

    # Sonya "Зайдёшь ко мне?"
    Sonya "你会来我家吗？"

# game/characters_events_idles/sonya_events.rpy:680
translate chinese sonya_scene7_evening_girlroom_cf65688b:

    # Sonya "Просто . . . {w}хочу поговорить "
    Sonya "只是 。 。 。 {w}我想谈谈"

# game/characters_events_idles/sonya_events.rpy:682
translate chinese sonya_scene7_evening_girlroom_0609085f:

    # gg "Конечно"
    gg "当然"

# game/characters_events_idles/sonya_events.rpy:684
translate chinese sonya_scene7_evening_girlroom_fe1b6c78:

    # gg "Ты какая-то задумчивая"
    gg "你有点心思缜密"

# game/characters_events_idles/sonya_events.rpy:686
translate chinese sonya_scene7_evening_girlroom_24fe6265:

    # Sonya "Да . . ."
    Sonya "是的。 。 。"

# game/characters_events_idles/sonya_events.rpy:688
translate chinese sonya_scene7_evening_girlroom_546a584b:

    # Sonya "Просто не могу всё выкинуть из головы"
    Sonya "我就是无法将这一切从我的脑海中抹去"

# game/characters_events_idles/sonya_events.rpy:690
translate chinese sonya_scene7_evening_girlroom_7ff0eaf1:

    # Sonya "Всё как-то закрутилось слишком быстро"
    Sonya "一切都开始旋转得太快"

# game/characters_events_idles/sonya_events.rpy:692
translate chinese sonya_scene7_evening_girlroom_fb1f6848:

    # gg "В каком смысле?"
    gg "从什么意义上说？"

# game/characters_events_idles/sonya_events.rpy:694
translate chinese sonya_scene7_evening_girlroom_b7dadb54:

    # Sonya "Ну . . . {w}обычно я держусь спокойно"
    Sonya "出色地 。 。 。 {w}我通常保持冷静"

# game/characters_events_idles/sonya_events.rpy:696
translate chinese sonya_scene7_evening_girlroom_8a221fed:

    # Sonya "Всё у меня под контролем"
    Sonya "一切尽在我掌控之中"

# game/characters_events_idles/sonya_events.rpy:698
translate chinese sonya_scene7_evening_girlroom_afb359d5:

    # Sonya "Но рядом с тобой . . . {w}всё иначе"
    Sonya "但在你旁边。 。 。 {w}一切都不同了"

# game/characters_events_idles/sonya_events.rpy:700
translate chinese sonya_scene7_evening_girlroom_486c8325:

    # gg "Иначе - это плохо?"
    gg "不然不好吗？"

# game/characters_events_idles/sonya_events.rpy:702
translate chinese sonya_scene7_evening_girlroom_6f2ad814:

    # Sonya "Иногда кажется, что я делаю глупости"
    Sonya "有时我觉得我在做一些愚蠢的事情"

# game/characters_events_idles/sonya_events.rpy:704
translate chinese sonya_scene7_evening_girlroom_b81ca64b:

    # Sonya "Такие . . . {w}нелепые"
    Sonya "这样的。 。 。 {w}荒谬"

# game/characters_events_idles/sonya_events.rpy:706
translate chinese sonya_scene7_evening_girlroom_716ea2d0:

    # Sonya "Будто я снова подросток"
    Sonya "我仿佛又回到了少年时代"

# game/characters_events_idles/sonya_events.rpy:708
translate chinese sonya_scene7_evening_girlroom_c3165439:

    # gg " . . ."
    gg "。 。 。"

# game/characters_events_idles/sonya_events.rpy:710
translate chinese sonya_scene7_evening_girlroom_43cc3ee5:

    # Sonya "Я не уверена в своём поведении"
    Sonya "我对自己的行为没有信心"

# game/characters_events_idles/sonya_events.rpy:711
translate chinese sonya_scene7_evening_girlroom_bf81f51b:

    # Sonya "Может, я слишком тороплюсь"
    Sonya "也许我太着急了"

# game/characters_events_idles/sonya_events.rpy:713
translate chinese sonya_scene7_evening_girlroom_7263e949:

    # Sonya "Может, выгляжу смешно"
    Sonya "也许我看起来很有趣"

# game/characters_events_idles/sonya_events.rpy:715
translate chinese sonya_scene7_evening_girlroom_5c74b5ea:

    # gg "Мне так не кажется"
    gg "我不这么认为"

# game/characters_events_idles/sonya_events.rpy:717
translate chinese sonya_scene7_evening_girlroom_9d42851b:

    # Sonya "А если вдруг?"
    Sonya "如果突然怎么办？"

# game/characters_events_idles/sonya_events.rpy:718
translate chinese sonya_scene7_evening_girlroom_6fb3c26c:

    # Sonya "Если я правда не такая, какой должна быть?"
    Sonya "如果我真的不是我应该成为的人怎么办？"

# game/characters_events_idles/sonya_events.rpy:720
translate chinese sonya_scene7_evening_girlroom_5c8cc88c:

    # Sonya "Ты всё равно примешь меня?"
    Sonya "你还会接受我吗？"

# game/characters_events_idles/sonya_events.rpy:727
translate chinese sonya_scene7_evening_girlroom_ca1ff0ec:

    # gg "Мне нравишься настоящая ты"
    gg "我喜欢真实的你"

# game/characters_events_idles/sonya_events.rpy:730
translate chinese sonya_scene7_evening_girlroom_495fe1ef:

    # gg "Мне не нужно, чтобы ты была какой-то другой"
    gg "我不需要你成为其他任何人"

# game/characters_events_idles/sonya_events.rpy:746
translate chinese sonya_scene7_evening_girlroom_df7e877e:

    # Sonya "Спасибо . . ."
    Sonya "谢谢 。 。 。"

# game/characters_events_idles/sonya_events.rpy:747
translate chinese sonya_scene7_evening_girlroom_860f4d16:

    # Sonya "Это именно то что я хотела"
    Sonya "这正是我想要的"

# game/characters_events_idles/sonya_events.rpy:753
translate chinese sonya_scene7_evening_girlroom_489479bc:

    # Sonya "{sc}Да . . . Так . . .{/sc}"
    Sonya "{sc}是的。 。 。所以 。 。 .{/sc}"

# game/characters_events_idles/sonya_events.rpy:759
translate chinese sonya_scene7_evening_girlroom_2d94ee37:

    # Sonya "На диване ты меня трогал"
    Sonya "沙发上你触碰了我"

# game/characters_events_idles/sonya_events.rpy:760
translate chinese sonya_scene7_evening_girlroom_fc982615:

    # Sonya "Теперь - моя очередь"
    Sonya "现在轮到我了"

# game/characters_events_idles/sonya_events.rpy:767
translate chinese sonya_scene7_evening_girlroom_7b973257:

    # Sonya "Смотри на меня"
    Sonya "看着我"

# game/characters_events_idles/sonya_events.rpy:775
translate chinese sonya_scene7_evening_girlroom_1b8740c5:

    # Sonya "Всё - ты теперь мой!"
    Sonya "就是这样——你现在是我的了！"

# game/characters_events_idles/sonya_events.rpy:783
translate chinese sonya_scene7_evening_girlroom_2da445da:

    # Sonya "Подожди тут"
    Sonya "在这里等一下"

# game/characters_events_idles/sonya_events.rpy:785
translate chinese sonya_scene7_evening_girlroom_250fe814:

    # Sonya "Я быстро"
    Sonya "我很快"

# game/characters_events_idles/sonya_events.rpy:791
translate chinese sonya_scene7_evening_girlroom_dadabf98:

    # gg_chat "Это случилось так быстро . . . "
    gg_chat "事情发生得太快了。 。 。"

# game/characters_events_idles/sonya_events.rpy:798
translate chinese sonya_scene7_evening_girlroom_e844ad84:

    # Sonya "Останься"
    Sonya "停留"

# game/characters_events_idles/sonya_events.rpy:800
translate chinese sonya_scene7_evening_girlroom_1d2efc6a:

    # Sonya "Посиди со мной"
    Sonya "和我坐在一起"

# game/characters_events_idles/sonya_events.rpy:802
translate chinese sonya_scene7_evening_girlroom_b435d332:

    # Sonya "И посмотрим, куда это нас приведёт."
    Sonya "让我们看看这会将我们带向何方。"

# game/characters_events_idles/sonya_events.rpy:805
translate chinese sonya_scene7_evening_girlroom_ca91d43d:

    # gg_chat "Было тепло"
    gg_chat "天气很暖和"

# game/characters_events_idles/sonya_events.rpy:806
translate chinese sonya_scene7_evening_girlroom_899d5485:

    # gg_chat "Я хотел остаться рядом"
    gg_chat "我想靠近"

translate chinese strings:

    # game/characters_events_idles/sonya_events.rpy:516
    old "Утро"
    new "早晨"

    # game/characters_events_idles/sonya_events.rpy:608
    old "Играешь со мной?"
    new "你在玩我吗？"

    # game/characters_events_idles/sonya_events.rpy:618
    old "Мне так хорошо"
    new "我感觉很好"

    # game/characters_events_idles/sonya_events.rpy:725
    old "Такой ты и нужна"
    new "这就是你被需要的方式"

    # game/characters_events_idles/sonya_events.rpy:734
    old "Поцеловать"
    new "吻"

# TODO: Translation updated at 2026-01-27 02:10

# game/characters_events_idles/sonya_events.rpy:20
translate chinese sonya_scene1_morning_kitchen_c92bc08a:

    # Sonya "Там диван, конечно, старый"
    Sonya "当然，那里有一张旧沙发。"

# game/characters_events_idles/sonya_events.rpy:50
translate chinese sonya_scene1_morning_kitchen_12302e27:

    # Sonya "У нас, обычно, никто особо не спрашивает"
    Sonya "通常没有人问我们太多"

# game/characters_events_idles/sonya_events.rpy:161
translate chinese sonya_scene2_day_girlroom_9c553288:

    # Sonya "Так и планировал . . ."
    Sonya "这就是我的计划。 。 。"

# game/characters_events_idles/sonya_events.rpy:177
translate chinese sonya_scene2_day_girlroom_c5761118:

    # Sonya "Ты, получается, больше утренний человек?"
    Sonya "你是一个比较喜欢早起的人吗？"

# game/characters_events_idles/sonya_events.rpy:335
translate chinese sonya_scene3_day_bathroom_21f8234f:

    # Sonya "Горячий, аккуратнее"
    Sonya "热，要小心"

# game/characters_events_idles/sonya_events.rpy:383
translate chinese sonya_scene4_morning_bathroom_0d2b005c:

    # gg "Да, где-то я уже такое видел"
    gg "是的，我以前在某处见过这个"

# game/characters_events_idles/sonya_events.rpy:385
translate chinese sonya_scene4_morning_bathroom_11b14ed3:

    # Sonya "Ты смотришь . . ."
    Sonya "你正在寻找。 。 。"

# game/characters_events_idles/sonya_events.rpy:486
translate chinese sonya_scene5_night_girlroom_44967887:

    # Sonya "Я не хочу ни о чем думать . . ."
    Sonya "我什么都不想想。 。 。"

# game/characters_events_idles/sonya_events.rpy:835
translate chinese sonya_scene8_morning_kitchen_a482bb49:

    # gg "Утречка"
    gg "早安"

# game/characters_events_idles/sonya_events.rpy:837
translate chinese sonya_scene8_morning_kitchen_ce42d6cf:

    # Sonya "Доброе утро . . ."
    Sonya "早安 . . ."

# game/characters_events_idles/sonya_events.rpy:839
translate chinese sonya_scene8_morning_kitchen_72c13c11:

    # Sonya "Я . . . почти закончила готовить, садись"
    Sonya "我 . . . 快做完了，坐下吧"

# game/characters_events_idles/sonya_events.rpy:842
translate chinese sonya_scene8_morning_kitchen_bb1eb7c8:

    # gg "Ты рано встала"
    gg "你起得真早"

# game/characters_events_idles/sonya_events.rpy:844
translate chinese sonya_scene8_morning_kitchen_42ef4d92:

    # Sonya "Не спалось"
    Sonya "睡不着"

# game/characters_events_idles/sonya_events.rpy:846
translate chinese sonya_scene8_morning_kitchen_a756dcde:

    # Sonya "Подумала . . ."
    Sonya "我在想 . . ."

# game/characters_events_idles/sonya_events.rpy:848
translate chinese sonya_scene8_morning_kitchen_381d05fd:

    # Sonya "Раз ты всё равно проснёшься . . ."
    Sonya "既然你反正会醒 . . ."

# game/characters_events_idles/sonya_events.rpy:850
translate chinese sonya_scene8_morning_kitchen_13f1fe10:

    # Sonya "Будет хорошо, заранее приготовить тебе"
    Sonya "早点给你准备好，会比较好"

# game/characters_events_idles/sonya_events.rpy:861
translate chinese sonya_scene8_morning_kitchen_c3201521:

    # Sonya "Можно?"
    Sonya "可以吗?"

# game/characters_events_idles/sonya_events.rpy:865
translate chinese sonya_scene8_morning_kitchen_0609085f:

    # gg "Конечно"
    gg "当然"

# game/characters_events_idles/sonya_events.rpy:870
translate chinese sonya_scene8_morning_kitchen_f49db0d9:

    # gg "Очень вкусно"
    gg "很好吃"

# game/characters_events_idles/sonya_events.rpy:872
translate chinese sonya_scene8_morning_kitchen_6f15bff0:

    # Sonya "Я рада"
    Sonya "我很高兴"

# game/characters_events_idles/sonya_events.rpy:874
translate chinese sonya_scene8_morning_kitchen_8bd5d020:

    # Sonya "Мне важно, чтобы тебе было хорошо"
    Sonya "我希望你过得好"

# game/characters_events_idles/sonya_events.rpy:882
translate chinese sonya_scene8_morning_kitchen_41dbce33:

    # Sonya "Я всю ночь думала . . ."
    Sonya "我整晚都在想 . . ."

# game/characters_events_idles/sonya_events.rpy:885
translate chinese sonya_scene8_morning_kitchen_f519c6fc:

    # Sonya "Раньше я беспокоилась"
    Sonya "以前我很担心"

# game/characters_events_idles/sonya_events.rpy:887
translate chinese sonya_scene8_morning_kitchen_b0e09a72:

    # Sonya "А сегодня . . ."
    Sonya "但是今天 . . ."

# game/characters_events_idles/sonya_events.rpy:889
translate chinese sonya_scene8_morning_kitchen_814991c8:

    # Sonya "Мне спокойно"
    Sonya "我很平静"

# game/characters_events_idles/sonya_events.rpy:898
translate chinese sonya_scene8_morning_kitchen_d0794f94:

    # Sonya "Если ты не против . . ."
    Sonya "如果你不介意 . . ."

# game/characters_events_idles/sonya_events.rpy:900
translate chinese sonya_scene8_morning_kitchen_9c748c84:

    # Sonya "Я могу . . ."
    Sonya "我可以 . . ."

# game/characters_events_idles/sonya_events.rpy:904
translate chinese sonya_scene8_morning_kitchen_a877578e:

    # Sonya "Быть чуть ближе"
    Sonya "靠得更近一点"

# game/characters_events_idles/sonya_events.rpy:926
translate chinese sonya_scene8_morning_kitchen_1b7d05a8:

    # Sonya "Чувствовать, как ты становишься твёрже . . ."
    Sonya "感受你变得更坚硬 . . ."

# game/characters_events_idles/sonya_events.rpy:927
translate chinese sonya_scene8_morning_kitchen_b85aacb1:

    # Sonya "От моего прикосновения . . . {w}это так . . ."
    Sonya "我的触摸 . . . {w}就是这样 . . ."

# game/characters_events_idles/sonya_events.rpy:928
translate chinese sonya_scene8_morning_kitchen_9213f2a8:

    # Sonya ". . . Заводит. {w}Сильнее, чем я думала"
    Sonya ". . . 让我兴奋。 {w}比我想象的还要强烈"

# game/characters_events_idles/sonya_events.rpy:929
translate chinese sonya_scene8_morning_kitchen_9bc062d5:

    # Sonya "Смотри на меня . . . только на меня . . ."
    Sonya "看着我 . . . 只看着我 . . ."

# game/characters_events_idles/sonya_events.rpy:940
translate chinese sonya_scene8_morning_kitchen_55a277bb:

    # Sonya "Я . . . не знаю, как правильно это сказать . . ."
    Sonya "我 . . . 不知道该怎么正确地说 . . ."

# game/characters_events_idles/sonya_events.rpy:942
translate chinese sonya_scene8_morning_kitchen_beb08d03:

    # Sonya "Но мне хорошо, когда ты рядом"
    Sonya "但我喜欢你在我身边"


# game/characters_events_idles/sonya_events.rpy:961
translate chinese sonya_scene9_night_myroom_9a8b0be2:

    # gg "Привет"
    gg "你好"

# game/characters_events_idles/sonya_events.rpy:963
translate chinese sonya_scene9_night_myroom_b3a2b8a1:

    # Sonya "Привет ты ещё не ложишься?"
    Sonya "你好，你还不准备睡觉吗？"

# game/characters_events_idles/sonya_events.rpy:965
translate chinese sonya_scene9_night_myroom_bb3c3085:

    # Sonya "Тогда пойдём вместе в ванную?"
    Sonya "那我们一起去洗澡吗？"

# game/characters_events_idles/sonya_events.rpy:967
translate chinese sonya_scene9_night_myroom_9afefc8e:

    # Sonya "Я хочу голову помыть . . ."
    Sonya "我想洗头 . . ."

# game/characters_events_idles/sonya_events.rpy:969
translate chinese sonya_scene9_night_myroom_b4639877:

    # Sonya "И тебе тоже"
    Sonya "你也要洗"

# game/characters_events_idles/sonya_events.rpy:971
translate chinese sonya_scene9_night_myroom_66416cc5:

    # gg "Ну пойдем"
    gg "那我们走吧"

# game/characters_events_idles/sonya_events.rpy:981
translate chinese sonya_scene9_night_myroom_c5d3f2b1:

    # Sonya "Ты тоже раздевайся давай"
    Sonya "你也脱衣服吧"

# game/characters_events_idles/sonya_events.rpy:987
translate chinese sonya_scene9_night_myroom_ebd2cc14:

    # Sonya "Подожди . . ."
    Sonya "等一下 . . ."

# game/characters_events_idles/sonya_events.rpy:989
translate chinese sonya_scene9_night_myroom_abb56970:

    # Sonya "У тебя молния заела"
    Sonya "你的拉链卡住了"

# game/characters_events_idles/sonya_events.rpy:996
translate chinese sonya_scene9_night_myroom_3672b0c0:

    # Sonya "Быстро ты . . ."
    Sonya "你真快 . . ."

# game/characters_events_idles/sonya_events.rpy:998
translate chinese sonya_scene9_night_myroom_ba83a14c:

    # Sonya "Давай садись"
    Sonya "坐下吧"

# game/characters_events_idles/sonya_events.rpy:1000
translate chinese sonya_scene9_night_myroom_674bc70f:

    # Sonya "Стой . . . не двигайся"
    Sonya "停下 . . . 别动"

# game/characters_events_idles/sonya_events.rpy:1002
translate chinese sonya_scene9_night_myroom_dc365125:

    # Sonya "Я хочу сама"
    Sonya "我自己来"

# game/characters_events_idles/sonya_events.rpy:1006
translate chinese sonya_scene9_night_myroom_9c274529:

    # gg "У меня отличный вид"
    gg "我有很好的视野"

# game/characters_events_idles/sonya_events.rpy:1008
translate chinese sonya_scene9_night_myroom_4af82ab0:

    # Sonya "Я знаю"
    Sonya "我知道"

# game/characters_events_idles/sonya_events.rpy:1010
translate chinese sonya_scene9_night_myroom_d339691d:

    # Sonya "Мне просто приятно, что ты смотришь"
    Sonya "我很喜欢你看着我"

# game/characters_events_idles/sonya_events.rpy:1012
translate chinese sonya_scene9_night_myroom_98944675:

    # Sonya "Теперь ты меня"
    Sonya "现在你拥有我"

# game/characters_events_idles/sonya_events.rpy:1016
translate chinese sonya_scene9_night_myroom_06da4938:

    # Sonya "Ты точно будешь пахнуть как я"
    Sonya "你一定会像我一样闻起来"

# game/characters_events_idles/sonya_events.rpy:1018
translate chinese sonya_scene9_night_myroom_aa254d79:

    # Sonya "Ты такой тёплый сейчас . . . мне это нравится"
    Sonya "你现在好温暖 . . . 我喜欢这样"

# game/characters_events_idles/sonya_events.rpy:1020
translate chinese sonya_scene9_night_myroom_908db179:

    # Sonya "Пойдём спать вместе"
    Sonya "我们一起睡吧"

# game/characters_events_idles/sonya_events.rpy:1022
translate chinese sonya_scene9_night_myroom_e190b45e:

    # Sonya "Я не хочу сегодня одна"
    Sonya "我今天不想一个人"

# game/characters_events_idles/sonya_events.rpy:1024
translate chinese sonya_scene9_night_myroom_dd09f522:

    # Sonya "Но на сегодня приключений хватит . . . а то я завтра вообще не проснусь"
    Sonya "今天的冒险够了 . . . 否则我明天根本起不来"

# game/characters_events_idles/sonya_events.rpy:1031
translate chinese sonya_scene9_night_myroom_654cb5b3:

    # Sonya "Спокойной ночи"
    Sonya "晚安"

# game/characters_events_idles/sonya_events.rpy:1032
translate chinese sonya_scene9_night_myroom_5e65cbb1:

    # Sonya "{bt=a3-p2.0-s3.0}Любимый"
    Sonya "{bt=a3-p2.0-s3.0}亲爱的"

# game/characters_events_idles/sonya_events.rpy:1038
translate chinese sonya_scene9_night_myroom_7f924e87:

    # gg "Спокойной"
    gg "晚安"

# game/characters_events_idles/sonya_events.rpy:1039
translate chinese sonya_scene9_night_myroom_02749544:

    # gg "Я правда рад, что я с тобой"
    gg "我真的很高兴和你在一起"


