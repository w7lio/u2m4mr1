﻿# TODO: Translation updated at 2026-01-21 02:05

translate chinese strings:

    # game/screens.rpy:427
    old "Назад"
    new "后退"

    # game/screens.rpy:429
    old "Пропуск"
    new "经过"

    # game/screens.rpy:430
    old "Авто"
    new "汽车"

    # game/screens.rpy:431
    old "Сохранить"
    new "节省"

    # game/screens.rpy:432
    old "Б.Сохр"
    new "B.保存"

    # game/screens.rpy:433
    old "Б.Загр"
    new "扎格"

    # game/screens.rpy:434
    old "Настройки"
    new "设置"

    # game/screens.rpy:583
    old "НОВАЯ ИГРА"
    new "新游戏"

    # game/screens.rpy:584
    old "ЗАГРУЗИТЬ"
    new "下载"

    # game/screens.rpy:585
    old "НАСТРОЙКИ"
    new "设置"

    # game/screens.rpy:586
    old "О ИГРЕ"
    new "关于游戏"

    # game/screens.rpy:593
    old "ИСТОРИЯ"
    new "故事"

    # game/screens.rpy:594
    old "СОХРАНИТЬ"
    new "节省"

    # game/screens.rpy:599
    old "ЗАВЕРШИТЬ ПОВТОР"
    new "结束重复"

    # game/screens.rpy:601
    old "МЕНЮ"
    new "菜单"

    # game/screens.rpy:606
    old "ВЫХОД"
    new "出口"

    # game/screens.rpy:758
    old "Вернуться"
    new "返回"

    # game/screens.rpy:912
    old "Версия [config.version!t]\n"
    new "版本[config.version!t]\n"

    # game/screens.rpy:951
    old "{} страница"
    new "{}页"

    # game/screens.rpy:951
    old "Автосохранения"
    new "自动保存"

    # game/screens.rpy:951
    old "Быстрые сохранения"
    new "快速保存"

    # game/screens.rpy:999
    old "{#file_time}%A, %d %B %Y, %H:%M"
    new "{#file_time}%A、%d %B %Y、%H:%M"

    # game/screens.rpy:999
    old "Пустой слот"
    new "空槽"

    # game/screens.rpy:1020
    old "<"
    new "<"

    # game/screens.rpy:1024
    old "{#auto_page}А"
    new "{#auto_page}A"

    # game/screens.rpy:1027
    old "{#quick_page}Б"
    new "{#quick_page}B"

    # game/screens.rpy:1033
    old ">"
    new ">"

    # game/screens.rpy:1105
    old "Всего текста"
    new "总文本"

    # game/screens.rpy:1106
    old "После выборов"
    new "选举后"

    # game/screens.rpy:1112
    old "Режим экрана"
    new "屏幕模式"

    # game/screens.rpy:1113
    old "Оконный"
    new "窗户"

    # game/screens.rpy:1114
    old "Полный"
    new "满的"

    # game/screens.rpy:1118
    old "Язык"
    new "语言"

    # game/screens.rpy:1151
    old "Скорость текста"
    new "文字速度"

    # game/screens.rpy:1155
    old "Скорость авточтения"
    new "自动读取速度"

    # game/screens.rpy:1159
    old "Прозрачность окна"
    new "窗口透明度"

    # game/screens.rpy:1165
    old "Громкость музыки"
    new "音乐音量"

    # game/screens.rpy:1172
    old "Громкость звуков"
    new "音量"

    # game/screens.rpy:1178
    old "Тест"
    new "测试"

    # game/screens.rpy:1182
    old "Громкость голоса"
    new "语音音量"

    # game/screens.rpy:1193
    old "Без звука"
    new "没有声音"

    # game/screens.rpy:1378
    old "История диалогов пуста."
    new "对话历史记录为空。"

    # game/screens.rpy:1621
    old "Ты правда хочешь выйти"
    new "你真的想出去吗"

    # game/screens.rpy:1628
    old "Да"
    new "是的"

    # game/screens.rpy:1632
    old "Нет"
    new "不"

    # game/screens.rpy:1686
    old "Пропускаю"
    new "我正在跳过"

    # game/screens.rpy:1997
    old "Меню"
    new "菜单"

    # game/screens.rpy:2362
    old "д"
    new "d"

    # game/screens.rpy:2488
    old "Персонажи"
    new "人物"

    # game/screens.rpy:2608
    old "Подсказка"
    new "线索"

    # game/screens.rpy:2627
    old "Отслеживать квест"
    new "追踪任务"

    # game/screens.rpy:2636
    old "Перестать отслеживать"
    new "停止追踪"

    # game/screens.rpy:2657
    old "Продвигайтесь по сюжету"
    new "故事的进展"

# TODO: Translation updated at 2026-01-27 02:10

translate chinese strings:

    # game/screens.rpy:574
    old "ИГРАЙ РАНЬШЕ ДРУГИХ"
    new "在其他人之前玩"

# TODO: Translation updated at 2026-01-27 02:18

translate chinese strings:

    # game/screens.rpy:602
    old "Бесплатные девлоги"
    new "免费开发博客"

