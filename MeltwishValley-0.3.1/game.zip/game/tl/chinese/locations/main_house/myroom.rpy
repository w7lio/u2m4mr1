﻿# TODO: Translation updated at 2026-01-21 02:05

# game/locations/main_house/myroom.rpy:22
translate chinese myroom_c1835e38:

    # "Что бы лечь спать нажмите ночью на кровать"
    "晚上睡觉时按一下床"

# game/locations/main_house/myroom.rpy:27
translate chinese myroom_edb2c466:

    # "Теперь вы можешь управлять временем суток"
    "现在您可以控制一天中的时间"

# game/locations/main_house/myroom.rpy:28
translate chinese myroom_1cd5975b:

    # "Нажмите на значок в правом верхнем углу, чтобы изменить время"
    "点击右上角的图标可以更改时间"

# game/locations/main_house/myroom.rpy:30
translate chinese myroom_2f1c23a7:

    # "В левом нижнем углу отображаются текущее время суток, день недели и счётчик дней"
    "左下角显示当前时间、星期几和日计数器"

# game/locations/main_house/myroom.rpy:33
translate chinese myroom_4dcc1b35:

    # "Теперь вам доступна книга персонажей"
    "人物书现已提供给您"

# game/locations/main_house/myroom.rpy:36
translate chinese myroom_f5a7354e:

    # "В ней вы можете посмотреть описание каждой девушки и текущий уровень отношений"
    "在其中你可以看到每个女孩的描述以及当前的关系级别"

# game/locations/main_house/myroom.rpy:37
translate chinese myroom_b927df5c:

    # "Здесь же доступны подсказки к следующему событию и возможность закрепить активный квест"
    "此处还提供了下一个事件的提示以及固定活动任务的功能。"

# TODO: Translation updated at 2026-01-26 03:22

# game/locations/main_house/myroom.rpy:27
translate chinese myroom_71fb3107:

    # "Теперь вы можете управлять временем суток"
    "现在您可以控制一天中的时间"

# game/locations/main_house/myroom.rpy:28
translate chinese myroom_a6aee4e7:

    # "Нажмите на значок в правом верхнем углу, чтобы сменить время"
    "点击右上角的图标可以更改时间"

# game/locations/main_house/myroom.rpy:33
translate chinese myroom_b9554520:

    # "Также вам доступна книга персонажей"
    "还有一本人物书给你"

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/myroom.rpy:27
translate chinese myroom_ac4e4f25:

    # "Теперь ты можешь управлять временем суток"
    "现在您可以控制一天中的时间"

# game/locations/main_house/myroom.rpy:28
translate chinese myroom_6784fea3:

    # "Нажми на значок в правом верхнем углу, чтобы сменить время"
    "点击右上角的图标可以更改时间"

# game/locations/main_house/myroom.rpy:33
translate chinese myroom_b3480ee4:

    # "Также тебе доступна книга персонажей"
    "还提供给您一本人物书"

# game/locations/main_house/myroom.rpy:36
translate chinese myroom_030a80cc:

    # "В ней ты можешь посмотреть описание каждой девушки и текущий уровень отношений"
    "在其中你可以看到每个女孩的描述以及当前的关系级别"

