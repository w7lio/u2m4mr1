﻿# TODO: Translation updated at 2026-01-21 02:05

# game/locations/main_house/bathroom.rpy:18
translate chinese bathroom_3da38f85:

    # gg "Я думаю я не так сильно знаком с Маей"
    gg "我想我不太了解玛雅"

# game/locations/main_house/bathroom.rpy:23
translate chinese bathroom_1dae98de:

    # gg "Я думаю я не так сильно знаком с Соней"
    gg "我想我不太了解索尼娅"

# TODO: Translation updated at 2026-01-26 03:22

# game/locations/main_house/bathroom.rpy:19
translate chinese bathroom_8df379f4:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Маей"
    gg "我想我对 Maya 还不够了解。"

# game/locations/main_house/bathroom.rpy:25
translate chinese bathroom_675eb9d2:

    # gg "Наверное, я ещё недостаточно хорошо знаком с Соней"
    gg "我想我还不太了解索尼娅。"

