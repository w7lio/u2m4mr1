﻿# TODO: Translation updated at 2026-01-21 02:05

# game/locations/main_house/kitchen.rpy:24
translate chinese kitchen_e44eab80:

    # "Привет, перед началом игры давай быстро разберемся с управлением"
    "您好，在开始游戏之前，我们先来快速了解一下操作"

# game/locations/main_house/kitchen.rpy:25
translate chinese kitchen_e9ff8856:

    # "Что бы перейти в другую комнату тебе нужно навестись мышкой в правую часть экрана"
    "要进入另一个房间，您需要将鼠标指向屏幕右侧"

# game/locations/main_house/kitchen.rpy:28
translate chinese kitchen_22e95808:

    # "После выбери комнату в которую хочешь попасть"
    "然后选择你想去的房间"

# game/locations/main_house/kitchen.rpy:29
translate chinese kitchen_c3e67100:

    # "На иконках комнат будут отображены девушки которые сейчас там находятся"
    "房间图标将显示当前在那里的女孩"

# game/locations/main_house/kitchen.rpy:30
translate chinese kitchen_ffc31834:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой ключевое действие"
    "如果女孩执行了关键操作，图标旁边会出现一个{color=#fffb27ff}星星{/color}"

# game/locations/main_house/kitchen.rpy:31
translate chinese kitchen_4c3bfaea:

    # "Попробуйте перейти в комнату Маи"
    "尝试去麦的房间"

# TODO: Translation updated at 2026-01-27 02:10

# game/locations/main_house/kitchen.rpy:30
translate chinese kitchen_b2963125:

    # "Рядом с иконкой появится {color=#fffb27ff}звездочка{/color}, если с девушкой доступно ключевое действие"
    "如果女孩可以执行关键操作，图标旁边会出现一个{color=#fffb27ff}星号{/color}"

# game/locations/main_house/kitchen.rpy:31
translate chinese kitchen_b1f7eb9e:

    # "Попробуй перейти в комнату Маи"
    "尝试去麦的房间"

