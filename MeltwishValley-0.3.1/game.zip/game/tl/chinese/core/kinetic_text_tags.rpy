﻿# TODO: Translation updated at 2026-01-21 02:05

# game/core/kinetic_text_tags.rpy:1
translate chinese 6c0c3176:

    # "Kinetic Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    "动力学文本标签 Ren'Py 模块 2021 Daniel Westfall <SoDaRa2595@gmail.com>"

# game/core/kinetic_text_tags.rpy:1
translate chinese 8689f4cd:

    # "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"
    "http://twitter.com/sodara9 如果您最终使用它，我将不胜感激！ :D 知道我帮助了一些人，我真的很开心！真的希望这可以帮助社区创造一些非常巧妙的方式来增加他们的对话！ http://opensource.org/licenses/mit-license.php Github：https://github.com/SoDaRa/Kinetic-Text-Tags itch.io：https://wattson.itch.io/kinetic-text-tags 论坛帖子： https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"

