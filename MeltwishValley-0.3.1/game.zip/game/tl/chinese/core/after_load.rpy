﻿# TODO: Translation updated at 2026-01-21 02:05

translate chinese strings:

    # game/core/after_load.rpy:9
    old "Спокойный и наблюдательный, он приехал в посёлок, чтобы сбежать от прошлого и найти себя заново. Не всегда уверен, но с каждым новым знакомством делает шаг ближе к тому, кем хочет стать"
    new "冷静而敏锐的他来到这个村庄，是为了逃离过去，重新找回自己。并不总是确定，但每结识一个新人，他就离自己想成为的人更近了一步"

    # game/core/after_load.rpy:9
    old "Союзник"
    new "盟友"

    # game/core/after_load.rpy:9
    old "Вс."
    new "太阳。"

    # game/core/after_load.rpy:9
    old "Кухня"
    new "厨房"

    # game/core/after_load.rpy:9
    old "Утро Кухня"
    new "早晨厨房"

    # game/core/after_load.rpy:9
    old "Ждем тебя в следующем патче"
    new "我们在下一个补丁中等你"

    # game/core/after_load.rpy:9
    old "Вы прошли все сюжетные события этого персонажа в текущем патче"
    new "已完成当前补丁中该角色的所有故事事件"

    # game/core/after_load.rpy:9
    old "Мая"
    new "可能"

    # game/core/after_load.rpy:9
    old "Дерзкая, ироничная и ленивая, кажется отстранённой, но чувствует глубже, чем показывает. Скрывает мягкость за сарказмом, пока не решит открыть себя по-настоящему. Не терпит слабости — особенно в себе"
    new "她傲慢、讽刺、懒惰，看似冷漠，但她的感受比她表现出来的更深刻。在讽刺背后隐藏温柔，直到他决定真正暴露自己。不能容忍弱点——尤其是他自己"

    # game/core/after_load.rpy:9
    old "Вт."
    new "星期二"

    # game/core/after_load.rpy:9
    old "Ср."
    new "周三。"

    # game/core/after_load.rpy:9
    old "Вечер"
    new "晚上"

    # game/core/after_load.rpy:9
    old "Зал"
    new "大厅"

    # game/core/after_load.rpy:9
    old "Вечер Зал"
    new "晚厅"

    # game/core/after_load.rpy:9
    old "Пт."
    new "周五。"

    # game/core/after_load.rpy:9
    old "Сб."
    new "星期六。"

    # game/core/after_load.rpy:9
    old "День"
    new "天"

    # game/core/after_load.rpy:9
    old "Ее комната"
    new "她的房间"

    # game/core/after_load.rpy:9
    old "День Ее комната"
    new "白天她的房间"

    # game/core/after_load.rpy:9
    old "Пн."
    new "周一。"

    # game/core/after_load.rpy:9
    old "Чт."
    new "周四。"

    # game/core/after_load.rpy:9
    old "Вечер кухня"
    new "晚上厨房"

    # game/core/after_load.rpy:9
    old "День ее комната"
    new "那天她的房间"

    # game/core/after_load.rpy:9
    old "Ночь"
    new "夜晚"

    # game/core/after_load.rpy:9
    old "Ночь ее комната"
    new "晚上她的房间"

    # game/core/after_load.rpy:9
    old "Вечер зал"
    new "晚间大厅"

    # game/core/after_load.rpy:9
    old "Утро ее комната"
    new "早上她的房间"

    # game/core/after_load.rpy:9
    old "День кухня"
    new "厨房日"

    # game/core/after_load.rpy:9
    old "Ванная"
    new "浴室"

    # game/core/after_load.rpy:9
    old "Утро ванная"
    new "早上卫生间"

    # game/core/after_load.rpy:9
    old "Соня"
    new "索尼娅"

    # game/core/after_load.rpy:9
    old "Тёплая и заботливая, но собранная и точная, как часы. Любит музыку, игры и порядок, иногда стесняется — но именно она делает шаг первой"
    new "热情、关怀，但又沉着、精确，就像时钟一样。她热爱音乐、游戏和秩序，有时她很害羞——但她是迈出第一步的人"

    # game/core/after_load.rpy:9
    old "День Ванная"
    new "日间沐浴"

    # game/core/after_load.rpy:9
    old "Утро Ванная"
    new "早晨浴室"

    # game/core/after_load.rpy:9
    old "Стоит подождать"
    new "值得等待"

    # game/core/after_load.rpy:9
    old "Думаю стоит подождать"
    new "我认为等待是值得的"

    # game/core/after_load.rpy:9
    old "Вечер Ее комната"
    new "晚上 她的房间"

    # game/core/after_load.rpy:9
    old "Кейт"
    new "凯特"

    # game/core/after_load.rpy:9
    old "Яркая и энергичная, Кейт не умеет сидеть на месте — она живёт движением и смехом. Кажется лёгкой и беззаботной, но за её улыбкой прячется страх остаться одной"
    new "凯特聪明、精力充沛，不知道如何安静地坐着——她靠运动和笑声生活。她看似轻松无忧，笑容背后却隐藏着对孤独的恐惧"

    # game/core/after_load.rpy:9
    old "Утро Зал"
    new "晨堂"

# TODO: Translation updated at 2026-01-26 03:22

# game/core/after_load.rpy:4
translate chinese after_load_f281aeec:

    # "Привет. Игра потерпела большой реворк, получила новое интро и сцены"
    "你好。游戏进行了重大修改，获得了新的介绍和场景"

# game/core/after_load.rpy:5
translate chinese after_load_92feb703:

    # "Старые сейвы работать не будут(("
    "旧的保存将不起作用(("

# game/core/after_load.rpy:6
translate chinese after_load_dc6483bb:

    # "Пожалуйста начните игру заново"
    "请重新开始游戏"

# TODO: Translation updated at 2026-01-27 02:10

# game/core/after_load.rpy:4
translate chinese after_load_75a05417:

    # "Привет. Игра претерпела большие изменения, получила новое интро и сцены"
    "你好。游戏发生了很大的变化，获得了新的简介和场景"

# game/core/after_load.rpy:6
translate chinese after_load_c7ff0b32:

    # "Пожалуйста, начните игру заново"
    "请重新开始游戏"

# TODO: Translation updated at 2026-01-27 22:54

translate chinese strings:

    # game/core/after_load.rpy:13
    old "День Зал"
    new "日间大厅"

