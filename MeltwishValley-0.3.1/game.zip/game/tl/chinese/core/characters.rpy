﻿# TODO: Translation updated at 2026-01-21 02:05

translate chinese strings:

    # game/core/characters.rpy:28
    old "Почтальон"
    new "邮差"

    # game/core/characters.rpy:32
    old "Секретарь"
    new "秘书"

    # game/core/characters.rpy:36
    old "Директор"
    new "导演"

    # game/core/characters.rpy:40
    old "Незнакомая девушка"
    new "陌生女孩"

# TODO: Translation updated at 2026-01-26 03:22

translate chinese strings:

    # game/core/characters.rpy:40
    old "Незнакомка"
    new "陌生人"

