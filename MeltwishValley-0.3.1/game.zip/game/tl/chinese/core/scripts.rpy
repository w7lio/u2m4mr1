﻿# TODO: Translation updated at 2026-01-21 02:05

# game/core/scripts.rpy:52
translate chinese next_time_button_9cf59ffc:

    # "Пора спать"
    "是时候睡觉了"

# game/core/scripts.rpy:97
translate chinese sleep_until_morning_caa36b56:

    # "Думаю еще не время ложиться спать"
    "我认为还没到睡觉的时间"

