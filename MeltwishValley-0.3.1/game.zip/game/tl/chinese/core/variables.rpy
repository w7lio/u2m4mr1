﻿# TODO: Translation updated at 2026-01-21 02:05

translate chinese strings:

    # game/core/variables.rpy:88
    old "Понедельник"
    new "周一"

    # game/core/variables.rpy:88
    old "Вторник"
    new "周二"

    # game/core/variables.rpy:88
    old "Среда"
    new "周三"

    # game/core/variables.rpy:88
    old "Четверг"
    new "周四"

    # game/core/variables.rpy:88
    old "Пятница"
    new "星期五"

    # game/core/variables.rpy:88
    old "Суббота"
    new "周六"

    # game/core/variables.rpy:88
    old "Воскресенье"
    new "星期日"

    # game/core/variables.rpy:121
    old "Моя комната"
    new "我的房间"

# TODO: Translation updated at 2026-02-13 11:40

translate chinese strings:

    # game/core/variables.rpy:422
    old "Ночь Зал"
    new "夜厅"

# TODO: Translation updated at 2026-02-16 03:29

translate chinese strings:

    # game/core/variables.rpy:427
    old "Комната Сони"
    new "索尼的房间"

# game/core/variables.rpy:427
    old "Утро комната Сони"
    new "早晨，索尼的房间"

# game/core/variables.rpy:427
    old "День зал"
    new "日间大厅"

