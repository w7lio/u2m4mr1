﻿

translate chinese strings:

    # game/special_events/halloween 2025.rpy:8
    old "Сначала"
    new "起初"

    # game/special_events/halloween 2025.rpy:10
    old "Сон с Соней"
    new "和索尼娅一起睡觉"

    # game/special_events/halloween 2025.rpy:14
    old "Сон с Маей"
    new "和玛雅一起睡觉"

# TODO: Translation updated at 2026-01-26 03:22

# game/special_events/halloween 2025.rpy:28
translate chinese halloween_prestart_6dc15a83:

    # gg "Хм . . ."
    gg "嗯。 。 。"

# game/special_events/halloween 2025.rpy:29
translate chinese halloween_prestart_3173d374:

    # gg "А что это еще такое?"
    gg "这还有什么？"

# game/special_events/halloween 2025.rpy:30
translate chinese halloween_prestart_9d6bd7cd:

    # gg "Эта тыква будто манит меня дотронуться до нее"
    gg "这个南瓜似乎在召唤我去触摸它。"

# game/special_events/halloween 2025.rpy:32
translate chinese halloween_prestart_6b235c12:

    # gg "Вроде ничего не случилось"
    gg "好像什么都没发生"

# game/special_events/halloween 2025.rpy:33
translate chinese halloween_prestart_99b702cc:

    # gg "Просто обычная тыква"
    gg "只是一个普通的南瓜"

# game/special_events/halloween 2025.rpy:34
translate chinese halloween_prestart_882ef6af:

    # gg "Так не интересно"
    gg "所以没兴趣"

# game/special_events/halloween 2025.rpy:38
translate chinese halloween_prestart_2eb26325:

    # gg "Ай!" with hpunch
    gg "哎呀！" with hpunch

# game/special_events/halloween 2025.rpy:39
translate chinese halloween_prestart_b858f49b:

    # gg "Почему так щипет"
    gg "为什么这么刺痛？"

# game/special_events/halloween 2025.rpy:40
translate chinese halloween_prestart_eb8d9b68:

    # gg "Что то мне не хорошо"
    gg "有些事对我不好"

# game/special_events/halloween 2025.rpy:41
translate chinese halloween_prestart_462beaf3:

    # gg "Пойду отдохну"
    gg "我去休息一下"

# game/special_events/halloween 2025.rpy:50
translate chinese halloween_start_941a30ef:

    # Sonya "[povname]"
    Sonya "[povname]"

# game/special_events/halloween 2025.rpy:52
translate chinese halloween_start_2768572c:

    # Sonya "Знаешь, что я поняла?"
    Sonya "你知道我意识到了什么吗？"

# game/special_events/halloween 2025.rpy:53
translate chinese halloween_start_b99b94d3:

    # gg "Что пора поспать?"
    gg "是时候睡觉了吗？"

# game/special_events/halloween 2025.rpy:55
translate chinese halloween_start_73751dc8:

    # Sonya "Что пора украшать дом"
    Sonya "是时候装饰房子了"

# game/special_events/halloween 2025.rpy:57
translate chinese halloween_start_2efbd354:

    # gg "Украшать?"
    gg "装饰？"

# game/special_events/halloween 2025.rpy:59
translate chinese halloween_start_baa9dc02:

    # Sonya "У нас через 2 дня Хэллоуин, а атмосферы - ноль"
    Sonya "还有两天就是万圣节了，气氛却为零"

# game/special_events/halloween 2025.rpy:61
translate chinese halloween_start_d64dca0a:

    # Sonya "Я хочу, чтобы всё выглядело"
    Sonya "我想让一切看起来"

# game/special_events/halloween 2025.rpy:63
translate chinese halloween_start_c1524153:

    # Sonya "Хотя бы немного празднично"
    Sonya "至少有点节日气氛"

# game/special_events/halloween 2025.rpy:65
translate chinese halloween_start_c4c69fc7:

    # Maya "Украшать?{w} Пора бы да"
    Maya "装饰一下？{w}时间到了"

# game/special_events/halloween 2025.rpy:67
translate chinese halloween_start_f5a85bf6:

    # Maya "Можно повесить гирлянды и поставить свечи!"
    Maya "您可以挂花环并点燃蜡烛！"

# game/special_events/halloween 2025.rpy:69
translate chinese halloween_start_88ab11a7:

    # Sonya "Вот. Поддержка есть"
    Sonya "这里。有支持"

# game/special_events/halloween 2025.rpy:71
translate chinese halloween_start_f2b19d78:

    # gg "Видимо у меня нет выбора"
    gg "显然我别无选择"

# game/special_events/halloween 2025.rpy:73
translate chinese halloween_start_bc7a61df:

    # Maya "Ты просто устал, тебе нужно отвлечься"
    Maya "你只是累了，你需要分散注意力"

# game/special_events/halloween 2025.rpy:75
translate chinese halloween_start_06d0d58b:

    # Sonya "Вот именно"
    Sonya "就是这样"

# game/special_events/halloween 2025.rpy:77
translate chinese halloween_start_041234b8:

    # Sonya "Украшение дома - лучший антистресс"
    Sonya "家居装修是最好的抗压剂"

# game/special_events/halloween 2025.rpy:79
translate chinese halloween_start_c578bb24:

    # Maya "Тогда решено"
    Maya "然后就决定了"

# game/special_events/halloween 2025.rpy:80
translate chinese halloween_start_6e15e900:

    # Maya "Начнём с гостиной"
    Maya "我们先从客厅开始"

# game/special_events/halloween 2025.rpy:82
translate chinese halloween_start_d298f1fa:

    # Maya "Я за уют, но без перебора"
    Maya "我追求舒适，但又不过分"

# game/special_events/halloween 2025.rpy:84
translate chinese halloween_start_2a522c28:

    # Sonya "Надо позвать Кейт"
    Sonya "我们需要给凯特打电话"

# game/special_events/halloween 2025.rpy:85
translate chinese halloween_start_20197ce8:

    # Sonya "Без неё всё равно не обойдётся"
    Sonya "没有她仍然行不通"

# game/special_events/halloween 2025.rpy:87
translate chinese halloween_start_bcecc811:

    # Maya "Я напишу ей"
    Maya "我会写信给她"

# game/special_events/halloween 2025.rpy:88
translate chinese halloween_start_81baf5ad:

    # Maya "Если не занята, придёт"
    Maya "如果她不忙的话她就会来"

# game/special_events/halloween 2025.rpy:90
translate chinese halloween_start_4a4b3e1e:

    # Sonya "Пойдем поможешь мне"
    Sonya "来帮我吧"

# game/special_events/halloween 2025.rpy:92
translate chinese halloween_start_082fbdc3:

    # Sonya "У нас в кладовке чего только нету"
    Sonya "我们的食品储藏室里什么都有"

# game/special_events/halloween 2025.rpy:94
translate chinese halloween_start_569f8605:

    # Sonya "Осторожно, она тяжёлая"
    Sonya "小心点，很重"

# game/special_events/halloween 2025.rpy:98
translate chinese halloween_start_08a41431:

    # gg "Не волнуйся, я пока справляюсь"
    gg "别担心，我现在可以应对"

# game/special_events/halloween 2025.rpy:100
translate chinese halloween_start_2ee9b67e:

    # Maya "Написала, сказала, что уже бежит"
    Maya "她写信说她已经在跑步了"

# game/special_events/halloween 2025.rpy:102
translate chinese halloween_start_56e25c3d:

    # Sonya "Это хорошо"
    Sonya "这很好"

# game/special_events/halloween 2025.rpy:104
translate chinese halloween_start_cc205380:

    # Maya "О, смотри, старая паутина!"
    Maya "哦，看，老蜘蛛网！"

# game/special_events/halloween 2025.rpy:106
translate chinese halloween_start_6d122aa8:

    # Sonya "Это не декор, не трогай!"
    Sonya "这不是装饰品，请勿触摸！"

# game/special_events/halloween 2025.rpy:108
translate chinese halloween_start_1c832081:

    # Maya "Ты же знаешь я боюсь пауков!"
    Maya "你知道我害怕蜘蛛！"

# game/special_events/halloween 2025.rpy:109
translate chinese halloween_start_e8c9fd97:

    # gg "Ха ха"
    gg "哈哈"

# game/special_events/halloween 2025.rpy:114
translate chinese halloween_start_5c8cb7fa:

    # Kate "Я пришла"
    Kate "我来了"

# game/special_events/halloween 2025.rpy:115
translate chinese halloween_start_5cba982d:

    # Kate "Где вы, мои маленькие смертные?"
    Kate "我的小凡人，你们在哪里？"

# game/special_events/halloween 2025.rpy:116
translate chinese halloween_start_66671892:

    # Maya "Привет!"
    Maya "你好！"

# game/special_events/halloween 2025.rpy:118
translate chinese halloween_start_41cac97b:

    # Kate "О, вы уже начали без меня?{w} Это предательство"
    Kate "哦，没有我你就已经开始了吗？{w}这是背叛"

# game/special_events/halloween 2025.rpy:120
translate chinese halloween_start_3f833e29:

    # Maya "Мы только подготовились"
    Maya "我们刚刚准备好"

# game/special_events/halloween 2025.rpy:122
translate chinese halloween_start_10a24600:

    # Sonya "Отлично, теперь можем начинать по-настоящему"
    Sonya "太好了，现在我们可以真正开始了"

# game/special_events/halloween 2025.rpy:124
translate chinese halloween_start_59716300:

    # Maya "Всё, распределяем задачи?"
    Maya "就这样吧，我们来分配一下任务吧？"

# game/special_events/halloween 2025.rpy:126
translate chinese halloween_start_c6287aa3:

    # Kate "Так эту куклу повесим вон там, над теликом"
    Kate "所以我们把这个娃娃挂在电视上方。"

# game/special_events/halloween 2025.rpy:127
translate chinese halloween_start_ddd8aded:

    # Kate "Еще нужны паутины, гирлянда из флажков, черепа . . ."
    Kate "我们还需要蜘蛛网、旗帜花环和头骨。 。 。"

# game/special_events/halloween 2025.rpy:129
translate chinese halloween_start_c1c2f306:

    # Maya "Тогда в моей комнате обойдемся без жутких украшений?"
    Maya "那么我的房间里可以不用令人毛骨悚然的装饰品吗？"

# game/special_events/halloween 2025.rpy:131
translate chinese halloween_start_344d78c3:

    # gg "Ну это же Хэллоуин, а чем ты?"
    gg "嗯，万圣节到了，你在做什么呢？"

# game/special_events/halloween 2025.rpy:133
translate chinese halloween_start_7e9f8506:

    # Sonya "Мая просто трусишка"
    Sonya "玛雅只是个胆小鬼"

# game/special_events/halloween 2025.rpy:135
translate chinese halloween_start_423eeb13:

    # Maya "ЭЙ!! Просто я считаю это глупым!"
    Maya "嘿！！我只是觉得这很愚蠢！"

# game/special_events/halloween 2025.rpy:136
translate chinese halloween_start_1c4935b1:

    # Maya "Можно сделать дом тёплым, как осень!"
    Maya "你可以让你的家变得像秋天一样温暖！"

# game/special_events/halloween 2025.rpy:137
translate chinese halloween_start_5acb8aac:

    # Maya "Листья и природу . . . И без жути . . ."
    Maya "叶子和自然。 。 。而且没有恐怖。 。 。"

# game/special_events/halloween 2025.rpy:139
translate chinese halloween_start_9d95e4f7:

    # Kate "А я хочу, чтобы было так жууутко, что соседские дети визжали от страха если посмеют постучаться в нашу дверь"
    Kate "我希望事情变得如此糟糕，以至于邻居的孩子如果敢敲我们的门，就会害怕地尖叫"

# game/special_events/halloween 2025.rpy:141
translate chinese halloween_start_97fa9b09:

    # Sonya "Звучит как цель"
    Sonya "听起来像是一个目标"

# game/special_events/halloween 2025.rpy:143
translate chinese halloween_start_7a0152d7:

    # Maya "Надеюсь, что все пройдет без происшествий"
    Maya "我希望一切顺利"

# game/special_events/halloween 2025.rpy:145
translate chinese halloween_start_cd410fe4:

    # gg "Ну что же, давайте постараемся"
    gg "好吧，让我们尝试一下"

# game/special_events/halloween 2025.rpy:153
translate chinese halloween_start_e7148dd7:

    # Maya "А знаете, не так уж и плохо, очень даже мило и уютно"
    Maya "你知道，这并没有那么糟糕，甚至非常美好和舒适"

# game/special_events/halloween 2025.rpy:155
translate chinese halloween_start_4203fcb3:

    # Kate "ДА! Вышло супер, мы такие молодцы"
    Kate "是的！结果太棒了，我们太棒了"

# game/special_events/halloween 2025.rpy:157
translate chinese halloween_start_3c177eb8:

    # Sonya "Давайте дальше украсим кухню!"
    Sonya "接下来我们来装饰一下厨房吧！"

# game/special_events/halloween 2025.rpy:158
translate chinese halloween_start_3fc97c96:

    # Sonya "[povname] хватай коробки с украшениями!"
    Sonya "[povname] 抢装饰盒！"

# game/special_events/halloween 2025.rpy:167
translate chinese halloween_start_c18a0daf:

    # Maya "Ну почему я должна ее вешать?"
    Maya "我为什么要把它挂起来？"

# game/special_events/halloween 2025.rpy:169
translate chinese halloween_start_538416e3:

    # Kate "Потому что ты самая высокая, это же логично!"
    Kate "因为你最高，这是合乎逻辑的！"

# game/special_events/halloween 2025.rpy:171
translate chinese halloween_start_fac78089:

    # Maya "Фууу. Я не боюсь пауков, просто они такие гадкие, мне противно от них"
    Maya "呃。我不怕蜘蛛，只是它们太讨厌了，让我恶心"

# game/special_events/halloween 2025.rpy:173
translate chinese halloween_start_196b4d6a:

    # gg "Тыкву тоже поставь на полку"
    gg "把南瓜也放到架子上"

# game/special_events/halloween 2025.rpy:182
translate chinese halloween_start_3ee05b57:

    # Maya "АААААААААА!" with hpunch
    Maya "啊啊啊啊啊啊！" with hpunch

# game/special_events/halloween 2025.rpy:186
translate chinese halloween_start_7410244b:

    # gg "Все, я убрал, не бойся, он же не настоящий"
    gg "就是这样，我把它删除了，别害怕，他不是真的"

# game/special_events/halloween 2025.rpy:188
translate chinese halloween_start_1ceba70d:

    # Maya "Спасибо"
    Maya "谢谢"

# game/special_events/halloween 2025.rpy:190
translate chinese halloween_start_5375f0ad:

    # gg "Слишком часто ты падаешь в мои объятия, а не специально ли ты это делаешь?"
    gg "你太多次投入我的怀抱，但这不是你故意的吗？"

# game/special_events/halloween 2025.rpy:192
translate chinese halloween_start_ccd7999c:

    # Maya "Еще чего!"
    Maya "还有什么！"

# game/special_events/halloween 2025.rpy:193
translate chinese halloween_start_c938832e:

    # Maya "Ты просто мешаешься на пути, вот и все!"
    Maya "你只是妨碍了你，仅此而已！"

# game/special_events/halloween 2025.rpy:194
translate chinese halloween_start_5807bf69:

    # Kate "Не поранились? Голубки"
    Kate "你没受伤吗？鸽子"

# game/special_events/halloween 2025.rpy:196
translate chinese halloween_start_180bf5f1:

    # Maya "Все с паутиной мы закончили"
    Maya "我们已经完成了网络"

# game/special_events/halloween 2025.rpy:197
translate chinese halloween_start_62eaed17:

    # Maya "Пойду возьму яблочного сидра"
    Maya "我去买点苹果酒"

# game/special_events/halloween 2025.rpy:203
translate chinese halloween_start_6a9d122d:

    # Sonya "Еще 5 минут и кексы готовы"
    Sonya "再过5分钟，纸杯蛋糕就准备好了"

# game/special_events/halloween 2025.rpy:205
translate chinese halloween_start_92462f90:

    # Kate "Пахнет потрясающе"
    Kate "闻起来很香"

# game/special_events/halloween 2025.rpy:207
translate chinese halloween_start_ada25b4b:

    # Maya "Всё, теперь осталось только подождать"
    Maya "就是这样，现在你所要做的就是等待"

# game/special_events/halloween 2025.rpy:208
translate chinese halloween_start_4ac68531:

    # Maya "Потом будем украшать"
    Maya "然后我们来装饰一下"

# game/special_events/halloween 2025.rpy:210
translate chinese halloween_start_7d203e0d:

    # Kate "Эй а кем вы будете в ночь Хэллоуина?"
    Kate "嘿，万圣节之夜你会扮演谁？"

# game/special_events/halloween 2025.rpy:212
translate chinese halloween_start_3e0fd7f3:

    # Sonya "Я уже думала об этом!"
    Sonya "我已经考虑过这个问题了！"

# game/special_events/halloween 2025.rpy:213
translate chinese halloween_start_21be6b25:

    # Sonya "Мм, Кейт тебе бы подошел костюм демонессы"
    Sonya "嗯，凯特，恶魔服装很适合你"

# game/special_events/halloween 2025.rpy:215
translate chinese halloween_start_8fc9e335:

    # Maya "Кстати да, хоть ты и выглядишь как ангелок, но ты коварная как домовёнок"
    Maya "顺便说一句，是的，虽然你看起来像天使，但你却像布朗尼一样狡猾"

# game/special_events/halloween 2025.rpy:217
translate chinese halloween_start_6485ec70:

    # Kate "Эй!! Неплохая идея"
    Kate "嘿！！不错的主意"

# game/special_events/halloween 2025.rpy:221
translate chinese halloween_start_9ea771a0:

    # Kate "Королева демонов Уахахахаха!"
    Kate "恶魔女王哇哈哈哈哈！"

# game/special_events/halloween 2025.rpy:222
translate chinese halloween_start_dfa5392d:

    # Kate "Все должны пасть к моим ногам!"
    Kate "所有人都必须拜倒在我的脚下！"

# game/special_events/halloween 2025.rpy:224
translate chinese halloween_start_d1a70744:

    # Sonya "Все, ей больше не наливать!"
    Sonya "就这样了，别再泼她了！"

# game/special_events/halloween 2025.rpy:226
translate chinese halloween_start_67a78ead:

    # gg "Не знал что Кейт так быстро выносит с алкоголя"
    gg "我不知道凯特戒酒这么快"

# game/special_events/halloween 2025.rpy:228
translate chinese halloween_start_89e99062:

    # Maya "Я бы хотела костюм ведьмочки или какой-нибудь волшебной дриады . . ."
    Maya "我想要一套女巫服装或某种魔法树妖。 。 。"

# game/special_events/halloween 2025.rpy:230
translate chinese halloween_start_ccfee06e:

    # Kate "Думаю тебе пойдет"
    Kate "我认为它会适合你"

# game/special_events/halloween 2025.rpy:232
translate chinese halloween_start_8e96eaa2:

    # Sonya "А я заказала на днях вместо 1 пачки бинта, целых 6, похоже это знак делать костюм мумии?"
    Sonya "而前几天我点的不是1包绷带，而是6包之多，看来这是制作木乃伊服装的标志？"

# game/special_events/halloween 2025.rpy:234
translate chinese halloween_start_2aa5e0fb:

    # Maya "Ты как раз самая старшая"
    Maya "你只是最年长的"

# game/special_events/halloween 2025.rpy:236
translate chinese halloween_start_38bc2712:

    # Sonya "Ах ты!"
    Sonya "哦你！"

# game/special_events/halloween 2025.rpy:238
translate chinese halloween_start_5d38e441:

    # Maya "Стоп, а как же барсик? Ему тоже нужен костюм!"
    Maya "等等，獾呢？他也需要一套西装！"

# game/special_events/halloween 2025.rpy:239
translate chinese halloween_start_fb608953:

    # Maya "Например дракончика или мистер тыковка . . ."
    Maya "比如小龙或者南瓜先生。 。 。"

# game/special_events/halloween 2025.rpy:241
translate chinese halloween_start_7fd69d94:

    # Sonya "Попробуй поймать и нарядить, мистер Барсик не дастся!"
    Sonya "尝试抓住它并打扮它，巴尔西克先生不会成功！"

# game/special_events/halloween 2025.rpy:243
translate chinese halloween_start_70adb582:

    # Maya "Что ты . . . {w}Он любит переодевашки"
    Maya "你什么。 。 。 {w}他喜欢打扮"

# game/special_events/halloween 2025.rpy:246
translate chinese halloween_start_c0036cba:

    # Sonya "Вот и кексы готовы"
    Sonya "现在纸杯蛋糕已经准备好了"

# game/special_events/halloween 2025.rpy:248
translate chinese halloween_start_ae45c746:

    # gg "С кухней готово, что дальше?"
    gg "厨房已经准备好了，接下来做什么？"

# game/special_events/halloween 2025.rpy:249
translate chinese halloween_start_354f0704:

    # Sonya "Предлагаю разделиться"
    Sonya "我建议我们分手"

# game/special_events/halloween 2025.rpy:250
translate chinese halloween_start_07a07420:

    # Sonya "Мы с Маей украсим наши комнаты, Кейт, украсишь ванну"
    Sonya "玛雅和我将装饰我们的房间，凯特，你可以装饰浴室吗"

# game/special_events/halloween 2025.rpy:251
translate chinese halloween_start_4e86ac78:

    # Sonya "[povname], будешь помогать нам?"
    Sonya "[povname]，你愿意帮助我们吗？"

# game/special_events/halloween 2025.rpy:252
translate chinese halloween_start_564e6225:

    # gg "Окей"
    gg "好的"

# game/special_events/halloween 2025.rpy:263
translate chinese halloween_prepare_mayaroom_7afc2c47:

    # gg "У тебя тут прям логово ведьмы которая варит зелья из трав"
    gg "这里有一个女巫的巢穴，她用草药酿造药剂"

# game/special_events/halloween 2025.rpy:264
translate chinese halloween_prepare_mayaroom_63c64e7b:

    # gg "Мм. . . пахнет приятно"
    gg "毫米。 。 。闻起来很香"

# game/special_events/halloween 2025.rpy:266
translate chinese halloween_prepare_mayaroom_1ca099b7:

    # Maya "Хватит нюхать женскую комнату!"
    Maya "别再嗅女厕所了！"

# game/special_events/halloween 2025.rpy:268
translate chinese halloween_prepare_mayaroom_eded9518:

    # Maya "Ты здесь нужен только исполнять мои приказы"
    Maya "你来这里只是为了执行我的命令。"

# game/special_events/halloween 2025.rpy:269
translate chinese halloween_prepare_mayaroom_799aa249:

    # Maya "Поставь эти тыквы в тот угол!"
    Maya "把那些南瓜放在那个角落里！"

# game/special_events/halloween 2025.rpy:271
translate chinese halloween_prepare_mayaroom_292858b8:

    # gg "А где пожалуйста?"
    gg "请问哪里？"

# game/special_events/halloween 2025.rpy:273
translate chinese halloween_prepare_mayaroom_ad71fbb0:

    # Maya "Пожалуйста, не беси меня"
    Maya "请别惹我生气"

# game/special_events/halloween 2025.rpy:275
translate chinese halloween_prepare_mayaroom_63b60e81:

    # gg "Ох"
    gg "哦"

# game/special_events/halloween 2025.rpy:277
translate chinese halloween_prepare_mayaroom_977c102e:

    # Maya "Мм. . . нет!"
    Maya "毫米。 。 。不！"

# game/special_events/halloween 2025.rpy:279
translate chinese halloween_prepare_mayaroom_9cb8ca98:

    # Maya "Выглядит недостаточно хорошо!"
    Maya "看起来不够好！"

# game/special_events/halloween 2025.rpy:281
translate chinese halloween_prepare_mayaroom_3b7bbda5:

    # Maya "Давай лучше в тот угол!"
    Maya "我们最好去那个角落吧！"

# game/special_events/halloween 2025.rpy:283
translate chinese halloween_prepare_mayaroom_f714e642:

    # gg "Давай ты сначала решишь точно куда, чтоб я не таскал сто раз эти тыквы"
    gg "我们先决定一下具体在哪里，免得我把这些南瓜搬一百遍"

# game/special_events/halloween 2025.rpy:285
translate chinese halloween_prepare_mayaroom_a2933c08:

    # Maya "Говорю же туда неси!"
    Maya "我告诉你，把它带到那里！"

# game/special_events/halloween 2025.rpy:287
translate chinese halloween_prepare_mayaroom_4c580716:

    # gg "Точно?"
    gg "确切地？"

# game/special_events/halloween 2025.rpy:288
translate chinese halloween_prepare_mayaroom_fccb4de7:

    # gg "Я больше двигать не буду, подумай хорошо"
    gg "我不会再动了，好好想想"

# game/special_events/halloween 2025.rpy:290
translate chinese halloween_prepare_mayaroom_4aa933c6:

    # Maya "Хотя как сейчас тоже неплохо . . ."
    Maya "虽然现在这样也不错。 。 。"

# game/special_events/halloween 2025.rpy:292
translate chinese halloween_prepare_mayaroom_b2b57087:

    # Maya "Все ты свободен!"
    Maya "你们都自由了！"

# game/special_events/halloween 2025.rpy:294
translate chinese halloween_prepare_mayaroom_04c6c53d:

    # gg "Спасибо"
    gg "谢谢"

# game/special_events/halloween 2025.rpy:295
translate chinese halloween_prepare_mayaroom_dad56d9b:

    # Maya "Если что еще позову"
    Maya "如果还有什么事情我会打电话"

# game/special_events/halloween 2025.rpy:297
translate chinese halloween_prepare_mayaroom_6a8ac153:

    # Maya "Все Давай, давай, живее!!"
    Maya "大家加油，加油，加油！！"

# game/special_events/halloween 2025.rpy:310
translate chinese halloween_prepare_sonyaroom_b708d644:

    # Sonya "Ой" with hpunch
    Sonya "哦" with hpunch

# game/special_events/halloween 2025.rpy:312
translate chinese halloween_prepare_sonyaroom_4b100306:

    # Sonya "Добро пожаловать в мою обитель!"
    Sonya "欢迎来到我的住所！"

# game/special_events/halloween 2025.rpy:314
translate chinese halloween_prepare_sonyaroom_7fb491df:

    # gg "У тебя в стиле майнкрафта все, очень милая комната"
    gg "一切都是我的世界风格，非常漂亮的房间"

# game/special_events/halloween 2025.rpy:316
translate chinese halloween_prepare_sonyaroom_9dc8d94c:

    # Sonya "Да, у меня много игрушек осталось"
    Sonya "是的，我还剩下很多玩具"

# game/special_events/halloween 2025.rpy:317
translate chinese halloween_prepare_sonyaroom_1174b034:

    # gg "Чем то тебе помочь?"
    gg "我怎么帮你？"

# game/special_events/halloween 2025.rpy:319
translate chinese halloween_prepare_sonyaroom_36233e2b:

    # Sonya "О можешь пожалуйста разложить остальные блоки"
    Sonya "哦，你能把剩下的块布置出来吗？"

# game/special_events/halloween 2025.rpy:321
translate chinese halloween_prepare_sonyaroom_51e25d01:

    # gg "Хорошо давай"
    gg "好吧，来吧"

# game/special_events/halloween 2025.rpy:325
translate chinese halloween_prepare_sonyaroom_5b80a77c:

    # Sonya "Так это сюда"
    Sonya "所以就在这里"

# game/special_events/halloween 2025.rpy:331
translate chinese halloween_prepare_sonyaroom_5e22d509:

    # Sonya "О забыла я же еще кексов поставила"
    Sonya "哦，我忘了，我还放了一些纸杯蛋糕"

# game/special_events/halloween 2025.rpy:340
translate chinese halloween_prepare_bathroom_5d6a2459:

    # gg "Тук-Тук, к вам можно?"
    gg "敲敲门，我可以去找你吗？"

# game/special_events/halloween 2025.rpy:342
translate chinese halloween_prepare_bathroom_f77e9ebe:

    # Kate "О, ты вовремя, как раз хотела тебя позвать, хочу призрака повесить над ванной"
    Kate "哦，你来得正是时候，我正要打电话给你，我想在浴室上方挂一个鬼魂"

# game/special_events/halloween 2025.rpy:343
translate chinese halloween_prepare_bathroom_65af0236:

    # Kate "Но не достаю, вот"
    Kate "但我看不到，就在这里"

# game/special_events/halloween 2025.rpy:345
translate chinese halloween_prepare_bathroom_b38aeb93:

    # Kate "Вот, видишь?"
    Kate "看到这里了吗？"

# game/special_events/halloween 2025.rpy:347
translate chinese halloween_prepare_bathroom_e0f0e638:

    # Kate "Хм . . . а если я встану на бортики ванной?"
    Kate "嗯。 。 。如果我站在浴缸的两侧怎么办？"

# game/special_events/halloween 2025.rpy:349
translate chinese halloween_prepare_bathroom_e11f6927:

    # gg "Стой, это не безопасно"
    gg "等等，这不安全"

# game/special_events/halloween 2025.rpy:358
translate chinese halloween_prepare_bathroom_01550c8f:

    # Kate "ААй!" with hpunch
    Kate "啊啊！" with hpunch

# game/special_events/halloween 2025.rpy:359
translate chinese halloween_prepare_bathroom_af26ae75:

    # Kate "Ох, я слишком пьяна, как хорошо что ты был рядом, спасибо"
    Kate "哦，我喝醉了，有你在真是太好了，谢谢"

# game/special_events/halloween 2025.rpy:361
translate chinese halloween_prepare_bathroom_78e2854b:

    # gg "Я так испугался за тебя"
    gg "我很为你害怕"

# game/special_events/halloween 2025.rpy:362
translate chinese halloween_prepare_bathroom_766703c6:

    # gg "За тобой глаз, да глаз, будь аккуратнее"
    gg "有一只眼睛在看着你，是的，有一只眼睛在看着你，小心点"

# game/special_events/halloween 2025.rpy:364
translate chinese halloween_prepare_bathroom_ef29b55b:

    # Kate "Хорошо, я обещаю . . ."
    Kate "好吧，我保证。 。 。"

# game/special_events/halloween 2025.rpy:366
translate chinese halloween_prepare_bathroom_61bd7d2f:

    # Kate "Может уже отпустишь меня? Я не буду лезть туда вновь"
    Kate "也许你已经让我走了？我不会再去那里了"

# game/special_events/halloween 2025.rpy:368
translate chinese halloween_prepare_bathroom_77a74e82:

    # gg "Ты такая легкая"
    gg "你好轻"

# game/special_events/halloween 2025.rpy:370
translate chinese halloween_prepare_bathroom_a0e2f8bb:

    # Kate "Спасибо"
    Kate "谢谢"

# game/special_events/halloween 2025.rpy:383
translate chinese halloween_prepare_myroom_5692ba1f:

    # gg "Эх устал я помогать всем девочкам, и так спать хотел"
    gg "呃，我厌倦了帮助所有女孩，我只想睡觉"

# game/special_events/halloween 2025.rpy:385
translate chinese halloween_prepare_myroom_6e92de75:

    # gg "Думаю посплю часик"
    gg "我想我会睡一个小时"

# game/special_events/halloween 2025.rpy:400
translate chinese halloween_sonya_dream_8c6442c7:

    # gg_chat "Я просыпаюсь от странного звука - как будто кто-то провёл ногтем по дереву"
    gg_chat "我被一种奇怪的声音吵醒——就像有人用指甲划过木头一样"

# game/special_events/halloween 2025.rpy:401
translate chinese halloween_sonya_dream_a05b8801:

    # gg_chat "Это на кухне?"
    gg_chat "是在厨房里吗？"

# game/special_events/halloween 2025.rpy:403
translate chinese halloween_sonya_dream_514bb7b5:

    # gg_chat "Выхожу на кухню, потирая глаза"
    gg_chat "我走到厨房，揉揉眼睛。"

# game/special_events/halloween 2025.rpy:404
translate chinese halloween_sonya_dream_045482c0:

    # gg_chat "На столе - что-то, чего там не было"
    gg_chat "桌子上有一些本来不存在的东西"

# game/special_events/halloween 2025.rpy:405
translate chinese halloween_sonya_dream_e953cb07:

    # gg_chat "Шкатулка.{w} Тёмное дерево, углы обиты кроваво-красным металлом"
    gg_chat "盒子。{w}深色木质，四角覆盖着血红色金属"

# game/special_events/halloween 2025.rpy:406
translate chinese halloween_sonya_dream_76809b89:

    # gg "Что за чёрт . . ."
    gg "我勒个去。 。 。"

# game/special_events/halloween 2025.rpy:407
translate chinese halloween_sonya_dream_b5f93453:

    # gg_chat "Она не выглядит новой"
    gg_chat "她看起来并不新鲜"

# game/special_events/halloween 2025.rpy:408
translate chinese halloween_sonya_dream_5ac4f621:

    # gg_chat "Скорее наоборот - как будто ей сотни лет"
    gg_chat "恰恰相反——仿佛她已经有数百岁了"

# game/special_events/halloween 2025.rpy:413
translate chinese halloween_sonya_dream_a96a7298:

    # gg "Просто кто-то оставил{w} Мая? Соня?"
    gg "有人 5 月 {w} 刚离开吗？索尼娅？"

# game/special_events/halloween 2025.rpy:414
translate chinese halloween_sonya_dream_f60dffa6:

    # gg_chat "Глупо, но я всё равно касаюсь крышки"
    gg_chat "虽然很蠢，但我还是摸了摸盖子"

# game/special_events/halloween 2025.rpy:415
translate chinese halloween_sonya_dream_7aa1f899:

    # gg_chat "Тепло.{w} Как будто под пальцами кожа, а не дерево"
    gg_chat "温暖。{w}仿佛手指下的是皮革，而不是木头"

# game/special_events/halloween 2025.rpy:418
translate chinese halloween_sonya_dream_d4c068d1:

    # gg_chat "Внутри - монетка. Старая, истёртая, на ней выдавлен глаз, а края неровные, будто её кто-то грыз"
    gg_chat "里面有一枚硬币。它又旧又破，一只眼睛被挖掉了，边缘凹凸不平，好像被人啃过一样。"

# game/special_events/halloween 2025.rpy:419
translate chinese halloween_sonya_dream_891135f2:

    # gg "И всё? . . ."
    gg "就这样？ 。 。 。"

# game/special_events/halloween 2025.rpy:421
translate chinese halloween_sonya_dream_5bbdc303:

    # gg "Ладно, пока возьму себе"
    gg "好的，我暂时拿走"

# game/special_events/halloween 2025.rpy:422
translate chinese halloween_sonya_dream_63ba62de:

    # gg_chat "Я поворачиваю её в пальцах"
    gg_chat "我用手指转动它"

# game/special_events/halloween 2025.rpy:423
translate chinese halloween_sonya_dream_60e7c398:

    # gg_chat "Странная тяжесть, будто монета сделана не из металла, а из чего-то живого"
    gg_chat "奇怪的沉重感，仿佛这枚硬币不是由金属制成的，而是由某种有生命的东西制成的"

# game/special_events/halloween 2025.rpy:427
translate chinese halloween_sonya_dream_b51c492c:

    # gg "Где же все?"
    gg "大家都在哪里？"

# game/special_events/halloween 2025.rpy:432
translate chinese halloween_sonya_dream_867b75aa:

    # gg "Чёрт. что за бред телевизор сам включился . . ."
    gg "废话。这电视自动开机是怎么回事？ 。 。"

# game/special_events/halloween 2025.rpy:467
translate chinese halloween_sonya_dream_cfa5487f:

    # gg "Что за бред"
    gg "什么废话"

# game/special_events/halloween 2025.rpy:468
translate chinese halloween_sonya_dream_6ca44626:

    # gg "Нужно проверить остальные комнаты"
    gg "需要检查其他房间"

# game/special_events/halloween 2025.rpy:471
translate chinese halloween_sonya_dream_3109e8d5:

    # gg "Соня?"
    gg "索尼娅？"

# game/special_events/halloween 2025.rpy:473
translate chinese halloween_sonya_dream_af6b4c99:

    # gg "Эй . . . поздно уже, ты меня пугаешь, честно"
    gg "嘿 。 。 。已经晚了，说实话，你吓到我了"

# game/special_events/halloween 2025.rpy:476
translate chinese halloween_sonya_dream_f09531f9:

    # gg "Просто показалось . . ."
    gg "看起来就是这样。 。 。"

# game/special_events/halloween 2025.rpy:477
translate chinese halloween_sonya_dream_6fecd311:

    # gg "Просто тень . . ."
    gg "只是一个影子。 。 。"

# game/special_events/halloween 2025.rpy:484
translate chinese halloween_sonya_dream_b989363c:

    # gg ". . ."
    gg "。 。 。"

# game/special_events/halloween 2025.rpy:486
translate chinese halloween_sonya_dream_e5e215bc:

    # Sonya "Как ты посмел меня разбудить!" with hpunch
    Sonya "你竟敢吵醒我！" with hpunch

# game/special_events/halloween 2025.rpy:488
translate chinese halloween_sonya_dream_cbf79f81:

    # gg "Соня, ты . . . {w}ты издеваешься? . . ."
    gg "索尼娅，你…… 。 {w}你在开玩笑吗？ 。 。 。"

# game/special_events/halloween 2025.rpy:490
translate chinese halloween_sonya_dream_ea23c51e:

    # gg "Это ты? Что это за грёбаные игры? . . ."
    gg "是你吗？这些游戏到底是什么？ 。 。 。"

# game/special_events/halloween 2025.rpy:492
translate chinese halloween_sonya_dream_c5bc9963:

    # Sonya "Имя звучит знакомо"
    Sonya "这个名字听起来很耳熟"

# game/special_events/halloween 2025.rpy:493
translate chinese halloween_sonya_dream_4db18375:

    # Sonya "Но та, кого ты звал, умерла вместе с этим домом"
    Sonya "但你打电话给的那个人却和这栋房子一起死了"

# game/special_events/halloween 2025.rpy:494
translate chinese halloween_sonya_dream_f5284849:

    # gg "Прекрати . . ."
    gg "停止吧。 。 。"

# game/special_events/halloween 2025.rpy:496
translate chinese halloween_sonya_dream_bf221ec2:

    # Sonya "Дом теперь мой.{w} Я - его хозяин"
    Sonya "这房子现在是我的了。{w}我是它的主人"

# game/special_events/halloween 2025.rpy:498
translate chinese halloween_sonya_dream_2c4ebaa2:

    # Sonya "Боишься?"
    Sonya "你害怕吗？"

# game/special_events/halloween 2025.rpy:499
translate chinese halloween_sonya_dream_0063da0b:

    # gg "Да . . ."
    gg "是的。 。 。"

# game/special_events/halloween 2025.rpy:501
translate chinese halloween_sonya_dream_b67571be:

    # Sonya "Хорошо"
    Sonya "美好的"

# game/special_events/halloween 2025.rpy:503
translate chinese halloween_sonya_dream_14d503b0:

    # Sonya "Страх делает кровь живой"
    Sonya "恐惧使血液活跃起来"

# game/special_events/halloween 2025.rpy:511
translate chinese halloween_sonya_dream_ab894d3a:

    # Sonya "Ты принёс монету?"
    Sonya "你带硬币了吗？"

# game/special_events/halloween 2025.rpy:515
translate chinese halloween_sonya_dream_c3bf29e7:

    # gg "Что? . . ."
    gg "什么？ 。 。 。"

# game/special_events/halloween 2025.rpy:517
translate chinese halloween_sonya_dream_52cb176c:

    # Sonya "Дар, что был запечатан. Ты открыл его"
    Sonya "一份被密封的礼物。你打开了它"

# game/special_events/halloween 2025.rpy:518
translate chinese halloween_sonya_dream_e3369996:

    # Sonya "Ты впустил меня"
    Sonya "你让我进去"

# game/special_events/halloween 2025.rpy:520
translate chinese halloween_sonya_dream_1f166693:

    # Sonya "Я не Соня"
    Sonya "我不是索尼娅"

# game/special_events/halloween 2025.rpy:524
translate chinese halloween_sonya_dream_86fe7642:

    # Sonya "Я та, что носила её лицо"
    Sonya "我是那个戴着她脸的人"

# game/special_events/halloween 2025.rpy:525
translate chinese halloween_sonya_dream_625b9f75:

    # Sonya "И теперь ты мой"
    Sonya "现在你是我的了"

# game/special_events/halloween 2025.rpy:527
translate chinese halloween_sonya_dream_0ac9332f:

    # Sonya "Всё, что ты боялся потерять . . . я уже взяла"
    Sonya "你害怕失去的一切。 。 。我已经拿了"

# game/special_events/halloween 2025.rpy:529
translate chinese halloween_sonya_dream_64ed8507:

    # Sonya "А теперь - перестань сопротивляться"
    Sonya "现在停止抵抗"

# game/special_events/halloween 2025.rpy:533
translate chinese halloween_sonya_dream_9d9be648:

    # Sonya "Да . . . вот оно. Жар под кожей. Сок, который ты копил для кого-то другого. Теперь он мой"
    Sonya "是的。 。 。这里是。皮肤下发热。你为别人节省的果汁。现在他是我的了"

# game/special_events/halloween 2025.rpy:534
translate chinese halloween_sonya_dream_709e3011:

    # Sonya "Я чувствую . . . как твоя суть отделяется от костей. Как светится . . . и течёт ко мне"
    Sonya "我觉得。 。 。你的本质是如何与你的骨头分离的。它如何发光。 。 。并流向我"

# game/special_events/halloween 2025.rpy:535
translate chinese halloween_sonya_dream_5e3f412d:

    # Sonya "Скоро . . . скоро ты станешь пустым. Лёгким. И будешь спать"
    Sonya "即将推出。 。 。很快你就会变得空虚。简单的。你会睡觉"

# game/special_events/halloween 2025.rpy:540
translate chinese halloween_sonya_dream_8f2a3a2a:

    # Sonya "Сейчас. Отдай мне последнюю искру. Тот всполох, что зовут экстазом… я приму его как дань"
    Sonya "现在。给我你最后的火花。那个叫做狂喜的闪光……我会接受它作为致敬"

# game/special_events/halloween 2025.rpy:543
translate chinese halloween_sonya_dream_279834b2:

    # Sonya "ДА! Вот . . . пылающая монета твоей души . . . я беру её!"
    Sonya "是的！这里 。 。 。你灵魂的燃烧硬币。 。 。我要买它！"

# game/special_events/halloween 2025.rpy:546
translate chinese halloween_sonya_dream_feb25de8:

    # Sonya "Спи. В твоих снах будет песок. И глаза в темноте . . . мои глаза"
    Sonya "睡觉。梦里会有沙子。还有黑暗中的眼睛。 。 。我的眼睛"

# game/special_events/halloween 2025.rpy:549
translate chinese halloween_sonya_dream_dbd299d0:

    # Sonya "Может быть, я позову снова . . . когда проголодаюсь"
    Sonya "也许我会再打电话。 。 。当我饿的时候"

# game/special_events/halloween 2025.rpy:574
translate chinese halloween_maya_dream_032be6f2:

    # gg "Чёрт . . . {w}нет, нет, снова это . . ."
    gg "废话。 。 。 {w}不，不，又是这样。 。 。"

# game/special_events/halloween 2025.rpy:576
translate chinese halloween_maya_dream_ff7388e6:

    # Maya "Эй, спокойно"
    Maya "嘿，冷静点"

# game/special_events/halloween 2025.rpy:578
translate chinese halloween_maya_dream_92686e55:

    # Maya "Ты в безопасности"
    Maya "你安全吗"

# game/special_events/halloween 2025.rpy:579
translate chinese halloween_maya_dream_edf9349e:

    # gg "Где я? . . ."
    gg "我在哪里？ 。 。 。"

# game/special_events/halloween 2025.rpy:580
translate chinese halloween_maya_dream_de23ff68:

    # gg "Что . . . что это за место?"
    gg "什么 。 。 。这是一个什么样的地方？"

# game/special_events/halloween 2025.rpy:582
translate chinese halloween_maya_dream_75c561e6:

    # Maya "Мой дом"
    Maya "我的家"

# game/special_events/halloween 2025.rpy:584
translate chinese halloween_maya_dream_912b1ea9:

    # gg "Почему . . . я . . . здесь? . . ."
    gg "为什么 。 。 。我 。 。 。这里？ 。 。 。"

# game/special_events/halloween 2025.rpy:586
translate chinese halloween_maya_dream_05fc8512:

    # Maya "Потому что ты боялся"
    Maya "因为你害怕了"

# game/special_events/halloween 2025.rpy:587
translate chinese halloween_maya_dream_657245c6:

    # Maya "И кто-то должен был тебя остановить"
    Maya "应该有人阻止你"

# game/special_events/halloween 2025.rpy:589
translate chinese halloween_maya_dream_dcba1503:

    # gg "Нет . . .{w} не приближайся"
    gg "不 。 。 .{w}别靠近"

# game/special_events/halloween 2025.rpy:590
translate chinese halloween_maya_dream_e91592a1:

    # gg "Я видел, как это начинается"
    gg "我看到它开始了"

# game/special_events/halloween 2025.rpy:591
translate chinese halloween_maya_dream_d9b24014:

    # gg "Сначала свет, потом . . ."
    gg "首先是光，然后是。 。 。"

# game/special_events/halloween 2025.rpy:594
translate chinese halloween_maya_dream_23c69478:

    # Maya "Никто не собирается тебя пугать"
    Maya "没有人会吓到你"

# game/special_events/halloween 2025.rpy:595
translate chinese halloween_maya_dream_fb15da85:

    # gg "Это сон?"
    gg "这是梦吗？"

# game/special_events/halloween 2025.rpy:597
translate chinese halloween_maya_dream_ef47f8b8:

    # Maya "Возможно"
    Maya "或许"

# game/special_events/halloween 2025.rpy:598
translate chinese halloween_maya_dream_11e09330:

    # Maya "Но в этом сне тебе можно не убегать"
    Maya "但在这个梦里你不必逃跑"

# game/special_events/halloween 2025.rpy:600
translate chinese halloween_maya_dream_e96ceee2:

    # Maya "Сядь.{w} Попробуй просто дышать"
    Maya "坐下来。{w}试着呼吸一下"

# game/special_events/halloween 2025.rpy:601
translate chinese halloween_maya_dream_f1385d77:

    # gg "Я . . .{w} не могу"
    gg "我 。 。 .{w}我不能"

# game/special_events/halloween 2025.rpy:603
translate chinese halloween_maya_dream_38874e86:

    # Maya "Можешь{w}, начни только тихо"
    Maya "您可以{w}，安静地开始"

# game/special_events/halloween 2025.rpy:605
translate chinese halloween_maya_dream_4a1eadac:

    # Maya "Ты думал, я кто-то другой, да?"
    Maya "你以为我是别人，对吗？"

# game/special_events/halloween 2025.rpy:607
translate chinese halloween_maya_dream_8d83da3f:

    # gg "После всего . . ."
    gg "一切之后。 。 。"

# game/special_events/halloween 2025.rpy:608
translate chinese halloween_maya_dream_9aa85be5:

    # gg "Я и не знаю, кому верить"
    gg "我不知道该相信谁"

# game/special_events/halloween 2025.rpy:609
translate chinese halloween_maya_dream_95a67e98:

    # Maya "Тогда не верь"
    Maya "那就别信"

# game/special_events/halloween 2025.rpy:610
translate chinese halloween_maya_dream_cf12428b:

    # Maya "Просто смотри"
    Maya "就看吧"

# game/special_events/halloween 2025.rpy:614
translate chinese halloween_maya_dream_5da82532:

    # gg "Чувствуешь?{w} Здесь нет боли"
    gg "你能感觉到吗？{w}这里没有疼痛"

# game/special_events/halloween 2025.rpy:616
translate chinese halloween_maya_dream_df19ec31:

    # Maya "Ты дрожишь"
    Maya "你在发抖"

# game/special_events/halloween 2025.rpy:617
translate chinese halloween_maya_dream_b989363c:

    # gg ". . ."
    gg "。 。 。"

# game/special_events/halloween 2025.rpy:620
translate chinese halloween_maya_dream_718947a3:

    # Maya "Бедный"
    Maya "贫穷的"

# game/special_events/halloween 2025.rpy:622
translate chinese halloween_maya_dream_20c45a93:

    # Maya "Я давно не видела людей"
    Maya "我已经很久没见到人了"

# game/special_events/halloween 2025.rpy:624
translate chinese halloween_maya_dream_0f6f1ec4:

    # Maya "Вот, видишь?{w} Уже лучше"
    Maya "看？ {w}这样更好"

# game/special_events/halloween 2025.rpy:625
translate chinese halloween_maya_dream_1db499d0:

    # gg "Не знаю, что это.{w} Но уже лучше"
    gg "我不知道它是什么。{w}但它更好"

# game/special_events/halloween 2025.rpy:627
translate chinese halloween_maya_dream_927ad5b3:

    # Maya "Сейчас кое что тебя поставит на ноги"
    Maya "现在有些东西会让你站起来"

# game/special_events/halloween 2025.rpy:630
translate chinese halloween_maya_dream_9add8ae1:

    # Maya "Здесь только травы"
    Maya "这里只有草药"

# game/special_events/halloween 2025.rpy:631
translate chinese halloween_maya_dream_338034af:

    # Maya "Лаванда, мята, немного корицы.{w} Попей"
    Maya "薰衣草、薄荷、一点肉桂。{w}喝"

# game/special_events/halloween 2025.rpy:633
translate chinese halloween_maya_dream_8f20081e:

    # gg "Что это?"
    gg "这是什么？"

# game/special_events/halloween 2025.rpy:634
translate chinese halloween_maya_dream_3fdb7032:

    # Maya "Это магия"
    Maya "这很神奇"

# game/special_events/halloween 2025.rpy:636
translate chinese halloween_maya_dream_7c4cba20:

    # Maya "Лечебное зелье, с небольшим побочным эфектом"
    Maya "具有轻微副作用的治疗药水"

# game/special_events/halloween 2025.rpy:638
translate chinese halloween_maya_dream_59e469a3:

    # gg "Каким еще эфектом"
    gg "还有什么作用"

# game/special_events/halloween 2025.rpy:641
translate chinese halloween_maya_dream_809b7a3a:

    # Maya "Просто отдохни.{w} Не думай об этом"
    Maya "休息吧。{w}别想它"

# game/special_events/halloween 2025.rpy:643
translate chinese halloween_maya_dream_ae92cf27:

    # gg "А если я снова усну?"
    gg "如果我又睡着了怎么办？"

# game/special_events/halloween 2025.rpy:645
translate chinese halloween_maya_dream_c1fe7b6b:

    # Maya "Тогда пусть этот сон, будет приятным"
    Maya "那么就让这个梦变得愉快吧"

# game/special_events/halloween 2025.rpy:650
translate chinese halloween_maya_dream_6274b812:

    # Maya "Да . . . вот так . . . Ты так нуждаешься в этом. Я знала"
    Maya "是的。 。 。像这样 。 。 。你非常需要这个。我知道"

# game/special_events/halloween 2025.rpy:651
translate chinese halloween_maya_dream_c101e994:

    # gg "Майя . . . Я . . ."
    gg "玛雅。 。 。我 。 。 。"

# game/special_events/halloween 2025.rpy:652
translate chinese halloween_maya_dream_5e852895:

    # Maya "Какая прекрасная . . . реакция. Всё для меня?"
    Maya "多么美丽啊。 。 。反应。一切都是为了我？"

# game/special_events/halloween 2025.rpy:653
translate chinese halloween_maya_dream_cab511be:

    # Maya "О-ох . . . Да . . . Вот так"
    Maya "哦。 。 。是的。 。 。像这样"

# game/special_events/halloween 2025.rpy:654
translate chinese halloween_maya_dream_87be51c0:

    # Maya "Да-да-да! Вот здесь! Чувствую, как ты пульсируешь!"
    Maya "是的，是的，是的！就在这里！我感觉到你在跳动！"

# game/special_events/halloween 2025.rpy:656
translate chinese halloween_maya_dream_aafdbf4d:

    # Maya "Aaa-ох . . ."
    Maya "啊啊哦。 。 。"

# game/special_events/halloween 2025.rpy:659
translate chinese halloween_maya_dream_162eda56:

    # Maya "Идеально . . . Ты был идеален . . . Запомни это . . . Запомни меня . . ."
    Maya "完美的 。 。 。你很完美。 。 。记住这一点。 。 。记住账号。 。 。"

# game/special_events/halloween 2025.rpy:687
translate chinese halloween_kate_dream_2a6a4db2:

    # gg "Кейт? . . ."
    gg "凯特？ 。 。 。"

# game/special_events/halloween 2025.rpy:692
translate chinese halloween_kate_dream_3c8f411e:

    # gg "Что . . . что происходит?"
    gg "什么 。 。 。发生了什么事？"

# game/special_events/halloween 2025.rpy:696
translate chinese halloween_kate_dream_6b307304:

    # Kate "{sc}{size=*1.2}Ты"
    Kate "{sc}{size=*1.2}你"

# game/special_events/halloween 2025.rpy:698
translate chinese halloween_kate_dream_21111df8:

    # Kate "Вторгся в середину ритуала"
    Kate "闯入仪式中间"

# game/special_events/halloween 2025.rpy:699
translate chinese halloween_kate_dream_2caa82ea:

    # Kate "Твоё присутствие нарушило поток"
    Kate "你的出现扰乱了流程"

# game/special_events/halloween 2025.rpy:701
translate chinese halloween_kate_dream_bc58cb35:

    # gg "Гх . . . {w}Прости, я не знал . . ."
    gg "呃。 。 。 {w}抱歉，我不知道。 。 。"

# game/special_events/halloween 2025.rpy:703
translate chinese halloween_kate_dream_91b43246:

    # Kate "Ты не просто услышал. Ты почувствовал зов"
    Kate "你不只是听到了。你感受到呼唤了吗"

# game/special_events/halloween 2025.rpy:705
translate chinese halloween_kate_dream_211858ba:

    # Kate "Иначе ты бы не вошёл"
    Kate "不然你就不会进来"

# game/special_events/halloween 2025.rpy:707
translate chinese halloween_kate_dream_0f5b8117:

    # Kate "Люди носят маски каждый день"
    Kate "人们每天都戴着口罩"

# game/special_events/halloween 2025.rpy:708
translate chinese halloween_kate_dream_4fc89b6e:

    # Kate "Они молятся свету, а в темноте становятся теми, кем боятся быть"
    Kate "他们向光明祈祷，但在黑暗中他们变成了他们害怕的样子"

# game/special_events/halloween 2025.rpy:710
translate chinese halloween_kate_dream_fd7485b5:

    # gg "Кейт, пожалуйста . . . остановись"
    gg "凯特，请。 。 。停止"

# game/special_events/halloween 2025.rpy:712
translate chinese halloween_kate_dream_21bb7ba7:

    # Kate "Это имя лишь оболочка, которую я носила"
    Kate "这个名字只是我披上的外壳"

# game/special_events/halloween 2025.rpy:713
translate chinese halloween_kate_dream_54373c98:

    # Kate "Сейчас я — та, кто принимает исповедь. А исповедь требует . . . отдачи"
    Kate "现在我是接受告白的人了。并且需要忏悔。 。 。回报"

# game/special_events/halloween 2025.rpy:715
translate chinese halloween_kate_dream_6aceb243:

    # Kate "Ты боишься. Это хорошо. Страх очищает"
    Kate "你害怕了。这很好。恐惧净化"

# game/special_events/halloween 2025.rpy:716
translate chinese halloween_kate_dream_6993148d:

    # Kate "Но за страхом . . . всегда прячется желание"
    Kate "但背后却是恐惧。 。 。欲望总是隐藏着"

# game/special_events/halloween 2025.rpy:718
translate chinese halloween_kate_dream_5f463a3c:

    # Kate "Мой ритуал требует энергии. Чистой, незамутнённой лицемерием"
    Kate "我的仪式需要能量。纯洁、不被虚伪所蒙蔽"

# game/special_events/halloween 2025.rpy:720
translate chinese halloween_kate_dream_e52aea01:

    # Kate "Твой страх — это начало. Но чтобы завершить круг . . . нужно"
    Kate "你的恐惧就是开始。但要完成这个循环。 。 。需要"

# game/special_events/halloween 2025.rpy:722
translate chinese halloween_kate_dream_6c364d34:

    # Kate "Нечто большее"
    Kate "更多的东西"

# game/special_events/halloween 2025.rpy:725
translate chinese halloween_kate_dream_4729db36:

    # gg "Что ты хочешь? . . . "
    gg "你想要什么？ 。 。 。"

# game/special_events/halloween 2025.rpy:727
translate chinese halloween_kate_dream_14ab3952:

    # Kate "Я хочу ту часть себя, которая не боится тьмы"
    Kate "我想要我的一部分不害怕黑暗"

# game/special_events/halloween 2025.rpy:729
translate chinese halloween_kate_dream_d9bfbc43:

    # Kate "Которая жаждет её"
    Kate "谁渴望她"

# game/special_events/halloween 2025.rpy:730
translate chinese halloween_kate_dream_2a999a14:

    # Kate "Это не сердце. Это — пустота, которую ты пытался заполнить ложью"
    Kate "这不是一颗心。这是你试图用谎言来填补的空白"

# game/special_events/halloween 2025.rpy:732
translate chinese halloween_kate_dream_62c66a6e:

    # Kate "Позволь мне заполнить её истиной"
    Kate "让我用真理来填补它"

# game/special_events/halloween 2025.rpy:733
translate chinese halloween_kate_dream_6f6518cc:

    # gg "Гхк . . ."
    gg "嘎嘎。 。 。"

# game/special_events/halloween 2025.rpy:734
translate chinese halloween_kate_dream_a32c9003:

    # gg "Я не могу подвинуться"
    gg "我无法动弹"

# game/special_events/halloween 2025.rpy:736
translate chinese halloween_kate_dream_12b2e70f:

    # Kate "Не сопротивляйся. Это тоже часть ритуала"
    Kate "不要反抗。这也是仪式的一部分"

# game/special_events/halloween 2025.rpy:738
translate chinese halloween_kate_dream_fd3fd304:

    # Kate "Ты отдаёшь — я принимаю. Так было всегда"
    Kate "你给予-我接收。一直都是这样"

# game/special_events/halloween 2025.rpy:740
translate chinese halloween_kate_dream_7cee1ec3:

    # Kate "Видишь? Твоё тело уже понимает. Оно помнит правила"
    Kate "你看到了吗？你的身体已经明白了。它记住规则"

# game/special_events/halloween 2025.rpy:753
translate chinese halloween_kate_dream_e36daadf:

    # Kate "Это дрожь . . . пробуждения"
    Kate "这是一个颤抖。 。 。唤醒"

# game/special_events/halloween 2025.rpy:761
translate chinese halloween_kate_dream_18a21981:

    # Kate "Тише. Не мешай"
    Kate "安静的。请勿打扰"

# game/special_events/halloween 2025.rpy:762
translate chinese halloween_kate_dream_64b1ddea:

    # Kate "Я только знакомлюсь с тем, что моё"
    Kate "我才刚刚开始知道什么是我的"

# game/special_events/halloween 2025.rpy:764
translate chinese halloween_kate_dream_fa83af8e:

    # Kate "Ты . . . для этого . . .{w} и пришёл . . ."
    Kate "你 。 。 。为了这 。 。 .{w} 来了。 。 。"

# game/special_events/halloween 2025.rpy:765
translate chinese halloween_kate_dream_475590f4:

    # Kate "Чтоб тебя . . . размяли . . .{w} взяли в руки . . ."
    Kate "给你。 。 。揉捏。 .{w} 已接听。 。 。"

# game/special_events/halloween 2025.rpy:767
translate chinese halloween_kate_dream_020e238d:

    # gg "Агхх . ."
    gg "啊啊。 。"

# game/special_events/halloween 2025.rpy:768
translate chinese halloween_kate_dream_0c86ca7b:

    # Kate "Да!"
    Kate "是的！"

# game/special_events/halloween 2025.rpy:769
translate chinese halloween_kate_dream_d0b4a1d1:

    # Kate "Вот так"
    Kate "像这样"

# game/special_events/halloween 2025.rpy:770
translate chinese halloween_kate_dream_854a0208:

    # Kate "Рвись! Кончай!{w} Отдавай это мне"
    Kate "匆忙！射精！{w}给我"

# game/special_events/halloween 2025.rpy:772
translate chinese halloween_kate_dream_4402c96f:

    # Kate "Ахахаха ха ха"
    Kate "啊哈哈哈哈"

# game/special_events/halloween 2025.rpy:774
translate chinese halloween_kate_dream_c8fc9712:

    # Kate "Видишь? Даже твой пик — в моей власти"
    Kate "你看到了吗？连你的巅峰都在我的掌控之中"

# game/special_events/halloween 2025.rpy:775
translate chinese halloween_kate_dream_ab9b9a56:

    # Kate "Я решаю когда и как"
    Kate "我决定何时以及如何"

# game/special_events/halloween 2025.rpy:777
translate chinese halloween_kate_dream_d8951333:

    # Kate "А теперь хватит игр"
    Kate "现在游戏就够了"

# game/special_events/halloween 2025.rpy:786
translate chinese halloween_kate_dream_088e1fcf:

    # Kate "Всё, время нежностей кончилось"
    Kate "就这样，温柔的时光结束了"

# game/special_events/halloween 2025.rpy:789
translate chinese halloween_kate_dream_d84a2e22:

    # Kate "Молчи и терпи. Это плата за твой глупый интерес"
    Kate "保持沉默并保持耐心。这就是你愚蠢利益的代价"

# game/special_events/halloween 2025.rpy:791
translate chinese halloween_kate_dream_959b5201:

    # Kate "А-ах . . . Так . . . Глубоко . . ."
    Kate "啊啊。 。 。所以 。 。 。深的。 。 。"

# game/special_events/halloween 2025.rpy:794
translate chinese halloween_kate_dream_ad7fd02e:

    # Kate "Да . . . Вот так"
    Kate "是的。 。 。像这样"

# game/special_events/halloween 2025.rpy:795
translate chinese halloween_kate_dream_e0d93040:

    # Kate "Отдай мне это.{w} Всю свою подавленную тьму.{w} Всю свою скрытую жажду"
    Kate "把它给我。{w}你所有被压抑的黑暗。{w}你所有隐藏的渴望"

# game/special_events/halloween 2025.rpy:796
translate chinese halloween_kate_dream_3f099ced:

    # gg "Я . . . я не могу . . ."
    gg "我 。 。 。我不能。 。 。"

# game/special_events/halloween 2025.rpy:797
translate chinese halloween_kate_dream_0e94451f:

    # Kate "Можешь. И ты сделаешь.{w} Сейчас"
    Kate "能。你会的。{w}现在"

# game/special_events/halloween 2025.rpy:800
translate chinese halloween_kate_dream_866aa006:

    # Kate "А-ах . . ."
    Kate "啊啊。 。 。"

# game/special_events/halloween 2025.rpy:802
translate chinese halloween_kate_dream_25c1049a:

    # Kate "Ха.."
    Kate "哈.."

# game/special_events/halloween 2025.rpy:804
translate chinese halloween_kate_dream_c4c58437:

    # Kate "Ритуал завершён. Ты отдал достаточно . . . чтобы я продолжила свой путь"
    Kate "仪式完成。你给的已经够多了。 。让我继续我的路"

# game/special_events/halloween 2025.rpy:806
translate chinese halloween_kate_dream_c5ab54b2:

    # Kate "Ты проснёшься пустым.{w} Безнадёжно пустым. И, может быть, снова выползешь ко мне . . ."
    Kate "你醒来时会感到空虚。{w}空虚得无可救药。也许你会再次爬到我身边。 。 。"

# game/special_events/halloween 2025.rpy:807
translate chinese halloween_kate_dream_0eb6bd42:

    # Kate "Чтобы снова украсть немного этой полноты"
    Kate "再次偷走一些充实感"

# game/special_events/halloween 2025.rpy:809
translate chinese halloween_kate_dream_2f7f297c:

    # Kate "Хотя бы на мгновение"
    Kate "至少一会儿"

# game/special_events/halloween 2025.rpy:832
translate chinese halloween_kate_dream_b989363c:

    # gg ". . ."
    gg "。 。 。"

# game/special_events/halloween 2025.rpy:833
translate chinese halloween_kate_dream_5174a63c:

    # gg "Приснится же такое . . ."
    gg "我会梦见这样的事情。 。 。"

# game/special_events/halloween 2025.rpy:835
translate chinese halloween_kate_dream_13dee7c8:

    # "Тыква хранит воспоминания"
    "南瓜保留着回忆"

# game/special_events/halloween 2025.rpy:836
translate chinese halloween_kate_dream_bb8e42de:

    # "Коснись её, чтобы вновь увидеть сцену"
    "触摸它即可再次看到场景"

translate chinese strings:

    # game/special_events/halloween 2025.rpy:15
    old "Сон с Кейт"
    new "和凯特一起睡觉"

# TODO: Translation updated at 2026-01-27 02:10

# game/special_events/halloween 2025.rpy:727
translate chinese halloween_kate_dream_195da2d7:

    # Kate "Я хочу ту часть тебя, которая не боится тьмы"
    Kate "我想要你不惧怕黑暗的那部分"

