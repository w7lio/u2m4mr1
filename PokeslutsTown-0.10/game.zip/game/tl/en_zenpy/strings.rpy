translate en_zenpy strings:

    old "Click to play the video."
    new "Nhấp để phát video."

    old "Self-voicing disabled."
    new "Đã tắt tự đọc."

    old "Clipboard voicing enabled. "
    new "Đã bật đọc bộ nhớ tạm. "

    old "Self-voicing enabled. "
    new "Đã bật tự đọc. "

    old "bar"
    new "thanh"

    old "selected"
    new "đã chọn"

    old "viewport"
    new "khung nhìn"

    old "horizontal scroll"
    new "cuộn ngang"

    old "vertical scroll"
    new "cuộn dọc"

    old "activate"
    new "kích hoạt"

    old "deactivate"
    new "hủy kích hoạt"

    old "increase"
    new "tăng"

    old "decrease"
    new "giảm"

    old "Self-Voicing"
    new "Tự đọc"

    old "Self-voicing support is limited when using a touch screen."
    new "Hỗ trợ tự đọc bị hạn chế khi dùng màn hình cảm ứng."

    old "Off"
    new "Tắt"

    old "Text-to-speech"
    new "Chuyển văn bản thành giọng nói"

    old "Clipboard"
    new "Bộ nhớ tạm"

    old "Debug"
    new "Gỡ lỗi"

    old "Voice Volume"
    new "Âm lượng giọng nói"

    old "Reset"
    new "Đặt lại"

    old "Self-Voicing Volume Drop"
    new "Giảm âm lượng khi tự đọc"

    old "Mono Audio"
    new "Âm thanh mono"

    old "Enable"
    new "Bật"

    old "Disable"
    new "Tắt"

    old "Font Override"
    new "Ghi đè phông chữ"

    old "Default"
    new "Mặc định"

    old "DejaVu Sans"
    new "DejaVu Sans"

    old "Opendyslexic"
    new "Opendyslexic"

    old "High Contrast Text"
    new "Văn bản tương phản cao"

    old "Text Size Scaling"
    new "Tỉ lệ cỡ chữ"

    old "Line Spacing Scaling"
    new "Tỉ lệ giãn dòng"

    old "Kerning"
    new "Kerning"

    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Menu trợ năng. Dùng phím mũi tên lên và xuống để điều hướng, nhấn Enter để kích hoạt nút và thanh."

    old "Self-Voicing and Audio"
    new "Tự đọc và âm thanh"

    old "Text"
    new "Văn bản"

    old "Return"
    new "Quay lại"

    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Các tùy chọn trong menu này nhằm cải thiện khả năng tiếp cận. Chúng có thể không hoạt động với mọi trò chơi, và một số kết hợp tùy chọn có thể khiến trò chơi không chơi được. Đây không phải vấn đề của trò chơi hay engine. Để có kết quả tốt nhất khi thay đổi phông chữ, hãy cố giữ nguyên cỡ chữ như ban đầu."

    old "{#weekday}Monday"
    new "{#weekday}Thứ Hai"

    old "{#weekday}Tuesday"
    new "{#weekday}Thứ Ba"

    old "{#weekday}Wednesday"
    new "{#weekday}Thứ Tư"

    old "{#weekday}Thursday"
    new "{#weekday}Thứ Năm"

    old "{#weekday}Friday"
    new "{#weekday}Thứ Sáu"

    old "{#weekday}Saturday"
    new "{#weekday}Thứ Bảy"

    old "{#weekday}Sunday"
    new "{#weekday}Chủ Nhật"

    old "{#weekday_short}Mon"
    new "{#weekday_short}Mon"

    old "{#weekday_short}Tue"
    new "{#weekday_short}Tue"

    old "{#weekday_short}Wed"
    new "{#weekday_short}Wed"

    old "{#weekday_short}Thu"
    new "{#weekday_short}Thu"

    old "{#weekday_short}Fri"
    new "{#weekday_short}Fri"

    old "{#weekday_short}Sat"
    new "{#weekday_short}Sat"

    old "{#weekday_short}Sun"
    new "{#weekday_short}Sun"

    old "{#month}January"
    new "{#month}Tháng 1"

    old "{#month}February"
    new "{#month}Tháng 2"

    old "{#month}March"
    new "{#month}Tháng 3"

    old "{#month}April"
    new "{#month}Tháng 4"

    old "{#month}May"
    new "{#month}Tháng 5"

    old "{#month}June"
    new "{#month}Tháng 6"

    old "{#month}July"
    new "{#month}Tháng 7"

    old "{#month}August"
    new "{#month}Tháng 8"

    old "{#month}September"
    new "{#month}Tháng 9"

    old "{#month}October"
    new "{#month}Tháng 10"

    old "{#month}November"
    new "{#month}Tháng 11"

    old "{#month}December"
    new "{#month}Tháng 12"

    old "{#month_short}Jan"
    new "{#month_short}Jan"

    old "{#month_short}Feb"
    new "{#month_short}Feb"

    old "{#month_short}Mar"
    new "{#month_short}Mar"

    old "{#month_short}Apr"
    new "{#month_short}Apr"

    old "{#month_short}May"
    new "{#month_short}May"

    old "{#month_short}Jun"
    new "{#month_short}Jun"

    old "{#month_short}Jul"
    new "{#month_short}Jul"

    old "{#month_short}Aug"
    new "{#month_short}Aug"

    old "{#month_short}Sep"
    new "{#month_short}Sep"

    old "{#month_short}Oct"
    new "{#month_short}Oct"

    old "{#month_short}Nov"
    new "{#month_short}Nov"

    old "{#month_short}Dec"
    new "{#month_short}Dec"

    old "%b %d, %H:%M"
    new "%b %d, %H:%M"

    old "Save slot %s: [text]"
    new "Ô lưu %s: [text]"

    old "Load slot %s: [text]"
    new "Ô tải %s: [text]"

    old "Delete slot [text]"
    new "Xóa ô [text]"

    old "File page auto"
    new "Trang tệp tự động"

    old "File page quick"
    new "Trang tệp nhanh"

    old "File page [text]"
    new "Trang tệp [text]"

    old "Page {}"
    new "Trang {}"

    old "Automatic saves"
    new "Lưu tự động"

    old "Quick saves"
    new "Lưu nhanh"

    old "Next file page."
    new "Trang tệp tiếp theo."

    old "Previous file page."
    new "Trang tệp trước."

    old "Quick save complete."
    new "Lưu nhanh hoàn tất."

    old "Quick save."
    new "Lưu nhanh."

    old "Quick load."
    new "Tải nhanh."

    old "Language [text]"
    new "Ngôn ngữ [text]"

    old "Open [text] directory."
    new "Mở thư mục [text]."

    old "The interactive director is not enabled here."
    new "Trình đạo diễn tương tác không được bật ở đây."

    old "Done"
    new "Xong"

    old "(statement)"
    new "(câu lệnh)"

    old "(tag)"
    new "(thẻ)"

    old "(attributes)"
    new "(thuộc tính)"

    old "(transform)"
    new "(transform)"

    old "(transition)"
    new "(chuyển cảnh)"

    old "(channel)"
    new "(kênh)"

    old "(filename)"
    new "(tên tệp)"

    old "Change"
    new "Thay đổi"

    old "Add"
    new "Thêm"

    old "Cancel"
    new "Hủy"

    old "Remove"
    new "Xóa"

    old "Statement:"
    new "Câu lệnh:"

    old "Tag:"
    new "Thẻ:"

    old "Attributes:"
    new "Thuộc tính:"

    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Nhấp để bật/tắt thuộc tính, nhấp chuột phải để bật/tắt thuộc tính phủ định."

    old "Transforms:"
    new "Transform:"

    old "Click to set transform, right click to add to transform list."
    new "Nhấp để đặt transform, nhấp chuột phải để thêm vào danh sách transform."

    old "Customize director.transforms to add more transforms."
    new "Tùy chỉnh director.transforms để thêm transform."

    old "Behind:"
    new "Phía sau:"

    old "Click to set, right click to add to behind list."
    new "Nhấp để đặt, nhấp chuột phải để thêm vào danh sách phía sau."

    old "Transition:"
    new "Chuyển cảnh:"

    old "Click to set."
    new "Nhấp để đặt."

    old "Customize director.transitions to add more transitions."
    new "Tùy chỉnh director.transitions để thêm chuyển cảnh."

    old "Channel:"
    new "Kênh:"

    old "Customize director.audio_channels to add more channels."
    new "Tùy chỉnh director.audio_channels để thêm kênh."

    old "Audio Filename:"
    new "Tên tệp âm thanh:"

    old "Are you sure?"
    new "Bạn có chắc không？"

    old "Are you sure you want to delete this save?"
    new "Bạn có chắc muốn xóa bản lưu này không？"

    old "Are you sure you want to overwrite your save?"
    new "Bạn có chắc muốn ghi đè bản lưu của mình không？"

    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Tải sẽ làm mất tiến trình chưa lưu.\nBạn có chắc muốn làm điều này không？"

    old "Are you sure you want to quit?"
    new "Bạn có chắc muốn thoát không？"

    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Bạn có chắc muốn quay về menu chính không？\nThao tác này sẽ làm mất tiến trình chưa lưu."

    old "Are you sure you want to continue where you left off?"
    new "Bạn có chắc muốn tiếp tục từ chỗ đã dừng không？"

    old "Are you sure you want to end the replay?"
    new "Bạn có chắc muốn kết thúc phần phát lại không？"

    old "Are you sure you want to begin skipping?"
    new "Bạn có chắc muốn bắt đầu bỏ qua không？"

    old "Are you sure you want to skip to the next choice?"
    new "Bạn có chắc muốn bỏ qua đến lựa chọn tiếp theo không？"

    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Bạn có chắc muốn bỏ qua hội thoại chưa xem đến lựa chọn tiếp theo không？"

    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Bản lưu này được tạo trên một thiết bị khác. Các tệp lưu được tạo với ý đồ độc hại có thể gây hại cho máy tính của bạn. Bạn có tin tưởng người tạo bản lưu này và tất cả những người có thể đã thay đổi tệp không？"

    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "Bạn có tin tưởng thiết bị đã tạo bản lưu này không？ Bạn chỉ nên chọn Có nếu bạn là người dùng duy nhất của thiết bị."

    old "Failed to save screenshot as %s."
    new "Không thể lưu ảnh chụp màn hình dưới dạng %s."

    old "Saved screenshot as %s."
    new "Đã lưu ảnh chụp màn hình dưới dạng %s."

    old "Skip Mode"
    new "Chế độ bỏ qua"

    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Chương trình này chứa phần mềm miễn phí theo một số giấy phép, bao gồm MIT License và GNU Lesser General Public License. Danh sách đầy đủ phần mềm, bao gồm liên kết đến toàn bộ mã nguồn, có thể được tìm thấy {a=https://www.renpy.org/l/license}tại đây{/a}."

    old "display"
    new "hiển thị"

    old "transitions"
    new "chuyển cảnh"

    old "skip transitions"
    new "bỏ qua chuyển cảnh"

    old "video sprites"
    new "sprite video"

    old "show empty window"
    new "hiện cửa sổ trống"

    old "text speed"
    new "tốc độ văn bản"

    old "joystick"
    new "joystick"

    old "joystick..."
    new "joystick…"

    old "skip"
    new "bỏ qua"

    old "skip unseen [text]"
    new "bỏ qua [text] chưa xem"

    old "skip unseen text"
    new "bỏ qua văn bản chưa xem"

    old "begin skipping"
    new "bắt đầu bỏ qua"

    old "after choices"
    new "sau các lựa chọn"

    old "skip after choices"
    new "bỏ qua sau các lựa chọn"

    old "auto-forward time"
    new "thời gian tự động chuyển tiếp"

    old "auto-forward"
    new "tự động chuyển tiếp"

    old "Auto forward"
    new "Tự động chuyển tiếp"

    old "auto-forward after click"
    new "tự động chuyển tiếp sau khi nhấp"

    old "automatic move"
    new "tự động di chuyển"

    old "wait for voice"
    new "chờ giọng nói"

    old "voice sustain"
    new "duy trì giọng nói"

    old "self voicing"
    new "tự đọc"

    old "self voicing enable"
    new "bật tự đọc"

    old "self voicing disable"
    new "tắt tự đọc"

    old "self voicing volume drop"
    new "giảm âm lượng khi tự đọc"

    old "clipboard voicing"
    new "đọc bộ nhớ tạm"

    old "clipboard voicing enable"
    new "bật đọc bộ nhớ tạm"

    old "clipboard voicing disable"
    new "tắt đọc bộ nhớ tạm"

    old "debug voicing"
    new "đọc gỡ lỗi"

    old "debug voicing enable"
    new "bật đọc gỡ lỗi"

    old "debug voicing disable"
    new "tắt đọc gỡ lỗi"

    old "emphasize audio"
    new "nhấn mạnh âm thanh"

    old "rollback side"
    new "phía quay lui"

    old "gl powersave"
    new "tiết kiệm điện GL"

    old "gl framerate"
    new "tốc độ khung hình GL"

    old "gl tearing"
    new "xé hình GL"

    old "font transform"
    new "biến đổi phông chữ"

    old "font size"
    new "cỡ chữ"

    old "font line spacing"
    new "giãn dòng phông chữ"

    old "system cursor"
    new "con trỏ hệ thống"

    old "renderer menu"
    new "menu trình kết xuất"

    old "accessibility menu"
    new "menu trợ năng"

    old "high contrast text"
    new "văn bản tương phản cao"

    old "audio when minimized"
    new "âm thanh khi thu nhỏ"

    old "audio when unfocused"
    new "âm thanh khi mất tiêu điểm"

    old "web cache preload"
    new "tải trước bộ nhớ đệm web"

    old "voice after game menu"
    new "giọng nói sau menu trò chơi"

    old "restore window position"
    new "khôi phục vị trí cửa sổ"

    old "mono audio"
    new "âm thanh mono"

    old "font kerning"
    new "kerning phông chữ"

    old "reset"
    new "đặt lại"

    old "main volume"
    new "âm lượng chính"

    old "music volume"
    new "âm lượng nhạc"

    old "sound volume"
    new "âm lượng âm thanh"

    old "voice volume"
    new "âm lượng giọng nói"

    old "mute main"
    new "tắt tiếng chính"

    old "mute music"
    new "tắt tiếng nhạc"

    old "mute sound"
    new "tắt tiếng âm thanh"

    old "mute voice"
    new "tắt tiếng giọng nói"

    old "mute all"
    new "tắt tiếng tất cả"

    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Đã bật đọc bộ nhớ tạm. Nhấn 'shift+C' để tắt."

    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "Tự đọc sẽ nói \"[renpy.display.tts.last]\". Nhấn 'alt+shift+V' để tắt."

    old "Self-voicing enabled. Press 'v' to disable."
    new "Đã bật tự đọc. Nhấn 'v' để tắt."

    old "Speech Bubble Editor"
    new "Trình chỉnh sửa bong bóng hội thoại"

    old "(hide)"
    new "(ẩn)"

    old "(clear retained bubbles)"
    new "(xóa các bong bóng được giữ lại)"

    old "Sync downloaded."
    new "Đã tải bản đồng bộ."

    old "Could not connect to the Ren'Py Sync server."
    new "Không thể kết nối đến máy chủ Ren'Py Sync."

    old "The Ren'Py Sync server timed out."
    new "Máy chủ Ren'Py Sync đã hết thời gian chờ."

    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Đã xảy ra lỗi không xác định khi kết nối đến máy chủ Ren'Py Sync."

    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "Máy chủ Ren'Py Sync không có bản sao của bản đồng bộ này. ID đồng bộ có thể không hợp lệ hoặc đã hết hạn."

    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Vui lòng nhập ID đồng bộ bạn đã tạo.\nKhông bao giờ nhập ID đồng bộ mà bạn không tự tạo."

    old "The sync ID is not in the correct format."
    new "ID đồng bộ không đúng định dạng."

    old "The sync could not be decrypted."
    new "Không thể giải mã bản đồng bộ."

    old "The sync belongs to a different game."
    new "Bản đồng bộ thuộc về một trò chơi khác."

    old "The sync contains a file with an invalid name."
    new "Bản đồng bộ chứa một tệp có tên không hợp lệ."

    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "Thao tác này sẽ tải các bản lưu của bạn lên {a=https://sync.renpy.org}Máy chủ Ren'Py Sync{/a}.\nBạn có muốn tiếp tục không？"

    old "Yes"
    new "Có"

    old "No"
    new "Không"

    old "Enter Sync ID"
    new "Nhập ID đồng bộ"

    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "Thao tác này sẽ liên hệ với {a=https://sync.renpy.org}Máy chủ Ren'Py Sync{/a}."

    old "Sync Success"
    new "Đồng bộ thành công"

    old "The Sync ID is:"
    new "ID đồng bộ là:"

    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Bạn có thể dùng ID này để tải bản lưu trên thiết bị khác.\nBản đồng bộ này sẽ hết hạn sau một giờ.\nRen'Py Sync được hỗ trợ bởi {a=https://www.renpy.org/sponsors.html}Nhà tài trợ của Ren'Py{/a}."

    old "Continue"
    new "Tiếp tục"

    old "Sync Error"
    new "Lỗi đồng bộ"

    old "Translation identifier: [identifier]"
    new "Mã định danh bản dịch: [identifier]"

    old " translates [tl.filename]:[tl.linenumber]"
    new " dịch [tl.filename]:[tl.linenumber]"

    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Đã sao chép vào bộ nhớ tạm.{/color}"

    old "Contacting App Store\nPlease Wait..."
    new "Đang liên hệ App Store\nVui lòng chờ…"

    old "No update methods found."
    new "Không tìm thấy phương thức cập nhật nào."

    old "Could not download file list: "
    new "Không thể tải danh sách tệp: "

    old "File list digest does not match."
    new "Mã băm danh sách tệp không khớp."

    old "An error is being simulated."
    new "Đang mô phỏng một lỗi."

    old "Either this project does not support updating, or the update status file was deleted."
    new "Dự án này không hỗ trợ cập nhật hoặc tệp trạng thái cập nhật đã bị xóa."

    old "This account does not have permission to perform an update."
    new "Tài khoản này không có quyền thực hiện cập nhật."

    old "This account does not have permission to write the update log."
    new "Tài khoản này không có quyền ghi nhật ký cập nhật."

    old "Could not verify update signature."
    new "Không thể xác minh chữ ký cập nhật."

    old "The update file was not downloaded."
    new "Tệp cập nhật chưa được tải xuống."

    old "The update file does not have the correct digest - it may have been corrupted."
    new "Tệp cập nhật không có mã băm chính xác - có thể đã bị hỏng."

    old "While unpacking {}, unknown type {}."
    new "Khi giải nén {}, gặp loại không xác định {}."

    old "Updater"
    new "Trình cập nhật"

    old "An error has occurred:"
    new "Đã xảy ra lỗi:"

    old "Checking for updates."
    new "Đang kiểm tra cập nhật."

    old "This program is up to date."
    new "Chương trình này đã cập nhật."

    old "[u.version] is available. Do you want to install it?"
    new "Đã có [u.version]. Bạn có muốn cài đặt không？"

    old "Preparing to download the updates."
    new "Đang chuẩn bị tải các bản cập nhật."

    old "Downloading the updates."
    new "Đang tải các bản cập nhật."

    old "Unpacking the updates."
    new "Đang giải nén các bản cập nhật."

    old "Finishing up."
    new "Đang hoàn tất."

    old "The updates have been installed. The program will restart."
    new "Các bản cập nhật đã được cài đặt. Chương trình sẽ khởi động lại."

    old "The updates have been installed."
    new "Các bản cập nhật đã được cài đặt."

    old "The updates were cancelled."
    new "Các bản cập nhật đã bị hủy."

    old "Proceed"
    new "Tiến hành"

    old "Preparing to download the game data."
    new "Đang chuẩn bị tải dữ liệu trò chơi."

    old "Downloading the game data."
    new "Đang tải dữ liệu trò chơi."

    old "The game data has been downloaded."
    new "Dữ liệu trò chơi đã được tải xuống."

    old "An error occurred when trying to download game data:"
    new "Đã xảy ra lỗi khi thử tải dữ liệu trò chơi:"

    old "This game cannot be run until the game data has been downloaded."
    new "Không thể chạy trò chơi này cho đến khi dữ liệu trò chơi được tải xuống."

    old "Retry"
    new "Thử lại"

    old "Fullscreen"
    new "Toàn màn hình"

    old "Image [index] of [count] locked."
    new "Hình [index] trên [count] bị khóa."

    old "prev"
    new "trước"

    old "next"
    new "tiếp"

    old "slideshow"
    new "trình chiếu"

    old "return"
    new "quay lại"

    old "Renderer"
    new "Trình kết xuất"

    old "Automatically Choose"
    new "Tự động chọn"

    old "Force GL2 Renderer"
    new "Buộc dùng trình kết xuất GL2"

    old "Force ANGLE2 Renderer"
    new "Buộc dùng trình kết xuất ANGLE2"

    old "Force GLES2 Renderer"
    new "Buộc dùng trình kết xuất GLES2"

    old "Gamepad"
    new "Tay cầm"

    old "Enable (No Blocklist)"
    new "Bật (không có danh sách chặn)"

    old "Calibrate"
    new "Hiệu chỉnh"

    old "Powersave"
    new "Tiết kiệm điện"

    old "Framerate"
    new "Tốc độ khung hình"

    old "Screen"
    new "Màn hình"

    old "Tearing"
    new "Xé hình"

    old "Changes will take effect the next time this program is run."
    new "Các thay đổi sẽ có hiệu lực vào lần chạy chương trình tiếp theo."

    old "Quit"
    new "Thoát"

    old "Performance Warning"
    new "Cảnh báo hiệu năng"

    old "This computer is using software rendering."
    new "Máy tính này đang dùng kết xuất phần mềm."

    old "This game requires use of GL2 that can't be initialised."
    new "Trò chơi này yêu cầu sử dụng GL2 nhưng không thể khởi tạo."

    old "This computer has a problem displaying graphics: [problem]."
    new "Máy tính này gặp sự cố khi hiển thị đồ họa: [problem]."

    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Trình điều khiển đồ họa của máy có thể đã lỗi thời hoặc không hoạt động đúng. Điều này có thể khiến đồ họa hiển thị chậm hoặc không chính xác."

    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "Tệp {a=edit:1:log.txt}log.txt{/a} có thể chứa thông tin giúp bạn xác định sự cố trên máy tính."

    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Chi tiết thêm về cách khắc phục có thể được tìm thấy trong {a=[url]}tài liệu{/a}."

    old "Continue, Show this warning again"
    new "Tiếp tục, hiển thị lại cảnh báo này"

    old "Continue, Don't show warning again"
    new "Tiếp tục, không hiển thị cảnh báo này nữa"

    old "Change render options"
    new "Thay đổi tùy chọn kết xuất"

    old "Select Gamepad to Calibrate"
    new "Chọn tay cầm để hiệu chỉnh"

    old "No Gamepads Available"
    new "Không có tay cầm nào khả dụng"

    old "Calibrating [name] ([i]/[total])"
    new "Đang hiệu chỉnh [name] ([i]/[total])"

    old "Press or move the '[control!s]' [kind]."
    new "Nhấn hoặc di chuyển [kind] '[control!s]'."

    old "Skip (A)"
    new "Bỏ qua (A)"

    old "Back (B)"
    new "Quay lại (B)"

    old "Open"
    new "Mở"

    old "Opens the traceback.txt file in a text editor."
    new "Mở tệp traceback.txt trong trình soạn thảo văn bản."

    old "Copy BBCode"
    new "Sao chép BBCode"

    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Sao chép tệp traceback.txt vào bộ nhớ tạm dưới dạng BBcode cho các diễn đàn như https://lemmasoft.renai.us/."

    old "Copy Markdown"
    new "Sao chép Markdown"

    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Sao chép tệp traceback.txt vào bộ nhớ tạm dưới dạng Markdown cho Discord."

    old "An exception has occurred."
    new "Đã xảy ra ngoại lệ."

    old "Rollback"
    new "Quay lui"

    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Thử quay lui về thời điểm trước đó, cho phép bạn lưu hoặc chọn một lựa chọn khác."

    old "Ignore"
    new "Bỏ qua"

    old "Ignores the exception, allowing you to continue."
    new "Bỏ qua ngoại lệ, cho phép bạn tiếp tục."

    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Bỏ qua ngoại lệ, cho phép bạn tiếp tục. Điều này thường dẫn đến thêm lỗi."

    old "Reload"
    new "Tải lại"

    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Tải lại trò chơi từ đĩa, lưu và khôi phục trạng thái trò chơi nếu có thể."

    old "Console"
    new "Bảng điều khiển"

    old "Opens a console to allow debugging the problem."
    new "Mở bảng điều khiển để gỡ lỗi sự cố."

    old "Quits the game."
    new "Thoát trò chơi."

    old "Parsing the script failed."
    new "Phân tích cú pháp kịch bản thất bại."

    old "Developer Menu"
    new "Menu nhà phát triển"

    old "Interactive Director (D)"
    new "Trình đạo diễn tương tác (D)"

    old "Reload Game (Shift+R)"
    new "Tải lại trò chơi (Shift+R)"

    old "Console (Shift+O)"
    new "Bảng điều khiển (Shift+O)"

    old "Variable Viewer"
    new "Trình xem biến"

    old "Persistent Viewer"
    new "Trình xem Persistent"

    old "Image Location Picker"
    new "Bộ chọn vị trí hình ảnh"

    old "Filename List"
    new "Danh sách tên tệp"

    old "Show Image Load Log (F4)"
    new "Hiện nhật ký tải hình ảnh (F4)"

    old "Hide Image Load Log (F4)"
    new "Ẩn nhật ký tải hình ảnh (F4)"

    old "Image Attributes"
    new "Thuộc tính hình ảnh"

    old "Show Translation Info"
    new "Hiện thông tin bản dịch"

    old "Hide Translation Info"
    new "Ẩn thông tin bản dịch"

    old "Speech Bubble Editor (Shift+B)"
    new "Trình chỉnh sửa bong bóng hội thoại (Shift+B)"

    old "Show Filename and Line"
    new "Hiện tên tệp và dòng"

    old "Hide Filename and Line"
    new "Ẩn tên tệp và dòng"

    old "Layer [l]:"
    new "Lớp [l]:"

    old "    (transforms: [', '.join(transform_list)])"
    new "    (transform: [', '.join(transform_list)])"

    old "    [name!q] [attributes!q] (hidden)"
    new "    [name!q] [attributes!q] (ẩn)"

    old "    [name!q] [attributes!q]"
    new "    [name!q] [attributes!q]"

    old "Nothing to inspect."
    new "Không có gì để kiểm tra."

    old "Hide deleted"
    new "Ẩn mục đã xóa"

    old "Show deleted"
    new "Hiện mục đã xóa"

    old "Rectangle copied to clipboard."
    new "Đã sao chép hình chữ nhật vào bộ nhớ tạm."

    old "Position copied to clipboard."
    new "Đã sao chép vị trí vào bộ nhớ tạm."

    old "Rectangle: %r"
    new "Hình chữ nhật: %r"

    old "Mouse position: %r"
    new "Vị trí chuột: %r"

    old "Right-click or escape to quit."
    new "Nhấp chuột phải hoặc nhấn escape để thoát."

    old "Type to filter: "
    new "Nhập để lọc: "

    old "Textures: [tex_count] ([tex_size_mb:.1f] MB)"
    new "Kết cấu: [tex_count] ([tex_size_mb:.1f] MB)"

    old "Image cache: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"
    new "Bộ nhớ đệm hình ảnh: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"

    old "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"
    new "\n{color=#cfc}✔ hình ảnh được dự đoán (tốt){/color}\n{color=#fcc}✘ hình ảnh không được dự đoán (xấu){/color}\n{color=#fff}Kéo để di chuyển.{/color}"

    old "Click to open in editor."
    new "Nhấp để mở trong trình chỉnh sửa."

    old "Displayable Inspector"
    new "Trình kiểm tra Displayable"

    old "Size"
    new "Kích thước"

    old "Style"
    new "Style"

    old "Location"
    new "Vị trí"

    old "Inspecting Styles of [displayable_name!q]"
    new "Đang kiểm tra Style của [displayable_name!q]"

    old "displayable:"
    new "displayable:"

    old "        (no properties affect the displayable)"
    new "        (không có thuộc tính nào ảnh hưởng đến displayable)"

    old "        (default properties omitted)"
    new "        (bỏ qua các thuộc tính mặc định)"

    old "<repr() failed>"
    new "<repr() failed>"

    old "Press <esc> to exit console. Type help for help.\n"
    new "Nhấn <esc> để thoát bảng điều khiển. Nhập help để được trợ giúp.\n"

    old "Ren'Py script enabled."
    new "Đã bật script Ren'Py."

    old "Ren'Py script disabled."
    new "Đã tắt script Ren'Py."

    old "The console is using short representations. To disable this, type 'long', and to re-enable, type 'short'"
    new "Bảng điều khiển đang dùng cách biểu diễn ngắn. Để tắt, nhập 'long', và để bật lại, nhập 'short'"

    old "help: show this help\n help <expr>: show signature and documentation of <expr>"
    new "help: hiện trợ giúp này\n help <expr>: hiện chữ ký và tài liệu của <expr>"

    old "Help may display undocumented functions. Please check that the function or\nclass you want to use is documented.\n\n"
    new "Trợ giúp có thể hiển thị các hàm chưa được ghi tài liệu. Vui lòng kiểm tra xem hàm hoặc\nlớp bạn muốn dùng đã có tài liệu chưa.\n\n"

    old "commands:\n"
    new "các lệnh:\n"

    old " <renpy script statement>: run the statement\n"
    new " <renpy script statement>: chạy câu lệnh\n"

    old " <python expression or statement>: run the expression or statement"
    new " <python expression or statement>: chạy biểu thức hoặc câu lệnh"

    old "clear: clear the console history"
    new "clear: xóa lịch sử bảng điều khiển"

    old "exit: exit the console"
    new "exit: thoát bảng điều khiển"

    old "stack: print the return stack"
    new "stack: in ngăn xếp trả về"

    old "load <slot>: loads the game from slot"
    new "load <slot>: tải trò chơi từ ô lưu"

    old "save <slot>: saves the game in slot"
    new "save <slot>: lưu trò chơi vào ô lưu"

    old "reload: reloads the game, refreshing the scripts"
    new "reload: tải lại trò chơi, làm mới các script"

    old "watch <expression>: watch a python expression\n watch short: makes the representation of traced expressions short (default)\n watch long: makes the representation of traced expressions as is"
    new "watch <expression>: theo dõi một biểu thức python\n watch short: khiến cách biểu diễn các biểu thức được theo dõi ngắn gọn (mặc định)\n watch long: khiến cách biểu diễn các biểu thức được theo dõi giữ nguyên"

    old "unwatch <expression>: stop watching an expression"
    new "unwatch <expression>: ngừng theo dõi một biểu thức"

    old "unwatchall: stop watching all expressions"
    new "unwatchall: ngừng theo dõi tất cả biểu thức"

    old "jump <label>: jumps to label"
    new "jump <label>: nhảy đến nhãn"

    old "short: Shorten the representation of objects on the console (default)."
    new "short: Rút gọn cách biểu diễn đối tượng trên bảng điều khiển (mặc định)."

    old "long: Print the full representation of objects on the console."
    new "long: In đầy đủ cách biểu diễn đối tượng trên bảng điều khiển."

    old "escape: Enables escaping of unicode symbols in unicode strings."
    new "escape: Bật thoát ký hiệu unicode trong chuỗi unicode."

    old "unescape: Disables escaping of unicode symbols in unicode strings and print it as is (default)."
    new "unescape: Tắt thoát ký hiệu unicode trong chuỗi unicode và in nguyên trạng (mặc định)."

    old "Trust with [poke_data['name']] increased! ([trust]/100)"
    new "Độ tin tưởng với [poke_data['name']] đã tăng! ([trust]/100)"

    old "Your experience shows. The encounter goes well."
    new "Kinh nghiệm của bạn được thể hiện. Cuộc chạm trán diễn ra tốt đẹp."

    old "[fail_text]"
    new "[fail_text]"

    old "You need [stat_name.capitalize()] 15 or higher for this encounter."
    new "Bạn cần [stat_name.capitalize()] từ 15 trở lên cho cuộc chạm trán này."

    old "The moment is lost. Try again next time."
    new "Đã bỏ lỡ thời điểm. Hãy thử lại lần sau."

    old "You need [req['food_name']] in your inventory."
    new "Bạn cần [req['food_name']] trong túi đồ."

    old "The Pokeball missed. [poke_data['name']] slipped away."
    new "Pokeball đã trượt. [poke_data['name']] đã thoát đi."

    old "You can try again next time."
    new "Bạn có thể thử lại lần sau."

