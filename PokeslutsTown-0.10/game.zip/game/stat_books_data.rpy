# ============================================================
# POKETOWN — stat_books_data.rpy
# Stat books sold in the general store
# ============================================================

define STAT_BOOKS = [

    # PHYSIQUE
    {
        "id":          "physique_basic",
        "name":        "Getting Fit for Beginners",
        "icon":        "💪",
        "description": "A simple guide to building physical strength.",
        "stat":        "physique",
        "stat_gain":   5,
        "price":       75,
    },
    {
        "id":          "physique_advanced",
        "name":        "Peak Performance: The Athletic Blueprint",
        "icon":        "🏋️",
        "description": "An advanced manual used by professional athletes.",
        "stat":        "physique",
        "stat_gain":   10,
        "price":       200,
    },

    # CHARISMA
    {
        "id":          "charisma_basic",
        "name":        "Talking for Dummies",
        "icon":        "💬",
        "description": "A practical guide to everyday conversation and social skills.",
        "stat":        "charisma",
        "stat_gain":   5,
        "price":       75,
    },
    {
        "id":          "charisma_advanced",
        "name":        "The Psychology of Influence",
        "icon":        "🎭",
        "description": "A deep study of human behavior and social dynamics.",
        "stat":        "charisma",
        "stat_gain":   10,
        "price":       200,
    },

    # INTELLIGENCE
    {
        "id":          "intelligence_basic",
        "name":        "Basic Mathematics",
        "icon":        "🧠",
        "description": "Fundamentals of arithmetic and logical thinking.",
        "stat":        "intelligence",
        "stat_gain":   5,
        "price":       75,
    },
    {
        "id":          "intelligence_advanced",
        "name":        "The Architecture of Thought",
        "icon":        "🔬",
        "description": "An advanced treatise on cognition, reasoning and mental mastery.",
        "stat":        "intelligence",
        "stat_gain":   10,
        "price":       200,
    },
]
