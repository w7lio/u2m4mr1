# ============================================================
# POKETOWN — pokemon_events.rpy
# Narrative labels for all Pokemon forest encounters
# ============================================================

# ============================================================
# GARDEVOIR
# ============================================================

label gardevoir_event_1_narrative:
    show expression "images/pokemon/gardevoir/gardevoir_1.png" as cg_scene
    with fade
    narrator "You spot her in a small sunlit clearing."
    narrator "A Gardevoir sits gracefully in meditation, legs crossed, eyes closed. Her elegant white and green body glows softly under the filtered sunlight. Her long flowing skirt sways gently with the breeze."
    narrator "You approach slowly."
    narrator "In the blink of an eye, her form flickers like a mirage... and she vanishes completely."
    narrator "Only a faint, sweet floral scent remains in the air."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gardevoir_event_2_narrative:
    show expression "images/pokemon/gardevoir/gardevoir_2.png" as cg_scene
    with fade
    narrator "You see her again, this time standing between the trees in the distance."
    narrator "She was already watching you. Her head slightly tilted, eyes focused with a soft violet glow pulsing gently in them. The light feels like a warm pressure against your mind, as if she is quietly analyzing you."
    narrator "Before you can react, the glow fades. A small, gentle smile forms on her lips. She gives you a graceful nod, almost playful, as if she has seen something she likes."
    narrator "Then, with one elegant step backwards, her form flickers... and she disappears once more into the forest."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gardevoir_event_3_narrative:
    show expression "images/pokemon/gardevoir/gardevoir_3.png" as cg_scene
    with fade
    narrator "You find her standing in a small clearing, closer than ever before. The Gardevoir looks at you calmly, but there’s a noticeable difference this time."
    narrator "Her cheeks have a soft pink tint and her breathing is slightly deeper. She slowly turns her body, showing off her elegant figure. The thin white fabric of her lower body clings to her wide hips and the curve of her ass."
    narrator "She raises one slender hand and gently touches her own chest, right between her full breasts. A faint pink psychic aura surrounds her body as she looks at you, almost like an invitation."
    narrator "She waits for your reaction."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gardevoir_event_3_narrative_post:
    show expression "images/pokemon/gardevoir/gardevoir_4.png" as cg_scene
    with fade
    narrator "You approach slowly and place your hand over hers. Her body trembles slightly at the contact. You feel the soft warmth of her breasts on your hand through the thin fabric."
    narrator "The pink psychic aura grows stronger and wraps around both of you, sending pleasant tingling sensations across your skin and down to your groin."
    narrator "She closes her eyes for a moment, clearly enjoying the touch. After several long seconds she opens them again, looking at you with half-lidded eyes and flushed cheeks."
    narrator "She steps back gracefully, gives you one last lingering look, and disappears in a swirl of pink light."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gardevoir_event_4_narrative:
    
    narrator "You encounter her again in a quiet forest clearing."
    narrator "She approaches slowly, her eyes fixed on the Lum Berry in your hand."
    show expression "images/pokemon/gardevoir/gardevoir_5.png" as cg_scene
    with fade
    narrator "You offer her the glowing berry. She takes it gracefully, her fingers brushing against yours. She eats it slowly, a soft pink blush spreading across her cheeks and chest."
    narrator "After finishing the berry, she sits down elegantly on the soft grass. She looks up at you with half-lidded eyes full of desire."
    show expression "images/pokemon/gardevoir/gardevoir_6.png" as cg_scene
    with fade
    narrator "Without a word, she pulls down your pants. Your cock springs free right in front of her face. Sitting there, her full body is clearly visible narrow waist, and wide hips completely exposed under her flowing white skirt."
    narrator "She leans forward and wraps her warm, soft lips around the head of your cock. She begins sucking gently, her tongue swirling around you as she takes you deeper into her mouth. Her head moves slowly back and forth in a smooth, wet rhythm."
    narrator "Her psychic aura gently caresses your body while she pleasures you, her beautiful form fully on display as she sits on the ground."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gardevoir_event_5_narrative:
    narrator "She emerges from the ball with a bright, joyful expression. Her eyes sparkle with happiness. She looks at you warmly, clearly pleased to finally have a trainer."
    narrator "You take her back to your house."
    show expression "images/pokemon/gardevoir/gardevoir_7.png" as cg_scene
    with fade
    narrator "Once inside your room, she stands in front of you, visibly excited. Her breathing is heavier and her cheeks are flushed."
    narrator "She slowly sits on the edge of your bed and spreads her legs slightly, letting her white skirt fall open. Her full breasts and smooth body are clearly visible. She looks at you with pure desire."
    narrator "You step closer. She pulls you onto the bed and wraps her legs around your waist. Your hard cock presses against her wet entrance. With one smooth motion, you push inside her tight, warm pussy."
    narrator "She arches her back in pleasure as you begin thrusting deeply. Her heavy breasts bounce with every movement while her psychic aura wraps around both of you, intensifying the sensation."
    narrator "You fuck her harder, her body trembling beneath you until you finally fill her with your cum."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return


# ============================================================
# LOPUNNY
# ============================================================

label lopunny_event_1_narrative:
    show expression "images/pokemon/lopunny/lopunny_1.png" as cg_scene
    with fade
    narrator "You notice something moving inside a thick bush."
    narrator "Only the lower half of her body is visible. Two long, powerful brown legs with soft cream-colored thighs extend from the foliage."
    narrator "Her wide hips and plump, fluffy rear are clearly exposed, barely covered by short black fur. Her round cottontail twitches nervously."
    narrator "You take a few steps closer to identify her."
    show expression "images/pokemon/lopunny/lopunny_0.png" as cg_scene
    with fade
    narrator "Suddenly, her long ears perk up. She notices your presence and panics. In a swift movement, she pulls herself out of the bush and dashes away into the forest, her fluffy tail bouncing behind her."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label lopunny_event_2_narrative:
    show expression "images/pokemon/lopunny/lopunny_2.png" as cg_scene
    with fade
    narrator "This time she is standing still, watching you carefully. Her long ears are perked up and her pink eyes are focused on you. You feel her evaluating you, as if judging your presence and charm."
    narrator "Her expression softens. She tilts her head slightly, looking you up and down with clear interest. Her gaze lingers on your body for a moment. A small, shy smile appears on her lips and her fluffy cottontail twitches happily."
    narrator "She stays visible a few seconds longer than before, allowing you to admire her thick thighs and curvaceous figure."
    show expression "images/pokemon/lopunny/lopunny_0.png" as cg_scene
    with fade
    narrator "before turning gracefully and hopping away into the forest."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label lopunny_event_3_narrative:
    show expression "images/pokemon/lopunny/lopunny_3.png" as cg_scene
    with fade
    narrator "The Lopunny is sitting against a tree with her legs spread. One hand is between her thick thighs, rubbing her pussy slowly while her other hand squeezes her soft breast."
    narrator "Her eyes are half-closed in pleasure and her long ears twitch with every movement."
    narrator "You step closer to get a better view."
    narrator "Her ears suddenly perk up. She clearly senses your presence."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label lopunny_event_3_narrative_post:
    show expression "images/pokemon/lopunny/lopunny_3.png" as cg_scene
    with fade
    narrator "You remain still and continue watching. Instead of stopping, she smiles playfully and spreads her legs wider, giving you a full view of her wet pussy and plump ass."
    narrator "She fingers herself more intensely, moaning softly while looking in your direction, clearly enjoying putting on a show for you."
    narrator "After a few moments her body tenses. She reaches orgasm with a cute shiver, her cottontail fluffing up."
    show expression "images/pokemon/lopunny/lopunny_0.png" as cg_scene
    with fade
    narrator " Still breathing heavily, she stands up, gives you a teasing wink, and hops away happily into the forest."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label lopunny_event_4_narrative:
    show expression "images/pokemon/lopunny/lopunny_4.png" as cg_scene
    with fade
    narrator "You meet her again in the forest."
    narrator "Lopunny notices the Pecha Berry in your hand and her eyes light up with excitement. Her long ears stand straight up and her cottontail begins to twitch rapidly."
    narrator "You extend your hand and offer her the berry. She hops closer happily and takes it from you."
    show expression "images/pokemon/lopunny/lopunny_5.png" as cg_scene
    with fade
    narrator "She crouches down on the ground right in front of you, leaning forward to eat the berry. Her round, fluffy ass sticks up as she eats with delight, her tail wagging energetically from side to side."
    narrator "Once she finishes the sweet berry, she stands up with a big satisfied smile. She looks at you warmly for a moment, then hops away cheerfully into the forest, her fluffy tail still bouncing happily."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label lopunny_event_5_narrative:
    narrator "She emerges from the ball full of energy and pure excitement. Her eyes shine brightly and her cottontail wags rapidly. She looks incredibly happy to finally belong to a trainer."
    narrator "Before you can react, she jumps on you with a burst of joy."
    show expression "images/pokemon/lopunny/lopunny_6.png" as cg_scene
    with fade
    narrator "Lopunny pushes you down onto the soft grass and straddles your waist. Without hesitation, she lowers herself onto you, taking your entire length deep inside her tight, wet pussy in one smooth motion."
    narrator "She begins riding you eagerly, bouncing up and down with fast, energetic movements."
    narrator "Her large, soft breasts bounce heavily with every thrust while her thick thighs squeeze against your sides. Her fluffy cottontail shakes wildly as she rides you harder and faster in the middle of the forest."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return


# ============================================================
# BRAIXEN
# ============================================================

label braixen_event_1_narrative:
    show expression "images/pokemon/braixen/braixen_1.png" as cg_scene
    with fade
    narrator "You walk through a quiet forest clearing at dusk."
    narrator "You spot Braixen practicing magic. She waves her wooden branch elegantly, creating small flames and sparks."
    show expression "images/pokemon/braixen/braixen_2.png" as cg_scene
    with fade
    narrator "She turns around, giving you a perfect view of her fluffy tail and round, plump rear swaying as she moves."
    narrator "She bends forward slightly while casting, making her ass more prominent." 
    narrator "You step closer to watch."
    narrator "Suddenly she senses your presence. Her ears perk up in surprise. With a quick embarrassed yelp, she creates a burst of smoke and flames, then vanishes into the forest, her fluffy tail disappearing last."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label braixen_event_2_narrative:
    show expression "images/pokemon/braixen/braixen_3.png" as cg_scene
    with fade
    narrator "You encounter Braixen again near a small pond in the forest."
    narrator "She is sitting on a rock, using her branch to create small illusions in the water, trying to make beautiful fiery reflections. She seems deep in thought, clearly trying to figure out something complex."
    narrator "You watch quietly for a moment and realize she is recreating a rare constellation pattern with her flames. You softly mention the correct order of stars you remember."
    show expression "images/pokemon/braixen/braixen_4.png" as cg_scene
    with fade
    narrator "Braixen successfully creates the full constellation. She looks surprised and turns toward you with wide eyes. For a few seconds she studies you with clear interest, her fluffy tail swaying slowly."
    narrator "She gives you a soft, appreciative smile and a longer view of her curvy rear as she stands up."
    narrator "Then, with a gentle puff of smoke and sparks, she disappears."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label braixen_event_3_narrative:
    show expression "images/pokemon/braixen/braixen_5.png" as cg_scene
    with fade
    narrator "You find Braixen in a secluded clearing."
    narrator "She is on all fours, her fluffy tail lifted high. She has her wooden branch pressed against her tight rear, slowly pushing the rounded end into her ass while letting out soft, needy moans."
    narrator "Her plump cheeks jiggle slightly with every movement."
    narrator "She notices you but doesn’t stop. Instead, she looks back at you with flushed cheeks and half-lidded eyes, as if inviting you to do something."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label braixen_event_3_narrative_post:
    show expression "images/pokemon/braixen/braixen_6.png" as cg_scene
    with fade
    narrator "You kneel behind her and take the branch, slowly pushing it deeper into her ass. Braixen lets out a loud moan and pushes back against it, clearly enjoying it."
    narrator "Her tail wraps around your arm as her body trembles with pleasure."
    narrator "After a few moments she clenches hard, shivers, and reaches a small orgasm."
    narrator "She looks back at you with lust-filled eyes, gives you a shy but satisfied smile, and disappears in a puff of flames and smoke."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label braixen_event_4_narrative:
    show expression "images/pokemon/braixen/braixen_7.png" as cg_scene
    with fade
    narrator "You encounter Braixen again in the forest."
    narrator "She takes the Cheri Berry from your hand and eats it eagerly. The spicy effect quickly hits her. Her face flushes and she starts breathing heavily from the heat."
    show expression "images/pokemon/braixen/braixen_8.png" as cg_scene
    with fade
    narrator "She walks quickly to a nearby river and bends over to drink water. Her fluffy tail lifts high, fully exposing her round, plump ass and wet pussy."
    show expression "images/pokemon/braixen/braixen_9.png" as cg_scene
    with fade
    narrator "You approach and give her a firm spank on her soft ass. Braixen lets out a surprised but pleased moan."
    narrator "She looks back at you with flushed cheeks and a happy, aroused expression, clearly enjoying the slap. Her tail wags excitedly."
    narrator "She drinks a bit more water, still presenting her ass to you, then stands up with a shy but satisfied smile and disappears in a swirl of flames."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label braixen_event_5_narrative:
    narrator "That same night, you bring her to your room."
    narrator "Braixen looks at you with intense desire. She pushes you onto the bed and climbs on top of you in reverse cowgirl position."
    narrator "She grabs her wooden branch and uses it to tease her own ass for a moment before setting it aside."
    show expression "images/pokemon/braixen/braixen_0.png" as cg_scene
    with fade
    narrator "She lowers herself onto your cock, taking you deep into her tight ass in one smooth motion. She lets out a loud moan as she starts riding you hard in reverse cowgirl."
    narrator "Her plump, round ass bounces vigorously on your cock, the sight of her fluffy tail and jiggling cheeks filling your view."
    narrator "She rides you faster and deeper, using her strong legs while moaning with pleasure."
    narrator "Her body trembles as she fucks you anally with passion until you both reach a powerful climax."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return


# ============================================================
# MEOWSCARADA
# ============================================================

label meowscarada_event_1_narrative:
    show expression "images/pokemon/meowscarada/meowscarada_1.png" as cg_scene
    with fade
    narrator "You walk through the moonlit forest at night."
    narrator "Among the shadows, you spot a figure performing elegant tricks. Meowscarada spins gracefully, her flower mask glowing faintly as she creates small illusions of sparkling lights around her."
    narrator "Her slender, curvaceous body moves with feline elegance, her tail swaying playfully."
    narrator "You get closer to watch."
    narrator "Suddenly she notices you. With a mischievous grin, she blows a kiss made of pink petals toward you and vanishes in a swirl of illusory flowers."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meowscarada_event_2_narrative:
    show expression "images/pokemon/meowscarada/meowscarada_2.png" as cg_scene
    with fade
    narrator "You encounter her again in the forest."
    narrator "This time Meowscarada is in a very playful mood. She circles around you, brushing her tail against your body teasingly and lightly dragging her claws across your chest."
    narrator "he seems to be testing how well you handle her flirtatious and overwhelming playfulness."
    narrator "You manage to keep calm and respond confidently to her teasing. She seems impressed and lets out a satisfied purr."
    narrator "She gives you one last firm bite on the neck before jumping back with a seductive smile and disappearing in a swirl of petals."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meowscarada_event_3_narrative:
    show expression "images/pokemon/meowscarada/meowscarada_3.png" as cg_scene
    with fade
    narrator "You find Meowscarada waiting for you in a hidden part of the forest."
    narrator "She suddenly drops to her knees in front of you. She looks up, opens her mouth invitingly, and closes her eyes, as if waiting for you to do something."
    narrator "Her expression is seductive and expectant."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meowscarada_event_3_narrative_post:
    show expression "images/pokemon/meowscarada/meowscarada_4.png" as cg_scene
    narrator "You slowly slide your thumb into her warm, wet mouth. She immediately starts sucking on it gently, her tongue swirling around it with clear pleasure."
    narrator "Soft purring sounds escape her throat as she enjoys it."
    narrator "After a few moments, she gives your thumb a firm, teasing bite."
    narrator "She opens her eyes with a mischievous grin, stands up, and disappears in a swirl of illusory petals."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meowscarada_event_4_narrative:
    narrator "You encounter Meowscarada again deep in the forest."
    narrator "She becomes visibly excited when she sees the Nebula Cabbage. Her tail sways eagerly as you offer it to her."
    show expression "images/pokemon/meowscarada/meowscarada_5.png" as cg_scene
    with fade
    narrator "She takes the round vegetable and drops to all fours right in front of you. She starts playing with it intensely, batting it around and pouncing on it like a toy."
    narrator "While chasing and rubbing against the cabbage, she grinds her hips and wet pussy against it shamelessly."
    narrator "Her ass sways provocatively with every movement, and soft moans escape her as she gets more aroused."
    narrator "She looks back at you with lustful eyes, clearly enjoying teasing you with the view."
    show expression "images/pokemon/meowscarada/meowscarada_6.png" as cg_scene
    with fade
    narrator "After several minutes of lewd play, she bites the cabbage hard, shivers with pleasure, and vanishes into the shadows with a mischievous purr."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meowscarada_event_5_narrative:
    narrator "The moment she emerges from the ball, her eyes burn with wild excitement. She pounces on you aggressively, pushing you down onto the forest floor."
    show expression "images/pokemon/meowscarada/meowscarada_7.png" as cg_scene
    with fade
    narrator "She quickly pulls down your pants and frees your hard cock. Without hesitation, she leans down and takes you into her warm, wet mouth."
    narrator "She sucks eagerly, coating your shaft with plenty of saliva, her tongue swirling around you as she bobs her head."
    show expression "images/pokemon/meowscarada/meowscarada_8.png" as cg_scene
    with fade
    narrator "Once she considers it wet enough, she climbs on top of you. She straddles your hips and lowers herself onto your cock in one smooth, hungry motion, taking you deep inside her tight pussy."
    narrator "She starts riding you hard and fast right there on the forest ground. Her claws dig into your chest as she bounces aggressively, moaning loudly while her tail lashes behind her."
    narrator "She fucks you with wild, needy energy until you both reach climax."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return


# ============================================================
# CINDERACE
# ============================================================

label cinderace_event_1_narrative:
    show expression "images/pokemon/cinderace/cinderace_1.png" as cg_scene
    with fade
    narrator "You hear powerful footsteps nearby."
    narrator "A tall Cinderace stands in a clearing, breathing heavily after training. Her athletic body is covered in sweat, highlighting her toned abs and strong, curvaceous legs."
    narrator "You step closer for a better look"
    show expression "images/pokemon/cinderace/cinderace_0.png" as cg_scene
    with fade
    narrator "Suddenly she notices you. Her crimson eyes sharpen. With a powerful kick and burst of flames, she dashes away at high speed."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label cinderace_event_2_narrative:
    show expression "images/pokemon/cinderace/cinderace_2.png" as cg_scene
    with fade
    narrator "You encounter Cinderace again in a clearing."
    narrator "She is struggling to move a large fallen tree blocking the path. Her powerful legs are straining as she pushes hard."
    narrator "You decide to help her. You grab the heavy trunk and try to lift or push it with her."
    narrator "Together you manage to move the heavy tree with ease. Cinderace looks at you with clear surprise and respect."
    show expression "images/pokemon/cinderace/cinderace_0.png"
    with fade
    narrator "She flexes her arms slightly."
    show expression "images/pokemon/cinderace/cinderace_3.png" as cg_scene
    with fade
    narrator "then dashes away in a burst of flames."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label cinderace_event_3_narrative:
    show expression "images/pokemon/cinderace/cinderace_4.png" as cg_scene
    with fade
    narrator "You find Cinderace in a secluded clearing."
    narrator "She is doing intense stretches. Her powerful legs are spread wide, and she bends forward, showing off her firm, round ass and toned thighs."
    narrator "Sweat glistens on her body, making her white and red fur shine. She looks strong and incredibly attractive."
    narrator "You get closer. She notices your presence but doesn’t run away this time. Instead, she looks back at you over her shoulder with a confident smirk."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label cinderace_event_3_narrative_post:
    show expression "images/pokemon/cinderace/cinderace_5.png" as cg_scene
    with fade
    narrator "You approach and gently slide your hand over her firm, muscular thigh. Her body tenses for a second, then relaxes. You feel the heat radiating from her fur and the strength in her leg."
    narrator "She pushes her ass back slightly against you, breathing heavier."
    narrator "A visible blush appears on her cheeks as she looks at you with fiery eyes full of desire."
    show expression "images/pokemon/cinderace/cinderace_0.png" as cg_scene
    with fade
    narrator "After a few moments she straightens up, gives you a teasing grin, and dashes away in a burst of flames."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label cinderace_event_4_narrative:
    show expression "images/pokemon/cinderace/cinderace_6.png" as cg_scene
    with fade
    narrator "You find Cinderace in the forest looking restless and hungry."
    narrator "She notices you and approaches quickly, her nose twitching as she smells your backpack. She leans in and sniffs around eagerly until she finds the Torchic drumstick."
    narrator "Her eyes light up with excitement. Her long ears perk up and her tail twitches rapidly."
    show expression "images/pokemon/cinderace/cinderace_7.png" as cg_scene
    with fade
    narrator "You take out the drumstick and offer it to her. She grabs it happily and sits down on the grass right in front of you."
    narrator "She spreads her strong legs slightly and begins eating. Juices drip down her chin as she devours the meat, looking very satisfied and content."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label cinderace_event_5_narrative:
    narrator "Cinderace was caught!"
    narrator "Later that night, you bring her to your room. The lights are dim."
    show expression "images/pokemon/cinderace/cinderace_8.png" as cg_scene
    with fade
    narrator "Cinderace looks at you with intense, heated eyes. Without saying a word, she pushes you gently onto the bed and climbs on top of you."
    narrator "She pulls down your pants, freeing your hard cock. With one strong hand she begins stroking you firmly and rhythmically. Her grip is tight and confident."
    narrator "She leans forward and presses her sweaty armpit directly against your face. The warm, musky scent of her after training fills your nose as she continues pumping your cock faster."
    narrator "Her strong thighs straddle you while her hand moves up and down with increasing speed."
    narrator "She keeps her armpit buried on your face, letting you breathe her scent deeply as she jerks you off intensely until you cum hard."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return


# ============================================================
# GOTHITELLE
# ============================================================

label gothitelle_event_1_narrative:
    narrator "You walk through a quiet, misty part of the forest at dusk."
    show expression "images/pokemon/gothitelle/gothitelle_1.png" as cg_scene
    with fade
    narrator "You notice Gothitelle standing among the trees. Her long black dress flows gently in the breeze, and her mature, elegant figure stands out in the soft light."
    narrator "She doesn't react when you step into her line of sight. It's impossible to tell whether she's ignoring you or simply already knows everything about you."
    narrator "She has a calm, almost motherly presence mixed with something darker and mysterious."
    narrator "She turns her head slowly and looks at you with deep, knowing eyes. For a moment she simply observes you in silence, as if studying something about you."
    narrator "Then she raises one hand slightly. A soft psychic aura surrounds her, and she disappears into the mist without a sound."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gothitelle_event_2_narrative:
    narrator "You encounter Gothitelle again in the misty forest."
    show expression "images/pokemon/gothitelle/gothitelle_2.png" as cg_scene
    with fade
    narrator "She is standing still under the shade of a large tree, her long black dress barely moving. When she notices you, she turns her head slowly and looks at you with calm, deep eyes."
    narrator "There is a quiet, superior presence about her, mixed with something almost caring."
    narrator "She studies you in silence for several seconds, as if measuring something only she can see."
    narrator "You stay calm and meet her gaze without looking away or acting nervous. Gothitelle’s expression softens just a little. A faint, almost approving smile appears on her lips."
    narrator "She continues watching you for a few more moments, her presence both protective and commanding, before she slowly turns and disappears into the mist."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gothitelle_event_3_narrative:
    show expression "images/pokemon/gothitelle/gothitelle_3.png" as cg_scene
    with fade
    narrator "You find Gothitelle sitting relaxed on a large fallen log in the misty forest."
    narrator "She is resting with her eyes half-closed, her long black dress draped elegantly around her. You stay and look at her for a moment."
    narrator "She notices your gaze. Without saying a word, she slowly lifts the side of her dress, revealing her enormous, thick thighs covered in fishnet stockings."
    narrator "She holds the fabric up just enough to give you a clear view, as if granting you a private favor."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gothitelle_event_3_narrative_post:
    narrator "You walk closer until you are standing right in front of her."
    show expression "images/pokemon/gothitelle/gothitelle_4.png" as cg_scene
    with fade
    narrator "Gothitelle looks up at you with calm, superior eyes. She gently takes your hand and places it on her thick thigh, guiding your fingers as you caress the soft, firm flesh under the black stockings."
    narrator "She keeps her hand over yours, controlling the movement while watching your reaction with quiet satisfaction."
    narrator "After several long moments she releases your hand, lets her dress fall back into place, and gives you a faint, approving smile before disappearing into the mist."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gothitelle_event_4_narrative:
    narrator "You encounter Gothitelle again in the misty forest."
    narrator "She takes the Colbur Berry from your hand without a word."
    show expression "images/pokemon/gothitelle/gothitelle_5.png" as cg_scene
    with fade
    narrator "Sitting down on the fallen log, she slowly lifts her long black dress and presses the spiked pink berry against her pussy through the thin fabric of her underwear."
    narrator "She starts grinding against it with slow, deliberate movements. Her breathing grows heavier and her thighs tense as she uses the berry like a rough toy."
    narrator "After a few minutes her body shivers and she reaches a quiet, controlled orgasm, soaking the berry with her juices."
    narrator "Still looking at you with calm, superior eyes, she brings the wet, glistening berry to your lips and gently pushes it into your mouth, making you taste her."
    narrator "Then she stands up, lets her dress fall back into place, and disappears into the mist."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label gothitelle_event_5_narrative:
    narrator "That night, you bring her to your room."
    narrator "She pushes you onto the bed and climbs on top of you in cowgirl position."
    show expression "images/pokemon/gothitelle/gothitelle_6.png" as cg_scene
    with fade
    narrator "Without removing her underwear, she pulls the fabric to the side and slowly lowers herself onto your hard cock, taking you deep inside her."
    narrator "She starts riding you with slow, controlled movements, her heavy breasts bouncing gently with every thrust. The fishnet stockings dig slightly into her thick thighs as she moves."
    narrator "She looks down at you with calm, superior eyes while she fucks you at her own pace, using you for her pleasure until she is fully satisfied."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return


# ============================================================
# TSAREENA
# ============================================================

label tsareena_event_1_narrative:
    narrator "You walk through a sunny clearing in the forest."
    show expression "images/pokemon/tsareena/tsareena_1.png" as cg_scene
    with fade
    narrator "You see Tsareena standing tall and elegant. She is practicing powerful kicks, her long legs slicing through the air with precision."
    narrator "Her body is athletic and curvy, with thick thighs and a proud posture. Her crown-like hair bounces slightly with each movement."
    narrator "You get closer to watch."
    narrator "Suddenly she notices you. She stops mid-kick, turns her head with a cold, assessing look, and then kicks the ground hard enough to create a small dust cloud. When the dust settles, she is already gone."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label tsareena_event_2_narrative:
    narrator "You encounter Tsareena again in a sunny clearing."
    show expression "images/pokemon/tsareena/tsareena_2.png" as cg_scene
    with fade
    narrator "She is sitting elegantly on a high rock, looking down at you with pure arrogance. She gestures with one finger for you to approach."
    narrator "When you get close, she slowly places one elegant foot on your chest and pushes you slightly backward. Her eyes study your face carefully, testing how you react to her dominance."
    narrator "You stay calm and meet her gaze without flinching. Tsareena raises an eyebrow and lets out a soft, amused laugh."
    narrator "She presses her foot a little harder for a moment, clearly enjoying the control, then removes it with elegant grace."
    narrator "She gives you a slow, approving look before standing up and walking away, her hips swaying with deliberate arrogance."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label tsareena_event_3_narrative:
    narrator "You find Tsareena in a quiet sunny clearing."
    show expression "images/pokemon/tsareena/tsareena_3.png" as cg_scene
    with fade
    narrator "She walks over with elegant arrogance and places her foot firmly on your chest, pushing you down onto the grass. She stands over you, looking down with a dominant smirk."
    narrator "Her thick thighs and powerful legs frame your face. She slowly grinds the sole of her foot against your chest, clearly enjoying the control."
    narrator "Her expression is arrogant but slightly heated."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label tsareena_event_3_narrative_post:
    show expression "images/pokemon/tsareena/tsareena_4.png" as cg_scene
    with fade
    narrator "You remain still and meet her gaze without resistance. Tsareena’s smirk deepens. She slowly slides her foot down from your chest, over your stomach, until the sole rests right against your crotch."
    narrator "She starts grinding firmly against your cock through your pants, clearly feeling it harden under her foot."
    narrator "A pleased, aroused expression appears on her face as she notices the erection she is causing. She continues rubbing slowly and deliberately for several long seconds, enjoying the control and your reaction, before finally lifting her foot."
    narrator "She gives you one last dominant, satisfied look and walks away with her hips swaying."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label tsareena_event_4_narrative:
    narrator "You encounter Tsareena again in a sunny clearing."
    show expression "images/pokemon/tsareena/tsareena_5.png" as cg_scene
    with fade
    narrator "She notices the Solar Carrot in your hand and walks over with her usual arrogant confidence. She takes it from you without asking."
    narrator "She sits down elegantly in front of you and starts eating the carrot in a deliberately slow and lewd way. She wraps her lips around the tip, sucks on it, and takes it deeper into her mouth while looking straight at you."
    narrator "The way she works her tongue and lips makes it look exactly like she is sucking a cock."
    narrator "Watching her makes you get hard almost immediately. Tsareena notices the growing bulge in your pants and smirks with clear satisfaction."
    show expression "images/pokemon/tsareena/tsareena_6.png" as cg_scene
    with fade
    narrator "Once she finishes the carrot, she leans forward, pulls your pants down, and takes your hard cock into her mouth."
    narrator "She starts sucking you with the same slow, dominant rhythm she used on the carrot, looking up at you with arrogant, aroused eyes while she gives you a skilled blowjob."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label tsareena_event_5_narrative:
    narrator "That night, you bring her home. In your bedroom, Tsareena looks at you with calm, dominant eyes. She pushes you down onto the bed and sits on your lap, facing you."
    show expression "images/pokemon/tsareena/tsareena_7.png" as cg_scene
    with fade
    narrator "She presses her thick, soft thighs around your cock and starts moving them up and down in a slow, controlled thighjob. Her powerful legs squeeze you tightly while she looks down at you with an arrogant smile."
    narrator "She keeps the rhythm steady until you cum, completely relaxed and drained between her thighs."
    narrator "When you try to sit up, she places a firm hand on your chest and pushes you back down."
    show expression "images/pokemon/tsareena/tsareena_8.png" as cg_scene
    with fade
    narrator "She turns around into reverse cowgirl position and slowly lowers herself onto your still-sensitive cock. She starts riding you with deep, deliberate movements, using her strong legs to control the pace."
    narrator "All night long she keeps mounting you, grinding and bouncing until she is fully satisfied, milking every last drop from you."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return


# ============================================================
# PRIMARINA
# ============================================================

label primarina_event_1_narrative:
    show expression "images/pokemon/primarina/primarina_1.png" as cg_scene
    with fade
    narrator "You walk near a beautiful river in the forest at dusk."
    narrator "You hear a lovely singing voice. In the water, you see Primarina gracefully swimming and performing."
    narrator "She spins elegantly, her long hair and tail flowing in the water, her curvaceous body partially visible above the surface."
    narrator "Her voice is hypnotic and beautiful."
    narrator "You get closer to listen better."
    narrator "Suddenly she notices you. She stops singing, looks at you with surprised but intrigued eyes, and disappears underwater with a graceful splash, leaving only ripples behind."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label primarina_event_2_narrative:
    show expression "images/pokemon/primarina/primarina_2.png" as cg_scene
    with fade
    narrator "You encounter Primarina again near the riverbank."
    narrator "She is on dry land, struggling to drag herself back to the water."
    narrator "Her long tail and body are heavy out of water. She looks tired and uncomfortable, moving slowly across the ground."
    show expression "images/pokemon/primarina/primarina_3.png" as cg_scene
    with fade
    narrator "You decide to help her. You approach and lift her powerful, curvaceous body into your arms."
    narrator "You easily lift Primarina as if she weighed nothing. She looks surprised at first, then relaxes in your arms."
    narrator "Her soft, smooth skin and heavy breasts press against your chest as you carry her. She gives you a grateful, slightly flustered look."
    narrator "You gently place her back in the river. She swims gracefully for a moment, then looks back at you with a warm smile before diving underwater."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label primarina_event_3_narrative:
    show expression "images/pokemon/primarina/primarina_4.png" as cg_scene
    with fade
    narrator "You find Primarina sitting on the riverbank, half in the water."
    narrator "Her body is wet and glistening. Her massive, heavy breasts are fully exposed, dripping with water and bouncing slightly with her breathing."
    narrator "She looks at you with seductive eyes and slowly lifts her breasts with her arms, offering them to you."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label primarina_event_3_narrative_post:
    show expression "images/pokemon/primarina/primarina_5.png" as cg_scene
    with fade
    narrator "You kneel down and take one of her huge, soft breasts into your mouth. You suck hungrily on her nipple while groping the other heavy tit."
    narrator "Primarina moans loudly, holding your head against her chest as her body trembles with pleasure. Her breasts feel incredibly soft and heavy in your hands."
    narrator "After several minutes of intense sucking and licking, she lets out a sweet, melodic moan and reaches orgasm just from your mouth."
    narrator "She looks at you with flushed cheeks and a satisfied smile before diving gracefully back into the river."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label primarina_event_4_narrative:
    show expression "images/pokemon/primarina/primarina_6.png" as cg_scene
    with fade
    narrator "You encounter Primarina near the river again."
    narrator "She looks hungry. When you take out the dead Magikarp, her eyes light up with excitement."
    narrator "You offer her the fresh fish. She takes it happily and sits on a rock by the water."
    show expression "images/pokemon/primarina/primarina_7.png" as cg_scene
    with fade
    narrator "She begins eating the Magikarp with delight, juices dripping down her chin and onto her massive breasts."
    narrator "While eating, she presses her heavy, soft tits together, letting the fish juices run between her cleavage. She looks at you seductively as she continues eating, deliberately making a mess on her chest."
    narrator "Once she finishes, she stands up, her big glistening breasts covered in juices. She gives you a playful smile and dives gracefully into the river."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label primarina_event_5_narrative:
    narrator "Later that evening, you take her to a beautiful beach at sunset."
    show expression "images/pokemon/primarina/primarina_8.png" as cg_scene
    with fade
    narrator "The sky is orange and pink. Primarina looks at you with seductive eyes. She gently pushes you to sit on the sand near the water and kneels between your legs."
    narrator "She pulls down your pants and frees your hard cock. She presses her massive, soft breasts around your shaft, completely enveloping it in warm, heavy titflesh. She begins moving her tits up and down in a slow, rhythmic titjob, her nipples brushing against you."
    narrator "The waves gently lap at your feet as she increases the speed, squeezing her breasts tighter around your cock."
    narrator "She looks up at you with a pleased, melodic moan while giving you an intense, slippery titjob until you cum hard between her huge breasts."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return


# ============================================================
# VAPOREON
# ============================================================

label vaporeon_event_1_narrative:
    narrator "You walk near a clear river in the forest."
    show expression "images/pokemon/vaporeon/vaporeon_1.png" as cg_scene
    with fade
    narrator "You see Vaporeon playing in the water. Her sleek, blue body glistens under the sunlight as she swims and splashes around. Her long, elegant tail moves gracefully through the current."
    show expression "images/pokemon/vaporeon/vaporeon_2.png" as cg_scene
    with fade
    narrator "She notices you watching. With a playful look, she swings her powerful tail hard against the water’s surface, sending a big splash that completely soaks you."
    narrator "Before you can react, she dives underwater and disappears downstream, leaving only ripples behind."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label vaporeon_event_2_narrative:
    narrator "You encounter Vaporeon again near the river."
    show expression "images/pokemon/vaporeon/vaporeon_3.png" as cg_scene
    with fade
    narrator "She is playing in the water when she notices you. With a mischievous and seductive smile, she suddenly rushes toward you and grabs your arm, trying to pull you into the water."
    narrator "You plant your feet firmly and resist her pull. Vaporeon loses her balance and falls into the water herself with a big splash. She comes back up laughing, her sleek body glistening."
    show expression "images/pokemon/vaporeon/vaporeon_2.png" as cg_scene
    with fade
    narrator "Still smiling playfully, she swings her powerful tail and hits the water hard, sending another big splash that soaks you completely."
    narrator "Then she dives under and swims away downstream, still laughing."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label vaporeon_event_3_narrative:
    show expression "images/pokemon/vaporeon/vaporeon_4.png" as cg_scene
    with fade
    narrator "You find Vaporeon happily rolling on the soft grass, lying on her back with her belly exposed."
    narrator "Her sleek blue body stretches out as she enjoys the sun."
    narrator "When she notices you, she stops and looks at you with clear expectation."
    show expression "images/pokemon/vaporeon/vaporeon_5.png" as cg_scene
    with fade
    narrator "She makes a small beckoning gesture with her finger, inviting you to come closer."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label vaporeon_event_3_narrative_post:
    show expression "images/pokemon/vaporeon/vaporeon_6.png" as cg_scene
    with fade
    narrator "You walk over and gently stroke her soft, warm belly."
    narrator "Vaporeon lets out a happy, almost purring sound and stretches even more under your hand."
    narrator "She clearly enjoys the attention, her legs relaxing and her tail swaying slowly."
    narrator "After a few moments of content belly rubs, she looks up at you with a seductive, satisfied smile, then rolls over and hops away toward the river."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label vaporeon_event_4_narrative:
    narrator "You walk through the forest without noticing her presence."
    show expression "images/pokemon/vaporeon/vaporeon_7.png" as cg_scene
    with fade
    narrator "When you set your backpack down on the ground for a moment, Vaporeon suddenly dashes out from the bushes. She snatches the Oran Berry from your bag in a flash and crouches low on the grass."
    narrator "She quickly eats the berry right there on the ground, her tail swaying happily. Once she finishes, she looks up at you with a mischievous, playful smile and a soft laugh."
    narrator "Then she hops away toward the river and disappears into the water."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label vaporeon_event_5_narrative:
    narrator "Almost immediately, she comes out of the PokéBall on her own, looking extremely happy."
    narrator "With a playful and excited expression, she grabs your arm and quickly pulls you toward the river. This time she succeeds easily and both of you fall into the water."
    show expression "images/pokemon/vaporeon/vaporeon_8.png" as cg_scene
    with fade
    narrator "Still smiling, she pulls down your pants underwater and frees your cock. Without wasting time, she straddles you right there in the river and lowers herself onto you, taking your full length inside her."
    narrator "She starts riding you with energetic, enthusiastic movements, water splashing around both of you as her sleek body moves up and down."
    narrator "She holds onto your shoulders and continues riding you happily in the river until she is fully satisfied."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

# ============================================================
# HATTERENE
# ============================================================
label hatterene_event_1_narrative:
    narrator "You walk through a quiet, shadowed part of the forest."
    show expression "images/pokemon/hatterene/hatterene_1.png" as cg_scene
    with fade
    narrator "Hatterene stands still between the trees, her massive hat-like hair covering most of her body. Only her pale face and sharp eyes are clearly visible. She watches you in complete silence."
    narrator "You take a few steps closer."
    narrator "A long lock of her hair slowly slides across the ground and wraps around your wrist, holding you in place. She studies you with a calm, seductive look, as if deciding whether you are worth her time."
    narrator "After a few seconds the hair unwraps and she fades back into the shadows, leaving only a faint floral scent behind."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label hatterene_event_2_narrative:
    narrator "You find Hatterene standing in a dead-quiet part of the forest."
    show expression "images/pokemon/hatterene/hatterene_2.png" as cg_scene
    with fade
    narrator "The protrusion on her hat glows faintly. A sudden image appears in your mind: your hand slowly reaching toward her face, then stroking her cheek with care. No words. Just that."
    narrator "You realize she is asking for a gentle touch, and testing whether you understand her without sound."
    show expression "images/pokemon/hatterene/hatterene_3.png" as cg_scene
    with fade
    narrator "You step closer in silence and gently brush your fingers along her cheek. Hatterene’s eyes close halfway."
    narrator "A lock of her hair curls around your wrist and holds you there while she leans into the caress."
    narrator "She stays like that for several seconds, clearly pleased. Then the hair unwraps and she fades back into the shadows."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label hatterene_event_3_narrative:
    narrator "You find Hatterene waiting in the shadows."
    show expression "images/pokemon/hatterene/hatterene_4.png" as cg_scene
    with fade
    narrator "Before you can move, several thick locks of her hair wrap around your arms and waist, holding you in place."
    narrator "She steps closer, her eyes half-lidded and clearly interested. More hair slides under your clothes, wraps around your cock, and starts stroking you slowly."
    narrator "She waits to see what you will do."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label hatterene_event_3_narrative_post:
    show expression "images/pokemon/hatterene/hatterene_5.png" as cg_scene
    with fade
    narrator "You stay quiet and let her continue."
    narrator "The hair tightens around your shaft and strokes you with a steady, wet rhythm, squeezing just enough to make you finish. You cum hard into the coiled strands."
    narrator "Hatterene lets out a small, happy giggle. The hair unwraps from your body, and she disappears into the dark."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label hatterene_event_4_narrative:
    narrator "You encounter Hatterene again in the quiet forest."
    narrator "The moment she sees you, her hat twitches and she leans toward your backpack. The strong scent coming from it clearly has her attention."
    show expression "images/pokemon/hatterene/hatterene_6.png" as cg_scene
    with fade
    narrator "You take your items out one by one until you find the Meteor Root. As soon as she sees it, her eyes lock onto it. You offer it to her."
    narrator "She takes the root and snaps it in half. A much stronger aroma fills the air. Her breathing turns heavy at once. The scent seems to hit her like an aphrodisiac."
    show expression "images/pokemon/hatterene/hatterene_7.png" as cg_scene
    with fade
    narrator "Hatterene sits down on the grass, legs spread wide, holding the broken root close to her face as she inhales. Her pussy is visibly wet, dripping onto the ground while she keeps smelling it."
    show expression "images/pokemon/hatterene/hatterene_8.png" as cg_scene
    with fade
    narrator "You kneel between her legs and start massaging her soaked folds with your fingers."
    narrator "She stays there trembling as you rub her, her juices running over your hand until her body finally shivers hard."
    narrator "Then the hair around her hat shifts, she stands, and she disappears back into the shadows."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label hatterene_event_5_narrative:
    narrator "Late that night, still in the forest, Hatterene steps out on her own."
    narrator "She raises one hand and casts a quiet spell. Soft lights bloom around the trees, turning the clearing into a dim, romantic glow."
    show expression "images/pokemon/hatterene/hatterene_9.png" as cg_scene
    with fade
    narrator "She leans forward against a tree, chest pressed to the bark, and looks back at you. Her long hair slides aside, leaving her ass and wet pussy fully exposed."
    narrator "You step behind her, grab her hips, and rub the head of your cock against her dripping entrance."
    show expression "images/pokemon/hatterene/hatterene_0.png" as cg_scene
    with fade
    narrator "Then you push in slowly, sinking into her tight, warm pussy until you are buried to the hilt. She shivers and pushes back onto you."
    narrator "You start thrusting from behind, each stroke slapping your hips against her ass. Her body rocks against the tree while her hair coils around your arms and waist, pulling you deeper."
    narrator "You fuck her harder, driving into her wet heat over and over, her juices running down her thighs."
    narrator "Her pussy clenches around your cock as she cums, trembling against the trunk. You keep pounding her through it until you finish inside her, filling her while the lights flicker around the two of you."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return
    
# ============================================================
# MELOETTA
# ============================================================

label meloetta_event_1_narrative:
    narrator "You hear a soft melody drifting through the forest."
    show expression "images/pokemon/meloetta/meloetta_1.png" as cg_scene
    with fade
    narrator "You follow the song until you reach a quiet clearing. Meloetta is standing there, eyes closed, singing with a gentle, beautiful voice."
    narrator "Her long green hair flows around her like a dress as she sways a little with the music."
    narrator "She opens her eyes and notices you. Her face turns red at once. She covers her mouth, looks away in embarrassment, and quickly disappears between the trees."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meloetta_event_2_narrative:
    narrator "You find Meloetta sitting on a rock in a quiet clearing. She looks bored and a little down, tapping her fingers without much energy."
    show expression "images/pokemon/meloetta/meloetta_2.png" as cg_scene
    with fade
    narrator "You try to encourage her to sing. She glances at you, then looks away, clearly unsure about performing in front of someone."
    narrator "You keep encouraging her gently, making it clear you want to hear her and that you are not going to laugh or judge. Meloetta’s cheeks turn pink. She looks flattered and a little more at ease."
    show expression "images/pokemon/meloetta/meloetta_1.png" as cg_scene
    with fade
    narrator "After a moment she stands up, takes a small breath, and starts singing just for you. Her voice fills the clearing, soft and beautiful."
    narrator "When the song ends, she gives you a shy, grateful smile before slipping away into the trees."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meloetta_event_3_narrative:
    show expression "images/pokemon/meloetta/meloetta_3.png" as cg_scene
    with fade
    narrator "You find Meloetta sitting in the grass, hugging her knees."
    narrator "When she sees you, she looks nervous but does not run. She pats the spot beside her, inviting you closer."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meloetta_event_3_narrative_post:
    narrator "You sit down next to her and softly take her hand."
    show expression "images/pokemon/meloetta/meloetta_4.png" as cg_scene
    with fade
    narrator "Meloetta tenses for a second, then relaxes. Her fingers curl around yours and she leans her head lightly against your shoulder."
    narrator "She stays like that for a while, quiet and comfortable, a small smile on her face. After a few moments she gives your hand a shy squeeze, stands up, and walks away looking happier."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meloetta_event_4_narrative:
    show expression "images/pokemon/meloetta/meloetta_5.png" as cg_scene
    with fade
    narrator "You find Meloetta sitting on a fallen log, one hand on her throat. She looks uncomfortable, and when she tries to hum, her voice comes out weak."
    narrator "You offer her a Citrus Berry. She takes it and eats it slowly. After a moment her expression softens. The soreness in her throat seems to ease."
    show expression "images/pokemon/meloetta/meloetta_6.png" as cg_scene
    with fade
    narrator "She looks at you with a grateful smile, then stands up to sing."
    narrator "This time her voice is clearer and more confident. While she sings, she sways her hips and lets her long green hair shift aside, showing more of her body."
    narrator "Her chest and waist stay in view as she moves, turning the song into something much more erotic than before."
    narrator "When she finishes, she gives you a shy but pleased look and disappears into the trees."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label meloetta_event_5_narrative:
    narrator "That night, in your room, Meloetta comes out of the Poke Ball on her own."
    narrator "Her face is already red. She avoids your eyes, walks up to the bed, and climbs onto your lap."
    show expression "images/pokemon/meloetta/meloetta_7.png" as cg_scene
    with fade
    narrator "She pulls your pants down just enough to free your cock, then sinks onto it slowly, taking you inside her with a shaky breath."
    narrator "Her long green hair falls forward and hides most of her face while she starts moving her hips."
    narrator "She rides you in a shy, needy rhythm, holding onto your chest and peeking at you through her hair."
    narrator "Even embarrassed, she keeps going, bouncing a little faster until she finishes on top of you and pulls you over the edge with her."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

# ============================================================
# ESPEON
# ============================================================

label espeon_event_1_narrative:
    show expression "images/pokemon/espeon/espeon_1.png" as cg_scene
    with fade
    narrator "You find Espeon resting in a patch of sunlight."
    narrator "She is lying on her side, elegant and alert, her lilac fur shining in the warmth. The red gem on her forehead glows faintly as soon as you step closer."
    narrator "Her forked tail flicks once, as if she already knows you are there."
    narrator "She lifts her head and looks at you with a proud, unimpressed stare. After a few seconds she stands, turns her back on you, and walks away into the trees without hurry."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label espeon_event_2_narrative:
    show expression "images/pokemon/espeon/espeon_2.png" as cg_scene
    with fade
    narrator "You find Espeon sitting in a patch of sunlight."
    narrator "She looks at the grass in front of you, then at your legs. Her forked tail taps the ground twice, and she lowers her chest as if waiting for a place to rest."
    show expression "images/pokemon/espeon/espeon_3.png" as cg_scene
    with fade
    narrator "You sit down. Espeon walks over at once and lays her head across your lap, nuzzling against you with a pleased look. Her eyes half-close while you stroke her lilac fur."
    narrator "She stays there for a while, warm and relaxed, her tail swaying slowly. Then she lifts her head, rubs her cheek against your hand, and walks away into the trees."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label espeon_event_3_narrative:
    show expression "images/pokemon/espeon/espeon_4.png" as cg_scene
    with fade
    narrator "You find Espeon stretched out in the sun, grooming her lilac fur."
    narrator "When she notices you, she does not run. She rolls onto her side, lifts one leg a little, and watches you with a proud, expectant look."
    narrator "Her tail flicks toward her belly and hip, as if telling you exactly where you are allowed to touch."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label espeon_event_3_narrative_post:
    show expression "images/pokemon/espeon/espeon_5.png" as cg_scene
    with fade
    narrator "You kneel down and run your hand over her warm belly and the curve of her hip."
    narrator "Espeon tenses first, then leans into your palm with a low, pleased sound."
    narrator "She presses her body against your hand, guiding you along her soft fur, closer to the inside of her thigh."
    narrator "She lets the contact linger, clearly enjoying it on her own terms. After a while she stands, rubs her cheek against your wrist once, and walks away with her tail held high."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label espeon_event_4_narrative:
    narrator "You find Espeon sitting in the sun again."
    show expression "images/pokemon/espeon/espeon_6.png" as cg_scene
    with fade
    narrator "She notices the Leppa Berry in your hand and her ears perk up. For once she drops a little of her pride and steps closer."
    narrator "You offer her the berry. She takes it carefully from your fingers and eats it with clear delight, her tail swaying as she chews."
    narrator "When she finishes, she looks satisfied and a bit happier than usual. She brushes past you, then walks away into the trees."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label espeon_event_5_narrative:
    narrator "That same afternoon, sunlight fills your room. Espeon comes out on her own and goes straight to the bed. She lies back at the edge, proud even now, and lifts one long leg against your chest."
    narrator "You step between her thighs and push into her slowly. Her lilac fur is warm under your hands. The gem on her forehead glows as you sink all the way in."
    narrator "She watches you the whole time, mouth open, too proud to look away."
    show expression "images/pokemon/espeon/espeon_7.png" as cg_scene
    with fade
    narrator "You hold her raised leg and start thrusting deep, the bed creaking under the rhythm. Her forked tail coils around your thigh and pulls you in harder."
    narrator "Each stroke makes her breasts move and her ears flatten against the sheets."
    narrator "She stays on her back at the edge of the bed, taking you in full view of the window light, her pussy tight and wet around your cock."
    narrator "When she finally cums, her tail squeezes you and she drags you over with her, still looking you in the eyes."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label zoroark_event_1_narrative:
    show expression "images/pokemon/zoroark/zoroark_1.png" as cg_scene
    with fade
    narrator "You walk through the dense forest when you spot someone who looks completely out of place."
    narrator "It's a girl with a distinct 'Gal' style."
    narrator "You approach her with curiosity and ask what she's doing in a place like this, but she doesn't respond."
    narrator "You try to get her attention again, but there is absolute silence."
    show expression "images/pokemon/zoroark/zoroark_2.png" as cg_scene
    with fade
    narrator "In a flash of light and smoke, the image of the girl vanishes, and in her place stands a Zoroark. Before you can say a word, she bolts, disappearing back into the trees."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label zoroark_event_2_narrative:
    show expression "images/pokemon/zoroark/zoroark_3.png" as cg_scene
    with fade
    narrator "As you continue exploring, a figure moves through the brush. It's her, in her original Zoroark form."
    narrator "She approaches you slowly and tries to put on a tough face."
    narrator "She attempts to create a small illusion to distract you, but the image flickers and vanishes almost instantly."
    narrator "She lets out a frustrated growl, realizing she hasn't fully mastered her ability, and leaves just like last time."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label zoroark_event_3_narrative:
    show expression "images/pokemon/zoroark/zoroark_4.png" as cg_scene
    with fade
    narrator "Rounding a bend in the path, the Gal girl appears before you again, looking more confident."
    narrator "Before you can react, she lunges forward with surprising agility, knocking you to the ground with the weight of her body."
    narrator "When you open your eyes, you find yourself in a vulnerable position. She has sat atop you, her legs crossed and pressed tightly against you."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label zoroark_event_3_narrative_post:
    show expression "images/pokemon/zoroark/zoroark_4.png" as cg_scene
    with fade
    narrator "You feel the searing heat of her tanned skin. Without warning, you realize your pants have been pushed aside and your dick is already trapped between her thighs."
    narrator "She begins to rub against you in a slow, rhythmic motion. You can feel the pressure of her thighs squeezing your cock."
    narrator "The girl's soft gasps fill the air as she presses her yours. Just as you are about to lose control, she tenses."
    show expression "images/pokemon/zoroark/zoroark_5.png" as cg_scene
    with fade
    narrator "The illusion shatters; you watch as the girl reverts to her Zoroark form while still playing with your cock."
    narrator "Overcome with shame, she abruptly stands up and vanishes into the undergrowth, leaving you panting and completely aroused."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label zoroark_event_4_narrative:
    narrator "You find Zoroark again in her Pokémon form. She seems withdrawn, as if expecting you to reject her because of her appearance."
    narrator "Instead of backing away, you open your bag and offer's her a Lum Berry. She looks the food surprised by your kindness."
    show expression "images/pokemon/zoroark/zoroark_6.png" as cg_scene
    with fade
    narrator "Suddenly, she kneels before you. With surprising delicacy, she takes your dick into her mouth."
    narrator "The sensation is incredible; her tongue is rough yet expert, wrapping around your glans with a powerful, rhythmic suction."
    show expression "images/pokemon/zoroark/zoroark_7.png" as cg_scene
    with fade
    narrator "She strives to give you pleasure, sucking hard until you finally reach your climax and filling her mouth."
    narrator "She licks her lips with satisfaction, having sealed a bond of trust with you."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return

label zoroark_event_5_narrative:
    narrator "She comes out of the Poké Ball on her Gal girl form and knocks you onto your back before you can stand."
    show expression "images/pokemon/zoroark/zoroark_8.png" as cg_scene
    with fade
    narrator "She positions herself over you and, with a decisive movement, guides your erection into her entrance."
    narrator "She drops onto you in one fluid motion, leaving you buried deep inside her."
    narrator "She begins to ride you with unfettered passion, her hips crashing against yours in a frenetic rhythm."
    show expression "images/pokemon/zoroark/zoroark_9.png" as cg_scene
    with fade
    narrator "As you penetrate her, she quickly shifts into her Zoroark form, making the sex more intense."
    narrator "Your hands grip her hips, pushing her down as she arches her back."
    narrator "Both of you hit the limit at the same time, exploding in a violent orgasm that leaves you exhausted, finally united by absolute pleasure."
    hide cg_scene
    with dissolve
    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    return
# ============================================================
# FALLBACK — no post narrative
# ============================================================

label forest_choice_no_post:
    return
