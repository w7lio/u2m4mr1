# ============================================================
# POKETOWN — screens.rpy
# All game screens and UI
# ============================================================
# ------------------------------------------------------------
# HUD — Always visible during gameplay
# Shows current time slot, day and money
# ------------------------------------------------------------
screen hud():
    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40


# ------------------------------------------------------------
# ROUTE SELECTION — Shown at game start
# Player can block routes they don't want to see
# ------------------------------------------------------------
screen route_selection_screen():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 700
        ypadding 40
        xpadding 40
        background "#111111EE"

        vbox:
            spacing 20

            text "Welcome to Poketown" size 32 bold True xalign 0.5 color "#FFD700"
            text "Some character routes contain Furry on human content." size 22 xalign 0.5 color "#CCCCCC"
            text "You can disable any route below." size 22 xalign 0.5 color "#CCCCCC"

            null height 20

            # One toggle per character
            for char_id in unlocked_routes:
                hbox:
                    spacing 20
                    xalign 0.5
                    text char_id.capitalize() size 22 color "#FFFFFF" xminimum 200
                    textbutton ("Enabled" if unlocked_routes[char_id] else "Disabled"):
                        action ToggleDict(unlocked_routes, char_id)
                        text_color ("#90EE90" if unlocked_routes[char_id] else "#E74C3C")

            null height 20

            textbutton "Start Game":
                xalign 0.5
                action Return()
                text_size 26
                text_color "#FFD700"
                text_outlines [(2, "#000000", 0, 0)]

# ------------------------------------------------------------
# CONTENT PREFERENCES SCREEN
# Used both at game start and in phone settings
# ------------------------------------------------------------
screen content_preferences_screen(during_game=False):
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 700
        ypadding 40
        xpadding 40
        background "#111111EE"

        vbox:
            xalign 0.5
            spacing 20

            text "Content Preferences" size 32 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            text "Choose what content you want to see." size 22 xalign 0.5 color "#CCCCCC"

            null height 20

            # One toggle per tag
            hbox:
                spacing 20
                xalign 0.5
                text "Incest" size 22 color "#FFFFFF" xminimum 250
                textbutton ("Enabled" if content_tags["Incest"] else "Disabled"):
                    action ToggleDict(content_tags, "Incest")
                    text_color ("#90EE90" if content_tags["Incest"] else "#E74C3C")

            hbox:
                spacing 20
                xalign 0.5
                text "BDSM" size 22 color "#FFFFFF" xminimum 250
                textbutton ("Enabled" if content_tags["BDSM"] else "Disabled"):
                    action ToggleDict(content_tags, "BDSM")
                    text_color ("#90EE90" if content_tags["BDSM"] else "#E74C3C")

            hbox:
                spacing 20
                xalign 0.5
                text "Furry on human" size 22 color "#FFFFFF" xminimum 250
                textbutton ("Enabled" if content_tags["Furry on human"] else "Disabled"):
                    action ToggleDict(content_tags, "Furry on human")
                    text_color ("#90EE90" if content_tags["Furry on human"] else "#E74C3C")

            hbox:
                spacing 20
                xalign 0.5
                text "Human on furry" size 22 color "#FFFFFF" xminimum 250
                textbutton ("Enabled" if content_tags["Human on furry"] else "Disabled"):
                    action ToggleDict(content_tags, "Human on furry")
                    text_color ("#90EE90" if content_tags["Human on furry"] else "#E74C3C")

            hbox:
                spacing 20
                xalign 0.5
                text "Prostitution" size 22 color "#FFFFFF" xminimum 250
                textbutton ("Enabled" if content_tags["Prostitution"] else "Disabled"):
                    action ToggleDict(content_tags, "Prostitution")
                    text_color ("#90EE90" if content_tags["Prostitution"] else "#E74C3C")

            null height 20

            if during_game:
                textbutton "Confirm":
                    xalign 0.5
                    action [Hide("content_preferences_screen"), Show("phone_settings")]
                    text_size 26
                    text_color "#FFD700"
                    text_outlines [(2, "#000000", 0, 0)]
            else:
                textbutton "Confirm":
                    xalign 0.5
                    action Return()
                    text_size 26
                    text_color "#FFD700"
                    text_outlines [(2, "#000000", 0, 0)]
# ------------------------------------------------------------
# ROUTE SELECTION — Game start only
# ------------------------------------------------------------
screen route_selection_screen():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 700
        ypadding 40
        xpadding 40
        background "#111111EE"

        vbox:
            spacing 20

            text "Welcome to Poketown" size 32 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            text "You can disable specific character routes below." size 22 xalign 0.5 color "#CCCCCC"

            null height 20

            for char_id in unlocked_routes:
                hbox:
                    spacing 20
                    xalign 0.5
                    text char_id.capitalize() size 22 color "#FFFFFF" xminimum 200
                    textbutton ("Enabled" if unlocked_routes[char_id] else "Disabled"):
                        action ToggleDict(unlocked_routes, char_id)
                        text_color ("#90EE90" if unlocked_routes[char_id] else "#E74C3C")

            null height 20

            textbutton "Next — Content Preferences":
                xalign 0.5
                action Return()
                text_size 24
                text_color "#FFD700"
                text_outlines [(2, "#000000", 0, 0)]
# ------------------------------------------------------------
# PHONE — Main screen
# ------------------------------------------------------------
screen phone_screen():
    modal True
    add "images/ui/phone.png"
    # Phone frame
    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 0

            # Status bar
            frame:
                xfill True
                ysize 50
                background "#22222200"
                padding (15, 10)    
                hbox:
                    spacing 20
                    xalign 0.5
                    text "Day [current_day]" size 18 color "#FFFFFF"
                    text slot_names[current_slot] size 18 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 20

            text "POKETOWN" size 24 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 20

            hbox:
                spacing 20
                xalign 0.5

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "📊":
                        xalign 0.5
                        action Show("phone_stats")
                        text_size 36
                    text "Stats" size 16 xalign 0.5 color "#FFFFFF"

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "📅":
                        xalign 0.5
                        action Show("phone_agenda")
                        text_size 36
                    text "Agenda" size 16 xalign 0.5 color "#FFFFFF"

            null height 15

            hbox:
                spacing 20
                xalign 0.5

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "💡":
                        xalign 0.5
                        action Show("phone_hints")
                        text_size 36
                    text "Hints" size 16 xalign 0.5 color "#FFFFFF"

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "🎒":
                        xalign 0.5
                        action Show("phone_inventory")
                        text_size 36
                    text "Inventory" size 16 xalign 0.5 color "#FFFFFF"

            null height 15

            hbox:
                spacing 20
                xalign 0.5

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "📋":
                        xalign 0.5
                        action Show("phone_missions")
                        text_size 36
                    text "Missions" size 16 xalign 0.5 color "#FFFFFF"

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "📖":
                        xalign 0.5
                        action Show("phone_pokedex")
                        text_size 36
                    text "Pokedex" size 16 xalign 0.5 color "#FFFFFF"

            null height 15

            hbox:
                spacing 20
                xalign 0.5

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "🖼️":
                        xalign 0.5
                        action Show("phone_gallery")
                        text_size 36
                    text "Gallery" size 16 xalign 0.5 color "#FFFFFF"

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "🍳":
                        xalign 0.5
                        action Show("phone_recipes")
                        text_size 36
                    text "Recipes" size 16 xalign 0.5 color "#FFFFFF"

            null height 20

            hbox:
                spacing 20
                xalign 0.5

                vbox:
                    xsize 140
                    spacing 5
                    textbutton "📅":
                        xalign 0.5
                        action Show("phone_schedule")
                        text_size 36
                    text "Schedule" size 16 xalign 0.5 color "#FFFFFF"
                
                vbox:
                    xsize 140
                    spacing 5
                    textbutton "⚙️":
                        xalign 0.5
                        action Show("phone_settings")
                        text_size 36
                    text "Settings" size 16 xalign 0.5 color "#FFFFFF"

            button:
                xalign 0
                yoffset -3
                background "#00000000"
                hover_background "#00000000"
                action Hide("phone_screen")
                add "images/ui/icons/void.png" xsize 50 ysize 50
# ------------------------------------------------------------
# PHONE — Settings
# ------------------------------------------------------------
screen phone_settings():
    modal True
    add "images/ui/phone.png"
    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            xalign 0.5
            spacing 15

            text "⚙️ Settings" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 10

            textbutton "Save Game":
                xalign 0.5
                action ShowMenu("save")
                text_size 22
                text_color "#FFFFFF"

            textbutton "Load Game":
                xalign 0.5
                action ShowMenu("load")
                text_size 22
                text_color "#FFFFFF"

            textbutton "Main Menu":
                xalign 0.5
                action MainMenu()
                text_size 22
                text_color "#FFFFFF"

            textbutton "How to Play":
                xalign 0.5
                action ShowMenu("help")
                text_size 22
                text_color "#FFFFFF"
            
            textbutton "Enter Code":
                xalign 0.5
                action Show("cheat_code_screen")
                text_size 22
                text_color "#FFFFFF"

            textbutton ("Capture: Easy" if capture_difficulty == "easy" else "Capture: Normal"):
                xalign 0.5
                action If(
                    capture_difficulty == "easy",
                    true=SetVariable("capture_difficulty", "normal"),
                    false=SetVariable("capture_difficulty", "easy")
                )
                text_size 22
                text_color "#FFFFFF"

            null height 10
            button:
                xalign 0
                yoffset 130
                xoffset -43
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_settings"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50
# ------------------------------------------------------------
# PHONE — Hint System
# ------------------------------------------------------------
screen phone_hints():
    modal True
    add "images/ui/phone.png"

    default selected_char = None

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            xalign 0.5

            text "💡 Hints" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90"

            null height 5

            frame:
                xfill True
                ysize 280
                background "#22222200"
                padding (10, 10)

                viewport:
                    xalign 0.5
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    xfill True
                    yfill True

                    vbox:
                        spacing 10
                        xalign 0.5

                        $ chars = list(hint_state.keys())
                        $ rows  = (len(chars) + 2) // 3

                        for row in range(rows):
                            hbox:
                                spacing 10
                                xalign 0.5
                                for col in range(3):
                                    $ idx = row * 3 + col
                                    if idx < len(chars):
                                        $ cc = chars[idx]
                                        button:
                                            xsize 95
                                            ysize 110
                                            background ("#FFD70033" if selected_char == cc else "#00000000")
                                            hover_background "#FFD70022"
                                            action SetScreenVariable("selected_char", cc)
                                            vbox:
                                                xalign 0.5
                                                yalign 0.5
                                                spacing 4
                                                add ("images/ui/icons/" + cc + ".png") zoom 0.5 xalign 0.5
                                                text cc.capitalize() size 13 xalign 0.5 color "#FFD700"

            null height 8

            frame:
                xfill True
                ysize 220
                background "#22222200"
                padding (15, 15)

                if selected_char is None:
                    text "Select a character\nto view their hint." size 18 color "#666666" xalign 0.5 yalign 0.5
                else:
                    $ hs   = hint_state[selected_char]
                    $ hint = get_current_hint(selected_char)
                    vbox:
                        spacing 12
                        xalign 0.5

                        hbox:
                            spacing 10
                            xalign 0.5
                            text selected_char.capitalize() size 22 bold True color "#FFFFFF"
                            text ("Event " + str(hs["current_hint"] + 1)) size 17 color "#888888" yalign 1.0

                        if hint is None:
                            text "✅ All events completed!" size 18 color "#90EE90" xalign 0.5
                        elif hs["hint_purchased"]:
                            frame:
                                xfill True
                                background "#1a2e1a00"
                                padding (12, 10)
                                text hint size 17 color "#fdfdfd" line_leading 3 xoffset 45 yoffset -20
                        else:
                            vbox:
                                spacing 12
                                xalign 0.5
                                text ("💡 Hint cost: $" + str(hs["hint_cost"])) size 18 color "#FFD700" xalign 0.5
                                textbutton "Buy Hint":
                                    xalign 0.5
                                    sensitive money >= hs["hint_cost"]
                                    action Function(buy_hint, selected_char)
                                    text_size 18
                                    text_color ("#90EE90" if money >= hs["hint_cost"] else "#555555")

            null height 5

            button:
                xalign 0
                yoffset 26
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_hints"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50

# ------------------------------------------------------------
# PHONE — Stats
# ------------------------------------------------------------
screen phone_stats():
    modal True
    add "images/ui/phone.png"
    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 20
            xalign 0.5

            text "📊 Stats" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 10

            # Physique
            frame:
                xfill True
                background "#22222200"
                padding (20, 15)
                vbox:
                    spacing 8
                    hbox:
                        spacing 10
                        text "💪" size 24
                        text "Physique" size 22 bold True color "#FFFFFF"
                        text str(stat_physique) size 22 color "#FFD700" xalign 1.0 outlines [(2, "#000000", 0, 0)]
                    bar:
                        value stat_physique
                        range 100
                        xsize 320
                        ysize 14

            # Charisma
            frame:
                xfill True
                background "#22222200"
                padding (20, 15)
                vbox:
                    spacing 8
                    hbox:
                        spacing 10
                        text "💬" size 24
                        text "Charisma" size 22 bold True color "#FFFFFF"
                        text str(stat_charisma) size 22 color "#FFD700" xalign 1.0 outlines [(2, "#000000", 0, 0)]
                    bar:
                        value stat_charisma
                        range 100
                        xsize 320
                        ysize 14

            # Intelligence
            frame:
                xfill True
                background "#22222200"
                padding (20, 15)
                vbox:
                    spacing 8
                    hbox:
                        spacing 10
                        text "🧠" size 24
                        text "Intelligence" size 22 bold True color "#FFFFFF"
                        text str(stat_intelligence) size 22 color "#FFD700" xalign 1.0 outlines [(2, "#000000", 0, 0)]
                    bar:
                        value stat_intelligence
                        range 100
                        xsize 320
                        ysize 14

            null height 10

            # Money
            frame:
                xfill True
                background "#22222200"
                padding (20, 15)
                hbox:
                    spacing 10
                    xalign 0.5
                    text "💰" size 24
                    text "Money" size 22 bold True color "#FFFFFF"
                    text ("$" + str(money)) size 22 bold True color "#90EE90" xalign 1.0

            # Day info
            frame:
                xfill True
                background "#22222200"
                padding (20, 15)
                hbox:
                    spacing 10
                    xalign 0.5
                    text "📅" size 24
                    text "Day" size 22 bold True color "#FFFFFF"
                    text str(current_day) size 22 color "#FFD700" xalign 1.0 outlines [(2, "#000000", 0, 0)]

            button:
                xalign 0
                yoffset -18
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_stats"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50

# ------------------------------------------------------------
# PHONE — Inventory
# ------------------------------------------------------------
screen phone_inventory():
    modal True
    add "images/ui/phone.png"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🎒 Inventory" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 5

            viewport:
                xoffset 10
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 336
                ysize 490
                xalign 0.5
                

                vbox:
                    xalign 0.5
                    spacing 15

                    # Key Items
                    text "🔑 Key Items" size 22 bold True color "#FFD700" outlines [(2, "#000000", 0, 0)]
                    if len(inventory_key_items) == 0:
                        text "Empty" size 18 color "#555555"
                    else:
                        for item in inventory_key_items:
                            frame:
                                xalign 0.0
                                xfill True
                                background "#22222200"
                                padding (15, 10)
                                hbox:
                                    xalign 0.5
                                    spacing 10
                                    text item["icon"] size 22
                                    vbox:
                                        xalign 0.5
                                        spacing 2
                                        text item["name"] size 20 bold True color "#FFFFFF"
                                        text item["description"] size 16 color "#CCCCCC"

                    null height 5

                    # Gifts
                    text "🎁 Gifts" size 22 bold True color "#FFD700" outlines [(2, "#000000", 0, 0)]
                    if len(inventory_gifts) == 0:
                        text "Empty" size 18 color "#555555"
                    else:
                        for item in inventory_gifts:
                            frame:
                                xalign 0.0
                                xfill True
                                background "#22222200"
                                padding (15, 10)
                                hbox:
                                    xalign 0.5
                                    spacing 10
                                    text item["icon"] size 22
                                    vbox:
                                        xalign 0.5
                                        spacing 2
                                        text item["name"] size 20 bold True color "#FFFFFF"
                                        text ("x" + str(item["quantity"])) size 16 color "#FFD700" outlines [(2, "#000000", 0, 0)]

                    null height 5

                    # Clothing
                    text "👗 Clothing" size 22 bold True color "#FFD700" outlines [(2, "#000000", 0, 0)]
                    if len(inventory_clothing) == 0:
                        text "Empty" size 18 color "#555555"
                    else:
                        for item in inventory_clothing:
                            frame:
                                xalign 0.0
                                xfill True
                                background "#22222200"
                                padding (15, 10)
                                hbox:
                                    xalign 0.5
                                    spacing 10
                                    text item["icon"] size 22
                                    vbox:
                                        xalign 0.5
                                        spacing 2
                                        text item["name"] size 20 bold True color "#FFFFFF"
                                        text item["character"].capitalize() size 16 color "#CCCCCC"

                    null height 5

                    # Seeds
                    text "🌱 Seeds" size 22 bold True color "#FFD700" outlines [(2, "#000000", 0, 0)]
                    if len(inventory_seeds) == 0:
                        text "Empty" size 18 color "#555555"
                    else:
                        for item in inventory_seeds:
                            frame:
                                xalign 0.0
                                xfill True
                                background "#22222200"
                                padding (15, 10)
                                hbox:
                                    xalign 0.5
                                    spacing 10
                                    text item["icon"] size 22
                                    vbox:
                                        xalign 0.5
                                        spacing 2
                                        text item["name"] size 20 bold True color "#FFFFFF"
                                        text ("x" + str(item["quantity"])) size 16 color "#FFD700" outlines [(2, "#000000", 0, 0)]

                    null height 5

                    # Food
                    text "🍎 Food" size 22 bold True color "#FFD700" outlines [(2, "#000000", 0, 0)]
                    if len(inventory_food) == 0:
                        text "Empty" size 18 color "#555555"
                    else:
                        for item in inventory_food:
                            frame:
                                xalign 0.0
                                xfill True
                                background "#22222200"
                                padding (15, 10)
                                hbox:
                                    xalign 0.5
                                    spacing 10
                                    text item["icon"] size 22
                                    vbox:
                                        xalign 0.5
                                        spacing 2
                                        text item["name"] size 20 bold True color "#FFFFFF"
                                        text ("x" + str(item["quantity"])) size 16 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 10
            button:
                xalign 0
                yoffset 14
                xoffset -11
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_inventory"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50
# ------------------------------------------------------------
# PHONE — Missions
# ------------------------------------------------------------
screen phone_missions():
    modal True
    add "images/ui/phone.png"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "📋 Missions" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 5

            viewport:
                xoffset 10
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 336
                ysize 480

                vbox:
                    xalign 0.5
                    spacing 12

                    $ accepted = accepted_missions

                    if len(accepted) == 0:
                        text "No active missions." size 20 xalign 0.5 color "#888888"
                        text "Check the bulletin board in the plaza." size 16 xalign 0.5 color "#555555"
                    else:
                        for mission in accepted:
                            $ m = mission
                            frame:
                                xfill True
                                background "#222222"
                                padding (15, 10)

                                vbox:
                                    xalign 0.5
                                    spacing 6

                                    hbox:
                                        spacing 8
                                        text m["item_icon"] size 24
                                        text m["item_name"] size 20 bold True color "#FFFFFF"
                                        text ("x" + str(m["quantity"])) size 18 color "#FFD700"

                                    hbox:
                                        spacing 8
                                        text "👤" size 16
                                        text m["requester"].capitalize() size 18 color "#CCCCCC"

                                    hbox:
                                        spacing 15
                                        text ("💰 $" + str(m["reward"])) size 16 color "#90EE90"
                                        text ("⏰ " + str(m["days_left"]) + "d left") size 16 color (
                                            "#E74C3C" if m["days_left"] <= 1
                                            else "#FFD700"
                                        )

            null height 10
            button:
                xalign 0
                yoffset 23
                xoffset -12
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_missions"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50
# ------------------------------------------------------------
# PHONE — Pokedex
# ------------------------------------------------------------
screen phone_pokedex():
    modal True
    add "images/ui/phone.png"
    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)
        vbox:
            xalign 0.5
            spacing 12
            text "📖 Pokedex" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            null height 10
            viewport:
                xoffset 10
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 336
                ysize 480
                vbox:
                    xalign 0.5
                    spacing 10
                    if len(pokedex) == 0:
                        text "No creatures discovered yet." size 20 xalign 0.5 color "#888888"
                    else:
                        for poke_id, data in pokedex.items():
                            frame:
                                xfill True
                                background "#222222"
                                padding (15, 10)
                                vbox:
                                    xalign 0.5
                                    spacing 4
                                    text poke_id.capitalize() size 20 bold True color "#FFFFFF"
                                    text ("Captured: " + ("Yes" if data["captured"] else "No")) size 18 color "#CCCCCC"
                                    text "Trust:" size 18 color "#FFD700" outlines [(2, "#000000", 0, 0)]
                                    bar:
                                        value data["trust"]
                                        range 100
                                        xsize 300
                                        ysize 12
            null height 10
            button:
                xalign 0
                yoffset 30
                xoffset -11
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_pokedex"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50
# ------------------------------------------------------------
# PHONE — Gallery
# ------------------------------------------------------------
screen phone_gallery():
    modal True
    add "images/ui/phone.png"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            xalign 0.5
            spacing 12

            text "🖼️ Gallery" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 10

            viewport:
                xoffset 20
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 287
                ysize 480

                vbox:
                    xalign 0.5
                    spacing 10

                    text "Characters" size 22 bold True color "#FFFFFF" xalign 0.5

                    for char_id in CHARACTER_CG_DATA:
                        $ cg_list    = CHARACTER_CG_DATA[char_id]
                        $ prog = max(character_progress.get(char_id, 0), gallery_unlocked.get(char_id, 0))
                        $ unlocked = [cg for cg in cg_list if prog >= cg["event"]]
                        $ total      = len(cg_list)
                        $ unlocked_n = len(unlocked)

                        if unlocked_n > 0:
                            textbutton (char_id.capitalize() + " (" + str(unlocked_n) + "/" + str(total) + ")"):
                                xalign 0.5
                                action Show("phone_gallery_char", char_id=char_id)
                                text_size 20
                                text_color "#FFFFFF"

                    null height 10

                    text "Pokemon" size 22 bold True color "#FFFFFF" xalign 0.5

                    for poke_id in POKEMON_CG_DATA:
                        $ cg_list    = POKEMON_CG_DATA[poke_id]
                        $ trust      = pokemon_state.get(poke_id, {}).get("trust", 0)
                        $ unlocked   = [cg for cg in cg_list if trust >= cg["trust"]]
                        $ total      = len(cg_list)
                        $ unlocked_n = len(unlocked)

                        if unlocked_n > 0:
                            textbutton (poke_id.capitalize() + " (" + str(unlocked_n) + "/" + str(total) + ")"):
                                xalign 0.5
                                action Show("phone_gallery_pokemon", poke_id=poke_id)
                                text_size 20
                                text_color "#FFFFFF"

            null height 10
            button:
                xalign 0
                yoffset 30
                xoffset -36
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_gallery"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50


screen phone_gallery_char(char_id):
    modal True
    add "images/ui/phone.png"

    $ cg_list  = CHARACTER_CG_DATA[char_id]
    $ prog = max(character_progress.get(char_id, 0), gallery_unlocked.get(char_id, 0))
    $ unlocked = [cg for cg in cg_list if prog >= cg["event"]]

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            xalign 0.5
            spacing 12

            text (char_id.capitalize() + " — Gallery") size 24 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            text (str(len(unlocked)) + "/" + str(len(cg_list)) + " unlocked") size 18 xalign 0.5 color "#FFFFFF"

            null height 5

            viewport:
                xoffset 35
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 287
                ysize 430

                vbox:
                    xalign 0.5
                    spacing 8

                    text "▶ Event Replay" size 18 bold True color "#FFFFFF" xalign 0.5

                    for cg in unlocked:
                        if cg["label"] is not None:
                            $ cg_item = cg
                            textbutton ("▶ Event " + str(cg_item["event"] - 1)):
                                xalign 0.5
                                action [
                                    SetVariable("gallery_replay", True),
                                    Hide("phone_gallery_char"),
                                    Hide("phone_gallery"),
                                    Hide("phone_screen"),
                                    Jump(cg_item["label"])
                                ]
                                text_size 18
                                text_color "#FFFFFF"

                    null height 8

                    text "🖼️ CG Gallery" size 18 bold True color "#FFFFFF" xalign 0.5

                    for cg in unlocked:
                        if cg["path"] is not None:
                            $ cg_item = cg
                            textbutton cg_item["id"]:
                                xalign 0.5
                                action Show("phone_gallery_fullscreen", cg_path=cg_item["path"])
                                text_size 18
                                text_color "#FFFFFF"

        null height 10
        button:
            xalign 0
            yoffset 625
            xoffset 0
            background "#00000000"
            hover_background "#00000000"
            action [Hide("phone_gallery_char"), Show("phone_gallery")]
            add "images/ui/icons/void.png" xsize 50 ysize 50


screen phone_gallery_pokemon(poke_id):
    modal True
    add "images/ui/phone.png"

    $ cg_list  = POKEMON_CG_DATA[poke_id]
    $ trust    = pokemon_state.get(poke_id, {}).get("trust", 0)
    $ unlocked = [cg for cg in cg_list if trust >= cg["trust"]]

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            xalign 0.5
            spacing 12

            text (poke_id.capitalize() + " — Gallery") size 24 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            text (str(len(unlocked)) + "/" + str(len(cg_list)) + " unlocked") size 18 xalign 0.5 color "#FFFFFF"
            text ("Trust: " + str(trust) + "/100") size 16 xalign 0.5 color "#555555"

            null height 5

            viewport:
                xoffset 35
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 287
                ysize 430

                vbox:
                    xalign 0.5
                    spacing 8

                    text "▶ Event Replay" size 18 bold True color "#FFFFFF" xalign 0.5

                    for cg in unlocked:
                        if cg["label"] is not None:
                            $ cg_item = cg
                            textbutton ("▶ Event " + str(cg_item["trust"] / 20)):
                                xalign 0.5
                                action [
                                    SetVariable("gallery_replay", True),
                                    Hide("phone_gallery_pokemon"),
                                    Hide("phone_gallery"),
                                    Hide("phone_screen"),
                                    Jump(cg_item["label"])
                                ]
                                text_size 18
                                text_color "#FFFFFF"

                    null height 8

                    text "🖼️ CG Gallery" size 18 bold True color "#FFFFFF" xalign 0.5

                    for cg in unlocked:
                        if cg["path"] is not None:
                            $ cg_item = cg
                            textbutton cg_item["id"]:
                                xalign 0.5
                                action Show("phone_gallery_fullscreen", cg_path=cg_item["path"])
                                text_size 18
                                text_color "#FFFFFF"

        null height 10
        button:
            xalign 0
            yoffset 625
            xoffset 0
            background "#00000000"
            hover_background "#00000000"
            action [Hide("phone_gallery_pokemon"), Show("phone_gallery")]
            add "images/ui/icons/void.png" xsize 50 ysize 50


screen phone_gallery_fullscreen(cg_path):
    modal True

    add cg_path

    button:
        xpos 0
        ypos 0
        xsize 1920
        ysize 1080
        background "#00000000"
        action Hide("phone_gallery_fullscreen")

# ------------------------------------------------------------
# PHONE — Agenda
# ------------------------------------------------------------
screen phone_agenda():
    modal True
    add "images/ui/phone.png"
    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)
        vbox:
            xalign 0.5
            spacing 12
            text "📅 Agenda" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            null height 10
            viewport:
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 360
                ysize 480
                vbox:
                    xalign 0.5
                    spacing 10
                    for char_id in affection:
                        frame:
                            xfill True
                            background "#222222"
                            padding (15, 10)
                            hbox:
                                xalign 0.5
                                spacing 15
                                vbox:
                                    xalign 0.5
                                    spacing 4
                                    text char_id.capitalize() size 20 bold True color "#FFFFFF"
                                    hbox:
                                        xalign 0.5
                                        spacing 5
                                        text "Affection:" size 16 color "#CCCCCC"
                                        text (str(affection[char_id]) + "/100") size 16 color "#FFD700" outlines [(2, "#000000", 0, 0)]
                                #textbutton "Invite":
                                #    yalign 0.5
                                #    action Show("phone_invite_date", char_id=char_id)
                                #    text_size 18
                                #    text_color "#FFD700"
                                #    text_outlines [(2, "#000000", 0, 0)]
            null height 10
            button:
                xalign 0
                yoffset 31
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_agenda"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50

screen phone_invite_date(char_id):
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 500
        background "#11111100"
        padding (20, 20)

        vbox:
            xalign 0.5
            spacing 15

            text ("Invite " + char_id.capitalize()) size 24 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 10

            if not dates_unlocked[char_id]:
                text "You don't know this person well enough yet." size 20 xalign 0.5 color "#E74C3C"
            elif affection[char_id] < 20:
                text "Your relationship isn't strong enough yet." size 20 xalign 0.5 color "#E74C3C"
            else:
                text "Where do you want to go?" size 20 xalign 0.5 color "#CCCCCC"
                textbutton "🏖️ Beach"    action [Hide("phone_invite_date"), Hide("phone_agenda"), Hide("phone_screen"), Return("date_beach_" + char_id)]    text_size 20
                textbutton "📚 Library"  action [Hide("phone_invite_date"), Hide("phone_agenda"), Hide("phone_screen"), Return("date_library_" + char_id)]  text_size 20
                textbutton "☕ Cafe"     action [Hide("phone_invite_date"), Hide("phone_agenda"), Hide("phone_screen"), Return("date_cafe_" + char_id)]     text_size 20
                textbutton "🥊 Gym"      action [Hide("phone_invite_date"), Hide("phone_agenda"), Hide("phone_screen"), Return("date_gym_" + char_id)]      text_size 20
                textbutton "🌲 Forest"   action [Hide("phone_invite_date"), Hide("phone_agenda"), Hide("phone_screen"), Return("date_forest_" + char_id)]   text_size 20

            null height 10
            button:
                xalign 0
                yoffset 36
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_invite_date"), Show("phone_agenda")]
                add "images/ui/icons/void.png" xsize 50 ysize 50
# ------------------------------------------------------------
# PHONE — Recipes
# ------------------------------------------------------------
screen phone_recipes():
    modal True
    add "images/ui/phone.png"
    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)
        vbox:
            xalign 0.5
            spacing 12
            text "🍳 Recipes" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            null height 10
            viewport:
                xoffset 10
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 336
                ysize 480
                vbox:
                    xalign 0.5
                    spacing 10
                    if len(unlocked_recipes) == 0:
                        text "No recipes unlocked yet." size 20 xalign 0.5 color "#888888"
                    else:
                        for rid in unlocked_recipes:
                            if rid in RECIPES:
                                $ rcp = RECIPES[rid]
                                frame:
                                    xalign 0.5
                                    xfill True
                                    background "#22222200"
                                    padding (15, 10)
                                    vbox:
                                        xalign 0.5
                                        spacing 4
                                        hbox:
                                            xalign 0.5
                                            spacing 8
                                            text rcp["icon"] size 22
                                            text rcp["name"] size 20 bold True color "#FFFFFF"
                                        text rcp["rarity"].replace("_", " ").capitalize() size 16 color "#888888"
                                        text rcp["description"] size 14 color "#CCCCCC"
            null height 10
            button:
                xalign 0
                yoffset 30
                xoffset -11
                background "#00000000"
                hover_background "#00000000"
                action [Hide("phone_recipes"), Show("phone_screen")]
                add "images/ui/icons/void.png" xsize 50 ysize 50
# ------------------------------------------------------------
# CHARACTER SELECT — Shows when entering a location
# ------------------------------------------------------------
screen character_select_screen(location):
    modal True
    add "images/ui/interact.png" xalign 0.5 yalign 0 yoffset 250

    use hud()

    frame:
        xalign 0.5
        yalign 0.5
        xsize 500
        ypadding 30
        background "#11111100"

        vbox:
            spacing 15
            xalign 0.5

            text "Who do you want to talk to?" size 26 bold True color "#FFD700" xalign 0.5

            null height 10

            $ present = get_characters_in_location(location)

            if len(present) == 0:
                null height 110
                text "Nobody is here right now." size 22 color "#888888" xalign 0.5
                null height 130
            else:
                viewport:
                    xsize 440
                    ysize 310
                    mousewheel True
                    draggable True
                    vbox:
                        spacing 10
                        for char_id in present:
                            $ aff_value = affection[char_id]
                            frame:
                                xfill True
                                background "#22222200"
                                padding (15, 10)
                                hbox:
                                    spacing 15
                                    xalign 0.5
                                    frame:
                                        xsize 60
                                        ysize 60
                                        background "#33333300"
                                        add ("images/ui/icons/" + char_id + ".png") xalign 0.5 yalign 0.5 zoom 0.4
                                    vbox:
                                        spacing 4
                                        xsize 250
                                        text char_id.capitalize() size 22 bold True color "#FFFFFF"
                                        hbox:
                                            spacing 5
                                            text "♥" size 18 color "#E74C3C"
                                            bar:
                                                value aff_value
                                                range 100
                                                xsize 180
                                                ysize 10
                                                yalign 0.5
                                    textbutton ">":
                                        yalign 0.5
                                        action Return(char_id)
                                        text_size 20
                                        text_color "#FFD700"
                                        text_bold True

            null height 10

            textbutton "← Leave":
                xalign 0.5
                action Return(None)
                text_size 20
                yoffset -13
                text_color "#dddddd"

# ------------------------------------------------------------
# BULLETIN BOARD
# ------------------------------------------------------------
screen bulletin_board_screen():
    modal True
    add "images/ui/board.png" xalign 0.5 yalign 0 zoom .65

    frame:
        xalign 0.5
        yalign 0.5
        xsize 560
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "📋 Bulletin Board" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]
            text "New missions posted daily." size 18 xalign 0.5 color "#000000"

            null height 5

            viewport:
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 500
                ysize 430

                vbox:
                    xalign 0.5
                    spacing 15

                    if len(active_missions) == 0:
                        text "No missions available today." size 20 xalign 0.5 color "#000000"
                    else:
                        for mission in active_missions:
                            $ m = mission
                            frame:
                                xfill True
                                if m["accepted"]:
                                    background Image("images/ui/mission_accepted.png", xalign=0.5, yalign=0.5)
                                else:
                                    background Image("images/ui/mission_available.png", xalign=0.5, yalign=0.5)
                                left_padding 25
                                top_padding 30

                                vbox:
                                    spacing 8

                                    hbox:
                                        spacing 10
                                        text m["item_icon"] size 26
                                        text m["item_name"] size 22 bold True color "#000000"
                                        text ("x" + str(m["quantity"])) size 20 color "#FFD700" outlines [(2, "#000000", 0, 0)]

                                    hbox:
                                        spacing 8
                                        text "👤" size 18
                                        text ("Requested by: " + m["requester"].capitalize()) size 18 color "#000000"

                                    hbox:
                                        spacing 20
                                        hbox:
                                            spacing 6
                                            text "💰" size 18
                                            text ("$" + str(m["reward"])) size 18 bold True color "#90EE90" outlines [(2, "#000000", 0, 0)]
                                        hbox:
                                            spacing 6
                                            text "⏰" size 18
                                            text (str(m["days_left"]) + " day(s) left") size 18 color (
                                                "#E74C3C" if m["days_left"] <= 1
                                                else "#FFD700" if m["days_left"] <= 2
                                                else "#ffffff"
                                            ) outlines [(2, "#000000", 0, 0)]
                                    if m["accepted"]:
                                        text "✅ Accepted — deliver to " + m["requester"].capitalize() size 16 color "#90EE90" outlines [(2, "#000000", 0, 0)]
                                    else:
                                        textbutton "Accept mission":
                                            action Function(accept_mission, m["id"])
                                            text_size 18
                                            text_color "#FFD700"
                                            text_outlines [(2, "#000000", 0, 0)]

            null height 5

            textbutton "← Leave":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#ff0000"
                text_outlines [(2, "#000000", 0, 0)]

# ------------------------------------------------------------
# GIFT SCREEN
# ------------------------------------------------------------
screen gift_screen(char_id):
    modal True
    add "images/ui/interact3.png" xalign 0.5 yalign 0 yoffset 200

    frame:
        xalign 0.5
        yalign 0.5
        xsize 500
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🎁 Give a Gift" size 26 bold True xalign 0.5 color "#FFD700"
            text ("to " + char_id.capitalize()) size 20 xalign 0.5 color "#CCCCCC"

            null height 5

            if not can_give_gift(char_id):
                text "You already gave a gift today." size 20 xalign 0.5 color "#E74C3C"
                text "Come back tomorrow." size 16 xalign 0.5 color "#888888"
            else:
                viewport:
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    xsize 460
                    ysize 420

                    vbox:
                        spacing 15

                        # Cooked dishes
                        if len([i for i in inventory_gifts if i.get("cooked")]) > 0:
                            text "🍳 Cooked Dishes" size 20 bold True color "#FFD700"
                            for item in inventory_gifts:
                                if item.get("cooked") and item["quantity"] > 0:
                                    $ gi = item
                                    frame:
                                        xfill True
                                        background "#222222"
                                        padding (15, 10)
                                        hbox:
                                            spacing 10
                                            text gi["icon"] size 26 yalign 0.5
                                            vbox:
                                                spacing 3
                                                xsize 220
                                                text gi["name"] size 18 bold True color "#FFFFFF"
                                                text ("x" + str(gi["quantity"])) size 14 color "#CCCCCC"
                                                $ aff_map = {"common": 2, "uncommon": 3, "rare": 4, "very_rare": 6, "exceptional": 10}
                                                text ("❤️ +" + str(aff_map.get(gi.get("rarity", "common"), 2))) size 14 color "#E74C3C"
                                            textbutton "Give":
                                                yalign 0.5
                                                action Return(("gift", gi["id"]))
                                                text_size 18
                                                text_color "#FFD700"

                        # General gifts
                        if len([i for i in inventory_gifts if not i.get("cooked")]) > 0:
                            text "🎁 Gifts" size 20 bold True color "#FFD700"
                            for item in inventory_gifts:
                                if not item.get("cooked") and item["quantity"] > 0:
                                    $ ggi = item
                                    frame:
                                        xfill True
                                        background "#222222"
                                        padding (15, 10)
                                        hbox:
                                            spacing 10
                                            text ggi["icon"] size 26 yalign 0.5
                                            vbox:
                                                spacing 3
                                                xsize 220
                                                text ggi["name"] size 18 bold True color "#FFFFFF"
                                                text ("x" + str(ggi["quantity"])) size 14 color "#CCCCCC"
                                                text ("❤️ +" + str(ggi.get("affection", 2))) size 14 color "#E74C3C"
                                            textbutton "Give":
                                                yalign 0.5
                                                action Return(("gift", ggi["id"]))
                                                text_size 18
                                                text_color "#FFD700"

                        $ char_clothing = [i for i in store.inventory_clothing if i.get("character") == char_id]
                        if len(char_clothing) > 0:
                            text "👗 Clothing" size 20 bold True color "#FFD700"
                            for item in char_clothing:
                                $ ci = item
                                frame:
                                    xfill True
                                    background "#222222"
                                    padding (15, 10)
                                    hbox:
                                        spacing 10
                                        text ci["icon"] size 26 yalign 0.5
                                        vbox:
                                            spacing 3
                                            xsize 220
                                            text ci["name"] size 18 bold True color "#FFFFFF"
                                            text "Unlocks outfit" size 14 color "#CCCCCC"
                                            text "❤️ +8" size 14 color "#E74C3C"
                                        textbutton "Give":
                                            yalign 0.5
                                            action Return(("clothing", ci["id"]))
                                            text_size 18
                                            text_color "#FFD700"

                        # Empress Outfit — independent of char_clothing
                        if empress_outfit_owned:
                            frame:
                                xfill True
                                background "#2E2A1A"
                                padding (15, 10)
                                hbox:
                                    spacing 10
                                    text "👑" size 26 yalign 0.5
                                    vbox:
                                        spacing 3
                                        xsize 220
                                        text "Empress Outfit" size 18 bold True color "#FFD700"
                                        text "Universal — no affection bonus" size 14 color "#888888"
                                    textbutton "Give":
                                        yalign 0.5
                                        action Return(("clothing", "empress_outfit"))
                                        text_size 18
                                        text_color "#FFD700"

                        if len(inventory_gifts) == 0 and len(inventory_clothing) == 0:
                            text "No gifts available." size 20 xalign 0.5 color "#888888"

            null height 5

            textbutton "← Cancel":
                xalign 0.5
                action Return(None)
                text_size 20
                text_color "#dddddd"

# ------------------------------------------------------------
# SKIN SELECTOR
# ------------------------------------------------------------
screen skin_selector(char_id):
    modal True
    add "images/ui/interact2.png" xalign 0.5 yalign 0 yoffset 260

    frame:
        xalign 0.5
        yalign 0.5
        xsize 600
        ysize 500
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "👗 Change Outfit" size 24 bold True xalign 0.5 color "#FFD700"
            text char_id.capitalize() size 20 xalign 0.5 color "#CCCCCC"

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 570
                ysize 300

                vbox:
                    spacing 10

                    # Default outfit always available
                    frame:
                        xfill True
                        if equipped_skin[char_id] == "default":
                            background "#1A2E1A"
                        else:
                            background "#222222"
                        padding (15, 10)
                        hbox:
                            spacing 10
                            text "👤" size 26 yalign 0.5
                            text "Default Outfit" size 20 color "#FFFFFF" xsize 240
                            if equipped_skin[char_id] == "default":
                                text "✅" size 24 yalign 0.5
                            else:
                                textbutton "Wear":
                                    yalign 0.5
                                    action [
                                        SetDict(equipped_skin, char_id, "default"),
                                        Return()
                                    ]
                                    text_size 18
                                    text_color "#FFD700"

                    # Unlocked skins
                    for skin_id in unlocked_skins[char_id]:
                        $ sk = skin_id
                        frame:
                            xfill True
                            if equipped_skin[char_id] == sk:
                                background "#1A2E1A"
                            else:
                                background "#222222"
                            padding (15, 10)
                            hbox:
                                spacing 10
                                text "👗" size 26 yalign 0.5
                                text sk size 20 color "#FFFFFF" xsize 240
                                if equipped_skin[char_id] == sk:
                                    text "✅" size 24 yalign 0.5
                                else:
                                    textbutton "Wear":
                                        yalign 0.5
                                        action [
                                            SetDict(equipped_skin, char_id, sk),
                                            Return()
                                        ]
                                        text_size 18
                                        text_color "#FFD700"

            textbutton "← Leave":
                xalign 0.5
                action Return(None)
                text_size 20
                text_color "#888888"

# ------------------------------------------------------------
# CHARACTER INTERACTION MENU
# ------------------------------------------------------------
screen character_interaction_menu(char_id, location):
    modal True
    add "images/ui/interact1.png" xalign 0.5 yalign 0 yoffset 260

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ypadding 30
        xpadding 30
        background "#11111100"

        vbox:
            spacing 15
            xalign 0.5

            text char_id.capitalize() size 28 bold True xalign 0.5 color "#FFD700"
            text ("❤️ " + str(affection[char_id]) + "/100") size 20 xalign 0.5 color "#E74C3C"

            null height 10

            textbutton "💬 Talk":
                xalign 0.5
                action Return("talk")
                text_size 22
                text_color "#FFFFFF"

            $ has_gifts = len(inventory_gifts) > 0 or len([i for i in inventory_clothing if i.get("character") == char_id]) > 0
            textbutton "🎁 Give Gift":
                xalign 0.5
                sensitive has_gifts and can_give_gift(char_id)
                action Return("gift")
                text_size 22
                if (has_gifts and can_give_gift(char_id)):
                    text_color "#FFD700"
                else:
                    text_color "#555555"

            textbutton "📅 Invite to Date":
                xalign 0.5
                sensitive dates_unlocked[char_id] and affection[char_id] >= 20
                action Return("date")
                text_size 22
                if (dates_unlocked[char_id] and affection[char_id] >= 20):
                    text_color "#FFD700"
                else:
                    text_color "#555555"

            $ has_skins = len(unlocked_skins[char_id]) > 0
            textbutton "👗 Change Outfit":
                xalign 0.5
                sensitive has_skins
                action Return("outfit")
                text_size 22
                if has_skins:
                    text_color "#FFD700"
                else:
                    text_color "#555555"

            null height 5

            textbutton "← Leave":
                xalign 0.5
                action Return(None)
                text_size 20
                text_color "#dddddd"

screen forest_choice_screen():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 560
        ypadding 30
        xpadding 30
        background "#111111EE"

        vbox:
            spacing 20
            xalign 0.5

            text "What do you do?" size 24 bold True xalign 0.5 color "#FFD700" 

            null height 10

            for i in range(len(choices)):
                $ ch = choices[i]
                textbutton ch["text"]:
                    xalign 0.5
                    xsize 480
                    action [
                        SetVariable("choice_result", ch["correct"]),
                        If(not ch["correct"],
                            true=SetVariable("mg_fail_text", ch.get("fail", "Something went wrong.")),
                            false=NullAction()
                        ),
                        Return()
                    ]
                    text_size 20
                    text_xalign 0.0
                    text_color "#FFFFFF"

screen cheat_code_screen():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 500
        ypadding 30
        xpadding 30
        background "#111111EE"

        vbox:
            spacing 20
            xalign 0.5

            text "Enter Code" size 26 bold True xalign 0.5 color "#FFD700"

            input:
                value VariableInputValue("cheat_code_input")
                xalign 0.5
                size 24
                color "#FFFFFF"
                length 20

            textbutton "Confirm":
                xalign 0.5
                action [Function(apply_cheat_code), Hide("cheat_code_screen")]
                text_size 22
                text_color "#FFD700"

            null height 10

            textbutton "← Leave":
                xalign 0.5
                action Hide("cheat_code_screen")
                text_size 20
                text_color "#888888"