# ============================================================
# POKETOWN - hint_data.rpy
# ============================================================

# ------------------------------------------------------------
# HINT DATABASE
# ------------------------------------------------------------
define HINT_DATA = {

    "maylene": {
        "hints": [
            "Place: Gym",
            "Place: Gym\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 20+",
            "Place: Gym\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 40+\nPhysique: 5+",
            "Place: Gym\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 55+\nPhysique: 10+",
            "Place: Beach\nTime: Afternoon\nDay: Sunday\nAffection: 70+\nCostume: Maylene's Swimsuit",
            "Place: Gym\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 80+\nCharisma: 15+",
            "Place: Plaza\nTime: Morning-Afternoon\nDay: Saturday\nAffection: 90+\nCharisma: 20+\nCostume: Maylene's Cosplay",
            "Place: Gym\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 95+\nPhysique: 25+",
        ],
    },
    "misty": {
        "hints": [
            "Place: Forest or Beach",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 20+",
            "Place: Beach\nTime: Day-Afternoon\nDays: Sat-Sun\nAffection: 40+\nPhysique: 10+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 55+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 70+\nCharisma: 10+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 80+\nCharisma: 15+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 90+\nCharisma: 20+",
            "Place: Forest\nTime: Night\nDays: Any\nAffection: 95+\nCharisma: 25+",
        ],
    },
    "mallow": {
        "hints": [
            "Place: Food Store",
            "Place: Food Store\nTime: Night\nDays: Mon-Fri\nAffection: 10+",
            "Place: Food Store\nTime: Night\nDays: Mon-Fri\nAffection: 20+",
            "Place: Food Store\nTime: Afternoon\nDays: Mon-Fri\nAffection: 35+",
            "Place: Food Store\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 50+\nCharisma: 10+",
            "Place: Food Store\nTime: Night\nDays: Mon-Fri\nAffection: 65+\nCharisma: 15+",
            "Place: Food Store\nTime: Afternoon-Night\nDays: Mon-Fri\nAffection: 80+\nCharisma: 20+",
            "Place: Food Store\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 95+\nCharisma: 25+",
        ],
    },
    "lillie": {
        "hints": [
            "Place: Cafe",
            "Place: Library\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 10+",
            "Place: Plaza\nTime: Morning-Day\nDays: Sat-Sun\nAffection: 20+\nCharisma: 10+",
            "Place: Library\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 35+\nCharisma: 15+",
            "Place: Cafe\nTime: Night-Midnight\nDays: Any\nAffection: 50+\nCharisma: 20+",
            "Place: Cafe\nTime: Night-Midnight\nDays: Any\nAffection: 65+",
            "Place: Cafe\nTime: Night-Midnight\nDays: Any\nAffection: 80+\nCharisma: 25+",
            "Place: Cafe\nTime: Night-Midnight\nDays: Any\nAffection: 95+",
        ],
    },
    "may": {
        "hints": [
            "Place: Plaza",
            "Place: Plaza\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 10+",
            "Place: Plaza\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 20+\nCharisma: 10+\nFood: Lum Berry",
            "Place: Plaza\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 35+\nCharisma: 15+\nCostume: May's Cosplay",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Sat-Sun\nAffection: 50+",
            "Place: Cafe\nTime: Night\nDays: Any\nAffection: 65+\nCharisma: 20+",
            "Place: Plaza\nTime: Morning\nDays: Mon-Fri\nAffection: 80+",
            "Place: Cafe\nTime: Night\nDays: Any\nAffection: 95+\nCharisma: 25+\nCostume: May's Lingerie\nFood: Sitrus Miltank Roast",
        ],
    },
    "iris": {
        "hints": [
            "Place: Forest",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 10+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 20+\nPhysique: 10+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 35+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 50+\nPhysique: 20+",
            "Place: Forest\nTime: Afternoon\nDays: Any\nAffection: 65+\nCharisma: 20+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 80+\nCharisma: 25+",
            "Place: Forest\nTime: Morning-Afternoon\nDays: Any\nAffection: 95+",
        ],
    },
    "leaf": {
        "hints": [
            "Place: Shopping Center",
            "Place: Shopping Center\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 10+\nCharisma: 10+",
            "Place: Shopping Center\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 20+\nCharisma: 15+",
            "Place: Plaza\nTime: Afternoon\nDays: Mon-Fri\nAffection: 35+",
            "Place: Shopping Center\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 50+",
            "Place: Delia's Home\nTime: Afternoon\nDays: Sat-Sun\nAffection: 65+",
            "Place: Shopping Center\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 80+",
            "Place: Plaza\nTime: Morning-Day\nDays: Sat-Sun\nAffection: 95+",
        ],
    },
    "cynthia": {
        "hints": [
            "Place: Library",
            "Place: Library\nTime: Night-Midnight\nDays: Any\nAffection: 10+\nIntelligence: 10+",
            "Place: Library\nTime: Night-Midnight\nDays: Any\nAffection: 20+\nIntelligence: 15+",
            "Place: Library\nTime: Night-Midnight\nDays: Any\nAffection: 35+\nIntelligence: 15+",
            "Place: Library\nTime: Night-Midnight\nDays: Any\nAffection: 50+\nIntelligence: 20+",
            "Place: Library\nTime: Night-Midnight\nDays: Any\nAffection: 65+\nIntelligence: 20+",
            "Place: Library\nTime: Night-Midnight\nDays: Any\nAffection: 80+\nIntelligence: 25+",
            "Place: Library\nTime: Night-Midnight\nDays: Any\nAffection: 95+\nIntelligence: 25+",
        ],
    },
    "delia": {
        "hints": [
            "Place: Plaza",
            "Place: Plaza\nTime: Morning-Afternoon\nDays: Sat-Sun\nAffection: 10+\nCharisma: 10+",
            "Place: Delia's Home\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 20+\nCharisma: 15+\nFood: Bronze Potato, Alba Onion",
            "Place: Plaza\nTime: Morning-Afternoon\nDays: Sat-Sun\nAffection: 35+",
            "Place: Delia's Home\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 50+\nFood: Bronze Potato, Torchic Breast",
            "Place: Delia's Home\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 65+\nFood: Leppa Berry, Bronze Potato, Alba Onion",
            "Place: Delia's Home\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 80+\nFood: Lum Berry, Torchic Breast, Moss Pumpkin",
            "Place: Delia's Home\nTime: Morning-Day\nDays: Mon-Fri\nAffection: 95+\nFood: Colbur Berry, Tauros Steak, Meteor Root",
        ],
    },
    "elesa": {
        "hints": [
            "Place: Clothing Store",
            "Place: Clothing Store\nTime: Morning-Night\nDays: Any\nAffection: 10+\nCharisma: 10+",
            "Place: Clothing Store\nTime: Morning-Night\nDays: Any\nAffection: 20+\nCharisma: 15+",
            "Place: Clothing Store\nTime: Morning-Night\nDays: Any\nAffection: 35+\nCharisma: 20+",
            "Place: Clothing Store\nTime: Morning-Night\nDays: Any\nAffection: 50+",
            "Place: Clothing Store\nTime: Morning-Night\nDays: Any\nAffection: 65+\nCharisma: 25+",
            "Place: Clothing Store\nTime: Morning-Night\nDays: Any\nAffection: 80+",
            "Place: Clothing Store\nTime: Morning-Night\nDays: Any\nAffection: 95+",
        ],
    },
    "erika": {
        "hints": [
            "Place: Greenhouse",
            "Place: Greenhouse\nTime: Morning-Night\nDays: Mon-Sat\nAffection: 10+\nPhysique: 10+",
            "Place: Greenhouse\nTime: Morning-Night\nDays: Mon-Sat\nAffection: 20+\nPhysique: 15+",
            "Place: Greenhouse\nTime: Morning-Night\nDays: Mon-Sat\nAffection: 35+",
            "Place: Forest\nTime: Midnight\nDay: Sunday\nAffection: 50+\nPhysique: 20+",
            "Place: Greenhouse\nTime: Morning-Night\nDays: Mon-Sat\nAffection: 65+",
            "Place: Forest\nTime: Midnight\nDay: Sunday\nAffection: 80+\nPhysique: 80+",
            "Place: Greenhouse\nTime: Morning-Night\nDays: Mon-Sat\nAffection: 95+",
        ],
    },
    "lusamine": {
        "hints": [
            "Place: Cafe",
            "Place: Cafe\nTime: Morning-Afternoon\nDays: Mon-Fri and Sunday\nAffection: 10+",
            "Place: Cafe\nTime: Morning-Afternoon\nDays: Mon-Fri and Sunday\nAffection: 20+\nCharisma: 10+",
            "Place: Cafe\nTime: Morning-Afternoon\nDays: Mon-Fri and Sunday\nAffection: 35+\nCharisma: 15+",
            "Place: Cafe\nTime: Morning-Afternoon\nDays: Mon-Fri and Sunday\nAffection: 50+\nCharisma: 20+",
            "Place: Plaza\nTime: Day-Afternoon\nDay: Saturday\nAffection: 65+\nCharisma: 25+",
            "Place: Cafe\nTime: Morning-Afternoon\nDays: Mon-Fri and Sunday\nAffection: 80+",
            "Place: Cafe\nTime: Night-Midnight\nDay: Friday\nAffection: 95+",
        ],
    },
    "penny": {
        "hints": [
            "Place: Plaza or Forest",
            "Place: Plaza\nTime: Afternoon\nDays: Friday or Sat-Sun\nAffection: 10+"
            "Place: Forest\nTime: Morning-Day\nDay: Friday\nAffection: 20+",
            "Place: Plaza\nTime: Afternoon\nDays: Friday or Sat-Sun\nAffection: 35+"
            "Place: Studio\nTime: Morning-Afternoon\nDays: Mon-Thu\nAffection: 50+\nCharisma: 15+",
            "Place: Studio\nTime: Morning-Afternoon\nDays: Mon-Thu\nAffection: 65+\nCharisma: 20+",
            "Place: Studio\nTime: Morning-Afternoon\nDays: Mon-Thu\nAffection: 80+\nCharisma: 20+",
            "Place: Studio\nTime: Morning-Afternoon\nDays: Mon-Thu\nAffection: 95+\nCharisma: 25+\nCostume: Penny's Cosplay",
        ],
    },
    "roxanne": {
        "hints": [
            "Place: Library",
            "Place: Library\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 10+\nCharisma: 10+",
            "Place: Library\nTime: Morning-Afternoon\nDays: Mon-Fri\nDays: Sat-Sun\nAffection: 20+\nCharisma: 15+",
            "Place: Beach\nTime: Day-Afternoon\nDays: Sat-Sun\nAffection: 35+\nCharisma: 20+\nCostume: Roxanne's Swimsuit",
            "Place: Beach\nTime: Day-Afternoon\nDays: Sat-Sun\nAffection: 50+",
            "Place: Library\nTime: Morning-Afternoon\nDays: Mon-Fri\nAffection: 65+\nIntelligence: 20+",
            "Place: Plaza\nTime: Night-Midnight\nDays: Sat-Sun\nAffection: 80+\nCostume: Roxanne's Lingerie",
            "Place: Plaza\nTime: Midnight\nDays: Sat-Sun\nAffection: 95+\nCharisma: 25+",
        ],
    },
    "dawn": {
        "hints": [
            "Place: Plaza",
            "Place: Plaza\nTime: Night-Midnight\nDays: Mon-Fri\nAffection: 10+\nMoney: $20+",
            "Place: Plaza\nTime: Night-Midnight\nDays: Mon-Fri\nAffection: 20+\nMoney: $20+",
            "Place: Plaza\nTime: Night-Midnight\nDays: Mon-Fri\nAffection: 35+\nMoney: $65+",
            "Place: Plaza\nTime: Night-Midnight\nDays: Mon-Fri\nAffection: 50+",
            "Place: Shopping Center\nTime: Night-Midnight\nDays: Sat-Sun\nAffection: 65+\nMoney: $220+",
            "Place: Plaza\nTime: Day-Afternoon\nDay: Friday\nAffection: 80+",
            "Place: Plaza\nTime: Night-Midnight\nDays: Mon-Fri\nAffection: 95+",
        ],
    },
    "nessa": {
        "hints": [
            "Place: Beach",
            "Place: Beach\nTime: Day-Afternoon\nDays: Any\nAffection: 10+",
            "Place: Beach\nTime: Day-Afternoon\nDays: Any\nAffection: 20+\nPhysique: 5+",
            "Place: Beach\nTime: Day-Afternoon\nDays: Any\nAffection: 35+\nPhysique: 10+",
            "Place: Beach\nTime: Day-Afternoon\nDays: Any\nAffection: 50+\nPhysique: 15+\nCostume: Nessa's Swimsuit",
            "Place: Beach\nTime: Day-Afternoon\nDays: Any\nAffection: 65+\nPhysique: 20+",
            "Place: Beach\nTime: Day-Afternoon\nDays: Any\nAffection: 80+",
            "Place: Beach\nTime: Afternoon\nDays: Any\nAffection: 95+\nPhysique: 25+",
        ],
    },
    "helena": {
        "hints": [
            "Place: Home",
            "Place: Home\nTime: Midnight\nDays: Any\nAffection: 5+",
            "Place: Home\nTime: Morning–Day\nDays: Any\nAffection: 15+",
            "Place: Home\nTime: Day–Night\nDays: Any\nAffection: 30+",
            "Place: Home\nTime: Morning–Day\nDays: Any\nAffection: 45+",
            "Place: Home\nTime: Morning\nDays: Any\nAffection: 60+",
            "Place: Home\nTime: Night–Midnight\nDays: Any\nAffection: 75+",
            "Place: Home\nTime: Night–Midnight\nDays: Any\nAffection: 90+",
        ],
    },
}


# ------------------------------------------------------------
# HINT STATE - tracks purchases and current event per character
# ------------------------------------------------------------
default hint_state = {
    "elesa": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "erika": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "roxanne": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "cynthia": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "maylene": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "misty": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "mallow": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "nessa": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "penny": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "delia": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "leaf": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "lusamine": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "lillie": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "may": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "dawn": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "iris": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
    "helena": {
        "current_hint": 0,
        "hint_cost": 0,
        "hint_purchased": False,
    },
}
