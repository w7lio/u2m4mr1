# ============================================================
# Schedule screen for the phone
# ============================================================

default schedule_selected_char = None

screen phone_schedule():
    modal True
    add "images/ui/phone.png"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            xalign 0.5
            spacing 12

            text "📅 Schedules" size 26 bold True xalign 0.5 color "#FFD700" outlines [(2, "#000000", 0, 0)]

            null height 5

            viewport:
                xalign 0.5
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 287
                ysize 480

                vbox:
                    xalign 0.5
                    spacing 8

                    for char_id in character_schedules:
                        if affection.get(char_id, 0) > 0:
                            $ is_selected = (schedule_selected_char == char_id)
                            $ char_schedule = character_schedules[char_id]
                            $ active_state  = character_schedule_state.get(char_id, "default")
                            $ slots_data    = char_schedule.get(active_state, char_schedule["default"])

                            frame:
                                xsize 270
                                background (
                                    "#22334466" if is_selected
                                    else "#00000022"
                                )
                                padding (10, 8)

                                vbox:
                                    spacing 6
                                    xalign 0.0

                                    # Character name button
                                    textbutton char_id.capitalize():
                                        xalign 0.0
                                        action If(
                                            is_selected,
                                            true=SetVariable("schedule_selected_char", None),
                                            false=SetVariable("schedule_selected_char", char_id)
                                        )
                                        text_size 22
                                        text_bold True
                                        text_color "#FFD700"

                                    # Schedule entries — only shown when selected
                                    if is_selected:
                                        for entry in slots_data:
                                            $ d_start, d_end, s_start, s_end, loc = entry
                                            $ days_str = get_day_range_str(d_start, d_end)
                                            $ slots_str = get_slot_range_str(s_start, s_end)
                                            frame:
                                                xsize 245
                                                background "#11111166"
                                                padding (8, 6)
                                                vbox:
                                                    spacing 2
                                                    text ("📍 " + loc.replace("_", " ").capitalize()) size 17 color "#FFFFFF"
                                                    text ("📆 " + days_str) size 15 color "#CCCCCC"
                                                    text ("🕐 " + slots_str) size 15 color "#FFD700"

            null height 10
            button:
                xalign 0
                yoffset 35
                xoffset -36
                background "#00000000"
                hover_background "#00000000"
                action [
                    SetVariable("schedule_selected_char", None),
                    Hide("phone_schedule"),
                    Show("phone_screen")
                ]
                add "images/ui/icons/void.png" xsize 50 ysize 50
