init python:
   config.language = "en_zenpy"
   config.default_language = "en_zenpy"
