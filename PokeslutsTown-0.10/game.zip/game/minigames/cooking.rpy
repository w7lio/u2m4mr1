# ============================================================
# POKETOWN — minigames/cooking.rpy
# Cooking minigame — semicircle with moving bar
# Click within range to succeed, fail produces low quality dish
# ============================================================
# ------------------------------------------------------------
# COOKING VARIABLES
# ------------------------------------------------------------
default mg_cook_recipe_id    = ""
default mg_cook_recipe_name  = ""
default mg_cook_recipe_icon  = ""
default mg_cook_range        = 20
default mg_cook_bar_angle    = 0
default mg_cook_direction    = 1
default mg_cook_speed        = 6
default mg_cook_clicked      = False
default mg_cook_success      = False
default mg_cook_target_start = 60
default mg_cook_target_end   = 120


screen minigame_cooking():
    modal True

    # Bar movement
    if not mg_cook_clicked:
        timer 0.05 repeat True:
            action If(
                mg_cook_bar_angle + mg_cook_direction * mg_cook_speed > 180
                or mg_cook_bar_angle + mg_cook_direction * mg_cook_speed < 0,
                true=[
                    SetVariable("mg_cook_direction", mg_cook_direction * -1),
                    SetVariable("mg_cook_bar_angle",
                        mg_cook_bar_angle + mg_cook_direction * mg_cook_speed * -1
                    ),
                ],
                false=SetVariable("mg_cook_bar_angle",
                    mg_cook_bar_angle + mg_cook_direction * mg_cook_speed
                )
            )

    # Header
    frame:
        xalign 0.5
        yalign 0.05
        xsize 900
        ypadding 15
        xpadding 20
        background "#111111EE"

        hbox:
            spacing 20
            xalign 0.5
            text "🍳 Cooking" size 22 bold True color "#FFD700"
            text mg_cook_recipe_icon size 22
            text mg_cook_recipe_name size 20 color "#CCCCCC"

    # Main frame
    frame:
        xalign 0.5
        yalign 0.5
        xsize 780
        ypadding 40
        xpadding 40
        background "#111111EE"

        vbox:
            spacing 20
            xalign 0.5

            if not mg_cook_clicked:
                text "Click at the right moment!" size 22 xalign 0.5 color "#CCCCCC"
            elif mg_cook_success:
                text "✅ Perfect!" size 28 bold True xalign 0.5 color "#90EE90"
            else:
                text "🔥 Burnt!" size 28 bold True xalign 0.5 color "#E74C3C"

            null height 10

            # Semicircle display using imagebutton area
            # We simulate it with a hbox of angle indicators
            frame:
                xalign 0.5
                xsize 600
                ysize 330
                background "#1A1A1A"

                # Success range indicator
                frame:
                    xpos int((mg_cook_target_start / 180.0) * 600)
                    ypos 0
                    xsize int(((mg_cook_target_end - mg_cook_target_start) / 180.0) * 600)
                    ysize 330
                    background "#90EE3044"

                # Moving bar indicator
                frame:
                    xpos int((mg_cook_bar_angle / 180.0) * 600) - 3
                    ypos 0
                    xsize 6
                    ysize 330
                    background "#FFD700"

                # Labels
                vbox:
                    xalign 0.0
                    yalign 1.0
                    text "0°" size 16 color "#555555"

                vbox:
                    xalign 1.0
                    yalign 1.0
                    text "180°" size 16 color "#555555"

            # Angle display
            hbox:
                spacing 20
                xalign 0.5
                text ("Position: " + str(int(mg_cook_bar_angle)) + "°") size 20 color "#CCCCCC"
                text ("Target: " + str(int(mg_cook_target_start)) + "°-" + str(int(mg_cook_target_end)) + "°") size 20 color "#90EE90"

            null height 10

            if not mg_cook_clicked:
                textbutton "🍳 COOK!":
                    xalign 0.5
                    xsize 375
                    action [
                        SetVariable("mg_cook_clicked", True),
                        SetVariable("mg_cook_success",
                            mg_cook_target_start <= mg_cook_bar_angle <= mg_cook_target_end
                        ),
                    ]
                    text_size 30
                    text_xalign 0.5
                    text_color "#FFD700"
            else:
                textbutton "Continue →":
                    xalign 0.5
                    action Return(mg_cook_success)
                    text_size 24
                    text_color "#FFD700"


# ------------------------------------------------------------
# RECIPE SELECTION SCREEN
# ------------------------------------------------------------
screen cooking_recipe_select():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 750
        ysize 975
        background "#111111EE"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🍳 Kitchen" size 26 bold True xalign 0.5 color "#FFD700"
            text "Choose a recipe to cook:" size 20 xalign 0.5 color "#CCCCCC"

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 690
                ysize 690

                vbox:
                    spacing 10

                    if len(unlocked_recipes) == 0:
                        text "No recipes unlocked yet." size 20 xalign 0.5 color "#888888"
                        text "Talk to Delia or buy a cookbook." size 16 xalign 0.5 color "#555555"
                    else:
                        for rid in unlocked_recipes:
                            if rid in RECIPES:
                                $ recipe = RECIPES[rid]
                                $ cr = recipe
                                $ can_cook = has_ingredients(rid)
                                frame:
                                    xfill True
                                    if can_cook:
                                        background "#1A2E1A"
                                    else:
                                        background "#2E1A1A"
                                    padding (15, 10)

                                    hbox:
                                        spacing 10

                                        text cr["icon"] size 28 yalign 0.5

                                        vbox:
                                            spacing 3
                                            xsize 330
                                            text cr["name"] size 18 bold True color "#FFFFFF"
                                            text cr["rarity"].replace("_", " ").capitalize() size 14 color "#888888"
                                            # Ingredients
                                            $ ing_text = ", ".join(
                                                INGREDIENTS[i]["name"] if i in INGREDIENTS else i
                                                for i in cr["ingredients"]
                                            )
                                            text ing_text size 13 color "#CCCCCC"

                                        vbox:
                                            spacing 6
                                            yalign 0.5
                                            text ("❤️ +" + str(cr["affection"])) size 16 color "#E74C3C"
                                            if can_cook:
                                                textbutton "Cook":
                                                    action Return(rid)
                                                    text_size 18
                                                    text_color "#90EE90"
                                            else:
                                                text "Missing\ningredients" size 14 color "#E74C3C"

            null height 5

            textbutton "← Leave":
                xalign 0.5
                action Return(None)
                text_size 20
                text_color "#888888"


# ------------------------------------------------------------
# COOKING LABEL
# ------------------------------------------------------------
label minigame_cooking_start:

    $ recipe_choice = renpy.call_screen("cooking_recipe_select")

    if recipe_choice is None:
        jump location_home

    if recipe_choice not in RECIPES:
        jump location_home

    $ recipe = RECIPES[recipe_choice]

    python:
        import random
        mg_cook_recipe_id   = recipe_choice
        mg_cook_recipe_name = recipe["name"]
        mg_cook_recipe_icon = recipe["icon"]
        mg_cook_range       = recipe["cooking_range"]
        mg_cook_bar_angle   = 0
        mg_cook_direction   = 1
        mg_cook_clicked     = False
        mg_cook_success     = False
        rarity_speed = {
            "common":      5,
            "uncommon":    7,
            "rare":        9,
            "epic":        11,
            "exceptional": 13,
        }
        mg_cook_speed = rarity_speed.get(recipe["rarity"], 6)

        

        cook_center = random.randint(mg_cook_range, 180 - mg_cook_range)
        mg_cook_target_start = cook_center - mg_cook_range // 2
        mg_cook_target_end   = cook_center + mg_cook_range // 2

    $ success = renpy.call_screen("minigame_cooking")

    if success:
        $ add_cooked_dish(recipe_choice, "normal")
        $ consume_ingredients(recipe_choice)
        "[recipe['icon']] [recipe['name']] cooked successfully!"
        "Added to your gift inventory."
    else:
        $ add_cooked_dish(recipe_choice, "failed")
        $ consume_ingredients(recipe_choice)
        "The dish came out burnt..."
        "You produced a low quality version. It can be sold for $5."

    $ advance_slot()
    jump location_home
