# ============================================================
# POKETOWN — minigames/intelligence.rpy
# ============================================================

init python:
    import random

    def generate_math_question():
        a = random.randint(1, 20)
        b = random.randint(1, 20)
        op = random.choice(["+", "-"])

        if op == "+":
            correct = a + b
            question = "{} + {} = ?".format(a, b)
        else:
            if a < b:
                a, b = b, a
            correct = a - b
            question = "{} - {} = ?".format(a, b)

        wrong = set()
        while len(wrong) < 3:
            offset = random.randint(-5, 5)
            candidate = correct + offset
            if candidate != correct and candidate >= 0:
                wrong.add(candidate)

        options = list(wrong) + [correct]
        random.shuffle(options)

        return question, correct, options


default mg_intel_question  = ""
default mg_intel_correct   = 0
default mg_intel_options   = []
default mg_intel_current   = 0
default mg_intel_score     = 0
default mg_intel_answered  = False
default mg_intel_result    = ""
default mg_intel_time_left = 5


screen minigame_intelligence():
    modal True

    # Background
    add "images/ui/book.png"

    # Auto advance timer
    timer 5.0:
        action If(
            not mg_intel_answered,
            true=[
                SetVariable("mg_intel_answered", True),
                SetVariable("mg_intel_result", "timeout")
            ],
            false=NullAction()
        )

    # Countdown timer
    timer 1.0 repeat True:
        action If(
            not mg_intel_answered,
            true=SetVariable("mg_intel_time_left", mg_intel_time_left - 1),
            false=NullAction()
        )

    # --------------------------------------------------------
    # HEADER
    # --------------------------------------------------------
    frame:
        xalign 0.5
        yalign 0.05
        xsize 900
        ypadding 15
        xpadding 20
        background "#111111EE"
        hbox:
            spacing 30
            xalign 0.5
            text "🧠 Intelligence Quiz" size 22 bold True color "#FFD700"
            text "Question [mg_intel_current]/5" size 22 color "#CCCCCC"
            text "Score: [mg_intel_score]" size 22 color "#90EE90"

    # --------------------------------------------------------
    # LEFT FRAME — timer + question
    # x 360 y 300 to x 860 y 765
    # width = 860 - 360 = 500
    # height = 765 - 300 = 465
    # --------------------------------------------------------
    frame:
        xpos 360
        ypos 300
        xsize 500
        ysize 465
        background "#11111100"
        padding (30, 30)

        vbox:
            spacing 30
            xalign 0.5
            yalign 0.5

            # Timer
            text str(mg_intel_time_left) size 72 bold True xalign 0.5 outlines [(2, "#000000", 0, 0)] color (
                "#E74C3C" if mg_intel_time_left <= 1
                else "#FFD700" if mg_intel_time_left <= 2
                else "#FFFFFF"
            )

            # Question
            text mg_intel_question size 48 bold True xalign 0.5 color "#FFFFFF" outlines [(2, "#000000", 0, 0)]

    # --------------------------------------------------------
    # RIGHT FRAME — answers + continue button
    # x 1045 y 300 to x 1560 y 765
    # width = 1560 - 1045 = 515
    # height = 765 - 300 = 465
    # --------------------------------------------------------
    frame:
        xpos 1045
        ypos 300
        xsize 515
        ysize 465
        background "#11111100"
        padding (25, 25)

        vbox:
            spacing 20
            xalign 0.5
            yalign 0.5

            # Answer buttons 2x2
            hbox:
                spacing 15
                xalign 0.5
                vbox:
                    spacing 15
                    for i in [0, 1]:
                        if i < len(mg_intel_options):
                            $ opt = mg_intel_options[i]
                            textbutton str(opt):
                                xsize 220
                                xalign 0.5
                                sensitive not mg_intel_answered
                                action [
                                    SetVariable("mg_intel_answered", True),
                                    SetVariable("mg_intel_result",
                                        "correct" if opt == mg_intel_correct else "wrong"
                                    ),
                                    If(opt == mg_intel_correct,
                                        true=SetVariable("mg_intel_score", mg_intel_score + 1),
                                        false=NullAction()
                                    )
                                ]
                                text_size 28
                                text_xalign 0.5
                                text_outlines [(2, "#000000", 0, 0)]
                                text_color (
                                    "#90EE90" if (mg_intel_answered and opt == mg_intel_correct)
                                    else "#E74C3C" if (mg_intel_answered and opt != mg_intel_correct)
                                    else "#FFFFFF"
                                )
                vbox:
                    spacing 15
                    for i in [2, 3]:
                        if i < len(mg_intel_options):
                            $ opt = mg_intel_options[i]
                            textbutton str(opt):
                                xsize 220
                                xalign 0.5
                                text_outlines [(2, "#000000", 0, 0)]
                                sensitive not mg_intel_answered
                                action [
                                    SetVariable("mg_intel_answered", True),
                                    SetVariable("mg_intel_result",
                                        "correct" if opt == mg_intel_correct else "wrong"
                                    ),
                                    If(opt == mg_intel_correct,
                                        true=SetVariable("mg_intel_score", mg_intel_score + 1),
                                        false=NullAction()
                                    )
                                ]
                                text_size 28
                                text_xalign 0.5
                                text_color (
                                    "#90EE90" if (mg_intel_answered and opt == mg_intel_correct)
                                    else "#E74C3C" if (mg_intel_answered and opt != mg_intel_correct)
                                    else "#FFFFFF"
                                )

            # Feedback + continue
            if mg_intel_answered:
                null height 5
                if mg_intel_result == "correct":
                    text "✅ Correct!" size 26 color "#90EE90" xalign 0.5 outlines [(2, "#000000", 0, 0)]
                elif mg_intel_result == "wrong":
                    text "❌ Wrong!" size 26 color "#E74C3C" xalign 0.5 outlines [(2, "#000000", 0, 0)]
                else:
                    text "⏰ Time's up!" size 26 color "#FFD700" xalign 0.5 outlines [(2, "#000000", 0, 0)]

                textbutton "Next →":
                    xalign 0.5
                    text_outlines [(2, "#000000", 0, 0)]
                    action Return()
                    text_size 24
                    text_color "#FFD700"


label minigame_intelligence_start:

    $ mg_intel_score   = 0
    $ mg_intel_current = 0

    jump mg_intel_loop


label mg_intel_loop:

    if mg_intel_current >= 5:
        jump mg_intel_end

    python:
        q, c, opts         = generate_math_question()
        mg_intel_question  = q
        mg_intel_correct   = c
        mg_intel_options   = opts
        mg_intel_answered  = False
        mg_intel_result    = ""
        mg_intel_current  += 1
        mg_intel_time_left = 5

    call screen minigame_intelligence

    jump mg_intel_loop


label mg_intel_end:

    hide screen minigame_intelligence

    python:
        if mg_intel_score == 5:
            intel_gain = 5
        elif mg_intel_score >= 4:
            intel_gain = 4
        elif mg_intel_score >= 3:
            intel_gain = 3
        elif mg_intel_score >= 2:
            intel_gain = 2
        else:
            intel_gain = 1
        stat_intelligence += intel_gain

    "Quiz complete! You got [mg_intel_score]/5 correct."
    "Intelligence +[intel_gain]!"

    if stat_intelligence >= 20:
        $ discovered = try_unlock_recipe_from_study()
        if discovered and discovered in RECIPES:
            $ disc_recipe = RECIPES[discovered]
            "While studying you found a new recipe!"
            "[disc_recipe['icon']] [disc_recipe['name']] added to your recipe book!"
    $ advance_slot()

    jump location_library
