# ============================================================
# POKETOWN — minigames/books.rpy
# Book organizing — match book symbols to shelf slots
# 5 shelves total, 20 seconds per shelf, earn money per correct book
# ============================================================

init python:
    import random

    BOOK_SYMBOLS = ["🌟", "🔥", "💧", "🌿", "⚡", "🌙", "☀️", "🎵", "🎨", "🏆"]

    def generate_shelf(num_books=4):
        symbols = random.sample(BOOK_SYMBOLS, num_books)
        slots   = symbols[:]
        books   = symbols[:]
        random.shuffle(books)
        return slots, books

    def place_book():
        next_slot    = len(renpy.store.mg_books_placed)
        selected_idx = renpy.store.mg_books_selected

        if next_slot >= len(renpy.store.mg_books_slots):
            return
        if selected_idx is None:
            return

        book     = renpy.store.mg_books_hand[selected_idx]
        new_hand = list(renpy.store.mg_books_hand)
        new_hand[selected_idx] = None

        renpy.store.mg_books_placed   = renpy.store.mg_books_placed + [book]
        renpy.store.mg_books_hand     = new_hand
        renpy.store.mg_books_selected = None

        if len(renpy.store.mg_books_placed) == len(renpy.store.mg_books_slots):
            renpy.store.mg_books_complete = True


default mg_books_slots        = []
default mg_books_hand         = []
default mg_books_placed       = []
default mg_books_selected     = None
default mg_books_time_left    = 20
default mg_books_shelf        = 0
default mg_books_money_earned = 0
default mg_books_complete     = False
default mg_books_num_books    = 4
default mg_books_total        = 5


screen minigame_books():
    modal True

    # Background image
    add "images/ui/library.png"

    # Countdown timer
    if not mg_books_complete:
        timer 1.0 repeat True:
            action If(
                mg_books_time_left > 1,
                true=SetVariable("mg_books_time_left", mg_books_time_left - 1),
                false=[
                    SetVariable("mg_books_time_left", 0),
                    SetVariable("mg_books_complete", True),
                ]
            )

    # --------------------------------------------------------
    # HEADER
    # --------------------------------------------------------
    frame:
        xalign 0.5
        yalign 0.05
        xsize 930
        ypadding 15
        xpadding 20
        background "#111111EE"
        hbox:
            spacing 25
            xalign 0.5
            text "📚 Library Work" size 22 bold True color "#FFD700"
            text ("Shelf " + str(mg_books_shelf) + "/" + str(mg_books_total)) size 22 color "#CCCCCC"
            text ("⏰ " + str(mg_books_time_left) + "s") size 22 bold True color (
                "#E74C3C" if mg_books_time_left <= 5
                else "#FFD700" if mg_books_time_left <= 10
                else "#FFFFFF"
            )
            text ("Earned: $" + str(mg_books_money_earned)) size 22 color "#90EE90"

    # --------------------------------------------------------
    # SHELF SLOTS — books as tall rectangles (45x200)
    # Positions given as bottom-left corner:
    # 1. x700 y650  2. x950 y650  3. x1190 y650  4. x1410 y650
    # --------------------------------------------------------
    for i, symbol in enumerate(mg_books_slots):
        $ bx = [700, 950, 1190, 1410][i]
        $ by = 450

        if i == len(mg_books_placed) and not mg_books_complete:
            frame:
                xpos bx
                ypos by - 35
                xsize 45
                background "#00000000"
                text "V" size 20 color "#FFD700" xalign 0.5

        frame:
            xpos bx
            ypos by
            xsize 45
            ysize 200
            background "#00000000"

            if i < len(mg_books_placed):
                if mg_books_placed[i] == symbol:
                    background "#2E5C2E"
                else:
                    background "#5C2E2E"
                vbox:
                    xalign 0.5
                    yalign 0.5
                    text mg_books_placed[i] size 28 xalign 0.5
            else:
                # Ghost symbol showing target
                vbox:
                    xalign 0.5
                    yalign 0.5
                    text symbol size 28 xalign 0.5 color "#FFFFFF44"

    # --------------------------------------------------------
    # BOOKS IN HAND — square selector at bottom
    # --------------------------------------------------------
    frame:
        xalign 0.5
        ypos 720
        xsize 750
        ypadding 20
        xpadding 20
        background "#111111DD"

        vbox:
            spacing 12
            xalign 0.5

            text "Select a book to place:" size 20 color "#CCCCCC" xalign 0.5

            hbox:
                spacing 15
                xalign 0.5
                for i, book in enumerate(mg_books_hand):
                    if book is not None:
                        $ is_selected = (mg_books_selected == i)
                        vbox:
                            spacing 4
                            xalign 0.5

                            if is_selected:
                                text "^" size 20 color "#FFD700" xalign 0.5
                            else:
                                text " " size 20 xalign 0.5

                            frame:
                                xsize 100
                                ysize 100
                                if is_selected:
                                    background "#FFD70066"
                                else:
                                    background "#333333"

                                vbox:
                                    xalign 0.5
                                    yalign 0.5
                                    text book size 36 xalign 0.5

                                button:
                                    xsize 100
                                    ysize 100
                                    xpos 0
                                    ypos 0
                                    background "#00000000"
                                    action If(
                                        not mg_books_complete,
                                        true=If(
                                            mg_books_selected == i,
                                            true=SetVariable("mg_books_selected", None),
                                            false=SetVariable("mg_books_selected", i)
                                        ),
                                        false=NullAction()
                                    )

            # Place button
            if mg_books_selected is not None and not mg_books_complete:
                textbutton "📥 Place book":
                    xalign 0.5
                    action Function(place_book)
                    text_size 22
                    text_color "#FFD700"

            # Result feedback
            if mg_books_complete:
                if len(mg_books_placed) == len(mg_books_slots):
                    python:
                        _correct = sum(
                            1 for i in range(len(mg_books_placed))
                            if mg_books_placed[i] == mg_books_slots[i]
                        )
                    if _correct == mg_books_num_books:
                        text "✅ Perfect shelf!" size 24 color "#90EE90" xalign 0.5
                    else:
                        text ("✅ " + str(_correct) + "/" + str(mg_books_num_books) + " correct!") size 24 color "#FFD700" xalign 0.5
                else:
                    text "⏰ Time's up!" size 24 color "#E74C3C" xalign 0.5

                if mg_books_shelf < mg_books_total:
                    textbutton "Next Shelf →":
                        xalign 0.5
                        action Return()
                        text_size 24
                        text_color "#FFD700"
                else:
                    textbutton "Finish →":
                        xalign 0.5
                        action Return()
                        text_size 24
                        text_color "#FFD700"


label minigame_books_start:

    $ mg_books_shelf        = 0
    $ mg_books_money_earned = 0

    jump mg_books_loop


label mg_books_loop:

    if mg_books_shelf >= mg_books_total:
        jump mg_books_end

    python:
        slots, books        = generate_shelf(mg_books_num_books)
        mg_books_slots      = slots
        mg_books_hand       = books
        mg_books_placed     = []
        mg_books_selected   = None
        mg_books_time_left  = 7
        mg_books_complete   = False
        mg_books_shelf     += 1

    call screen minigame_books

    python:
        correct_placements = sum(
            1 for i in range(min(len(mg_books_placed), len(mg_books_slots)))
            if mg_books_placed[i] == mg_books_slots[i]
        )
        mg_books_money_earned += correct_placements * 5

    jump mg_books_loop


label mg_books_end:

    $ money += mg_books_money_earned

    if mg_books_money_earned >= 55:
        "Excellent work! The library has never been so organized."
    elif mg_books_money_earned >= 35:
        "Good effort. A few books out of place but not bad."
    else:
        "It's a start. Keep practicing."

    "You earned $[mg_books_money_earned] organizing books!"
    $ advance_slot()

    jump location_library
