# ============================================================
# POKETOWN — minigames/fishing.rpy
# Fishing — click to catch as many fish as possible in 20 seconds
# Clicks required per fish: max(1, randint(10,15) - physique*0.1)
# Reward: $5 per fish caught
# ============================================================

default mg_fish_clicks_done     = 0
default mg_fish_clicks_required = 10
default mg_fish_total           = 0
default mg_fish_time_left       = 20
default mg_fish_running         = False
default mg_fish_just_caught     = False


screen minigame_fishing():
    modal True

    if mg_fish_just_caught:
        add "images/backgrounds/fishing_caught.png"
    else:
        add "images/backgrounds/fishing.png"

    if mg_fish_running:
        timer 1.0 repeat True:
            action If(
                mg_fish_time_left > 1,
                true=SetVariable("mg_fish_time_left", mg_fish_time_left - 1),
                false=[
                    SetVariable("mg_fish_time_left", 0),
                    SetVariable("mg_fish_running", False),
                    Return(),
                ]
            )

    # Header
    frame:
        xalign 0.5
        yalign 0.05
        xsize 900
        ypadding 15
        xpadding 20
        background "#111111EE"
        hbox:
            spacing 30
            xalign 0.5
            text "🎣 Fishing" size 22 bold True color "#FFD700"
            text ("🐟 " + str(mg_fish_total) + " caught") size 22 color "#90EE90"
            text str(mg_fish_time_left) size 22 bold True color (
                "#E74C3C" if mg_fish_time_left <= 5
                else "#FFD700" if mg_fish_time_left <= 10
                else "#FFFFFF"
            )

    # Main frame
    frame:
        xalign 0.5
        yalign 0.45
        xsize 750
        ypadding 40
        xpadding 40
        background "#111111EE"

        vbox:
            spacing 25
            xalign 0.5

            hbox:
                spacing 10
                xalign 0.5
                text str(mg_fish_clicks_done) size 40 bold True color "#90EE90"
                text " / " size 40 color "#CCCCCC"
                text str(mg_fish_clicks_required) size 40 bold True color "#FFFFFF"

            text "clicks to reel in" size 22 xalign 0.5 color "#888888"

            null height 10

            if mg_fish_running and not mg_fish_just_caught:
                textbutton "🎣 CAST!":
                    yoffset 20
                    xalign 0.5
                    xsize 450
                    action If(
                        mg_fish_clicks_done + 1 < mg_fish_clicks_required,
                        true=SetVariable("mg_fish_clicks_done", mg_fish_clicks_done + 1),
                        false=[
                            SetVariable("mg_fish_clicks_done", mg_fish_clicks_required),
                            SetVariable("mg_fish_total", mg_fish_total + 1),
                            SetVariable("mg_fish_just_caught", True),
                        ]
                    )
                    text_size 32
                    text_xalign 0.5
                    text_color "#FFD700"

            elif mg_fish_just_caught:
                text "🐟 Got one!" size 30 bold True color "#90EE90" xalign 0.5
                textbutton "Cast again →":
                    xalign 0.5
                    xsize 450
                    action [
                        SetVariable("mg_fish_just_caught", False),
                        SetVariable("mg_fish_clicks_done", 0),
                        Function(fishing_new_fish),
                    ]
                    text_size 28
                    text_xalign 0.5
                    text_color "#FFD700"


init python:
    import random

    def fishing_new_fish():
        base = random.randint(10, 15)
        reduction = renpy.store.stat_physique * 0.1
        renpy.store.mg_fish_clicks_required = max(1, int(base - reduction))


label minigame_fishing_start:

    python:
        import random
        base = random.randint(10, 15)
        reduction = stat_physique * 0.1
        mg_fish_clicks_required = max(1, int(base - reduction))
        mg_fish_clicks_done     = 0
        mg_fish_total           = 0
        mg_fish_time_left       = 20
        mg_fish_running         = True
        mg_fish_just_caught     = False

    call screen minigame_fishing

    jump mg_fish_end


label mg_fish_end:

    $ fish_earnings = mg_fish_total * 3
    $ money += fish_earnings

    if mg_fish_total == 0:
        "The fish weren't biting today."
    elif mg_fish_total < 5:
        "Not bad. You caught [mg_fish_total] fish!"
    elif mg_fish_total < 10:
        "Great session! [mg_fish_total] fish caught."
    else:
        "Incredible! [mg_fish_total] fish, you're a natural."

    "You earned $[fish_earnings] from fishing!"

    $ advance_slot()
    jump time_slot
