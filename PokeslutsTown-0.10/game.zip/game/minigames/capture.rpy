# ============================================================
# POKETOWN — minigames/capture.rpy
# Pokemon capture — Pokeballs appear and disappear
# ============================================================
default mg_cap_balls        = []
default mg_cap_clicked      = []
default mg_cap_time_left    = 8
default mg_cap_total        = 15
default mg_cap_running      = False
default mg_cap_result       = False


screen minigame_capture_screen():
    modal True
    add ("images/pokemon/" + encountered_poke + "/bg.png")

    # Countdown timer
    if mg_cap_running:
        timer 1.0 repeat True:
            action If(
                mg_cap_time_left > 1,
                true=SetVariable("mg_cap_time_left", mg_cap_time_left - 1),
                false=[
                    SetVariable("mg_cap_time_left", 0),
                    SetVariable("mg_cap_running", False),
                    SetVariable("mg_cap_result", False),
                    Return(False),
                ]
            )

    # Header
    frame:
        xalign 0.5
        yalign 0.05
        xsize 900
        ypadding 12
        xpadding 20
        background "#111111ad"

        hbox:
            spacing 30
            xalign 0.5
            text "🎯 Catch it!" size 22 bold True color "#FFD700"
            text ("Remaining: " + str(mg_cap_total - len(mg_cap_clicked)) + "/" + str(mg_cap_total)) size 22 color "#CCCCCC"
            text str(mg_cap_time_left) size 30 bold True color (
                "#E74C3C" if mg_cap_time_left <= 3
                else "#FFD700" if mg_cap_time_left <= 5
                else "#FFFFFF"
            )

    # Game area — Pokeballs scattered on screen
    for ball in mg_cap_balls:
        if ball["id"] not in mg_cap_clicked:
            $ bid = ball["id"]
            $ bx  = ball["x"]
            $ by  = ball["y"]
            button:
                xpos bx
                ypos by
                xsize 120
                ysize 120
                background "#00000000"
                action If(
                    mg_cap_running,
                    true=[
                        SetVariable("mg_cap_clicked", mg_cap_clicked + [bid]),
                        If(
                            len(mg_cap_clicked) + 1 >= mg_cap_total,
                            true=[
                                SetVariable("mg_cap_running", False),
                                SetVariable("mg_cap_result", True),
                                Return(True),
                            ],
                            false=NullAction()
                        )
                    ],
                    false=NullAction()
                )
                add "images/ui/pokeball.png" xalign 0.5 yalign 0.5


label minigame_capture_start:

    python:
        import random
        _divisor = 2 if renpy.store.capture_difficulty == "easy" else 1
        renpy.store.mg_cap_total     = max(6, random.randint(2, 20) // _divisor)
        renpy.store.mg_cap_balls     = generate_pokeballs(renpy.store.mg_cap_total)
        renpy.store.mg_cap_clicked   = []
        renpy.store.mg_cap_time_left = 8
        renpy.store.mg_cap_running   = True
        renpy.store.mg_cap_result    = False

    $ result = renpy.call_screen("minigame_capture_screen")
    return result