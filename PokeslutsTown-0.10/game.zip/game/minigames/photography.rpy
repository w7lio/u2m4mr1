# ============================================================
# POKETOWN — minigames/photography.rpy
# Photography — 5 photos, click as close to focal point as possible
# Earnings scale proportionally to precision
# ============================================================

init python:
    import random

    def calculate_photo_earnings(focal, clicked, max_earn):
        distance = abs(focal - clicked)
        precision = max(0.0, 1.0 - (distance / 50.0))
        return int(max_earn * precision)


default mg_photo_current     = 0
default mg_photo_total_earn  = 0
default mg_photo_focal       = 50
default mg_photo_bar_value   = 0
default mg_photo_direction   = 1
default mg_photo_clicked     = False
default mg_photo_earn        = 0
default mg_photo_max_earn    = 25
default mg_photo_speed       = 2


screen minigame_photography():
    modal True

    add "images/ui/studio_shoot.png"

    if not mg_photo_clicked:
        timer 0.05 repeat True:
            action If(
                mg_photo_bar_value + mg_photo_direction * mg_photo_speed > 100
                or mg_photo_bar_value + mg_photo_direction * mg_photo_speed < 0,
                true=[
                    SetVariable("mg_photo_direction", mg_photo_direction * -1),
                    SetVariable("mg_photo_bar_value",
                        mg_photo_bar_value + mg_photo_direction * mg_photo_speed * -1
                    ),
                ],
                false=SetVariable("mg_photo_bar_value",
                    mg_photo_bar_value + mg_photo_direction * mg_photo_speed
                )
            )

    # HEADER
    frame:
        xalign 0.5
        yalign 0.05
        xsize 900
        ypadding 15
        xpadding 20
        background "#111111EE"
        hbox:
            spacing 30
            xalign 0.5
            text "📸 Photography" size 22 bold True color "#FFD700"
            text "Photo [mg_photo_current]/5" size 22 color "#CCCCCC"
            text "Earned: $[mg_photo_total_earn]" size 22 color "#90EE90"

    # FOCAL BAR — x 635-1095, y 495-520
    frame:
        xpos 635
        ypos 495
        xsize 460
        ysize 25
        background "#222222EE"
        frame:
            xpos int(mg_photo_focal / 100.0 * 460) - 3
            ypos -2
            xsize 5
            ysize 25
            background "#90EE90"
        frame:
            xpos int(mg_photo_bar_value / 100.0 * 460) - 3
            ypos -2
            xsize 5
            ysize 25
            background "#FFD700"

    # Labels under bar
    frame:
        xpos 635
        ypos 455
        xsize 460
        background "#00000000"
        hbox:
            xsize 460
            text "0" size 16 color "#AAAAAA" xalign 0.0
            text "🟢 Focal point" size 16 color "#90EE90" xalign 0.5
            text "100" size 16 color "#AAAAAA" xalign 1.0

    # SHOOT BUTTON — x 1200, y 685
    if not mg_photo_clicked:
        button:
            xpos 1125
            ypos 635
            xsize 100
            ysize 100
            background "#FFD70033"
            hover_background "#FFD70066"
            action [
                SetVariable("mg_photo_clicked", True),
                SetVariable("mg_photo_earn",
                    calculate_photo_earnings(
                        mg_photo_focal,
                        mg_photo_bar_value,
                        mg_photo_max_earn
                    )
                )
            ]
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 4
                text "📷" size 36 xalign 0.5
                frame:
                    background "#00000088"
                    padding (8, 4)
                    text "SHOOT!" size 18 bold True color "#FFD700" xalign 0.5

    # RESULT BOX — x 565-1340, y 885-1045
    if mg_photo_clicked:
        frame:
            xpos 565
            ypos 885
            xsize 775
            ysize 160
            background "#111111EE"
            padding (20, 15)
            vbox:
                spacing 10
                xalign 0.5
                hbox:
                    spacing 15
                    xalign 0.5
                    text "Focal: " size 20 color "#CCCCCC"
                    text str(mg_photo_focal) size 20 bold True color "#90EE90"
                    text "  Your shot: " size 20 color "#CCCCCC"
                    text str(mg_photo_bar_value) size 20 bold True color "#FFD700"
                if mg_photo_earn >= mg_photo_max_earn * 0.8:
                    text "🌟 Perfect shot!" size 24 color "#90EE90" xalign 0.5
                elif mg_photo_earn >= mg_photo_max_earn * 0.5:
                    text "👍 Good shot!" size 24 color "#FFD700" xalign 0.5
                else:
                    text "📷 Keep practicing." size 24 color "#E74C3C" xalign 0.5
                hbox:
                    spacing 20
                    xalign 0.5
                    text ("$" + str(mg_photo_earn) + " earned") size 22 bold True color "#90EE90"
                    textbutton "Next →":
                        action Return()
                        text_size 22
                        text_color "#FFD700"


label minigame_photography_start:

    $ mg_photo_current    = 0
    $ mg_photo_total_earn = 0

    jump mg_photo_loop


label mg_photo_loop:

    if mg_photo_current >= 5:
        jump mg_photo_end

    python:
        import random
        mg_photo_focal      = random.randint(20, 80)
        mg_photo_bar_value  = 0
        mg_photo_direction  = 1
        mg_photo_clicked    = False
        mg_photo_earn       = 0
        mg_photo_current   += 1
        mg_photo_speed      = 2 + (mg_photo_current - 1)

    call screen minigame_photography

    $ mg_photo_total_earn += mg_photo_earn

    jump mg_photo_loop


label mg_photo_end:

    $ money += mg_photo_total_earn

    if mg_photo_total_earn >= 65:
        "Incredible work today. Penny is impressed."
    elif mg_photo_total_earn >= 35:
        "Not bad. You're getting the hang of it."
    else:
        "Rough session. The light wasn't on your side today."

    "You earned $[mg_photo_total_earn] from photography!"
    $ advance_slot()

    jump location_studio
