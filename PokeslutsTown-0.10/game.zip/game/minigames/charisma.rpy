# ============================================================
# POKETOWN — minigames/charisma.rpy
# Customer service — 5 customers, match the symbol, 2 sec each
# Result defines Charisma gain and money earned
# ============================================================

init python:
    import random

    # Symbol pairs — each customer shows a need, player picks correct response
    CUSTOMER_SYMBOLS = [
        ("☕", "☕", "🍵", "🧃", "🍺", "🥤", "🍶"),
        ("🍰", "🍰", "🍩", "🍪", "🥐", "🧁", "🍮"),
        ("🧃", "🧃", "☕", "🍵", "🥤", "🍺", "🍶"),
        ("🍵", "🍵", "☕", "🧃", "🍺", "🥤", "🍶"),
        ("🥐", "🥐", "🍰", "🍩", "🍪", "🧁", "🍮"),
        ("🍩", "🍩", "🥐", "🍰", "🍪", "🧁", "🍮"),
        ("🥤", "🥤", "🧃", "☕", "🍵", "🍺", "🍶"),
        ("🍶", "🍶", "🧃", "☕", "🍵", "🍺", "🥤"),
        ("🍮", "🍮", "🍩", "🍪", "🥐", "🧁", "🍰"),
        ("🍪", "🍪", "🍰", "🍩", "🥐", "🧁", "🍮")
    ]

    def generate_customer():
        symbol_set = random.choice(CUSTOMER_SYMBOLS)
        request    = symbol_set[0]
        correct    = symbol_set[1]
        options    = list(symbol_set[1:])   # now 6 options
        random.shuffle(options)
        return request, correct, options


default mg_char_request    = ""
default mg_char_correct    = ""
default mg_char_options    = []
default mg_char_current    = 0
default mg_char_score      = 0
default mg_char_answered   = False
default mg_char_result     = ""
default mg_char_time_left  = 2
default mg_char_money_earn = 0


screen minigame_charisma():
    modal True
    add "images/ui/menu.png"

    # Countdown timer
    if not mg_char_answered:
        timer 1.0 repeat True:
            action If(
                mg_char_time_left > 1,
                true=SetVariable("mg_char_time_left", mg_char_time_left - 1),
                false=[
                    SetVariable("mg_char_time_left", 0),
                    SetVariable("mg_char_answered", True),
                    SetVariable("mg_char_result", "timeout"),
                ]
            )

    # Header
    frame:
        xalign 0.5
        yalign 0.05
        xsize 750
        ypadding 15
        xpadding 20
        background "#111111EE"

        hbox:
            spacing 30
            xalign 0.5
            text "☕ Cafe Work" size 22 bold True color "#FFD700"
            text "Customer [mg_char_current]/5" size 22 color "#CCCCCC"
            text "Score: [mg_char_score]" size 22 color "#90EE90"

    # Main frame
    frame:
        xalign 0.5
        yalign 0.42
        xsize 750
        ypadding 30
        xpadding 40
        background "#00000000"

        vbox:
            spacing 20
            xalign 0.5

            # Timer
            text str(mg_char_time_left) size 48 bold True xalign 0.5 color (
                "#E74C3C" if mg_char_time_left <= 1
                else "#FFD700" if mg_char_time_left <= 2
                else "#FFFFFF"
            )

            # Customer request
            frame:
                xalign 0.5
                xsize 450
                ypadding 20
                background "#22222200"
                vbox:
                    spacing 10
                    xalign 0.5
                    text "Customer wants:" size 20 color "#000000" xalign 0.5
                    text mg_char_request size 56 xalign 0.5

            null height 10

            # Answer options — 2x2 grid
            hbox:
                spacing 20
                xalign 0.5
                vbox:
                    spacing 15
                    for i in [0, 1, 2]:
                        if i < len(mg_char_options):
                            $ opt = mg_char_options[i]
                            textbutton opt:
                                xsize 240
                                xalign 0.5
                                sensitive not mg_char_answered
                                action [
                                    SetVariable("mg_char_answered", True),
                                    SetVariable("mg_char_result",
                                        "correct" if opt == mg_char_correct else "wrong"
                                    ),
                                    If(opt == mg_char_correct,
                                        true=SetVariable("mg_char_score", mg_char_score + 1),
                                        false=NullAction()
                                    )
                                ]
                                text_size 40
                                text_xalign 0.5
                                text_color (
                                    "#90EE90" if (mg_char_answered and opt == mg_char_correct)
                                    else "#E74C3C" if (mg_char_answered and opt != mg_char_correct)
                                    else "#FFFFFF"
                                )
                vbox:
                    spacing 15
                    for i in [3, 4, 5]:
                        if i < len(mg_char_options):
                            $ opt = mg_char_options[i]
                            textbutton opt:
                                xsize 240
                                xalign 0.5
                                sensitive not mg_char_answered
                                action [
                                    SetVariable("mg_char_answered", True),
                                    SetVariable("mg_char_result",
                                        "correct" if opt == mg_char_correct else "wrong"
                                ),
                                    If(opt == mg_char_correct,
                                        true=SetVariable("mg_char_score", mg_char_score + 1),
                                        false=NullAction()
                                    )
                                ]
                                text_size 40
                                text_xalign 0.5
                                text_color (
                                    "#90EE90" if (mg_char_answered and opt == mg_char_correct)
                                    else "#E74C3C" if (mg_char_answered and opt != mg_char_correct)
                                    else "#FFFFFF"
                                )

    # Feedback + next
    if mg_char_answered:
        frame:
            xalign 0.5
            yalign 0.82
            xsize 750
            ypadding 20
            xpadding 20
            background "#11111100"

            vbox:
                spacing 15
                xalign 0.5

                if mg_char_result == "correct":
                    text "✅ Correct!" size 26 color "#90EE90" xalign 0.5 outlines [(2, "#000000", 0, 0)]
                elif mg_char_result == "wrong":
                    text "❌ Wrong!" size 26 color "#E74C3C" xalign 0.5 outlines [(2, "#000000", 0, 0)]
                else:
                    text "⏰ Too slow!" size 26 color "#FFD700" xalign 0.5 outlines [(2, "#000000", 0, 0)]

                textbutton "Next →":
                    xalign 0.5
                    action Return()
                    text_size 24
                    text_color "#FFD700"
                    text_outlines [(2, "#000000", 0, 0)]

label minigame_charisma_start:

    $ mg_char_score    = 0
    $ mg_char_current  = 0
    $ mg_char_money_earn = 0

    jump mg_char_loop


label mg_char_loop:

    if mg_char_current >= 5:
        jump mg_char_end

    python:
        req, cor, opts     = generate_customer()
        mg_char_request    = req
        mg_char_correct    = cor
        mg_char_options    = opts
        mg_char_answered   = False
        mg_char_result     = ""
        mg_char_time_left  = 3
        mg_char_current   += 1

    call screen minigame_charisma

    jump mg_char_loop


label mg_char_end:

    python:
        # Charisma gain
        if mg_char_score == 5:
            charisma_gain = 5
        elif mg_char_score >= 4:
            charisma_gain = 4
        elif mg_char_score >= 3:
            charisma_gain = 3
        elif mg_char_score >= 2:
            charisma_gain = 2
        elif mg_char_score >= 1:
            charisma_gain = 1
        else:
            charisma_gain = 0

        # Money earned — scales with score
        mg_char_money_earn = mg_char_score * 12
        stat_charisma += charisma_gain
        money += mg_char_money_earn

    "Shift complete! You served [mg_char_score]/5 customers correctly."

    if mg_char_score > 0:
        "Charisma +[charisma_gain]!"
        "You earned $[mg_char_money_earn]!"
    else:
        "Better luck next shift."
    $ advance_slot()

    jump location_cafe 
