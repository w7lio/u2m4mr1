# ============================================================
# POKETOWN — minigames/strength.rpy
# Strength training — clicking race against growing requirements
# Round 1: 6 clicks in 4 seconds, +1 click per round
# Every 4 rounds = +1 Physique
# ============================================================

init python:
    pass

default mg_str_clicks_required = 6
default mg_str_clicks_done     = 0
default mg_str_round           = 0
default mg_str_time_left       = 4
default mg_str_running         = False
default mg_str_failed          = False
default mg_str_physique_gain   = 0


screen minigame_strength():
    modal True
    if mg_str_running and not mg_str_failed:
        add "images/ui/gym.png"

    elif not mg_str_failed and not mg_str_running:
        add "images/ui/gym1.png"

    elif mg_str_failed:
        add "images/ui/gym1.png"

    # Round timer
    if mg_str_running and not mg_str_failed:
        timer 1.0 repeat True:
            action If(
                mg_str_time_left > 1,
                true=SetVariable("mg_str_time_left", mg_str_time_left - 1),
                false=[
                    SetVariable("mg_str_time_left", 0),
                    SetVariable("mg_str_running", False),
                    SetVariable("mg_str_failed", True),
                ]
            )

    # Header
    frame:
        xalign 0.5
        yalign 0.05
        xsize 900
        ypadding 15
        xpadding 20
        background "#111111EE"
        hbox:
            spacing 30
            xalign 0.5
            text "💪 Strength Training" size 22 bold True color "#FFD700"
            text "Round [mg_str_round]" size 22 color "#CCCCCC"
            text ("Physique +" + str(mg_str_physique_gain)) size 22 color "#90EE90"

    # Main frame
    frame:
        xalign 0.5
        yalign 0.45
        xsize 750
        ypadding 40
        xpadding 40
        background "#111111EE"

        vbox:
            spacing 25
            xalign 0.5

            text str(mg_str_time_left) size 56 bold True xalign 0.5 color (
                "#E74C3C" if mg_str_time_left <= 1
                else "#FFD700" if mg_str_time_left <= 2
                else "#FFFFFF"
            )

            hbox:
                spacing 10
                xalign 0.5
                text str(mg_str_clicks_done) size 40 bold True color "#90EE90"
                text " / " size 40 color "#CCCCCC"
                text str(mg_str_clicks_required) size 40 bold True color "#FFFFFF"

            text "clicks" size 22 xalign 0.5 color "#888888"

            null height 10

            if mg_str_running and not mg_str_failed:
                textbutton "🏋️ LIFT!":
                    xalign 0.5
                    xsize 450
                    action If(
                        mg_str_clicks_done + 1 < mg_str_clicks_required,
                        true=SetVariable("mg_str_clicks_done", mg_str_clicks_done + 1),
                        false=[
                            SetVariable("mg_str_clicks_done", mg_str_clicks_required),
                            SetVariable("mg_str_running", False),
                        ]
                    )
                    text_size 32
                    text_xalign 0.5
                    text_color "#FFD700"

            elif not mg_str_failed and not mg_str_running:
                text "✅ Round complete!" size 26 color "#90EE90" xalign 0.5
                textbutton "Next Round →":
                    xalign 0.5
                    action Return("next")
                    text_size 24
                    text_color "#FFD700"

            elif mg_str_failed:
                text "❌ Too slow!" size 26 color "#E74C3C" xalign 0.5
                textbutton "Finish":
                    xalign 0.5
                    action Return("fail")
                    text_size 24
                    text_color "#888888"


label minigame_strength_start:

    $ mg_str_clicks_required = 6
    $ mg_str_clicks_done     = 0
    $ mg_str_round           = 0
    $ mg_str_failed          = False
    $ mg_str_physique_gain   = 0

    jump mg_str_loop


label mg_str_loop:

    $ mg_str_round         += 1
    $ mg_str_clicks_done    = 0
    $ mg_str_time_left      = 4
    $ mg_str_running        = True
    $ mg_str_failed         = False

    $ result = renpy.call_screen("minigame_strength")

    if result == "fail":
        jump mg_str_end
    else:
        if mg_str_round % 3 == 0:
            $ mg_str_physique_gain += 1

        $ mg_str_clicks_required += 1

        jump mg_str_loop


label mg_str_end:

    $ stat_physique += mg_str_physique_gain

    if mg_str_physique_gain == 0:
        "You didn't complete enough rounds this time."
        "Keep training!"
    else:
        "Training complete! You completed [mg_str_round - 1] rounds."
        "Physique +[mg_str_physique_gain]!"
    $ advance_slot()

    jump location_gym
