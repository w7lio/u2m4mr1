# ============================================================
# POKETOWN — definitions.rpy
# Global variables, characters and game state
# ============================================================

# ------------------------------------------------------------
# PLAYER
# ------------------------------------------------------------
default player_name = ""
default title_blink = True
default show_menu_options = False
# ------------------------------------------------------------
# TIME SYSTEM
# ------------------------------------------------------------
default current_day = 1
default current_slot = 0
# Slots: 0=Morning, 1=Day, 2=Afternoon, 3=Night, 4=Midnight

default slot_names = ["Morning", "Day", "Afternoon", "Night", "Midnight"]

# ------------------------------------------------------------
# STATS
# ------------------------------------------------------------
default stat_physique = 0
default stat_charisma = 0
default stat_intelligence = 0
default capture_difficulty = "normal"
# ------------------------------------------------------------
# MONEY
# ------------------------------------------------------------
default money = 0
# ------------------------------------------------------------
# CODES
# ------------------------------------------------------------
default used_cheat_codes = []
default cheat_code_input = ""
# ------------------------------------------------------------
# HOVER
# ------------------------------------------------------------
transform glow_on_hover:
    on idle:
        linear 0.2 matrixcolor BrightnessMatrix(0.0)
        alpha 1.0
    on hover:
        matrixcolor TintMatrix("#fffeb0") * BrightnessMatrix(0.5)
        linear 0.2 alpha 0.8
# ------------------------------------------------------------
# GIFT SYSTEM
# ------------------------------------------------------------
default gifts_given_today = {}
# Format: {"char_id": True}

define GENERAL_GIFTS = [
    {"id": "rose",            "name": "A Rose",                     "icon": "🌹", "price": 10,  "affection": 7},
    {"id": "chocolates",      "name": "A Box of Chocolates",        "icon": "🍫", "price": 20,  "affection": 15},
    {"id": "teddy_bear",      "name": "A Giant Teddy Bear",         "icon": "🧸", "price": 30,  "affection": 23},
    {"id": "perfume",         "name": "A Designer Perfume",         "icon": "🌸", "price": 40,  "affection": 32},
    {"id": "gold_necklace",   "name": "Gold Necklace and Earrings", "icon": "📿", "price": 50,  "affection": 40},
]

# ------------------------------------------------------------
# GARDEN
# ------------------------------------------------------------
default garden_slots = 9
default garden_plots = [None, None, None, None, None, None, None, None, None]
default garden_plot_target = 0
default garden_speed_level  = 0  
default garden_yield_level  = 0  

# ------------------------------------------------------------
# MISSIONS
# ------------------------------------------------------------
default accepted_missions = []
default active_missions = []
default missions_generated_today = False

# ------------------------------------------------------------
# INVENTORY
# ------------------------------------------------------------
default inventory_key_items = []
default inventory_gifts = []
default inventory_clothing = []
default inventory_seeds = []
default inventory_food = []
default inventory_clothing_ids = []
default purchased_stat_books = []
# ------------------------------------------------------------
# RECIPES
# ------------------------------------------------------------
default unlocked_recipes = []

# ------------------------------------------------------------
# POKEDEX
# ------------------------------------------------------------
default pokedex = {}
# Format: {"pokemon_id": {"discovered": True, "captured": False, "trust": 0}}
# ------------------------------------------------------------
# GALLERY
# ------------------------------------------------------------
define mflash = Fade(0.2, 0.0, 0.2, color="#ffffff")
define flash = ComposeTransition(mflash, mflash)
define gallery_replay = False
default gallery_unlocked = {}
define CHARACTER_CG_DATA = {
    "erika": [
        {"id": "Erika 01", "event": 2, "path": "images/cg/erika/Erika01.png",  "label": "erika_first_encounter"},
        {"id": "Erika 02", "event": 3, "path": "images/cg/erika/Erika02.png",  "label": "erika_second_encounter"},
        {"id": "Erika 03", "event": 4, "path": "images/cg/erika/Erika03.png",  "label": "erika_third_encounter"},
        {"id": "Erika 04", "event": 4, "path": "images/cg/erika/Erika03a.png", "label": None},
        {"id": "Erika 05", "event": 5, "path": "images/cg/erika/Erika04.png",  "label": "erika_fourth_encounter"},
        {"id": "Erika 06", "event": 5, "path": "images/cg/erika/Erika04a.png", "label": None},
        {"id": "Erika 07", "event": 6, "path": "images/cg/erika/Erika05.png",  "label": "erika_fifth_encounter"},
        {"id": "Erika 08", "event": 6, "path": "images/cg/erika/Erika05a.png", "label": None},
        {"id": "Erika 09", "event": 7, "path": "images/cg/erika/Erika06.png",  "label": "erika_sixth_encounter"},
        {"id": "Erika 10", "event": 7, "path": "images/cg/erika/Erika06a.png", "label": None},
        {"id": "Erika 11", "event": 8, "path": "images/cg/erika/Erika07.png",  "label": "erika_seventh_encounter"},
    ],
    "elesa": [
        {"id": "Elesa 00", "event": 2, "path": None,                           "label": "elesa_first_encounter"},
        {"id": "Elesa 01", "event": 3, "path": "images/cg/elesa/Elesa01.png",  "label": "elesa_second_encounter"},
        {"id": "Elesa 00", "event": 4, "path": None,                           "label": "elesa_third_encounter"},
        {"id": "Elesa 02", "event": 5, "path": "images/cg/elesa/Elesa02.png",  "label": "elesa_fourth_encounter"},
        {"id": "Elesa 03", "event": 5, "path": "images/cg/elesa/Elesa02a.png", "label": None},
        {"id": "Elesa 04", "event": 6, "path": "images/cg/elesa/Elesa03.png",  "label": "elesa_fifth_encounter"},
        {"id": "Elesa 05", "event": 7, "path": "images/cg/elesa/Elesa04.png",  "label": "elesa_sixth_encounter"},
        {"id": "Elesa 06", "event": 7, "path": "images/cg/elesa/Elesa04a.png", "label": None},
        {"id": "Elesa 07", "event": 8, "path": "images/cg/elesa/Elesa05.png",  "label": "elesa_seventh_encounter"},
        {"id": "Elesa 08", "event": 8, "path": "images/cg/elesa/Elesa05a.png", "label": None},
    ],
    "roxanne": [
        {"id": "Roxanne 01", "event": 2, "path": "images/cg/roxanne/Roxanne01.png",  "label": "roxanne_first_encounter"},
        {"id": "Roxanne 02", "event": 3, "path": "images/cg/roxanne/Roxanne02.png",  "label": "roxanne_second_encounter"},
        {"id": "Roxanne 03", "event": 4, "path": "images/cg/roxanne/Roxanne03.png",  "label": "roxanne_third_encounter"},
        {"id": "Roxanne 04", "event": 5, "path": "images/cg/roxanne/Roxanne04.png",  "label": "roxanne_fourth_encounter"},
        {"id": "Roxanne 05", "event": 6, "path": "images/cg/roxanne/Roxanne05.png",  "label": "roxanne_fifth_encounter"},
        {"id": "Roxanne 06", "event": 6, "path": "images/cg/roxanne/Roxanne05a.png", "label": None},
        {"id": "Roxanne 07", "event": 7, "path": "images/cg/roxanne/Roxanne06.png",  "label": "roxanne_sixth_encounter"},
        {"id": "Roxanne 08", "event": 8, "path": "images/cg/roxanne/Roxanne07.png",  "label": "roxanne_seventh_encounter"},
        {"id": "Roxanne 09", "event": 8, "path": "images/cg/roxanne/Roxanne08.png",  "label": None},
        {"id": "Roxanne 10", "event": 8, "path": "images/cg/roxanne/Roxanne08a.png", "label": None},
    ],
    "cynthia": [
        {"id": "Cynthia 00", "event": 2, "path": None,                               "label": "cynthia_first_encounter"},
        {"id": "Cynthia 01", "event": 3, "path": "images/cg/cynthia/Cynthia01.png",  "label": "cynthia_second_encounter"},
        {"id": "Cynthia 02", "event": 4, "path": "images/cg/cynthia/Cynthia02.png",  "label": "cynthia_third_encounter"},
        {"id": "Cynthia 03", "event": 5, "path": "images/cg/cynthia/Cynthia03.png",  "label": "cynthia_fourth_encounter"},
        {"id": "Cynthia 04", "event": 6, "path": "images/cg/cynthia/Cynthia04.png",  "label": "cynthia_fifth_encounter"},
        {"id": "Cynthia 05", "event": 6, "path": "images/cg/cynthia/Cynthia04a.png", "label": None},
        {"id": "Cynthia 06", "event": 7, "path": "images/cg/cynthia/Cynthia05.png",  "label": "cynthia_sixth_encounter"},
        {"id": "Cynthia 07", "event": 7, "path": "images/cg/cynthia/Cynthia05a.png", "label": None},
        {"id": "Cynthia 08", "event": 8, "path": "images/cg/cynthia/Cynthia06.png",  "label": "cynthia_seventh_encounter"},
        {"id": "Cynthia 09", "event": 8, "path": "images/cg/cynthia/Cynthia06a.png", "label": None},
    ],
    "penny": [
        {"id": "penny 00", "event": 2, "path": None,                           "label": "penny_first_encounter"},
        {"id": "Penny 01", "event": 3, "path": "images/cg/penny/penny01.png",  "label": "penny_second_encounter"},
        {"id": "penny 00", "event": 4, "path": None,                           "label": "penny_third_encounter"},
        {"id": "Penny 02", "event": 5, "path": "images/cg/penny/penny02.png",  "label": "penny_fourth_encounter"},
        {"id": "Penny 04", "event": 6, "path": "images/cg/penny/penny03.png",  "label": "penny_fifth_encounter"},
        {"id": "Penny 05", "event": 6, "path": "images/cg/penny/penny03a.png", "label": None},
        {"id": "Penny 06", "event": 7, "path": "images/cg/penny/penny04.png",  "label": "penny_sixth_encounter"},
        {"id": "Penny 07", "event": 7, "path": "images/cg/penny/penny04a.png", "label": None},
        {"id": "Penny 08", "event": 8, "path": "images/cg/penny/penny05.png",  "label": "penny_seventh_encounter"},
    ],
    "delia": [
        {"id": "Delia 01", "event": 2, "path": "images/cg/delia/Delia01.png",  "label": "delia_first_encounter"},
        {"id": "Delia 02", "event": 3, "path": "images/cg/delia/Delia02.png",  "label": "delia_second_encounter"},
        {"id": "Delia 03", "event": 4, "path": "images/cg/delia/Delia03.png",  "label": "delia_third_encounter"},
        {"id": "Delia 04", "event": 5, "path": "images/cg/delia/Delia04.png",  "label": "delia_fourth_encounter"},
        {"id": "Delia 05", "event": 5, "path": "images/cg/delia/Delia05.png",  "label": None},
        {"id": "Delia 06", "event": 6, "path": "images/cg/delia/Delia06.png",  "label": "delia_fifth_encounter"},
        {"id": "Delia 07", "event": 6, "path": "images/cg/delia/Delia06a.png", "label": None},
        {"id": "Delia 08", "event": 7, "path": "images/cg/delia/Delia07.png",  "label": "delia_sixth_encounter"},
        {"id": "Delia 09", "event": 7, "path": "images/cg/delia/Delia07a.png", "label": None},
        {"id": "Delia 10", "event": 8, "path": "images/cg/delia/Delia08.png",  "label": "delia_seventh_encounter"},
    ],
    "leaf": [
        {"id": "Leaf 00", "event": 2, "path": None,                          "label": "leaf_first_encounter"},
        {"id": "Leaf 01", "event": 3, "path": "images/cg/leaf/leaf01.png",   "label": "leaf_second_encounter"},
        {"id": "Leaf 02", "event": 3, "path": "images/cg/leaf/leaf01a.png",  "label": None},
        {"id": "Leaf 03", "event": 4, "path": "images/cg/leaf/leaf02.png",   "label": "leaf_third_encounter"},
        {"id": "Leaf 04", "event": 5, "path": "images/cg/leaf/leaf03.png",   "label": "leaf_fourth_encounter"},
        {"id": "Leaf 05", "event": 5, "path": "images/cg/leaf/leaf03a.png",  "label": None},
        {"id": "Leaf 06", "event": 6, "path": "images/cg/leaf/leaf04.png",   "label": "leaf_fifth_encounter"},
        {"id": "Leaf 07", "event": 6, "path": "images/cg/leaf/leaf04a.png",  "label": None},
        {"id": "Leaf 08", "event": 7, "path": "images/cg/leaf/leaf05.png",   "label": "leaf_sixth_encounter"},
        {"id": "Leaf 09", "event": 7, "path": "images/cg/leaf/leaf05a.png",  "label": None},
        {"id": "Leaf 10", "event": 8, "path": "images/cg/leaf/leaf06.png",   "label": "leaf_seventh_encounter"},
        {"id": "Leaf 11", "event": 8, "path": "images/cg/leaf/leaf06a.png",  "label": None},
    ],
    "may": [
        {"id": "may 00", "event": 2, "path": None,                        "label": "may_first_encounter"},
        {"id": "may 01", "event": 3, "path": "images/cg/may/May01.png",   "label": "may_second_encounter"},
        {"id": "may 02", "event": 3, "path": "images/cg/may/May02.png",   "label": None},
        {"id": "may 03", "event": 4, "path": "images/cg/may/May03.png",   "label": "may_third_encounter"},
        {"id": "may 04", "event": 4, "path": "images/cg/may/May04.png",   "label": None},
        {"id": "may 05", "event": 5, "path": "images/cg/may/May05.png",   "label": "may_fourth_encounter"},
        {"id": "may 06", "event": 5, "path": "images/cg/may/May06.png",   "label": None},
        {"id": "may 07", "event": 5, "path": "images/cg/may/May06a.png",  "label": None},
        {"id": "may 08", "event": 6, "path": "images/cg/may/May07.png",   "label": "may_fifth_encounter"},
        {"id": "may 09", "event": 6, "path": "images/cg/may/May07a.png",  "label": None},
        {"id": "may 10", "event": 6, "path": "images/cg/may/May08.png",   "label": None},
        {"id": "may 11", "event": 6, "path": "images/cg/may/May08a.png",  "label": None},
        {"id": "may 00", "event": 7, "path": None,                        "label": "may_sixth_encounter"},
        {"id": "may 12", "event": 8, "path": "images/cg/may/May09.png",   "label": "may_seventh_encounter"},
        {"id": "may 13", "event": 8, "path": "images/cg/may/May10.png",   "label": None},
        {"id": "may 14", "event": 8, "path": "images/cg/may/May11.png",   "label": None},
        {"id": "may 15", "event": 8, "path": "images/cg/may/May11a.png",  "label": None},
    ],
    "lusamine": [
        {"id": "Lusamine 00", "event": 2, "path":  None,                                "label": "lusamine_first_encounter"},
        {"id": "Lusamine 00", "event": 3, "path":  None,                                "label": "lusamine_second_encounter"},
        {"id": "Lusamine 01", "event": 4, "path": "images/cg/lusamine/lusamine01.png",  "label": "lusamine_third_encounter"},
        {"id": "Lusamine 02", "event": 5, "path": "images/cg/lusamine/lusamine02.png",  "label": "lusamine_fourth_encounter"},
        {"id": "Lusamine 03", "event": 5, "path": "images/cg/lusamine/lusamine02a.png", "label": None},
        {"id": "Lusamine 04", "event": 6, "path": "images/cg/lusamine/lusamine03.png",  "label": "lusamine_fifth_encounter"},
        {"id": "Lusamine 05", "event": 6, "path": "images/cg/lusamine/lusamine03a.png", "label": None},
        {"id": "Lusamine 06", "event": 7, "path": "images/cg/lusamine/lusamine04.png",  "label": "lusamine_sixth_encounter"},
        {"id": "Lusamine 07", "event": 7, "path": "images/cg/lusamine/lusamine04a.png", "label": None},
        {"id": "Lusamine 08", "event": 8, "path": "images/cg/lusamine/lusamine05.png",  "label": "lusamine_seventh_encounter"},
        {"id": "Lusamine 09", "event": 8, "path": "images/cg/lusamine/lusamine05a.png", "label": None},
    ],
    "lillie": [
        {"id": "lillie 00", "event": 2, "path":  None,                            "label": "lillie_first_encounter"},
        {"id": "lillie 01", "event": 3, "path": "images/cg/lillie/Lillie01.png",  "label": "lillie_second_encounter"},
        {"id": "lillie 02", "event": 4, "path": "images/cg/lillie/Lillie02.png",  "label": "lillie_third_encounter"},
        {"id": "lillie 03", "event": 5, "path": "images/cg/lillie/Lillie03.png",  "label": "lillie_fourth_encounter"},
        {"id": "lillie 04", "event": 5, "path": "images/cg/lillie/Lillie03a.png", "label": None},
        {"id": "lillie 05", "event": 6, "path": "images/cg/lillie/Lillie04.png",  "label": "lillie_fifth_encounter"},
        {"id": "lillie 06", "event": 6, "path": "images/cg/lillie/Lillie04a.png", "label": None},
        {"id": "lillie 07", "event": 7, "path": "images/cg/lillie/Lillie05.png",  "label": "lillie_sixth_encounter"},
        {"id": "lillie 08", "event": 7, "path": "images/cg/lillie/Lillie06.png",  "label": None},
        {"id": "lillie 09", "event": 7, "path": "images/cg/lillie/Lillie06a.png", "label": None},
        {"id": "lillie 10", "event": 8, "path": "images/cg/lillie/Lillie07.png",  "label": "lillie_seventh_encounter"},
        {"id": "lillie 11", "event": 8, "path": "images/cg/lillie/Lillie08.png",  "label": None},
        {"id": "lillie 12", "event": 8, "path": "images/cg/lillie/Lillie08a.png", "label": None},
    ],
    "dawn": [
        {"id": "Dawn 01", "event": 2, "path": "images/cg/dawn/Dawn02.png",   "label": "dawn_first_encounter"},
        {"id": "Dawn 02", "event": 3, "path": "images/cg/dawn/Dawn03.png",   "label": "dawn_second_encounter"},
        {"id": "Dawn 03", "event": 4, "path": "images/cg/dawn/Dawn04.png",   "label": "dawn_third_encounter"},
        {"id": "Dawn 00", "event": 5, "path": None,                          "label": "dawn_fourth_encounter"},
        {"id": "Dawn 04", "event": 6, "path": "images/cg/dawn/Dawn05b.png",  "label": "dawn_fifth_encounter"},
        {"id": "Dawn 05", "event": 6, "path": "images/cg/dawn/Dawn05.png",   "label": None},
        {"id": "Dawn 06", "event": 6, "path": "images/cg/dawn/Dawn05a.png",  "label": None},
        {"id": "Dawn 07", "event": 7, "path": "images/cg/dawn/Dawn06.png",   "label": "dawn_sixth_encounter"},
        {"id": "Dawn 08", "event": 8, "path": "images/cg/dawn/Dawn07.png",   "label": "dawn_seventh_encounter"},
        {"id": "Dawn 09", "event": 8, "path": "images/cg/dawn/Dawn07a.png",  "label": None},
        {"id": "Dawn 10", "event": 8, "path": "images/cg/dawn/Dawn07b.png",  "label": None},
        {"id": "Dawn 11", "event": 8, "path": "images/cg/dawn/Dawn08.png",   "label": None},
    ],
    "nessa": [
        {"id": "Nessa 00", "event": 2, "path": None,                           "label": "nessa_first_encounter"},
        {"id": "Nessa 01", "event": 3, "path": "images/cg/nessa/Nessa01.png",  "label": "nessa_second_encounter"},
        {"id": "Nessa 02", "event": 3, "path": "images/cg/nessa/Nessa02.png",  "label": None},
        {"id": "Nessa 03", "event": 4, "path": "images/cg/nessa/Nessa03.png",  "label": "nessa_third_encounter"},
        {"id": "Nessa 04", "event": 5, "path": "images/cg/nessa/Nessa04.png",  "label": "nessa_fourth_encounter"},
        {"id": "Nessa 05", "event": 5, "path": "images/cg/nessa/Nessa04a.png", "label": None},
        {"id": "Nessa 06", "event": 6, "path": "images/cg/nessa/Nessa05.png",  "label": "nessa_fifth_encounter"},
        {"id": "Nessa 07", "event": 7, "path": "images/cg/nessa/Nessa06.png",  "label": "nessa_sixth_encounter"},
        {"id": "Nessa 08", "event": 8, "path": "images/cg/nessa/Nessa07.png",  "label": "nessa_seventh_encounter"},
        {"id": "Nessa 09", "event": 8, "path": "images/cg/nessa/Nessa07a.png", "label": None},
    ],
    "maylene": [
        {"id": "Maylene 01", "event": 2, "path": "images/cg/maylene/maylene01.png",  "label": "maylene_first_encounter"},
        {"id": "Maylene 02", "event": 3, "path": "images/cg/maylene/maylene02.png",  "label": "maylene_second_encounter"},
        {"id": "Maylene 03", "event": 4, "path": "images/cg/maylene/maylene03.png",  "label": "maylene_third_encounter"},
        {"id": "Maylene 04", "event": 5, "path": "images/cg/maylene/maylene04.png",  "label": "maylene_fourth_encounter"},
        {"id": "Maylene 05", "event": 5, "path": "images/cg/maylene/maylene05.png",  "label": None},
        {"id": "Maylene 06", "event": 5, "path": "images/cg/maylene/maylene06.png",  "label": None},
        {"id": "Maylene 07", "event": 6, "path": "images/cg/maylene/maylene07.png",  "label": "maylene_fifth_encounter"},
        {"id": "Maylene 08", "event": 6, "path": "images/cg/maylene/maylene08.png",  "label": None},
        {"id": "Maylene 09", "event": 7, "path": "images/cg/maylene/maylene09.png",  "label": "maylene_sixth_encounter"},
        {"id": "Maylene 10", "event": 7, "path": "images/cg/maylene/maylene10.png",  "label": None},
        {"id": "Maylene 11", "event": 7, "path": "images/cg/maylene/maylene11.png",  "label": None},
        {"id": "Maylene 12", "event": 8, "path": "images/cg/maylene/maylene12.png",  "label": "maylene_seventh_encounter"},
        {"id": "Maylene 13", "event": 8, "path": "images/cg/maylene/maylene13.png",  "label": None},
        {"id": "Maylene 14", "event": 8, "path": "images/cg/maylene/maylene13a.png", "label": None},
    ],
    "misty": [
        {"id": "Misty 01", "event": 2, "path": "images/cg/misty/misty01.png",  "label": "misty_first_encounter"},
        {"id": "Misty 02", "event": 3, "path": "images/cg/misty/misty02.png",  "label": "misty_second_encounter"},
        {"id": "Misty 03", "event": 4, "path": "images/cg/misty/misty03.png",  "label": "misty_third_encounter"},
        {"id": "Misty 04", "event": 4, "path": "images/cg/misty/misty04.png",  "label": None},
        {"id": "Misty 05", "event": 5, "path": "images/cg/misty/misty05.png",  "label": "misty_fourth_encounter"},
        {"id": "Misty 06", "event": 6, "path": "images/cg/misty/misty06.png",  "label": "misty_fifth_encounter"},
        {"id": "Misty 07", "event": 6, "path": "images/cg/misty/misty07.png",  "label": None},
        {"id": "Misty 08", "event": 7, "path": "images/cg/misty/misty08.png",  "label": "misty_sixth_encounter"},
        {"id": "Misty 09", "event": 7, "path": "images/cg/misty/misty08a.png", "label": None},
        {"id": "Misty 10", "event": 8, "path": "images/cg/misty/misty09.png",  "label": "misty_seventh_encounter"},
        {"id": "Misty 11", "event": 8, "path": "images/cg/misty/misty09a.png", "label": None},
    ],
    "mallow": [
        {"id": "Mallow 00", "event": 2, "path": None,                             "label": "mallow_first_encounter"},
        {"id": "Mallow 01", "event": 3, "path": "images/cg/mallow/mallow01.png",  "label": "mallow_second_encounter"},
        {"id": "Mallow 02", "event": 4, "path": "images/cg/mallow/mallow02.png",  "label": "mallow_third_encounter"},
        {"id": "Mallow 03", "event": 4, "path": "images/cg/mallow/mallow03.png",  "label": None},
        {"id": "Mallow 04", "event": 5, "path": "images/cg/mallow/mallow04.png",  "label": "mallow_fourth_encounter"},
        {"id": "Mallow 05", "event": 5, "path": "images/cg/mallow/mallow05.png",  "label": None},
        {"id": "Mallow 06", "event": 6, "path": "images/cg/mallow/mallow06.png",  "label": "mallow_fifth_encounter"},
        {"id": "Mallow 07", "event": 6, "path": "images/cg/mallow/mallow06a.png", "label": None},
        {"id": "Mallow 08", "event": 7, "path": "images/cg/mallow/mallow07.png",  "label": "mallow_sixth_encounter"},
        {"id": "Mallow 09", "event": 7, "path": "images/cg/mallow/mallow07a.png", "label": None},
        {"id": "Mallow 10", "event": 8, "path": "images/cg/mallow/mallow08.png",  "label": "mallow_seventh_encounter"},
        {"id": "Mallow 11", "event": 7, "path": "images/cg/mallow/mallow09.png",  "label": None},
        {"id": "Mallow 12", "event": 7, "path": "images/cg/mallow/mallow09a.png", "label": None},
    ],
    "iris": [
        {"id": "iris 01", "event": 2, "path": "images/cg/iris/iris01.png",   "label": "iris_first_encounter"},
        {"id": "iris 02", "event": 3, "path": "images/cg/iris/iris02.png",   "label": "iris_second_encounter"},
        {"id": "iris 03", "event": 4, "path": "images/cg/iris/iris03.png",   "label": "iris_third_encounter"},
        {"id": "iris 04", "event": 4, "path": "images/cg/iris/iris04.png",   "label": None},
        {"id": "iris 05", "event": 5, "path": "images/cg/iris/iris05.png",   "label": "iris_fourth_encounter"},
        {"id": "iris 06", "event": 5, "path": "images/cg/iris/iris06.png",   "label": None},
        {"id": "iris 07", "event": 5, "path": "images/cg/iris/iris06a.png",  "label": None},
        {"id": "iris 08", "event": 6, "path": "images/cg/iris/iris07.png",   "label": "iris_fifth_encounter"},
        {"id": "iris 09", "event": 6, "path": "images/cg/iris/iris08.png",   "label": None},
        {"id": "iris 10", "event": 6, "path": "images/cg/iris/iris08a.png",  "label": None},
        {"id": "iris 11", "event": 7, "path": "images/cg/iris/iris09.png",   "label": "iris_sixth_encounter"},
        {"id": "iris 12", "event": 7, "path": "images/cg/iris/iris09a.png",  "label": None},
        {"id": "iris 13", "event": 8, "path": "images/cg/iris/iris10.png",   "label": "iris_seventh_encounter"},
        {"id": "iris 14", "event": 8, "path": "images/cg/iris/iris11.png",   "label": None},
        {"id": "iris 15", "event": 8, "path": "images/cg/iris/iris11a.png",  "label": None},
    ],
        "helena": [
        {"id": "helena 01", "event": 2, "path": "images/cg/helena/helena01.png",  "label": "helena_first_encounter"},
        {"id": "helena 02", "event": 3, "path": "images/cg/helena/helena02.png",  "label": None},
        {"id": "helena 03", "event": 4, "path": "images/cg/helena/helena03.png",  "label": "helena_second_encounter"},
        {"id": "helena 04", "event": 4, "path": "images/cg/helena/helena04.png",  "label": "helena_third_encounter"},
        {"id": "helena 05", "event": 5, "path": "images/cg/helena/helena05.png",  "label": None},
        {"id": "helena 06", "event": 5, "path": "images/cg/helena/helena06.png",  "label": None},
        {"id": "helena 07", "event": 6, "path": "images/cg/helena/helena07.png",  "label": "helena_fourth_encounter"},
        {"id": "helena 08", "event": 6, "path": "images/cg/helena/helena08.png",  "label": "helena_fifth_encounter"},
        {"id": "helena 09", "event": 7, "path": "images/cg/helena/helena09.png",  "label": "helena_sixth_encounter"},
        {"id": "helena 10", "event": 7, "path": "images/cg/helena/helena10.png",  "label": None},
        {"id": "helena 11", "event": 8, "path": "images/cg/helena/helena11.png",  "label": "helena_seventh_encounter"},
        {"id": "helena 12", "event": 8, "path": "images/cg/helena/helena12.png",  "label": None},
    ],
}

define POKEMON_CG_DATA = {
    "gardevoir": [
        {"id": "gardevoir 01", "trust": 20,  "path": "images/pokemon/gardevoir/gardevoir_1.png", "label": "gardevoir_event_1_narrative"},
        {"id": "gardevoir 02", "trust": 40,  "path": "images/pokemon/gardevoir/gardevoir_2.png", "label": "gardevoir_event_2_narrative"},
        {"id": "gardevoir 03", "trust": 60,  "path": "images/pokemon/gardevoir/gardevoir_3.png", "label": "gardevoir_event_3_narrative"},
        {"id": "gardevoir 04", "trust": 60,  "path": "images/pokemon/gardevoir/gardevoir_4.png", "label": "gardevoir_event_3_narrative_post"},
        {"id": "gardevoir 05", "trust": 80,  "path": "images/pokemon/gardevoir/gardevoir_5.png", "label": "gardevoir_event_4_narrative"},
        {"id": "gardevoir 06", "trust": 80,  "path": "images/pokemon/gardevoir/gardevoir_6.png", "label": None},
        {"id": "gardevoir 07", "trust": 100, "path": "images/pokemon/gardevoir/gardevoir_7.png", "label": "gardevoir_event_5_narrative"},
        {"id": "gardevoir 08", "trust": 100, "path": "images/pokemon/gardevoir/bg.png",          "label": None},
    ],
    "cinderace": [
        {"id": "cinderace 01", "trust": 20,  "path": "images/pokemon/cinderace/cinderace_0.png", "label": "cinderace_event_1_narrative"},
        {"id": "cinderace 02", "trust": 20,  "path": "images/pokemon/cinderace/cinderace_1.png", "label": None},
        {"id": "cinderace 03", "trust": 40,  "path": "images/pokemon/cinderace/cinderace_2.png", "label": "cinderace_event_2_narrative"},
        {"id": "cinderace 04", "trust": 40,  "path": "images/pokemon/cinderace/cinderace_3.png", "label": None},
        {"id": "cinderace 05", "trust": 60,  "path": "images/pokemon/cinderace/cinderace_4.png", "label": "cinderace_event_3_narrative"},
        {"id": "cinderace 06", "trust": 60,  "path": "images/pokemon/cinderace/cinderace_5.png", "label": "cinderace_event_3_narrative_post"},
        {"id": "cinderace 07", "trust": 80,  "path": "images/pokemon/cinderace/cinderace_6.png", "label": "cinderace_event_4_narrative"},
        {"id": "cinderace 08", "trust": 80,  "path": "images/pokemon/cinderace/cinderace_7.png", "label": None},
        {"id": "cinderace 09", "trust": 100, "path": "images/pokemon/cinderace/cinderace_8.png", "label": "cinderace_event_5_narrative"},
        {"id": "cinderace 10", "trust": 100, "path": "images/pokemon/cinderace/bg.png",          "label": None},
    ],
    "lopunny": [
        {"id": "lopunny 01", "trust": 20,  "path": "images/pokemon/lopunny/lopunny_0.png", "label": "lopunny_event_1_narrative"},
        {"id": "lopunny 02", "trust": 20,  "path": "images/pokemon/lopunny/lopunny_1.png", "label": None},
        {"id": "lopunny 03", "trust": 40,  "path": "images/pokemon/lopunny/lopunny_2.png", "label": "lopunny_event_2_narrative"},
        {"id": "lopunny 04", "trust": 60,  "path": "images/pokemon/lopunny/lopunny_3.png", "label": "lopunny_event_3_narrative"},
        {"id": "lopunny 04", "trust": 60,  "path": None,                                   "label": "lopunny_event_3_narrative_post"},
        {"id": "lopunny 05", "trust": 80,  "path": "images/pokemon/lopunny/lopunny_4.png", "label": "lopunny_event_4_narrative"},
        {"id": "lopunny 06", "trust": 80,  "path": "images/pokemon/lopunny/lopunny_5.png", "label": None},
        {"id": "lopunny 07", "trust": 100, "path": "images/pokemon/lopunny/lopunny_6.png", "label": "lopunny_event_5_narrative"},
        {"id": "lopunny 08", "trust": 100, "path": "images/pokemon/lopunny/bg.png",        "label": None},
    ],
    "braixen": [
        {"id": "braixen 01", "trust": 20,  "path": "images/pokemon/braixen/braixen_1.png", "label": "braixen_event_1_narrative"},
        {"id": "braixen 02", "trust": 20,  "path": "images/pokemon/braixen/braixen_2.png", "label": None},
        {"id": "braixen 03", "trust": 40,  "path": "images/pokemon/braixen/braixen_3.png", "label": "braixen_event_2_narrative"},
        {"id": "braixen 04", "trust": 40,  "path": "images/pokemon/braixen/braixen_4.png", "label": None},
        {"id": "braixen 05", "trust": 60,  "path": "images/pokemon/braixen/braixen_5.png", "label": "braixen_event_3_narrative"},
        {"id": "braixen 06", "trust": 60,  "path": "images/pokemon/braixen/braixen_6.png", "label": "braixen_event_3_narrative_post"},
        {"id": "braixen 07", "trust": 80,  "path": "images/pokemon/braixen/braixen_7.png", "label": "braixen_event_4_narrative"},
        {"id": "braixen 08", "trust": 80,  "path": "images/pokemon/braixen/braixen_8.png", "label": None},
        {"id": "braixen 09", "trust": 80,  "path": "images/pokemon/braixen/braixen_9.png", "label": None},
        {"id": "braixen 10", "trust": 100, "path": "images/pokemon/braixen/braixen_0.png", "label": "braixen_event_5_narrative"},
        {"id": "braixen 11", "trust": 100, "path": "images/pokemon/braixen/bg.png",        "label": None},
    ],
    "meowscarada": [
        {"id": "meowscarada 01", "trust": 20,  "path": "images/pokemon/meowscarada/meowscarada_1.png", "label": "meowscarada_event_1_narrative"},
        {"id": "meowscarada 02", "trust": 40,  "path": "images/pokemon/meowscarada/meowscarada_2.png", "label": "meowscarada_event_2_narrative"},
        {"id": "meowscarada 03", "trust": 60,  "path": "images/pokemon/meowscarada/meowscarada_3.png", "label": "meowscarada_event_3_narrative"},
        {"id": "meowscarada 04", "trust": 60,  "path": "images/pokemon/meowscarada/meowscarada_4.png", "label": "meowscarada_event_3_narrative_post"},
        {"id": "meowscarada 05", "trust": 80,  "path": "images/pokemon/meowscarada/meowscarada_5.png", "label": "meowscarada_event_4_narrative"},
        {"id": "meowscarada 06", "trust": 80,  "path": "images/pokemon/meowscarada/meowscarada_6.png", "label": None},
        {"id": "meowscarada 07", "trust": 100, "path": "images/pokemon/meowscarada/meowscarada_7.png", "label": "meowscarada_event_5_narrative"},
        {"id": "meowscarada 08", "trust": 100, "path": "images/pokemon/meowscarada/meowscarada_8.png", "label": None},
        {"id": "meowscarada 09", "trust": 100, "path": "images/pokemon/meowscarada/bg.png",            "label": None},
    ],
    "primarina": [
        {"id": "primarina 01", "trust": 20,  "path": "images/pokemon/primarina/primarina_1.png", "label": "primarina_event_1_narrative"},
        {"id": "primarina 02", "trust": 40,  "path": "images/pokemon/primarina/primarina_2.png", "label": "primarina_event_2_narrative"},
        {"id": "primarina 03", "trust": 40,  "path": "images/pokemon/primarina/primarina_3.png", "label": None},
        {"id": "primarina 04", "trust": 60,  "path": "images/pokemon/primarina/primarina_4.png", "label": "primarina_event_3_narrative"},
        {"id": "primarina 05", "trust": 60,  "path": "images/pokemon/primarina/primarina_5.png", "label": "primarina_event_3_narrative_post"},
        {"id": "primarina 06", "trust": 80,  "path": "images/pokemon/primarina/primarina_6.png", "label": "primarina_event_4_narrative"},
        {"id": "primarina 07", "trust": 80,  "path": "images/pokemon/primarina/primarina_7.png", "label": None},
        {"id": "primarina 08", "trust": 100, "path": "images/pokemon/primarina/primarina_8.png", "label": "primarina_event_5_narrative"},
        {"id": "primarina 09", "trust": 100, "path": "images/pokemon/primarina/bg.png",          "label": None},
    ],
    "gothitelle": [
        {"id": "gothitelle 01", "trust": 20,  "path": "images/pokemon/gothitelle/gothitelle_1.png", "label": "gothitelle_event_1_narrative"},
        {"id": "gothitelle 02", "trust": 40,  "path": "images/pokemon/gothitelle/gothitelle_2.png", "label": "gothitelle_event_2_narrative"},
        {"id": "gothitelle 03", "trust": 60,  "path": "images/pokemon/gothitelle/gothitelle_3.png", "label": "gothitelle_event_3_narrative"},
        {"id": "gothitelle 04", "trust": 60,  "path": "images/pokemon/gothitelle/gothitelle_4.png", "label": "gothitelle_event_3_narrative_post"},
        {"id": "gothitelle 05", "trust": 80,  "path": "images/pokemon/gothitelle/gothitelle_5.png", "label": "gothitelle_event_4_narrative"},
        {"id": "gothitelle 06", "trust": 100, "path": "images/pokemon/gothitelle/gothitelle_6.png", "label": "gothitelle_event_5_narrative"},
        {"id": "gothitelle 07", "trust": 100, "path": "images/pokemon/gothitelle/bg.png",           "label": None},
    ],
    "tsareena": [
        {"id": "tsareena 01", "trust": 20,  "path": "images/pokemon/tsareena/tsareena_1.png", "label": "tsareena_event_1_narrative"},
        {"id": "tsareena 02", "trust": 40,  "path": "images/pokemon/tsareena/tsareena_2.png", "label": "tsareena_event_2_narrative"},
        {"id": "tsareena 03", "trust": 60,  "path": "images/pokemon/tsareena/tsareena_3.png", "label": "tsareena_event_3_narrative"},
        {"id": "tsareena 04", "trust": 60,  "path": "images/pokemon/tsareena/tsareena_4.png", "label": "tsareena_event_3_narrative_post"},
        {"id": "tsareena 05", "trust": 80,  "path": "images/pokemon/tsareena/tsareena_5.png", "label": "tsareena_event_4_narrative"},
        {"id": "tsareena 06", "trust": 80,  "path": "images/pokemon/tsareena/tsareena_6.png", "label": None},
        {"id": "tsareena 07", "trust": 100, "path": "images/pokemon/tsareena/tsareena_7.png", "label": None},
        {"id": "tsareena 08", "trust": 100, "path": "images/pokemon/tsareena/tsareena_8.png", "label": "tsareena_event_5_narrative"},
        {"id": "tsareena 09", "trust": 100, "path": "images/pokemon/tsareena/bg.png",         "label": None},
    ],
    "vaporeon": [
        {"id": "vaporeon 01", "trust": 20,  "path": "images/pokemon/vaporeon/vaporeon_1.png", "label": "vaporeon_event_1_narrative"},
        {"id": "vaporeon 02", "trust": 20,  "path": "images/pokemon/vaporeon/vaporeon_2.png", "label": None},
        {"id": "vaporeon 03", "trust": 40,  "path": "images/pokemon/vaporeon/vaporeon_3.png", "label": "vaporeon_event_2_narrative"},
        {"id": "vaporeon 04", "trust": 60,  "path": "images/pokemon/vaporeon/vaporeon_4.png", "label": None},
        {"id": "vaporeon 05", "trust": 60,  "path": "images/pokemon/vaporeon/vaporeon_5.png", "label": "vaporeon_event_3_narrative"},
        {"id": "vaporeon 06", "trust": 60,  "path": "images/pokemon/vaporeon/vaporeon_6.png", "label": "vaporeon_event_3_narrative_post"},
        {"id": "vaporeon 07", "trust": 80,  "path": "images/pokemon/vaporeon/vaporeon_7.png", "label": "vaporeon_event_4_narrative"},
        {"id": "vaporeon 08", "trust": 100, "path": "images/pokemon/vaporeon/vaporeon_8.png", "label": "vaporeon_event_5_narrative"},
        {"id": "vaporeon 09", "trust": 100, "path": "images/pokemon/vaporeon/bg.png",         "label": None},
    ],
    "hatterene": [
        {"id": "hatterene 01", "trust": 20,  "path": "images/pokemon/hatterene/hatterene_1.png", "label": "hatterene_event_1_narrative"},
        {"id": "hatterene 02", "trust": 40,  "path": "images/pokemon/hatterene/hatterene_2.png", "label": "hatterene_event_2_narrative"},
        {"id": "hatterene 03", "trust": 40,  "path": "images/pokemon/hatterene/hatterene_3.png", "label": None},
        {"id": "hatterene 04", "trust": 60,  "path": "images/pokemon/hatterene/hatterene_4.png", "label": "hatterene_event_3_narrative"},
        {"id": "hatterene 05", "trust": 60,  "path": "images/pokemon/hatterene/hatterene_5.png", "label": "hatterene_event_3_narrative_post"},
        {"id": "hatterene 06", "trust": 80,  "path": "images/pokemon/hatterene/hatterene_6.png", "label": "hatterene_event_4_narrative"},
        {"id": "hatterene 07", "trust": 80,  "path": "images/pokemon/hatterene/hatterene_7.png", "label": None},
        {"id": "hatterene 08", "trust": 80,  "path": "images/pokemon/hatterene/hatterene_8.png", "label": None},
        {"id": "hatterene 09", "trust": 100, "path": "images/pokemon/hatterene/hatterene_9.png", "label": "hatterene_event_5_narrative"},
        {"id": "hatterene 10", "trust": 100, "path": "images/pokemon/hatterene/hatterene_0.png", "label": None},
        {"id": "hatterene 11", "trust": 100, "path": "images/pokemon/hatterene/bg.png",          "label": None},
    ],
    "meloetta": [
        {"id": "meloetta 01", "trust": 20,  "path": "images/pokemon/meloetta/meloetta_1.png", "label": "meloetta_event_1_narrative"},
        {"id": "meloetta 02", "trust": 40,  "path": "images/pokemon/meloetta/meloetta_2.png", "label": "meloetta_event_2_narrative"},
        {"id": "meloetta 03", "trust": 60,  "path": "images/pokemon/meloetta/meloetta_3.png", "label": "meloetta_event_3_narrative"},
        {"id": "meloetta 04", "trust": 60,  "path": "images/pokemon/meloetta/meloetta_4.png", "label": "meloetta_event_3_narrative_post"},
        {"id": "meloetta 05", "trust": 80,  "path": "images/pokemon/meloetta/meloetta_5.png", "label": "meloetta_event_4_narrative"},
        {"id": "meloetta 06", "trust": 80,  "path": "images/pokemon/meloetta/meloetta_6.png", "label": None},
        {"id": "meloetta 07", "trust": 100, "path": "images/pokemon/meloetta/meloetta_7.png", "label": "meloetta_event_5_narrative"},
        {"id": "meloetta 08", "trust": 100, "path": "images/pokemon/meloetta/bg.png",         "label": None},
    ],
    "espeon": [
        {"id": "espeon 01", "trust": 20,  "path": "images/pokemon/espeon/espeon_1.png", "label": "espeon_event_1_narrative"},
        {"id": "espeon 02", "trust": 40,  "path": "images/pokemon/espeon/espeon_2.png", "label": "espeon_event_2_narrative"},
        {"id": "espeon 03", "trust": 40,  "path": "images/pokemon/espeon/espeon_3.png", "label": None},
        {"id": "espeon 04", "trust": 60,  "path": "images/pokemon/espeon/espeon_4.png", "label": "espeon_event_3_narrative"},
        {"id": "espeon 05", "trust": 60,  "path": "images/pokemon/espeon/espeon_5.png", "label": "espeon_event_3_narrative_post"},
        {"id": "espeon 06", "trust": 80,  "path": "images/pokemon/espeon/espeon_6.png", "label": "espeon_event_4_narrative"},
        {"id": "espeon 07", "trust": 100, "path": "images/pokemon/espeon/espeon_7.png", "label": "espeon_event_5_narrative"},
        {"id": "espeon 08", "trust": 100, "path": "images/pokemon/espeon/bg.png",       "label": None},
    ],
    "zoroark": [
        {"id": "zoroark 01", "trust": 20,  "path": "images/pokemon/zoroark/zoroark_1.png", "label": "zoroark_event_1_narrative"},
        {"id": "zoroark 02", "trust": 20,  "path": "images/pokemon/zoroark/zoroark_2.png", "label": None},
        {"id": "zoroark 03", "trust": 40,  "path": "images/pokemon/zoroark/zoroark_3.png", "label": "zoroark_event_2_narrative"},
        {"id": "zoroark 04", "trust": 60,  "path": "images/pokemon/zoroark/zoroark_4.png", "label": "zoroark_event_3_narrative"},
        {"id": "zoroark 05", "trust": 60,  "path": "images/pokemon/zoroark/zoroark_5.png", "label": "zoroark_event_3_narrative_post"},
        {"id": "zoroark 06", "trust": 60,  "path": "images/pokemon/zoroark/zoroark_6.png", "label": "zoroark_event_4_narrative"},
        {"id": "zoroark 07", "trust": 80,  "path": "images/pokemon/zoroark/zoroark_7.png", "label": None},
        {"id": "zoroark 08", "trust": 80,  "path": "images/pokemon/zoroark/zoroark_8.png", "label": "zoroark_event_5_narrative"},
        {"id": "zoroark 09", "trust": 100, "path": "images/pokemon/zoroark/zoroark_9.png", "label": None},
        {"id": "zoroark 10", "trust": 100, "path": "images/pokemon/zoroark/bg.png",        "label": None},
    ],
}
# ------------------------------------------------------------
# CHARACTERS
# ------------------------------------------------------------

# Protagonist — name set by player at start
define mc = DynamicCharacter("player_name", color="#FFFFFF")

# Main characters
define elesa    = Character("Elesa",     color="#FFD700")
define erika    = Character("Erika",     color="#90EE90")
define roxanne  = Character("Roxanne",   color="#DEB887")
define cynthia  = Character("Cynthia",   color="#9B59B6")
define maylene  = Character("Maylene",   color="#E59866")
define misty    = Character("Misty",     color="#5DADE2")
define mallow   = Character("Mallow",    color="#58D68D")
define nessa    = Character("Nessa",     color="#1ABC9C")
define penny    = Character("Penny",     color="#F39C12")
define delia    = Character("Delia",     color="#EC407A")
define leaf     = Character("Leaf",      color="#66BB6A")
define lusamine = Character("Lusamine",  color="#8E44AD")
define lillie   = Character("Lillie",    color="#F8F9FA")
define may      = Character("May",       color="#E91E63")
define dawn     = Character("Dawn",      color="#42A5F5")
define iris     = Character("Iris",      color="#7E57C2")
define helena    = Character("Helena",   color="#bc92ff")

# ------------------------------------------------------------
# AFFECTION SYSTEM
# ------------------------------------------------------------
default affection = {
    "elesa"    : 0,
    "erika"    : 0,
    "roxanne"  : 0,
    "cynthia"  : 0,
    "maylene"  : 0,
    "misty"    : 0,
    "mallow"   : 0,
    "nessa"    : 0,
    "penny"    : 0,
    "delia"    : 0,
    "leaf"     : 0,
    "lusamine" : 0,
    "lillie"   : 0,
    "may"      : 0,
    "dawn"     : 0,
    "iris"     : 0,
    "helena"   : 0,
}

# ------------------------------------------------------------
# UNLOCKED ROUTES & EVENTS
# ------------------------------------------------------------
# Tracks which story events have been triggered
default story_events = {}
# Format: {"event_id": True/False}
default mg_fail_text = ""

# Tracks which dates have been unlocked per character
default dates_unlocked = {
    "elesa"    : False,
    "erika"    : False,
    "roxanne"  : False,
    "cynthia"  : False,
    "maylene"  : False,
    "misty"    : False,
    "mallow"   : False,
    "nessa"    : False,
    "penny"    : False,
    "delia"    : False,
    "leaf"     : False,
    "lusamine" : False,
    "lillie"   : False,
    "may"      : False,
    "dawn"     : False,
    "iris"     : False,
    "helena"   : False,
}

default character_progress = {
    "elesa"    : 0,
    "erika"    : 0,
    "roxanne"  : 0,
    "cynthia"  : 0,
    "maylene"  : 0,
    "misty"    : 0,
    "mallow"   : 0,
    "nessa"    : 0,
    "penny"    : 0,
    "delia"    : 0,
    "leaf"     : 0,
    "lusamine" : 0,
    "lillie"   : 0,
    "may"      : 0,
    "dawn"     : 0,
    "iris"     : 0,
    "helena"   : 0,
}

# Tracks unlocked skins per character
default unlocked_skins = {
    "elesa"    : [],
    "erika"    : [],
    "roxanne"  : [],
    "cynthia"  : [],
    "maylene"  : [],
    "misty"    : [],
    "mallow"   : [],
    "nessa"    : [],
    "penny"    : [],
    "delia"    : [],
    "leaf"     : [],
    "lusamine" : [],
    "lillie"   : [],
    "may"      : [],
    "dawn"     : [],
    "iris"     : [],
    "helena"   : [],
}

# Currently equipped skin per character
default equipped_skin = {
    "elesa"    : "default",
    "erika"    : "default",
    "roxanne"  : "default",
    "cynthia"  : "default",
    "maylene"  : "default",
    "misty"    : "default",
    "mallow"   : "default",
    "nessa"    : "default",
    "penny"    : "default",
    "delia"    : "default",
    "leaf"     : "default",
    "lusamine" : "default",
    "lillie"   : "default",
    "may"      : "default",
    "dawn"     : "default",
    "iris"     : "default",
    "helena"   : "default",
}
# ------------------------------------------------------------
# CONTENT TAGS
# ------------------------------------------------------------
default content_tags = {
    "Incest"          : True,
    "BDSM"            : True,
    "Prostitution"    : True,
    "Furry on human"  : True,
    "Human on furry"  : True,
}
# ------------------------------------------------------------
# CHARACTER SCHEDULES
# ------------------------------------------------------------
# Format: (day_start, day_end, slot_start, slot_end, location)
# Days: 0=Monday 1=Tuesday 2=Wednesday 3=Thursday 4=Friday 5=Saturday 6=Sunday
# Slots: 0=Morning 1=Day 2=Afternoon 3=Night 4=Midnight
# character schedule change: "$ character_schedule_state["cynthia"] = "after_cynthia_event_1" "

default character_schedules = {

    "leaf": {
        "default": [
            (0, 4, 0, 1, "shopping_center"),
            (0, 4, 2, 2, "plaza"),
            (0, 4, 3, 4, "home_delia_leaf"),
            (5, 6, 0, 1, "plaza"),
            (5, 6, 2, 4, "home_delia_leaf"),
        ],
    },

    "cynthia": {
        "default": [
            (0, 4, 2, 2, "cafe"),
            (5, 6, 0, 2, "plaza"),
            (0, 6, 3, 4, "library"),
        ],
    },

    "delia": {
        "default": [
            (0, 4, 0, 1, "home_delia_leaf"),
            (0, 4, 2, 2, "plaza"),
            (0, 6, 3, 4, "home_delia_leaf"),
            (5, 6, 0, 2, "plaza"),
        ],
    },

    "elesa": {
        "default": [
            (0, 4, 0, 3, "clothing_store"),
            (0, 4, 4, 4, "cafe"),
            (5, 6, 0, 1, "clothing_store"),
            (5, 6, 2, 4, "plaza"),
        ],
    },

    "erika": {
        "default": [
            (0, 5, 0, 3, "greenhouse"),
            (6, 6, 0, 3, "plaza"),
            (6, 6, 4, 4, "forest"),
        ],
    },

    "lusamine": {
        "default": [
            (0, 3, 0, 2, "cafe"),
            (4, 4, 0, 4, "cafe"),
            (5, 5, 0, 0, "cafe"),
            (5, 5, 1, 2, "plaza"),
            (6, 6, 0, 2, "cafe"),
        ],
    },

    "penny": {
        "default": [
            (0, 3, 0, 2, "studio"),
            (4, 4, 0, 1, "forest"),
            (4, 4, 2, 2, "plaza"),
            (5, 6, 0, 2, "plaza"),
        ],
    },

    "roxanne": {
        "default": [
            (0, 4, 0, 2, "library"),
            (5, 6, 0, 0, "library"),
            (5, 6, 1, 2, "beach"),
            (5, 6, 3, 4, "plaza"),
        ],
    },

    "dawn": {
        "default": [
            (0, 3, 0, 2, "cafe"),
            (5, 6, 3, 4, "shopping_center"),
            (4, 4, 0, 2, "plaza"),
            (5, 6, 0, 2, "beach"),
            (0, 4, 3, 4, "plaza"),
        ],
    },

    "nessa": {
        "default": [
            (0, 6, 1, 2, "beach"),
            (0, 4, 3, 4, "cafe"),
            (5, 6, 0, 0, "beach"),
            (5, 6, 3, 4, "plaza"),
        ],
    },

    "maylene": {
        "default": [
            (0, 4, 0, 3, "gym"),
            (5, 5, 0, 3, "plaza"),
            (6, 6, 0, 1, "gym"),
            (6, 6, 2, 3, "beach"),
        ],
    },

    "misty": {
        "default": [
            (0, 4, 0, 3, "forest"),
            (5, 6, 0, 1, "forest"),
            (5, 6, 2, 3, "beach"),
            (5, 6, 4, 4, "plaza"),
        ],
    },

    "mallow": {
        "default": [
            (0, 5, 0, 3, "food_store"),
            (6, 6, 0, 1, "plaza"),
            (6, 6, 2, 3, "cafe"),
        ],
    },

    "lillie": {
        "default": [
            (0, 4, 0, 2, "library"),
            (5, 6, 0, 1, "plaza"),
            (5, 6, 2, 2, "library"),
            (0, 6, 3, 4, "cafe"),
        ],
    },

    "may": {
        "default": [
            (0, 4, 0, 2, "plaza"),
            (0, 6, 3, 3, "cafe"),
            (5, 6, 0, 2, "forest"),
        ],
    },

    "iris": {
        "default": [
            (0, 6, 0, 2, "forest"),
            (0, 6, 3, 3, "plaza"),
        ],
    },
    "helena": {
        "default": [
            (0, 6, 0, 4, "home"),
        ],
        "after": [
            (0, 6, 0, 4, "home"),
        ],
    },
}

# ------------------------------------------------------------
# ACTIVE SCHEDULE STATE PER CHARACTER
# Change this with: $ character_schedule_state["char"] = "new_state"
# ------------------------------------------------------------
default character_schedule_state = {
    "elesa"    : "default",
    "erika"    : "default",
    "roxanne"  : "default",
    "cynthia"  : "default",
    "maylene"  : "default",
    "misty"    : "default",
    "mallow"   : "default",
    "nessa"    : "default",
    "penny"    : "default",
    "delia"    : "default",
    "leaf"     : "default",
    "lusamine" : "default",
    "lillie"   : "default",
    "may"      : "default",
    "dawn"     : "default",
    "iris"     : "default",
    "helena"   : "default",
}
# ------------------------------------------------------------
# CURRENT LOCATION TRACKER
# ------------------------------------------------------------

default current_location = ""

# ------------------------------------------------------------
# BACKGROUNDS
# ------------------------------------------------------------

image bg beach_day   = "images/backgrounds/beach_day.png"
image bg beach_night = "images/backgrounds/beach_night.png"

image bg cafe = "images/backgrounds/cafe.png"

image bg clothing_store = "images/backgrounds/clothing_store.png"

image bg delia_home = "images/backgrounds/delia_home.png"

image bg food_store = "images/backgrounds/food_store.png"

image bg forest_day   = "images/backgrounds/forest_day.png"
image bg forest_night = "images/backgrounds/forest_night.png"

image bg garden_day   = "images/backgrounds/garden_day.png"
image bg garden_night = "images/backgrounds/garden_night.png"

image bg general_store = "images/backgrounds/general_store.png"

image bg greenhouse_day = "images/backgrounds/greenhouse_day.png"

image bg gym = "images/backgrounds/gym.png"

image bg heartwood_map_day   = "images/backgrounds/heartwood_map_day.png"
image bg heartwood_map_night = "images/backgrounds/heartwood_map_night.png"

image bg home_interior_day   = "images/backgrounds/home_interior_day.png"
image bg home_interior_night = "images/backgrounds/home_interior_night.png"

image bg kitchen_day   = "images/backgrounds/Kitchen_day.png"
image bg kitchen_night = "images/backgrounds/Kitchen_night.png"

image bg library_day   = "images/backgrounds/library_day.png"
image bg library_night = "images/backgrounds/library_night.png"

image bg plaza_day   = "images/backgrounds/plaza_day.png"
image bg plaza_night = "images/backgrounds/plaza_night.png"

image bg shopping_center_day   = "images/backgrounds/shopping_center_day.png"
image bg shopping_center_night = "images/backgrounds/shopping_center_night.png"

image bg studio = "images/backgrounds/studio.png"

# ------------------------------------------------------------
# INTERACTION CONTEXT HELPER
# ------------------------------------------------------------
init python:

    def get_characters_in_location(location):
        present = []
        day = current_day % 7
        slot = current_slot

        for char_id, schedules in character_schedules.items():
            active = character_schedule_state[char_id]
            schedule = schedules.get(active, schedules["default"])

            for (d_start, d_end, s_start, s_end, s_location) in schedule:
                if (d_start <= day <= d_end and
                    s_start <= slot <= s_end and
                    s_location == location):
                    present.append(char_id)
        return present

    def get_interaction_context(char_id, location):
        slot = current_slot
        aff = affection[char_id]

        if aff < 20:
            aff_tier = "stranger"
        elif aff < 50:
            aff_tier = "acquaintance"
        elif aff < 80:
            aff_tier = "friend"
        else:
            aff_tier = "close"

        if slot in [0, 1]:
            time_tier = "day"
        elif slot in [2, 3]:
            time_tier = "evening"
        else:
            time_tier = "night"

        return (aff_tier, time_tier, location)

    def get_available_seeds():
        available = []
        for tier in range(6):
            if tier <= renpy.store.erika_seed_tier and tier in renpy.store.ERIKA_CATALOG:
                for seed in renpy.store.ERIKA_CATALOG[tier]:
                    available.append(seed)
        return available

    def buy_seed(seed_id):
        seed = None
        for tier in range(6):
            if tier in renpy.store.ERIKA_CATALOG:
                for s in renpy.store.ERIKA_CATALOG[tier]:
                    if s["id"] == seed_id:
                        seed = s
                        break
        if seed is None or renpy.store.money < seed["price"]:
            return
        renpy.store.money -= seed["price"]
        seed_item = {
            "id":       seed["id"] + "_seed",
            "name":     seed["name"],
            "icon":     seed["icon"],
            "quantity": 1,
        }
        found = False
        for item in renpy.store.inventory_seeds:
            if item["id"] == seed_item["id"]:
                item["quantity"] += 1
                found = True
                break
        if not found:
            renpy.store.inventory_seeds.append(seed_item)

    import random

    def generate_daily_missions():
        if renpy.store.missions_generated_today:
            return

        renpy.store.active_missions = []

        all_chars = [
            "elesa", "erika", "roxanne", "cynthia", "maylene",
            "misty", "mallow", "nessa", "penny", "delia",
            "leaf", "lusamine", "lillie", "may", "dawn", "iris"
        ]

        unlocked_tier = renpy.store.erika_seed_tier
        unlocked_ids  = set()

        for tier in range(unlocked_tier + 1):
            if tier in renpy.store.ERIKA_CATALOG:
                for seed in renpy.store.ERIKA_CATALOG[tier]:
                    unlocked_ids.add(seed["id"])

        growable = [
            ing_id for ing_id, data in renpy.store.INGREDIENTS.items()
            if data.get("growable", False) and ing_id in unlocked_ids
        ]

        if not growable:
            for seed in renpy.store.ERIKA_CATALOG.get(0, []):
                growable.append(seed["id"])

        unlocked_dishes = []
        for rid in renpy.store.unlocked_recipes:
            if rid in renpy.store.RECIPES:
                recipe = renpy.store.RECIPES[rid]
                unlocked_dishes.append({
                    "id":          rid,
                    "name":        recipe["name"],
                    "icon":        recipe["icon"],
                    "mission_min": recipe["mission_min"],
                    "mission_max": recipe["mission_max"],
                    "is_dish":     True,
                })

        requesters = random.sample(all_chars, 5)

        for requester in requesters:
            if unlocked_dishes and random.random() < 0.4:
                dish      = random.choice(unlocked_dishes)
                ing_id    = dish["id"]
                quantity  = 1
                reward    = random.randint(dish["mission_min"], dish["mission_max"])
                days_left = random.randint(3, 7)
                icon      = dish["icon"]
                name      = dish["name"]
            else:
                ing_id    = random.choice(growable)
                ing       = renpy.store.INGREDIENTS[ing_id]
                quantity  = random.randint(1, 3)
                sell      = ing["sell_price"]
                reward    = round(random.uniform(0.8, 1.5) * sell * quantity)
                days_left = random.randint(2, 4)
                icon      = ing["icon"]
                name      = ing["name"]

            renpy.store.active_missions.append({
                "id":        ing_id + "_" + str(random.randint(1000, 9999)),
                "requester": requester,
                "item_id":   ing_id,
                "item_name": name,
                "item_icon": icon,
                "quantity":  quantity,
                "reward":    reward,
                "days_left": days_left,
                "accepted":  False,
            })

        renpy.store.missions_generated_today = True

    def accept_mission(mission_id):
        for m in renpy.store.active_missions:
            if m["id"] == mission_id:
                renpy.store.accepted_missions.append(m)
                renpy.store.active_missions.remove(m)
                break

    def deliver_mission(mission_id):
        mission = None
        for m in renpy.store.accepted_missions:
            if m["id"] == mission_id:
                mission = m
                break

        if mission is None:
            return False

        item_id  = mission["item_id"]
        quantity = mission["quantity"]
        found    = None
        found_in = None

        for item in renpy.store.inventory_food:
            if item["id"] == item_id and item["quantity"] >= quantity:
                found    = item
                found_in = renpy.store.inventory_food
                break

        if found is None:
            for item in renpy.store.inventory_gifts:
                if item["id"] == item_id and item.get("cooked") and item["quantity"] >= quantity:
                    found    = item
                    found_in = renpy.store.inventory_gifts
                    break

        if found is None:
            return False

        found["quantity"] -= quantity
        if found["quantity"] <= 0:
            if found in renpy.store.inventory_food:
                renpy.store.inventory_food.remove(found)
            elif found in renpy.store.inventory_gifts:
                renpy.store.inventory_gifts.remove(found)

        renpy.store.money += mission["reward"]
        renpy.store.accepted_missions.remove(mission)
        return True

    def tick_missions():
        expired = []
        for m in renpy.store.accepted_missions:
            m["days_left"] -= 1
            if m["days_left"] <= 0:
                expired.append(m)
        for m in expired:
            renpy.store.accepted_missions.remove(m)

    def get_pending_delivery(char_id):
        for m in renpy.store.accepted_missions:
            if m["requester"] == char_id:
                return m
        return None

    import math
    import random

    def get_available_recipes():
        available = []
        for rid in renpy.store.unlocked_recipes:
            if rid in renpy.store.RECIPES:
                available.append(renpy.store.RECIPES[rid])
        return available

    def has_ingredients(recipe_id):
        recipe = renpy.store.RECIPES.get(recipe_id)
        if not recipe:
            return False
        for ing_id in recipe["ingredients"]:
            found = False
            for item in renpy.store.inventory_food:
                if item["id"] == ing_id and item["quantity"] > 0:
                    found = True
                    break
            if not found:
                return False
        return True

    def consume_ingredients(recipe_id):
        recipe = renpy.store.RECIPES.get(recipe_id)
        if not recipe:
            return
        for ing_id in recipe["ingredients"]:
            for item in renpy.store.inventory_food:
                if item["id"] == ing_id and item["quantity"] > 0:
                    item["quantity"] -= 1
                    if item["quantity"] <= 0:
                        renpy.store.inventory_food.remove(item)
                    break
    
    def add_temp_ingredient(ing_id, ing_name, ing_icon):
        for item in renpy.store.inventory_food:
            if item["id"] == ing_id:
                item["quantity"] += 1
                return
        renpy.store.inventory_food.append({"id": ing_id, "name": ing_name, "icon": ing_icon, "quantity": 1})

    def add_cooked_dish(recipe_id, quality="normal"):
        recipe = renpy.store.RECIPES.get(recipe_id)
        if not recipe:
            return
        dish = {
            "id":       recipe_id + ("_failed" if quality == "failed" else ""),
            "name":     recipe["name"] + (" (Burnt)" if quality == "failed" else ""),
            "icon":     recipe["icon"],
            "quantity": 1,
            "rarity":   recipe["rarity"],
            "affection": recipe["affection"] if quality == "normal" else 0,
            "sell_price": 5 if quality == "failed" else 0,
            "cooked":   True,
            "quality":  quality,
        }
        found = False
        for item in renpy.store.inventory_gifts:
            if item["id"] == dish["id"]:
                item["quantity"] += 1
                found = True
                break
        if not found:
            renpy.store.inventory_gifts.append(dish)

    def try_unlock_recipe_from_study():
        if renpy.store.stat_intelligence < 30:
            return None
        import random
        if random.random() > 0.20:
            return None
        pool = [
            rid for rid in renpy.store.STUDY_RECIPE_POOL
            if rid not in renpy.store.unlocked_recipes
        ]
        if not pool:
            return None
        chosen = random.choice(pool)
        renpy.store.unlocked_recipes.append(chosen)
        return chosen

    def unlock_recipe(recipe_id):
        if recipe_id not in renpy.store.unlocked_recipes:
            renpy.store.unlocked_recipes.append(recipe_id)

    def unlock_cookbook(book_id):
        book = renpy.store.COOKBOOKS.get(book_id)
        if not book:
            return
        for rid in book["recipes"]:
            unlock_recipe(rid)

    def can_give_gift(char_id):
        return char_id not in renpy.store.gifts_given_today

    def give_gift(char_id, item_id, item_type):
        import renpy
        store = renpy.store

        if not can_give_gift(char_id):
            return False, "already_given"

        if item_id == "empress_outfit":
            store.gifts_given_today[char_id] = True
            if item_id not in store.unlocked_skins[char_id]:
                store.unlocked_skins[char_id].append(item_id)
            return True, 0

        inventory = None
        if item_type == "gift":
            inventory = store.inventory_gifts
        elif item_type == "clothing":
            inventory = store.inventory_clothing
                
        item = None
        for i in inventory:
            if i["id"] == item_id:
                item = i
                break

        if item is None:
            return False, "not_found"

        if item_type == "clothing":
            if item.get("character") != char_id:
                return False, "wrong_character"
            if item_id not in store.unlocked_skins[char_id]:
                store.unlocked_skins[char_id].append(item_id)
            aff_gain = 8

        elif item_type == "gift":
            if item.get("cooked"):
                rarity = item.get("rarity", "common")
                aff_map = {
                    "common": 2, "uncommon": 3, "rare": 4,
                    "very_rare": 6, "exceptional": 10
                }
                aff_gain = aff_map.get(rarity, 2)
            else:
                aff_gain = item.get("affection", 2)

        current = store.affection[char_id]
        store.affection[char_id] = min(100, current + aff_gain)

        item["quantity"] -= 1
        if item["quantity"] <= 0:
            inventory.remove(item)

        store.gifts_given_today[char_id] = True

        return True, aff_gain

    def reset_daily_gifts():
        renpy.store.gifts_given_today = {}
    
    def buy_general_gift(gift_id):
        import renpy
        gift = None
        for g in renpy.store.GENERAL_GIFTS:
            if g["id"] == gift_id:
                gift = g
                break
        if gift is None or renpy.store.money < gift["price"]:
            return
        renpy.store.money -= gift["price"]
        item = {
            "id":        gift["id"],
            "name":      gift["name"],
            "icon":      gift["icon"],
            "quantity":  1,
            "affection": gift["affection"],
            "cooked":    False,
        }
        found = False
        for i in renpy.store.inventory_gifts:
            if i["id"] == item["id"]:
                i["quantity"] += 1
                found = True
                break
        if not found:
            renpy.store.inventory_gifts.append(item)

    def buy_clothing(item_id, char_id):
        import renpy
        store = renpy.store

        catalog = store.CLOTHING_CATALOG.get(char_id, [])
        item = None
        for c in catalog:
            if c["id"] == item_id:
                item = c
                break

        if item is None or store.money < item["price"]:
            return

        if item_id in store.inventory_clothing_ids:
            return

        store.money -= item["price"]

        clothing_item = {
            "id":        item["id"],
            "name":      item["name"],
            "icon":      item["icon"],
            "quantity":  1,
            "character": char_id,
            "affection": 8,
            "universal": False,
        }

        store.inventory_clothing.append(clothing_item)
        store.inventory_clothing_ids.append(item_id)


    def buy_empress_outfit():
        import renpy
        store = renpy.store
 
        if store.money < store.EMPRESS_OUTFIT["price"]:
            return
        if store.empress_outfit_owned:
            return

        store.money -= store.EMPRESS_OUTFIT["price"]
        store.empress_outfit_owned = True

        empress_item = {
            "id":        "empress_outfit",
            "name":      store.EMPRESS_OUTFIT["name"],
            "icon":      store.EMPRESS_OUTFIT["icon"],
            "quantity":  999,
            "character": "all",
            "affection": 0,
            "universal": True,
        }
        store.inventory_clothing.append(empress_item)
        store.inventory_clothing_ids.append("empress_outfit")

    def generate_pokeballs(count):
        import random
        balls = []
        for i in range(count):
            balls.append({
                "id":      i,
                "x": random.randint(50, 1750),
                "y": random.randint(180, 900),
                "visible": True,
            })
        return balls
    def get_random_pokemon():
        available = [
            pid for pid in renpy.store.available_pokemon
            if pid in renpy.store.pokemon_state
            and not renpy.store.pokemon_state[pid]["captured"]
        ]
        if not available:
            return None
        return random.choice(available)

    def get_current_event(poke_id):
        state = renpy.store.pokemon_state[poke_id]
        poke  = renpy.store.POKEMON_DATA[poke_id]
        idx   = state["current_event"]
        if idx >= len(poke["events"]):
            return None
        return poke["events"][idx]

    def advance_pokemon_event(poke_id):
        renpy.store.pokemon_state[poke_id]["current_event"] += 1
        renpy.store.pokemon_state[poke_id]["trust"] += 20
        renpy.store.pokemon_state[poke_id]["discovered"] = True
        if poke_id not in renpy.store.pokedex:
            renpy.store.pokedex[poke_id] = {
                "discovered": True,
                "captured":   False,
                "trust":      renpy.store.pokemon_state[poke_id]["trust"],
            }
        else:
            renpy.store.pokedex[poke_id]["trust"] = renpy.store.pokemon_state[poke_id]["trust"]

    def capture_pokemon(poke_id):
        renpy.store.pokemon_state[poke_id]["captured"] = True
        renpy.store.pokedex[poke_id]["captured"] = True
        if poke_id in renpy.store.available_pokemon:
            renpy.store.available_pokemon.remove(poke_id)

    def has_food_item(food_id):
        for item in renpy.store.inventory_food:
            if item["id"] == food_id and item["quantity"] > 0:
                return True
        return False

    def consume_food_item(food_id):
        for item in renpy.store.inventory_food:
            if item["id"] == food_id and item["quantity"] > 0:
                item["quantity"] -= 1
                if item["quantity"] <= 0:
                    renpy.store.inventory_food.remove(item)
                return True
        return False

    def get_stat_value(stat_name):
        if stat_name == "intelligence":
            return renpy.store.stat_intelligence
        elif stat_name == "charisma":
            return renpy.store.stat_charisma
        elif stat_name == "physique":
            return renpy.store.stat_physique
        return 0

    def get_current_hint(char_id):
        state = renpy.store.hint_state[char_id]
        hints = renpy.store.HINT_DATA[char_id]["hints"]
        idx   = state["current_hint"]
        if idx >= len(hints):
            return None
        return hints[idx]
   
    def buy_hint(char_id):
        state = renpy.store.hint_state[char_id]
        cost  = state["hint_cost"]
        if renpy.store.money < cost:
            return
        if state["hint_purchased"]:
            return
        renpy.store.money       -= cost
        state["hint_purchased"]  = True
   
    def advance_hint(char_id):
        state = renpy.store.hint_state[char_id]
        state["current_hint"]  += 1
        state["hint_cost"]     += 5
        state["hint_purchased"] = False
    def get_day_name():
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        return days[current_day % 7]
    
    def get_char_sprite(char_id, expression="default"):
        skin = renpy.store.equipped_skin.get(char_id, "default")
        if skin == "default":
            return "images/characters/{}/{}.png".format(char_id, expression)
        else:
            return "images/characters/{}/{}_{}.png".format(char_id, skin, expression)

    import hashlib

    def apply_cheat_code():
        code = renpy.store.cheat_code_input.strip().lower()
        renpy.store.cheat_code_input = ""

        code_hash = hashlib.md5(code.encode()).hexdigest()

        if code_hash in renpy.store.used_cheat_codes:
            renpy.notify("Code already used.")
            return

        if code_hash == "163863b77f489b6a2c3886737fbb4be8":
            renpy.store.money += 1500
            renpy.notify("Money added.")
        elif code_hash == "a75caeabeee0ccad5561b1465e440884":
            renpy.store.stat_physique     += 15
            renpy.store.stat_charisma     += 15
            renpy.store.stat_intelligence += 15
            renpy.notify("Stats increaced.")
        elif code_hash == "bf2b0f91b82a4bc681fd31437dce72b8":
            for char_id in renpy.store.CHARACTER_CG_DATA:
                renpy.store.gallery_unlocked[char_id] = 99
            for poke_id in renpy.store.POKEMON_CG_DATA:
                renpy.store.pokemon_state[poke_id]["trust"] = 100
            renpy.notify("Gallery unlocked!")
        elif code_hash == "9f94cfae6c9d9115854e586043568c9d":
            for ing_id, ing in renpy.store.INGREDIENTS.items():
                found = False
                for item in renpy.store.inventory_food:
                    if item["id"] == ing_id:
                        item["quantity"] += 5
                        found = True
                        break
                if not found:
                    renpy.store.inventory_food.append({
                        "id":       ing_id,
                        "name":     ing["name"],
                        "icon":     ing["icon"],
                        "quantity": 5,
                    })
            renpy.notify("+5 of every ingredient!")
        elif code_hash == "76c526005fa5a8962405f44dafb12d6a":
            for char_id, items in renpy.store.CLOTHING_CATALOG.items():
                for item in items:
                    item_id = item["id"]
                    if item_id not in renpy.store.unlocked_skins[char_id]:
                        renpy.store.unlocked_skins[char_id].append(item_id)
            for char_id in renpy.store.unlocked_skins:
                if "empress_outfit" not in renpy.store.unlocked_skins[char_id]:
                    renpy.store.unlocked_skins[char_id].append("empress_outfit")
            renpy.store.empress_outfit_owned = True
            renpy.notify("All outfits unlocked!")
        elif code_hash == "cafc86af51c386a7795cfe6a52a77e3c":
            for char in renpy.store.affection:
                renpy.store.affection[char] = min(100, renpy.store.affection[char] + 40)
            renpy.notify("Affection with all the girls increased.")
        else:
            renpy.notify("Invalid code.")
            return

        renpy.store.used_cheat_codes.append(code_hash)
    def advance_slot(amount=1):
        renpy.store.current_slot += amount
        if renpy.store.current_slot > 4:
            renpy.jump("end_of_day")

    def get_day_range_str(d_start, d_end):
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        if d_start == 0 and d_end == 6:
            return "Every day"
        elif d_start == d_end:
            return days[d_start]
        else:
            return days[d_start] + " — " + days[d_end]

    def get_slot_range_str(s_start, s_end):
        slots = ["Morning", "Day", "Afternoon", "Night", "Midnight"]
        if s_start == s_end:
            return slots[s_start]
        else:
            return slots[s_start] + " — " + slots[s_end]

    def upgrade_garden(upgrade_type):
        costs = renpy.store.GARDEN_UPGRADE_COSTS[upgrade_type]
        
        if upgrade_type == "speed":
            level = renpy.store.garden_speed_level
            max_level = 4
        elif upgrade_type == "yield":
            level = renpy.store.garden_yield_level
            max_level = 4

        if level >= max_level:
            renpy.notify("Already at max level!")
            return

        cost = costs[level + 1]
        if renpy.store.money < cost:
            renpy.notify("Not enough money!")
            return

        renpy.store.money -= cost

        if upgrade_type == "speed":
            renpy.store.garden_speed_level += 1
        elif upgrade_type == "yield":
            renpy.store.garden_yield_level += 1

    def play_location_music(location):

        music_map = {
            "plaza":            "audio/music/plaza.mp3",
            "beach":            "audio/music/beach.mp3",
            "library":          "audio/music/library.mp3",
            "forest":           "audio/music/forest.mp3",
            "greenhouse":       "audio/music/greenhouse.mp3",
            "gym":              "audio/music/gym.mp3",
            "shopping_center":  "audio/music/shopping.mp3",
            "studio":           "audio/music/home.mp3",
            "home":             "audio/music/home.mp3",
            "home_delia_leaf":  "audio/music/delia.mp3",
        }

        if location in music_map:
            renpy.music.play(music_map[location], fadein=1.0)

    def get_grow_days(base_days):
        reduction = [0, 1, 2, 3, 4]
        return max(1, base_days - reduction[renpy.store.garden_speed_level])

    def get_harvest_quantity():
        import random
        level = renpy.store.garden_yield_level
        if level == 0:   return 1
        elif level == 1: return 2 if random.random() < 0.5 else 1
        elif level == 2: return 2
        elif level == 3: return 3 if random.random() < 0.5 else 2
        elif level == 4: return 3

    GARDEN_UPGRADE_COSTS = {
        "speed": [0, 75, 150, 300, 500],
        "yield": [0, 100, 200, 400, 600],
    }

    def migrate_save():

        base_pokemon = ['gardevoir', 'cinderace', 'lopunny']
        new_pokemon  = ['braixen', 'primarina', 'meowscarada', 'tsareena', 'gothitelle', 'vaporeon', 'hatterene', 'meloetta', 'espeon', 'zoroark']

        updated_list = []

        for poke_id in base_pokemon:
            captured = store.pokemon_state.get(poke_id, {}).get("captured", False)
            if not captured:
                updated_list.append(poke_id)

        for poke_id in new_pokemon:
            captured = store.pokemon_state.get(poke_id, {}).get("captured", False)
            if not captured and poke_id not in updated_list:
                updated_list.append(poke_id)

        store.available_pokemon = updated_list

        all_chars = ["elesa","erika","roxanne","cynthia","maylene","misty","mallow",
                    "nessa","penny","delia","leaf","lusamine","lillie","may","dawn","iris","helena"]

        for cid in all_chars:
            if cid not in store.affection:
                store.affection[cid] = 0
            if cid not in store.dates_unlocked:
                store.dates_unlocked[cid] = False
            if cid not in store.character_progress:
                store.character_progress[cid] = 0
            if cid not in store.unlocked_skins:
                store.unlocked_skins[cid] = []
            if cid not in store.equipped_skin:
                store.equipped_skin[cid] = "default"
            if cid not in store.character_schedule_state:
                store.character_schedule_state[cid] = "default"
            if cid not in store.hint_state:
                store.hint_state[cid] = {
                    "current_hint": 0,
                    "hint_cost": 0,
                    "hint_purchased": False,
                }

        for poke_id in store.pokemon_state:
            if "current_event" not in store.pokemon_state[poke_id]:
                store.pokemon_state[poke_id]["current_event"] = 0
            if "trust" not in store.pokemon_state[poke_id]:
                store.pokemon_state[poke_id]["trust"] = 0
            if "captured" not in store.pokemon_state[poke_id]:
                store.pokemon_state[poke_id]["captured"] = False

        all_pokemon = base_pokemon + new_pokemon
        for poke_id in all_pokemon:
            if poke_id not in store.pokemon_state:
                store.pokemon_state[poke_id] = {
                    "discovered":    False,
                    "captured":      False,
                    "trust":         0,
                    "current_event": 0,
                    "available":     True,
                }
        store.character_schedules = {
            "leaf": {
                "default": [
                    (0, 4, 0, 1, "shopping_center"),
                    (0, 4, 2, 2, "plaza"),
                    (0, 4, 3, 4, "home_delia_leaf"),
                    (5, 6, 0, 1, "plaza"),
                    (5, 6, 2, 4, "home_delia_leaf"),
                ],
            },

            "cynthia": {
                "default": [
                    (0, 4, 2, 2, "cafe"),
                    (5, 6, 0, 2, "plaza"),
                    (0, 6, 3, 4, "library"),
                ],
            },

            "delia": {
                "default": [
                    (0, 4, 0, 1, "home_delia_leaf"),
                    (0, 4, 2, 2, "plaza"),
                    (0, 6, 3, 4, "home_delia_leaf"),
                    (5, 6, 0, 2, "plaza"),
                ],
            },

            "elesa": {
                "default": [
                    (0, 4, 0, 3, "clothing_store"),
                    (0, 4, 4, 4, "cafe"),
                    (5, 6, 0, 1, "clothing_store"),
                    (5, 6, 2, 4, "plaza"),
                ],
            },

            "erika": {
                "default": [
                    (0, 5, 0, 3, "greenhouse"),
                    (6, 6, 0, 3, "plaza"),
                    (6, 6, 4, 4, "forest"),
                ],
            },

            "lusamine": {
                "default": [
                    (0, 3, 0, 2, "cafe"),
                    (4, 4, 0, 4, "cafe"),
                    (5, 5, 0, 0, "cafe"),
                    (5, 5, 1, 2, "plaza"),
                    (6, 6, 0, 2, "cafe"),
                ],
            },

            "penny": {
                "default": [
                    (0, 3, 0, 2, "studio"),
                    (4, 4, 0, 1, "forest"),
                    (4, 4, 2, 2, "plaza"),
                    (5, 6, 0, 2, "plaza"),
                ],
            },

            "roxanne": {
                "default": [
                    (0, 4, 0, 2, "library"),
                    (5, 6, 0, 0, "library"),
                    (5, 6, 1, 2, "beach"),
                    (5, 6, 3, 4, "plaza"),
                ],
            },

            "dawn": {
                "default": [
                    (0, 3, 0, 2, "cafe"),
                    (5, 6, 3, 4, "shopping_center"),
                    (4, 4, 0, 2, "plaza"),
                    (5, 6, 0, 2, "beach"),
                    (0, 4, 3, 4, "plaza"),
                ],
            },

            "nessa": {
                "default": [
                    (0, 6, 1, 2, "beach"),
                    (0, 4, 3, 4, "cafe"),
                    (5, 6, 0, 0, "beach"),
                    (5, 6, 3, 4, "plaza"),
                ],
            },

            "maylene": {
                "default": [
                    (0, 4, 0, 3, "gym"),
                    (5, 5, 0, 3, "plaza"),
                    (6, 6, 0, 1, "gym"),
                    (6, 6, 2, 3, "beach"),
                ],
            },

            "misty": {
                "default": [
                    (0, 4, 0, 3, "forest"),
                    (5, 6, 0, 1, "forest"),
                    (5, 6, 2, 3, "beach"),
                    (5, 6, 4, 4, "plaza"),
                ],
            },

            "mallow": {
                "default": [
                    (0, 5, 0, 3, "food_store"),
                    (6, 6, 0, 1, "plaza"),
                    (6, 6, 2, 3, "cafe"),
                ],
            },

            "lillie": {
                "default": [
                    (0, 4, 0, 2, "library"),
                    (5, 6, 0, 1, "plaza"),
                    (5, 6, 2, 2, "library"),
                    (0, 6, 3, 4, "cafe"),
                ],
            },

            "may": {
                "default": [
                    (0, 4, 0, 2, "plaza"),
                    (0, 6, 3, 3, "cafe"),
                    (5, 6, 0, 2, "forest"),
                ],
            },

            "iris": {
                "default": [
                    (0, 6, 0, 2, "forest"),
                    (0, 6, 3, 3, "plaza"),
                ],
            },
            "helena": {
                "default": [
                    (0, 6, 4, 4, "home"),
                ],
                "after": [
                    (0, 6, 0, 4, "home"),
                ],
            },
        }
        store.mg_photo_current      = 0
        store.mg_photo_total_earn   = 0
        store.mg_photo_focal        = 50
        store.mg_photo_bar_value    = 0
        store.mg_photo_direction    = 1
        store.mg_photo_clicked      = False
        store.mg_photo_earn         = 0
        store.mg_photo_max_earn     = 25
        store.mg_photo_speed        = 2
        store.mg_books_slots        = []
        store.mg_books_hand         = []
        store.mg_books_placed       = []
        store.mg_books_selected     = None
        store.mg_books_time_left    = 20
        store.mg_books_shelf        = 0
        store.mg_books_money_earned = 0
        store.mg_books_complete     = False
        store.mg_books_num_books    = 4
        store.mg_books_total        = 5
        store.garden_slots          = 9
        store.garden_plots = [None, None, None, None, None, None, None, None, None]
        store.GENERAL_GIFTS = [
            {"id": "rose",          "name": "A Rose",                     "icon": "🌹", "price": 10,  "affection": 7},
            {"id": "chocolates",    "name": "A Box of Chocolates",        "icon": "🍫", "price": 20,  "affection": 15},
            {"id": "teddy_bear",    "name": "A Giant Teddy Bear",         "icon": "🧸", "price": 30,  "affection": 23},
            {"id": "perfume",       "name": "A Designer Perfume",         "icon": "🌸", "price": 40,  "affection": 32},
            {"id": "gold_necklace", "name": "Gold Necklace and Earrings", "icon": "📿", "price": 50,  "affection": 40},
        ]