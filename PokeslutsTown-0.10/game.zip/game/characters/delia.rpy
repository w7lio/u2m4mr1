# ============================================================
# POKETOWN, characters/delia.rpy
# ============================================================

label interact_delia:
    $ pending = get_pending_delivery("delia")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            delia "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            delia "I'm still waiting for my order..."
            delia "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("delia", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["delia"]
    $ slot = current_slot
    $ prog = character_progress["delia"]

    if prog == 0:
        jump delia_meeting
    elif prog == 1 and aff >= 10 and stat_charisma >= 10 and loc == "plaza" and slot in [0, 1, 2]:
        jump delia_first_encounter
    elif prog == 2 and aff >= 20 and stat_charisma >= 15 and loc == "home_delia_leaf" and slot in [0, 1, 2]:
        jump delia_second_encounter
    elif prog == 3 and aff >= 35 and loc == "plaza" and slot in [0, 1, 2]:
        jump delia_third_encounter
    elif prog == 4 and aff >= 50 and loc == "home_delia_leaf" and slot in [0, 1, 2]:
        jump delia_fourth_encounter
    elif prog == 5 and aff >= 65 and loc == "home_delia_leaf" and slot in [0, 1, 2]:
        jump delia_fifth_encounter
    elif prog == 6 and aff >= 80 and loc == "home_delia_leaf" and slot in [0, 1, 2]:
        jump delia_sixth_encounter
    elif prog == 7 and aff >= 95 and loc == "home_delia_leaf" and slot in [0, 1, 2]:
        jump delia_seventh_encounter
    else:
        jump delia_contextual_dialogue


# ------------------------------------------------------------
# CONTEXTUAL DIALOGUE
# ------------------------------------------------------------

label delia_contextual_dialogue:

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve
    $ affection["delia"] = min(100, affection["delia"] + 3)

    if aff_tier == "stranger":
        if loc == "home_delia_leaf":
            delia "Welcome dear, make yourself at home."
        else:
            delia "Hello! I don't think we've met. I'm Delia."
            delia "I live here with my daughter. You should come by for dinner sometime."

    elif aff_tier == "acquaintance":
        if loc == "home_delia_leaf":
            delia "I made too much food again. Would you like some?"
            delia "I always cook for three out of habit."
        else:
            delia "How are you settling in, dear? Heartwood takes some getting used to."

    elif aff_tier == "friend":
        if loc == "home_delia_leaf":
            delia "You're practically family at this point. Sit down, I'll make tea."
        else:
            delia "You know, my daughter talks about you. I hope that's alright."

    else:
        if loc == "home_delia_leaf":
            delia "This house feels livelier since you started visiting."
            delia "I hope you know you're always welcome here."
        else:
            delia "You remind me of someone I used to know. That's a compliment, dear."

    hide delia
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label delia_meeting:

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Hi, you must be Leaf's friend. Welcome, it's nice to meet you."

    hide delia
    with dissolve

    $ affection["delia"] = min(100, affection["delia"] + 5)
    $ character_progress["delia"] += 1
    $ advance_hint("delia")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label delia_first_encounter:

    scene bg plaza_day
    with fade

    narrator "While walking through the plaza, you spot Delia struggling with several heavy bags of groceries."

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    mc "Hey Delia, looks like you've got your hands full. Need some help with those?"

    delia "Oh! Would you really? Thank you so much, dear. What a sweet young man you are."

    narrator "You take the heavy grocery bags from her and walk together toward her house."

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia01.png" as cg_scene
    with dissolve

    delia "Thank you again for helping me. I'm so sorry for making you climb all these stairs. I don't know what's wrong with the elevator today."

    mc "It's no trouble at all, really."

    delia "You're such a kind young man. You'll make some lucky girl a wonderful husband one day."

    delia "Back in my day, men weren't nearly this thoughtful. It's quite refreshing."

    delia "You know, I love to cook. If you'd like, I could teach you a few recipes sometime. It would definitely earn you some points with the ladies."

    narrator "You finish putting away the groceries in her kitchen."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "If you ever want those cooking lessons, just bring me a Bronze Potato and an Alba Onion. We'll cook something together."

    hide delia
    with dissolve

    $ character_progress["delia"] += 1
    $ affection["delia"] = min(100, affection["delia"] + 5)
    $ advance_hint("delia")
    $ advance_slot(2)

    jump location_home_delia_leaf


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label delia_second_encounter:

    if gallery_replay:
        $ add_temp_ingredient("bronze_potato", "Bronze Potato", "🥔")
        $ add_temp_ingredient("alba_onion", "Alba Onion", "🧅")
    
    $ has_potato = has_food_item("bronze_potato")
    $ has_onion  = has_food_item("alba_onion")

    if not has_potato or not has_onion:
        show expression get_char_sprite("delia", "default") as delia at center
        with dissolve
        delia "Don't forget, bring a Bronze Potato and an Alba Onion and we'll cook together."
        hide delia
        with dissolve
        jump location_home_delia_leaf

    scene bg delia_home
    with fade

    narrator "You arrive at Delia's house carrying the Bronze Potato and Alba Onion she asked for."

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Come in, come in, dear! Make yourself comfortable in the living room. I'll be right out, I'm just finishing getting ready."

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia02.png" as cg_scene at center
    with dissolve

    narrator "You sit on the couch and wait. As you look around the cozy living room, something catches your eye, a photograph partially tucked under the armchair."

    narrator "Curious, you pick it up. It's an old photo of Delia from many years ago... completely naked, posing seductively on a bed with a very provocative smile."

    delia "Oh my goodness!"

    narrator "Delia walks in just as you're holding the photo. Her eyes widen slightly."

    delia "Oh dear... I didn't realize I'd left that there. How terribly embarrassing."

    narrator "Despite her words, she doesn't seem overly ashamed. In fact, there's a playful glint in her eyes."

    delia "That was from my younger, wilder days. I was quite the adventurous woman back then."

    delia "If you'd like, you can keep it. I'd be flattered knowing a handsome young man like you is looking at me that way."

    delia "Now then... did you bring the ingredients I asked for? Let's get cooking, shall we?"

    hide cg_scene
    with dissolve

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    narrator "You spend the next while cooking together with Delia. The atmosphere feels noticeably warmer than before."

    hide delia
    with dissolve

    $ consume_food_item("bronze_potato")
    $ consume_food_item("alba_onion")

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ unlock_recipe("potato_onion_skillet")

    $ character_progress["delia"] += 1
    $ affection["delia"] = min(100, affection["delia"] + 5)
    $ advance_hint("delia")
    $ advance_slot(2)

    jump location_home_delia_leaf


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label delia_third_encounter:

    scene bg plaza_day
    with fade

    narrator "You run into Delia again in the plaza. Once more, she's carrying several heavy grocery bags."

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Oh! Hello again, dear. What a pleasant surprise. It's been such a hot day today, hasn't it?"

    mc "It really has. Do you need a hand with those bags?"

    delia "Oh no, I couldn't keep imposing on you like this..."

    mc "It's no trouble at all. I'm not busy right now."

    delia "Well... if you insist. Thank you so much. You know, being a single mother means there's rarely anyone around to help with these things."

    narrator "You take the heavy bags and walk with her back to her house."

    delia "This is the second time you've helped me. You're too kind for your own good."

    delia "Please, come inside for a moment. I'd like to thank you properly this time."

    mc "Really, it's fine. There's no need."

    delia "I insist, sweetheart. Besides... you look like the heat is getting to you as well. Let me take care of you for a bit."

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia03.png" as cg_scene
    with dissolve

    narrator "Delia gives you a warm, seductive smile and gently pushes you against the wall."

    narrator "She kneels gracefully in front of you, unbuttons your pants and pulls them down, freeing your cock."

    narrator "Without hesitation, she takes you into her warm, soft mouth and begins sucking with slow, experienced movements. Her tongue swirls around the head while her hand strokes the base."

    narrator "She looks up at you with lustful, affectionate eyes as she pleasures you, clearly enjoying herself."

    narrator "Her technique is gentle but skillful. She gradually takes you deeper, humming softly around your length."

    narrator "It doesn't take long before the pleasure becomes overwhelming. With a groan, you cum hard into her mouth."

    narrator "Delia swallows every drop without hesitation, then slowly pulls back, licking her lips with a satisfied smile."

    delia "Wow, I wasn't expecting that much. You can really tell you're still in your prime."

    delia "You know, I'd love to continue our cooking lessons."

    delia "Bring a Bronze Potato and a Torchic Breast, and we'll make something together."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["delia"] += 1
    $ affection["delia"] = min(100, affection["delia"] + 5)
    $ advance_hint("delia")
    $ advance_slot(2)

    jump location_home_delia_leaf


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label delia_fourth_encounter:

    if gallery_replay:
        $ add_temp_ingredient("bronze_potato", "Bronze Potato", "🥔")
        $ add_temp_ingredient("torchic_breast", "Torchic Breast", "🍗")
        

    $ has_potato  = has_food_item("bronze_potato")
    $ has_torchic = has_food_item("torchic_breast")

    if not has_potato or not has_torchic:
        show expression get_char_sprite("delia", "default") as delia at center
        with dissolve
        delia "Don't forget, bring a Bronze Potato and a Torchic Breast for our next lesson."
        hide delia
        with dissolve
        jump location_home_delia_leaf

    scene bg delia_home
    with fade

    narrator "You arrive at Delia's house carrying the ingredients she asked for."

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Come in, dear!"

    hide delia
    with dissolve

    mc "Hey Delia, I brought the—"

    show expression "images/cg/delia/Delia04.png" as cg_scene
    with dissolve

    narrator "You freeze mid-sentence. Delia is standing in the kitchen wearing nothing but a small apron. Her large breasts are barely contained, and her generous curves are on full display."

    delia "Oh? What's the matter, sweetheart?" 

    narrator "She tilts her head with a playful smile, clearly enjoying your reaction."

    delia "Did I catch you off guard?"

    mc "I... I'm just not used to seeing you like this."

    delia "I'm just getting comfortable for our cooking lesson. It's quite hot in the kitchen, you know~"

    delia "Come on now, don't just stand there staring. Time's ticking. Let's get started."

    hide cg_scene
    with dissolve

    show expression "images/cg/delia/Delia05.png" as cg_scene
    with dissolve

    narrator "You try to focus on cooking with Delia, but it's nearly impossible. Every time she moves, her barely-covered breasts and soft curves draw your eyes."

    narrator "Despite the constant distraction, you manage to finish the dish together."

    hide cg_scene
    with dissolve

    delia "Mmm, delicious! You're learning very fast, sweetheart."

    mc "With a teacher like you, how could I not?"

    delia "Such a smooth talker~" 

    delia "Well then... I think it's time for your reward."

    show expression "images/cg/delia/Delia05.png" as cg_scene
    with dissolve

    narrator "Delia kneels in front of you once again, this time with clear confidence. She pulls down your pants and takes your cock deep into her warm mouth."

    narrator "She sucks you eagerly, moving her head faster and using her tongue with much more skill than last time."

    narrator "Her soft moans vibrate around your shaft as she pleasures you, clearly enjoying the act."

    narrator "It doesn't take long before the pleasure becomes too much. With a groan, you cum hard into her mouth."

    narrator "Delia swallows every drop, then pulls back slowly, licking her lips with a satisfied smile."

    delia "No dinner is complete without dessert, don't you think?"

    delia "Next time, bring a Leppa Berry, a Bronze Potato, and an Alba Onion... and we'll continue your lessons."

    hide cg_scene
    with dissolve

    $ consume_food_item("bronze_potato")
    $ consume_food_item("torchic_breast")

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ unlock_recipe("potato_torchic_roast")

    $ character_progress["delia"] += 1
    $ affection["delia"] = min(100, affection["delia"] + 5)
    $ advance_hint("delia")
    $ advance_slot(2)

    jump location_home_delia_leaf


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label delia_fifth_encounter:

    if gallery_replay:
        $ add_temp_ingredient("bronze_potato", "Bronze Potato", "🥔")
        $ add_temp_ingredient("leppa_berry", "Leppa Berry", "🍓")
        $ add_temp_ingredient("alba_onion", "Alba Onion", "🧅")

    $ has_leppa  = has_food_item("leppa_berry")
    $ has_potato = has_food_item("bronze_potato")
    $ has_onion  = has_food_item("alba_onion")

    if not has_leppa or not has_potato or not has_onion:
        show expression get_char_sprite("delia", "default") as delia at center
        with dissolve
        delia "Don't forget, bring a Leppa Berry, a Bronze Potato, and an Alba Onion for our next lesson."
        hide delia
        with dissolve
        jump location_home_delia_leaf

    scene bg delia_home
    with fade

    narrator "You arrive at Delia's house with the requested ingredients."

    narrator "As expected, she's wearing her revealing cooking apron again, leaving very little to the imagination."

    show expression "images/cg/delia/Delia05.png" as cg_scene
    with dissolve

    mc "Wow... quite the view again."

    delia "Oh? Don't get flustered now, dear. Come help me cook."

    narrator "Throughout the cooking process, Delia is much more affectionate than before. She constantly brushes her soft body against yours, her breasts pressing against your arm or back as she reaches for ingredients."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Wonderful! You're becoming such a great assistant."

    mc "Thanks. Things are getting more demanding though... we're really raising the bar each time."

    delia "You're right, I'm sorry about that. I just want to take full advantage of having such a helpful young man around to try more complex dishes."

    mc "Don't apologize. I'm happy to help."

    delia "Even so... don't think you're leaving without your reward."

    delia "This time, dessert is definitely on me~"

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia06.png" as cg_scene
    with dissolve

    narrator "Delia gives you a sultry smile and gently pushes you back onto the sofa."

    narrator "She straddles your lap, her soft thighs on either side of you. With one hand she reaches between her legs, grabs your hard cock, and slowly lowers herself onto it."

    narrator "You slide into her warm, wet pussy with ease. Delia lets out a deep, satisfied sigh as she takes you all the way inside."

    delia "Mmmh... There we go, sweetheart... Feel how wet I am for you?"

    narrator "She starts riding you slowly at first, rolling her hips in a sensual rhythm. Her large breasts bounce heavily with every movement."

    delia "Ahh... You're so deep like this... I love it."

    narrator "Gradually, she picks up the pace, riding you faster and harder. Her soft moans fill the room as her body moves with growing desire."

    delia "Nngh... Yes... Just like that... Let me take care of you, baby."

    narrator "She places her hands on your chest for support, her big breasts bouncing wildly as she rides you with increasing passion."

    delia "Mmmh! You're getting even harder inside me... Does it feel good?"

    narrator "Her breathing becomes heavier and more erratic. Her hips move frantically as she chases her pleasure."

    delia "Ahh...! I'm so close... Don't hold back, Cum with me, sweetheart!"

    show expression "images/cg/delia/Delia06a.png" as cg_scene
    with flash

    narrator "Delia moans loudly as she cums hard, her pussy clenching tightly around your cock. Her whole body trembles on top of you."

    narrator "The feeling of her orgasm pushes you over the edge. You thrust up into her and cum deep inside her warm pussy."

    delia "Haaah... That's it... Fill me up... Good boy~"

    hide cg_scene
    with dissolve

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Phew, I'm not as young as I used to be!"
    delia "For our next lesson, how about you bring a Lum Berry, a Torchic Breast, and a Moss Pumpkin?"

    hide delia
    with dissolve

    $ consume_food_item("leppa_berry")
    $ consume_food_item("bronze_potato")
    $ consume_food_item("alba_onion")

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ unlock_recipe("leppa_root_hash")

    $ character_progress["delia"] += 1
    $ affection["delia"] = min(100, affection["delia"] + 5)
    $ advance_hint("delia")
    $ advance_slot(2)

    jump location_home_delia_leaf


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label delia_sixth_encounter:

    if gallery_replay:
        $ add_temp_ingredient("moss_pumpkin", "Moss Pumpkin", "🎃")
        $ add_temp_ingredient("lum_berry", "Lum Berry", "✨")
        $ add_temp_ingredient("torchic_breast", "Torchic Breast", "🍗")

    $ has_lum     = has_food_item("lum_berry")
    $ has_torchic = has_food_item("torchic_breast")
    $ has_pumpkin = has_food_item("moss_pumpkin")

    if not has_lum or not has_torchic or not has_pumpkin:
        show expression get_char_sprite("delia", "default") as delia at center
        with dissolve
        delia "Don't forget, bring a Lum Berry, a Torchic Breast, and a Moss Pumpkin for our next lesson."
        hide delia
        with dissolve
        jump location_home_delia_leaf

    scene bg delia_home
    with fade

    narrator "You arrive at Delia's house with the ingredients she requested. As soon as you walk in, you find her waiting with an eager expression."

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "You're finally here! I've been so excited waiting for you, sweetheart."

    mc "That eager to cook today?"

    delia "Oh... right. Cooking."

    narrator "She lets out a soft, embarrassed laugh and brings a hand to her cheek."

    delia "Sorry, dear. I was so focused on seeing you that cooking completely slipped my mind."

    mc "That's fine. If you want, we could start with dessert this time and do the cooking afterwards."

    delia "Mmm... Now that's a wonderful idea~"

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia06.png" as cg_scene
    with dissolve

    narrator "Delia gives you a hungry smile and pushes you back onto the sofa with surprising eagerness."

    narrator "She quickly straddles you, her thick thighs settling on either side of your hips. Without wasting time, she grabs your cock and lowers herself onto it, taking you deep inside her wet pussy in one smooth motion."

    delia "Mmmh~! There we go, sweetheart..."

    narrator "She starts riding you with eager, energetic movements. Her hips move up and down, her large breasts bouncing heavily with every thrust."

    delia "Ahh... You're so hard today... I love how you feel inside me."

    narrator "Her moans grow louder and sweeter as she picks up the pace, grinding and bouncing on your cock with clear desire."

    delia "Nngh... Yes... Just like that, baby. Let me ride you nice and deep~"

    narrator "She leans forward, pressing her soft breasts against your chest as her hips move faster and more desperately."

    show expression "images/cg/delia/Delia06a.png" as cg_scene
    with flash

    delia "Haaah...! You're hitting all the right spots... Mmmh!"

    narrator "Her warm, tight pussy squeezes around you as she rides you passionately, clearly enjoying being in control."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Mmm... What a wonderful treat. After that, I almost lost all interest in cooking, you know?"

    narrator "She lets out a soft, contented laugh, still looking a little flushed."

    mc "Shall we keep going?"

    delia "Oh, as tempting as that is... no, sweetheart. Let's take a little break and finish cooking first."

    delia "We can always pick up where we left off after the meal~"

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia05.png" as cg_scene
    with dissolve

    narrator "You prepare the dish with Delia. It's hard to think clearly while cooking, but you manage to finish it."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Wonderful! We really made quite a feast this time, didn't we?"

    narrator "Delia looks at the finished dishes with satisfaction, then turns her gaze back to you with a playful glint in her eyes."

    mc "Ready for round two?"

    delia "My my... Don't you want to eat first, sweetheart?"

    mc "No. Straight to the main event."

    delia "Oh dear~" 

    narrator "She lets out a soft, amused laugh, her cheeks turning a light shade of pink."

    delia "You're becoming quite bold lately. I like that."

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia07.png" as cg_scene
    with dissolve

    narrator "You both move to Delia's bedroom. She gently pushes you onto the bed and climbs on top of you."

    narrator "Straddling your hips in cowgirl position, Delia looks down at you with a warm, lustful smile. She reaches between her legs, grabs your cock, and slowly lowers herself onto it."

    delia "Mmmh~... There we go, sweetheart... Feel how deep you are?"

    narrator "She takes you all the way inside her warm, wet pussy with a long, satisfied moan. Her big, soft breasts rest heavily against her chest as she settles on you."

    delia "Ahh... You fill me up so nicely..."

    narrator "She begins riding you with slow, steady movements, her hips rolling sensually. Her large breasts bounce beautifully with every rise and fall."

    delia "Nngh... Yes... Just like that... Let me take care of you, baby."

    narrator "Gradually, her pace increases. She starts riding you harder and faster, her moans growing louder and sweeter."

    delia "Haaah...! You're so deep... Mmmh! I love this position..."

    narrator "Her body moves with passion, her breasts bouncing wildly as she rides you eagerly. Her breathing becomes ragged and needy."

    delia "Ahh...! I'm getting close... Don't hold back, sweetheart... Cum with me!"

    show expression "images/cg/delia/Delia07a.png" as cg_scene
    with flash

    narrator "Delia's pussy clenches tightly around you as she reaches a powerful climax. Her whole body trembles on top of you, moaning loudly in pleasure."

    narrator "The feeling of her orgasm pushes you over the edge. You thrust up into her and cum hard, filling her deeply as you both ride out your climax together."

    delia "Haaah... Yes... That's it... Fill me up~"

    hide cg_scene
    with dissolve

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Wow... I haven't felt like this in decades, sweetheart."

    narrator "Delia lets out a contented sigh, still looking a little flushed and blissful."

    delia "How about we plan our next recipe?"

    mc "What did you have in mind?"

    delia "Mmm, let me think... Could you bring me a Colbur Berry, a Tauros Steak, and a Meteor Root next time?"

    delia "I'll handle the rest of the ingredients. We'll make something really special~"

    hide delia
    with dissolve

    $ consume_food_item("lum_berry")
    $ consume_food_item("torchic_breast")
    $ consume_food_item("moss_pumpkin")

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ unlock_recipe("lum_torchic_medley")

    $ character_progress["delia"] += 1
    $ affection["delia"] = min(100, affection["delia"] + 5)
    $ advance_hint("delia")
    $ advance_slot(2)

    jump location_home_delia_leaf


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label delia_seventh_encounter:

    if gallery_replay:
        $ add_temp_ingredient("meteor_root", "Meteor Root", "🪨")
        $ add_temp_ingredient("colbur_berry", "Colbur Berry", "🫚")
        $ add_temp_ingredient("tauros_steak", "Tauros Steak", "🥩")

    $ has_colbur = has_food_item("colbur_berry")
    $ has_tauros = has_food_item("tauros_steak")
    $ has_meteor = has_food_item("meteor_root")

    if not has_colbur or not has_tauros or not has_meteor:
        show expression get_char_sprite("delia", "default") as delia at center
        with dissolve
        delia "Don't forget, bring a Colbur Berry, a Tauros Steak, and a Meteor Root for our feast."
        hide delia
        with dissolve
        jump location_home_delia_leaf

    scene bg delia_home
    with fade

    narrator "It took quite some effort to gather all the rare ingredients, but you finally managed. Today you're returning to Delia's house for what promises to be a very special feast."

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "Oh, you're here! I've been looking forward to this all day, sweetheart."

    delia "Did you manage to bring everything?"

    mc "Of course. I'm ready to cook."

    delia "Perfect~ Before we start, I need your help with something special."

    delia "We have to knead the Colbur Berry properly to bring out all of its sweet juice."

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia08.png" as cg_scene
    with dissolve

    narrator "Delia picks up the Colbur Berry. It's a vibrant pink color, covered in soft, rounded little spikes that give it a textured surface almost like it was made for this."

    delia "This one has such a nice shape and texture... Don't you think?"

    narrator "She leans back against the kitchen counter, spreads her legs, and hands you the berry with a playful, expectant smile."

    delia "Be a good boy and help me knead it... Use it on me."

    narrator "You press the soft, textured berry against her wet entrance and slowly push it inside her. Delia lets out a sweet moan as the little spikes gently stimulate her inner walls."

    delia "Mmmh~... Yes, just like that... Move it slowly at first."

    narrator "Following her instructions, you begin sliding the pink Colbur Berry in and out of her pussy. The soft spikes drag deliciously against her sensitive insides with every movement."

    delia "Ahh...! Oh sweetheart... It feels so good... A little deeper now..."

    narrator "You push it further inside her, moving it with a steady rhythm. Delia's breathing becomes heavier and her large breasts rise and fall with each thrust of the berry."

    delia "Nngh~... Faster, baby... Knead it nice and deep for me, Mmmh!"

    narrator "You increase the pace, thrusting the textured berry in and out of her. Delia’s moans grow louder and more desperate as her body starts to tremble."

    delia "Right there! Don't stop... I'm going to cum...!"

    narrator "With a long, blissful cry, Delia reaches orgasm. Her pussy clenches tightly around the Colbur Berry as her body shakes with pleasure."

    delia "Haaah... Haah... You're so good at this..."

    narrator "She looks down at you with flushed cheeks and a very satisfied smile."

    hide cg_scene
    with dissolve

    narrator "It's an ambitious feast, but after working together for a long while, you finally manage to complete it."

    show expression get_char_sprite("delia", "default") as delia at center
    with dissolve

    delia "My goodness... We really outdid ourselves this time. There's so much food here, I don't think I could possibly eat it all by myself."

    mc "It'd be a shame to let it go to waste."

    delia "Oh, it won't go to waste, sweetheart. I'm going to invite some friends over for dinner tonight. I'm sure they'll love it."

    mc "In that case, I should probably get going and let you prepare."

    delia "Nonsense~"

    narrator "She steps closer, a playful smile on her lips."

    delia "There's still plenty of time before they arrive. Dinner won't be for another couple of hours..."

    delia "We should celebrate our hard work first, don't you think?"

    hide delia
    with dissolve

    show expression "images/cg/delia/Delia07.png" as cg_scene
    with dissolve

    narrator "You follow Delia into her bedroom. The moment the door closes, she turns around and pushes you onto the bed with eager desire."

    narrator "She climbs on top of you, straddling your hips in cowgirl position once again. This time her movements are filled with hunger."

    delia "Mmm... One last time before my guests arrive~"

    narrator "She reaches down, grabs your cock and guides it to her entrance. With a deep moan, she lowers herself, taking you all the way inside her warm, wet pussy."

    delia "Ahh~... Yes... You feel so good, sweetheart..."

    narrator "Delia begins riding you passionately, her experienced hips moving with both skill and raw desire. Her large, heavy breasts bounce heavily with every rise and fall."

    delia "Nngh...! Look at them bouncing for you... Do you like the view?"

    narrator "She leans forward, placing her hands on your chest as she rides you harder and faster. Her moans grow louder and sweeter."

    delia "Haaah...! You're so deep like this... Mmmh! I love feeling you throb inside me..."

    narrator "The sound of skin slapping against skin fills the room. Delia's movements become more frantic as pleasure builds rapidly for both of you."

    delia "Ahh...! I'm so close, baby... Cum with me... I want to feel you cum inside me one more time!"

    show expression "images/cg/delia/Delia07a.png" as cg_scene
    with flash

    narrator "Delia's body suddenly tenses. She slams down hard and cums intensely, her pussy clenching tightly around your cock as she moans loudly in ecstasy."

    narrator "The powerful contractions of her orgasm push you over the edge. You thrust up into her and release deep inside her, filling her completely as you both reach a strong, shared climax."

    delia "Haaah...! Yes... Fill me up, sweetheart... Just like that~"

    hide cg_scene
    with dissolve

    $ consume_food_item("colbur_berry")
    $ consume_food_item("tauros_steak")
    $ consume_food_item("meteor_root")

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ unlock_recipe("colbur_tauros_feast")

    $ character_progress["delia"] += 1
    $ affection["delia"] = min(100, affection["delia"] + 5)
    $ advance_hint("delia")
    $ advance_slot(2)

    jump location_home_delia_leaf
