# ============================================================
# POKETOWN, characters/may.rpy
# ============================================================

label interact_may:

    $ pending = get_pending_delivery("may")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            may "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            may "I'm still waiting for my order..."
            may "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("may", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["may"]
    $ slot = current_slot
    $ prog = character_progress["may"]

    if prog == 0:
        jump may_meeting
    elif prog == 1 and aff >= 10 and loc == "plaza" and slot in [0, 1, 2]:
        jump may_first_encounter
    elif prog == 2 and aff >= 20 and stat_charisma >= 10 and loc == "plaza" and slot in [0, 1, 2] and has_food_item("lum_berry"):
        jump may_second_encounter
    elif prog == 3 and aff >= 35 and stat_charisma >= 15 and loc == "plaza" and slot in [0, 1, 2] and "may_cosplay" in unlocked_skins["may"]:
        jump may_third_encounter
    elif prog == 4 and aff >= 50 and stat_charisma >= 15 and loc == "forest" and slot in [0, 1, 2]:
        jump may_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_charisma >= 20 and loc == "cafe" and slot in [3]:
        jump may_fifth_encounter
    elif prog == 6 and aff >= 80 and loc == "plaza" and slot in [0]:
        jump may_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_charisma >= 25 and loc == "cafe" and slot in [2, 3] and "may_Lingerie" in unlocked_skins["may"] and len([i for i in inventory_gifts if i.get("id") == "sitrus_miltank_roast" and i.get("quantity", 0) > 0]) > 0:
        jump may_seventh_encounter
    else:
        jump may_contextual_dialogue

label may_contextual_dialogue:
    show expression get_char_sprite("may", "default") as may at center
    with dissolve
    $ affection["may"] = min(100, affection["may"] + 3)

    if aff_tier == "stranger":
        if loc == "plaza":
            may "Oh hey! You must be the new person everyone's talking about."
            may "I'm May! Welcome to Heartwood!"
        elif loc == "forest":
            may "Another explorer! Finally!"
            may "I'm May. I've been mapping the forest trails in my spare time."
        else:
            may "Hi! I'm May! I feel like I've seen you around but we haven't actually met."
    elif aff_tier == "acquaintance":
        if loc == "forest":
            may "I found a new trail yesterday. Want to hear about it?"
        elif loc == "cafe":
            may "I come here to plan my next adventure. Over coffee, obviously."
        else:
            may "Hey! How's everything going? Tell me something interesting."
    elif aff_tier == "friend":
        if loc == "plaza":
            may "You're one of my favorite people to run into here."
            may "Like genuinely. Not just being nice."
        elif loc == "forest":
            may "I want to show you the trail I found. Just us though."
        else:
            may "You know what, you've made this town a lot more fun."
    elif aff_tier == "close":
        if loc == "forest":
            may "Every adventure is better with you. That's just a fact."
        else:
            may "I've traveled a lot. I've never wanted to stay somewhere this much before."

    hide may
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location

# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label may_meeting:

    scene bg plaza_day
    with fade

    show expression get_char_sprite("may", "default") as may at center
    with dissolve

    may "Heyy~ So you're the new farmer everyone's talking about!"

    may "I saw you moving into the old farm the other day. You look strong~"

    may "I'm May! I live nearby. I'd love to see what kind of fruits and vegetables you're growing... maybe I can taste them sometime?"

    narrator "She gives you a bright, flirty smile and a playful wink."

    hide may
    with dissolve

    $ character_progress["may"] += 1
    $ affection["may"] = min(100, affection["may"] + 5)
    $ advance_hint("may")
    $ advance_slot()

    jump expression "location_" + current_location

# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label may_first_encounter:

    scene bg plaza_day
    with fade

    narrator "You're walking through the busy plaza when a cheerful voice calls out to you."

    show expression get_char_sprite("may", "default") as may at center
    with dissolve

    may "There you are! I've been waiting for you, you know?!"

    may "How can you be so cruel? Poor little me, starving to death because the new farmer won't pay any attention to me!"

    narrator "May puts on an exaggerated, dramatic pout, placing the back of her hand against her forehead like a damsel in distress."

    mc "Your acting isn't very convincing."

    narrator "May's eyes sparkle with mischief. Without warning, she steps forward, grabs your collar and pulls you into a bold, playful kiss right in the middle of the plaza."

    may "Mwah~! There. Does that convince you better?"

    may "If you want another one of those... you have to bring me a Lum Berry next time, okay?"

    mc "A Lum Berry? I don't even know where to find that."

    may "That's not my problem anymore~ Talk to the girl who runs the greenhouse or something. Figure it out, Mr. Farmer!"

    narrator "She gives you a cheeky wink and a bright smile, then turns away with an exaggerated sway in her hips."

    hide may
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["may"] += 1
    $ affection["may"] = min(100, affection["may"] + 5)
    $ advance_hint("may")
    $ advance_slot(2)

    jump expression "location_" + current_location

# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label may_second_encounter:

    scene bg plaza_day
    with fade

    narrator "You spot May in the plaza. The moment she sees the Lum Berry in your hand, her face lights up."

    show expression get_char_sprite("may", "default") as may at center
    with dissolve

    may "Yay~! You actually brought it! I knew you wouldn't let me starve!"

    narrator "She runs toward you with a big, bright smile, eyes locked on the berry."

    mc "Hold on. How do you know this is for you?"

    may "Oh please~ Of course you brought the exact fruit I asked for. You were just taking a casual walk through the plaza, right?"

    narrator "She gives you a sarcastic but adorable smile. The two of you end up sitting together on a bench."

    may "Lum Berries are my absolute favorite! They stopped selling them at the store, so it's been forever since I had one."

    narrator "She eats the berry happily, making cute little satisfied sounds with every bite."

    narrator "As soon as she finishes, May stands up and boldly sits on your lap, facing you. She wraps her arms around your neck."

    may "Time for your prize~"

    mc "Wait... isn't this a bit much right here in the plaza?"

    may "Relax~ It's just two lovebirds kissing. Nothing weird about that, right?"

    mc "We're not lovebirds..."

    may "Aww, too bad... And here I was hoping to kiss my boyfriend."

    may "I guess I'll just have to leave then..."

    mc "Alright, fine... maybe we are boyfriend and girlfriend."

    may "That's what I like to hear, big guy~"

    hide may
    with dissolve

    show expression "images/cg/may/May01.png" as cg_scene
    with dissolve

    narrator "May smiles triumphantly and pulls you into a deep, playful kiss right there on the bench, not caring who might be watching."

    narrator "Her lips are soft and sweet, still carrying the faint fruity taste of the Lum Berry. She kisses you eagerly, pressing her body against yours."

    may "Mmmh~"

    show expression "images/cg/may/May02.png" as cg_scene
    with dissolve

    narrator "You slide your hands down her back and boldly caress her round, firm ass, squeezing it gently as you pull her closer on your lap."

    may "Ah...! Hey... you're getting handsy already~"

    narrator "She doesn't pull away. Instead, she lets out a soft, playful moan into the kiss and grinds lightly against you, clearly enjoying the attention."

    may "Mmm... I like it when you touch me like that..."

    narrator "The kiss grows deeper and more heated. May's fingers run through your hair as she tilts her head, kissing you with bold passion right in the middle of the plaza."

    narrator "Every time you squeeze her ass, she lets out a cute little whimper, her body shivering with excitement."

    may "Nnh~ You're so naughty... but don't stop..."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["may"] += 1
    $ affection["may"] = min(100, affection["may"] + 5)
    $ advance_hint("may")
    $ advance_slot(2)

    jump expression "location_" + current_location
# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label may_third_encounter:

    scene bg plaza_day
    with fade

    narrator "While walking through the plaza, someone suddenly covers your eyes from behind."

    may "Guess who~!"

    mc "May. You're the only person in town who walks around shouting like she's the main character of a show."

    may "Hehe~ That's because I have way too much personality for this small town!"

    narrator "You turn around and see May wearing a very cute Megumin cosplay."

    show expression "images/cg/may/May03.png" as cg_scene
    with dissolve

    may "So? Do you like it? I knew you were a secret nerd the moment I saw you~ This is exactly what boys like these days, right?"

    mc "It looks really good on you."

    may "I'm glad you think so... I'm even wearing the full outfit underneath, you know?"

    may "But if you want to see the rest... you'll have to earn it~"

    narrator "At that moment, a sudden breeze lifts her skirt, giving you a clear view of her panties."

    show expression "images/cg/may/May04.png" as cg_scene
    with dissolve

    may "Kyaa—?!"

    narrator "May quickly presses her skirt down, her face turning bright red."

    mc "Looks like I earned it pretty easily."

    may "D-Don't say it like that! ...But ...be honest. Does it look good on me?"

    mc "It looks fantastic."

    may "Hehe, of course it does! Everything looks fantastic on me~"

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["may"] += 1
    $ affection["may"] = min(100, affection["may"] + 5)
    $ advance_hint("may")
    $ advance_slot(2)

    jump expression "location_" + current_location
# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label may_fourth_encounter:

    scene bg forest_day
    with fade

    narrator "You're walking through the peaceful forest when you hear a familiar cheerful voice calling out to you."

    show expression get_char_sprite("may", "default") as may at center
    with dissolve

    may "Heyyy~! What are you doing out here all alone in the forest, Mr. Farmer?"

    mc "I could ask you the same thing."

    may "There's not much to do in town, so I like coming here to walk and clear my head sometimes."

    may "Oh! That reminds me... I've never invited you to show me your farm! What are you waiting for? Invite me~!"

    mc "Alright, let's go."

    hide may
    with dissolve

    scene bg garden_day 
    with fade

    show expression "images/cg/may/May05.png" as cg_scene
    with dissolve

    narrator "When you arrive at your farm, May runs excitedly toward your crops."

    may "Wooow! This is so cool! You can grow all this food for free?!"

    mc "It's not exactly free. You have to buy the seeds, take care of them, and harvest everything."

    may "Well... it's free for me, right~?"

    narrator "She laughs playfully and quickly picks a few fruits, eating them with obvious delight."

    hide cg_scene
    with dissolve

    scene bg home_interior_night
    with fade
    show expression get_char_sprite("may", "default") as may at center
    with dissolve

    narrator "Later, you both end up in your bedroom. May lies on top of you comfortably, resting her head on your chest."

    narrator "Suddenly, May notices your erection pressing against her."

    may "Hehe~ Did I make your little friend this happy already?"

    may "Since it's my fault he's so excited... I'll help you calm him down~"

    hide may
    with dissolve

    show expression "images/cg/may/May06.png" as cg_scene
    with dissolve

    narrator "She reaches down boldly, pulls your cock out and slides it under her panties, pressing the shaft right against her warm, wet pussy."

    may "Mmmh... But don't get any ideas. I won't let you put it in... at least not yet~"

    narrator "May starts grinding against you intensely, rolling her hips back and forth. Her slick folds rub along your length as she moans softly."

    may "Ahh~ You're so hard... It feels really good like this..."

    narrator "She gets more and more into it, breathing heavily and moving faster. Her breasts bounce with every roll of her hips."

    may "Nnh...! Just like that... keep throbbing against me~"

    show expression "images/cg/may/May06a.png" as cg_scene
    with flash

    narrator "The stimulation quickly becomes too much. You cum hard, shooting thick ropes inside her panties and all over her clothes."

    may "Wow~ You came so much! Look at the mess you made... You're going to have to clean my clothes now, you know?"

    narrator "Without any shame, May stands up, slowly takes off all her clothes and tosses them aside. She stays completely naked in front of you."

    may "I'll take a little nap here while you clean up~ Don't take too long, okay?"

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["may"] += 1
    $ affection["may"] = min(100, affection["may"] + 5)
    $ advance_hint("may")
    $ advance_slot(2)

    jump expression "location_" + current_location
    
# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label may_fifth_encounter:

    scene bg cafe
    with fade

    show expression get_char_sprite("may", "default") as may at center
    with dissolve

    may "Heyy~! Over here! Come sit with me!"

    narrator "May is sitting at a table, happily eating a big slice of strawberry cake."

    may "Come on, join me! This is exactly what I needed to end the day perfectly, delicious strawberry cake and spending time with my cute boyfriend~"

    hide may
    with dissolve

    show expression "images/cg/may/May07.png" as cg_scene
    with dissolve

    may "Want some? It's my favorite! You know this is the only café in town, right? But I love coming here."

    narrator "She scoops a piece of cake with her fork and brings it to your mouth with a playful smile."

    may "Ahhhhh~ Open wide!"

    narrator "You spend a while chatting and enjoying the cake together."

    narrator "Suddenly, May looks at you with a mischievous, playful expression."

    may "Hey... now that the place is emptier, do you know what would be really fun?"

    show expression "images/cg/may/May07a.png" as cg_scene
    with dissolve

    narrator "Before you can answer, she quickly lifts her blouse and flashes her breasts right there at the table."

    mc "May! What are you doing?! We're in public!"

    may "I'm doing it so you can look, silly~"

    narrator "She lifts it again with a cheeky grin, clearly enjoying your reaction."

    mc "Stop it... someone could see us."

    may "Aww, are you going to be a boring saint now? How lame~"

    narrator "With a playful laugh, May grabs your hand and pulls you out of the café."

    scene bg shopping_center_night
    with fade

    narrator "She drags you into one of the bathroom stalls and locks the door behind her with a mischievous giggle."

    may "Look at that~ All that complaining and your little friend is so happy to see me."

    show expression "images/cg/may/May08.png" as cg_scene
    with dissolve

    narrator "Without wasting any time, May kneels in front of you, pulls down your pants and wraps her soft lips around your hard cock."

    narrator "She gives you an intense, sloppy blowjob, taking you deep into her warm mouth while looking up at you with provocative, teasing eyes."

    may "Mmmph~ Mmmh...!"

    narrator "Her head bobs eagerly, her tongue swirling around the head and sliding along the underside. Wet, lewd sounds echo inside the small stall."

    may "Does it feel good? You can be rougher with me, you know~"

    narrator "She sucks harder, hollowing her cheeks and taking you even deeper. Her eyes water slightly but she keeps that playful sparkle in them."

    show expression "images/cg/may/May08a.png" as cg_scene
    with flash

    narrator "The pleasure quickly becomes overwhelming. You groan and cum hard, filling her mouth with thick ropes."

    may "Mmm~! Mmmh..."

    narrator "She swallows everything with a satisfied hum, then pulls back with a playful pop, licking her lips."

    may "Hehe, I didn't expect to have double dessert today~"

    hide may
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["may"] += 1
    $ affection["may"] = min(100, affection["may"] + 5)
    $ advance_hint("may")
    $ advance_slot(2)

    jump expression "location_" + current_location

# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label may_sixth_encounter:

    scene bg plaza_day
    with fade

    show expression get_char_sprite("may", "default") as may at center
    with dissolve

    may "Ohhh~ Finally my boyfriend decides to show up! The one who never looks for me and never invites me to his house anymore..."

    narrator "May puts on her dramatic, victimized face again, pouting exaggeratedly with the back of her hand on her forehead."

    mc "What is it this time?"

    narrator "She dramatically pulls out a teenage magazine and shows you an article about romantic dinners."

    may "Look at this! I want this~ A romantic dinner made by my boyfriend!"

    mc "You know you can just ask, right? Without all the drama."

    may "But if I don't do drama, how will you know it's really me~?"

    narrator "You sigh but can't help smiling at her antics."

    mc "Fine. I'll make you a romantic dinner."

    may "Yay~! Perfect! Make a Sitrus Miltank Roast and pick me up at the café on the night. I'll bring the dessert~"

    mc "What kind of dessert?"

    may "Be a good boy... and maybe I'll give you more than one dessert~"

    narrator "She gives you a very suggestive wink before walking away happily, swaying her hips."

    hide may
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["may"] += 1
    $ affection["may"] = min(100, affection["may"] + 5)
    $ advance_hint("may")
    $ advance_slot(2)

    jump expression "location_" + current_location

# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label may_seventh_encounter:

    scene bg cafe
    with fade

    show expression get_char_sprite("may", "default") as may at center
    with dissolve

    may "You're late! I was waiting here with the dessert and everything..."

    may "I don't think you're earning your special prize anymore~"

    mc "You said in the night and it's still the night."

    may "Hmph! You better hope that Sitrus Miltank Roast is absolutely delicious, or no prize for you!"

    scene bg home_interior_night
    with fade

    narrator "You take May to your house. The table is beautifully set with candles, flowers, and a perfectly prepared romantic dinner."

    show expression "images/cg/may/May09.png" as cg_scene
    with dissolve

    may "Wow~ You really went all out to make it look nice!"

    mc "Only the best for my special girl."

    narrator "You both enjoy a lovely romantic dinner together. May is clearly delighted and eats with her usual enthusiasm."

    may "This is exactly what I wanted~ The food is delicious!"

    mc "So... did I earn my special prize?"

    may "Honestly? I was going to give it to you anyway... but yes, you definitely earned it."

    narrator "After dinner, you both move to the bedroom. May slowly takes off her clothes, revealing a very cute and sexy maid lingerie set underneath."

    show expression "images/cg/may/May10.png" as cg_scene
    with dissolve

    may "Do you like it? I picked it just for tonight~"

    narrator "May pushes you onto the bed and climbs on top, straddling you with a bright, mischievous smile."

    may "Tonight I'm riding my boyfriend until he can't take it anymore~"

    narrator "She lowers herself onto your cock, taking you inside her warm, wet pussy in one smooth motion. A soft moan escapes her lips as she sinks down completely."

    show expression "images/cg/may/May11.png" as cg_scene
    with dissolve

    may "Ahh~! You feel so good... I love this position."

    narrator "May starts moving her hips energetically, riding you with playful enthusiasm. Her breasts bounce with every rise and fall while she looks down at you with sparkling eyes."

    may "Mmmh~ Do you like watching me like this? Tell me how good it feels!"

    narrator "You grip her hips and thrust up to meet her movements. The room fills with the sound of skin slapping and her cheerful, needy moans."

    may "Ahhn...! Harder~ Don't hold back!"

    narrator "She leans forward, placing her hands on your chest for support as she rides you faster. Her body trembles with pleasure, but she keeps that bright, playful energy."

    may "I'm getting close... Cum with me, okay? I want to feel you deep inside!"

    show expression "images/cg/may/May11a.png" as cg_scene
    with flash

    narrator "May's movements become more frantic. She throws her head back, moaning loudly as she cums hard around you, her walls squeezing tightly."

    narrator "The sight and feeling push you over the edge. You thrust deep and cum inside her, filling her completely while she shivers with pleasure."

    may "Yes~! Fill me up... I love feeling you like this..."

    narrator "Afterwards, May collapses on top of you, breathing heavily but still smiling. She nuzzles against your neck and kisses you softly."

    may "Best... dessert... ever~"

    hide cg_scene
    with dissolve

    narrator "Later, lying together in bed, May cuddles up to you with a satisfied smile."

    may "Best boyfriend ever~"

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["may"] += 1
    $ affection["may"] = min(100, affection["may"] + 5)
    $ advance_hint("may")
    $ advance_slot(2)

    jump expression "location_" + current_location

