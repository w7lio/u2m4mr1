# ============================================================
# POKETOWN, characters/nessa.rpy
# ============================================================

label interact_nessa:

    $ pending = get_pending_delivery("nessa")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            nessa "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            nessa "I'm still waiting for my order..."
            nessa "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("nessa", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["nessa"]
    $ slot = current_slot
    $ prog = character_progress["nessa"]

    if prog == 0:
        jump nessa_meeting
    elif prog == 1 and aff >= 10 and loc == "beach" and slot in [1, 2]:
        jump nessa_first_encounter
    elif prog == 2 and aff >= 20 and stat_physique >= 5 and loc == "beach" and slot in [1, 2]:
        jump nessa_second_encounter
    elif prog == 3 and aff >= 35 and stat_physique >= 10 and loc == "beach" and slot in [1, 2]:
        jump nessa_third_encounter
    elif prog == 4 and aff >= 50 and stat_physique >= 15 and loc == "beach" and slot in [1, 2] and "nessa_swimsuit" in unlocked_skins["nessa"]:
        jump nessa_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_physique >= 20 and loc == "beach" and slot in [1, 2]:
        jump nessa_fifth_encounter
    elif prog == 6 and aff >= 80 and loc == "beach" and slot in [1, 2]:
        jump nessa_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_physique >= 25 and loc == "beach" and slot == 2:
        jump nessa_seventh_encounter
    else:
        jump nessa_contextual_dialogue

label nessa_contextual_dialogue:
    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve
    $ affection["nessa"] = min(100, affection["nessa"] + 3)

    if aff_tier == "stranger":
        if loc == "beach":
            nessa "You picked a good spot. The light here is incredible in the morning."
            nessa "I'm Nessa. I'm here most days."
        else:
            nessa "Hey. I don't think we've met. I'm Nessa."
    elif aff_tier == "acquaintance":
        if loc == "beach":
            nessa "The waves are different today. Can you feel it?"
        elif loc == "cafe":
            nessa "I come here after the beach. Salt air makes me crave something warm."
        else:
            nessa "Hey you. How's Heartwood treating you?"
    elif aff_tier == "friend":
        if loc == "beach":
            nessa "I used to come here alone every morning."
            nessa "I don't anymore."
        elif time_tier == "evening":
            nessa "The beach at night is something else. I'm glad you're seeing it."
        else:
            nessa "You have a calming effect on me. I hope you know that."
    elif aff_tier == "close":
        if loc == "beach":
            nessa "This beach is mine. And I want to share it with you."
        else:
            nessa "You've become part of my routine. The best part."

    hide nessa
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location

# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label nessa_meeting:

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "Hmph. You look like a soft city boy."

    nessa "If you want my attention, get stronger first. I don't waste time with weaklings."

    mc "Wow, straight to the point..."

    nessa "Now leave me alone. I have training to do."

    hide nessa
    with dissolve

    $ character_progress["nessa"] += 1
    $ affection["nessa"] = min(100, affection["nessa"] + 5)
    $ advance_hint("nessa")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label nessa_first_encounter:

    scene bg beach_day
    with fade

    narrator "You spot Nessa training intensely near the water, running sprints along the shore."

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "Hmm... Maybe I judged you too quickly last time. You don't look as soft as I thought."

    nessa "Still... talk is cheap. Want to prove yourself? Let's make a bet."

    mc "I'm listening."

    nessa "Race me to that big rock at the end of the beach. If I win, you buy me dinner tonight. If you somehow win... I'll do whatever you want."

    mc "Whatever I want? That's pretty bold."

    nessa "Hmph! Don't get cocky. There's no way you're beating me."

    narrator "You both take off running across the sand. Nessa is incredibly fast and competitive, easily beating you by a noticeable margin."

    nessa "Hah! What did I tell you? Too slow!"

    nessa "Looks like you're treating me to dinner tonight, loser."

    mc "Alright, you win fair and square. Dinner it is."

    narrator "That evening you take her out for dinner. Despite her tough attitude, the conversation isn't as awkward as you expected. She even smiles once or twice when she thinks you're not looking."

    hide nessa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["nessa"] += 1
    $ affection["nessa"] = min(100, affection["nessa"] + 5)
    $ advance_hint("nessa")
    $ advance_slot(2)

    jump location_beach

# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label nessa_second_encounter:

    scene bg beach_day
    with fade

    narrator "You find Nessa stretching on the beach, preparing for another intense training session."

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "You again? Didn't you get enough humiliation yesterday?"

    mc "Actually, I was hoping for a rematch. Something different this time."

    nessa "Hmph. Fine. How about a swimming race? First one to the buoy and back."

    mc "You're on. And if I win... I want a kiss."

    nessa "W-What?! Don't get ahead of yourself! As if you'd ever beat me in the water."

    nessa "But sure... if by some miracle you win, I'll give you a kiss. Not that it's ever going to happen."

    hide nessa
    with dissolve

    show expression "images/cg/nessa/Nessa01.png" as cg_scene
    with dissolve

    narrator "You both dive into the ocean and swim hard. Nessa is incredibly fast and graceful in the water, easily beating you to the finish."

    nessa "Hah! Too slow again! What did I tell you?"

    mc "Damn... you're really good."

    narrator "Nessa crosses her arms, looking smug. But after a moment, she glances away, her cheeks slightly red."

    nessa "Hmph... since you tried hard, I guess... I'll give you a consolation prize."

    show expression "images/cg/nessa/Nessa02.png" as cg_scene
    with dissolve

    narrator "Before you can say anything, Nessa quickly leans in and gives you a short but firm kiss on the lips."

    nessa "There! Happy now? Don't get the wrong idea! It was just a consolation prize because you lost so pathetically!"

    narrator "Despite her harsh words, she avoids eye contact and her face is noticeably flushed."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "Now stop smiling like an idiot and get lost. I still have training to do."

    hide nessa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["nessa"] += 1
    $ affection["nessa"] = min(100, affection["nessa"] + 5)
    $ advance_hint("nessa")
    $ advance_slot(2)

    jump location_beach

# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label nessa_third_encounter:

    scene bg beach_day
    with fade

    narrator "You find Nessa training in the shallow water. She notices you approaching and raises an eyebrow."

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "What now? Another race?"

    mc "How about something different? A breath-holding contest underwater. First one to come up loses."

    nessa "Hah? That's so childish. What are we, kids?"

    mc "Scared you'll lose?"

    nessa "Tch... Fine! I'll play your stupid game. But the stakes are higher this time."

    nessa "I saw this really nice elegant bikini at the mall the other day. It's expensive. If I win, you buy it for me."

    mc "Deal. And if I win... you show me your tits."

    nessa "Wha?! You pervert! What the hell kind of bet is that?!"

    mc "You're the one who said higher stakes. Scared?"

    nessa "Hmph! As if! Fine! But don't cry when you lose!"

    narrator "You both take a deep breath and dive underwater. The seconds tick by. Both of you push your limits, determined not to lose."

    narrator "After what feels like an eternity, you both surface at almost exactly the same time."

    nessa "Haah... Haah... Damn it! It's a tie!"

    nessa "That doesn't count! We need a second match!"

    mc "Or... we can say both of us win. You get your expensive bikini, and I get what I asked for."

    nessa "Tch... You're such a pain in the ass."

    narrator "She looks away, clearly embarrassed, but you can see the excitement in her eyes. She really wants that bikini."

    nessa "Fine... But only because I want that bikini. Don't you dare look away!"

    hide nessa
    with dissolve

    show expression "images/cg/nessa/Nessa03.png" as cg_scene
    with dissolve

    narrator "Nessa glances around to make sure no one else is nearby, then slowly pulls up the top of her swimsuit in the water, revealing her firm, athletic breasts."

    nessa "There... happy now? Take a good look because this is the last time"

    narrator "Her voice trails off as she notices how intensely you're staring. Her cheeks turn bright red."

    nessa "S-Stop staring like an idiot! Idiot..."

    narrator "Despite her harsh words, she doesn't cover herself immediately, letting you admire her for a few more seconds before quickly pulling her top back up."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "Now go buy me that bikini before I change my mind! And don't tell anyone about this!"

    hide nessa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["nessa"] += 1
    $ affection["nessa"] = min(100, affection["nessa"] + 5)
    $ advance_hint("nessa")
    $ advance_slot(2)

    jump location_beach


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label nessa_fourth_encounter:

    scene bg beach_day
    with fade

    narrator "You find Nessa on the beach wearing the elegant new bikini you bought her. It looks amazing on her athletic body."

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "So? You bought it, so it's only fair you get to see how it looks on me."

    nessa "What do you think? It suits me, right?"

    mc "You look incredible."

    nessa "Hmph, obviously. Since I basically won last time by getting this bikini, I'm still on a winning streak."

    nessa "Let's do another race. Same as the first one, but farther this time. From here to the distant palm tree and back."

    mc "You're on."

    narrator "Both of you take off running at full speed across the hot sand. This time you push yourself harder than ever and manage to win by a narrow margin."

    nessa "Hah... Hah... No way...!"

    narrator "Nessa stops, hands on her knees, breathing heavily and looking clearly annoyed."

    nessa "Tch... Fine. You won this time. What do you want?"

    mc "I want you to give me a handjob."

    nessa "Wha...?! Are you serious?! You're really pushing it now!"

    nessa "Just because you won once doesn't mean you can ask for whatever perverted thing you want!"

    narrator "You pull down your swimming trunks slightly, revealing your fully erect cock."

    nessa "...!"

    narrator "Her eyes widen as she stares at it. Her face turns bright red."

    nessa "Y-You idiot... Getting hard just from racing me..."

    nessa "Hmph... Fine. But it's also my fault for wearing something this sexy. Don't get the wrong idea!"

    hide nessa
    with dissolve

    show expression "images/cg/nessa/Nessa04.png" as cg_scene
    with dissolve

    narrator "Nessa kneels in front of you in the shallow water, still wearing her new bikini. The waves gently lap around her thighs as she wraps her soft, warm hand around your hard cock."

    nessa "How's this...? Not bad, right?"

    narrator "She starts stroking you with firm, steady movements. Her athletic hand moves with confidence, twisting slightly at the head on every upstroke."

    nessa "Tch... It's so hard... and throbbing like crazy in my hand."

    narrator "Despite her tsundere tone, her breathing grows heavier and her eyes stay fixed on your cock. She pumps faster, her grip tightening as she gets more into it."

    nessa "Hah... Look at you... getting this excited just from my hand..."

    show expression "images/cg/nessa/Nessa04a.png" as cg_scene
    with flash

    narrator "The pleasure quickly builds. You groan as you reach your limit. Thick ropes of cum shoot out, landing on her hand, forearm, and across her bikini top."

    nessa "Whoa...! You came so much... What a mess..."

    narrator "Nessa looks at the cum dripping down her skin, a faint blush on her cheeks. She doesn't pull away immediately, still slowly stroking you through the aftershocks."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "There... satisfied now?"

    nessa "Don't think this means anything. It was just a fluke. Next time I won't lose again."

    hide nessa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["nessa"] += 1
    $ affection["nessa"] = min(100, affection["nessa"] + 5)
    $ advance_hint("nessa")
    $ advance_slot(2)

    jump location_beach

# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label nessa_fifth_encounter:

    scene bg beach_day
    with fade

    narrator "You arrive at the beach and spot Nessa training as usual. However, something seems off. She doesn't look focused on her exercises. It almost looks like she's been waiting for you."

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "There you are. Finally."

    mc "Were you waiting for me?"

    nessa "H-Huh?! Don't flatter yourself! I was just... training!"

    nessa "Anyway! You only won last time because it was on land. In the water, I'm still the best. Let's settle this with a swimming race."

    mc "You're on."

    narrator "Both of you dive into the sea and swim with everything you have. Nessa is incredibly fast and agile in the water, clearly in her element. She wins by a solid margin."

    nessa "Hah! See?! I told you! In the water, you don't stand a chance against me!"

    mc "Fair enough... You win. What do you want as your prize?"

    nessa "..."

    narrator "Nessa looks away, her cheeks turning pink. She fidgets slightly before speaking."

    nessa "I want... to do it. Right here. In the sea."

    mc "Wait... seriously?"

    nessa "W-What?! Don't look so surprised! You're always the perverted one asking for dirty things! I've never asked for anything for myself until now!"

    nessa "It's only fair that I get some pleasure too, idiot!"

    hide nessa
    with dissolve

    show expression "images/cg/nessa/Nessa05.png" as cg_scene
    with dissolve

    narrator "You both move to a more private area in the water. Nessa wraps her arms around your neck and her strong legs around your waist, holding onto you tightly."

    narrator "You remove her bikini bottom and slowly push inside her while floating in the sea. The water makes everything feel smooth and weightless."

    nessa "Mmh...! Finally... Don't be gentle with me."

    narrator "You thrust into her with deep, steady movements. The waves rock your bodies together as Nessa's competitive attitude starts to melt away."

    nessa "Ahh...! Harder...! Don't hold back... I can take it!"

    narrator "Her athletic body presses tightly against yours. You feel every curve and muscle as you drive deeper, the cool water contrasting with her warm, tight pussy."

    nessa "Hah...! Yes... Just like that...!"

    narrator "Nessa moans softly against your ear, her nails digging into your shoulders. The sensation of the sea and her body makes everything incredibly intense."

    narrator "After a long, passionate session, you both reach climax together. Nessa clings to you tightly, trembling as her orgasm hits her hard."

    nessa "I'm... cumming...!"

    narrator "You cum deep inside her at the same time, holding her close while the waves continue to lap around you."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "Haaah... Haaah... Not bad..."

    nessa "But don't get too cocky. Get ready... because I'm planning to keep winning from now on."

    hide nessa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["nessa"] += 1
    $ affection["nessa"] = min(100, affection["nessa"] + 5)
    $ advance_hint("nessa")
    $ advance_slot(2)

    jump location_beach

# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label nessa_sixth_encounter:

    scene bg beach_day
    with fade

    narrator "You head to the beach looking for Nessa, eager for another challenge. Instead, you find her relaxing under a large umbrella, lying on a towel."

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    mc "Hey Nessa! Ready for today's bet?"

    nessa "Hmph... Not today."

    mc "What? Why not?"

    nessa "It's my rest day. If I train every single day without resting, I'll end up hurting my muscles. Even athletes need breaks, idiot."

    nessa "If you wanted to compete so badly, you should have come yesterday. Now it's too late."

    mc "So... I should just leave then?"

    nessa "Yeah... you can go if you want. We'll do it another day."

    narrator "Despite her words, you notice the way she glances at you. She doesn't really want you to leave."

    mc "Actually... mind if I stay and keep you company?"

    nessa "...Do whatever you want."

    narrator "You spend the rest of the afternoon with her. You talk, joke around, and eventually offer to give her a massage."

    hide nessa
    with dissolve

    show expression "images/cg/nessa/Nessa06.png" as cg_scene
    with dissolve

    narrator "Nessa lies face down on the towel as you massage her shoulders, back, and legs. Her body is incredibly toned from all her training. At first she stays quiet, but slowly she begins to relax under your hands."

    nessa "Mmm... Not bad... A little harder on the shoulders..."

    narrator "For once, she doesn't complain or act tsundere. She simply enjoys the moment."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "Hmph... I guess spending the day with you wasn't that bad."

    nessa "Don't think this means I'm going easy on you next time though."

    narrator "As the sun begins to set, you both leave the beach together. The atmosphere between you feels noticeably warmer and closer than before."

    hide nessa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["nessa"] += 1
    $ affection["nessa"] = min(100, affection["nessa"] + 5)
    $ advance_hint("nessa")
    $ advance_slot(2)

    jump location_beach

# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label nessa_seventh_encounter:

    scene bg beach_day
    with fade

    narrator "You're surprised when Nessa comes looking for you this time. She looks more determined than ever."

    show expression get_char_sprite("nessa", "default") as nessa at center
    with dissolve

    nessa "There you are. Ready for one more race? This time I'm not holding back."

    mc "Bring it on."

    nessa "Swimming race. Same buoy as always. No excuses."

    narrator "Both of you dive into the ocean and swim with everything you have. It's incredibly close. You push your body to the absolute limit and, by a very narrow margin, you touch the buoy first."

    nessa "Hah... Hah... Damn it..."

    narrator "Nessa looks genuinely shocked for a moment, then crosses her arms with a pout."

    nessa "Tch... Fine. You won. I accept my defeat."

    mc "You let me win, didn't you?"

    nessa "H-Huh?! What are you talking about?! I would never!"

    mc "Then if I really won... I want to fuck your ass."

    nessa "Wha...?! Y-You pervert! How can you ask for something like that so casually?!"

    mc "If you didn't want to do what I ask, why did you let me win?"

    nessa "I-I didn't let you win! Shut up!"

    narrator "Nessa's face turns bright red. She looks away, clearly embarrassed."

    mc "Then pay up. Be honest with me for once and tell me how you really feel."

    nessa "..."

    narrator "After a long silence, Nessa suddenly grabs your face and kisses you passionately. It's not a quick tsundere kiss, it's deep, needy, and full of all the feelings she's been holding back."

    nessa "Idiot... You already know how I feel."

    hide nessa
    with dissolve

    scene bg home_interior_night
    with fade

    narrator "That same night, you invite Nessa to your farm. You prepare a romantic dinner under the stars. For the first time, she drops most of her tough act and enjoys the evening with you."

    show expression "images/cg/nessa/Nessa07.png" as cg_scene
    with dissolve

    narrator "The night ends in your bedroom. Nessa is more passionate and honest than ever before. You start slow, savoring every sensation as desire gradually takes over."

    narrator "Her athletic body moves perfectly with yours, hips rolling to meet every thrust. She moans your name without holding back."

    nessa "Ahh...! Idiot... Don't stop...!"

    narrator "You pick up the pace, thrusting deeper and harder. Nessa's strong legs wrap around you, pulling you closer as her nails dig into your back."

    nessa "Hah...! Right there... Don't you dare slow down...!"

    narrator "The intensity builds until you both reach a powerful climax together. Nessa arches her back, crying out as her body trembles beneath you."

    nessa "I'm... cumming...!"

    show expression "images/cg/nessa/Nessa07a.png" as cg_scene
    with flash

    narrator "You finish deep inside her at the same time, holding her tightly as waves of pleasure wash over both of you."

    narrator "Afterwards, Nessa rests her head on your chest, breathing softly. Her usual confident mask is gone, replaced by a rare, vulnerable expression."

    nessa "Hmph... This doesn't mean I'm going easy on you from now on."

    nessa "...But maybe... I wouldn't mind losing to you sometimes."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["nessa"] += 1
    $ affection["nessa"] = min(100, affection["nessa"] + 5)
    $ advance_hint("nessa")
    $ advance_slot(3)

    jump location_beach

