# ============================================================
# POKETOWN, characters/iris.rpy
# ============================================================

label interact_iris:

    $ pending = get_pending_delivery("iris")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            iris "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            iris "I'm still waiting for my order..."
            iris "I need [pending['item_name']] x[pending['quantity']]."
        
    $ ctx = get_interaction_context("iris", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["iris"]
    $ slot = current_slot
    $ prog = character_progress["iris"]

    if prog == 0 and loc == "forest":
        jump iris_meeting
    elif prog == 1 and aff >= 10 and loc == "forest" and slot in [0, 1, 2]:
        jump iris_first_encounter
    elif prog == 2 and aff >= 20 and stat_physique >= 10 and loc == "forest" and slot in [0, 1, 2]:
        jump iris_second_encounter
    elif prog == 3 and aff >= 35 and loc == "forest" and slot in [0, 1, 2]:
        jump iris_third_encounter 
    elif prog == 4 and aff >= 50 and stat_physique >= 20 and loc == "forest" and slot in [0, 1, 2]:
        jump iris_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_charisma >= 20 and loc == "forest" and slot in [2]:
        jump iris_fifth_encounter
    elif prog == 6 and aff >= 80 and stat_charisma >= 25 and loc == "forest" and slot in [0, 1, 2]:
        jump iris_sixth_encounter
    elif prog == 7 and aff >= 95 and loc == "forest" and slot in [0, 1, 2]:
        jump iris_seventh_encounter
    else:
        jump iris_contextual_dialogue

label iris_contextual_dialogue:
    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve
    $ affection["iris"] = min(100, affection["iris"] + 3)

    if aff_tier == "stranger":
        if loc == "forest":
            iris "You move too loudly. The forest hears everything."
            iris "I'm Iris. I'm here every day. You'll learn to spot me."
        else:
            iris "You're new. I can tell by the way you look at things."
            iris "I'm Iris."
    elif aff_tier == "acquaintance":
        if loc == "forest":
            iris "You're getting quieter. The forest is teaching you."
        elif loc == "plaza":
            iris "I only come here when I need to remember what people are like."
            iris "Usually I prefer trees."
        else:
            iris "You're more interesting than most people here. That's not nothing."
    elif aff_tier == "friend":
        if loc == "forest":
            iris "There are parts of this forest I've never shown anyone."
            iris "I'm considering it. With you."
        elif time_tier == "night":
            iris "The forest at night is mine. You're one of the few I'd share it with."
        else:
            iris "I don't trust easily. I hope you understand what it means that I trust you."
    elif aff_tier == "close":
        if loc == "forest":
            iris "I used to think I preferred being alone out here."
            iris "I was wrong."
        else:
            iris "You're woven into my days now. I don't know when that happened."
            iris "I don't want to undo it."

    hide iris
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location

# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label iris_meeting:

    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve

    iris "Oh? A new face."

    iris "Most people from town don’t like coming this deep into the forest. I already like you better than most of them."

    hide iris
    with dissolve

    $ affection["iris"] = min(100, affection["iris"] + 5)
    $ character_progress["iris"] += 1
    $ advance_hint("iris")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label iris_first_encounter:

    scene bg forest_day
    with fade

    narrator "While exploring the forest, you suddenly hear a voice from above."

    iris "Boo!"

    show expression "images/cg/iris/iris01.png" as cg_scene
    with dissolve

    narrator "Iris is hanging upside down from a tree branch, grinning at you."

    mc "What the- How can you jump out at me like that out of nowhere?!"

    iris "Seriously? You come into a forest and get scared just because something jumps at you? What would you do if it was a wild animal instead of me?"

    mc "In all the time I’ve been living in this town, the only thing that’s attacked me out of nowhere is you."

    narrator "Iris laughs, still hanging upside down."

    iris "Fair enough. Still, I know this forest pretty well. A lot of creatures live here. Either you have a surprisingly good connection with them... or you’re lying."

    iris "I can tell because I get along really well with the animals around here."

    mc "Yeah, well... so do I."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve

    narrator "Iris flips down from the branch and lands lightly on her feet. She looks at you with a slightly strange expression."

    iris "That’s weird."

    iris "And that’s coming from me. I’m the weird one."

    hide iris
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["iris"] += 1
    $ affection["iris"] = min(100, affection["iris"] + 5)
    $ advance_hint("iris")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label iris_second_encounter:

    scene bg forest_day
    with fade

    narrator "While walking through the forest, you suddenly feel a weight slam into your back."

    iris "Attaaaack!"

    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve

    narrator "Iris jumps onto you from behind and knocks you to the ground. She ends up sitting on your back, looking down at you with a smug expression."

    iris "Bad reflexes. You keep coming into my forest completely unprepared."

    mc "Why do you keep attacking me?!"

    iris "I just want to know how you’re doing physically. What if something actually happens to you out here?"

    mc "So you want to test me? Fine. Let’s play, girl."

    iris "Now that’s more like it."

    iris "First one to reach the top of that hill wins."
    
    hide iris
    with dissolve

    narrator "The moment she finishes speaking, Iris leaps up into the trees and starts swinging and jumping between the branches at impressive speed. You scramble to your feet and start running after her."

    show expression "images/cg/iris/iris02.png" as cg_scene
    with dissolve

    narrator "After a long, exhausting climb, you finally reach the top of the hill, completely out of breath. Iris is already there, sitting comfortably on a rock as if she’d been waiting for a while."

    iris "You finally made it."

    mc "I don’t even know why I agreed to this."

    iris "To have fun, obviously."

    mc "I didn’t do this to entertain you."

    iris "Well, for something you claim you didn’t do for fun... you sure managed to entertain me."

    narrator "She gives you a wide, cheeky grin before hopping back into the trees and disappearing with a loud laugh."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["iris"] += 1
    $ affection["iris"] = min(100, affection["iris"] + 5)
    $ advance_hint("iris")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label iris_third_encounter:

    scene bg forest_day
    with fade

    narrator "While walking through the forest, you suddenly stop when you notice someone in the river. It’s Iris... completely naked, calmly bathing in the water."

    show expression "images/cg/iris/iris03.png" as cg_scene
    with dissolve

    mc "So... are you like a homeless person or something?"

    iris "No. I just like being in the forest. I have my own apartment in town like everyone else."

    mc "So you just come out here naked to bathe in the river?"

    iris "Do you have a problem with that?"

    mc "Yes. You’re completely naked. Anyone could see you. In fact, I’m looking at you right now."

    iris "That sounds like your problem, not mine. I’m just like this. I don’t care if a weirdo like you stares at me."

    mc "You’re the weirdo who likes being stared at by weirdos like me."

    narrator "Iris suddenly puts on an exaggeratedly sad expression and speaks in a soft, fake-tender voice."

    show expression "images/cg/iris/iris04.png" as cg_scene
    with dissolve

    iris "You’re right... How didn’t I realize? A defenseless girl like me, out here all alone without any clothes... You should help me."

    narrator "She extends her hand toward you with a pitiful look."

    mc "Alright, fine. Let me help you."

    narrator "You reach out to take her hand. The moment your fingers touch, Iris yanks hard with surprising strength and pulls you straight into the river."

    iris "Hahahahaha! Look who’s the weirdo bathing with clothes on now!"
    
    hide cg_scene
    with dissolve
    
    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve

    narrator "She laughs loudly while you scramble in the water. After a moment she calmly gets out of the river, dries herself off a bit, and puts her clothes back on. Then she sits nearby while you try to dry yourself."

    iris "Come on, sit down. You look ridiculous."

    hide iris
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["iris"] += 1
    $ affection["iris"] = min(100, affection["iris"] + 5)
    $ advance_hint("iris")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label iris_fourth_encounter:

    scene bg forest_day
    with fade

    narrator "While walking through the forest, you spot Iris sitting on a thick tree branch, looking distracted and clearly bored."

    show expression "images/cg/iris/iris05.png" as cg_scene
    with dissolve

    narrator "Remembering all the times she’s jumped you, you pick up a small rock and toss it lightly at her."

    iris "Ow,! What the hell was that?"

    mc "Just testing you. You don’t seem very fit to be in the forest right now."

    iris "Tch... Sorry, I’m not really in the mood today."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve

    narrator "She jumps down from the branch and lands in front of you. After a short pause, a mischievous smile appears on her face."

    iris "Although... now that I think about it, you can help me with that."

    narrator "Before you can answer, Iris steps closer and starts touching you openly. Her hands slide over your chest, then lower, teasing you with clear intent until she feels you getting hard."

    iris "Heh... Looks like you’re already in the mood."

    mc "You’re unbelievable."

    iris "And you’re hard. So are we doing this or what?"

    hide iris
    with dissolve
    
    show expression "images/cg/iris/iris06.png" as cg_scene
    with dissolve

    narrator "You end up sitting on the ground with your back against a tree. Iris turns around and sits on your lap, facing away from you, then sinks down onto your cock with a satisfied breath."

    iris "Ahh... That’s better."

    narrator "She starts moving her hips at her own pace, riding you reverse with confidence. Her hands rest on your thighs for support as she looks over her shoulder with a playful, slightly flushed expression."

    iris "You’re not allowed to finish before me, got it?"

    narrator "She keeps riding you steadily, sometimes slowing down just to tease you, sometimes going faster when she wants more. The forest stays quiet around you except for her soft, unrestrained moans."

    iris "Hah... Just stay still and let me use you."
        
    show expression "images/cg/iris/iris06a.png" as cg_scene
    with flash

    narrator "After a while her movements become more urgent. She cums first, tightening around you with a sharp breath, and the feeling pulls you over the edge right after her."

    iris "Haa... Not bad."

    narrator "She stays on top of you for a moment longer before casually getting up and adjusting her clothes as if nothing special happened."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["iris"] += 1
    $ affection["iris"] = min(100, affection["iris"] + 5)
    $ advance_hint("iris")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label iris_fifth_encounter:

    scene bg forest_day
    with fade

    narrator "Iris asked you to meet her because she wanted to show you her special place. She didn’t explain what it was, and instead made you climb a long path up the mountain."

    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve

    narrator "After a while, you finally reach a small natural spring nestled between the rocks. Warm water gently flows into a clear pool."

    iris "Tadah! What do you think?"

    mc "A bunch of stagnant water?"

    iris "Nooo, it’s not stagnant. The water’s flowing. It’s a natural spring, and it comes out warm. It’s basically my personal hot spring."
    
    hide iris
    with dissolve

    show expression "images/cg/iris/iris07.png" as cg_scene
    with dissolve

    narrator "Without any hesitation, Iris starts taking off her clothes and jumps straight into the water."

    iris "Come on, get in. The water’s really nice."

    narrator "You start undressing until you’re left in your underwear and step closer to the edge. Just as you’re about to get in, Iris interrupts you."

    iris "Boooo. You’re seriously getting in with clothes on?"

    mc "I don’t know... I just don’t like being seen naked."

    iris "What kind of nonsense is that? We’ve already had sex and now you’re embarrassed to be naked?"

    mc "Yeah, well... you’re right."

    narrator "You finish taking off the rest of your clothes and get into the warm water."

    iris "Hehehe... there’s your cute little friend."

    narrator "You both relax in the spring for a while. Iris stays very close to you the entire time, brushing against your body and teasing you without any subtlety. Before long, you end up fully hard."

    iris "Aren’t you embarrassed to have an erection right now?"

    mc "Me? You’re the one who should be embarrassed. You keep provoking me and then act like you don’t know what’s happening."

    iris "Me? Fine then. If it’s all my fault, I’ll help you calm it down."
    
    show expression "images/cg/iris/iris08.png" as cg_scene
    with dissolve

    narrator "She gives you a wicked, victorious little laugh, as if she had been waiting for this exact moment. Then she sinks lower in the water, takes your cock into her mouth, and starts sucking you right there in the spring."

    narrator "Iris doesn’t hold back at all. She moves her head with clear confidence, taking you deep while using her tongue along the underside. Water drips from her wet hair as she looks up at you from below."

    iris "Hah... Just relax. I’ll finish you off."

    narrator "She keeps a steady, skilled rhythm, occasionally pulling back to lick the head before sinking down again. The warm spring water and her tight, wet mouth make it hard to last."
    
    show expression "images/cg/iris/iris08a.png" as cg_scene
    with flash

    narrator "It doesn’t take long before the pressure builds. You groan as you finish hard in her mouth, thick pulses filling her throat."

    iris "Mmmh...!"

    narrator "Iris swallows without hesitation, then slowly pulls away with a satisfied hum, licking her lips."

    iris "There. Better?"

    narrator "Afterward, the two of you get out, dry off, put your clothes back on, and leave the spring as if nothing particularly special had happened."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["iris"] += 1
    $ affection["iris"] = min(100, affection["iris"] + 5)
    $ advance_hint("iris")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label iris_sixth_encounter:

    scene bg forest_day
    with fade

    narrator "While walking through a quieter part of the forest, you suddenly hear footsteps approaching with clear purpose. Iris appears from between the trees, looking straight at you."

    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve

    iris "There you are. I was getting bored."

    mc "So you came looking for me?"

    iris "Obviously. Come on."

    narrator "Without giving much explanation, she grabs your wrist and pulls you deeper into the forest until you reach a more secluded clearing surrounded by thick trees."

    iris "This should be good enough."

    narrator "Iris doesn’t waste time. She pushes you back against a tree and starts kissing you roughly, her hands already working on your clothes with familiar confidence."

    iris "I’m in the mood for something longer today. Try to keep up."
    
    hide iris
    with dissolve

    show expression "images/cg/iris/iris09.png" as cg_scene
    with dissolve

    narrator "She gets you hard quickly and then climbs onto your lap, sinking down onto your cock with a satisfied breath. This time she rides you slower at first, taking her time and clearly enjoying the control."

    iris "Ahh... Yeah. Just like that."

    narrator "Iris moves with more intensity than before. She changes pace whenever she wants, sometimes grinding deep and slow, sometimes bouncing harder while holding onto your shoulders. Her soft, unrestrained moans fill the quiet clearing."

    iris "You’re not allowed to finish until I say so."

    narrator "She keeps going for a long while, clearly more comfortable and demanding than the previous times. When she finally gets close, she speeds up and cums hard around you, her body trembling as she lets out a sharp moan."

    show expression "images/cg/iris/iris09a.png" as cg_scene
    with flash

    narrator "Only then does she allow you to finish. The moment you cum inside her, she stays on top of you, catching her breath with a small, satisfied smirk."

    iris "Not bad. You lasted longer than I expected."

    narrator "After a moment she casually gets off you, adjusts her clothes, and stretches as if she had just finished a light workout."

    iris "See you around."

    narrator "She walks off into the trees with the same easy confidence as always, leaving you still leaning against the tree."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["iris"] += 1
    $ affection["iris"] = min(100, affection["iris"] + 5)
    $ advance_hint("iris")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label iris_seventh_encounter:

    scene bg forest_day
    with fade
    
    show expression "images/cg/iris/iris10.png" as cg_scene
    with dissolve

    narrator "While exploring a more remote part of the forest, you suddenly stop when you notice Iris. She’s sitting against a tree with her hand between her legs, touching herself without much care for being seen."

    narrator "You hesitate for a moment, wondering if you should interrupt her... but in the end you do."

    mc "Bored?"

    iris "Yeah. Honestly, I’ve been really horny lately. Mostly your fault. I can’t stop thinking about the other times."

    mc "Looks like I made the weird forest girl fall in love."

    iris "Ha. In love? I didn’t fall in love with you. I’m a free girl. I take what I want and do what I want."

    iris "It’s just that I’ve been thinking a lot about what we’ve done... and there’s something I’ve always wanted to try. Let’s just say I think you’re the right person for it."

    mc "Alright, let’s hear what weird thing you’re going to ask for this time."

    iris "You say that like you’re not going to do it anyway. So far you’ve done everything I’ve asked."

    iris "What I want is for us to do it from behind."

    show expression "images/cg/iris/iris11.png" as cg_scene
    with dissolve

    narrator "After a short pause, Iris doesn’t wait for a long answer. She pushes you down to sit against the tree, straddles your lap facing you, and guides you into her ass slowly."

    iris "Ahh... Okay, that’s... tighter than I expected."

    narrator "She starts riding you carefully at first, getting used to the feeling. Once she adjusts, she moves with more confidence, using the same free and demanding pace she always has."

    iris "Don’t you dare finish before me."

    show expression "images/cg/iris/iris11a.png" as cg_scene
    with flash

    narrator "Iris keeps moving on top of you until she finally cums, her body tensing as she lets out a sharp breath. Shortly after, you finish inside her as well."

    narrator "When it’s over, she gets up without much ceremony and starts fixing her clothes."
    
    hide cg_scene
    with dissolve
    
    show expression get_char_sprite("iris", "default") as iris at center
    with dissolve

    iris "Well... at least I got it out of my system. But it wasn’t that big of a deal. I think I still prefer normal sex."

    mc "Are you asking for a second round?"

    iris "No. But now that you mention it... you’re going to have to give it to me."

    hide iris
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["iris"] += 1
    $ affection["iris"] = min(100, affection["iris"] + 5)
    $ advance_hint("iris")
    $ advance_slot(2)

    jump expression "location_" + current_location

