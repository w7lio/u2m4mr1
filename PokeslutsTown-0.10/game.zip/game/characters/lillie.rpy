# ============================================================
# POKETOWN, characters/lillie.rpy
# ============================================================

label interact_lillie:

    $ pending = get_pending_delivery("lillie")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            lillie "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            lillie "I'm still waiting for my order..."
            lillie "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("lillie", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["lillie"]
    $ slot = current_slot
    $ prog = character_progress["lillie"]

    if prog == 0:
        jump lillie_meeting
    elif prog == 1 and aff >= 10 and loc == "library" and slot in [0, 1, 2]:
        jump lillie_first_encounter
    elif prog == 2 and aff >= 20 and stat_charisma >= 10 and loc == "plaza" and slot in [0, 1]:
        jump lillie_second_encounter
    elif prog == 3 and aff >= 35 and stat_charisma >= 15 and loc == "library" and slot in [0, 1, 2]:
        jump lillie_third_encounter
    elif prog == 4 and aff >= 50 and stat_charisma >= 20 and loc == "cafe" and slot in [3, 4]:
        jump lillie_fourth_encounter
    elif prog == 5 and aff >= 65 and loc == "cafe" and slot in [3, 4]:
        jump lillie_fifth_encounter
    elif prog == 6 and aff >= 80 and stat_charisma >= 25 and loc == "cafe" and slot in [3, 4]:
        jump lillie_sixth_encounter
    elif prog == 7 and aff >= 95 and loc == "cafe" and slot in [3, 4]:
        jump lillie_seventh_encounter
    else:
        jump lillie_contextual_dialogue

label lillie_contextual_dialogue:
    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve
    $ affection["lillie"] = min(100, affection["lillie"] + 3)

    if aff_tier == "stranger":
        if loc == "library":
            lillie "Oh! Sorry, I didn't notice you there."
            lillie "I'm Lillie. I come here to... get some space. From home."
        else:
            lillie "Hi. I'm Lillie. You're new here, aren't you?"
            lillie "Heartwood is small but it grows on you."
    elif aff_tier == "acquaintance":
        if loc == "library":
            lillie "I feel safer in here than most places. Isn't that strange?"
        elif loc == "plaza":
            lillie "Mother doesn't know I come here. She'd want to supervise."
        else:
            lillie "I'm glad to see a familiar face."
    elif aff_tier == "friend":
        if loc == "library":
            lillie "I've been saving this book. I thought we could read it at the same time."
            lillie "Is that too much?"
        else:
            lillie "You make me feel like I don't have to explain myself. I appreciate that more than you know."
    elif aff_tier == "close":
        if loc == "library":
            lillie "I used to come here to hide. Now I come here hoping to find you."
        else:
            lillie "I've spent most of my life doing what others expected."
            lillie "With you I feel like I can just... be."

    hide lillie
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location

# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label lillie_meeting:

    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve

    lillie "Oh, hi, you must be new around here, I don't know you, although I should probably ask my mother first if it's okay to talk to you"

    hide lillie
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ affection["lillie"] = min(100, affection["lillie"] + 5)
    $ character_progress["lillie"] += 1
    $ advance_hint("lillie")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label lillie_first_encounter:

    scene bg library_day
    with fade

    narrator "The library is quiet this morning. Sunlight filters through tall windows. A girl with long blonde hair sits alone, staring at an open book without really reading it. She seems lost in her thoughts."

    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve

    mc "Hey... are you okay? You look a little lost."

    lillie "Ah...! Oh, um... hello. I didn't notice you there."

    narrator "Lillie straightens up quickly, startled. Her fingers fidget nervously with the corner of the book as she avoids your gaze."

    lillie "My mother gave me the whole day off today. She said I should do whatever I want in town... but I don't really know what to do. I don't usually go many places."

    mc "So you're just sitting here trying to figure it out?"

    lillie "Yeah... It's kind of pathetic, isn't it? Even when I have free time, I don't know how to enjoy it."

    mc "Not at all. Want some company? I was planning to read here anyway. We can just sit together if you'd like."

    lillie "R-really? You wouldn't mind?"

    narrator "Lillie's eyes widen in surprise, but a small, shy smile slowly appears on her lips."

    lillie "Thank you... I'd like that."

    narrator "You sit beside her. At first she's quiet, but little by little she begins to relax. She shyly shows you interesting passages in her book and asks soft questions about the town. For the first time in a long while, she doesn't feel so alone."

    hide lillie
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lillie"] += 1
    $ affection["lillie"] = min(100, affection["lillie"] + 5)
    $ advance_hint("lillie")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label lillie_second_encounter:

    scene bg plaza_day
    with fade

    narrator "You arrive at the plaza as agreed. Lillie is already waiting on a bench, holding a cute picnic basket on her lap. A pretty fabric bow decorates the handle."

    show expression "images/cg/lillie/Lillie01.png" as cg_scene
    with dissolve

    lillie "You really came... I'm glad. I brought some snacks. I thought we could sit together for a while."

    mc "That's really sweet of you. I like the bow on the basket. It's very cute."

    lillie "Oh, this? Thank you... I made it myself. I really like tying bows and knots. It helps me calm down when my thoughts get too loud."

    mc "You know, that kind of bow would look really good in your hair."

    lillie "E-eh?! In my hair...? W-what do you mean?"

    narrator "Lillie's cheeks turn bright red. She looks away quickly, fidgeting with the edge of her dress."

    mc "Just that it would suit you. You're always so neat and pretty."

    lillie "I... I don't know about that..."

    narrator "She takes a deep breath, trying to compose herself."

    lillie "I work at the cafe with my mother. She's very strict. She decides almost everything... what I wear, where I go, what I do. I've tried to be more independent, but it's really difficult for me."

    mc "That sounds exhausting."

    lillie "It is... Sometimes I just want to do something without worrying if it's 'right' or 'proper'. But I always end up feeling lost."

    narrator "Lillie gently touches the bow on the basket. There's quiet sadness in her voice, but also a tiny spark of hope."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lillie"] += 1
    $ affection["lillie"] = min(100, affection["lillie"] + 5)
    $ advance_hint("lillie")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label lillie_third_encounter:

    scene bg library_day
    with fade

    narrator "You return to the library the next day. You find Lillie in the same quiet corner, looking restless and anxious again. However, today she has a cute fabric bow tied in her hair."

    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve

    mc "Hey, Lillie."

    lillie "Ah...! You came back."

    narrator "The moment she sees you, her shoulders relax noticeably. It's clear your presence calms her down."

    mc "That bow looks really cute on you."

    lillie "T-thank you... I made it this morning. I thought it might help me feel a little better."

    mc "It does look good... but I think it would look even better a bit lower."

    narrator "Before she can react, you gently reach out and slide the bow down from her hair to around her neck. You pull lightly on the string, tightening it just enough to turn it into a soft collar."

    hide lillie
    with dissolve

    show expression "images/cg/lillie/Lillie02.png" as cg_scene
    with dissolve

    lillie "E-eh?! W-what are you...?"

    narrator "Lillie's face turns bright red. She freezes, not knowing what to say, her hands lightly touching the bow now around her neck."

    mc "See? It suits you even more like this."

    narrator "You let out a soft, amused laugh at her reaction. Despite her shock, you notice her breathing has become slightly heavier and her eyes have a strange sparkle."

    mc "Don't worry. If you have trouble making your own decisions... let me make them for you."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve

    narrator "Lillie looks at you, completely flustered. After a long moment of silence, she gives a tiny, extremely embarrassed nod."

    narrator "You pull her closer and kiss her passionately. Lillie melts into the kiss, her hands clutching your shirt."

    mc "I have plans for you, Lillie. If you want them."

    hide lillie
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lillie"] += 1
    $ affection["lillie"] = min(100, affection["lillie"] + 5)
    $ advance_hint("lillie")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label lillie_fourth_encounter:

    scene bg cafe
    with fade

    narrator "You arrive at the cafe in the afternoon, looking forward to spending time with Lillie. As soon as you enter, you find her behind the counter looking upset."

    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve

    lillie "Ah... you came. I'm really sorry... My mother cancelled my day off at the last minute. She said the cafe needed me."

    mc "That's unfair. You were really excited about today."

    lillie "It's okay... I'm used to it. Do you want to stay for a bit anyway? It's pretty empty right now."

    mc "Of course. I'm not leaving you like this."

    narrator "You keep her company behind the counter. With the cafe almost empty, you both start getting closer. Soon you're stealing soft kisses whenever no one is looking."

    lillie "Mmm... This is dangerous... but I like it."

    narrator "Just as things begin to heat up, the bell above the door rings. A customer walks in. You both pull away quickly, hearts pounding."

    narrator "After serving the customer, he sits at a table near the window and shows no sign of leaving soon."

    mc "He's not going anywhere... but I can't wait much longer."

    lillie "W-what? Here? But... someone could see us..."

    mc "Behind the counter. No one will notice if you're quick. Come on, Lillie."

    narrator "Lillie hesitates, her face burning bright red. After a nervous moment, she slowly kneels behind the counter, hidden from view."

    hide lillie
    with dissolve

    show expression "images/cg/lillie/Lillie03.png" as cg_scene
    with dissolve

    narrator "With trembling hands, Lillie pulls down your pants. Her eyes widen slightly as she frees your cock, only inches from her face."

    narrator "She glances nervously toward the customer sitting just a few meters away, then looks back up at you with flushed cheeks."

    lillie "Mmmh... We have to be really quiet... Please..."

    narrator "She leans in and takes you into her warm, soft mouth. At first her movements are shy and hesitant, her lips wrapping tightly around you."

    narrator "The risk of being caught seems to make her more eager. She starts sucking a little faster, her tongue swirling around the head with surprising dedication."

    lillie "Mmmph... hah... Does it feel good...?"

    narrator "Her warm breath and soft moans vibrate around you. She bobs her head gently, trying to take more of you while keeping her noises quiet. Her eyes water slightly from the effort, but she doesn't stop."

    narrator "Every time the customer shifts in his seat, Lillie freezes for a second, your cock still deep in her mouth, heart racing."

    lillie "Nnh...! I-I'm trying to make you cum fast... but it's so hard to stay quiet..."

    narrator "Her shy but determined sucking, combined with the thrill of the situation, quickly pushes you closer to the edge."

    show expression "images/cg/lillie/Lillie03a.png" as cg_scene
    with dissolve
    
    mc "Lillie... I'm going to cum..."

    narrator "She doesn't pull away. Instead, she takes you as deep as she can, her cheeks hollowing as she sucks with nervous intensity."

    narrator "With a groan, you cum hard in her mouth, releasing thick ropes directly onto her tongue. Lillie lets out a surprised whimper but swallows everything, her throat moving visibly as she takes every drop."

    narrator "A small trickle escapes the corner of her lips. She quickly wipes it with her finger, her face completely red with embarrassment."

    lillie "I... I can't believe I just did that... here..."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lillie"] += 1
    $ affection["lillie"] = min(100, affection["lillie"] + 5)
    $ advance_hint("lillie")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label lillie_fifth_encounter:

    scene bg cafe
    with fade

    narrator "You stay with Lillie to close the cafe. After the last customer leaves and everything is tidy, you stop her before she can lock the door."

    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve

    lillie "We should go... it's getting really late."

    mc "Just a little longer. No one’s coming at this hour."

    lillie "B-but... what if someone sees us? Or my mother finds out..."

    mc "Trust me. You said you wanted to feel free, right?"

    narrator "Lillie looks nervous, but she doesn't refuse. Fear and excitement mix in her eyes."

    mc "Good girl."

    narrator "You take out the cute pink collar with a leash you prepared earlier. The moment you fasten it around her neck, Lillie gasps."

    lillie "E-eh?! W-what is this...?"

    mc "Shhh. Be quiet and obey. That's what you wanted, isn't it?"

    narrator "Lillie's face burns bright red. She looks incredibly embarrassed, but after a few seconds she gives a tiny, shy nod."

    lillie "...O-okay..."

    hide lillie
    with dissolve

    narrator "You gently tug on the leash, guiding her behind the counter. The cafe is dark and empty, lit only by the soft glow of street lamps filtering through the windows."

    narrator "Lillie follows obediently, her breathing already quick and shallow. The pink collar sits snug around her neck."

    mc "On your hands and knees, like a good girl."

    show expression "images/cg/lillie/Lillie04.png" as cg_scene
    with dissolve

    narrator "She hesitates for a second, cheeks burning, but slowly drops to all fours. You position yourself behind her and lift her skirt, pulling her panties aside."

    narrator "She's already wet. You rub your cock against her slick folds before pushing inside her in one slow thrust."

    lillie "Ahh...! Nnh... It's so deep like this..."

    narrator "You start moving, taking her from behind while holding the leash firmly. Every thrust makes her small body jolt forward."

    lillie "Mmmh...! Hah... We shouldn't... be doing this here..."

    narrator "Despite her nervous words, her hips push back against you eagerly. The leash keeps her movements controlled as you pick up the pace."

    mc "But you love it, don't you? Being fucked in your mother's cafe like this..."

    lillie "D-don't say that...! Ahhn...!"

    narrator "You tug the leash gently whenever she moans too loudly, reminding her to stay quiet. The risk of being caught only makes her tighter around you."

    narrator "Her hands grip the edge of the counter as you thrust harder, the sound of skin meeting skin echoing softly in the empty cafe."

    lillie "I-I'm going to... if you keep going like that...!"

    narrator "You feel her walls clench around you. With one final, deep thrust and a firm tug on the leash, you both reach your climax together."

    show expression "images/cg/lillie/Lillie04a.png" as cg_scene
    with flash

    narrator "Lillie trembles violently, biting her lip to muffle her moan as she cums. You fill her completely, holding the leash tight until the last wave passes."

    narrator "She stays on all fours for a moment, panting softly, the pink collar still around her neck."
    
    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lillie"] += 1
    $ affection["lillie"] = min(100, affection["lillie"] + 5)
    $ advance_hint("lillie")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label lillie_sixth_encounter:

    scene bg cafe
    with fade

    narrator "After closing time, you convince Lillie to let you come to her room. She's nervous but excited, still wearing the pink collar from before."

    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve

    lillie "I... I can't believe I'm letting you do this again. My mother would kill me if she knew..."

    mc "But you like it when I take control, don't you?"

    lillie "T-that's... not fair. You already know the answer..."

    hide lillie
    with dissolve

    show expression "images/cg/lillie/Lillie05.png" as cg_scene
    with dissolve

    narrator "You gently take her hands and guide them behind her back. Using soft red ropes, you tie her wrists together in a simple but secure knot."

    lillie "Ah...! It's tighter than I expected..."

    mc "Does it feel bad?"

    lillie "...No. It feels... safe. Like I don't have to think about anything right now."

    narrator "You push her gently onto the bed. With her wrists tied behind her back, Lillie looks incredibly vulnerable and beautiful. Her breathing is fast and shallow."

    mc "You're so pretty like this, Lillie. Completely at my mercy."

    lillie "D-don't say embarrassing things like that while I'm tied up..."

    narrator "Despite her embarrassed words, Lillie's body trembles with clear excitement. You take your time teasing her, kissing along her neck and collarbone while your hands explore her body."

    narrator "She can't do anything but squirm and take it, her wrists securely tied behind her back."

    lillie "Mmmh... Please... I need more..."

    show expression "images/cg/lillie/Lillie06.png" as cg_scene
    with dissolve

    narrator "You finally position yourself between her legs and push inside her slowly. The ropes keep her back slightly arched, making every thrust feel deeper."

    lillie "Ahhn...! It's so intense like this... I can't move..."

    narrator "You start moving faster, holding her hips as you take her. Lillie moans louder than ever, her voice shaky and needy. The pink collar shifts around her neck with every thrust."

    lillie "I feel so... free like this... It's weird, right? Being tied up and feeling freer than when I'm loose..."

    mc "It's not weird at all. This is exactly what you needed."

    narrator "You lean down and kiss her deeply while continuing to thrust. Her body tightens around you, the combination of ropes and pleasure pushing her closer to the edge."

    lillie "I'm... I'm going to cum... Please don't stop...!"

    show expression "images/cg/lillie/Lillie06a.png" as cg_scene
    with flash

    narrator "With a final, deep thrust, Lillie cums hard, her whole body shaking. Her moans are muffled against your shoulder as the orgasm washes over her."

    narrator "You follow right after, filling her completely while she trembles beneath you."

    narrator "Afterwards, you carefully untie her wrists and pull her into your arms. She curls up against your chest, still wearing the pink collar, breathing softly."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lillie"] += 1
    $ affection["lillie"] = min(100, affection["lillie"] + 5)
    $ advance_hint("lillie")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label lillie_seventh_encounter:

    scene bg cafe
    with fade

    narrator "You arrive at the cafe right as Lillie is closing up. She looks tired, but her face lights up with a soft smile when she sees you."

    show expression get_char_sprite("lillie", "default") as lillie at center
    with dissolve

    lillie "You're here... I was waiting for you."

    mc "Tonight you're not going home."

    lillie "E-eh? What do you mean...?"

    mc "It's not a request, Lillie. You're spending the night at my farm. With me. Under my rules."

    narrator "Lillie's face turns bright red. She looks extremely nervous, but after a few seconds she lowers her gaze and nods obediently."

    lillie "...Yes. I understand."

    narrator "You take her by the hand and lead her to your farm. The moment you close the door of your room behind you, the atmosphere shifts completely."

    hide lillie
    with dissolve

    scene bg home_interior_night
    with dissolve

    show expression "images/cg/lillie/Lillie07.png" as cg_scene
    with dissolve

    narrator "You take your time tying Lillie in a full shibari harness. Intricate red ropes bind her arms behind her back, frame her breasts, and create beautiful patterns across her pale skin. Her legs are also bound, leaving her completely helpless."

    lillie "Haa... It's so tight... I can barely move at all..."

    mc "That's the point. Tonight you don't have to think. You don't have to decide anything. Just feel."

    show expression "images/cg/lillie/Lillie08.png" as cg_scene
    with dissolve

    narrator "You lay her gently on the bed and enter her hard. The ropes dig into her skin with every deep thrust, intensifying every sensation."

    lillie "Ahh...! It's so intense... I feel like I'm floating..."

    narrator "You take her in multiple positions while she's fully bound: missionary with her legs tied together, on her stomach with her arms pulled back, and finally on all fours with the leash attached to her pink collar."

    lillie "Please... harder... I want to feel completely yours..."

    narrator "Lillie cums again and again, each orgasm stronger than the last. Her body shakes violently against the ropes as she loses herself in pleasure."

    lillie "I feel... so free... Thank you... for taking control..."

    show expression "images/cg/lillie/Lillie08a.png" as cg_scene
    with flash
    narrator "You finally cum deep inside her while she's tied in a tight hogtie. Her whole body trembles as she rides the last waves of her orgasm."

    narrator "Afterwards, you carefully untie every rope, kissing the red marks left on her skin. You pull her into your arms and hold her close while she recovers."

    lillie "I never want to go back to how I was before... Being yours like this... it's the freest I've ever felt."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lillie"] += 1
    $ affection["lillie"] = min(100, affection["lillie"] + 5)
    $ advance_hint("lillie")
    $ advance_slot(2)

    jump expression "location_" + current_location

