# ============================================================
# POKETOWN, characters/cynthia.rpy
# ============================================================

label interact_cynthia:

    $ pending = get_pending_delivery("cynthia")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            cynthia "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            cynthia "I'm still waiting for my order..."
            cynthia "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("cynthia", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["cynthia"]
    $ slot = current_slot
    $ prog = character_progress["cynthia"]

    if prog == 0:
        jump cynthia_meeting
    elif prog == 1 and aff >= 10 and stat_intelligence >= 10 and loc == "library" and slot in [3, 4]:
        jump cynthia_first_encounter
    elif prog == 2 and aff >= 20 and stat_intelligence >= 15 and loc == "library" and slot in [3, 4]:
        jump cynthia_second_encounter
    elif prog == 3 and aff >= 35 and stat_intelligence >= 15 and loc == "library" and slot in [3, 4]:
        jump cynthia_third_encounter
    elif prog == 4 and aff >= 50 and stat_intelligence >= 20 and loc == "library" and slot in [3, 4]:
        jump cynthia_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_intelligence >= 20 and loc == "library" and slot in [3, 4]:
        jump cynthia_fifth_encounter
    elif prog == 6 and aff >= 80 and stat_intelligence >= 25 and loc == "library" and slot in [3, 4]:
        jump cynthia_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_intelligence >= 25 and loc == "library" and slot in [3, 4]:
        jump cynthia_seventh_encounter
    else:
        jump cynthia_contextual_dialogue


# ------------------------------------------------------------
# CONTEXTUAL DIALOGUE
# ------------------------------------------------------------

label cynthia_contextual_dialogue:

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve
    $ affection["cynthia"] = min(100, affection["cynthia"] + 3)

    if aff_tier == "stranger":
        if loc == "library":
            cynthia "Interesting. Most people don't come to the mythology section."
            cynthia "I'm Cynthia. I own this place, technically, though it runs itself."
        else:
            cynthia "You must be new here. I'd remember a face like yours."
            cynthia "I'm Cynthia. Welcome to Heartwood."

    elif aff_tier == "acquaintance":
        if loc == "library":
            cynthia "Still exploring the shelves? Good. Most people give up after the first aisle."
        elif loc == "cafe":
            cynthia "I come here to write. The noise helps me think, oddly enough."
        else:
            cynthia "I've been thinking about our last conversation. You raised interesting points."

    elif aff_tier == "friend":
        if loc == "library":
            cynthia "I've been waiting for someone to discuss this chapter with."
            cynthia "Sit down. This might take a while."
        elif loc == "beach":
            cynthia "I come here when the research gets too heavy."
            cynthia "The ocean doesn't ask questions."
        elif time_tier == "night":
            cynthia "The best conversations happen after dark, I've found."
        else:
            cynthia "Perfect timing. I wanted to show you something."

    else:
        if loc == "library":
            cynthia "I dedicated a shelf to books I want to read with you. Don't tell anyone."
        elif time_tier == "night":
            cynthia "I used to spend every night alone with my research."
            cynthia "I don't miss it."
        else:
            cynthia "You know, for someone who just arrived in town, you've become remarkably important to me."

    hide cynthia
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label cynthia_meeting:

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    cynthia "Welcome to the library. I'm the owner. If you need anything, just let me know."

    hide cynthia
    with dissolve

    $ character_progress["cynthia"] += 1
    $ affection["cynthia"] = min(100, affection["cynthia"] + 5)
    $ advance_hint("cynthia")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label cynthia_first_encounter:

    scene bg library_night
    with fade

    narrator "The library is completely empty except for Cynthia, who is carefully organizing the shelves."

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    cynthia "The library is already closed. Whatever you need, I'm very busy right now. I don't have time to help you."

    mc "You work too hard. Maybe a little help wouldn't be so bad?"

    narrator "Cynthia gives you a sharp, challenging look."

    cynthia "No. I've managed this library by myself for many years. I doubt a young little farmer like you could be of much use."

    mc "Oh... I'm sorry, I didn't mean to offend you."

    cynthia "Ha. Don't worry, I did mean to offend you. Still, it was a nice thought. But I seriously doubt you understand how a library should be organized."

    mc "You're right. Sorry for bothering you."

    cynthia "Even so... you can come by more often. Who knows? Maybe you'll actually learn something and become useful someday."

    mc "Sure, alright."

    narrator "You leave the library feeling somewhat unsettled by your interaction with Cynthia."

    hide cynthia
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["cynthia"] += 1
    $ affection["cynthia"] = min(100, affection["cynthia"] + 5)
    $ advance_hint("cynthia")
    $ advance_slot(2)

    jump location_library


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label cynthia_second_encounter:

    scene bg library_night
    with fade

    narrator "You run into Cynthia again at night. She looks more irritated than usual."

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    mc "Could you use an extra hand today, or am I still too useless for you?"

    cynthia "Ugh, you again? I'm busy right now."

    mc "I know, but I thought I could help like I offered last time."

    cynthia "Fine. You can sort the books that were left out on the tables. I'll be in my office. Don't expect me to praise you if you do it poorly."

    mc "Yes, ma'am."

    narrator "Cynthia turns and walks away quickly, leaving you to organize the books. After a long time, you finally manage to put everything back in its proper place."

    mc "Should I go tell her I'm done? It would be rude to just leave without saying anything..."

    narrator "You notice the light in her office is still on. You walk over and open the door."

    mc "Cynthia, I think I'm done..."

    hide cynthia
    with dissolve

    show expression "images/cg/cynthia/Cynthia01.png" as cg_scene
    with dissolve

    narrator "You freeze. Cynthia is sitting in her chair with her hand between her legs, clearly in the middle of pleasuring herself."

    narrator "The moment she notices you, her eyes lock onto yours. Her expression shifts from surprise to something colder."

    narrator "Embarrassed, you quickly step back."

    hide cg_scene
    with dissolve

    narrator "You leave the library with your heart pounding, unable to shake the image of what you just saw."

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["cynthia"] += 1
    $ affection["cynthia"] = min(100, affection["cynthia"] + 5)
    $ advance_hint("cynthia")
    $ advance_slot(2)

    jump location_library


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label cynthia_third_encounter:

    scene bg library_night
    with fade

    narrator "You've been avoiding Cynthia ever since you walked in on her last time. However, she called you earlier today, clearly angry, and demanded you come to the library."

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    mc "H-hey Cynthia... I'm really sorry about the other night. I didn't mean to walk in on you."

    cynthia "Whether you meant to or not, you left the books completely out of place. Most people might not notice, but I can't stand disorder in my library."

    mc "Oh... right, the books."

    cynthia "Yes, the books. Though I'm curious... is that really the reason you're apologizing, or is it something else?"

    mc "Well... I showed up unannounced, and you were... you know..."

    cynthia "What? First time you've seen a woman touching herself?"

    mc "No, but... I thought..."

    cynthia "Ugh, enough. Be quiet and come with me. I'll do you a favor and let you make it up to me for the mess you caused."

    narrator "Cynthia takes you by the hand and firmly leads you toward her office."

    cynthia "Alright. I'm going to teach you a few things, so when you eventually get a girlfriend, you don't embarrass yourself like an inexperienced boy."

    hide cynthia
    with dissolve

    show expression "images/cg/cynthia/Cynthia02.png" as cg_scene
    with dissolve

    narrator "Cynthia sits on the edge of her desk and slowly take off her pants."

    narrator "Without hesitation, she grabs the back of your head with a firm grip and pulls your face between her thighs."

    narrator "The moment your tongue makes contact with her wet pussy, she lets out a low, controlled breath."

    cynthia "Mmh... That's it. Use your tongue properly."

    narrator "She presses your head harder against her, guiding your movements with clear authority."

    narrator "Her pussy is warm and slick against your mouth as you begin licking her."

    cynthia "Slower... focus on my clit. Use the flat of your tongue, Ahh... yes, just like that."

    narrator "Her breathing becomes heavier, but she still tries to maintain her composure, giving you precise instructions between soft gasps."

    cynthia "Nngh... swirl around it... don't suck yet. Mmm... good boy."

    narrator "Her thighs start to tremble slightly around your head. Her grip on your hair tightens as her hips begin to move subtly against your face."

    cynthia "Faster now... right there, fuck... don't stop..."

    narrator "Her voice starts to crack. The composed librarian is slowly losing control."

    narrator "Suddenly, her thighs clamp tightly around your head as her body tenses up."

    cynthia "Ahhh! I'm cumming...!"

    narrator "She grinds hard against your mouth as a powerful orgasm washes over her. You can feel her pussy pulsing and twitching against your tongue."

    narrator "She holds your head firmly in place, not letting you pull away until the last waves of pleasure fade."

    cynthia "Haaah... Haah... Not bad at all."

    narrator "After catching her breath, she looks down at you with a satisfied, slightly arrogant smile."

    cynthia "You have potential, boy. It seems I'll have to give you several more lessons... until you truly learn how to please a woman properly."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["cynthia"] += 1
    $ affection["cynthia"] = min(100, affection["cynthia"] + 5)
    $ advance_hint("cynthia")
    $ advance_slot(2)

    jump location_library


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label cynthia_fourth_encounter:

    scene bg library_night
    with fade

    narrator "Cynthia has been asking you to help organize the shelves more frequently lately. Though she'd never admit it, she clearly enjoys having you around."

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    cynthia "Thank you for your help today. Stay a little longer tonight... I want to continue your lessons."

    narrator "The way she looks at you now feels different. More intense. The shift in her behavior excites you, and Cynthia clearly notices."

    cynthia "My, my... that reaction tells me you're quite eager. But you'll have to wait. Finish organizing the shelves first. Once the library is closed, I'll take care of you."

    narrator "Motivated by her words, you work much faster than usual. When you finally finish, you notice that the entire library has already been closed up. The only light on is coming from her office on the second floor, with the door slightly open."

    cynthia "Took you long enough. I was starting to think you'd lost your nerve."

    mc "Sorry for taking so long..."

    cynthia "Shhh."

    "She places a finger over her lips, her eyes narrowing."

    cynthia "While you're with me, under my supervision, you only speak when I tell you to. Understood?"

    narrator "You nod quickly."

    cynthia "Good boy."

    hide cynthia
    with dissolve

    show expression "images/cg/cynthia/Cynthia03.png" as cg_scene
    with dissolve

    narrator "Cynthia spreads her legs wide and pulls your head firmly between her thighs, pressing your face against her already wet pussy."

    narrator "This time she is far more demanding."

    cynthia "Mmh... That's right. Use that tongue like I taught you."

    narrator "She immediately starts grinding her hips against your mouth, riding your face with clear hunger."

    cynthia "Faster... right there on my clit. Don't you dare slow down, Ahh..."

    narrator "Her grip on your hair tightens painfully as she controls every movement, using your mouth for her pleasure."

    cynthia "Nngh... good boy. Lick deeper... yes, just like that. Fuck..."

    narrator "She becomes significantly wetter, her juices coating your tongue and chin as her breathing turns into heavy, needy gasps."

    cynthia "Harder! Don't stop... keep sucking on it... Mmmh!"

    narrator "Her usual composure is cracking. She rides your face more aggressively, her thighs trembling around your head."

    cynthia "I'm close... don't you fucking stop, Ahh! Ahhh!"

    narrator "She suddenly presses her pussy hard against your mouth and cums intensely, her whole body shaking. Her thighs clamp tightly around your head as powerful spasms run through her."

    narrator "She holds you there firmly, grinding slowly against your tongue as she rides out every last wave of her orgasm."

    narrator "After a long, silent moment, she finally releases your head and looks down at you with half-lidded eyes."

    cynthia "Haaah... Good boy."

    narrator "She gently strokes your hair once before standing up."

    cynthia "Clean yourself up and make sure you lock everything when you leave."

    narrator "Cynthia tosses you the keys, gives you one last satisfied look, and walks out of the office, leaving you kneeling there."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["cynthia"] += 1
    $ affection["cynthia"] = min(100, affection["cynthia"] + 5)
    $ advance_hint("cynthia")
    $ advance_slot(2)

    jump location_library


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label cynthia_fifth_encounter:

    scene bg library_night
    with fade

    narrator "You've been coming to the library almost every day for weeks now. Cynthia never asks you directly to come, but on the days you don't show up, her mood is noticeably worse the following night."

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    cynthia "You're late today."

    mc "I didn't know I had a fixed schedule."

    cynthia "You don't. But the books aren't going to organize themselves. Get to work."

    narrator "You start sorting the usual shelves. Halfway through, Cynthia unusually comes down from her office and begins checking a nearby section in silence."

    mc "Are you checking my work?"

    cynthia "Supervising. There's a big difference."

    mc "And...?"

    cynthia "You've improved. I won't tell you by how much. I refuse to inflate your ego."

    narrator "She continues inspecting the shelves quietly. After a few moments, still without looking at you, she speaks."

    cynthia "Stay after closing tonight. It's time for your next lesson."

    narrator "Once the library closes, Cynthia heads up to her office. She stops at the top of the stairs and signals for you to follow her with a single gesture."

    hide cynthia
    with dissolve

    show expression "images/cg/cynthia/Cynthia04.png" as cg_scene
    with dissolve

    narrator "Without warning, she pushes you down onto the chair and turns around, straddling you in reverse cowgirl position."

    narrator "She reaches between her legs, grabs your hard cock, and slowly lowers herself onto it, taking you inside her tight, wet pussy."

    cynthia "Mmh... Feel that? This is how I want you tonight."

    narrator "She starts riding you with firm, controlled movements, her ass moving up and down at her own rhythm."

    cynthia "Hands on my thighs. Don't move... just stay right there and let me use you."

    narrator "She looks over her shoulder at you with a dominant, almost arrogant gaze as she gradually increases her pace, taking you deeper with every thrust."

    cynthia "Nngh... That's it... deeper... Fuck..."

    narrator "Her moans grow lower and more commanding as she rides you harder, her hips rolling with experienced confidence."

    cynthia "You're getting harder inside me... Good boy. But don't you dare cum yet."

    narrator "Her movements become faster and more intense. Her breathing turns into heavy, shaky gasps as she chases her own pleasure."

    cynthia "Ahh...! I'm going to cum... Don't move!"

    narrator "She slams down hard one final time and cums intensely, her pussy clenching tightly around your cock. Her whole body trembles as she rides out her orgasm."

    narrator "Even after finishing, she doesn't stop. She continues riding you relentlessly, determined to make you cum as well."

    cynthia "Haaah... Now it's your turn. Cum inside me... Fill me up."

    show expression "images/cg/cynthia/Cynthia04a.png" as cg_scene
    with flash

    narrator "Her words and the tight grip of her pussy push you over the edge. You thrust up into her and cum hard, releasing deep inside her."

    cynthia "Mmm... That's a good boy."

    narrator "She stays seated on you for a moment longer, savoring the feeling, before finally lifting herself off with a satisfied sigh."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    cynthia "Good. But don't get excited, this is only the beginning of what comes next."

    mc "There's more?"

    cynthia "There's always more. You should have learned that by now."

    narrator "She leaves the keys as always and heads out. But before leaving she pauses a moment at the door."

    cynthia "Don't be late tomorrow."

    hide cynthia
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["cynthia"] += 1
    $ affection["cynthia"] = min(100, affection["cynthia"] + 5)
    $ advance_hint("cynthia")
    $ advance_slot(2)

    jump location_library


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label cynthia_sixth_encounter:

    scene bg library_night
    with fade

    narrator "When you arrive at the library, you find it in complete chaos. There are boxes everywhere, stacks of books covering the floor, and Cynthia standing in the middle of it all looking visibly stressed."

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    mc "What happened here?"

    cynthia "A large donation. Three hundred books arrived with no cataloguing and no organization. The people who sent them expect everything to be ready by tomorrow."

    mc "I can help."

    cynthia "Obviously. That's the only reason I didn't kick you out the moment you walked in."

    narrator "You spend the next several hours working side by side. Cynthia gives orders while you sort and organize. For the first time, the atmosphere doesn't feel like one of her usual 'lessons' it feels more like two people working together."

    narrator "By the time you finish, it's very late. Cynthia finally sits down for the first time in hours and quietly looks over the completed work."

    cynthia "Not bad."

    mc "Just 'not bad'?"

    cynthia "Fine. It's good. Don't let it go to your head."

    narrator "She stands up and gestures with her head for you to follow her upstairs."

    hide cynthia
    with dissolve

    show expression "images/cg/cynthia/Cynthia05.png" as cg_scene
    with dissolve

    narrator "Cynthia bends over her desk and looks back at you with a commanding gaze."

    cynthia "Take me from behind. Now."

    narrator "You step forward and push your cock inside her. She's incredibly wet and tight."

    cynthia "Harder... Give me a steady, deep rhythm. Don't be gentle."

    narrator "She reaches back with one hand, grabbing your hip and pulling you deeper into her with each thrust."

    cynthia "Deeper! That's it... Fuck me properly. Mmh..."

    narrator "Her body rocks forward against the desk with every powerful thrust. Even in this position, she remains completely in control."

    cynthia "Faster now... Don't slow down. Nngh! Just like that... good boy."

    narrator "Her moans grow louder and more demanding as you pound into her. The sound of skin slapping against skin fills the office."

    cynthia "Harder! Make me feel it, Ahh...! Fuck!"

    narrator "Her body suddenly tenses. She grips the edge of the desk tightly as her first orgasm hits her hard."

    cynthia "I'm cumming! Don't you dare stop!!"

    narrator "Her pussy clenches rhythmically around your cock as she shudders violently. But instead of slowing down, she pushes back against you even more greedily."

    cynthia "Keep going... I want another one. Don't you stop until I cum again."

    narrator "You continue thrusting hard into her sensitive pussy. Her moans become louder and more desperate as she chases her second orgasm."

    cynthia "Yes! Right there... I'm so close... Ahhh!"

    narrator "She cums even harder the second time, her legs shaking and her voice breaking into a long, throaty moan."

    cynthia "Haaah... Now... Cum inside me. Fill me up."
    
    show expression "images/cg/cynthia/Cynthia05a.png" as cg_scene
    with flash

    narrator "With her permission, you thrust deep one final time and release inside her, pumping every drop into her throbbing pussy."

    cynthia "Mmm... Good boy."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    narrator "When it's over she stays quiet for a moment, something she doesn't usually do."

    cynthia "You're improving faster than I expected. Don't say that out loud."

    mc "I didn't say anything."

    cynthia "Good. Lock up when you leave."

    hide cynthia
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["cynthia"] += 1
    $ affection["cynthia"] = min(100, affection["cynthia"] + 5)
    $ advance_hint("cynthia")
    $ advance_slot(2)

    jump location_library


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label cynthia_seventh_encounter:

    scene bg library_night
    with fade

    narrator "It's quite late when you arrive at the library. The main lights are off, but the warm glow from her office upstairs is clearly visible."

    narrator "You pull out your keys without even thinking. By now it's become automatic. The library is perfectly quiet and organized, exactly how she likes it. You head upstairs. Her office door is slightly ajar."

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    cynthia "I knew you'd come."

    mc "I always do."

    cynthia "Yes... I've noticed."

    narrator "She's sitting at her desk, but she isn't working. She looks straight at you with a calm, intense gaze."

    cynthia "Tonight is the last lesson."

    mc "Last?"

    cynthia "Of the basic course, yes. What comes after this... is something different."

    narrator "Her voice carries a subtle weight. For the first time, she doesn't sound like she's simply teaching you, she sounds like she's making a decision."

    hide cynthia
    with dissolve

    show expression "images/cg/cynthia/Cynthia06.png" as cg_scene
    with dissolve

    narrator "Tonight feels different. Cynthia doesn't start with instructions or evaluations like before."

    narrator "She simply looks at you with quiet intensity, then lies back on her desk and pulls you on top of her."

    narrator "She wraps her legs tightly around your waist, locking her ankles behind your back."

    cynthia "Inside me... Now."

    narrator "You push into her slowly. She's incredibly wet and warm. She lets out a soft, deep sigh as you fill her completely."

    cynthia "Mmh... That's it. Move just like this..."

    narrator "Even in this position, she remains fully in control. Her legs dictate the rhythm, pulling you deeper or holding you back when she wants to slow down."

    narrator "Her hands grip your back firmly, nails digging into your skin as her breathing grows heavier."

    cynthia "Deeper... Yes... Just like that. Don't rush it."

    narrator "She pulls you down into a possessive kiss, her tongue demanding as her hips roll up to meet your thrusts."

    cynthia "Nngh... Harder now... Ahh...!"

    narrator "Her usual composure begins to melt. Her kisses become more desperate, her nails rake down your back as pleasure builds inside her."

    cynthia "Don't stop... Stay right there, Fuck...!"

    narrator "Her body suddenly tenses beneath you. Her legs squeeze you tighter as she reaches a long, powerful climax."

    show expression "images/cg/cynthia/Cynthia06a.png" as cg_scene
    with flash

    cynthia "Ahhh! I'm cumming...! Hold me...!"

    narrator "Her pussy clenches rhythmically around your cock as waves of pleasure wash over her. She holds you close, refusing to let you pull away even for a second."

    narrator "She rides out every last tremor, kissing you deeply through her orgasm, her moans vibrating against your mouth."

    narrator "Only when her body finally relaxes does she loosen her legs slightly, still keeping you buried deep inside her."

    cynthia "Haaah... Good boy."

    narrator "She strokes your hair gently, her usual arrogance replaced by something softer, more intimate."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("cynthia", "default") as cynthia at center
    with dissolve

    cynthia "...Good. Very good."

    narrator "She says it almost to herself. Her voice is softer than usual, completely missing the usual teacher-like tone."

    narrator "The silence that follows feels different from other nights. It's quieter... heavier."

    cynthia "Lock up when you leave."

    mc "Cynthia."

    cynthia "What?"

    mc "When does the next course start?"

    narrator "Cynthia doesn't answer immediately. She picks up a book from the desk and pretends to look through it, though her eyes aren't really moving."

    narrator "After a long pause, she finally speaks."

    cynthia "When I decide it starts."

    mc "And when will that be?"

    narrator "She stays quiet for a few more seconds, still not looking at you."

    cynthia "...Soon."

    narrator "Her voice is low, almost gentle. For the first time, there's no cold distance in it, just a quiet promise."

    hide cynthia
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["cynthia"] += 1
    $ affection["cynthia"] = min(100, affection["cynthia"] + 5)
    $ advance_hint("cynthia")
    $ advance_slot(2)

    jump location_library
