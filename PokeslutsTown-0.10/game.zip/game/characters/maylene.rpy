# ============================================================
# POKETOWN, characters/maylene.rpy
# ============================================================

label interact_maylene:

    $ pending = get_pending_delivery("maylene")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            maylene "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            maylene "I'm still waiting for my order..."
            maylene "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("maylene", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["maylene"]
    $ slot = current_slot
    $ prog = character_progress["maylene"]

    if prog == 0 and loc == "gym":
        jump maylene_meeting
    elif prog == 1 and aff >= 20 and loc == "gym" and slot in [0, 1, 2]:
        jump maylene_first_encounter
    elif prog == 2 and aff >= 40 and stat_physique >= 5 and loc == "gym" and slot in [0, 1, 2]:
        jump maylene_second_encounter
    elif prog == 3 and aff >= 55 and stat_physique >= 10 and loc == "gym" and slot in [0, 1, 2]:
        jump maylene_third_encounter
    elif prog == 4 and aff >= 70 and loc == "beach" and slot in [0, 1, 2] and "maylene_swimsuit" in unlocked_skins["maylene"]:
        jump maylene_fourth_encounter
    elif prog == 5 and aff >= 80 and stat_charisma >= 15 and loc == "gym" and slot in [0, 1, 2]:
        jump maylene_fifth_encounter
    elif prog == 6 and aff >= 90 and stat_charisma >= 20 and loc == "plaza" and slot in [0, 1, 2] and "maylene_cosplay" in unlocked_skins["maylene"]:
        jump maylene_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_physique >= 25 and loc == "gym" and slot in [0, 1, 2]:
        jump maylene_seventh_encounter
    else:
        jump maylene_contextual_dialogue

label maylene_contextual_dialogue:
    show expression get_char_sprite("maylene", "default") as mallow at center
    with dissolve
    $ affection["maylene"] = min(100, affection["maylene"] + 3)

    if aff_tier == "stranger":
        if loc == "gym":
            maylene "You here to train? Good. I respect that."
            maylene "I'm Maylene. I run the strength program here."
        else:
            maylene "Hey. Don't think we've met. I'm Maylene."
            maylene "I'm at the gym most days if you want to train sometime."
    elif aff_tier == "acquaintance":
        if loc == "gym":
            maylene "Your form is improving. Keep at it."
        elif loc == "plaza":
            maylene "Rest days are important too. Even I take them."
            maylene "Don't tell anyone though."
        else:
            maylene "Hey! How's the training going?"
    elif aff_tier == "friend":
        if loc == "gym":
            maylene "I've been pushing you harder lately. You haven't complained once."
            maylene "I like that about you."
        elif loc == "cafe":
            maylene "Don't laugh. Even fighters need coffee."
        elif time_tier == "evening":
            maylene "Evenings are when I actually relax. Funny running into you now."
        else:
            maylene "You're one of the few people who keeps up with me. Literally."
    elif aff_tier == "close":
        if loc == "gym":
            maylene "Training with you has become the best part of my day."
            maylene "I didn't expect that."
        else:
            maylene "I'm not great with words. But I'm glad you're here."

    hide maylene
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location

# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label maylene_meeting:

    show expression get_char_sprite("maylene", "default") as maylene at center
    with dissolve

    maylene "I’m Maylene, the trainer here at the gym. If you ever want help with your training, just talk to me."

    hide maylene
    with dissolve

    $ affection["maylene"] = min(100, affection["maylene"] + 5)
    $ character_progress["maylene"] += 1
    $ advance_hint("maylene")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label maylene_first_encounter:

    scene bg gym
    with fade

    narrator "You enter the gym and immediately notice Maylene practicing. She’s delivering sharp kicks to a long boxing bag, her movements precise and controlled."

    show expression "images/cg/maylene/maylene01.png" as cg_scene
    with dissolve

    mc "Hey."

    maylene "Hey. What do you want to do? I’ll instruct you."

    mc "I didn’t know you did boxing here. I’m interested."

    narrator "Maylene glances at your body for a second. A small laugh escapes her before she quickly covers it up."

    maylene "No offense, but I don’t think you’re ready for boxing. And even if you were, there aren’t any guys around here who practice it, so finding you an opponent would be difficult."

    mc "What about you? You could be my opponent."

    narrator "Maylene lets out a much more open, almost shameless laugh."

    maylene "Sorry, that was rude. But fighting me would be really tough for you. You wouldn’t stand a chance."

    mc "Sounds like you’re scared."

    maylene "Provoking me is useless. If you want, I can give you some classes... but giving you an actual fight would be unsportsmanlike."

    hide maylene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["maylene"] += 1
    $ affection["maylene"] = min(100, affection["maylene"] + 5)
    $ advance_hint("maylene")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label maylene_second_encounter:

    scene bg gym
    with fade

    narrator "You arrive at the gym ready to train. Maylene is already waiting for you."

    show expression get_char_sprite("maylene", "default") as maylene at center
    with dissolve

    maylene "You better be ready. I’m going to make you sweat. As long as there’s no one else here, I’ll give you my full attention."

    narrator "Maylene puts you through an intensive training session. The pace is relentless. By the end, you’re sitting on the floor, completely exhausted and breathing hard."

    maylene "That’s all you’ve got? I thought you’d last longer."

    mc "I’m just getting started. Give me a few weeks and I’ll surpass you."

    maylene "Ha. Sure you will. Go take a shower, you’re dripping sweat. I’ll clean up the gym in the meantime."

    mc "Aren’t you going to shower too? You sweated a lot."

    maylene "I would, but there aren’t many guys in this town, and even fewer come to the gym... so we don’t have a men’s shower. Since no one’s around, you can use this one."

    hide maylene
    with dissolve

    show expression "images/cg/maylene/maylene02.png" as cg_scene
    with dissolve

    narrator "You head to the shower. After washing off the sweat and changing, you step out to find Maylene waiting near the entrance. She’s only wearing a towel wrapped around her body."

    maylene "You sure took your time. Hurry up and get going. I’m closing early today."

    narrator "You leave the gym, still catching your breath from the training."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["maylene"] += 1
    $ affection["maylene"] = min(100, affection["maylene"] + 5)
    $ advance_hint("maylene")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label maylene_third_encounter:

    scene bg gym
    with fade

    narrator "The gym is more crowded than usual today, so you end up training on your own. After a while, Maylene walks over to check on you."

    show expression get_char_sprite("maylene", "default") as maylene at center
    with dissolve

    mc "I’m pretty sure I could beat you by now."

    maylene "You’ve only been training for a few days. You’re not ready to spar with anyone yet."

    mc "Then let’s make a bet. If you’re that confident, it should be an easy win for you."

    maylene "My sports swimsuit tore, so I haven’t been able to go swimming at the beach. If I win, you buy me a new one."

    maylene "And if you win... well, you can ask for whatever you want. Not that it’s going to happen."

    narrator "Before you can even respond, Maylene turns and heads off to change. A few minutes later she returns, and the two of you step into the ring."

    maylene "Let’s keep it simple. First one to hit the floor loses. And watch out for the legs, I do kickboxing."

    mc "Got it."

    hide maylene
    with dissolve

    show expression "images/cg/maylene/maylene03.png" as cg_scene
    with dissolve

    narrator "You get into a fighting stance. The moment the spar starts, Maylene’s foot comes up fast and hard, connecting cleanly with the side of your head. You barely have time to react before you’re already on the floor."

    mc "Ow... I thought you’d go easy on me since I’m a beginner."

    maylene "I *was* going easy. If I hadn’t, you’d be knocked out."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["maylene"] += 1
    $ affection["maylene"] = min(100, affection["maylene"] + 5)
    $ advance_hint("maylene")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label maylene_fourth_encounter:

    scene bg beach_day
    with fade

    narrator "Maylene invited you to the beach. Since you bought her the new swimsuit, she said it was only fair that you came along to see her try it out."

    show expression "images/cg/maylene/maylene04.png" as cg_scene
    with dissolve

    maylene "You know, I’m grateful... but I feel like this thing is a bit small. Don’t you think?"

    mc "I think it looks great on you."

    maylene "Haha. How funny."

    narrator "Her tone is clearly sarcastic and unimpressed."

    maylene "I didn’t think you were the perverted type."

    mc "It’s not my fault the swimsuit looks that good on you."

    maylene "Okay. I’m going swimming. You can stay here staring at other girls."

    hide cg_scene
    with dissolve

    narrator "Maylene heads into the water. You stay on the sand resting, waiting for her to come back. After a while you realize she’s been gone too long and start to worry. Looking out at the sea, you spot her in the distance waving for you to come closer."

    maylene "For god’s sake, how much longer were you going to take? I’ve been trying to get your attention for a while."

    show expression "images/cg/maylene/maylene05.png" as cg_scene
    with dissolve

    narrator "When you get closer, you notice she’s no longer wearing the top of her swimsuit."

    maylene "I took the top off for a moment because it was too tight and I needed to breathe... and the waves took it."

    mc "Hahaha. Alright, don’t worry. I’ll bring you something."

    show expression "images/cg/maylene/maylene06.png" as cg_scene
    with dissolve

    narrator "You go back to the shore, grab a jacket, and return to her. She puts it on and the two of you walk back to the beach together."

    maylene "Sorry. I didn’t expect that to happen. And sorry for getting your jacket wet."

    mc "Don’t worry about it. Keep it, it looks good on you. Besides, this whole situation is my fault. I clearly got you the wrong size."

    narrator "Maylene looks away for a second. A faint blush appears on her face, though she still seems more amused than embarrassed."

    maylene "Thanks. I hope I keep seeing you at the gym."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["maylene"] += 1
    $ affection["maylene"] = min(100, affection["maylene"] + 5)
    $ advance_hint("maylene")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label maylene_fifth_encounter:

    scene bg gym
    with fade

    narrator "When you enter the gym, Maylene actually looks glad to see you. The place is empty again."

    show expression get_char_sprite("maylene", "default") as maylene at center
    with dissolve

    maylene "Good timing. Since no one’s around, I can focus on you completely today."

    narrator "The training is intense, and she stays much closer than usual, correcting your form with her hands and barely giving you space."

    maylene "Phew... You’ve gotten pretty good. I have to try harder and harder just to keep up with you."

    mc "Sounds like I’ve earned another spar. How about we make it a bet again?"

    maylene "You that eager to buy me more stuff? Fine. I still don’t know what I want though. Go shower and I’ll think about it."

    narrator "You head to the shower. While you’re washing off the sweat, the door suddenly opens."

    hide maylene
    with dissolve

    show expression "images/cg/maylene/maylene07.png" as cg_scene
    with dissolve

    maylene "I already know what I wa-"

    narrator "Maylene freezes mid-sentence the moment she sees you completely naked. Her eyes drop for a second and she stares, face turning red."

    mc "Ah, sorry, I was just-"

    maylene "Wha-! I’m sorry, I’m sorry!"
    
    hide cg_scene
    with dissolve

    narrator "She slams the door shut immediately. When you finish and step out, she’s waiting outside, clearly nervous and avoiding eye contact."

    mc "Sorry you had to see that..."

    maylene "Better not talk about it. Let’s just fight, okay?"

    narrator "She walks quickly toward the ring. Once you’re both inside, she takes a breath."

    maylene "Same rules as last time."

    show expression "images/cg/maylene/maylene08.png" as cg_scene
    with flash

    narrator "Maylene looks more distracted than usual. Even so, she still opens with one of her fast kicks. This time you’re ready and raise your arm to block. The sudden shift in balance, combined with her nerves, makes her slip and fall flat on her back."

    mc "You lost."

    maylene "What? No, I just slipped."

    mc "Exactly. And you touched the ground. According to your own rules, that means you lose. You said same rules."

    maylene "Ugh... Fine. What do you want?"

    mc "A date."

    narrator "Maylene’s face turns red again."

    maylene "Seriously? You want a date with me?"

    mc "Don’t get too happy. It’s a prize for me, not for you, you'll wear what I say."

    maylene "How bad can it be...?"

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["maylene"] += 1
    $ affection["maylene"] = min(100, affection["maylene"] + 5)
    $ advance_hint("maylene")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label maylene_sixth_encounter:

    scene bg plaza_day
    with fade

    narrator "You arrive at the plaza and immediately spot Maylene waiting near one of the benches. She’s wearing a tight Chun-Li cosplay: the blue qipao hugging her body, the gold spikes on her wrists, and her hair tied up in the two familiar buns."
    narrator " The outfit is short enough that every step makes the fabric ride a little higher on her thighs."

    show expression "images/cg/maylene/maylene09.png" as cg_scene
    with dissolve

    maylene "Okay. This is worse than I thought."

    maylene "I knew you were going to pick something revealing, but I didn’t expect a full-on geek fetish. I look ridiculous."

    mc "You don’t. It actually suits you. You’ve got the legs for it."

    maylene "That’s not the compliment you think it is. I feel like I walked out of some fighting game."

    mc "You kind of did."

    maylene "Ugh. Fine. I already put it on, so don’t make me regret this more than I already do."

    narrator "The two of you start walking through the plaza. At first Maylene keeps her arms crossed and stays a little behind you, clearly aware of how much skin the outfit shows. A few people glance her way. She clicks her tongue every time she notices."

    maylene "If anyone from the gym sees me like this, I’m blaming you."

    mc "Then let’s just walk. No one has to know."

    show expression "images/cg/maylene/maylene10.png" as cg_scene
    with dissolve

    narrator "After a while she starts to relax. You buy something cold to drink and sit on a bench under the shade. Maylene stretches her legs out in front of her, still looking a bit self-conscious, but her shoulders finally drop."

    maylene "This is still stupid. But hanging out like this isn’t that bad."

    narrator "You stay there longer than planned. She talks about training, about how empty the gym has been lately, and even laughs when you point out that she hasn’t complained about the outfit in several minutes. For a moment she looks genuinely comfortable next to you."

    maylene "Alright. That’s enough standing around in this thing. Let’s go back to the gym before I change my mind."

    hide cg_scene
    with dissolve

    scene bg gym
    with dissolve

    narrator "Once inside, Maylene immediately pulls at the hem of the qipao, as if she just remembered how short it is."

    maylene "I’m changing. This outfit feels weird. I’m not used to walking around in something like this."

    mc "Take your time."

    narrator "She disappears into the locker room. You start training on your own: bag work, footwork, a few stretches. Time passes. Then more time. She still doesn’t come out."

    narrator "After waiting long enough that it starts to feel strange, you decide to check on her."

    narrator "You push the locker room door open just enough to look inside… and freeze."

    show expression "images/cg/maylene/maylene11.png" as cg_scene
    with dissolve

    narrator "Maylene is still wearing the Chun-Li outfit. She’s sitting on the bench with her legs slightly open, one hand under the short qipao, fingers moving between her thighs. Her other hand is gripping the edge of the bench."
    narrator "Her face is flushed, her breathing uneven, and her hips shift faintly against her own touch. The spikes on her wrists catch the light every time her hand moves."

    maylene "Ah—?!"

    narrator "The second she sees you, her whole body tenses. She yanks her hand back, slams her knees together, and stares at you with wide, panicked eyes."

    maylene "Don’t come in! Just— leave!"

    narrator "She shoves the door shut hard enough that it echoes through the empty gym. You stand there for a moment, then decide not to push it."

    mc "Alright. I’ll go."

    hide cg_scene
    with dissolve

    narrator "You leave the gym without saying anything else, giving her the space she asked for."

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["maylene"] += 1
    $ affection["maylene"] = min(100, affection["maylene"] + 5)
    $ advance_hint("maylene")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label maylene_seventh_encounter:

    scene bg gym
    with fade

    narrator "The gym is empty again when you arrive. Maylene looks straight at you the moment you walk in."

    show expression get_char_sprite("maylene", "default") as maylene at center
    with dissolve

    maylene "Finally. I’m going to get revenge for the humiliation from last time."

    mc "You mean the cheerleader outfit... or what happened when we got back to the gym?"

    narrator "Maylene’s face turns red immediately and she looks away for a second."

    maylene "No need to specify which one. I’m just taking my revenge."

    mc "Alright, miss. Whatever you say."

    maylene "This time it’s a real fight. Until one of us loses."

    mc "You sure I’m ready for that?"

    maylene "Doesn’t matter anymore. This is about getting my honor back."

    hide maylene
    with dissolve
    
    show expression "images/cg/maylene/maylene03.png" as cg_scene
    with dissolve

    narrator "The spar turns into a full fight. Maylene doesn’t hold back at all. By the end you’re on the floor, breathing hard and clearly battered."

    mc "Ow... Did you get your honor back?"

    maylene "Ah... sorry. I went too hard on you. I was still frustrated about last time."

    hide cg_scene
    with dissolve

    mc "Haha, don’t worry. I’m not that hurt."

    maylene "No, I am sorry. It wasn’t even that serious. I just got embarrassed because you brought out a side of me I didn’t know I had... and I took it out on you."

    mc "It’s fine. I get it. I probably pushed you a bit too far too."

    maylene "Come on. Let me help you."

    narrator "Maylene pulls you up and supports you as she leads you toward the showers."

    mc "I’m fine here. I can manage on my own."

    maylene "I’m not leaving you alone. You might hurt yourself in there. Besides, these are the girls’ showers. I have more right to be here than you do."

    show expression "images/cg/maylene/maylene12.png" as cg_scene
    with dissolve

    narrator "She steps into the shower with you and starts taking off her clothes without hesitation. The hot water runs over both of you as she stays close, her touch turning clearly affectionate and intentional."

    show expression "images/cg/maylene/maylene13.png" as cg_scene
    with dissolve

    narrator "She presses her back against your chest, then braces her hands on the wet wall. You enter her from behind with a slow thrust, and a sharp breath leaves her as the water spills over both of you."

    maylene "Hah... Easy at first."

    narrator "She starts pushing back against you, first carefully, then harder. Her rhythm feels a lot like the way she fights: focused, intense, and without holding back."

    maylene "Nnh... That’s it... Don’t go soft on me now."

    narrator "Your hands settle on her hips as she rolls back into every thrust. Water runs down her back and between your bodies, the sound of skin meeting skin mixing with the shower."

    maylene "Ahh... Right there... Keep going."

    narrator "Her moans grow louder, unrestrained. She leans farther into the wall, legs trembling as her pace turns rougher and more desperate."

    maylene "I’m... close...!"

    show expression "images/cg/maylene/maylene13a.png" as cg_scene
    with dissolve

    narrator "Maylene cums hard with a shaky cry, tightening around you as she presses back against you. The sudden pressure pulls you over the edge right after her."

    narrator "You finish deep inside her, holding her up against the wall while both of you shake under the hot water. For a moment she stays there, breathing hard, her forehead resting on her arm."

    maylene "Hehe... I really wanted to do this with you."

    hide cg_scene
    with dissolve

    show expression "images/characters/maylene/empress_outfit_default.png" as maylene at center
    with dissolve

    mc "You could’ve just asked instead of beating me up first."

    maylene "Nah. I think it was good to give you that beating. That way you understand we’re going to do this when *I* want."

    maylene "Now get dressed and sleep well. Tomorrow we’re training twice as hard."

    mc "I don’t think I can train tomorrow. These injuries need to heal."

    maylene "Hmm... Then maybe you should just heal here."

    hide maylene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["maylene"] += 1
    $ affection["maylene"] = min(100, affection["maylene"] + 5)
    $ advance_hint("maylene")
    $ advance_slot(2)

    jump expression "location_" + current_location

