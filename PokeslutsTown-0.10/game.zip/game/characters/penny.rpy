# ============================================================
# POKETOWN, characters/penny.rpy
# ============================================================

label interact_penny:

    $ pending = get_pending_delivery("penny")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            penny "Oh! You brought my order. Thank you!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            penny "I'm still waiting for my order..."
            penny "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("penny", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["penny"]
    $ slot = current_slot
    $ prog = character_progress["penny"]

    if prog == 0:
        jump penny_meeting
    elif prog == 1 and aff >= 10 and loc == "plaza" and slot in [0, 1, 2]:
        jump penny_first_encounter
    elif prog == 2 and aff >= 20 and loc == "forest" and slot in [0, 1]:
        jump penny_second_encounter
    elif prog == 3 and aff >= 35 and loc == "plaza" and slot in [0, 1, 2]:
        jump penny_third_encounter
    elif prog == 4 and aff >= 50 and stat_charisma >= 15 and loc == "studio" and slot in [0, 1, 2]:
        jump penny_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_charisma >= 20 and loc == "studio" and slot in [0, 1, 2]:
        jump penny_fifth_encounter
    elif prog == 6 and aff >= 80 and stat_charisma >= 20 and loc == "studio" and slot in [0, 1, 2]:
        jump penny_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_charisma >= 25 and loc == "studio" and slot in [0, 1, 2] and "penny_cosplay" in unlocked_skins["penny"]:
        jump penny_seventh_encounter
    else:
        jump penny_contextual_dialogue


# ------------------------------------------------------------
# CONTEXTUAL DIALOGUE
# ------------------------------------------------------------

label penny_contextual_dialogue:

    show expression get_char_sprite("penny", "default") as penny at center
    with dissolve
    $ affection["penny"] = min(100, affection["penny"] + 3)

    if aff_tier == "stranger":
        if loc == "studio":
            penny "Oh! Sorry, I didn't hear you come in."
            penny "I'm Penny. This is my studio. Try not to move anything."
        else:
            penny "Hi. I'm Penny. I do photography."
            penny "If you ever want portraits done, come by the studio."

    elif aff_tier == "acquaintance":
        if loc == "studio":
            penny "You have a good eye for light. I noticed."
        elif loc == "plaza":
            penny "I'm looking for interesting compositions. Everything's a potential shot."
        else:
            penny "Hey! I actually thought about taking your photo the other day."
            penny "You have interesting features."

    elif aff_tier == "friend":
        if loc == "studio":
            penny "I printed one of the photos from last time. Want to see?"
        elif loc == "cafe":
            penny "I people-watch here. You're more interesting than most."
        else:
            penny "I don't show my personal work to many people. But I'd show you."

    else:
        if loc == "studio":
            penny "You're my favorite subject. Don't tell my other clients."
            penny "Actually, I don't have other clients right now. So."
        else:
            penny "Every time I look through my lens now I think about how I'd show you the shot."

    hide penny
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label penny_meeting:

    show expression get_char_sprite("penny", "default") as penny at center
    with dissolve

    penny "What do you need? Sorry, I'm in the middle of taking some photos. Please don't bother me right now."

    hide penny
    with dissolve

    $ affection["penny"] = min(100, affection["penny"] + 5)
    $ character_progress["penny"] += 1
    $ advance_hint("penny")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label penny_first_encounter:

    scene bg plaza_day
    with fade

    narrator "You're sitting in the plaza, enjoying the warm sunlight and the calm atmosphere, a welcome change from your old life in the city."

    narrator "You feel a light tap on your back."

    show expression get_char_sprite("penny", "default") as penny at center
    with dissolve

    penny "Um... excuse me? You're in my shot."

    narrator "You turn around to see a girl with a soft, almost shy voice holding a camera."

    mc "Oh, sorry about that."

    narrator "You quickly move aside. She tries to reposition herself, adjusting her angle with clear frustration."

    penny "Ugh... it's too late now. The light isn't right anymore. I'll have to come back tomorrow."

    narrator "She lowers her camera and gives you a slightly annoyed look."

    mc "Hey, don't be mad. I didn't know you needed that exact spot at that exact second."

    penny "You're right... I'm sorry. It's just that I've been trying to get this particular shot for days."

    mc "The spot is still here. You can take it now, can't you?"

    penny "It's not the same. The lighting changed. You wouldn't understand..."

    mc "You're a bit of a perfectionist, huh?"

    penny "Maybe... I just like things to be a certain way."

    narrator "She gives you one last mildly irritated glance before walking away, clearly still bothered by the missed opportunity."

    hide penny
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["penny"] += 1
    $ affection["penny"] = min(100, affection["penny"] + 5)
    $ advance_hint("penny")
    $ advance_slot(2)

    jump location_plaza


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label penny_second_encounter:

    scene bg forest_day
    with fade

    narrator "While exploring the forest, you notice a series of faint flashes coming from some bushes ahead."

    narrator "Curious, you approach quietly. Peeking through the foliage, you find Penny crouched down, carefully aiming her camera at some wild Pokémon."

    show expression "images/cg/penny/Penny01.png" as cg_scene
    with dissolve

    mc "Boo!"

    penny "Kyaaah!!"

    narrator "Penny jumps violently, nearly dropping her camera. Her face turns bright red in an instant."

    penny "W-what are you doing?! You can't just sneak up on people like that!"

    mc "Sorry, sorry. I saw the flashes and got curious. Didn't mean to scare you."

    narrator "You glance at what she was photographing."

    mc "Ah... so that's why you're so embarrassed. You didn't want me seeing what you were shooting."

    penny "T-that's not it at all! I'm just... studying the local Pokémon! Collecting data, that's all!"

    narrator "She fumbles with her camera, clearly flustered."

    penny "Now go away! You're going to scare them off with all that noise..."

    mc "If they didn't run when you screamed, I think they're fine."

    penny "Ugh... Whatever. I'm done for today anyway."

    narrator "Mortified, Penny quickly gathers her things and hurries away from the spot without looking back."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["penny"] += 1
    $ affection["penny"] = min(100, affection["penny"] + 5)
    $ advance_hint("penny")
    $ advance_slot(2)

    jump location_forest


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label penny_third_encounter:

    scene bg plaza_day
    with fade

    narrator "You run into Penny in the plaza again. She's holding her camera, seemingly searching for the perfect angle."

    show expression get_char_sprite("penny", "default") as penny at center
    with dissolve

    mc "Looking for another perfect shot today?"

    penny "Eep! Don't sneak up on me like that! You scared me again..."

    mc "Sorry. I thought you saw me coming."

    penny "Well, I didn't... And no, I'm not taking *that* kind of photo again. That was a one-time thing."

    mc "A one-time thing? I thought you really wanted that specific shot. You made me move and everything."

    penny "O-oh... right. Yes, that photo. Of course."

    narrator "Penny fidgets nervously, clearly embarrassed."

    mc "Wait... don't tell me you meant something completely different."

    penny "I-I didn't mean anything! I'm just taking normal photos, okay?!"

    narrator "You notice she's also carrying several heavy grocery bags."

    mc "Looks like photography isn't the only thing on your schedule today."

    penny "Ah, these? I just did some shopping. I walked by and the lighting was nice, so I stopped for a moment..."

    mc "That's a lot of bags for one person. Want some help carrying them?"

    penny "R-really? That would be amazing, thank you..."

    narrator "You end up walking with Penny to her house. When you arrive, you're surprised to see it's the largest and most elegant house in town."

    mc "You live *here*? Photography must pay really well."

    penny "It... depends on the kind of photography."

    narrator "Inside, the living room has been converted into a professional photography studio with lights, backdrops, and equipment."

    narrator "What really catches your attention is an oddly shaped toy sitting prominently in the middle of the set, clearly not meant for innocent photography."

    mc "Right... I think I understand what kind pays the bills."

    penny "T-that's not! It's not what it looks like! I was just... um..."

    narrator "Penny's face turns bright red. She dashes forward, grabs the toy, and runs to her room without finishing the sentence."

    narrator "You leave the groceries by the entrance and quietly let yourself out."

    hide penny
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["penny"] += 1
    $ affection["penny"] = min(100, affection["penny"] + 5)
    $ advance_hint("penny")
    $ advance_slot(2)

    jump location_plaza


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label penny_fourth_encounter:

    scene bg studio
    with fade

    narrator "To your surprise, Penny actually calls you to her house. Given how shy she usually is, you didn't expect her to reach out first."

    show expression get_char_sprite("penny", "default") as penny at center
    with dissolve

    penny "O-oh... you actually came. Um, come in, please."

    narrator "You step inside her studio. Penny fidgets nervously, clearly uncomfortable with the situation."

    mc "So... why did you call me?"

    penny "Well... it's pretty obvious you already saw what kind of photos I take. And as embarrassing as this is to admit... I could really use some help with the camera."

    penny "It's hard doing everything by myself when I'm both the photographer and the model..."

    mc "You want me to take photos of you?"

    penny "Y-yes... Just that. Don't get any weird ideas! I'm not into guys like you or anything!"

    mc "Relax, it was just a joke. You really don't have to get so defensive."

    penny "I-I'm not being defensive! I'm just... setting boundaries!"

    narrator "Despite her flustered protests, you end up helping Penny with her photo session. She spends most of the time blushing and giving very specific instructions about angles and lighting."

    hide penny
    with dissolve

    show expression "images/cg/penny/Penny02.png" as cg_scene
    with dissolve

    narrator "Penny is visibly nervous as she slowly undresses in front of you. Her cheeks are already bright red."

    narrator "She lies down on the bed and, after a moment of hesitation, shyly spreads her legs toward the camera."

    penny "D-don't stare too much... just take the photos, okay?"

    narrator "With trembling hands, she picks up a medium-sized toy and presses it against her entrance. She bites her lip as she slowly pushes it inside herself."

    narrator "Her face turns an even deeper shade of red. She avoids looking directly at you or the camera, clearly mortified but determined to continue."

    narrator "She begins moving the toy in and out with slow, unsteady movements. Soft, embarrassed whimpers escape her lips as her breathing grows heavier."

    penny "Nngh... Is this... angle okay...?"

    narrator "You take photos from different angles as she requested, the camera clicking softly in the quiet room. Penny's body trembles slightly with every thrust of the toy."

    narrator "Despite her intense embarrassment, her movements gradually become a little bolder as pleasure starts to overtake her shyness."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["penny"] += 1
    $ affection["penny"] = min(100, affection["penny"] + 5)
    $ advance_hint("penny")
    $ advance_slot(2)

    jump location_studio


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label penny_fifth_encounter:

    scene bg studio
    with fade

    narrator "You arrive at Penny's studio for another photo session. She seems different today, restless and clearly dissatisfied."

    show expression get_char_sprite("penny", "default") as penny at center
    with dissolve

    mc "Is everything okay? You look a bit off today."

    penny "Not really... I've been doing the same kind of photos for so long that it's starting to feel repetitive. Even my subscribers are getting bored. I've been losing quite a few lately..."

    mc "Hmm... Would you like to try something different?"

    penny "I... I've been thinking about it. Something more... real."

    mc "And you want my help with that?"

    penny "N-no! I mean... yes, but not like that! You already know what I mean..."

    narrator "Penny fidgets nervously before reaching into a drawer and handing you a folder."

    penny "Here... this."

    narrator "You open the folder. Inside are printed messages from her subscribers and some very explicit ideas for future content."

    mc "Wow... This is quite a step up. Are you sure your audience is ready for this?"

    penny "They've been asking for it a lot recently. That's... kind of what made me start considering it."

    mc "Alright. If you really want to do this, I'll help you like always. Camera, lighting, everything."

    narrator "Penny brings out a much larger and strangely shaped toy for the session. She's visibly nervous, but there's also a spark of genuine excitement in her eyes."

    hide penny
    with dissolve

    show expression "images/cg/penny/Penny03.png" as cg_scene
    with dissolve

    narrator "Penny gets on all fours on the bed at first, but after a moment of hesitation, she turns around and lowers herself onto the large toy in reverse cowgirl position."

    narrator "She bites her lip as she slowly sinks down onto it. The thick, strangely shaped toy stretches her noticeably with every inch she takes in."

    penny "Haa... It's... really big..."

    narrator "With shaky hands, she starts moving her hips up and down. You take photos from behind as requested, the camera clicking softly in the quiet room."

    narrator "Penny’s breathing quickly becomes much heavier. Soft, embarrassed moans escape her lips as she rides the toy deeper."

    penny "Nngh... D-don't take too many from that angle..."

    narrator "Despite her shyness, her body starts moving with more need. Her back arches as she tries to take as much of the toy as she can, her hips rolling desperately."

    narrator "Her legs begin to tremble. She grips the sheets tightly, her moans growing louder and less controlled."

    penny "Ahh...! I-I'm... I'm going to..."

    show expression "images/cg/penny/Penny03a.png" as cg_scene
    with flash

    narrator "Penny reaches a powerful climax, her whole body shaking as she rides the toy through her orgasm. Her soft, embarrassed cries fill the studio as waves of pleasure wash over her."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["penny"] += 1
    $ affection["penny"] = min(100, affection["penny"] + 5)
    $ advance_hint("penny")
    $ advance_slot(2)

    jump location_studio


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label penny_sixth_encounter:

    scene bg studio
    with fade

    narrator "You arrive at Penny's studio for another session. This time she greets you with an unusually bright smile."

    show expression get_char_sprite("penny", "default") as penny at center
    with dissolve

    penny "Hiii! You're here!"

    mc "Someone's in a really good mood today."

    penny "I am! You won't believe it, the last photos we took got so many likes! I actually doubled my subscriber count!"

    mc "That's amazing, Penny. Congratulations."

    penny "Thank you... Really. I never would have dared to post something like that without your help."

    narrator "She fidgets with her hands, looking both excited and a little shy."

    penny "So... I wanted to do something nice for you. I know you've been wanting this for a while..."

    mc "Oh? I'm listening."

    penny "D-don't get too cocky! But yes... if you want, we can do something more... intimate today."

    mc "I'm definitely not going to say no."

    penny "Good! But even if we're... doing that, the photos still have to turn out well, okay? So you'll have to work twice as hard."

    mc "You want to take photos while we do it?"

    penny "Of course! I have to get something good out of your 'reward' too, right?"

    mc "Fair enough. I'll do my best."

    narrator "Penny's face is flushed, but she looks determined as she climbs onto the bed and pulls you with her."

    hide penny
    with dissolve

    show expression "images/cg/penny/Penny04.png" as cg_scene
    with dissolve

    narrator "Penny straddles your hips, her face already bright red. With shaky hands, she guides your cock to her entrance and slowly lowers herself onto you."

    penny "Haa... It's... really deep like this..."

    narrator "She places her hands on your chest for support and begins moving her hips in small, hesitant motions. She avoids looking directly at you, clearly embarrassed."

    narrator "As she grows more comfortable, her movements become deeper and faster. Her breathing turns ragged and she bites her lip hard, trying to suppress her moans."

    penny "Nngh... D-don't stare at me like that..."

    narrator "Despite her embarrassment, her body starts moving with more need. Her breasts bounce softly with every rise and fall of her hips as she rides you."

    narrator "Her moans gradually escape despite her efforts to stay quiet. Her face is flushed all the way to her ears."

    penny "Ahh...! I-I'm... I'm getting close..."

    show expression "images/cg/penny/Penny04a.png" as cg_scene
    with flash

    narrator "Penny suddenly tenses up. She cums hard on top of you, her whole body shaking as she tries (and fails) to hold back her voice."

    narrator "Even through her orgasm, she keeps moving her hips until you reach your limit as well. With a final, deep thrust, you cum inside her."

    penny "Haaah... Haaah... That was... too much..."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["penny"] += 1
    $ affection["penny"] = min(100, affection["penny"] + 5)
    $ advance_hint("penny")
    $ advance_slot(2)

    jump location_studio


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label penny_seventh_encounter:

    scene bg studio
    with fade

    narrator "You arrive at Penny's studio ready for another session, but she stops you before you can even set up the lights."

    show expression get_char_sprite("penny", "default") as penny at center
    with dissolve

    penny "Wait! Um... I have an idea for something different today."

    mc "Oh? What did you have in mind?"

    penny "Well... what if we did the session outside this time? In the forest. It would give it a more... wild and natural feel."

    mc "You're really stepping out of your comfort zone lately. I'm in if that's what you want."

    penny "Y-yeah... I've been thinking about it a lot. Let's go before I change my mind."

    narrator "You head into the forest with Penny. After walking for a while, you find a beautiful, secluded clearing with soft sunlight filtering through the trees."

    narrator "Once there, Penny changes into a cute Eevee costume. She looks incredibly embarrassed but also excited."

    hide penny
    with dissolve

    show expression "images/cg/penny/Penny05.png" as cg_scene
    with dissolve

    narrator "Penny bends over in front of you, her face bright red. With shaky hands."

    penny "H-haa... This feels so weird... but kind of cute, right?"

    narrator "The fluffy tail sways gently behind her as she gets down on all fours in the grass. She looks back at you, embarrassed but clearly excited."

    penny "D-don't stare too much... Just... be gentle at first, okay?"

    narrator "You position yourself behind her and slowly enter her in doggy style. Penny lets out a soft, embarrassed moan as you fill her."

    narrator "With every thrust, the fluffy tail bounces and sways cutely behind her, adding a strangely adorable touch to the lewd scene."

    penny "Nngh... Ahh... The tail makes it feel even more... intense..."

    narrator "You grip her hips and start thrusting deeper. Penny's soft moans grow louder, mixing with the sound of skin against skin in the quiet forest clearing."

    penny "Mmmh...! Harder... but don't pull the tail..."

    narrator "Her body trembles more and more with each thrust. The fluffy tail shakes wildly as she gets closer to the edge."

    penny "Ahh! I'm... I'm cumming...!"

    show expression "images/cg/penny/Penny05.png" as cg_scene
    with flash

    narrator "Penny cums hard, her whole body shaking violently as she grips the grass. The fluffy tail twitches and sways with every spasm of her orgasm."

    narrator "The sight and feeling push you over the edge right after her. You thrust deep and cum inside her, holding her hips tightly as you both ride out your pleasure."

    narrator "Afterward, you both clean up the area and Penny quickly fixes her costume, still blushing furiously."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["penny"] += 1
    $ affection["penny"] = min(100, affection["penny"] + 5)
    $ advance_hint("penny")
    $ advance_slot(2)

    jump location_studio
