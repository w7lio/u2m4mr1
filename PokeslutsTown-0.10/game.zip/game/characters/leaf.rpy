# ============================================================
# POKETOWN, characters/leaf.rpy
# ============================================================

label interact_leaf:

    $ pending = get_pending_delivery("leaf")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            leaf "Oh! You brought my order. Thanks!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            leaf "Still waiting on that order..."
            leaf "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("leaf", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["leaf"]
    $ slot = current_slot
    $ prog = character_progress["leaf"]

    if prog == 0:
        jump leaf_meeting
    elif prog == 1 and aff >= 10 and stat_charisma >= 10 and loc == "shopping_center" and slot in [0, 1, 2]:
        jump leaf_first_encounter
    elif prog == 2 and aff >= 20 and stat_charisma >= 15 and loc == "shopping_center" and slot in [0, 1, 2]:
        jump leaf_second_encounter
    elif prog == 3 and aff >= 35 and loc == "plaza" and slot in [0, 1, 2]:
        jump leaf_third_encounter
    elif prog == 4 and aff >= 50 and loc == "shopping_center" and slot in [0, 1, 2]:
        jump leaf_fourth_encounter
    elif prog == 5 and aff >= 65 and loc == "home_delia_leaf" and slot in [0, 1, 2]:
        jump leaf_fifth_encounter
    elif prog == 6 and aff >= 80 and loc == "shopping_center" and slot in [0, 1, 2]:
        jump leaf_sixth_encounter
    elif prog == 7 and aff >= 95 and loc == "plaza" and slot in [0, 1]:
        jump leaf_seventh_encounter
    else:
        jump leaf_contextual_dialogue


# ------------------------------------------------------------
# CONTEXTUAL DIALOGUE
# ------------------------------------------------------------

label leaf_contextual_dialogue:

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve
    $ affection["leaf"] = min(100, affection["leaf"] + 3)

    if aff_tier == "stranger":
        if loc == "home_delia_leaf":
            leaf "Oh. Mom didn't say we were having company."
            leaf "I'm Leaf. Sorry about the mess, that's hers not mine."
        elif loc == "forest":
            leaf "You hike too? Most people in town don't bother."
            leaf "I'm Leaf."
        else:
            leaf "Hey. You're new here."
            leaf "I'm Leaf. Welcome to the smallest town you've ever been to, probably."

    elif aff_tier == "acquaintance":
        if loc == "forest":
            leaf "You're getting further in each time. I've noticed."
        elif loc == "plaza":
            leaf "I come here when the house gets too quiet."
            leaf "Mom means well but she hovers."
        else:
            leaf "Hey! How's farm life treating you?"

    elif aff_tier == "friend":
        if loc == "forest":
            leaf "I know a path that goes all the way to the ridge. Nobody else knows it."
            leaf "Want to see it sometime?"
        elif loc == "home_delia_leaf":
            leaf "You're the only person I actually want to see when they knock on that door."
        else:
            leaf "You're surprisingly easy to talk to. I don't say that about many people."

    else:
        if loc == "forest":
            leaf "This is my place. And I want you in it."
        else:
            leaf "I used to think small towns were suffocating."
            leaf "They're better with the right person in them."

    hide leaf
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label leaf_meeting:

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "Hey, you're the new farmer, right? I'm Leaf."
    leaf "Hey, do you have any spare coins? I'm looking at something in that shop and I'm a little short."

    mc "You just met me and you're already asking for money?"

    leaf "I saw you were new and figured you might be generous. Besides, it's not that much. Yes or no?"

    narrator "She looks at you with a completely shameless smile, not a hint of embarrassment."

    hide leaf
    with dissolve

    $ affection["leaf"] = min(100, affection["leaf"] + 5)
    $ character_progress["leaf"] += 1
    $ advance_hint("leaf")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label leaf_first_encounter:

    if gallery_replay:
        $ money += 80

    if money < 80:
        show expression get_char_sprite("leaf", "default") as leaf at center
        with dissolve
        leaf "Hey, I need someone with some cash today. Come back when you're less broke."
        hide leaf
        with dissolve
        jump location_shopping_center

    scene bg shopping_center_day
    with fade

    narrator "While walking through the shopping center, you spot Leaf standing in front of a store window, staring intently at something inside."

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    mc "Aren't you the girl who asked me for money the other day?"

    leaf "Oh hey, it's the farmer boy! Yeah, that was me."

    narrator "She barely glances at you before pointing at a stylish bag displayed in the window."

    leaf "Look at this. It's perfect. I need it."

    mc "Need it... or just really want it?"

    leaf "Same difference to me. The problem is I already ran out of money this week."

    mc "How are you out of money already? I only just got here and you've already tried to hit me up once."

    leaf "Because money disappears too fast! There’s way too many cute things in the world. It’s not my fault."

    mc "And what exactly do you want me to do about it?"

    leaf "Well... obviously buy it for me?"

    mc "Why would I do that?"

    leaf "Because I'm charming and I deserve nice things."

    narrator "She says it with complete confidence, not a hint of shame or irony."

    mc "That's not really an argument."

    leaf "It worked on my mom for eighteen years. You'll be easier, I can tell."

    mc "You don't even know me."

    leaf "Not yet~" 

    narrator "She flashes you a cheeky grin and looks back at the bag with longing eyes."

    narrator "Somehow, against your better judgment, you end up buying the bag for her."

    leaf "I knew you were a good person! Thank you~"

    leaf "Hey, are you hungry? There's a really good place nearby. Let's go!"

    mc "And who's paying for lunch?"

    leaf "You just bought me a bag. What's the difference?"

    narrator "You end up having lunch with Leaf. She talks non-stop the entire time, about clothes, shops, things she wants, things she already has but still wants more of. It's exhausting... but strangely entertaining."

    hide leaf
    with dissolve

    $ money -= 80

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["leaf"] += 1
    $ affection["leaf"] = min(100, affection["leaf"] + 5)
    $ advance_hint("leaf")
    $ advance_slot(2)

    jump location_shopping_center


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label leaf_second_encounter:

    if gallery_replay:
        $ money += 120

    if money < 120:
        show expression get_char_sprite("leaf", "default") as leaf at center
        with dissolve
        leaf "Hey, I need someone with some cash today. Come back when you're less broke."
        hide leaf
        with dissolve
        jump location_shopping_center

    scene bg shopping_center_day
    with fade

    narrator "Leaf sends you a message telling you to meet her at the mall. She doesn't ask, she simply informs you."

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "You're here. Good. There's a huge sale today and I need someone strong to carry my bags."

    mc "Is that all you need from me?"

    leaf "For now, yes. Try to keep up."

    narrator "You end up spending the entire afternoon following Leaf from store to store. She shops with laser focus, handing you bags without a second thought and constantly dragging you into fitting rooms for opinions."

    leaf "This one or the blue one?"

    mc "The blue one looks better."

    leaf "Wrong. I'm getting this one."

    mc "Then why even ask me?"

    leaf "So I can ignore your opinion, obviously. It helps me feel sure about my choice."

    narrator "By the end of the day, you're both loaded with shopping bags. Leaf is in an excellent mood."

    narrator "Just as you're about to leave the mall, she stops in front of a lingerie store and walks in without saying a word, glancing back at you expectantly."

    mc "You want me to go in here too?"

    leaf "Shh. Just come and give me your honest opinion."

    narrator "Inside the store, Leaf browses the lingerie with the same casual confidence she showed with clothes and accessories. No shame whatsoever."

    leaf "What about this one?"

    mc "Yeah, that looks good."

    leaf "You sure?"

    mc "I'm sure."

    leaf "Perfect. You're buying it for me."

    mc "Leaf..."

    leaf "Come on, it's more fun this way. Don't ruin the moment."

    narrator "Somehow, you end up buying the lingerie for her. Leaf drops it into one of her bags like it's the most normal thing in the world."

    narrator "Once outside the mall, she turns to you with a mischievous smile."

    leaf "My mom's not home until late tonight. Want to come over?"

    mc "To do what exactly?"

    leaf "So you can watch me try this on, obviously."

    narrator "She says it so casually that it takes you a second to process."

    leaf "Unless you're scared~"

    narrator "You end up going to her house. The moment the door to her room closes, Leaf wastes no time following through on her suggestion."

    hide leaf
    with dissolve

    show expression "images/cg/leaf/Leaf01.png" as cg_scene
    with dissolve

    narrator "The moment you enter Leaf's room and close the door, she pushes you playfully onto the bed."

    narrator "With a mischievous grin, she kneels between your legs and quickly pulls down your pants, freeing your cock."

    leaf "Let's see what we've got here~"

    narrator "She wraps her soft hand around your shaft and starts stroking you slowly at first, her movements confident and teasing."

    narrator "She looks up at you the entire time with that shameless, playful smile, clearly enjoying your reactions."

    leaf "Mmm, you're already this hard? Cute."

    narrator "Her hand moves with practiced ease, sometimes slow and deliberate, sometimes faster, occasionally twisting gently as she strokes."

    narrator "Before long she adds her second hand, using both to pleasure you while maintaining eye contact."

    leaf "Does that feel good? You look like you're having trouble holding it together."

    narrator "She speeds up her movements when she feels you throbbing in her hands, her grip firm and eager."

    leaf "Come on... Don't hold back. I want to see it."

    show expression "images/cg/leaf/Leaf01a.png" as cg_scene
    with flash

    narrator "With a few final quick strokes, you can't hold it anymore. You cum hard, shooting thick ropes across her hands and fingers."

    narrator "Leaf lets out a soft, satisfied laugh as she watches you finish, clearly pleased with herself."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "Wow... Look at the mess you made. Not bad, farmer boy."

    mc "That's all you've got?"

    leaf "For now. We'll see if you improve."

    hide leaf
    with dissolve

    $ money -= 120

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["leaf"] += 1
    $ affection["leaf"] = min(100, affection["leaf"] + 5)
    $ advance_hint("leaf")
    $ advance_slot(2)

    jump location_shopping_center


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label leaf_third_encounter:

    scene bg plaza_day
    with fade

    narrator "You run into Leaf in the plaza. She's carrying a new shopping bag and has that familiar look of someone who definitely spent money she shouldn't have."

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    mc "More shopping?"

    leaf "It was an amazing sale. I couldn't just walk past it."

    mc "With what money this time?"

    leaf "This week's allowance. Which is now officially gone."

    mc "Leaf..."

    leaf "What? Don't give me that look." 

    narrator "She steps closer with a cheeky grin."

    leaf "Hey, my mom's not home right now. Come over."

    mc "Straight to the point, huh?"

    leaf "I know what I want. Are you coming or are you going to keep lecturing me?"

    narrator "You end up going with her. The moment you're inside her room, Leaf pulls out the lingerie you bought her last time and holds it up proudly."

    leaf "See? I told you it looked good on me."

    mc "It does look really good."

    leaf "I know~"

    narrator "She tosses the lingerie aside and looks at you with a playful, mischievous spark in her eyes."

    leaf "But today I want to try something else."

    mc "What is it?"

    leaf "You'll see. Just relax... and follow my lead."

    hide leaf
    with dissolve

    show expression "images/cg/leaf/Leaf02.png" as cg_scene
    with dissolve

    narrator "True to form, Leaf takes full control with the same shameless confidence she always shows."

    narrator "She quickly strips off her clothes and pushes you back against the wall with a playful yet determined shove."

    leaf "Stay right there..."

    narrator "She lifts one leg, wrapping it around your waist, and presses her body against yours. Her skin feels hot and smooth."

    leaf "Hold my leg up."

    narrator "You grip her raised thigh as she reaches down, guiding your cock to her entrance. With a soft moan, she sinks down onto you, taking you inside her tight, wet pussy."

    leaf "Mmmh... Fuck, that's good..."

    narrator "She clings to your shoulders, her nails digging in slightly as she starts moving her hips. You thrust up into her while holding her leg, fucking her against the wall in a standing position."

    leaf "Ahh...! Harder... Don't be gentle with me."

    narrator "Leaf's moans grow louder and needier with every thrust. Her body bounces against yours, her breathing ragged as she takes you deeper."

    leaf "Nngh! Yes... Just like that... Fuck me harder!"

    narrator "She gets noticeably tighter around you, her leg squeezing your waist as pleasure builds rapidly. Her shameless moans fill the room."

    leaf "I'm close... Don't stop! Cum inside me...!"

    narrator "With a loud cry, Leaf reaches her climax first, her pussy clenching rhythmically around your cock. The intense contractions push you over the edge right after her."

    narrator "You thrust deep and cum hard inside her, filling her as both of you ride out a powerful orgasm together, still pressed against the wall."


    hide cg_scene
    with dissolve

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "Haaah... Haaah... Not bad... Not bad at all~"

    mc "Glad to hear it."

    leaf "Hey, will you come to the mall with me next week? There's a new store opening."

    mc "What if I say no?"

    leaf "Nothing. But it'd be a shame because you're actually starting to grow on me."

    narrator "She says it while tidying her room, back turned, like it's nothing. But she says it."

    hide leaf
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["leaf"] += 1
    $ affection["leaf"] = min(100, affection["leaf"] + 5)
    $ advance_hint("leaf")
    $ advance_slot(2)

    jump location_plaza


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label leaf_fourth_encounter:

    if gallery_replay:
        $ money += 60

    if money < 60:
        show expression get_char_sprite("leaf", "default") as leaf at center
        with dissolve
        leaf "Hey, I need someone with some cash today. Come back when you're less broke."
        hide leaf
        with dissolve
        jump location_shopping_center

    scene bg shopping_center_day
    with fade

    narrator "You meet Leaf at the mall as planned. She arrives with her usual energy and a new shopping list, but today she seems more talkative than normal, and not just about clothes."

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "So... did you really come all the way out here just to be a farmer? Don't you get bored?"

    mc "Not yet."

    leaf "How? There's nothing to do around here."

    mc "There are a few reasons."

    leaf "Like what?"

    mc "Like this conversation, for example."

    leaf "Ugh, that was so cheesy."

    narrator "She rolls her eyes, but there's a small smile on her lips."

    mc "You asked."

    narrator "Later, while standing in front of a shop window, Leaf stares at an item but doesn't ask you to buy it. She just looks."

    mc "Don't you want it?"

    leaf "Yeah, I do... but not today."

    mc "That's new. What's going on with you?"

    leaf "Nothing. Sometimes I don't need everything to be a transaction, you know."

    narrator "She glances at you sideways. For once, she sounds sincere."

    narrator "As you continue walking, Leaf quietly slips her arm around yours without saying a word."

    narrator "That afternoon, once you're back in her room, Leaf pulls out something she had bought on her own and had been saving for today."

    narrator "This time the atmosphere feels different, there's more ease, less urgency. She still wants to be in control, but she allows you to take the lead more than usual."

    hide leaf
    with dissolve

    show expression "images/cg/leaf/Leaf03.png" as cg_scene
    with dissolve

    narrator "Leaf pushes you onto the bed with a confident smirk and climbs on top of you, straddling your hips."

    narrator "She takes her time lowering herself onto your cock, sinking down slowly until you're buried deep inside her."

    leaf "Mmm... Fuck, you feel good today..."

    narrator "She starts riding you in cowgirl position with smooth, deliberate movements. Her hands rest on your chest as she rolls her hips in slow, teasing circles."

    leaf "You like it when I take control, don't you?"

    narrator "She leans down and kisses you deeply, her tongue playing with yours while she continues moving her hips. The kiss grows more passionate as her pace quickens."

    leaf "Nngh... Harder... I want it deeper..."

    narrator "Her movements become faster and more intense. She rides you with growing urgency, her moans spilling into your mouth."

    leaf "Ahh...! Yes... Just like that... Don't stop..."

    narrator "Her body starts trembling. She breaks the kiss and sits up straight, riding you harder as she chases her pleasure."

    leaf "I'm gonna cum... Stay right there, Ahh!"

    narrator "Leaf cums first, her pussy clenching tightly around you as her body shakes on top of you. Her moans are loud and shameless."

    narrator "Even after her orgasm, she doesn't stop. She keeps riding you through the aftershocks until you finally reach your limit."

    leaf "Cum inside me... I want to feel it..."

    show expression "images/cg/leaf/Leaf03a.png" as cg_scene
    with flash

    narrator "With a groan, you thrust up into her and cum hard, filling her deeply as she grinds down on you."

    leaf "Haaah... Not bad at all~"

    hide cg_scene
    with dissolve

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "Hey."

    mc "Hm?"

    leaf "You don't only come see me for this, right?"

    mc "No. That's not the only reason."

    leaf "Good... Because I don't only look for you when I want money or gifts."

    mc "I know."

    leaf "Wait... You actually knew?"

    mc "Yeah, I did."

    narrator "Leaf goes quiet for a rare moment. She looks at you with an expression that's hard to read, a mix of surprise and something softer."

    leaf "...Okay. Just checking."

    hide leaf
    with dissolve

    $ money -= 60

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["leaf"] += 1
    $ affection["leaf"] = min(100, affection["leaf"] + 5)
    $ advance_hint("leaf")
    $ advance_slot(2)

    jump location_shopping_center


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label leaf_fifth_encounter:

    scene bg delia_home
    with fade

    narrator "Out of nowhere on a Tuesday morning, you receive a message from Leaf: \"My mom leaves in an hour. Hurry up.\""

    narrator "You arrive in less than twenty minutes. The door opens before you even knock. Leaf quickly pulls you inside and closes the door, glancing out to the street to make sure no one saw you."

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    mc "Good morning to you too."

    leaf "Shh. Get in already."

    narrator "She practically drags you upstairs to her room. You can tell from her energy that she's been thinking about this for a while."

    leaf "I want to try something today."

    mc "What is it?"

    leaf "Something I've been wanting to do with you specifically. Not just anyone."

    mc "With me specifically?"

    leaf "Don't let it go to your head, idiot."

    mc "Too late."

    leaf "Ugh, shut up and listen."

    narrator "Leaf takes full control from the very beginning, with a rare intensity and clarity in her eyes. This time she seems more determined than ever."

    narrator "The moment the door closes, she jumps into your arms and wraps both legs tightly around your waist."

    hide leaf
    with dissolve

    show expression "images/cg/leaf/Leaf04.png" as cg_scene
    with dissolve

    narrator "You turn her body and press her back against your chest. She lifts her arms, and you hook them behind her head in a full nelson hold, locking your hands behind her neck."

    leaf "Yeah... Like this. Hold me tight."

    narrator "Supporting her full weight, you thrust upward and enter her deeply in one smooth motion. Leaf lets out a loud, surprised moan as you fill her completely."

    leaf "Ahh! Fuck... So deep...!"

    narrator "You start fucking her hard in full nelson position, her body bouncing helplessly with every powerful thrust. Her legs dangle in the air as you hold her completely suspended."

    leaf "Nngh! Harder...! Don't you dare hold back!"

    narrator "Leaf's moans grow louder and more desperate. Her tight pussy clenches around you as you pound into her, the position allowing you to reach incredibly deep."

    leaf "Ahh...! Shit, you're so deep like this... Mmmh!"

    narrator "Her body trembles in your arms. She tries to move her hips but can barely do anything except take everything you give her."

    leaf "I'm gonna cum... Don't stop! I'm cumming!!"

    show expression "images/cg/leaf/Leaf04a.png" as cg_scene
    with flash

    narrator "Leaf cums hard, her whole body shaking violently in your full nelson hold. Her loud moans echo through the room as her pussy spasms around your cock."

    narrator "The intense contractions push you over the edge. You thrust deep one final time and cum hard inside her, filling her while still holding her suspended in the air."

    leaf "Haaah... Haaah... Fuck... That was intense..."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "I definitely wanted to do that."

    mc "How long have you been thinking about it?"

    leaf "Since the second time we met, more or less."

    mc "Took you long enough."

    leaf "I had to make sure you deserved it, obviously."

    mc "And? Do I?"

    leaf "Today... yeah. You did."

    narrator "Leaf looks away for a second, almost embarrassed by her own admission. It's a rare sight."

    narrator "As you're about to leave, she stops you right at the door."

    leaf "Hey. Next week is my birthday."

    mc "What do you want?"

    leaf "Something nice from that new store in the mall... and for you to show up."

    mc "In that order of importance?"

    narrator "Leaf gives you a playful smirk but doesn't answer. Instead, she gently pushes you out and starts closing the door."

    leaf "Don't be late."

    hide leaf
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["leaf"] += 1
    $ affection["leaf"] = min(100, affection["leaf"] + 5)
    $ advance_hint("leaf")
    $ advance_slot(2)

    jump location_home_delia_leaf


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label leaf_sixth_encounter:

    if gallery_replay:
        $ money += 150

    if money < 150:
        show expression get_char_sprite("leaf", "default") as leaf at center
        with dissolve
        leaf "Hey, it's my birthday. Don't show up empty handed."
        hide leaf
        with dissolve
        jump location_shopping_center

    scene bg shopping_center_day
    with fade

    narrator "For Leaf's birthday, you meet her at the mall. You arrive carrying the gift you'd already bought for her."

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    narrator "She doesn't even wait to find a bench. She opens the gift right there in the middle of the corridor, tearing the wrapping without hesitation."

    leaf "Oh... Perfect. I knew you'd get it right if I gave you good instructions."

    mc "You're welcome."

    leaf "Thank you. Really."

    narrator "She says it unusually soft, without any sarcastic remark afterwards. For a moment, the usual bravado disappears."

    narrator "You walk through the mall together, but today Leaf buys much less than usual. She seems more interested in talking than shopping."

    leaf "Hey... Are you planning on staying in town for a long time?"

    mc "I don't know yet. Why?"

    leaf "No reason. Just curious."

    mc "Leaf."

    leaf "What? It really is just curiosity, okay?"

    narrator "She looks away, clearly a little embarrassed by her own question."

    narrator "Later, in her room with the whole afternoon free because her mom would be back late, Leaf feels different. Calmer. More present."

    leaf "No rush this time... okay?"

    mc "No rush?"

    leaf "Yeah. I want to take our time today."

    narrator "It's the first time she's ever asked for that."

    hide leaf
    with dissolve

    show expression "images/cg/leaf/Leaf05.png" as cg_scene
    with dissolve

    narrator "Leaf presses her back against your chest, reaching behind to pull you closer."

    narrator "She lifts one leg, holding it up as she guides you inside her from behind. You grip her raised thigh firmly, supporting her weight as you thrust deep into her."

    leaf "Mmmh... Yeah... Just like that..."

    narrator "You start moving inside her with slow, deep strokes. Leaf turns her head to the side, kissing you hungrily while you fuck her standing up."

    leaf "Ahh... Deeper... Don't hold back..."

    narrator "Her body trembles with every thrust. The position lets you reach incredibly deep, and Leaf's soft moans grow louder against your mouth."

    leaf "Nngh! Fuck... You're so deep like this... Harder..."

    narrator "You pick up the pace, pounding into her while keeping her leg lifted high. Her pussy clenches tightly around you as pleasure builds rapidly for both of you."

    leaf "I'm close... Don't stop! Kiss me while I cum..."

    show expression "images/cg/leaf/Leaf05a.png" as cg_scene
    with flash

    narrator "Leaf kisses you desperately as she reaches her climax first. Her body shakes violently in your arms, her leg trembling as her pussy spasms around your cock."

    narrator "The feeling of her orgasm pushes you over the edge. You thrust deep one final time and cum hard inside her, filling her while still holding her leg up."

    leaf "Haaah... Haaah... Fuck... That felt amazing..."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "Hey."

    mc "Yeah?"

    leaf "I'm glad you stayed in town."

    mc "Is that my birthday present too?"

    leaf "Don't push your luck."

    narrator "She says it with her usual sharp tone, but she doesn't pull away. She stays pressed against you, quiet for a rare moment."

    narrator "Her body is still warm from what you just did. For once, she doesn't feel the need to fill the silence with teasing or demands."

    hide leaf
    with dissolve

    $ money -= 150

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ money -= 150
    $ character_progress["leaf"] += 1
    $ affection["leaf"] = min(100, affection["leaf"] + 5)
    $ advance_hint("leaf")
    $ advance_slot(2)

    jump location_shopping_center


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label leaf_seventh_encounter:

    scene bg plaza
    with fade

    narrator "You meet Leaf in the plaza on a quiet Sunday morning. She arrives carrying a small bag and hands it to you without saying a word first."

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    mc "What's this?"

    leaf "Just open it."

    narrator "You open the bag. Inside is a gift, something from one of the stores in the mall, clearly picked for you."

    mc "You bought me something?"

    leaf "Yeah, first time. Don't get used to it... or do. We'll see."

    mc "You used your own money?"

    leaf "Obviously. No strings attached." 

    narrator "She pauses for a second."

    leaf "Well... almost none."

    mc "And what's the 'almost' part?"

    leaf "Come over this afternoon. My mom's out all day."

    narrator "That afternoon at her house, the atmosphere feels noticeably different from all the previous times. There's no rush, no shopping list, no sense of transaction hanging in the air."

    narrator "Leaf is completely relaxed, more herself than you've ever seen her, and with Leaf, that means more than it sounds."

    hide leaf
    with dissolve

    show expression "images/cg/leaf/Leaf06.png" as cg_scene
    with dissolve

    narrator "In her room, Leaf gets on all fours on the bed, arching her back and looking over her shoulder at you with that signature playful grin."

    leaf "Well? What are you waiting for?"

    narrator "You position yourself behind her and push inside her in one smooth thrust. Leaf lets out a loud moan as you fill her completely."

    leaf "Ahh! Fuck... That's it..."

    narrator "You grip her hips firmly and start thrusting deep. Leaf immediately pushes back against you, matching your rhythm with just as much eagerness."

    leaf "Harder... Don't be gentle with me today."

    narrator "You pick up the pace, fucking her harder. The sound of skin slapping against skin fills the room as her body rocks forward with every thrust."

    leaf "Nngh! Yes... Right there... Fuck!"

    narrator "Leaf buries her face into the pillow to muffle her moans, but it barely helps. Her voice still comes through loud and needy as she takes you deeper."

    leaf "I'm getting close... Don't stop!"

    narrator "Her body starts trembling. She pushes back even harder against you, her pussy clenching tightly around your cock."

    leaf "Ahh! I'm cumming...!"

    show expression "images/cg/leaf/Leaf06a.png" as cg_scene
    with flash

    narrator "Leaf cums hard, her whole body shaking as she moans into the pillow. The intense spasms of her orgasm push you over the edge right after her."

    narrator "You thrust deep one final time and cum inside her, groaning as you fill her while she continues trembling beneath you."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("leaf", "default") as leaf at center
    with dissolve

    leaf "Hey."

    mc "What?"

    leaf "There's a new store opening at the mall next week."

    mc "I knew it."

    leaf "But this time... I'm treating you."

    mc "With what money?"

    leaf "Yours, obviously. That's what you're here for, isn't it?"

    narrator "She says it with a big, cheeky grin, but before you can reply, she buries her face in your shoulder."
    
    narrator "For a moment she stays like that, quiet. No teasing, no sarcastic comeback. Just her warm breath against your neck."

    hide leaf
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["leaf"] += 1
    $ affection["leaf"] = min(100, affection["leaf"] + 5)
    $ advance_hint("leaf")
    $ advance_slot(2)

    jump location_plaza