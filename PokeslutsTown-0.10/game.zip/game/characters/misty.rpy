# ============================================================
# POKETOWN, characters/misty.rpy
# ============================================================

label interact_misty:

    $ pending = get_pending_delivery("misty")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            misty "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            misty "I'm still waiting for my order..."
            misty "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("misty", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["misty"]
    $ slot = current_slot
    $ prog = character_progress["misty"]

    if prog == 0 and loc == "forest":
        jump misty_meeting
    elif prog == 1 and aff >= 20 and loc == "forest" and slot in [0, 1, 2]:
        jump misty_first_encounter
    elif prog == 2 and aff >= 40 and stat_physique >= 10 and loc == "beach" and slot in [0, 1, 2]:
        jump misty_second_encounter
    elif prog == 3 and aff >= 55 and loc == "forest" and slot in [0, 1, 2]:
        jump misty_third_encounter
    elif prog == 4 and aff >= 70 and stat_charisma >= 10 and loc == "forest" and slot in [0, 1, 2]:
        jump misty_fourth_encounter
    elif prog == 5 and aff >= 80 and stat_charisma >= 15 and loc == "forest" and slot in [0, 1, 2]:
        jump misty_fifth_encounter
    elif prog == 6 and aff >= 90 and stat_charisma >= 20 and loc == "forest" and slot in [0, 1, 2]:
        jump misty_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_charisma >= 25 and loc == "forest" and slot in [3, 4]:
        jump misty_seventh_encounter
    else:
        jump misty_contextual_dialogue

label misty_contextual_dialogue:
    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve
    $ affection["misty"] = min(100, affection["misty"] + 3)

    if aff_tier == "stranger":
        if loc == "forest":
            misty "Careful in here. The forest has its own rules."
            misty "I'm Misty. I know these paths better than anyone."
        elif loc == "beach":
            misty "The water here is different from back home. Calmer."
            misty "Oh sorry, I'm Misty. I spend a lot of time outdoors."
        else:
            misty "Hey! I'm Misty. You're new around here, right?"
    elif aff_tier == "acquaintance":
        if loc == "forest":
            misty "You're getting better at moving quietly. The Pokemon notice that."
        elif loc == "beach":
            misty "The tides here follow a different pattern. I've been mapping them."
        else:
            misty "Hey you! How's your exploring going?"
    elif aff_tier == "friend":
        if loc == "forest":
            misty "There's a spot deeper in I haven't shown anyone."
            misty "Maybe I'll take you someday."
        elif loc == "beach":
            misty "I come here to clear my head. You're the only person I don't mind having around when I do that."
        else:
            misty "You've really grown on me, you know that?"
    elif aff_tier == "close":
        if loc == "forest":
            misty "The forest feels different when you're with me in it."
            misty "Safer, somehow."
        else:
            misty "I used to explore alone. I think I prefer this."

    hide misty
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location

# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label misty_meeting:

    narrator "Near the edge of the lake, you notice a girl sitting quietly with a fishing rod in her hands. When she notices you approaching, she quickly raises a hand."

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    misty "Shh. Keep it down. I’ve got a big one on the line and I don’t want you scaring it off."

    hide misty
    with dissolve

    $ affection["misty"] = min(100, affection["misty"] + 5)
    $ character_progress["misty"] += 1
    $ advance_hint("misty")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label misty_first_encounter:

    scene bg forest_day
    with fade

    narrator "You find Misty sitting by the lake with a fishing rod in her hands. At first she seems focused... until you notice her head has dropped slightly and her breathing is slow and steady."

    show expression "images/cg/misty/misty01.png" as cg_scene
    with dissolve

    narrator "She’s asleep. After a moment, you decide to wake her up."

    misty "Hah?! What the hell do you think you’re doing?!"

    misty "I wasn’t sleeping! That’s just your imagination!"

    narrator "She quickly turns to check her fishing setup... and freezes."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    misty "No... no no no"

    narrator "Not only is the bait gone. The fish she had already caught are missing too."

    misty "Are you kidding me...? I lost the entire day’s work..."

    misty "Ugh, this is the worst. Just... stay away from me."

    narrator "Clearly furious and frustrated, Misty grabs what’s left of her gear and storms off toward the trees."

    hide misty
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["misty"] += 1
    $ affection["misty"] = min(100, affection["misty"] + 5)
    $ advance_hint("misty")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label misty_second_encounter:

    scene bg beach_day
    with fade

    narrator "You find Misty fishing at the beach. Even from a distance it’s clear she’s in a bad mood, pulling at the line with more force than necessary."

    show expression "images/cg/misty/misty02.png" as cg_scene
    with dissolve

    misty "What do you want now?"

    mc "Just checking on you."

    misty "Well don’t. I had to come all the way out here to get this week’s batch of fresh fish."

    misty "I can catch a lot more in the ocean, but I hate how hot and dry it feels. The lake is way better... but thanks to someone, I lost a whole day’s work."

    misty "So now I’m stuck dealing with this. You should help me. It’s your fault I have to work overtime like this."

    mc "My fault?"

    misty "Yes. Your fault. Now stop talking and make yourself useful."

    narrator "Despite her sharp tone, she doesn’t actually send you away. After a bit more insisting from her, you end up staying to help her fish."

    misty "And train those arms. Fishing is a lot more demanding than you think."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["misty"] += 1
    $ affection["misty"] = min(100, affection["misty"] + 5)
    $ advance_hint("misty")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label misty_third_encounter:

    scene bg forest_day
    with fade

    narrator "You find Misty fishing by the lake again. This time you approach her more naturally."

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    mc "Has my help with the fishing actually been useful?"

    misty "It’s not that big of a deal. I could’ve handled it just fine on my own."

    narrator "Even so, she doesn’t tell you to leave. The two of you end up spending some time together in relative silence, the only sounds being the water and the occasional pull on the line."

    narrator "After a while, the sky darkens quickly. Heavy rain starts pouring down without much warning."

    hide misty
    with dissolve

    show expression "images/cg/misty/misty03.png" as cg_scene
    with dissolve

    misty "Are you kidding me...? Come on, hurry up!"

    narrator "Misty quickly gathers her things and heads toward her cabin. When you reach the door, she hesitates for a second before opening it wider."

    misty "Get in. I don’t want you getting completely soaked... even if you probably deserve to walk home like that."

    narrator "Inside the cabin, Misty disappears into her room for a moment to change into dry clothes. When she comes back, she lights the fireplace and sits close to the growing fire."

    show expression "images/cg/misty/misty04.png" as cg_scene
    with dissolve

    misty "Why are you still standing there? You’re dripping on my floor."

    narrator "Despite her annoyed tone, she doesn’t actually send you away. After a moment she clicks her tongue and shifts slightly to the side."

    misty "Just... sit down already. The fire’s warm."

    narrator "You sit near the fireplace. Misty stays close, clearly enjoying the heat even if she refuses to admit she’s fine with your company."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["misty"] += 1
    $ affection["misty"] = min(100, affection["misty"] + 5)
    $ advance_hint("misty")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label misty_fourth_encounter:

    scene bg forest_day
    with fade

    narrator "Misty specifically asked you to come help her fish at the lake. However, when you arrive, she acts as if she never requested anything."

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    misty "What are you doing here?"

    mc "You told me to come."

    misty "Whatever. Just don’t get in the way."

    narrator "Despite her words, the two of you end up sitting side by side, fishing in silence for a while."

    hide misty
    with dissolve

    show expression "images/cg/misty/misty05.png" as cg_scene
    with dissolve

    narrator "Suddenly Misty’s line goes extremely tight. Whatever is on the other end is strong enough to yank her forward."

    misty "Ah! It’s huge!"

    narrator "You quickly move behind her and hold on to keep her from being pulled in. The force is too much though, and both of you lose your balance, falling into the lake together."

    misty "Ugh! This is your fault for distracting me!"
    
    hide cg_scene
    with dissolve

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    narrator "You help her back to the shore. When you try to set her down on her feet, she winces and grabs your arm."

    misty "Ow... my ankle. I don’t think I can walk like this."

    misty "You’ll have to take me back to the cabin."

    narrator "Something about the way she says it makes you suspect she’s exaggerating... maybe she just didn’t mind being held. Still, you don’t call her out on it."

    mc "Alright. Hold on."

    narrator "You lift her onto your back and carry her the short distance to her cabin by the lake. She stays quiet the whole way, her arms loosely wrapped around your shoulders."

    hide misty
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["misty"] += 1
    $ affection["misty"] = min(100, affection["misty"] + 5)
    $ advance_hint("misty")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label misty_fifth_encounter:

    scene bg forest_day
    with fade

    narrator "Misty asked you to come to her cabin. However, when she opens the door, she already looks annoyed."

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    misty "Finally you show up. Last time you didn’t even come inside. What, are you rejecting my hospitality?"

    mc "You never told me to come in."

    narrator "Misty’s face turns red almost immediately."

    misty "Y-you shouldn’t have to wait for me to invite you if you actually want to spend time with me..."

    misty "Besides, I just wanted to thank you. You’ve been helping me a lot lately."

    hide misty
    with dissolve

    show expression "images/cg/misty/misty04.png" as cg_scene
    with dissolve

    narrator "She looks away, clearly struggling with her own words. The atmosphere inside the small cabin feels heavier than usual."

    misty "Don’t get the wrong idea. It’s not like I... need you or anything. I just"

    narrator "Before she can finish, you step closer. Misty tenses, but she doesn’t move back. Her breathing is already a little uneven."

    mc "You’re really bad at this."

    misty "Shut up..."

    show expression "images/cg/misty/misty06.png" as cg_scene
    with dissolve

    narrator "The distance between you disappears. What starts as a tense, almost reluctant kiss quickly turns deeper. Misty makes a small frustrated sound against your mouth, but her hands grab onto your clothes instead of pushing you away."

    narrator "You end up against the wall near the fireplace. Her body presses firmly against yours as the kissing grows more heated. Your hands slide under her clothes, exploring her skin, and she shivers while still trying to act like she’s not completely into it."

    show expression "images/cg/misty/misty07.png" as cg_scene
    with dissolve

    misty "This doesn’t mean anything... got it?"

    narrator "Even as she says that, she doesn’t stop you. Your hand moves between her legs, rubbing her over the fabric first, then slipping inside. Misty bites her lip hard, her forehead resting against your shoulder as she tries to hold back her voice."

    misty "Nngh... you idiot..."

    narrator "She’s already wet, her hips moving slightly against your hand despite her sharp words. You keep touching her more directly, fingers pressing and stroking while she clings to you."
    
    narrator "Her breathing turns shaky and her usual attitude starts breaking down under the pleasure."

    misty "Don’t you dare stop... if you’re going to do this, at least do it properly..."

    narrator "You keep going until her body tenses up. Misty comes with a muffled, frustrated moan, hiding her face against you as her legs tremble. For a moment she just stays there, catching her breath, still holding onto your clothes."

    misty "...This never happened."

    narrator "Her voice is quieter than usual, and the usual bite behind her words feels weaker."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["misty"] += 1
    $ affection["misty"] = min(100, affection["misty"] + 5)
    $ advance_hint("misty")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label misty_sixth_encounter:

    scene bg forest_day
    with fade

    narrator "You find Misty fishing by the lake again. Her head is slightly lowered, and her grip on the rod looks loose. It doesn’t take long to realize she’s half-asleep."

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    mc "Misty."

    misty "Hnh...? Don’t sneak up on me like that."

    mc "You were falling asleep again."

    misty "I wasn’t. I was just resting my eyes."

    narrator "She sits up straighter and pretends to focus on the water, but her face is already a little red."

    misty "It’s not my fault. Fishing takes patience. You sit here in silence for hours and eventually your brain just... shuts off."

    mc "Then I’ll stay and keep you company."

    misty "I didn’t ask you to."

    narrator "Even so, she doesn’t tell you to leave. You sit down beside her. For a while the two of you just watch the lake in silence."

    mc "About last time..."

    misty "Don’t."

    mc "You’re the one who invited me over."

    misty "That doesn’t mean we have to talk about it. It was a mistake. A temporary lapse in judgment. That’s all."

    narrator "Her voice is sharp, but she keeps glancing at your mouth and then quickly looking away. The air between you grows heavier."

    mc "You didn’t look like you wanted it to stop."

    misty "Shut up. You’re reading too much into it."

    narrator "You lean closer. Misty tenses, but she doesn’t pull away. After a second her fingers tighten around the fishing rod... and then she kisses you first, almost like she’s annoyed at herself for doing it."

    misty "This doesn’t mean anything."

    narrator "You pull her onto your lap so she’s sitting facing away from you, still holding the fishing rod over the water. Her breath catches when she feels you press against her."

    misty "Are you seriously going to do this here?"

    mc "You’re the one who sat down on me."

    misty "I did not nngh..."

    hide misty
    with dissolve

    show expression "images/cg/misty/misty08.png" as cg_scene
    with dissolve

    narrator "You remove her shorts and guide yourself into her slowly. Misty bites her lip hard, her back pressing against your chest as she takes you in."

    misty "Ahh... you idiot... it’s too deep like this..."

    narrator "She keeps one hand on the fishing rod, the other gripping your thigh. You start moving her on your cock with slow, deep thrusts. Every time she tries to stay quiet, another shaky breath slips out of her."

    misty "Don’t you dare make me drop this... I’m still working..."

    narrator "Despite her words, her hips start moving on their own. She rides you in small, needy motions while pretending to watch the water. The wet sound of your bodies meeting mixes with the quiet of the lake."

    misty "Nngh... why does it feel this good...?"

    narrator "You hold her waist and thrust up into her harder. Misty’s composure breaks further. Her thighs tremble, the rod wobbling in her hand as she tries and fails to keep her voice down."

    misty "I’m close... don’t stop"

    show expression "images/cg/misty/misty08a.png" as cg_scene
    with flash

    narrator "She cums first, her body tightening around you as a frustrated, pleasured moan escapes her. The way she clenches down pulls you over the edge right after, and you finish inside her while she’s still shaking on your lap."

    narrator "For a moment neither of you says anything. Misty stays seated on you, breathing hard, her face bright red."

    misty "...You only distract me. That’s all this is."

    narrator "She doesn’t get off you right away. After a few seconds of silence, she looks away, clearly embarrassed."

    misty "...We’re not done."

    misty "I mean, if you’re already here, we might as well... go again. Just so I can concentrate after. Don’t get the wrong idea."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["misty"] += 1
    $ affection["misty"] = min(100, affection["misty"] + 5)
    $ advance_hint("misty")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label misty_seventh_encounter:

    scene bg forest_day
    with fade

    narrator "While exploring the forest near the lake, you suddenly hear a loud splash followed by Misty’s voice."

    misty "Hey! Help! Somebody!"

    narrator "You run toward the sound without thinking. Misty is in the water, struggling just enough to look like she’s in trouble. You jump in, grab her, and pull her back to shore."

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    misty "Haa... thanks."

    mc "How do you live next to a lake and not know how to swim?"

    misty "I do know how to swim."

    mc "Then what was that?"

    narrator "Misty looks away, water still dripping from her hair. After a second she clicks her tongue, clearly embarrassed."

    misty "I saw you nearby, okay? I just... needed a reason to get your attention."

    mc "You don’t have to do stuff like that. If you want something, just say it. It’s easier if you’re direct."

    narrator "Misty’s face turns red. She stands there for a moment, hugging her arms, then lets out a frustrated breath."

    misty "You want me to be direct?"

    misty "Fine."

    misty "Spend the night at my cabin."

    narrator "There’s no sarcasm in her voice this time. Just embarrassment and a stubborn kind of honesty."

    mc "Alright."

    hide misty
    with dissolve

    narrator "By the time you reach the cabin, the sun is already gone. Misty lights the fireplace and the small room fills with warm orange light. For a while neither of you says much. She sits on the rug in front of the fire, still a little tense, like she’s waiting for herself to back out and then refusing to do it."

    show expression get_char_sprite("misty", "default") as misty at center
    with dissolve

    misty "Don’t make this weird."

    mc "You’re the one who invited me."

    misty "I know what I did."

    narrator "She looks at you for a second too long. Then she grabs the front of your shirt and pulls you down into a kiss. It’s rougher than before, less hesitant, like she already decided she isn’t going to hide behind excuses tonight."

    misty "If we’re doing this, we’re doing it properly."
    
    hide misty
    with dissolve

    show expression "images/cg/misty/misty09.png" as cg_scene
    with dissolve

    narrator "Clothes come off in a messy rush. You end up on the rug in front of the fireplace, the heat of the fire against your skin as Misty climbs over you. She sinks down onto your cock with a shaky breath, her hands braced on your chest."

    misty "Ahh... damn it... why does it feel even better like this..."

    narrator "She starts riding you hard, no longer pretending to be composed. Her hips roll against yours with hungry, uneven movements, the wet sound of your bodies filling the quiet cabin. Every time she tries to glare at you, it breaks into another moan."

    misty "Don’t look at me like that... nngh... just, hold me."

    narrator "You grab her waist and thrust up into her. Misty gasps and leans forward, her forehead dropping against yours as you fuck her deeper. The firelight catches on her flushed skin. Her usual sharp attitude is gone, replaced by raw need."

    misty "Harder... I want to feel all of it..."

    narrator "The pace turns intense. She clings to you while you drive into her again and again, her moans growing louder, less controlled. When she cums, her whole body tenses and she cries out against your mouth, tightening around you so hard it pulls you over the edge with her."

    show expression "images/cg/misty/misty09a.png" as cg_scene
    with flash

    narrator "You finish deep inside her. For a long moment she stays on top of you, breathing hard, her face buried against your neck."

    misty "...You’re staying. I’m not asking."

    narrator "Her voice is quiet, almost stubborn. After a second she adds, softer:"

    misty "I got used to you being around. So don’t disappear just because I act like I don’t care."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["misty"] += 1
    $ affection["misty"] = min(100, affection["misty"] + 5)
    $ advance_hint("misty")
    $ advance_slot(2)

    jump expression "location_" + current_location

