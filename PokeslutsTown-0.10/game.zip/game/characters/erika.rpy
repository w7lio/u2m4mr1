# ============================================================
# POKETOWN, characters/erika.rpy
# ============================================================

label interact_erika:
    $ pending = get_pending_delivery("erika")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            erika "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            erika "I'm still waiting for my order..."
            erika "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx  = get_interaction_context("erika", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["erika"]
    $ slot = current_slot
    $ prog = character_progress["erika"]

    if prog == 0:
        jump erika_meeting
    elif prog == 1 and aff >= 10 and stat_physique >= 10 and loc == "greenhouse" and slot in [0, 1, 2, 3]:
        jump erika_first_encounter
    elif prog == 2 and aff >= 20 and stat_physique >= 15 and loc == "greenhouse" and slot in [0, 1, 2, 3]:
        jump erika_second_encounter
    elif prog == 3 and aff >= 35 and loc == "greenhouse" and slot in [0, 1, 2, 3]:
        jump erika_third_encounter
    elif prog == 4 and aff >= 50 and stat_physique >= 20 and loc == "forest" and slot == 4:
        jump erika_fourth_encounter
    elif prog == 5 and aff >= 65 and loc == "greenhouse" and slot in [0, 1, 2, 3]:
        jump erika_fifth_encounter
    elif prog == 6 and aff >= 80 and stat_physique >= 25 and loc == "forest" and slot == 4:
        jump erika_sixth_encounter
    elif prog == 7 and aff >= 95 and loc == "greenhouse" and slot in [0, 1, 2, 3]:
        jump erika_seventh_encounter
    else:
        jump erika_contextual_dialogue


label erika_contextual_dialogue:

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve
    $ affection["erika"] = min(100, affection["erika"] + 3)

    if aff_tier == "stranger":
        if loc == "greenhouse":
            erika "Welcome. If you need seeds or upgrades, just let me know."
        else:
            erika "Hello there. I'm Erika. I run the greenhouse on the edge of town."
    elif aff_tier == "acquaintance":
        if loc == "greenhouse":
            erika "Your garden must be coming along nicely by now."
            erika "Let me know if you need anything."
        elif loc == "plaza":
            erika "Even I need fresh air sometimes. Away from the greenhouse, I mean."
        elif time_tier == "evening":
            erika "The evenings here are quieter than I expected."
        else:
            erika "Good to see you. How are the crops?"
    elif aff_tier == "friend":
        if loc == "greenhouse":
            erika "I saved some special seeds for you. Don't tell the other customers."
        elif loc == "cafe":
            erika "I come here to think. Plants are wonderful but they don't talk back."
        else:
            erika "There's something grounding about seeing a familiar face."
    else:
        if loc == "greenhouse":
            erika "You're the only person I let water my personal collection. You know that?"
        else:
            erika "I planted something new today. I thought of you when I chose it."

    hide erika
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


label erika_meeting:

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    erika "Hi, I don’t think I know you, you must be the farmer who moved here recently."
    erika "If you need seeds or any upgrades for your farm, you can buy them at my greenhouse."

    hide erika
    with dissolve

    $ affection["erika"] = min(100, affection["erika"] + 5)
    $ character_progress["erika"] += 1
    $ advance_hint("erika")
    $ advance_slot()

    jump expression "location_" + current_location

label erika_first_encounter:

    scene bg greenhouse_day
    with fade

    narrator "You find Erika inside her greenhouse, struggling to pull a stubborn root out of the ground."

    show expression "images/cg/erika/Erika01.png" as cg_scene
    with dissolve

    erika "Ugh... Why won't you come out?"

    mc "Need a hand?"

    erika "Oh, it's the new farmer." 

    narrator "She straightens up and brushes some dirt from her hands, offering you a calm, gentle smile."

    erika "Yes, please. I don't usually have trouble with these, but this one is being particularly difficult today."

    mc "Don't worry, let me try."

    narrator "You grab the root and pull with steady strength. After a moment of resistance, it finally comes loose."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    erika "There we go. Thank you so much. It's nice to have an extra pair of strong hands around."

    mc "Anytime. Feel free to ask whenever you need help."

    erika "I appreciate that. I have a feeling you and I are going to get along very well."

    hide erika
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["erika"] += 1
    $ affection["erika"] = min(100, affection["erika"] + 5)
    $ advance_hint("erika")
    $ advance_slot(2)

    jump location_greenhouse


label erika_second_encounter:

    scene bg greenhouse_day
    with fade

    narrator "While browsing for seeds in the greenhouse, you grow increasingly frustrated with the limited selection available."

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    erika "You look a bit annoyed. Is something wrong?"

    mc "Honestly... You have so many beautiful plants here, but you only offer me a handful of seeds."

    erika "Ah... caught me." 

    narrator "She smiles softly, not looking particularly guilty."

    erika "You didn't expect me to make it that easy for you to compete with me, did you?"

    mc "Fair point."

    erika "How about this... If you help me out around the greenhouse from time to time, I'll expand the variety of seeds I sell you. What do you think?"

    mc "Alright. I don't have much of a choice if I want to grow better crops."

    narrator "You end up spending the entire day working alongside Erika in the greenhouse."

    erika "You're still here. You really put in the effort today. Thank you."

    mc "Well, I had to earn those seeds somehow."

    erika "And you did. Quite well, actually."

    narrator "She pauses for a moment, considering something."

    erika "You know... I have a small sauna out back. Would you like to join me and unwind a little? You deserve it after all your hard work."

    mc "Are you sure?"

    erika "Of course. It's the least I can do."

    hide erika
    with dissolve

    show expression "images/cg/erika/Erika02.png" as cg_scene
    with dissolve

    narrator "Erika enters the sauna wearing only a small white towel. It barely covers her curves, leaving her shoulders, thighs, and her breasts exposed."

    narrator "You both sit together in the warm, steamy sauna."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["erika"] += 1
    $ affection["erika"] = min(100, affection["erika"] + 5)
    $ erika_seed_tier = 1
    $ advance_hint("erika")
    $ advance_slot(2)

    jump location_greenhouse


label erika_third_encounter:

    scene bg greenhouse_day
    with fade

    narrator "While you're buying seeds as usual, Erika gently pulls you aside, away from the main area."

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    erika "Hey... You've been such a big help around here lately. I wanted to ask you for a favor."

    mc "Sure. What do you need?"

    erika "There's a rare fruit I've been researching. It only grows deep in the forest, in some difficult areas. I could really use someone strong and reliable to help me with an expedition."

    mc "And what do I get out of it?"

    erika "Oh? You're negotiating now?" 

    narrator "She lets out a soft, amused laugh, tilting her head slightly."

    erika "I thought selling you seeds at a good price was already a fair deal... but apparently not."

    mc "Not this time. You'll have to sweeten the offer a little."

    erika "Hmm... Fine. Let's make a deal then."

    narrator "She looks at you with a calm, knowing smile."

    erika "First, let me help you with something. Then we'll talk about that expedition."

    hide erika
    with dissolve

    show expression "images/cg/erika/Erika03.png" as cg_scene
    with dissolve

    narrator "Erika gives you a calm, seductive smile and slowly kneels in front of you."

    narrator "She pulls down your pants with steady hands, freeing your cock. Without any rush, she leans forward and takes you into her warm, soft mouth."

    narrator "She starts sucking slowly and skillfully, her tongue moving in gentle circles around the head before taking you deeper."

    erika "Mmm..."

    narrator "Her movements are unhurried but confident. She looks up at you with serene eyes as she pleasures you, clearly enjoying the moment."

    narrator "She pulls back slightly, her lips brushing against your shaft, then takes you even deeper, using her hand to stroke the base."

    narrator "Her technique is excellent, slow and teasing at first, then gradually faster and more intense."

    erika "You’re getting harder... I can feel it."

    narrator "She increases her pace, sucking and stroking with focused determination. Her soft moans vibrate around your cock as she works you closer to the edge."

    mc "Erika... I'm close..."

    narrator "She doesn't pull away. Instead, she looks up at you and hums encouragingly, continuing to suck with renewed intensity."

    show expression "images/cg/erika/Erika03a.png" as cg_scene
    with flash

    narrator "With a groan, you finally cum hard into her mouth. Erika stays in place, calmly swallowing every drop without hesitation."

    narrator "After you finish, she slowly pulls back, licking her lips with a satisfied, gentle smile."

    erika "Is that enough to convince you?"

    mc "For now. But we'll keep figuring out how you earn my help going forward."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["erika"] += 1
    $ affection["erika"] = min(100, affection["erika"] + 5)
    $ advance_hint("erika")
    $ advance_slot(2)

    jump location_greenhouse


label erika_fourth_encounter:

    scene bg forest_night
    with fade

    narrator "You set out with Erika on the expedition to find the rare fruit near the top of the mountain."

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    erika "Try to keep up. I didn't expect you to be this slow."

    mc "Sorry, I'm not exactly used to mountain climbing... especially while carrying most of your gear."

    erika "I know. But if we actually find this fruit, I need to collect several samples and seeds to bring back to the greenhouse. It has to be handled carefully."

    mc "Alright, just give me a second to catch my breath."

    narrator "As you continue climbing, Erika missteps. A small rockslide suddenly gives way beneath her. She falls into you, and both of you tumble down the mountainside."

    narrator "When you finally regain consciousness, it's already dark."

    erika "You're awake. How are you feeling? You were out for quite a while."

    mc "What happened...?"

    erika "We fell. We're back at the base of the mountain now. It's far too late and too dangerous to head back to town tonight, so we'll have to camp here."

    narrator "Erika has already made a small fire and prepared some simple food."

    mc "Thanks... It's getting pretty cold out here."

    erika "It is." 

    narrator "She sits closer to the fire, the warm light dancing across her face."

    erika "We'll have to find a way to keep warm tonight."

    hide erika
    with dissolve

    show expression "images/cg/erika/Erika04.png" as cg_scene
    with dissolve

    narrator "The fire is dying down and the night air grows colder. Erika moves closer, then climbs on top of you, straddling your hips."

    narrator "Without a word, she reaches between you, guides your cock to her entrance, and slowly lowers herself, taking you inside her warm, wet pussy."

    erika "Mmm... This should help us stay warm..."

    narrator "She starts riding you with slow, steady movements. Her hips roll smoothly as she tries to maintain her usual composure."

    erika "Don't... read too much into this. It's strictly for warmth."

    narrator "Despite her words, her breathing quickly becomes heavier. She moves faster, taking you deeper with each roll of her hips."

    erika "Ahh... You're so deep like this..."

    narrator "Her hands rest on your chest for support as she rides you with increasing intensity. Her calm facade begins to crack, soft moans escaping her lips."

    erika "Nngh... Don't stop... Keep me warm..."

    narrator "She leans forward, pressing her body against yours as her movements grow more urgent. Her breathing turns into quiet, needy gasps."

    erika "I'm... getting close..."

    narrator "Erika's body suddenly tenses. She buries her face in your neck as she cums, trembling on top of you while trying to suppress her moans."

    show expression "images/cg/erika/Erika04a.png" as cg_scene
    with flash

    narrator "The feeling of her pulsing around you pushes you over the edge. You thrust up into her and cum deep inside, filling her as you both cling to each other."

    erika "Haaah... Haah... That should be... more than enough warmth for the night."

    narrator "Exhausted and satisfied, Erika drifts off to sleep on top of you. You spend the rest of the night together in the quiet forest."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["erika"] += 1
    $ affection["erika"] = min(100, affection["erika"] + 5)
    $ erika_seed_tier = 2
    $ advance_hint("erika")
    $ advance_slot(2)

    jump location_forest


label erika_fifth_encounter:

    scene bg greenhouse_day
    with fade

    narrator "A few days after the expedition, you meet Erika again at her greenhouse."

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    erika "There you are... I've been wanting to talk to you about what happened during the expedition."

    erika "I'm sorry. We were so close to reaching the top, and then I caused us to fall. I got frustrated and took it out on you. That wasn't fair."

    mc "Don't worry about it. Things like that happen in the mountains. We'll get it next time."

    erika "Still... I wasn't very kind to you that night. I feel like I owe you a proper thank you."

    mc "A proper thank you? What did you have in mind?"

    hide erika
    with dissolve

    show expression "images/cg/erika/Erika05.png" as cg_scene
    with dissolve

    narrator "Erika takes your hand and leads you to the back of the greenhouse, into her private sauna."

    narrator "The moment the door closes, the warm, steamy air envelops you both. She gently pushes you down to sit and kneels between your legs."

    narrator "With calm, confident movements, she wraps her soft hand around your cock and begins stroking you slowly."

    erika "You've been working so hard lately... Let me take care of you."

    show expression "images/cg/erika/Erika05a.png" as cg_scene
    with flash

    narrator "Her hand moves with skilled, deliberate strokes, slow at first, then gradually faster. She watches your reactions with serene eyes, clearly enjoying the control she has."

    erika "That was only the beginning of your reward..."

    narrator "After a while, she leans forward and takes you into her warm, wet mouth."

    erika "Mmm..."

    narrator "She gives you a slow, sensual blowjob, using both her mouth and hand in perfect rhythm. Her tongue swirls around the head while she sucks with gentle but firm pressure."

    erika "You taste good..."

    narrator "Her pace increases as she feels you throbbing. She takes you deeper, her movements becoming more eager until you can't hold back anymore."

    narrator "With a groan, you cum hard. Erika stays in place, calmly swallowing everything you give her."

    narrator "After you finish, she pulls back slowly and looks up at you with a soft, satisfied smile."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["erika"] += 1
    $ affection["erika"] = min(100, affection["erika"] + 5)
    $ erika_seed_tier = 3
    $ advance_hint("erika")
    $ advance_slot(2)

    jump location_greenhouse


label erika_sixth_encounter:

    scene bg forest_night
    with fade

    narrator "You set out once again with Erika on the expedition to find the rare fruit. The climb is exhausting, but working together you finally reach the summit."

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    erika "It should be somewhere around here. Let's search carefully."

    mc "You still haven't told me exactly what it looks like."

    erika "It's similar to a Colbur Berry, but much more vibrant and striking. You'll know it when you see it."

    narrator "You spend a long time searching every tree and bush in the area, but find nothing."

    erika "This doesn't make sense... It has to be here."

    mc "Are you sure this is the right season?"

    erika "It should be... but this fruit is incredibly rare. The trees almost never bear fruit, even under perfect conditions."

    mc "I'm sorry. Maybe we can try again next year."

    narrator "Erika stays silent for a moment, clearly disappointed. Then, without warning, she steps forward and pulls you into a gentle hug."

    erika "I'm so sorry... I dragged you all the way up here for nothing."

    narrator "Her voice is soft, filled with genuine regret as she holds you close."
    
    narrator "Seeing Erika so disappointed, you gently lift her chin and kiss her. What starts as a comforting kiss quickly becomes deep and passionate."

    hide erika
    with dissolve

    show expression "images/cg/erika/Erika06.png" as cg_scene
    with dissolve

    narrator "Erika responds with surprising intensity, her hands gripping your shirt as the emotions of the day pour out into the kiss."

    narrator "She pushes you down onto the soft grass and climbs on top of you, straddling your hips."

    erika "I need you... right now."

    narrator "She removes his clothing and lowers herself onto your cock, taking you inside her warmth in one smooth motion."

    erika "Ahh... Yes..."

    narrator "She begins riding you with passionate, rolling movements. The sun is setting behind the mountains, bathing her body in golden light as she moves above you."

    erika "Mmmh... Deeper... I want to feel all of you..."

    narrator "Her usual calm composure melts away. She rides you harder, her moans echoing softly across the quiet mountain summit."

    erika "Don't hold back... Let me feel you..."

    narrator "Her breathing grows heavier and more desperate. She leans forward, pressing her body against yours as her hips move faster."

    erika "I'm... I'm so close...!"

    show expression "images/cg/erika/Erika06a.png" as cg_scene
    with flash

    narrator "Erika cums first, trembling on top of you as her pussy clenches tightly around your cock. Her soft, beautiful moans fill the evening air."

    narrator "The feeling of her orgasm sends you over the edge right after her. You thrust up into her and cum deep inside, holding her close as you both reach climax together beneath the setting sun."

    hide cg_scene
    with dissolve

    narrator "As the light of dusk settles around you, you notice a glimmer in the canopy of a nearby tree."

    narrator "As the last light of dusk settles around you, a faint glimmer catches your eye in the canopy of a nearby tree."

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    mc "How are you feeling?"

    erika "Honestly... this is the best consolation I could have asked for."

    mc "Well, I have something even better than a consolation prize."

    narrator "You point toward the treetop. Nestled among the branches is the rare fruit you've been searching for, glowing softly in the fading light."

    erika "No way..."

    narrator "Her eyes widen with genuine surprise and joy. With your help, you carefully bring the fruit down from the tree."

    erika "We actually found it... Thank you."

    narrator "Together, you carefully pack the precious fruit and begin the journey back down the mountain toward the greenhouse."

    hide erika
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["erika"] += 1
    $ affection["erika"] = min(100, affection["erika"] + 5)
    $ erika_seed_tier = 4
    $ advance_hint("erika")
    $ advance_slot(2)

    jump location_forest


label erika_seventh_encounter:

    scene bg greenhouse_day
    with fade

    narrator "A few days later, Erika sends you a message asking you to come to the greenhouse. She says she has important findings about the rare fruit."

    show expression get_char_sprite("erika", "default") as erika at center
    with dissolve

    erika "Thank you for coming so quickly. I've spent the last few days studying the fruit we found."

    mc "What did you discover?"

    erika "It's fascinating, actually. On the inside, it's very similar to a Colbur Berry, only much sweeter. But the real secret lies in the skin."

    erika "The skin contains a very potent natural aphrodisiac... though it doesn't work if you eat it."

    mc "So then... how does it work?"

    narrator "Erika gives you a calm, meaningful smile, her eyes shining with curiosity and something more."

    erika "Would you like to try it with me?"

    mc "I was really hoping you'd say that."

    hide erika
    with dissolve

    show expression "images/cg/erika/Erika07.png" as cg_scene
    with dissolve

    narrator "You both head to Erika’s private room at the back of the greenhouse."

    narrator "She lies down on the bed and hands you the prepared skin of the rare fruit. With slow, deliberate movements, you gently rub the potent aphrodisiac directly against her sensitive folds."

    erika "Mmm... It's warm... I can already feel it working."

    narrator "Erika’s breathing quickly becomes heavier. Her cheeks flush and her body grows noticeably hotter as the powerful aphrodisiac takes effect."

    erika "Ahh... It's much stronger than I expected... Please... I need you inside me."

    narrator "Unable to hold back any longer, you position yourself on top of her. She wraps her legs around your waist as you slowly enter her."

    erika "Yes... Just like that... Deeper..."

    narrator "You start thrusting into her with long, deep strokes. Erika’s usual calm demeanor melts away as she moans softly beneath you, her body responding eagerly to every movement."

    erika "Nngh... Harder... Don't be gentle with me today."

    narrator "The sex becomes more intense. You thrust deeper and faster while she clings to your back, her legs squeezing tightly around you."

    erika "Ahh...! I'm so close... Stay with me...!"

    narrator "Erika reaches her climax first, her body arching beneath you as her pussy clenches rhythmically around your cock. Her soft, beautiful moans fill the room."

    narrator "The feeling of her orgasm pushes you over the edge. You thrust deep one final time and cum hard inside her, filling her completely as you both ride out your pleasure."

    erika "Haaah... Haah... That was... incredible."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["erika"] += 1
    $ affection["erika"] = min(100, affection["erika"] + 5)
    $ erika_seed_tier = 5
    $ advance_hint("erika")
    $ advance_slot(2)

    jump location_greenhouse
