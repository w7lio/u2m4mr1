# ============================================================
# POKETOWN, characters/mallow.rpy
# ============================================================

label interact_mallow:

    $ pending = get_pending_delivery("mallow")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            mallow "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            mallow "I'm still waiting for my order..."
            mallow "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("mallow", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["mallow"]
    $ slot = current_slot
    $ prog = character_progress["mallow"]

    if prog == 0 and loc == "food_store":
        jump mallow_meeting
    elif prog == 1 and aff >= 10 and loc == "food_store" and slot in [3]:
        jump mallow_first_encounter
    elif prog == 2 and aff >= 20 and loc == "food_store" and slot in [3]:
        jump mallow_second_encounter
    elif prog == 3 and aff >= 35 and loc == "food_store" and slot in [2]:
        jump mallow_third_encounter
    elif prog == 4 and aff >= 50 and stat_charisma >= 10 and loc == "food_store" and slot in [0, 1, 2]:
        jump mallow_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_charisma >= 15 and loc == "food_store" and slot in [3]:
        jump mallow_fifth_encounter
    elif prog == 6 and aff >= 80 and stat_charisma >= 20 and  loc == "food_store" and slot in [2, 3]:
        jump mallow_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_charisma >= 25 and loc == "food_store" and slot in [0, 1, 2]:
        jump mallow_seventh_encounter
    else:
        jump mallow_contextual_dialogue

label mallow_contextual_dialogue:
    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve
    $ affection["mallow"] = min(100, affection["mallow"] + 3)

    if aff_tier == "stranger":
        if loc == "food_store":
            mallow "Welcome! Everything here is fresh, I promise."
            mallow "I'm Mallow! If you're cooking anything, I can help you find what you need."
        else:
            mallow "Hi there! I'm Mallow. I run the food store."
            mallow "Come by if you need ingredients for anything!"
    elif aff_tier == "acquaintance":
        if loc == "food_store":
            mallow "Oh! I just got a new shipment. There's something you'd love."
        elif loc == "cafe":
            mallow "I always check out the competition. Don't tell Lusamine."
        else:
            mallow "Hey! Eating well lately I hope?"
    elif aff_tier == "friend":
        if loc == "food_store":
            mallow "I set aside some of the good stuff for you. First come first served but... you're always first."
        elif loc == "plaza":
            mallow "I'm testing a new recipe in my head. Tell me what you think."
            mallow "Hypothetically."
        else:
            mallow "You always show up right when I need cheering up. How do you do that?"
    elif aff_tier == "close":
        if loc == "food_store":
            mallow "You're my favorite customer. And my favorite person. Don't tell the other customers."
        else:
            mallow "I made something for you. It's not on the menu. It's just... for you."

    hide mallow
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label mallow_meeting:

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    mallow "Welcome. Feel free to look around. If you need anything, just let me know."

    mallow "I'm always here..."

    hide mallow
    with dissolve

    $ affection["mallow"] = min(100, affection["mallow"] + 5)
    $ character_progress["mallow"] += 1
    $ advance_hint("mallow")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label mallow_first_encounter:

    scene bg food_store
    with fade

    narrator "You arrive at the food store late in the evening. The lights are still on. Behind the counter, Mallow looks visibly tired as she rearranges some products."

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    mc "You're still open this late?"

    mallow "Ah... yes. Sometimes customers come at this hour."

    mc "Then it's their fault for not coming earlier. You shouldn't have to stay this late because of them."

    mallow "I can't think of it that way. If someone needs something, I should be here."

    mc "You look exhausted. Closing a bit earlier wouldn't hurt."

    mallow "I appreciate the concern, but I can't just leave. It wouldn't be right."

    narrator "She gives you a polite but firm smile. It's clear she won't change her mind tonight."

    mc "Alright... just don't overdo it."

    narrator "You leave the store, glancing back once. Mallow is still there, working under the soft lights of the empty shop."

    hide mallow
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["mallow"] += 1
    $ affection["mallow"] = min(100, affection["mallow"] + 5)
    $ advance_hint("mallow")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label mallow_second_encounter:

    scene bg food_store
    with fade

    narrator "You return to the food store at night, this time with a clear plan in mind."

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    mc "How did last night go? Any late customers?"

    mallow "Honestly... no one came. But I still can't just close early. What if someone needs something?"

    mc "You already stayed open late and nothing happened. Just for tonight, come with me."

    narrator "Mallow hesitates for a long moment. Finally, she sighs and nods reluctantly."

    mallow "...Fine. Just this once."

    narrator "You lead her out of the store and up a quiet path into the forest. After a short walk, you reach a hill where the trees open up and the sky is completely clear."

    scene bg forest_night
    with dissolve

    narrator "Above you, a beautiful meteor shower fills the night sky."

    hide mallow
    with dissolve

    show expression "images/cg/mallow/mallow01.png" as cg_scene
    with dissolve

    mallow "Wow... This is amazing. I haven't seen anything like this in years."

    narrator "Her tired expression softens into a genuine, animated smile."

    mallow "Thank you for bringing me here."

    mc "You looked like you needed a break."

    narrator "You sit together for a while, watching the stars fall. After some quiet, Mallow starts talking, her voice softer than usual."

    mallow "You know... ever since I was little, the only thing I ever did was work with my family. The restaurant was everything. I grew up measuring my days by opening hours, by how many people came through the door, by whether the food turned out right."

    mallow "When I moved to this town, I thought opening the food store would feel different. I used the same ingredients I already knew, the same routines... but somehow it just became the same thing all over again. Only quieter. And lonelier."

    mallow "I keep telling myself that if I work hard enough, if I stay open long enough, then maybe one day I'll feel like I've earned the right to rest. But that day never comes. I just... keep going. And the more time passes, the less I remember what it felt like to actually enjoy something."

    mallow "Sometimes I wonder if I even know how to want anything for myself anymore."

    mc "Then start small. Close the store a little earlier from now on. I'll help you make use of that free time. You don't have to figure everything out alone."

    narrator "Mallow looks at you for a long moment. There's uncertainty in her eyes, but also a quiet, fragile hope."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["mallow"] += 1
    $ affection["mallow"] = min(100, affection["mallow"] + 5)
    $ advance_hint("mallow")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label mallow_third_encounter:

    scene bg food_store
    with fade

    narrator "You arrive at the food store just as the sun is beginning to set."

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    mc "Are you ready?"

    mallow "Ready? It's still early. I can't close yet."

    mc "Yes, you can. Just for tonight."

    mallow "But..."

    mc "I planned something. We're going to cook together at my place."

    narrator "Mallow’s eyes light up almost instantly."

    mallow "Cook? Really? Do you like cooking?"

    mc "I know a little."

    mallow "Then I’m deciding what we make."

    narrator "Without waiting for an answer, she starts gathering ingredients from the shelves with surprising energy. A few minutes later, the two of you leave the store together."

    scene bg home_interior_day
    with dissolve

    narrator "When you arrive at the farmhouse, Mallow looks around with clear wonder."

    mallow "This is your place? It must be incredible living here... It reminds me of when I was a kid. My apartment in town feels so cold and artificial compared to this."

    scene bg kitchen_day
    with dissolve

    narrator "You both step into the kitchen. Mallow quickly takes charge, giving you clear, cheerful instructions as you cook side by side."

    mallow "No, not like that. Here, let me show you..."

    narrator "At one point, while she’s focused on the pan, you stop and look at her."

    hide mallow
    with dissolve

    show expression "images/cg/mallow/mallow02.png" as cg_scene
    with dissolve

    mc "You look beautiful when you’re happy like this."

    narrator "Mallow freezes for a second. Her cheeks turn pink, but the smile that follows is softer and brighter than before."

    mallow "...Thank you."

    hide cg_scene
    with dissolve

    narrator "After the food is ready, you sit down and eat together. The conversation is easy, and for the first time she seems completely present."

    scene bg plaza_night
    with dissolve

    show expression "images/cg/mallow/mallow03.png" as cg_scene
    with dissolve

    narrator "Later, you walk her back to her apartment. In front of her door, she hesitates for a moment before leaning in and giving you a soft, unexpected kiss."

    mallow "Good night..."

    narrator "She quickly disappears inside, leaving you standing there with a quiet smile."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["mallow"] += 1
    $ affection["mallow"] = min(100, affection["mallow"] + 5)
    $ advance_hint("mallow")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label mallow_fourth_encounter:

    scene bg food_store
    with fade

    narrator "You arrive at the food store earlier than usual. Mallow looks up in mild surprise when the door opens."

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    mallow "You're here already? It's still too early..."

    mc "Don't worry. This time I didn't come to pull you away from work. I just had nothing better to do, so I decided to stop by and say hi."

    narrator "Mallow relaxes a little, but there's a clear nervousness in her expression. She avoids your eyes for a moment."

    mallow "About last night... the kiss. I... I've never really done anything like that before. I spend almost all my time working, so I don't have any experience with those kinds of things."

    mc "Then I can teach you, if you want."

    mallow "You? A farmer teaching me about that?" 

    narrator "She lets out a soft, genuine laugh."

    mallow "I somehow doubt a farmer has that much sexual experience."

    mc "I've slept with half the women in this town, you know."

    narrator "Mallow laughs even harder, covering her mouth with one hand."

    mallow "You're impossible..."

    mc "I'm serious. If you want, I'll teach you."

    hide mallow
    with dissolve

    show expression "images/cg/mallow/mallow04.png" as cg_scene
    with dissolve

    narrator "After a short pause, she gives a small, shy nod. You lean in and kiss her. At first she's hesitant, but soon she starts kissing you back with growing passion, clearly happy despite her nervousness."

    mallow "Mmm..."

    narrator "Suddenly she pulls away, glancing quickly at the door."

    mallow "Someone might come in..."

    mc "No one comes this early. Don't worry."

    narrator "You notice her breathing is already heavier. Sliding a hand down, you begin gently caressing her through her clothes, right between her legs."

    hide cg_scene
    with dissolve

    show expression "images/cg/mallow/mallow05.png" as cg_scene
    with dissolve

    mallow "Ah... wait..."

    narrator "She doesn't stop you. Her hips shift slightly as you continue rubbing her over the fabric. Her face grows more flushed, and soft, shaky breaths escape her lips."

    narrator "After a while, her body tenses. She grips the edge of the counter as a quiet, startled moan slips out of her. A dark, damp patch forms on her clothes where your hand has been."

    mallow "Haa... That was... I've never felt anything that intense before..."

    mc "And that was only from touching you over your clothes."

    narrator "Mallow looks at you, still dazed and clearly embarrassed, but there's a new spark of curiosity in her eyes."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["mallow"] += 1
    $ affection["mallow"] = min(100, affection["mallow"] + 5)
    $ advance_hint("mallow")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label mallow_fifth_encounter:

    scene bg food_store
    with fade

    narrator "You arrive at the food store near closing time. This time, Mallow is already putting some products away."

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    mallow "You're here... Actually, I was thinking of closing a little earlier today."

    mc "Really?"

    mallow "Yeah. I... I wanted to see you."

    narrator "She gives you a shy smile. After locking up, the two of you head to the farmhouse together."

    scene bg kitchen_day
    with dissolve

    narrator "Once inside the kitchen, Mallow starts gathering ingredients with more confidence than last time. You cook side by side again, but the atmosphere feels different, warmer, heavier."

    mallow "You're getting better at this..."

    narrator "At one point, while she’s stirring something on the stove, you step closer from behind and rest your hands on her waist. She tenses slightly, then relaxes into your touch."

    mc "You’re beautiful when you’re focused like this."

    narrator "Mallow turns her head toward you. Her cheeks are already flushed. You lean in and kiss her. This time she doesn’t pull away. The kiss deepens quickly, becoming more urgent."

    mallow "Mmm... Wait... the food..."

    mc "It can wait."

    narrator "You lift her carefully and sit her on the edge of the kitchen counter. She wraps her arms around your neck as you kiss her again, more passionately. Your hands slide under her clothes, exploring her body while she breathes shakily against your lips."

    mallow "I’ve never... done this before. Not all the way."

    mc "We’ll go slow. Tell me if you want me to stop."

    hide mallow
    with dissolve

    show expression "images/cg/mallow/mallow06.png" as cg_scene
    with dissolve

    narrator "She shakes her head softly, her eyes filled with nervous desire. You help her out of her clothes and free yourself. Positioning yourself between her legs, you enter her slowly."

    mallow "Ahh... It’s... so deep..."

    narrator "You move carefully at first, giving her time to adjust. Mallow clings to you, her soft moans filling the quiet kitchen as pleasure gradually overcomes her nervousness."

    mallow "Don’t stop... please..."

    narrator "You pick up the pace, holding her hips while she wraps her legs around you. The sound of your bodies meeting mixes with her increasingly desperate breaths."

    show expression "images/cg/mallow/mallow06a.png" as cg_scene
    with flash

    narrator "After a while, her body tenses and she cums with a quiet, shaky cry, burying her face against your shoulder. The feeling of her tightening around you pushes you over the edge soon after, and you finish inside her."

    narrator "For a long moment you stay like that, still connected, holding each other in the warm kitchen. Mallow’s breathing slowly steadies."

    mallow "That was... more intense than I imagined. Thank you for being patient with me."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["mallow"] += 1
    $ affection["mallow"] = min(100, affection["mallow"] + 5)
    $ advance_hint("mallow")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label mallow_sixth_encounter:

    scene bg food_store
    with fade

    narrator "This time, Mallow invites you to her apartment. It’s small and simple, just as she described before, a little cold and lacking the warmth of the farm."

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    mallow "It’s not much... but make yourself comfortable. I prepared something simple for us."

    narrator "You sit down and eat together. Afterward, since the apartment is so small, the two of you end up on her bed watching television, leaning against the headboard."

    narrator "After a while of quiet conversation, Mallow’s voice softens."

    mallow "You know... I miss a lot of things from before. The restaurant, the noise of the kitchen, even just having people around. And I really miss my best friend, Lana. We used to talk about everything."

    mallow "But... I’m also happy. Things have been getting better lately. And I have you."

    narrator "She looks at you with a gentle, sincere smile. The atmosphere between you grows warmer. What starts as a soft kiss quickly becomes deeper and more needy."

    mallow "I want you..."
    
    hide mallow
    with dissolve

    show expression "images/cg/mallow/mallow07.png" as cg_scene
    with dissolve

    narrator "You help each other out of your clothes. Mallow lies back on the bed, her face flushed with a mix of desire and lingering shyness. You position yourself between her legs and enter her slowly."

    mallow "Ahh... It still feels so intense..."

    narrator "You move inside her with steady, deep thrusts. She wraps her arms around you, holding on tightly as her soft moans fill the small room."

    mallow "Harder... please..."

    narrator "You pick up the pace. Mallow’s body responds eagerly, her legs locking around your waist as pleasure builds between you. After a while she cums first, trembling and clinging to you with a quiet cry."

    show expression "images/cg/mallow/mallow07a.png" as cg_scene
    with flash

    narrator "The feeling of her tightening around you pushes you over the edge soon after, and you finish deep inside her."

    narrator "You stay like that for a long moment, still joined, breathing together in the quiet of her small apartment."

    mallow "I’m really glad you came tonight..."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["mallow"] += 1
    $ affection["mallow"] = min(100, affection["mallow"] + 5)
    $ advance_hint("mallow")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label mallow_seventh_encounter:

    scene bg food_store
    with fade

    narrator "You arrive at the food store at the time you both agreed on. The lights are already off and the “Closed” sign is hanging on the door. Mallow is waiting outside, holding a small bag, looking both nervous and excited."

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    mallow "You’re here... I actually did it. I closed the store for the whole day. No excuses this time."

    mc "I’m really glad you did."

    mallow "I still feel a little guilty, but... I wanted this. Come on, you promised to pick me up."

    narrator "The two of you leave the town behind and head toward the farm. The air feels fresher the farther you get from the buildings."

    scene bg home_interior_day
    with dissolve

    narrator "Once you arrive, you don’t go inside right away. Instead, you spend a long time outdoors. You walk slowly along the edge of the fields, sit under a large tree, and simply watch the wind move through the grass."

    show expression "images/cg/mallow/mallow08.png" as cg_scene
    with dissolve

    mallow "I’ve always loved being in nature. Even when I was little and working at the restaurant, the moments I liked the most were when I could step outside for a bit and just breathe. Everything feels quieter here... more real."

    mallow "My apartment is so closed off. You can barely feel the seasons change. Being here makes me remember how much I used to enjoy this."

    narrator "You keep walking for a while longer. Sometimes you talk, sometimes you just stay quiet next to each other. Mallow looks more relaxed than you’ve ever seen her."
 
    hide cg_scene
    with dissolve

    scene bg kitchen_day
    with dissolve

    show expression get_char_sprite("mallow", "default") as mallow at center
    with dissolve

    narrator "In the late afternoon you finally go inside. Mallow wants to cook a special dish she used to make at the family restaurant years ago. She moves around the kitchen with clear nostalgia and quiet happiness."

    mallow "I haven’t cooked this in so long... I hope I still remember the taste."

    narrator "The two of you prepare the meal together. The atmosphere is warm and unhurried. At one point, while the food is simmering, Mallow stops and turns to look at you."

    mallow "Before I met you, every day felt exactly the same. Open the store, work until late, go home, sleep, repeat. I didn’t even notice how empty it had become."

    mallow "Now I actually look forward to things. To closing early. To coming here. To spending time with you. It still feels a little strange sometimes... but in the best way."

    mc "I’m happy to hear that."

    narrator "She steps closer. The kiss that follows is soft at first, then deeper and more needy. Clothes begin to come off slowly as you move against the kitchen counter."

    mallow "I want you... right here."
    
    hide mallow
    with dissolve

    show expression "images/cg/mallow/mallow09.png" as cg_scene
    with dissolve

    narrator "You turn Mallow around and gently press her against the kitchen counter. She leans forward, resting her hands on the surface as you carefully enter her from behind."

    mallow "Ahh...! It feels even better when I’m this relaxed..."

    narrator "You take your time, thrusting deep and steady. Her soft, shy moans fill the quiet kitchen. Every now and then she looks back over her shoulder at you, cheeks flushed and eyes half-lidded."

    mallow "Hah... Please... don’t stop..."

    narrator "You keep a steady rhythm, one hand resting on her hip while the other gently holds her waist. After a while her body starts trembling. Her soft moans grow higher and more desperate."

    mallow "I-I’m... I’m going to...!"
    
    show expression "images/cg/mallow/mallow09a.png" as cg_scene
    with flash

    narrator "Mallow cums hard with a trembling cry, her body tightening around you as she presses back against the counter. The sudden pressure and the way she shakes pulls you over the edge right after her."

    narrator "You finish deep inside her, holding her close while both of you catch your breath. She stays leaning against the counter for a moment, breathing soft and shaky."

    narrator "Eventually she turns around and rests her forehead against yours, offering a small, warm smile."

    mallow "Thank you... for reminding me that I can still have a life outside of work. And that I can enjoy being outside again."

    mallow "I want more days like this. With you."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["mallow"] += 1
    $ affection["mallow"] = min(100, affection["mallow"] + 5)
    $ advance_hint("mallow")
    $ advance_slot(2)

    jump expression "location_" + current_location

