# ============================================================
# POKETOWN, characters/elesa.rpy
# ============================================================

label interact_elesa:

    $ pending = get_pending_delivery("elesa")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            elesa "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            elesa "I'm still waiting for my order..."
            elesa "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("elesa", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["elesa"]
    $ slot = current_slot
    $ prog = character_progress["elesa"]

    if prog == 0:
        jump elesa_meeting
    elif prog == 1 and aff >= 10 and stat_charisma >= 10 and loc == "clothing_store":
        jump elesa_first_encounter
    elif prog == 2 and aff >= 20 and stat_charisma >= 15 and loc == "clothing_store":
        jump elesa_second_encounter
    elif prog == 3 and aff >= 35 and stat_charisma >= 20 and loc == "clothing_store":
        jump elesa_third_encounter
    elif prog == 4 and aff >= 50 and stat_charisma >= 20 and loc == "clothing_store":
        jump elesa_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_charisma >= 25 and loc == "clothing_store":
        jump elesa_fifth_encounter
    elif prog == 6 and aff >= 80 and stat_charisma >= 25 and loc == "clothing_store":
        jump elesa_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_charisma >= 25 and loc == "clothing_store":
        jump elesa_seventh_encounter
    else:
        jump elesa_contextual_dialogue


label elesa_contextual_dialogue:

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve
    $ affection["elesa"] = min(100, affection["elesa"] + 3)

    if aff_tier == "stranger":
        if loc == "shopping":
            elesa "Welcome. Everything in this store is handpicked by me."
            elesa "Take your time browsing."
        else:
            elesa "I don't think we've met. I'm Elesa."
            elesa "I run the clothing store at the shopping center."
    elif aff_tier == "acquaintance":
        if loc == "shopping":
            elesa "Back again? Good taste brings people back, I suppose."
        elif loc == "plaza":
            elesa "Taking a break from the store. Don't read too much into it."
        elif time_tier == "evening":
            elesa "The evenings here are quieter than I'm used to."
            elesa "I don't hate it."
        else:
            elesa "Oh, it's you. Small town, isn't it."
    elif aff_tier == "friend":
        if loc == "shopping":
            elesa "I was thinking about you actually."
            elesa "I got something in that might suit you."
        elif loc == "beach":
            elesa "You found my secret spot. Not many people come here."
        elif time_tier == "night":
            elesa "Couldn't sleep either?"
        else:
            elesa "Hey. How's your day going?"
    else:
        if loc == "shopping":
            elesa "You know you don't have to buy anything to visit, right?"
            elesa "...I'm glad you're here."
        elif time_tier == "night":
            elesa "Late nights feel different when you're around."
        else:
            elesa "There you are."

    hide elesa
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


label elesa_meeting:

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "Welcome. I'm Elesa, I own this boutique."
    elesa "If you're looking for a gift or something for yourself, I'd be happy to help."
    elesa "Though... looking at your size, I'm afraid I don't have much to offer you at the moment."

    mc "Why not?"

    elesa "Because I don't design menswear. Not yet."

    narrator "She holds your gaze a second longer than necessary before returning to what she was doing."

    hide elesa
    with dissolve

    $ character_progress["elesa"] += 1
    $ affection["elesa"] = min(100, affection["elesa"] + 5)
    $ advance_hint("elesa")
    $ advance_slot()

    jump expression "location_" + current_location


label elesa_first_encounter:

    scene bg clothing_store
    with fade

    narrator "While browsing in the mall, Elesa suddenly appears beside you, as if she had been waiting."

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "What a fortunate coincidence."

    mc "I live here. It's not that much of a coincidence."

    elesa "Fair enough." 

    narrator "She crosses her arms elegantly, looking you up and down with a critical but professional eye."

    elesa "I have a business proposal for you. You're free to refuse, of course."

    mc "I'm listening."

    elesa "I've been wanting to expand my line into menswear for quite some time. The problem is that there are very few men in this town with the right proportions for proper fitting."

    mc "And I do?"

    elesa "Your build is... acceptable. Not ideal, but workable. Better than most around here."

    mc "Wow. What a compliment."

    elesa "It wasn't a compliment. It was an honest assessment."

    narrator "She tilts her head slightly, her expression remaining composed and elegant."

    elesa "So, are you interested? I would need you to come to the boutique when required, for measurements, fittings, and occasional opinions. In exchange, once the line is ready, I'll dress you properly. Free of charge."

    mc "And if I don't like what you design?"

    narrator "Elesa gives you a small, confident smile that clearly says that possibility isn't even worth considering."

    elesa "We have a deal then?"

    mc "Alright. Deal."

    elesa "Excellent. Come by the boutique tomorrow at eleven sharp. Don't be late."

    hide elesa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["elesa"] += 1
    $ affection["elesa"] = min(100, affection["elesa"] + 5)
    $ advance_hint("elesa")
    $ advance_slot(2)

    jump location_clothing_store


label elesa_second_encounter:

    scene bg clothing_store
    with fade

    narrator "You arrive at the boutique exactly at eleven. Elesa is already waiting, measuring tape in hand and an air of complete control over her schedule."

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "Punctual. I'm pleasantly surprised."

    mc "You told me not to be late."

    elesa "And yet most people still manage to disappoint. You're already ahead of the curve."

    narrator "She guides you to the center of the shop and begins taking your measurements with precise, professional movements, noting every number in her small notebook."

    mc "Have you had this boutique for long?"

    elesa "Six years. And I've worked alone most of the time."

    mc "No assistants?"

    elesa "I have them. But for something this important, I prefer to handle it personally. Details matter."

    hide elesa
    with dissolve

    show expression "images/cg/elesa/Elesa01.png" as cg_scene
    with dissolve

    narrator "She crouches down to measure your inseam. A heavy silence fills the boutique as she works with focused concentration."

    mc "Can I ask why you're expanding into menswear now?"

    elesa "The timing feels right."

    mc "Or because someone with 'reasonable proportions' finally showed up?"

    narrator "Elesa pauses for a brief moment, then continues writing in her notebook without looking up."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "The two aren't mutually exclusive."

    elesa "I'm done for today. Come back on Thursday at the same time."

    mc "You're not going to tell me what you're planning to design?"

    elesa "You'll see on Thursday. Trust the process."

    mc "You mean trust you."

    elesa "Precisely."

    narrator "She gives you a small, elegant smile before turning away."

    hide elesa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["elesa"] += 1
    $ affection["elesa"] = min(100, affection["elesa"] + 5)
    $ advance_hint("elesa")
    $ advance_slot(2)

    jump location_clothing_store


label elesa_third_encounter:

    scene bg clothing_store
    with fade

    narrator "When you arrive, Elesa already has three carefully selected pieces laid out on the counter."

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "You're on time. Good. Let's begin. Try them on in that order, starting with the shirt."

    narrator "You try on each garment while Elesa watches with her arms crossed, studying every detail with sharp, professional eyes. She occasionally steps forward to adjust the fit with precise touches."

    elesa "Turn around."

    mc "What do you think?"

    elesa "The shoulder on the right needs to come in about a centimeter. The fabric drape is acceptable."

    mc "And what do *you* think? Not the designer, you."

    narrator "Elesa pauses, looking at you for a moment with an unreadable expression."

    elesa "It suits you. Better than I expected, actually."

    mc "Was that a compliment?"

    elesa "Don't get used to them. I give them out very sparingly."

    mc "I've noticed."

    narrator "Elesa looks away and writes something in her notebook, the faintest hint of a smile tugging at her lips."

    elesa "Next week I'm hosting a small private event here at the boutique. A presentation for my regular clients."

    mc "You want me there as a model?"

    elesa "As my assistant... though yes, you'll also be wearing one of my designs."

    mc "And if I don't like what you choose for me?"

    elesa "Trust the process."

    mc "Again with that phrase."

    elesa "Because it works. Always."

    hide elesa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["elesa"] += 1
    $ affection["elesa"] = min(100, affection["elesa"] + 5)
    $ advance_hint("elesa")
    $ advance_slot(2)

    jump location_clothing_store


label elesa_fourth_encounter:

    scene bg clothing_store
    with fade

    narrator "The event is far more elegant than you expected. The boutique has been completely rearranged, soft lighting and champagne create a refined atmosphere, and Elesa's clients are exactly as sophisticated as one would imagine."

    narrator "Elesa greets you at the door with a quick, appraising look before composing herself."

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "You look good. The jacket fits exactly as I envisioned."

    mc "You chose it."

    elesa "Precisely. That's why it fits perfectly."

    narrator "Throughout the evening, you stay by her side. Elesa moves through the room with natural grace, presenting pieces and conversing with clients. Every so often she gives you quiet, precise instructions."

    elesa "The woman in the back has been staring at the blue dress for half an hour. Go tell her it would look stunning on her. She has excellent taste but needs a little push."

    mc "Is that selling or psychology?"

    elesa "In my boutique, they're the same thing."

    narrator "You do as she asks. It works. From across the room, you catch Elesa watching you with an expression that shifts for just a moment, something softer, before returning to her usual composure."

    narrator "When the last clients finally leave, the boutique falls into a peaceful silence. Elesa begins tidying with her characteristic efficiency."

    mc "How did it go?"

    elesa "Very well. Better than expected... in more ways than one."

    mc "Which part?"

    elesa "The part where you were useful."

    mc "Was that almost a compliment?"

    elesa "It was an objective assessment."

    narrator "After finishing tidying together, Elesa walks toward a door at the back of the shop you've never noticed before."

    elesa "This room is where I keep previous season pieces and designs that aren't ready for the public yet. Almost no one is allowed inside."

    mc "And I'm allowed?"

    elesa "You've earned it tonight. Come."

    narrator "The private room is small, intimate, and impeccably organized, garments covered in protective sheets, framed sketches on the walls, and warmer lighting than the main boutique."

    hide elesa
    with dissolve

    show expression "images/cg/elesa/Elesa02.png" as cg_scene
    with dissolve

    narrator "Elesa closes the distance and gently pushes you back against the wall with a composed but decisive touch."

    narrator "She kneels gracefully in front of you, her movements refined even now. With steady, elegant hands she unbuttons your pants, her sharp eyes never leaving yours."

    elesa "Don't move."

    narrator "She takes your cock into her mouth slowly, savoring it with controlled precision. Her tongue swirls around the head before she takes you deeper, sucking with expert, unhurried skill."

    narrator "One of her hands strokes the base in perfect rhythm with her lips, while she maintains unwavering eye contact, a striking mix of professional focus and barely contained desire."

    elesa "Mmm..."

    narrator "Her pace gradually increases, becoming faster and more intense. Even as her movements grow more passionate, she never loses that elegant control."

    narrator "You feel yourself reaching the edge. Elesa notices and doesn't pull away. Instead, she takes you deeper, her eyes locked on yours."

    show expression "images/cg/elesa/Elesa02a.png" as cg_scene
    with flash

    narrator "With a low groan, you cum hard in her mouth. She swallows every drop without hesitation."

    narrator "After a moment, she slowly pulls back, delicately wiping the corner of her lips with her finger before rising to her feet with perfect poise."

    elesa "There... Consider that your reward for tonight."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "Don't mention what happened here. To anyone."

    mc "Of course. I won't say a word."

    elesa "And don't read too much into it."

    mc "I won't."

    narrator "Elesa studies your face for a moment, as if trying to decide whether she believes you. Her expression remains composed, but there's a faint flicker of something else in her eyes."

    elesa "Good. See that you don't."

    narrator "Despite her words, she doesn't step away immediately. For a brief second, the usual elegant mask slips just enough to show a hint of vulnerability before she regains control."

    hide elesa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["elesa"] += 1
    $ affection["elesa"] = min(100, affection["elesa"] + 5)
    $ clothing_vip_unlocked = True
    $ advance_hint("elesa")
    $ advance_slot(2)

    jump location_clothing_store


label elesa_fifth_encounter:

    scene bg clothing_store
    with fade

    narrator "A few days later, you find a note slipped under your door. The handwriting is impeccable, on heavy, elegant paper. It simply reads: \"Thursday. Eleven. Don't be late. - E.\""

    narrator "When you arrive at the boutique exactly on time, Elesa is already waiting. She seems quieter than usual, more focused on the garments in front of her."

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    mc "Are you alright?"

    elesa "I'm fine. Try this on."

    narrator "You put on the new piece. Elesa steps closer to adjust the collar, her fingers lingering a moment longer than necessary."

    mc "What's wrong?"

    elesa "Nothing. The cut isn't quite right yet."

    mc "I wasn't asking about the clothes."

    narrator "Elesa meets your gaze for a few seconds before looking away."

    elesa "I have a very important collection presentation in two months. The biggest one I've ever done. Buyers are coming from outside the region."

    mc "And you want me to be part of it?"

    elesa "You're the only male model I trust. It's not a choice... it's a necessity."

    mc "Of course I'll help."

    elesa "Don't say it like that."

    mc "Like what?"

    elesa "Like you understand more than I'm saying."

    narrator "She turns back to her designs, but when she takes your measurements again, her touch is slower, less clinical than before."

    narrator "Once she's finished, Elesa silently leads you toward the private room at the back of the boutique."

    hide elesa
    with dissolve

    show expression "images/cg/elesa/Elesa03.png" as cg_scene
    with dissolve

    narrator "The moment the door to the private room closes, Elesa presses you down onto the small couch with surprising determination."

    narrator "She hikes up her elegant dress and straddles your lap, her eyes locked on yours with intense focus."

    elesa "Not a word about this... understood?"

    narrator "She reaches between you, guides your cock to her entrance, and slowly lowers herself, taking you inside her completely. A soft, controlled breath escapes her lips as she settles fully onto you."

    elesa "Mmm... Just like that..."

    narrator "She begins riding you with deep, measured movements. Her hands rest on your shoulders for balance as she controls the rhythm, her usual composure still mostly intact."

    narrator "Gradually, her breathing becomes heavier. Her hips move with more urgency, taking you deeper each time."

    elesa "Ahh... You feel... better than I expected."

    narrator "She leans forward, pressing her body against yours while continuing to ride you. Her inner walls squeeze you tightly as her pace quickens."

    elesa "Don't hold back... I want to feel you..."

    narrator "Her composure finally cracks. She buries her face in your neck, biting her lip to stifle her moans as pleasure overtakes her."

    narrator "Elesa reaches climax first, her body trembling on top of you as she clenches tightly around your cock. She lets out a quiet, elegant moan against your skin."

    narrator "The feeling of her orgasm pushes you over the edge. You thrust up into her and cum deep inside, filling her as she continues to move slowly through the aftershocks."

    elesa "This doesn't change anything about our working relationship."

    mc "It doesn't have to."

    elesa "Good."

    mc "Good."

    narrator "Neither of you sounds fully convinced. A heavy, meaningful silence fills the small room."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["elesa"] += 1
    $ affection["elesa"] = min(100, affection["elesa"] + 5)
    $ advance_hint("elesa")
    $ advance_slot(2)

    jump location_clothing_store


label elesa_sixth_encounter:

    scene bg clothing_store
    with fade

    narrator "Your visits to the boutique have become more frequent. Elesa always finds a professional excuse, an adjustment, a fitting, or an opinion on fabric. And you always make time."

    narrator "This afternoon, you find her standing with her back to you, arms crossed, staring intently at a sketch on the wall."

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "Tell me what you see."

    mc "In the sketch?"

    elesa "Yes."

    narrator "You step closer. It's a suit with clean, sharp lines, classic, but with a subtle, unexpected detail at the collar."

    mc "It's serious without being boring. The collar detail catches you off guard... in a good way. It breaks the expectation right when you think you've figured it out."

    narrator "A long silence fills the room."

    elesa "That's exactly what I was going for."

    mc "You mean in the suit... or in what I just said?"

    elesa "Both, apparently."

    narrator "She turns to face you. For the first time, she isn't holding her notebook or a piece of fabric. There's nothing to hide behind."

    elesa "Can I ask you something that has nothing to do with clothes?"

    mc "Of course."

    elesa "Why do you keep coming here? The collection isn't finished yet. I don't owe you anything."

    mc "I'm not coming for the clothes, Elesa."

    narrator "She holds your gaze, searching your eyes. For a moment, her usual composure wavers."

    elesa "I know."

    narrator "Her voice is quieter than usual."

    elesa "I just... wanted to hear you say it."

    hide elesa
    with dissolve

    show expression "images/cg/elesa/Elesa04.png" as cg_scene
    with dissolve

    narrator "The moment the tension breaks, Elesa pushes you back onto the couch with a decisive yet graceful motion and climbs on top of you."

    narrator "She reaches under her elegant dress, slides her panties down her legs, and discards them without ceremony. Straddling your lap, she guides your cock to her entrance and slowly sinks down, taking you inside her."

    elesa "Mmm... There we go..."

    narrator "She starts riding you with slow, controlled movements, savoring every inch as she settles into a sensual rhythm. Her hands rest on your chest for balance."

    narrator "Gradually, her pace increases. She leans forward, pressing her body against yours as she kisses you deeply, her tongue moving with the same precision she applies to everything else."

    elesa "Don't... hold back..."

    narrator "Her breathing becomes heavier, turning into soft, restrained moans against your mouth. Even as pleasure builds, she maintains an air of elegance, her hips rolling with practiced grace."

    narrator "Soon her movements grow more urgent. She rides you harder, her body trembling as she chases her release."

    elesa "Ahh... I'm close... Stay with me..."

    show expression "images/cg/elesa/Elesa04a.png" as cg_scene
    with flash

    narrator "Elesa reaches her climax first, her body shaking on top of you as she clenches tightly around your cock. She bites her lip to stifle a moan, but a few soft, elegant sounds still escape."

    narrator "The feeling of her orgasm pushes you over the edge. You thrust up into her and cum deep inside, holding her close as both of you ride out a powerful climax together."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    elesa "The presentation is in three weeks. I want you there."

    mc "As your assistant or as something more?"

    elesa "As whatever you are. We'll figure that part out after."

    hide elesa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["elesa"] += 1
    $ affection["elesa"] = min(100, affection["elesa"] + 5)
    $ advance_hint("elesa")
    $ advance_slot(2)

    jump location_clothing_store


label elesa_seventh_encounter:

    scene bg clothing_store
    with fade

    narrator "The night of the big presentation, the boutique is completely transformed. Perfect lighting, white flowers, and important buyers from out of town seated in the front row."

    narrator "Elesa is in her element, flawless, commanding every detail with a calm that only you know how much it costs her."

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve

    narrator "When she sees you arrive, something in her expression softens for a brief second, like a missing piece finally falling into place."

    elesa "You're on time."

    mc "Always."

    elesa "The suit from the sketch. Go change."

    narrator "You change in the private room. When you step out, several buyers take notes and whisper among themselves."

    narrator "Elesa watches everything with her usual impeccable composure, but when no one is looking, she gives you a glance that says more than anything she's said in all these months."

    narrator "Once the last guest leaves and the boutique falls silent, Elesa closes the door and leans back against the counter. For the first time, she looks simply tired, the perfect mask finally lowered."

    mc "How did it go?"

    elesa "Very well. The buyers are interested in the full menswear line for next season."

    mc "Congratulations."

    elesa "It's your congratulations as well."

    mc "You're actually admitting that?"

    elesa "I'm acknowledging it. That's not the same thing."

    mc "What's the difference?"

    elesa "Admitting would mean it cost me something. Acknowledging is simply observing a fact."

    mc "And didn't it cost you something?"

    narrator "Elesa looks at you for a long moment. Then she picks up her notebook from the counter, closes it, and sets it down gently, as if she no longer needs it."

    elesa "Come."

    narrator "She leads you to the private room one last time that night. This time, there is no professional excuse, and neither of you pretends there is."

    hide elesa
    with dissolve

    show expression "images/cg/elesa/Elesa05.png" as cg_scene
    with dissolve

    narrator "The moment the door closes, all remaining restraint vanishes. Elesa kisses you with a passion she rarely allows herself to show, her hands pulling you closer."

    narrator "She guides you down onto the couch until you're on top of her. Without breaking the kiss, she reaches between you, guiding your cock to her entrance."

    narrator "You enter her slowly, savoring her warmth and tightness. Elesa lets out a soft, trembling breath against your lips as you fill her completely."

    elesa "Ahh... Yes..."

    narrator "You begin thrusting deep and steady. Her legs wrap tightly around your waist, pulling you even deeper with every movement."

    narrator "Her carefully maintained composure finally shatters. Soft, elegant moans escape her lips as she arches beneath you."

    elesa "Harder... Don't hold back tonight..."

    narrator "Her nails dig into your back as her body moves with yours. The usually poised designer is now completely lost in the moment, her hips rising to meet every thrust."

    elesa "Nngh... I'm so close... Stay with me..."

    show expression "images/cg/elesa/Elesa05a.png" as cg_scene
    with flash

    narrator "Elesa's body suddenly tenses. She clings to you tightly as she reaches a powerful climax, her inner walls pulsing around you. Her moan is muffled against your shoulder."

    narrator "The intensity of her orgasm pulls you over the edge right after her. You thrust deep one final time and cum inside her, holding each other tightly as waves of pleasure wash over you both."

    narrator "For a long moment, you remain like that, tangled together in the afterglow, breathing heavily in the quiet room."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("elesa", "default") as elesa at center
    with dissolve
    
    elesa "Tomorrow I need to start the summer collection."

    mc "Right."

    elesa "I'll need the model."

    mc "The model will be here."

    elesa "Good."

    narrator "This time, when she says it, it sounds like something entirely different from an assessment."

    hide elesa
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["elesa"] += 1
    $ affection["elesa"] = min(100, affection["elesa"] + 5)
    $ advance_hint("elesa")
    $ advance_slot(2)

    jump location_clothing_store
