# ============================================================
# POKETOWN, characters/helena.rpy
# ============================================================

label interact_helena:

    $ pending = get_pending_delivery("helena")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            helena "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            helena "I'm still waiting for my order..."
            helena "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("helena", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["helena"]
    $ slot = current_slot
    $ prog = character_progress["helena"]

    if prog == 0 and loc == "home":
        jump helena_meeting
    elif prog == 1 and aff >= 5 and loc == "home" and slot in [4]:
        jump helena_first_encounter
    elif prog == 2 and aff >= 15 and loc == "home" and slot in [0, 1]:
        jump helena_second_encounter
    elif prog == 3 and aff >= 30 and loc == "home" and slot in [1, 2, 3]:
        jump helena_third_encounter
    elif prog == 4 and aff >= 45 and loc == "home" and slot in [0, 1]:
        jump helena_fourth_encounter
    elif prog == 5 and aff >= 60 and loc == "home" and slot in [0]:
        jump helena_fifth_encounter
    elif prog == 6 and aff >= 75 and loc == "home" and slot in [3, 4]:
        jump helena_sixth_encounter
    elif prog == 7 and aff >= 90 and loc == "home" and slot in [3, 4]:
        jump helena_seventh_encounter
    else:
        jump helena_contextual_dialogue


label helena_contextual_dialogue:
    show expression get_char_sprite("helena", "default") as helena at center
    with dissolve
    $ affection["helena"] = min(100, affection["helena"] + 3)

    if aff_tier == "stranger":
        helena "This house used to be empty. It still smells a little empty."
    elif aff_tier == "acquaintance":
        helena "The kitchen smells better when you're in the house."
    elif aff_tier == "friend":
        helena "I washed your clothes. I smelled them first. They smell like home now."
    elif aff_tier == "close":
        helena "If you get stressed, use me. That's easier than pretending you don't want to."

    hide helena
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label helena_meeting:

    scene kitchen_night
    with fade

    narrator "The rain hits the farmhouse roof harder than usual. You’re almost asleep when a noise comes from the kitchen. Something shifts. A cupboard opens. Someone is inside the house."

    narrator "You get up and walk down the hall as quietly as you can. In the kitchen, a soaked girl is crouched in front of an open cabinet, rummaging through the food with quick, desperate hands."

    show expression get_char_sprite("helena", "default") as helena at center
    with dissolve

    "???" "Ah-!"

    narrator "The second she notices you, her whole body locks up. Her eyes are wide, wet hair stuck to her face. For a moment she just stares at you like an animal caught in someone else’s den."

    "???" "No- no no no-"

    narrator "She drops whatever she was holding and bolts. The back door slams open. Rain and cold air rush in as her footsteps disappear into the dark."

    narrator "You stand there in the empty kitchen, listening to the rain. Food is scattered on the floor. The house doesn’t feel abandoned anymore."

    narrator "Whoever she is, she knew this place. And if she’s coming back, you need to find out who she is."

    hide helena
    with dissolve

    $ affection["helena"] = min(100, affection["helena"] + 5)
    $ character_progress["helena"] += 1
    $ advance_hint("helena")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label helena_first_encounter:

    scene bg kitchen_night
    with fade

    narrator "the house is still quiet in that uneasy way. Then you hear it again: cupboards, hurried movement, someone trying not to make noise and failing."

    narrator "You walk to the kitchen and turn on the light."

    show expression "images/cg/helena/helena01.png" as cg_scene
    with dissolve

    narrator "A large woman is crouched on the floor in an old, worn-out dress. She’s holding a cookie jar with both hands. Her mouth is full. For a second she just stares at you, crumbs on her lips, like she hoped the dark would keep her hidden."

    narrator "The moment she realizes you’ve seen her, her eyes fill with sadness."

    helena "I’m sorry. I know I shouldn’t keep coming here. I tried living in the forest, but it’s cold at night and-"

    mc "Wait. Wait. What are you talking about?"

    narrator "She swallows hard. Her voice comes out wet and uneven, but she doesn’t run this time."

    helena "Before you got here, I used to live in this house. I didn’t have anywhere else to go, and it was abandoned, so I thought... nobody would care."

    helena "Then one day you arrived. So I left. But I don’t know where else to be. Surviving outside is hard. That’s why I sneak in at night. For food. For a place to hide."

    helena "I really like this place. Couldn’t we make a deal? So I can stay?"

    mc "I don’t think a homeless girl has much to offer me."

    show expression "images/cg/helena/helena02.png" as cg_scene
    with dissolve

    narrator "Helena goes quiet. Then, without much warning, she stands up and lifts the front of her worn dress, exposing her large breasts. She holds the fabric there, watching your face as if that should be enough to settle the conversation."

    mc "Yeah. I’m not that simple."

    narrator "She doesn’t lower the dress right away. She just keeps looking at you, confused, like she doesn’t understand what else a deal is supposed to look like."

    mc "We can talk about it later. For now, you can stay in the barn. We’ll figure something out."

    narrator "Helena finally lets the dress fall back into place. She nods too quickly, as if she’s afraid you’ll change your mind if she waits too long."

    helena "The barn... yes. That’s fine. I can stay in the barn."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery
    
    $ store.character_schedule_state["helena"] = "after"
    $ character_progress["helena"] += 1
    $ affection["helena"] = min(100, affection["helena"] + 5)
    $ advance_hint("helena")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label helena_second_encounter:

    scene bg home_interior_day
    with fade

    narrator "You head to the barn to check on her. Helena is already awake, sitting among the crates with fruit juice still on her fingers and a half-eaten apple beside her."

    show expression "images/cg/helena/helena03.png" as cg_scene
    with dissolve

    helena "I didn’t sleep well. The barn is loud. And it smells like dirt. But it’s better than sleeping outside. At least I can eat whatever I want."

    mc "Eating my fruit wasn’t part of the deal."

    helena "That’s unfair. I almost never get to eat. And you have so much fresh fruit just sitting here."

    mc "Then next time ask. Don’t just take it."

    helena "Fine. I’ll ask."

    narrator "She says it like the matter is already settled. You let it go."

    mc "I’ve been thinking. I can offer you something better."

    mc "The house has an attic. We could put a bed up there. I don’t use it. It’s gloomy and dark... which seems pretty on-brand for you."

    narrator "Helena’s whole face changes. The tired look disappears almost at once."

    helena "The attic? In the house?"

    helena "Yes. Yes, I want that. Thank you."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("helena", "default") as helena at center
    with dissolve

    narrator "She steps in too close. Her expression turns nervous, but she doesn’t back away."

    helena "And about payment..."

    mc "Go on. I’m listening."

    narrator "Helena lets out a small, crooked smile, as if she didn’t expect you to play along that easily."

    helena "I didn’t say it had to be anything specific."

    helena "But if what you have in mind is sex, we can negotiate that too."

    mc "Is that your idea of rent?"

    helena "It can be. If you want it to be."

    narrator "She tilts her head, watching you with that same unnerving calm."

    helena "Besides... I’m not a homeless girl anymore."

    hide helena
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["helena"] += 1
    $ affection["helena"] = min(100, affection["helena"] + 5)
    $ advance_hint("helena")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label helena_third_encounter:

    scene bg home_interior_day
    with fade

    narrator "The attic is dim and dusty, just like you said it would be. You put together a simple straw bed in the corner. It isn’t much, but it’s dry, raised off the floor, and better than the barn."

    show expression get_char_sprite("helena", "default") as helena at center
    with dissolve

    helena "This is the most comfortable thing I’ve slept on in months."

    narrator "She sits on it immediately, pressing her hands into the straw, then leaning down to smell it like that matters as much as how it feels."

    helena "It still smells like the barn a little. I don’t mind."

    narrator "She looks up at you from the bed, that same nervous, too-direct expression on her face."

    helena "If you want, I can start paying rent in advance."

    narrator "She’s been insistent since the beginning. Not flirtatious, exactly. Just blunt, like this is the obvious next step. After a moment, you accept."

    mc "Alright."

    helena "Sit down."

    narrator "Helena guides you onto the straw bed and kneels in front of you. She undoes your pants without hesitation and pulls them down. Then she leans in close, pressing her face against the bulge in your underwear."

    narrator "She doesn’t touch you with her hands first. She inhales. Slow. Deep. Like she’s trying to memorize it."

    helena "I could smell you from the start."

    helena "That man smell. On your clothes. In the house. On the air when you walked past me."

    helena "It always made me wet. That’s why I kept offering."

    narrator "She pulls her worn dress off completely. Underneath, her underwear is a soft pale pink. Clean. Almost delicate. The contrast with the rest of her is so sharp you let out a short laugh."

    mc "Didn’t expect that."

    helena "What?"

    mc "Nothing. Just... pink."

    hide helena
    with dissolve

    show expression "images/cg/helena/helena04.png" as cg_scene
    with dissolve

    narrator "Helena doesn’t seem embarrassed. She takes the panties off, wraps the warm fabric around your cock, and starts stroking you through it. The cloth is thin enough that you can feel every movement of her hand."

    helena "I know boys usually think this is super hot."

    narrator "She keeps going, using her underwear like it belongs there. Her eyes stay on your cock the whole time, and every so often she leans in again just to smell you. When you finally cum, the semen soaks through the fabric and stains the pink cloth completely."

    show expression "images/cg/helena/helena05.png" as cg_scene
    with dissolve

    narrator "Helena looks at the mess with open satisfaction. Then she slides the wet panties back on, pressing them against herself so the stain sits right between her legs."

    helena "Now I can keep your smell with me."

    show expression "images/cg/helena/helena06.png" as cg_scene
    with dissolve

    narrator "Her breath catches as she starts rubbing herself over the soaked fabric, slow and shameless, like she already forgot you were supposed to be part of a negotiation."

    mc "I’ll leave you to it."

    narrator "Helena doesn’t stop you. She just nods, still touching herself on the straw bed, breathing in like the scent is the best part."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["helena"] += 1
    $ affection["helena"] = min(100, affection["helena"] + 5)
    $ advance_hint("helena")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label helena_fourth_encounter:

    scene bg home_interior_day
    with fade

    narrator "Helena started helping around the house without being asked. She sweeps the hallway. She puts things back where they belong, more or less."

    narrator "She even washes dishes, though she does it in a way that feels a little too focused, like she’s listening to the house while she works. You don’t mind. It’s useful."

    narrator "You go looking for her and find her in the wash area. There’s a basket of dirty clothes at her feet. A few pieces are in the water. The rest are still dry."

    narrator "Helena isn’t washing anything. She’s holding one of your shirts up to her face, breathing it in with her eyes half-closed."

    show expression "images/cg/helena/helena07.png" as cg_scene
    with dissolve

    mc "That’s not how laundry works."

    helena "I know."

    mc "Then why are you smelling it?"

    narrator "She doesn’t drop the shirt. She just lowers it a little, enough to look at you over the fabric."

    helena "It smells like the house now."

    helena "Before you came, this place didn’t smell like anything. Wood. Dust. Rain when it got in. Empty smells. I could sleep here and still feel like I was outside."

    helena "Now it smells like someone lives here. Like food. Like sleep. Like you walking through the rooms."

    helena "It makes me feel like I have a home."

    mc "Dirty clothes don’t smell like home. They smell like sweat."

    helena "I like that too."

    narrator "She brings the shirt back to her face and inhales again, slower this time, as if the distinction you just made doesn’t matter at all."

    helena "Sweat is honest. It stays in the cloth. It means you were here, working, getting hot, leaving something behind."

    helena "Empty houses don’t do that."

    mc "You’re a weirdo."

    helena "Yes."

    mc "That kind of thing scares people off."

    helena "I know."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("helena", "default") as helena at center
    with dissolve

    narrator "She finally looks at you properly. There’s no embarrassment on her face. If anything, she looks calm. Almost pleased."

    helena "But you haven’t made me leave."

    helena "If it bothered you that much, I wouldn’t still be sleeping upstairs. I wouldn’t still be touching your clothes. I wouldn’t still be here."

    helena "So I think you don’t mind that I’m a weirdo. Not as much as you say."

    mc "Don’t tempt your luck."

    narrator "Helena smiles a little, small and crooked, like she heard the warning and filed it away as something softer than it was meant to be."

    helena "I won’t. I’ll finish the laundry."

    narrator "She says that, then immediately lifts another piece of your clothing to her face before putting it in the water. You leave her to it."

    hide helena
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["helena"] += 1
    $ affection["helena"] = min(100, affection["helena"] + 5)
    $ advance_hint("helena")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label helena_fifth_encounter:

    scene bg kitchen_day
    with fade

    narrator "You wake up later than usual. You stayed up too long last night, and your head still feels heavy. Then you hear it from downstairs: the soft pop of oil, eggs cooking, a pan shifting over the fire."

    narrator "For a second you tense. Someone is in the kitchen."

    narrator "You go down quickly. Helena is already there, standing at the stove in that same worn dress, cooking breakfast like she belongs in the house. She doesn’t jump when she sees you. She just looks over her shoulder."

    show expression "images/cg/helena/helena08.png" as cg_scene
    with dissolve

    mc "Uh... how was your morning?"

    helena "She already left. I waited until she was gone before I came down."

    narrator "She says it so plainly that it takes you a second to catch up."

    mc "So you noticed. Sorry."

    helena "Don’t be."

    helena "It’s obvious. You bring girls here to fuck them. Even Pokémon, for some reason. I knew that before you knew I was living here."

    mc "I... didn’t expect you to know that much. Now I’m a little embarrassed."

    helena "Jeje. I don’t mind."

    narrator "She turns back to the pan for a moment, then inhales, slow and unashamed, as if the kitchen still holds last night in the air."

    helena "I like it, actually. Being upstairs. Listening to them. Hearing the bed. The wet sounds. The way the house changes when you’re having sex."

    helena "The smell stays after they leave. Sweat. Skin. Cum. It’s thick. It gets in the sheets and the hallway and even down here if the night goes long enough."

    helena "It makes me wet. I sit up there and breathe it in and think about you doing that in the room below me."

    helena "So no. It doesn’t bother me."

    helena "But I want a turn too."

    narrator "She looks at you while she says it. No teasing smile. No shy glance. Just that same strange, direct calm."

    mc "Haha. Okay. You caught me."

    mc "I guess I’m a little weird too."

    helena "I already knew that."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["helena"] += 1
    $ affection["helena"] = min(100, affection["helena"] + 5)
    $ advance_hint("helena")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label helena_sixth_encounter:

    scene bg home_interior_night
    with fade

    narrator "Rain hits the roof hard enough to wake you. Then you feel it: someone standing by the bed. When you turn, Helena is there in the dark, practically naked except for her pale pink panties. Her hair is damp. Her skin looks cold."

    show expression get_char_sprite("helena", "default") as helena at center
    with dissolve

    helena "I can’t sleep. It’s too cold."

    mc "Are you serious? You’re not cold sleeping like that?"

    helena "I am. But clothes don’t help in this situation."

    helena "Can I stay with you tonight?"

    mc "Okay. Fine. Just don’t be so invasive."

    helena "Alright. I won’t be more invasive than normal."

    narrator "She gets into the bed immediately. Not beside you. Against you. Her bare chest presses to your side, her thigh hooks over yours, and her face finds the heat of your neck like she’s been waiting for it. A second later her hand slides under your underwear."

    mc "This is your idea of not being invasive?"

    helena "I said I wouldn’t be more invasive than normal."

    narrator "Her fingers wrap around your cock and start stroking it slowly. You’re already hard. She notices. Of course she notices."

    helena "Besides... he likes it too, doesn’t he?"

    mc "How is he supposed to stay calm when you’re rubbing against me naked and touching me like that?"

    helena "Okay, okay. Let me help you settle it."
    
    hide helena
    with dissolve

    show expression "images/cg/helena/helena09.png" as cg_scene
    with dissolve

    narrator "Helena disappears under the blankets. You feel her heavy breasts press around your cock first, warm and soft, squeezing you tightly between them."

    narrator "Then her mouth joins in. She licks the head slowly, sucks it, and keeps stroking you with her chest at the same time."

    helena "Mmm... you smell stronger like this."

    narrator "She doesn’t rush. Her breath is hot against your skin as she takes her time, sliding her tits up and down your length while her tongue circles the tip."

    helena "Hah... I like it when you’re like this."

    narrator "Every so often she takes you deeper into her mouth, wet and messy, then pulls back to focus on the head again while her breasts keep squeezing and rubbing."

    narrator "The blankets shift with her movements. Soft, wet sounds fill the small space under them."

    helena "Mmmh... don’t hold back."

    narrator "It doesn’t take long. You cum hard, and she stays right there under the blankets, letting it land across her cheeks, lips, and tongue."

    narrator "You hear a small, pleased sound from her, almost happy, as she keeps gently milking you with her mouth and tits until you’re finished."

    narrator "She comes back up after a moment. Cum is still on her face. She looks satisfied, not embarrassed."

    show expression "images/cg/helena/helena10.png" as cg_scene
    with dissolve

    helena "There. Now we can sleep."

    mc "You’re not going to wash your face?"

    helena "No. I’m more than fine like this."

    mc "Okay. Just don’t get it on my bed."

    helena "You don’t say that to the other girls."

    narrator "She settles against you again, still mostly naked, still too close, her stained face tucked near your chest like that’s the most comfortable way she knows how to sleep."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["helena"] += 1
    $ affection["helena"] = min(100, affection["helena"] + 5)
    $ advance_hint("helena")
    $ advance_slot(2)

    jump expression "location_" + current_location


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label helena_seventh_encounter:

    scene bg home_interior_night
    with fade

    narrator "Helena has been at it all night. She keeps brushing against you. Sitting too close. Asking, then asking again, then pretending she wasn’t asking while her hand finds your thigh. By the time she leans in one more time, your patience is already thin."

    show expression get_char_sprite("helena", "default") as helena at center
    with dissolve

    mc "You’re exhausting."

    helena "Then use me to get rid of it."

    mc "That’s your answer to everything."

    helena "It works."

    narrator "You look at her for a second. She’s already undressed, waiting like this was always going to happen. After a moment you give in, more out of irritation than romance."

    mc "You know what? Fine. You asked for it. Don’t regret it later."

    hide helena
    with dissolve

    show expression "images/cg/helena/helena11.png" as cg_scene
    with dissolve

    narrator "You turn her around and bend her over the bed. Helena goes easily, almost eagerly. You pull her arms back and hold them there, using that grip to keep her in place as you push into her from behind."

    helena "Ah- that’s... tight."

    narrator "You don’t start slow. You fuck her hard, pulling her arms back every time your hips slam against her. The bed creaks under the force. Helena’s breath breaks into short, wet sounds, her face pressed into the sheets."

    helena "Nngh... yes... like that..."

    narrator "You keep going rough and deep, using the grip on her arms to pull her back onto you. Her heavy breasts drag against the mattress with every thrust. She doesn’t ask you to stop. If anything, she pushes back into you, messy and hungry."

    helena "Harder... I can take it...!"

    narrator "Her moans grow louder and more broken. You feel her start to tighten around you, her body shaking as the roughness pushes her closer."

    helena "Hah...! Don’t stop- I’m...!"

    narrator "Helena cums hard with a sharp cry, clenching tightly around you while you keep holding her arms back. The way she squeezes pulls you over the edge right after."

    show expression "images/cg/helena/helena12.png" as cg_scene
    with flash

    narrator "You finish deep inside her, still gripping her arms as you empty yourself. She shudders and stays bent over for a moment, breathing hard, her cheek against the mattress. Only then do you let go."

    narrator "The two of you end up on the bed after. Helena immediately attaches herself to you the way she always does: too close, too warm, one leg over yours, her face against your chest. You don’t tell her to move."

    show expression "images/cg/helena/helena10.png" as cg_scene
    with dissolve

    mc "That what you wanted? You satisfied?"

    helena "I loved it."

    helena "But you were too rough. Next time, do it calmer."

    mc "Then I hope you learned your lesson."

    helena "I did."

    helena "I have to help you destress more often. That way you won’t get to the point where you have to fuck me that hard."

    narrator "You let out a long breath and stare at the ceiling."

    mc "Unbelievable. At this rate you’re going to make me as crazy as you."

    helena "Jeje. Is that a compliment?"

    mc "I don’t know what I’m going to do with you."

    helena "Let me sleep down here with you?"

    mc "Fine. You can. As long as I’m not bringing someone else over that day. Got it?"

    helena "Got it."

    narrator "She settles even closer, already half-asleep, her body heavy and warm against yours. Just before she drifts off, her voice comes out small and strangely happy."

    helena "I love you."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["helena"] += 1
    $ affection["helena"] = min(100, affection["helena"] + 5)
    $ advance_hint("helena")
    $ advance_slot(2)

    jump expression "location_" + current_location
