# ============================================================
# POKETOWN, characters/dawn.rpy
# ============================================================

label interact_dawn:

    $ pending = get_pending_delivery("dawn")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            dawn "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            dawn "I'm still waiting for my order..."
            dawn "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("dawn", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["dawn"]
    $ slot = current_slot
    $ prog = character_progress["dawn"]

    if prog == 0:
        jump dawn_meeting
    elif prog == 1 and aff >= 10 and money >= 20 and loc == "plaza" and slot in [3, 4]:
        jump dawn_first_encounter
    elif prog == 2 and aff >= 20 and money >= 40  and loc == "plaza" and slot in [3, 4]:
        jump dawn_second_encounter
    elif prog == 3 and aff >= 35 and money >= 80 and loc == "plaza" and slot in [3, 4]:
        jump dawn_third_encounter
    elif prog == 4 and aff >= 50 and loc == "plaza" and slot in [3, 4]:
        jump dawn_fourth_encounter
    elif prog == 5 and aff >= 65 and money >= 240 and loc == "shopping_center" and slot in [3, 4]:
        jump dawn_fifth_encounter
    elif prog == 6 and aff >= 80 and loc == "plaza" and slot in [1, 2]:
        jump dawn_sixth_encounter
    elif prog == 7 and aff >= 95 and loc == "plaza" and slot in [3, 4]:
        jump dawn_seventh_encounter
    else:
        jump dawn_contextual_dialogue

label dawn_contextual_dialogue:
    show expression get_char_sprite("dawn", "default") as dawn at center
    with dissolve
    $ affection["dawn"] = min(100, affection["dawn"] + 3)

    if aff_tier == "stranger":
        if loc == "shopping":
            dawn "Oh, good eye! That one just came in."
            dawn "Sorry, force of habit. I'm Dawn. I love fashion almost professionally."
        else:
            dawn "Hi! I'm Dawn. I feel like we should have met sooner."
    elif aff_tier == "acquaintance":
        if loc == "shopping":
            dawn "I was going to get that but honestly? It would look better on you."
        elif loc == "cafe":
            dawn "I come here to think. And to people-watch. And to be seen. All three."
        else:
            dawn "Hey! You have great timing, I was just thinking about you."
    elif aff_tier == "friend":
        if loc == "plaza":
            dawn "I love this spot. And I love that we keep ending up here at the same time."
        elif time_tier == "evening":
            dawn "Evening light makes everything look better. Including this conversation."
        else:
            dawn "I don't say this easily but you're genuinely one of my favorite people."
    elif aff_tier == "close":
        if loc == "cafe":
            dawn "I used to come here alone. Now I keep hoping you'll walk in."
        else:
            dawn "I've tried to figure out what it is about you."
            dawn "I think it's that you actually listen. That's rare."

    hide dawn
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location

# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label dawn_meeting:


    narrator "you notice a girl with long blue hair sitting on a bench, looking frustrated while checking her phone."

    show expression get_char_sprite("dawn", "default") as dawn at center
    with dissolve

    dawn "Ugh... not now..."

    mc "Hey, is everything okay?"

    dawn "Huh?" 

    narrator "She looks up at you with a mix of surprise and annoyance."

    dawn "Sorry, but I don't have time to talk with strangers right now. I'm really busy."

    narrator "She sighs deeply and looks back at her phone, clearly frustrated and distracted."

    hide dawn
    with dissolve

    $ character_progress["dawn"] += 1
    $ affection["dawn"] = min(100, affection["dawn"] + 5)
    $ advance_hint("dawn")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label dawn_first_encounter:

    scene bg plaza_night
    with fade

    narrator "That same night, you're relaxing on a bench in the plaza, casually scrolling through your phone."

    show expression "images/cg/dawn/Dawn02.png" as cg_scene
    with dissolve

    narrator "A suggestive thumbnail catches your attention. It's a photo of a girl with long blue hair, lifting her blouse and sensually exposing her breasts. Her face is partially covered, but you instantly recognize her as the same girl you saw on the plaza earlier that day."

    mc "Wait... that's her."

    narrator "Curious, you enter her profile. It's a small paid adult content account under the name 'DawnStarXX'. She doesn't have many subscribers yet."

    narrator "Feeling a mix of surprise and curiosity, you decide to send her $20."

    narrator "After sending the money, you notice her account goes offline almost immediately."

    narrator "You wonder if she realized someone from town found her secret."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["dawn"] += 1
    $ affection["dawn"] = min(100, affection["dawn"] + 5)
    $ advance_hint("dawn")
    $ advance_slot(2)

    jump location_plaza

# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label dawn_second_encounter:

    scene bg plaza_night
    with fade

    narrator "Later that night, you're back in the plaza, sitting on a bench and checking your phone."

    show expression "images/cg/dawn/Dawn01.png" as cg_scene
    with dissolve

    narrator "Suddenly, you receive a new private message from 'DawnStarXX'."

    "DawnStarXX" "Thank you so much for your donation earlier... You're the biggest tip I've received this month."

    narrator "You think for a moment whether to reply or not, but end up typing back."

    mc "You're welcome. I really liked your photo. Saw that you accept donations."

    "DawnStarXX" "It's been really difficult lately... so I appreciate every single person who supports me. Thank you again."

    narrator "You decide to push a little further."

    mc "I'd be willing to send an even bigger donation tonight... but only with one condition."

    mc "Post a new erotic photo wearing lingerie. If you do it, I'll send it right away."

    narrator "The chat shows that she is typing... then stops... then starts typing again."

    "DawnStarXX" "......"

    "DawnStarXX" "That's... a pretty big request."

    narrator "The conversation stops there. You wait for several minutes, but she doesn't reply anymore."

    narrator "You close the app and decide to wait."

    hide cg_scene
    with dissolve

    narrator "About an hour later, you refresh her profile and see a new photo has been uploaded."

    show expression "images/cg/dawn/Dawn03.png" as cg_scene
    with dissolve

    narrator "It's a sensual photo of her in underwear, posing shyly in front of a mirror. Her face is still partially hidden."

    narrator "You immediately send her $40."

    narrator "She doesn't message you back, but you notice that the photo stays up."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["dawn"] += 1
    $ affection["dawn"] = min(100, affection["dawn"] + 5)
    $ advance_hint("dawn")
    $ advance_slot(2)

    jump location_plaza


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label dawn_third_encounter:

    scene bg plaza_night
    with fade

    narrator "A few nights later, you return to the plaza at night and open the app again."

    show expression "images/cg/dawn/Dawn01.png" as cg_scene
    with dissolve

    narrator "Dawn's profile has become noticeably more active. Her erotic photos are getting more frequent and bolder. It seems your previous suggestion was well received by her audience."

    mc "Your posts have been getting a lot more attention lately. Looks like people really liked the new direction."

    "DawnStarXX" "Thank you... I owe that to your suggestion. The donations have increased and I'm feeling a bit more relieved..."

    "DawnStarXX" "But I'm still struggling a lot."

    narrator "You decide to push her further."

    mc "I can send you the same amount as last time if you post a new photo... completely naked, with the word 'slut' written on your belly."

    "DawnStarXX" "..."

    "DawnStarXX" "That's... way too much. I don't think I'm ready for something like that."

    narrator "You wait a moment before replying."

    mc "I'll pay double this time."

    narrator "The chat falls completely silent. She stops typing."

    hide cg_scene
    with dissolve

    narrator "You wait for nearly an hour, checking her profile every few minutes."

    show expression "images/cg/dawn/Dawn04.png" as cg_scene
    with dissolve

    narrator "Finally, a new photo appears on her profile."

    narrator "It's a full nude shot. Dawn is standing in front of her mirror, completely naked, with the word 'slut' clearly written in red marker across her lower belly. Her face is still partially hidden, but her expression looks deeply embarrassed."

    narrator "You immediately send her $80."

    narrator "The photo remains public. She doesn't send any message after that."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["dawn"] += 1
    $ affection["dawn"] = min(100, affection["dawn"] + 5)
    $ advance_hint("dawn")
    $ advance_slot(2)

    jump location_plaza


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label dawn_fourth_encounter:

    scene bg plaza_night
    with fade

    narrator "Once again, you find yourself in the plaza at night. You open the app and message DawnStarXX."

    show expression "images/cg/dawn/Dawn01.png" as cg_scene
    with dissolve

    mc "Hey. Were you waiting for me?"

    "DawnStarXX" "...... Yeah... I guess I was."

    mc "Does it excite you? Taking orders from a stranger on the internet?"

    narrator "She doesn't reply to that message."

    mc "It's fine. If you've been waiting for me, it must be because you want to take the next step."

    "DawnStarXX" "What kind of photo do you want to see this time?"

    mc "Maybe this time I don't want just a photo."

    mc "What if we meet in person?"

    "DawnStarXX" "No. Absolutely not. I don't want to mix this with my real life."

    mc "I'll pay you $80."

    "DawnStarXX" "I'm sorry... but I wouldn't do that for $80."

    mc "What about $160?"

    narrator "The chat shows her typing for a long time before she finally responds."

    "DawnStarXX" "It's absurd anyway... Even if I accepted, I live very far away. We couldn't meet."

    mc "Actually, I'm also from a remote place. Does Heartwood Town sound familiar?"

    narrator "The message is delivered, but she stops replying. The chat remains silent for the rest of the night."

    hide cg_scene
    with dissolve

    narrator "You can almost imagine her shock on the other side of the screen."

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["dawn"] += 1
    $ affection["dawn"] = min(100, affection["dawn"] + 5)
    $ advance_hint("dawn")
    $ advance_slot(2)

    jump location_plaza

# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label dawn_fifth_encounter:

    scene bg shopping_center_night
    with fade

    narrator "That night you are walking through the shopping center when your phone vibrates."

    show expression "images/cg/dawn/Dawn01.png" as cg_scene
    with dissolve

    "DawnStarXX" "Please... don't reveal my identity. I'll do anything you want."

    mc "I don't know what you're talking about."

    "DawnStarXX" "You mentioned Heartwood Town... You already know who I am, don't you?"

    mc "I really don't know who you are in real life. But yes, I figured it out from your last messages."

    mc "Honestly? It's a very pleasant surprise."

    "DawnStarXX" "..."

    mc "So, about my offer to meet... are you still interested?"

    "DawnStarXX" "This is different... Talking about it in chat is one thing, but in real life..."

    mc "There's a way we can keep your anonymity. Go to the far bathrooms in the shopping center. The last stall has a hole in the wall."

    "DawnStarXX" "You want me to... do something sexual through a glory hole?!"

    mc "What did you expect when you said you'd do anything?"

    mc "I'll pay you $240 if you do it."

    narrator "The chat remains silent for a long time. You can almost feel her internal struggle."

    "DawnStarXX" "...Okay. I'll do it."

    hide cg_scene
    with dissolve

    narrator "You head to the remote bathrooms and enter the stall with the glory hole. You wait several tense minutes."

    narrator "Finally, you hear the door of the next stall open and close. Soft footsteps."

    show expression "images/cg/dawn/Dawn05b.png" as cg_scene
    with dissolve

    narrator "A moment later, a delicate, slightly trembling hand slips through the glory hole."

    narrator "After a few seconds of hesitation, her warm fingers wrap gently around your cock. Her touch is shy and exploratory at first."

    dawn "Mmm..."

    narrator "She starts stroking you slowly, her movements uncertain but full of curiosity. Gradually, her hand becomes more confident, pumping you with a steady rhythm."

    narrator "Then you feel something warmer and softer, her breath against your skin. A second later, her lips press against the head of your cock."

    show expression "images/cg/dawn/Dawn05.png" as cg_scene
    with dissolve

    narrator "Dawn takes you into her mouth, sucking gently at first. Her tongue swirls hesitantly around the tip before she starts bobbing her head, taking you deeper with growing eagerness."

    dawn "Nngh... mmmh..."

    narrator "Even through the wall, you can hear her soft, embarrassed moans as she sucks you with increasing passion. Her hand strokes the base while her mouth works the head and shaft."

    narrator "The combination of her warm mouth and the thrill of the situation quickly pushes you to the edge."

    show expression "images/cg/dawn/Dawn05a.png" as cg_scene
    with flash

    narrator "With a groan, you cum hard through the glory hole. Dawn lets out a surprised whimper but doesn't pull away, taking as much as she can."

    hide cg_scene
    with dissolve

    narrator "After you finish, you quickly clean up and leave the bathroom without saying anything."

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["dawn"] += 1
    $ affection["dawn"] = min(100, affection["dawn"] + 5)
    $ advance_hint("dawn")
    $ advance_slot(2)

    jump location_shopping_center

# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label dawn_sixth_encounter:

    scene bg plaza_day
    with fade

    narrator "During the day, while walking through the plaza, your phone vibrates with a new message."

    show expression "images/cg/dawn/Dawn01.png" as cg_scene
    with dissolve

    "DawnStarXX" "I knew it! I knew it!!! You're that dirty farmer!"

    mc "Calm down. Yes, I knew who you were from the very beginning."

    "DawnStarXX" "Why didn't you say anything?!"

    mc "I didn't want to hurt you or expose you. You were already doing it before I found your account. I just supported you and gave you some suggestions."

    "DawnStarXX" "..."

    "DawnStarXX" "I see..."

    mc "Now that the masks are off... would you like to grab a coffee? We can talk properly."

    "DawnStarXX" "...... Okay. Let's meet at the cafe."

    hide cg_scene
    with dissolve

    scene bg cafe
    with fade

    narrator "A short while later, you meet Dawn at the cafe. She looks nervous but sits down with you."

    show expression "images/cg/dawn/Dawn06.png" as cg_scene
    with dissolve

    dawn "I... I still can't believe this is happening."

    dawn "I haven't been able to find a proper job since I moved here. Rent is expensive and I was falling behind on payments..."

    dawn "But thanks to you... my situation has improved. Not just because of the money, but because my content started getting more attention after your suggestions."

    mc "I'm glad I could help. If you want, I can keep helping you with your content."

    mc "I'm sure if you include more real action, your subscribers will increase a lot."

    narrator "Dawn blushes deeply and looks down at her coffee."

    dawn "I... I'll think about it."

    dawn "Thank you again... for not exposing me."

    hide cg_scene
    with dissolve

    narrator "After finishing your coffee, you both say goodbye. The atmosphere between you feels much more intimate now."

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["dawn"] += 1
    $ affection["dawn"] = min(100, affection["dawn"] + 5)
    $ advance_hint("dawn")
    $ advance_slot(2)

    jump location_plaza


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label dawn_seventh_encounter:

    scene bg plaza_night
    with fade

    narrator "Dawn finally agreed to let you help her with new content. You arrive at her small apartment that night."

    show expression get_char_sprite("dawn", "default") as dawn at center
    with dissolve

    narrator "As soon as you enter, you find her already waiting in elegant black lingerie. She looks nervous but excited."

    dawn "I... I prepared everything. The lighting, the camera... We can start whenever you want."

    mc "You look amazing."

    hide dawn
    with dissolve

    show expression "images/cg/dawn/Dawn07.png" as cg_scene
    with dissolve

    narrator "You both move to Dawn's bedroom. The moment the door closes, she pushes you onto the bed with surprising boldness and climbs on top of you."

    narrator "Facing away from you in reverse cowgirl position, and slowly lowers herself onto your cock."

    dawn "Mmh...! It's really going inside... I can feel every inch..."

    narrator "She starts riding you with slow, cautious movements, clearly still a little nervous. But as pleasure builds, her hips begin moving faster and more eagerly."
    
    show expression "images/cg/dawn/Dawn07a.png" as cg_scene
    with flash

    narrator "You reach up and give her ass a firm spank. The sound echoes in the room."

    dawn "Ahh?! W-what are you doing?!"

    mc "Trust me. Your audience loves when you get a little humiliated. This is going to do really well."

    narrator "Dawn lets out a surprised moan, but instead of protesting further, she starts riding you even harder. Her cheeks burn bright red, yet her movements betray how much the words affected her."

    dawn "You're so perverted... Ahh...! But... keep going... spank me again..."

    narrator "You spank her again, harder this time. Dawn's moans grow louder and more shameless as she bounces on your cock, her ass rippling with every impact."

    dawn "Nngh...! This is so embarrassing... but it feels so good..."

    show expression "images/cg/dawn/Dawn07b.png" as cg_scene
    with flash

    narrator "You spend the rest of the night exploring multiple positions. Dawn becomes more and more uninhibited with each passing hour, going from shy whimpers to loud, desperate moans as she fully embraces her corrupted side."

    narrator "You take dozens of photos and videos: her riding you, on all fours, pressed against the wall, and many more. The more exposed and degraded she feels, the wetter and more eager she becomes."

    dawn "Haaah... Haaah... I can't believe I'm letting you do all this to me... but don't stop... please don't stop..."

    narrator "By the end of the night, Dawn is a trembling, satisfied mess, completely addicted to the thrill of being watched and used."

    hide cg_scene
    with dissolve

    narrator "Much later, when you finally leave her apartment, you feel satisfied. You open the app one last time before heading home."

    show expression "images/cg/dawn/Dawn08.png" as cg_scene
    with dissolve

    narrator "Her newest post is already up, a very explicit set of photos and a short video from tonight. The comments and tips are flooding in."

    narrator "You smile as you walk away, knowing that Dawn's corruption journey has only just begun."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["dawn"] += 1
    $ affection["dawn"] = min(100, affection["dawn"] + 5)
    $ advance_hint("dawn")
    $ advance_slot(2)

    jump location_plaza

