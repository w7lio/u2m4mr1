# ============================================================
# POKETOWN, characters/roxanne.rpy
# ============================================================

label interact_roxanne:
    $ pending = get_pending_delivery("roxanne")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            roxanne "Oh! You brought my order. Thank you so much!"
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            roxanne "I'm still waiting for my order..."
            roxanne "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("roxanne", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["roxanne"]
    $ slot = current_slot
    $ prog = character_progress["roxanne"]

    if prog == 0 and loc == "library" and slot in [0, 1, 2]:
        jump roxanne_meeting
    elif prog == 1 and aff >= 10 and stat_charisma >= 10 and loc == "library" and slot in [0, 1, 2]:
        jump roxanne_first_encounter
    elif prog == 2 and aff >= 20 and stat_charisma >= 15 and loc == "library" and slot in [0, 1, 2]:
        jump roxanne_second_encounter
    elif prog == 3 and aff >= 35 and stat_charisma >= 20 and loc == "beach" and slot in [1, 2] and "roxanne_swimsuit" in unlocked_skins["roxanne"]:
        jump roxanne_third_encounter
    elif prog == 4 and aff >= 50 and loc == "beach" and slot in [1, 2]:
        jump roxanne_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_intelligence >= 20 and loc == "library" and slot in [0, 1, 2]:
        jump roxanne_fifth_encounter
    elif prog == 6 and aff >= 80 and loc == "plaza" and slot in [3, 4] and "roxanne_Lingerie" in unlocked_skins["roxanne"]:
        jump roxanne_sixth_encounter
    elif prog == 7 and aff >= 95 and stat_charisma >= 25 and loc == "plaza" and slot == 4:
        jump roxanne_seventh_encounter
    else:
        jump roxanne_contextual_dialogue


# ------------------------------------------------------------
# CONTEXTUAL DIALOGUE
# ------------------------------------------------------------

label roxanne_contextual_dialogue:

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve
    $ affection["roxanne"] = min(100, affection["roxanne"] + 3)

    if aff_tier == "stranger":
        if loc == "library":
            roxanne "Please keep your voice down. This is a library."
            roxanne "...Sorry. That came out harsher than I meant. I'm Roxanne."
        else:
            roxanne "Hi. I spend most of my time at the library if you're ever looking for me."

    elif aff_tier == "acquaintance":
        if loc == "library":
            roxanne "Have you read anything interesting lately?"
            roxanne "I can make recommendations if you'd like."
        elif loc == "plaza":
            roxanne "I needed a break from reading. My eyes were starting to cross."
        else:
            roxanne "Oh, hello. Nice to run into you."

    elif aff_tier == "friend":
        if loc == "library":
            roxanne "I found a book you'd probably like. I bookmarked a section for you."
        elif time_tier == "evening":
            roxanne "The library at night is a different place. Peaceful."
            roxanne "I'm glad you came by."
        else:
            roxanne "You know, you're one of the few people I actually enjoy talking to."

    else:
        if loc == "library":
            roxanne "I've been saving this book for you. Don't ask me why, I just knew."
        elif loc == "plaza":
            roxanne "This used to be my favorite place in town. Now it's my second favorite."
            roxanne "...Wherever you are is first. Obviously."
        else:
            roxanne "I don't show my personal work to many people. But I'd show you."

    hide roxanne
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label roxanne_meeting:

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    roxanne "Oh, you're the new farmer. Do you need something?"
    roxanne "I'm busy, I don't want to waste my time talking to you."

    hide roxanne
    with dissolve

    $ affection["roxanne"] = min(100, affection["roxanne"] + 5)
    $ character_progress["roxanne"] += 1
    $ advance_hint("roxanne")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label roxanne_first_encounter:

    scene bg library_day
    with fade

    narrator "While wandering through the library, you spot Roxanne sitting in a quiet corner, seemingly absorbed in a book."

    mc "Better not to bother her."

    narrator "Just as you turn to leave, a soft, muffled moan reaches your ears."

    show expression "images/cg/roxanne/Roxanne01.png" as cg_scene
    with dissolve

    narrator "You carefully peek between the shelves. Roxanne has one hand discreetly inside her skirt, slowly rubbing her clit. Her breathing is heavy and her cheeks are flushed."

    mc "Do you... need any help with that?"

    hide cg_scene
    with dissolve

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    roxanne "A-ahh?! What the,?! Were you watching me?!"

    mc "I was just looking for books. I didn't expect to find you... doing that in the middle of the library."

    roxanne "T-this isn't what it looks like! I mean, it is, but... ugh!"

    mc "Wouldn't it be easier to do this at home?"

    roxanne "You don't understand... At home it doesn't feel the same. The risk... the possibility of getting caught... it makes everything more intense."

    mc "So you actually enjoy doing it in public?"

    roxanne "That's none of your business! Just... just forget you saw anything!"

    narrator "Mortified, Roxanne grabs a book from the shelf and throws it at you before storming off, her face burning red."

    hide roxanne
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["roxanne"] += 1
    $ affection["roxanne"] = min(100, affection["roxanne"] + 5)
    $ advance_hint("roxanne")
    $ advance_slot(2)

    jump location_library


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label roxanne_second_encounter:

    scene bg library_day
    with fade

    narrator "The library looks very quiet today, almost too quiet. You decide to look for Roxanne."

    narrator "You find her in the most secluded corner of the library. She's crouched down, searching for something on the lower shelf."

    show expression "images/cg/roxanne/Roxanne02.png" as cg_scene
    with dissolve

    roxanne "Ahhhh..."

    narrator "You can't believe it. She's doing it again. Looking more carefully, you realize she's not just touching herself, she's slowly sliding a dildo in and out of her pussy."

    narrator "Her body trembles slightly with every movement, clearly lost in pleasure."

    mc "Now you're bringing your toys too?"

    hide cg_scene
    with dissolve

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    roxanne "Aaaaaah! You again?! You peeping tom!"

    mc "Don't blame me. You're the one masturbating with a dildo in a public library."

    roxanne "I'm not doing it for you to watch!"

    mc "So you enjoy the thrill of doing it in public? The risk of getting caught?"

    roxanne "That's none of your business! Just... just get out of here already!"

    mc "Sure, fine. I won't bother you about your little public shows anymore."

    narrator "Roxanne's face is completely red. She quickly pulls up her panties, grabs her things, and storms off angrily."

    hide roxanne
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["roxanne"] += 1
    $ affection["roxanne"] = min(100, affection["roxanne"] + 5)
    $ advance_hint("roxanne")
    $ advance_slot(2)

    jump location_library

# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label roxanne_third_encounter:

    scene bg beach_day
    with fade

    narrator "While walking along the beach, you spot Roxanne in the distance. You approach curiously."

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    roxanne "Do you have that annoying habit with everyone, or is it just with me?"

    mc "I just wanted to say hi. Last time I said I'd help you with your... hobby."

    roxanne "Don't call it that!"

    mc "Alright, alright. I brought you something."

    narrator "You hand her a small gift bag. Roxanne opens it and pulls out a very revealing bikini."

    roxanne "W-what?! You expect me to wear this?!"

    mc "You don't have to wear it right now. It's just... in case you ever feel like it."

    roxanne "Ugh... Fine. I'll be right back."

    mc "You know, you could just change here. It's not like I haven't seen you in more compromising situations."

    roxanne "Don't push your luck!"

    narrator "Roxanne huffs and walks behind some rocks to change."

    hide roxanne
    with dissolve

    show expression "images/cg/roxanne/Roxanne03.png" as cg_scene
    with dissolve

    narrator "When she returns, she's wearing the new bikini. The fabric is extremely revealing, accentuating her figure in a way that makes her look both stunning and vulnerable."

    roxanne "S-so... what do you think?"

    mc "It looks amazing on you."

    roxanne "D-don't say it like that! And look... people are staring..."

    mc "Relax. From this distance it just looks like a normal swimsuit. Though I have to admit... it suits your tastes perfectly."

    narrator "Roxanne's face turns bright red, but she doesn't cover herself. Instead, she shifts slightly, clearly aware, and secretly thrilled, by the eyes on her."

    hide cg_scene
    with dissolve

    narrator "You spend the rest of the afternoon with Roxanne."

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["roxanne"] += 1
    $ affection["roxanne"] = min(100, affection["roxanne"] + 5)
    $ advance_hint("roxanne")
    $ advance_slot(2)

    jump location_beach


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label roxanne_fourth_encounter:

    scene bg beach_day
    with fade

    narrator "You run into Roxanne again on the beach. She's sitting on the sand, wearing the revealing bikini you gave her."

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    mc "Hey, looks like you really liked my gift after all."

    roxanne "Shut up, idiot. This is my only swimsuit now. I can't wear anything else when I come to the beach."

    hide roxanne
    with dissolve

    show expression "images/cg/roxanne/Roxanne04.png" as cg_scene
    with dissolve

    narrator "As you get closer, you notice her hand is discreetly between her legs, rubbing her pussy over the thin fabric of the bikini."

    mc "I knew you'd be doing something more than just sunbathing."

    roxanne "S-shut up! Stop staring at me like that!"

    mc "If it bothers you so much to be watched... why do you keep doing it in public?"

    hide cg_scene
    with dissolve

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    roxanne "It's not my fault... You gave me this stupidly revealing swimsuit. So it's your responsibility."

    mc "Oh really? You've been responsible for quite a few things lately and never owned up to them either."

    roxanne "Ugh... Fine. If it means you'll stop bothering me and leave quickly... I'll help you."

    narrator "Her face is flushed, but there's a clear spark of nervous excitement in her eyes."

    hide roxanne
    with dissolve

    show expression "images/cg/roxanne/Roxanne05.png" as cg_scene
    with dissolve

    narrator "Roxanne kneels in front of you on the warm sand, her face flushed with a mixture of embarrassment and excitement."

    narrator "With shaky hands, she pulls down your pants and frees your cock. She glances up at you, biting her lip, before leaning forward."

    roxanne "I can't believe I'm doing this... out here..."

    narrator "She starts by slowly licking the head, her warm tongue tracing circles around it. Then she takes you into her mouth, sucking gently at first."

    narrator "The wet sounds of her mouth mix with the rhythmic crash of the waves nearby. She gradually takes you deeper, her head moving back and forth with increasing confidence."

    narrator "Her tongue swirls skillfully around your shaft as she sucks, her cheeks hollowing with each motion."

    roxanne "Mmmh... nngh..."

    narrator "Even though she's clearly embarrassed, her movements become faster and more eager. She looks up at you with watery eyes, torn between shame and arousal."

    show expression "images/cg/roxanne/Roxanne05a.png" as cg_scene
    with flash

    narrator "The combination of her warm mouth and the thrill of being exposed on the beach quickly pushes you toward the edge."

    hide cg_scene
    with dissolve

    narrator "Afterward, you spend some time together on the beach."

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["roxanne"] += 1
    $ affection["roxanne"] = min(100, affection["roxanne"] + 5)
    $ advance_hint("roxanne")
    $ advance_slot(2)

    jump location_beach


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label roxanne_fifth_encounter:

    scene bg library_day
    with fade

    narrator "You spot Roxanne in one of the most secluded corners of the library. At this point, you already know what she's probably doing."

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    roxanne "Argh... damn it. I can't get there..."

    mc "Having trouble today?"

    roxanne "Ah?! You again?! Why do you always show up when I'm... ugh!"

    narrator "She quickly pulls her hand away, clearly frustrated."

    roxanne "I don't feel the thrill anymore. It's just... not working like before."

    mc "The library isn't exciting enough for you now?"

    roxanne "I guess not... After everything we've done, touching myself here just feels... ordinary. The risk isn't the same."

    mc "So you need something stronger to feel that excitement again."

    roxanne "Don't say it like that... It's embarrassing."

    mc "Don't worry. I'll help you find that thrill again."

    narrator "You spend the next while with her, talking quietly and sharing ideas. Roxanne listens attentively, alternating between embarrassment and clear curiosity."

    hide roxanne
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["roxanne"] += 1
    $ affection["roxanne"] = min(100, affection["roxanne"] + 5)
    $ advance_hint("roxanne")
    $ advance_slot(2)

    jump location_library


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label roxanne_sixth_encounter:

    scene bg plaza_night
    with fade

    narrator "You meet Roxanne in the plaza at night, as agreed. The streets are quiet, lit only by the soft glow of the street lamps."

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    mc "Hey. Ready for this?"

    roxanne "Shhh! Keep your voice down... I don't want anyone to notice us."

    mc "Relax. Here, I brought what you asked for."

    narrator "You hand her a large coat and the carefully arranged shibari ropes underneath. Roxanne's eyes widen slightly."

    roxanne "Wow... this is... a lot more revealing than I imagined."

    mc "You don't have to do it if you don't want to. But you specifically asked for this."

    roxanne "I know... I just got nervous seeing it in person. Turn around for a second."

    narrator "Roxanne quickly changes behind a corner. When she returns, she's wearing only the intricate shibari ropes under the large open coat."

    hide roxanne
    with dissolve

    show expression "images/cg/roxanne/Roxanne06.png" as cg_scene
    with dissolve

    roxanne "I feel so exposed... The coat is barely covering anything."

    mc "You look incredible. I knew you'd enjoy walking around like this."

    roxanne "I'm scared someone I know might see me... but at the same time..."

    mc "You're getting wet just from the fear, aren't you?"

    roxanne "S-shut up! That's enough for today. I think I've had my fill of excitement."

    mc "Alright. We'll go further next time."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["roxanne"] += 1
    $ affection["roxanne"] = min(100, affection["roxanne"] + 5)
    $ advance_hint("roxanne")
    $ advance_slot(2)

    jump location_plaza


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label roxanne_seventh_encounter:

    scene bg plaza_night
    with fade

    narrator "Walking through the plaza at night, you run into Roxanne wearing the outfit you gave her."

    show expression get_char_sprite("roxanne", "default") as roxanne at center
    with dissolve

    roxanne "I was waiting for you, I knew you'd come."

    mc "You could invite me over to your place. I'm sure we'd have a better time there."

    roxanne "No. I want us to do it here."

    mc "Do it?!"

    roxanne "Yes. I'm sorry for being so direct, but the toys and my own fingers aren't enough for me anymore. I need something more."

    mc "I thought you'd never ask."

    hide roxanne
    with dissolve


    show expression "images/cg/roxanne/Roxanne07.png" as cg_scene
    with dissolve

    narrator "Roxanne approaches you, breathing heavily, her eyes filled with desperate need."

    narrator "She pulls you into a urgent, messy kiss while grabbing your hand and guiding it under her skirt, pressing your fingers against her soaked pussy."

    roxanne "Touch me... I'm already so wet..."

    narrator "You pull out your hard cock. Roxanne turns around quickly, placing her hands against a stone column and lifting her short skirt, offering herself to you."

    narrator "Her swollen, glistening pussy is completely exposed in the open plaza. The thrill of possibly being seen makes her tremble with anticipation."

    roxanne "Hurry... put it in... I want to feel you right here..."

    show expression "images/cg/roxanne/Roxanne08.png" as cg_scene
    with dissolve

    narrator "You position yourself behind her and slowly push inside her hot, dripping entrance. Roxanne lets out a shaky moan as you fill her completely."

    roxanne "Ahh...! Yes... Deeper..."

    narrator "You start thrusting harder, fucking her against the column. The sound of skin slapping against skin echoes softly in the night air."

    roxanne "Nngh...! Harder... Someone could see us... and I don't even care anymore..."

    narrator "Her moans grow louder and more shameless as you pound into her. The risk of being caught clearly heightens her pleasure."

    roxanne "I'm... I'm going to cum! Ahh!"

    show expression "images/cg/roxanne/Roxanne08a.png" as cg_scene
    with flash

    narrator "Roxanne trembles violently as she cums hard, her pussy clenching tightly around your cock. Her legs shake as waves of pleasure run through her body."

    narrator "The intense contractions push you over the edge. You thrust deep one final time and cum inside her, filling her while she continues to shake against the column."

    narrator "Afterward, you both stay there for a long moment, catching your breath in the open plaza. You end up spending the entire night together under the stars."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["roxanne"] += 1
    $ affection["roxanne"] = min(100, affection["roxanne"] + 5)
    $ advance_hint("roxanne")
    $ advance_slot(2)

    jump location_plaza
