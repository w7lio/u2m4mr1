# ============================================================
# POKETOWN, characters/lusamine.rpy
# ============================================================

label interact_lusamine:

    $ pending = get_pending_delivery("lusamine")
    if pending:
        $ delivered = deliver_mission(pending["id"])
        if delivered:
            lusamine "You brought my order. Good."
            "[pending['item_icon']] Delivered [pending['item_name']] x[pending['quantity']]"
            "💰 Received $[pending['reward']]!"
        else:
            lusamine "I'm still waiting for my order."
            lusamine "I need [pending['item_name']] x[pending['quantity']]."

    $ ctx = get_interaction_context("lusamine", current_location)
    $ aff_tier, time_tier, loc = ctx
    $ aff  = affection["lusamine"]
    $ slot = current_slot
    $ prog = character_progress["lusamine"]

    if prog == 0:
        jump lusamine_meeting
    elif prog == 1 and aff >= 10 and loc == "cafe" and slot in [0, 1, 2]:
        jump lusamine_first_encounter
    elif prog == 2 and aff >= 20 and stat_charisma >= 10 and loc == "cafe" and slot in [0, 1, 2]:
        jump lusamine_second_encounter
    elif prog == 3 and aff >= 35 and stat_charisma >= 15 and loc == "cafe" and slot in [0, 1, 2]:
        jump lusamine_third_encounter
    elif prog == 4 and aff >= 50 and stat_charisma >= 20 and loc == "cafe" and slot in [0, 1, 2]:
        jump lusamine_fourth_encounter
    elif prog == 5 and aff >= 65 and stat_charisma >= 25 and loc == "plaza" and slot in [1, 2]:
        jump lusamine_fifth_encounter
    elif prog == 6 and aff >= 80 and loc == "cafe" and slot in [0, 1, 2]:
        jump lusamine_sixth_encounter
    elif prog == 7 and aff >= 95 and loc == "cafe" and slot in [3, 4]:
        jump lusamine_seventh_encounter
    else:
        jump lusamine_contextual_dialogue


# ------------------------------------------------------------
# CONTEXTUAL DIALOGUE
# ------------------------------------------------------------

label lusamine_contextual_dialogue:

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve
    $ affection["lusamine"] = min(100, affection["lusamine"] + 3)

    if aff_tier == "stranger":
        if loc == "cafe":
            lusamine "Welcome. Sit wherever you like."
        else:
            lusamine "I don't believe we've been introduced. I'm Lusamine."
            lusamine "I run the cafe. Come by if your standards are high enough."

    elif aff_tier == "acquaintance":
        if loc == "cafe":
            lusamine "You've been coming here regularly. I've noticed."
            lusamine "Punctuality and consistency. Good traits."
        elif loc == "plaza":
            lusamine "I rarely come here. Too much noise."
            lusamine "Yet here I am."
        else:
            lusamine "You again. I'm beginning to think this isn't coincidence."

    elif aff_tier == "friend":
        if loc == "cafe":
            lusamine "I had them prepare your usual before you arrived."
            lusamine "Don't make it a habit of expecting that."
        elif time_tier == "evening":
            lusamine "The evenings here are the only time I find tolerable."
            lusamine "Your company makes them more so."
        else:
            lusamine "I don't give compliments easily. But you've earned a few."

    else:
        if loc == "cafe":
            lusamine "Everyone who works here knows you're not just a customer."
            lusamine "I hope that doesn't embarrass you. It shouldn't."
        else:
            lusamine "I've built walls around everything I care about."
            lusamine "You're the first person I've considered letting past them."

    hide lusamine
    with dissolve
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# MEETING
# ------------------------------------------------------------

label lusamine_meeting:

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    lusamine "Well. A new face. I don't often see new people around here. You're the farmer who moved to town?"

    mc "That's me. Just arrived."

    lusamine "Mmm. Sit wherever you like. I'll bring you something."

    narrator "She doesn't ask what you want. A few minutes later she sets down exactly what you would have ordered."

    lusamine "Welcome to town. I hope to see you here often."

    narrator "She turns and leaves before you can respond. Something in her tone didn't sound like hospitality. It sounded more like a decision."

    hide lusamine
    with dissolve

    $ affection["lusamine"] = min(100, affection["lusamine"] + 5)
    $ character_progress["lusamine"] += 1
    $ advance_hint("lusamine")
    $ advance_slot()

    jump expression "location_" + current_location


# ------------------------------------------------------------
# FIRST ENCOUNTER
# ------------------------------------------------------------

label lusamine_first_encounter:

    scene bg cafe
    with fade

    narrator "You come back to the cafe. Lusamine sees you walk in from behind the counter and says nothing, but something in her posture shifts slightly, like someone confirming a hypothesis."

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    lusamine "Back so soon. Sit down, I already know what you want."

    mc "How do you know?"

    lusamine "Because people are predictable. You're slightly less so than most, but still."

    narrator "She brings you the same thing as the first time. You sit and watch her move through the cafe, attending to other customers with an efficiency that doesn't look like effort, it looks like nature."

    mc "Do you always work alone?"

    lusamine "I have staff. But I handle the morning shift myself."

    mc "Why?"

    lusamine "Because that's when the clients I care about come in."

    narrator "She holds your gaze a moment before returning to the counter. When the cafe thins out, she comes back to your table without being called."

    lusamine "Do you have work in town besides the farm?"

    mc "Not yet."

    lusamine "I could offer you something here. A few hours in the morning, nothing complicated."

    mc "Why me?"

    lusamine "Because I think you'd be useful. And because I think you could do with someone to help you find your footing in this town."

    mc "Find my footing?"

    lusamine "This town has its rules. I know all of them. Think it over."

    narrator "She leaves the bill on the table. It's already paid."

    lusamine "Tomorrow at eight, if you're interested. If you don't show up, no hard feelings. But you'll show up."

    narrator "She leaves without waiting for an answer. The next morning, at eight on the dot, you're there."

    hide lusamine
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lusamine"] += 1
    $ affection["lusamine"] = min(100, affection["lusamine"] + 5)
    $ advance_hint("lusamine")
    $ advance_slot(2)

    jump location_cafe


# ------------------------------------------------------------
# SECOND ENCOUNTER
# ------------------------------------------------------------

label lusamine_second_encounter:

    scene bg cafe
    with fade

    narrator "Your first week working at the cafe passes with surprising smoothness. Lusamine gives instructions with surgical precision, corrects mistakes without ever raising her voice, and occasionally watches you with that unreadable expression."

    narrator "At the end of the week, once the last customer leaves, Lusamine leans gracefully against the counter and studies you."

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    lusamine "You're not bad."

    mc "That's... high praise coming from you."

    lusamine "It wasn't praise. It was an observation. I reserve praise for when it's truly deserved."

    mc "And when does that happen?"

    lusamine "Rarely."

    narrator "She tilts her head slightly, observing you with those sharp, calculating eyes."

    lusamine "Do you know why most people who work for me don't last long?"

    mc "Why?"

    lusamine "Because they believe they can push back against me. Or worse... that they can ignore me."

    mc "And me?"

    lusamine "You listen. That's already more than most manage."

    mc "So that's what you're looking for? Someone who obeys?"

    lusamine "I'm looking for someone who understands how things work here." 

    narrator "She takes a slow, deliberate step closer to you."

    lusamine "Do you have any plans this afternoon?"

    mc "No."

    lusamine "Good."

    narrator "She places the keys to the cafe on the counter in front of you."

    lusamine "Lock up when you're done. The keys go under the counter."

    narrator "Without another word, she picks up her coat and heads toward the door, leaving you alone in her cafe."

    hide lusamine
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lusamine"] += 1
    $ affection["lusamine"] = min(100, affection["lusamine"] + 5)
    $ advance_hint("lusamine")
    $ advance_slot(2)

    jump location_cafe


# ------------------------------------------------------------
# THIRD ENCOUNTER
# ------------------------------------------------------------

label lusamine_third_encounter:

    scene bg cafe
    with fade

    narrator "You've been working at the cafe for two weeks now. One quiet morning, before the first customers arrive, Lusamine pulls you aside."

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    lusamine "There's a supplier in the plaza who's been testing my patience. I've asked him three times to adjust his delivery schedule. He keeps ignoring me."

    mc "What do you want me to do?"

    lusamine "Go speak with him. Deliver the same message I did. Sometimes people listen better when it doesn't come directly from me."

    mc "And if he still refuses?"

    lusamine "He won't. Not when he hears my name from someone who actually works for me."

    narrator "You go to the plaza. The moment you mention Lusamine, the supplier's attitude changes completely. The new schedule is settled in under five minutes."

    narrator "When you return to the cafe, Lusamine is already waiting. You never quite figure out how she knows everything so quickly."

    lusamine "Well done, pet."

    mc "Pet?"

    lusamine "It's a term of endearment. In my own way."

    mc "It doesn't sound very endearing."

    lusamine "It is, if you understand me."

    narrator "She studies you for a moment with that cold, calculating gaze."

    lusamine "Come to my house tonight. I have something for you."

    mc "What kind of something?"

    lusamine "The kind that isn't explained. Only received."

    narrator "That night, you arrive at her house. It's exactly as you imagined, elegant, meticulously ordered, and intimidating in its perfection."

    lusamine "You're on time. Good."

    hide lusamine
    with dissolve

    show expression "images/cg/lusamine/Lusamine01.png" as cg_scene
    with dissolve

    narrator "Lusamine leads you to her bedroom without a word. The room is as elegant and orderly as the rest of her house."

    narrator "She takes out a pair of sleek black handcuffs and secures your wrists tightly behind your back. With a single look, she makes you kneel in front of her."

    lusamine "Good boy."

    narrator "She sits gracefully on the edge of the bed and slowly removes one of her expensive heels, letting it drop to the floor."

    narrator "She extends her bare foot and presses it firmly against your crotch, rubbing your hardening cock with deliberate, controlled movements."

    lusamine "Look at me."

    narrator "Her eyes never leave yours as she works your cock with her foot, sometimes slow and teasing, sometimes applying more pressure. Every movement is precise and commanding."

    lusamine "You're already this hard just from my foot? How predictable."

    narrator "She smiles faintly, a cold, satisfied curve of her lips, as she feels you throbbing beneath her sole. She increases the pace, rubbing faster and more firmly, completely in control."

    lusamine "You don't get to cum until I allow it. Understood?"

    narrator "She continues the slow, torturous footjob, watching every reaction on your face with clinical interest. When she finally decides you've had enough, she presses down harder."

    lusamine "Now."

    narrator "You can't hold back any longer. You cum hard, spilling over her foot. Lusamine watches with a pleased, almost predatory expression."

    lusamine "You're more obedient than I expected. I like that."

    narrator "She keeps her foot pressed against you for a moment longer, savoring the sight, before finally pulling away."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lusamine"] += 1
    $ affection["lusamine"] = min(100, affection["lusamine"] + 5)
    $ advance_hint("lusamine")
    $ advance_slot(2)

    jump location_cafe


# ------------------------------------------------------------
# FOURTH ENCOUNTER
# ------------------------------------------------------------

label lusamine_fourth_encounter:

    scene bg cafe
    with fade

    narrator "Things with Lusamine have settled into a clear rhythm. You work at the cafe, run her errands, and every so often she summons you to her house, always on her schedule, always on her terms."

    narrator "One morning, she does something unusual. Instead of staying behind the counter, she sits directly across from you."

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    lusamine "Tell me something about yourself. Something I don't already know."

    mc "Is there anything you don't know?"

    lusamine "Very little. But I enjoy hearing it from your own mouth."

    mc "Why?"

    lusamine "Because most people lie when talking about themselves. You don't. That's rare enough to be interesting."

    mc "What do you want to know?"

    lusamine "Why you really came to this town. The truth. Not the polite version you tell others."

    narrator "Her gaze is steady and piercing. There's something in the way she asks that makes it almost impossible to deflect."

    narrator "You tell her. She listens in complete silence, giving you her full, undivided attention, the kind that feels both like a privilege and a trap."

    lusamine "Thank you for being honest with me."

    mc "Was that a test?"

    lusamine "Everything is a test. You passed this one."

    narrator "She stands up gracefully and rests a hand on your shoulder for a brief moment, an unusually gentle gesture coming from her."

    lusamine "Come to my house tonight. There's something I want to show you."

    narrator "That night, when you arrive at her house, Lusamine is still in complete control... but something feels different. The distance between you has narrowed, even if only slightly. Her intensity remains, sharper than ever."

    hide lusamine
    with dissolve

    show expression "images/cg/lusamine/Lusamine02.png" as cg_scene
    with dissolve

    narrator "Lusamine ties your wrists firmly to the headboard with silky black ropes, then blindfolds you with a soft cloth. The world goes dark."

    lusamine "You won't need your sight tonight. Only your obedience."

    narrator "She spends a long time teasing you. Her fingers trace lightly over your cock, followed by the warmth of her mouth. She brings you right to the edge again and again, only to stop completely each time."

    lusamine "Not yet."

    narrator "Her control is absolute. Every time your breathing becomes desperate and your hips twitch, she pulls back, leaving you throbbing and denied."

    lusamine "You look so pathetic like this... struggling not to beg."

    narrator "After what feels like an eternity of exquisite torture, she finally wraps her hand around your cock and strokes with firm, precise movements."

    lusamine "Now... Cum for me."

    show expression "images/cg/lusamine/Lusamine02a.png" as cg_scene
    with flash

    narrator "Her voice is low and commanding in your ear as she works you with ruthless efficiency. The combination of her hand and her whispered control pushes you over the edge instantly."

    narrator "You cum hard, groaning as she milks every drop from you."

    lusamine "Good boy."

    narrator "She doesn't stop stroking until you're completely spent and trembling."

    lusamine "You're getting used to this, aren't you?"

    mc "Is that... a problem?"

    lusamine "Not at all."

    narrator "You can hear the faint satisfaction in her voice."

    lusamine "It's exactly what I wanted."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lusamine"] += 1
    $ affection["lusamine"] = min(100, affection["lusamine"] + 5)
    $ advance_hint("lusamine")
    $ advance_slot(2)

    jump location_cafe


# ------------------------------------------------------------
# FIFTH ENCOUNTER
# ------------------------------------------------------------

label lusamine_fifth_encounter:

    scene bg plaza_day
    with fade

    narrator "One afternoon in the plaza, you unexpectedly run into Lusamine outside her usual environment. She's browsing a stall with the same composed elegance she carries everywhere."

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    mc "Didn't expect to see you here."

    lusamine "I do leave the cafe from time to time. Shocking, I know."

    mc "A little, yes."

    lusamine "Walk with me."

    narrator "It isn't a request. You fall into step beside her as she continues through the plaza, selecting items with precise decisions. For the first time, you see her interacting with the town without the barrier of the counter."

    mc "How long have you lived in this town?"

    lusamine "Long enough to understand exactly how it functions."

    mc "And how does it function?"

    lusamine "Through hierarchies. People like to pretend they don't exist, yet they obey them perfectly."

    mc "And where do you stand in that hierarchy?"

    narrator "Lusamine glances at you sideways, the corner of her mouth curving into something that might almost be a smile, cold and calculated."

    lusamine "Exactly where I choose to be."

    narrator "She stops walking and turns to face you fully."

    lusamine "Come to my house this afternoon. Not as my employee."

    mc "Then as what?"

    lusamine "As what you are."

    narrator "She leans in slightly, her voice low and possessive."

    lusamine "My favorite. For now."

    narrator "That afternoon, when you arrive at her house, Lusamine is more direct than ever. Her patience seems to have run out, she wants more, and she's no longer interested in taking things slowly."

    hide lusamine
    with dissolve

    show expression "images/cg/lusamine/Lusamine03.png" as cg_scene
    with dissolve

    narrator "Lusamine straps your wrists and ankles firmly to the sturdy chair in her room, leaving you completely helpless."

    lusamine "Much better. Now you can't ruin my pace."

    narrator "She straddles your lap and slowly lowers herself onto your cock, taking you inside her with deliberate control. Once fully seated, she begins riding you with slow, precise movements."

    narrator "She dictates every inch, every speed, every depth. Whenever you try to thrust up into her, she brings down a small riding crop against your chest with a sharp snap."

    lusamine "Stay still. This is for my pleasure, not yours."

    narrator "She rides you with elegant, merciless precision, grinding deep, then rising until only the tip remains inside her, again and again."

    lusamine "Look at you... so eager. So desperate."

    narrator "She brings herself to a first orgasm with a soft, controlled moan, her body trembling slightly on top of you. She doesn't stop. She continues riding through the aftershocks, chasing a second climax."

    lusamine "You're going to wait... until I've had my fill."

    narrator "After her second orgasm, her breathing finally grows heavier. She leans forward, gripping your shoulders as she rides you harder and faster."

    lusamine "Now... Cum for me."

    show expression "images/cg/lusamine/Lusamine03a.png" as cg_scene
    with flash

    narrator "The moment she gives permission, you thrust as much as the restraints allow and cum hard inside her. Lusamine watches your face with cold satisfaction as you empty yourself."

    lusamine "You're exactly what I needed in this town."

    narrator "She stays seated on you for a long moment, savoring the feeling, before whispering close to your ear."

    lusamine "Even if you don't fully understand it yet."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lusamine"] += 1
    $ affection["lusamine"] = min(100, affection["lusamine"] + 5)
    $ advance_hint("lusamine")
    $ advance_slot(2)

    jump location_plaza


# ------------------------------------------------------------
# SIXTH ENCOUNTER
# ------------------------------------------------------------

label lusamine_sixth_encounter:

    scene bg cafe
    with fade

    narrator "One morning you arrive at the cafe to find another employee covering the floor. Lusamine calls you to the small office in the back, a room you've never entered before."

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    lusamine "Close the door."

    narrator "You obey without hesitation."

    lusamine "There's an investor who wants to buy this location. He's made three generous offers. I've rejected all of them."

    mc "And now?"

    lusamine "He's coming in person this week to try again. I want you present during the meeting."

    mc "What do you need me to do?"

    lusamine "Nothing. Just be there. Sit beside me and stay silent."

    mc "That's it?"

    lusamine "That's enough. When people see that I have someone who stands with me without question, the balance of power shifts."

    narrator "Two days later the meeting takes place. The investor is arrogant and pushy, clearly used to getting what he wants. Lusamine dismantles him calmly, elegantly, and without ever raising her voice."

    narrator "You don't say a single word. But every time the man looks to you hoping for support, he finds only cold indifference."

    narrator "Once the investor leaves defeated, Lusamine turns to you with a faint look of satisfaction."

    lusamine "Good."

    mc "I didn't do anything."

    lusamine "Exactly. You did precisely what I asked of you."

    narrator "That night at her house, Lusamine is different. Not softer, but more present. As if a decision has been made."

    hide lusamine
    with dissolve

    show expression "images/cg/lusamine/Lusamine04.png" as cg_scene
    with dissolve

    narrator "Lusamine pushes you onto the bed and climbs on top of you in reverse cowgirl position. A sleek black collar is already fastened around your neck, connected to a matching leash in her hand."

    narrator "She lowers herself onto your cock with deliberate slowness, taking you deep inside her. Once fully seated, she begins riding you with powerful, possessive movements."

    lusamine "You look so good like this... completely under my control."

    narrator "She pulls firmly on the leash, forcing your head back as she bounces on your cock with increasing intensity. Every movement is calculated, dominant, and merciless."

    lusamine "Beg for it."

    mc "Please... Lusamine... let me cum..."

    lusamine "Pathetic. Louder."

    mc "Please! I'm begging you... please let me cum!"

    lusamine "Good boy."

    narrator "She yanks the leash harder, using it for leverage as she rides you faster and deeper, her hips slamming down with possessive force."

    lusamine "There are very few people I trust. That doesn't change easily..."

    narrator "Her breathing grows heavier, but her voice remains cold and commanding."

    lusamine "But you're getting closer to that line than most ever will."

    show expression "images/cg/lusamine/Lusamine04a.png" as cg_scene
    with flash

    narrator "She pulls the leash tight as she cums hard, her body trembling on top of you. The feeling of her clenching around your cock finally pushes you over the edge."

    narrator "With a desperate groan, you cum deep inside her as she continues riding you through both your orgasms."

    hide cg_scene
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lusamine"] += 1
    $ affection["lusamine"] = min(100, affection["lusamine"] + 5)
    $ advance_hint("lusamine")
    $ advance_slot(2)

    jump location_cafe


# ------------------------------------------------------------
# SEVENTH ENCOUNTER
# ------------------------------------------------------------

label lusamine_seventh_encounter:

    scene bg cafe
    with fade

    narrator "One night, Lusamine calls you to her house without any explanation. When you arrive, the table is elegantly set for two and the aroma of a carefully prepared meal fills the air. It's the first time you've seen her cook for someone else."

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    mc "What's all this?"

    lusamine "Dinner. Surely you've seen one before."

    mc "I didn't expect this from you."

    lusamine "Most people don't expect anything from me but distance. You shouldn't get used to this either."

    mc "It's a little late for that warning."

    narrator "Lusamine holds your gaze for a long moment. Something flickers across her face, something you can't quite name, but that you've never seen before."

    lusamine "Sit down."

    narrator "The dinner is surprisingly pleasant. Lusamine talks more than usual, not about business or control, but about small things. And she listens when you speak with that absolute, piercing attention that always feels both intimate and dangerous."

    lusamine "Do you know why I chose you from the very beginning?"

    mc "I had my suspicions."

    lusamine "Because everyone else in this town already had their place. You arrived with none. That made you... moldable."

    mc "And if I hadn't gone along with it?"

    lusamine "You would have. I knew it the first time you walked into my cafe."

    mc "Am I that predictable?"

    lusamine "No. You're one of the least predictable people I've met. That's precisely why it worked so well."

    narrator "When dinner ends, Lusamine stands gracefully and extends her hand toward you without a word. She doesn't need to explain."

    hide lusamine
    with dissolve

    show expression "images/cg/lusamine/Lusamine05.png" as cg_scene
    with dissolve

    narrator "Lusamine ties you spread-eagle to the bed using soft but unforgiving silk ropes, leaving you completely exposed and helpless."

    lusamine "Perfect. Exactly how I like you."

    narrator "She straddles your hips and slowly sinks down onto your cock, taking you inside her with deliberate control. Once fully seated, she begins riding you with slow, sensual movements."

    lusamine "You feel that? How deep I can take you... and how little you can do about it."

    narrator "She leans forward, her face hovering just above yours. Her voice becomes a low, commanding whisper as she rides you with exquisite precision."

    lusamine "Don't you dare cum yet. You finish when I decide."

    narrator "She brings you right to the edge again and again, slowing down or stopping completely every time she feels you getting close. Her control is absolute."

    lusamine "Good... Look at you, trembling beneath me. So desperate."

    narrator "After what feels like an eternity of exquisite torment, she finally increases her pace, riding you harder while still maintaining that elegant dominance."

    lusamine "Now... Cum for me. Fill me."

    show expression "images/cg/lusamine/Lusamine05a.png" as cg_scene
    with flash

    narrator "The moment she gives permission, you cum hard deep inside her. Lusamine watches your face with cold satisfaction as you throb and empty yourself."

    narrator "Even after you finish, she stays on top of you for a long time, gently stroking your hair with possessive affection."

    lusamine "You're mine now. Whether you fully realize it yet... or not."

    hide cg_scene
    with dissolve

    show expression get_char_sprite("lusamine", "default") as lusamine at center
    with dissolve

    lusamine "Tomorrow at eight at the cafe. Don't be late, pet."

    mc "I'm never late."

    lusamine "No. That's one of the things I like most about you."

    narrator "She says it while already turning away, already thinking about something else. But this time, almost without noticing, she's smiling."

    hide lusamine
    with dissolve

    if gallery_replay:
        $ gallery_replay = False
        jump return_to_gallery

    $ character_progress["lusamine"] += 1
    $ affection["lusamine"] = min(100, affection["lusamine"] + 5)
    $ advance_hint("lusamine")
    $ advance_slot(2)

    jump location_cafe
