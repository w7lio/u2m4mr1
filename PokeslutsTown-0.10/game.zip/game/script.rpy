# ============================================================
# POKETOWN — script.rpy
# Entry point of the game
# ============================================================

# ------------------------------------------------------------
# disclaimer screen
# ------------------------------------------------------------
screen disclaimer_screen():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1400
        ypadding 40
        xpadding 40
        background "#11111100"

        vbox:
            spacing 20
            xalign 0.5
            xsize 1400

            text "DISCLAIMER" size 45 bold True xalign 0.5 color "#ff0000" text_align 0.5
            text "This game is intended for adults only." size 22 xalign 0.5 color "#FFFFFF" text_align 0.5
            text "All characters depicted in romantic, suggestive, or explicit situations are fictional adults aged 18 years or older." size 22 xalign 0.5 color "#FFFFFF" text_align 0.5
            text "This game contains adult themes, sexual content, strong language, and mature humor." size 22 xalign 0.5 color "#FFFFFF" text_align 0.5
            text "By continuing, you confirm that you are legally allowed to view adult-oriented content in your country or region." size 22 xalign 0.5 color "#FFFFFF" text_align 0.5
            text "This game is an unofficial parody project created for entertainment purposes." size 22 xalign 0.5 color "#FFFFFF" text_align 0.5
            text "It is not affiliated with, endorsed by, sponsored by, or associated with any existing brands, companies, franchises, or rights holders." size 22 xalign 0.5 color "#FFFFFF" text_align 0.5
            text "All trademarks, names, and copyrights belong to their respective owners." size 22 xalign 0.5 color "#FFFFFF" text_align 0.5
            text "Press any key to continue." size 20 xalign 0.5 color "#888888"

    button:
        xpos 0
        ypos 0
        xsize 1920
        ysize 1080
        background "#00000000"
        action Return()


label splashscreen:
    scene black
    with fade

    call screen disclaimer_screen

    scene black
    with fade

    return
# ------------------------------------------------------------
# GAME ENTRY — Name input
# ------------------------------------------------------------
label start:

    $ player_name = renpy.input("What's your name?", length=20).strip()
    if player_name == "":
        $ player_name = "Trainer"
        

    jump intro
# ------------------------------------------------------------
# INTRO — Arrival at Heartwood Town
# ------------------------------------------------------------
label intro:

    scene black
    with fade

    narrator "The city never slept. Neither did you, not well, anyway."

    narrator "No job. No partner. No one who'd notice if you disappeared for a week."

    narrator "Then the letter arrived. Your grandfather's farm, sitting empty out in Heartwood. You'd ignored it for years. Too small, too quiet, too far from everything you thought mattered."

    narrator "Funny how quickly that changes when your bank account hits zero."

    narrator "You packed what fit in two bags and bought the cheapest ticket they had."

    narrator "The further the city shrank behind you, the lighter something in your chest felt."

    scene bg home_interior_day
    with fade

    narrator "Heartwood Town."

    narrator "The air hits you first, clean, warm, carrying something like cut grass and old wood. You stand at the door of the farmhouse and just breathe for a moment."

    narrator "It's small. Dusty. The furniture looks like it hasn't moved in a decade."

    narrator "But it's solid. More solid than anywhere you've lived in years."

    scene bg garden_day
    with fade

    narrator "Out back, the garden plots are still intact. The soil looks dark and ready, like it's been waiting."

    narrator "You crouch down and run your hand through it. Still fertile."

    narrator "You find an old tin on the kitchen shelf. Inside $50. Your grandfather's way of saying welcome, probably."

    scene bg home_interior_day
    with fade

    narrator "You came here out of options. But standing in the middle of this quiet, unassuming place..."

    narrator "You start to wonder why it took you this long."

    narrator "(Starting with the Lusamine route is recommended.)"

    $ money += 50
    $ current_day = 1
    $ current_slot = 0

    jump day_start

label return_to_gallery:
    jump expression "location_" + current_location
# ------------------------------------------------------------
# DAY START — Main daily loop
# ------------------------------------------------------------
label day_start:
    $ missions_generated_today = False
    $ reset_daily_gifts()
    $ tick_missions()
    $ generate_daily_missions()
    $ current_slot = 0
    jump time_slot

# ------------------------------------------------------------
# TIME SLOT — Controls the flow of each time slot
# ------------------------------------------------------------
label time_slot:

    if current_slot >= 5:
        jump end_of_day

    $ location_choice = renpy.call_screen("location_select_screen")
    $ play_location_music(location_choice)

    if location_choice == "plaza":
        jump location_plaza
    elif location_choice == "shopping_center":
        jump location_shopping_center
    elif location_choice == "greenhouse":
        jump location_greenhouse
    elif location_choice == "library":
        jump location_library
    elif location_choice == "gym":
        jump location_gym
    elif location_choice == "cafe":
        jump location_cafe
    elif location_choice == "beach":
        jump location_beach
    elif location_choice == "forest":
        jump location_forest
    elif location_choice == "studio":
        jump location_studio
    elif location_choice == "home_delia_leaf":
        jump location_home_delia_leaf
    elif location_choice == "home":
        jump location_home
    elif location_choice == "skip":
        jump end_of_day

# ------------------------------------------------------------
# END OF DAY
# ------------------------------------------------------------
label end_of_day:

    $ current_day += 1

    scene bg heartwood_map_night
    with fade

    narrator "The day comes to an end."
    narrator "Day [current_day] begins tomorrow."

    jump day_start

label after_load:
    $ migrate_save()
    return