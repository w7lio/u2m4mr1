# ============================================================
# POKETOWN — map_screen.rpy
# Interactive map of Heartwood Town
# ============================================================

screen location_select_screen():
    modal True

    if current_slot <= 2:
        add "images/backgrounds/heartwood_map_day.png"
    else:
        add "images/backgrounds/heartwood_map_night.png"

    # Beach
    button:
        xpos 278
        ypos 285
        xsize 100
        ysize 100
        action Return("beach")
        at glow_on_hover 
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/beach.png" zoom 0.4 xalign 0.5
            

    # Home
    button:
        xpos 665
        ypos 215
        xsize 100
        ysize 100
        action Return("home")
        at glow_on_hover 
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/farm.png" zoom 0.4 xalign 0.5

    # Apartments
    button:
        xpos 925
        ypos 210
        xsize 100
        ysize 100
        sensitive (current_slot <= 2)
        action Return("home_delia_leaf")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/apartment.png" zoom 0.4 xalign 0.5 
    if current_slot > 2:
        frame:
            xpos 925
            ypos 210
            xsize 100
            ysize 100
            background "#ff000000"
            add "images/ui/icons/blocked.png" zoom 0.4 xalign 0.5 yalign 0.5
            text "🔒" size 28 xalign 0.5 yalign 0.5

    # Greenhouse
    button:
        xpos 1285
        ypos 310
        xsize 100
        ysize 100
        sensitive (current_slot <= 2)
        action Return("greenhouse")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/greenhouse.png" zoom 0.4 xalign 0.5
    if current_slot > 2:
        frame:
            xpos 1285
            ypos 310
            xsize 100
            ysize 100
            background "#ff000000"
            add "images/ui/icons/blocked.png" zoom 0.4 xalign 0.5 yalign 0.5
            text "🔒" size 28 xalign 0.5 yalign 0.5

    # Library
    button:
        xpos 1545
        ypos 485
        xsize 100
        ysize 100
        action Return("library")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/library.png" zoom 0.4 xalign 0.5

    # Photo Studio
    button:
        xpos 1495
        ypos 750
        xsize 100
        ysize 100
        sensitive (current_slot <= 2)
        action If(
            character_progress["penny"] >= 4,
            true=Return("studio"),
            false=Notify("You don't know anyone here yet.")
        )
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/studio.png" zoom 0.4 xalign 0.5
    if current_slot > 2:
        frame:
            xpos 1495
            ypos 750
            xsize 100
            ysize 100
            background "#ff000000"
            add "images/ui/icons/blocked.png" zoom 0.4 xalign 0.5 yalign 0.5
            text "🔒" size 28 xalign 0.5 yalign 0.5

    # Plaza
    button:
        xpos 955
        ypos 805
        xsize 100
        ysize 100
        action Return("plaza")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/plaza.png" zoom 0.4 xalign 0.5

    # Forest
    button:
        xpos 1595
        ypos 135
        xsize 100
        ysize 100
        action Return("forest")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/forest.png" zoom 0.4 xalign 0.5

    # Mall
    button:
        xpos 355
        ypos 500
        xsize 100
        ysize 100
        action Return("shopping_center")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/mall.png" zoom 0.4 xalign 0.5

    # Gym
    button:
        xpos 455
        ypos 845
        xsize 100
        ysize 100
        sensitive (current_slot <= 2)
        action Return("gym")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/gym.png" zoom 0.4 xalign 0.5
    if current_slot > 2:
        frame:
            xpos 455
            ypos 845
            xsize 100
            ysize 100
            background "#ff000000"
            add "images/ui/icons/blocked.png" zoom 0.4 xalign 0.5 yalign 0.5
            text "🔒" size 28 xalign 0.5 yalign 0.5 

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40