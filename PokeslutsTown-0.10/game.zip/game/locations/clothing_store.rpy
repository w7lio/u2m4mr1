# ============================================================
# POKETOWN — locations/clothing_store.rpy
# ============================================================

label location_clothing_store:
    $ current_location = "clothing_store"
    scene bg clothing_store
    with fade

    $ cs_choice = renpy.call_screen("clothing_store_location_screen")

    if cs_choice == "browse":
        jump clothing_store_main
    elif cs_choice == "characters":
        jump clothing_store_characters
    elif cs_choice == "leave":
        jump location_shopping_center
    else:
        jump location_shopping_center


label clothing_store_browse:
    call screen clothing_store_screen
    jump location_clothing_store


label clothing_store_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="clothing_store")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="clothing_store")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_clothing_store
        elif interaction == "date":
            jump expression "date_" + char_choice
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_clothing_store
        else:
            jump location_clothing_store
    else:
        jump location_clothing_store


screen clothing_store_location_screen():
    modal True

    # Browse
    button:
        xpos 790
        ypos 295
        xsize 100
        ysize 100
        action Return("browse")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/cloth.png" zoom 0.4 xalign 0.5

    # Talk
    button:
        xpos 1000
        ypos 625
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5

    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40


# ============================================================
# CLOTHING STORE SCREENS
# ============================================================

screen clothing_store_screen():
    modal True
    add "images/ui/clothing.png" xalign 0.5 yalign 0 zoom .80 yoffset 195

    frame:
        xalign 0.5
        yalign 0.5
        xsize 560
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "👗 Clothing Store" size 26 bold True xalign 0.5 color "#FFD700" yoffset -18
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90"

            null height 5

            text "Select character" size 20 color "#252525" xalign 0.5 yoffset -13

            viewport:
                xalign 0.5
                xoffset 12
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 480
                ysize 360

                vbox:
                    spacing 15
                    xalign 0.5

                    $ chars = list(CLOTHING_CATALOG.keys())
                    $ rows  = (len(chars) + 2) // 3

                    for row in range(rows):
                        hbox:
                            spacing 15
                            xalign 0.5
                            for col in range(4):
                                $ idx = row * 4 + col
                                if idx < len(chars):
                                    $ cc = chars[idx]
                                    button:
                                        xsize 100
                                        ysize 120
                                        background "#00000000"
                                        hover_background "#FFD70022"
                                        action Return(("select_char", cc))
                                        vbox:
                                            xalign 0.5
                                            yalign 0.5
                                            spacing 4
                                            add ("images/ui/icons/" + cc + ".png") zoom 0.5 xalign 0.5
                                            text cc.capitalize() size 14 xalign 0.5 color "#FFD700"

            null height 5

            textbutton "← Back":
                xalign 0.5
                action Return(None)
                text_size 20
                text_color "#c0c0c0"


screen clothing_store_char_screen(char_id):
    modal True
    add "images/ui/cloth.png" xalign 0.5 yalign 0 zoom .80 yoffset 195

    frame:
        xalign 0.5
        yalign 0.5
        xsize 560
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text ("👗 " + char_id.capitalize() + "'s Outfits") size 24 bold True xalign 0.5 color "#FFD700" yoffset -18
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90" yoffset -17

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 510
                ysize 430

                vbox:
                    spacing 10

                    text "🛍️ Normal" size 20 bold True color "#CCCCCC"

                    for item in CLOTHING_CATALOG[char_id]:
                        if item["zone"] == "normal":
                            $ ci = item
                            $ already_have = ci["id"] in inventory_clothing_ids
                            frame:
                                xfill True
                                if already_have:
                                    background "#1A2E1A"
                                else:
                                    background "#222222"
                                padding (15, 10)
                                hbox:
                                    spacing 10
                                    text ci["icon"] size 26 yalign 0.5
                                    vbox:
                                        spacing 3
                                        xsize 230
                                        text ci["name"] size 18 bold True color "#FFFFFF"
                                        text ("$" + str(ci["price"])) size 16 color "#FFD700"
                                    if already_have:
                                        text "✅" size 24 yalign 0.5
                                    else:
                                        textbutton "Buy":
                                            yalign 0.5
                                            sensitive money >= ci["price"]
                                            action Function(buy_clothing, ci["id"], char_id)
                                            text_size 18
                                            if money >= ci["price"]:
                                                text_color "#90EE90"
                                            else:
                                                text_color "#555555"

                    null height 5

                    if clothing_vip_unlocked:
                        text "💎 VIP" size 20 bold True color "#FFD700"

                        for item in CLOTHING_CATALOG[char_id]:
                            if item["zone"] == "vip":
                                $ vi = item
                                $ vip_have = vi["id"] in inventory_clothing_ids
                                frame:
                                    xfill True
                                    if vip_have:
                                        background "#1A2E1A"
                                    else:
                                        background "#2A1A2E"
                                    padding (15, 10)
                                    hbox:
                                        spacing 10
                                        text vi["icon"] size 26 yalign 0.5
                                        vbox:
                                            spacing 3
                                            xsize 230
                                            text vi["name"] size 18 bold True color "#FFFFFF"
                                            text ("$" + str(vi["price"])) size 16 color "#FFD700"
                                        if vip_have:
                                            text "✅" size 24 yalign 0.5
                                        else:
                                            textbutton "Buy":
                                                yalign 0.5
                                                sensitive money >= vi["price"]
                                                action Function(buy_clothing, vi["id"], char_id)
                                                text_size 18
                                                if money >= vi["price"]:
                                                    text_color "#90EE90"
                                                else:
                                                    text_color "#555555"

                        null height 5
                        text "👑 Empress" size 20 bold True color "#FFD700"
                        frame:
                            xfill True
                            if empress_outfit_owned:
                                background "#2E2A1A"
                            else:
                                background "#2A1A1A"
                            padding (15, 10)
                            hbox:
                                spacing 10
                                text EMPRESS_OUTFIT["icon"] size 26 yalign 0.5
                                vbox:
                                    spacing 3
                                    xsize 230
                                    text EMPRESS_OUTFIT["name"] size 18 bold True color "#FFD700"
                                    text "Universal — works for everyone" size 14 color "#CCCCCC"
                                    text "No affection bonus" size 14 color "#888888"
                                    text ("$" + str(EMPRESS_OUTFIT["price"])) size 16 color "#FFD700"
                                if empress_outfit_owned:
                                    text "✅ Owned" size 18 color "#90EE90" yalign 0.5
                                else:
                                    textbutton "Buy":
                                        yalign 0.5
                                        sensitive money >= EMPRESS_OUTFIT["price"]
                                        action Function(buy_empress_outfit)
                                        text_size 18
                                        if money >= EMPRESS_OUTFIT["price"]:
                                            text_color "#90EE90"
                                        else:
                                            text_color "#555555"
                    else:
                        frame:
                            xfill True
                            background "#1A1A1A"
                            padding (15, 10)
                            text "💎 VIP zone locked — build your relationship with Elesa to unlock." size 18 color "#555555" xalign 0.5

            null height 5

            textbutton "← Back":
                xalign 0.5
                action Return(None)
                text_size 20
                text_color "#c0c0c0"
                yoffset -17


label clothing_store_main:

    $ store_action = renpy.call_screen("clothing_store_screen")

    if store_action is None:
        jump location_clothing_store

    if not isinstance(store_action, tuple):
        jump location_clothing_store

    $ action_type, action_value = store_action

    if action_type == "select_char":
        $ char_screen_result = renpy.call_screen("clothing_store_char_screen", char_id=action_value)
        jump clothing_store_main

    jump location_clothing_store
