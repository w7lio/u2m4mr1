# ============================================================
# POKETOWN — locations/general_store.rpy
# ============================================================

label location_general_store:
    $ current_location = "general_store"
    scene bg general_store
    with fade

    $ gs_choice = renpy.call_screen("general_store_screen")

    if gs_choice == "books":
        jump general_store_cookbooks
    elif gs_choice == "gifts":
        jump general_store_gifts
    elif gs_choice == "stat_books":
        jump general_store_stat_books
    elif gs_choice == "characters":
        jump general_store_characters
    elif gs_choice == "leave":
        jump location_shopping_center
    else:
        jump location_shopping_center


label general_store_gifts:
    call screen general_store_gifts_screen
    jump location_general_store


label general_store_cookbooks:
    call screen general_store_cookbook_screen
    jump location_general_store


label general_store_stat_books:
    call screen general_store_stat_books_screen
    jump location_general_store

label general_store_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="general_store")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="general_store")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_general_store
        elif interaction == "date":
            jump expression "date_" + char_choice
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_general_store
        else:
            jump location_general_store
    else:
        jump location_general_store

screen general_store_screen():
    modal True

    # Cookbooks
    button:
        xpos 600
        ypos 290
        xsize 100
        ysize 100
        action Return("books")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/book.png" zoom 0.4 xalign 0.5

    # Gifts
    button:
        xpos 1025
        ypos 305
        xsize 100
        ysize 100
        action Return("gifts")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/gift.png" zoom 0.4 xalign 0.5

    # Stat Books
    button:
        xpos 812
        ypos 550
        xsize 100
        ysize 100
        action Return("stat_books")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/book.png" zoom 0.4 xalign 0.5

    # Talk
    button:
        xpos 1510
        ypos 340
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5

    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40


# ============================================================
# STAT BOOKS SCREEN
# ============================================================

screen general_store_stat_books_screen():
    modal True
    add "images/ui/general1.png" xalign 0.5 yalign 0 zoom .80 yoffset 195
    

    frame:
        xalign 0.5
        yalign 0.5
        xsize 600
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "📖 Stat Books" size 26 bold True xalign 0.5 color "#FFD700"
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90"

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 550
                ysize 400

                vbox:
                    spacing 10

                    for book in STAT_BOOKS:
                        $ sb = book
                        frame:
                            xfill True
                            background "#22222200"
                            padding (15, 12)
                            hbox:
                                spacing 10
                                text sb["icon"] size 28 yalign 0.5
                                vbox:
                                    spacing 3
                                    xsize 280
                                    text sb["name"] size 18 bold True color "#FFFFFF"
                                    text sb["description"] size 14 color "#CCCCCC"
                                    text ("+" + str(sb["stat_gain"]) + " " + sb["stat"].capitalize()) size 16 color "#90EE90"
                                $ already_bought = sb["id"] in purchased_stat_books
                                vbox:
                                    spacing 6
                                    yalign 0.5
                                    text ("$" + str(sb["price"])) size 20 bold True color "#FFD700"
                                    if already_bought:
                                        text "✅ Owned" size 18 color "#90EE90"
                                    else:
                                        textbutton "Buy":
                                            sensitive money >= sb["price"]
                                            action Function(buy_stat_book, sb["id"])
                                            text_size 18
                                            if money >= sb["price"]:
                                                text_color "#90EE90"
                                            else:
                                                text_color "#555555"

            null height 5

            textbutton "← Back":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#888888"


# ============================================================
# GIFTS AND COOKBOOKS SCREENS — kept from original
# ============================================================

screen general_store_gifts_screen():
    modal True
    add "images/ui/general.png" xalign 0.5 yalign 0 zoom .80 yoffset 195

    frame:
        xalign 0.5
        yalign 0.5
        xsize 600
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🎁 Gifts" size 26 bold True xalign 0.5 color "#FFD700"
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90"

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 460
                ysize 400

                vbox:
                    spacing 10

                    for gift in GENERAL_GIFTS:
                        $ g = gift
                        frame:
                            xfill True
                            background "#22222200"
                            padding (15, 10)
                            hbox:
                                spacing 10
                                text g["icon"] size 28 yalign 0.5
                                vbox:
                                    spacing 3
                                    xsize 220
                                    text g["name"] size 20 bold True color "#FFFFFF"
                                    text ("❤️ +" + str(g["affection"])) size 16 color "#E74C3C"
                                vbox:
                                    spacing 6
                                    yalign 0.5
                                    text ("$" + str(g["price"])) size 20 bold True color "#FFD700"
                                    textbutton "Buy":
                                        sensitive money >= g["price"]
                                        action Function(buy_general_gift, g["id"])
                                        text_size 18
                                        if money >= g["price"]:
                                            text_color "#90EE90"
                                        else:
                                            text_color "#555555"

            null height 5

            textbutton "← Back":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#888888"


screen general_store_cookbook_screen():
    modal True
    add "images/ui/general1.png" xalign 0.5 yalign 0 zoom .80 yoffset 195

    frame:
        xalign 0.5
        yalign 0.5
        xsize 600
        ysize 700
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "📚 Cookbooks" size 26 bold True xalign 0.5 color "#FFD700" yoffset 22
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90" yoffset 22

            null height 5

            for book_id, book in COOKBOOKS.items():
                $ bk = book
                $ bid = book_id
                $ already_owned = all(r in unlocked_recipes for r in bk["recipes"])
                frame:
                    xfill True
                    if already_owned:
                        background "#1A2E1A"
                    else:
                        background "#22222200"
                    padding (15, 12)

                    vbox:
                        spacing 8

                        hbox:
                            spacing 10
                            text bk["icon"] size 28
                            vbox:
                                spacing 3
                                text bk["name"] size 22 bold True color "#FFFFFF"
                                text (str(len(bk["recipes"])) + " recipes included") size 16 color "#CCCCCC"

                        hbox:
                            spacing 20
                            text ("$" + str(bk["price"])) size 20 bold True color "#FFD700"
                            if already_owned:
                                text "✅ Already owned" size 18 color "#90EE90"
                            else:
                                textbutton "Buy":
                                    sensitive money >= bk["price"]
                                    action Function(buy_cookbook, bid)
                                    text_size 20
                                    if money >= bk["price"]:
                                        text_color "#90EE90"
                                    else:
                                        text_color "#555555"

            null height 5

            textbutton "← Back":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#888888"


init python:
    def buy_cookbook(book_id):
        import renpy
        book = renpy.store.COOKBOOKS.get(book_id)
        if not book:
            return
        if renpy.store.money < book["price"]:
            return
        renpy.store.money -= book["price"]
        unlock_cookbook(book_id)

    def buy_stat_book(book_id):
        import renpy
        book = None
        for b in renpy.store.STAT_BOOKS:
            if b["id"] == book_id:
                book = b
                break
        if book is None or renpy.store.money < book["price"]:
            return
        if book_id in renpy.store.purchased_stat_books:
            return
        renpy.store.money -= book["price"]
        renpy.store.purchased_stat_books.append(book_id)
        stat = book["stat"]
        gain = book["stat_gain"]
        if stat == "physique":
            renpy.store.stat_physique += gain
        elif stat == "charisma":
            renpy.store.stat_charisma += gain
        elif stat == "intelligence":
            renpy.store.stat_intelligence += gain
