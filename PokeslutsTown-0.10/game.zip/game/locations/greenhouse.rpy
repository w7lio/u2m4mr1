# ============================================================
# POKETOWN — locations/greenhouse.rpy
# ============================================================

label location_greenhouse:
    $ current_location = "greenhouse"
    scene bg greenhouse_day 
    with fade

    $ gh_choice = renpy.call_screen("greenhouse_screen")

    if gh_choice == "seeds":
        jump greenhouse_seeds
    elif gh_choice == "upgrades":
        jump greenhouse_upgrades
    elif gh_choice == "characters":
        jump greenhouse_characters
    elif gh_choice == "leave":
        jump time_slot
    else:
        jump time_slot


label greenhouse_seeds:
    call screen greenhouse_seed_shop
    jump location_greenhouse


label greenhouse_upgrades:
    call screen greenhouse_upgrade_shop
    jump location_greenhouse

label greenhouse_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="greenhouse")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="greenhouse")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_greenhouse
        elif interaction == "date":
            jump expression "date_" + char_choice
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_greenhouse
        else:
            jump location_greenhouse
    else:
        jump location_greenhouse


screen greenhouse_screen():
    modal True

    # Seeds
    button:
        xpos 320
        ypos 425
        xsize 100
        ysize 100
        action Return("seeds")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/seed.png" zoom 0.4 xalign 0.5

    # Upgrades
    button:
        xpos 120
        ypos 540
        xsize 100
        ysize 100
        action Return("upgrades")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/upgrades.png" zoom 0.4 xalign 0.5

    # Talk
    button:
        xpos 1360
        ypos 640
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5

    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40


init python:
    def buy_seed(seed_id):
        import renpy
        seed = None
        for tier in range(6):
            if tier in renpy.store.ERIKA_CATALOG:
                for s in renpy.store.ERIKA_CATALOG[tier]:
                    if s["id"] == seed_id:
                        seed = s
                        break
        if seed is None or renpy.store.money < seed["price"]:
            return
        renpy.store.money -= seed["price"]
        seed_item = {
            "id":       seed["id"] + "_seed",
            "name":     seed["name"],
            "icon":     seed["icon"],
            "quantity": 1,
        }
        found = False
        for item in renpy.store.inventory_seeds:
            if item["id"] == seed_item["id"]:
                item["quantity"] += 1
                found = True
                break
        if not found:
            renpy.store.inventory_seeds.append(seed_item)


screen greenhouse_seed_shop():
    modal True

    $ available_seeds = get_available_seeds()

    frame:
        xalign 0.5
        yalign 0.5
        xsize 500
        ysize 650
        background "#111111EE"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🌿 Erika's Seeds" size 26 bold True xalign 0.5 color "#FFD700"
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90"

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 460
                ysize 400

                vbox:
                    spacing 10

                    for seed in available_seeds:
                        $ cs = seed
                        frame:
                            xfill True
                            background "#222222"
                            padding (15, 10)

                            hbox:
                                spacing 10
                                text cs["icon"] size 28 yalign 0.5
                                vbox:
                                    spacing 3
                                    xsize 220
                                    text cs["name"] size 20 bold True color "#FFFFFF"
                                    text (str(cs["grow_days"]) + " days") size 16 color "#CCCCCC"
                                    text cs["rarity"].replace("_", " ").capitalize() size 14 color "#888888"
                                vbox:
                                    spacing 6
                                    yalign 0.5
                                    text ("$" + str(cs["price"])) size 20 bold True color "#FFD700"
                                    textbutton "Buy":
                                        sensitive money >= cs["price"]
                                        action Function(buy_seed, cs["id"])
                                        text_size 18
                                        if money >= cs["price"]:
                                            text_color "#90EE90"
                                        else:
                                            text_color "#555555"

            null height 5

            textbutton "← Back":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#888888"

screen greenhouse_upgrade_shop():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 500
        ysize 650
        background "#111111EE"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🌱 Garden Upgrades" size 26 bold True xalign 0.5 color "#FFD700"
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90"

            null height 5

            frame:
                xfill True
                background "#222222"
                padding (15, 10)
                vbox:
                    spacing 6
                    hbox:
                        spacing 10
                        text "⚡" size 28 yalign 0.5
                        vbox:
                            spacing 3
                            xsize 220
                            text "Growth Speed" size 20 bold True color "#FFFFFF"
                            text ("Level " + str(garden_speed_level) + "/4") size 16 color "#CCCCCC"
                            if garden_speed_level < 4:
                                text ("Next: -" + str([0,1,2,3,4][garden_speed_level+1]) + " days") size 14 color "#888888"
                            else:
                                text "Maxed!" size 14 color "#90EE90"
                        vbox:
                            spacing 6
                            yalign 0.5
                            if garden_speed_level < 4:
                                text ("$" + str(GARDEN_UPGRADE_COSTS["speed"][garden_speed_level+1])) size 20 bold True color "#FFD700"
                                textbutton "Upgrade":
                                    sensitive money >= GARDEN_UPGRADE_COSTS["speed"][garden_speed_level+1]
                                    action Function(upgrade_garden, "speed")
                                    text_size 18
                                    text_color "#90EE90"
                            else:
                                text "MAX" size 20 color "#555555"

            null height 5

            frame:
                xfill True
                background "#222222"
                padding (15, 10)
                vbox:
                    spacing 6
                    hbox:
                        spacing 10
                        text "🌾" size 28 yalign 0.5
                        vbox:
                            spacing 3
                            xsize 220
                            text "Harvest Yield" size 20 bold True color "#FFFFFF"
                            text ("Level " + str(garden_yield_level) + "/4") size 16 color "#CCCCCC"
                            if garden_yield_level < 4:
                                text (["→x1","50% x2","x2","50% x3","x3"][garden_yield_level+1]) size 14 color "#888888"
                            else:
                                text "Maxed!" size 14 color "#90EE90"
                        vbox:
                            spacing 6
                            yalign 0.5
                            if garden_yield_level < 4:
                                text ("$" + str(GARDEN_UPGRADE_COSTS["yield"][garden_yield_level+1])) size 20 bold True color "#FFD700"
                                textbutton "Upgrade":
                                    sensitive money >= GARDEN_UPGRADE_COSTS["yield"][garden_yield_level+1]
                                    action Function(upgrade_garden, "yield")
                                    text_size 18
                                    text_color "#90EE90"
                            else:
                                text "MAX" size 20 color "#555555"

            null height 10

            textbutton "← Back":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#888888"
