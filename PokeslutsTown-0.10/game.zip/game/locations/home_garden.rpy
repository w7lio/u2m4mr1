# ============================================================
# POKETOWN — locations/home_garden.rpy
# ============================================================

label location_home:
    $ current_location = "home"
    if current_slot <= 2:
        scene bg home_interior_day 
    else:
        scene bg home_interior_night
    with fade

    $ home_choice = renpy.call_screen("home_screen")

    if home_choice == "garden":
        jump home_garden
    elif home_choice == "kitchen":
        jump home_kitchen
    elif home_choice == "characters":
        jump home_characters
    elif home_choice == "sleep":
        jump end_of_day
    else:
        jump time_slot


# ============================================================
# HOME SCREEN — interactive map
# ============================================================

screen home_screen():
    modal True

    # Garden
    button:
        xpos 400
        ypos 375
        xsize 100
        ysize 100
        action Return("garden")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/garden.png" zoom 0.4 xalign 0.5

    # Kitchen
    button:
        xpos 1200
        ypos 325
        xsize 100
        ysize 100
        action Return("kitchen")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/cook.png" zoom 0.4 xalign 0.5

    button:
        xpos 550
        ypos 750
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5

    # Sleep — skip to next day
    button:
        xpos 1500
        ypos 595
        xsize 100
        ysize 100
        action Return("sleep")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/sleep.png" zoom 0.4 xalign 0.5

    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40

# ============================================================
# KITCHEN
# ============================================================

label home_kitchen:
    $ current_location = "home_kitchen"

    if character_progress["delia"] < 2:
        narrator "You don't know how to cook anything yet."
        narrator "Maybe someone could teach you."
        jump location_home

    if current_slot <= 2:
        scene bg kitchen_day
    else:
        scene bg kitchen_night
    with fade
    jump minigame_cooking_start

label home_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="home")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="home")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_home
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_home
        else:
            jump location_home
    else:
        jump location_home


# ============================================================
# GARDEN SCREEN
# ============================================================

screen garden_screen():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1500
        ypadding 45
        xpadding 45
        background "#11111100"

        vbox:
            spacing 30
            xalign 0.5

            hbox:
                spacing 30
                xalign 0.5
                text "🌱 Garden" size 28 bold True color "#FFD700" outlines [(2, "#000000", 0, 0)]
                text ("Day " + str(current_day)) size 28 color "#ffffff" outlines [(2, "#000000", 0, 0)]

            null height 8

            $ plots_per_row = 3
            $ total_plots   = garden_slots

            for row in range((total_plots + plots_per_row - 1) // plots_per_row):
                hbox:
                    spacing 25
                    xalign 0.5
                    for col in range(plots_per_row):
                        $ plot_idx = row * plots_per_row + col
                        if plot_idx < total_plots:
                            $ plot = garden_plots[plot_idx]
                            frame:
                                xsize 350
                                ysize 180
                                background "#1A2E1A"
                                padding (22, 15)

                                if plot is None:
                                    vbox:
                                        spacing 12
                                        xalign 0.5
                                        yalign 0.5
                                        text "🟫" size 30 xalign 0.5
                                        text "Empty" size 18 color "#555555" xalign 0.5
                                        textbutton "Plant seed":
                                            xalign 0.5
                                            action [
                                                Hide("garden_screen"),
                                                Return(("plant", plot_idx))
                                            ]
                                            text_size 16
                                            text_color "#90EE90"
                                else:
                                    $ days_left = max(0, plot["ready_day"] - current_day)
                                    $ is_ready  = days_left <= 0

                                    vbox:
                                        spacing 10
                                        xalign 0.5

                                        hbox:
                                            spacing 12
                                            xalign 0.5
                                            text plot["icon"] size 28
                                            text plot["name"] size 18 bold True color "#FFFFFF"

                                        if is_ready:
                                            text "✅ Ready to harvest!" size 16 color "#90EE90" xalign 0.5
                                            textbutton "Harvest":
                                                xalign 0.5
                                                action [
                                                    Hide("garden_screen"),
                                                    Return(("harvest", plot_idx))
                                                ]
                                                text_size 16
                                                text_color "#FFD700"
                                        else:
                                            text ("⏳ " + str(days_left) + " day(s) left") size 16 color "#FFD700" xalign 0.5

            null height 15

            textbutton "← Leave garden":
                xalign 0.5
                action Return(("leave", -1))
                text_size 20
                text_color "#ffffff"
                text_outlines [(2, "#000000", 0, 0)]


# ============================================================
# GARDEN LOGIC
# ============================================================

label home_garden:
    $ current_location = "home_garden"

    if current_slot <= 2:
        scene bg garden_day 
    else:
        scene bg garden_night 
    with fade

    narrator "Your garden."

    $ garden_action = renpy.call_screen("garden_screen")
    $ action_type, plot_idx = garden_action

    if action_type == "leave":
        jump location_home

    elif action_type == "harvest":
        $ plot = garden_plots[plot_idx]
        python:
            qty = get_harvest_quantity()
            harvested = {
                "id":       plot["ingredient_id"],
                "name":     plot["name"],
                "icon":     plot["icon"],
                "quantity": qty,
            }
            found = False
            for item in inventory_food:
                if item["id"] == harvested["id"]:
                    item["quantity"] += qty
                    found = True
                    break
            if not found:
                inventory_food.append(harvested)
            garden_plots[plot_idx] = None

        "[plot['icon']] [plot['name']] x[qty] harvested! Added to your inventory."
        jump home_garden

    elif action_type == "plant":
        jump garden_plant_menu


label garden_plant_menu:

    $ garden_plot_target = plot_idx
    call screen garden_seed_select
    jump home_garden


screen garden_seed_select():
    modal True

    frame:
        xalign 0.5
        yalign 0.5
        xsize 450
        ysize 550
        background "#111111EE"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🌱 Choose a seed" size 24 bold True xalign 0.5 color "#FFD700"

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 400
                ysize 380

                vbox:
                    spacing 10

                    if len(inventory_seeds) == 0:
                        text "No seeds available." size 20 color "#888888" xalign 0.5
                    else:
                        for seed in inventory_seeds:
                            if seed["quantity"] > 0:
                                frame:
                                    xfill True
                                    background "#222222"
                                    padding (15, 10)
                                    hbox:
                                        spacing 10
                                        text seed["icon"] size 28 yalign 0.5
                                        vbox:
                                            spacing 3
                                            xsize 220
                                            text seed["name"] size 20 bold True color "#FFFFFF"
                                            text ("x" + str(seed["quantity"])) size 16 color "#FFD700"
                                        textbutton "Plant":
                                            xalign 1.0
                                            yalign 0.5
                                            action [
                                                Function(plant_seed, seed),
                                                Return()
                                            ]
                                            text_size 18
                                            text_color "#90EE90"

            null height 5

            textbutton "← Cancel":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#888888"


init python:
    def plant_seed(seed):
        import renpy
        ing_id  = seed["id"].replace("_seed", "")
        ing     = renpy.store.INGREDIENTS.get(ing_id)
        if not ing:
            return

        new_plot = {
            "ingredient_id": ing_id,
            "name":          seed["name"].replace(" Seed", ""),
            "icon":          seed["icon"],
            "planted_day":   renpy.store.current_day,
            "ready_day": renpy.store.current_day + get_grow_days(ing["grow_days"]),
            "grow_days":     ing["grow_days"],
        }

        idx = renpy.store.garden_plot_target
        plots = list(renpy.store.garden_plots)
        plots[idx] = new_plot
        renpy.store.garden_plots = plots

        for item in renpy.store.inventory_seeds:
            if item["id"] == seed["id"]:
                item["quantity"] -= 1
                if item["quantity"] <= 0:
                    renpy.store.inventory_seeds.remove(item)
                break
