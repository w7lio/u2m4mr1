# ============================================================
# POKETOWN — locations/shopping_center.rpy
# ============================================================

label location_shopping_center:
    $ current_location = "shopping_center"
    if current_slot <= 2:
        scene bg shopping_center_day
    else:
        scene bg shopping_center_night
    with fade

    $ shop_choice = renpy.call_screen("shopping_center_screen")

    if shop_choice == "clothing":
        jump shop_clothing
    elif shop_choice == "general":
        jump shop_general
    elif shop_choice == "food":
        jump shop_food
    elif shop_choice == "cafe":
        jump location_cafe
    elif shop_choice == "characters":
        jump shopping_characters
    elif shop_choice == "leave":
        jump time_slot
    else:
        jump time_slot


label shop_clothing:
    $ current_location = "shopping_center"
    jump location_clothing_store

label shop_general:
    $ current_location = "shopping_center"
    jump location_general_store


label shop_food:
    $ current_location = "shopping_center"
    jump location_food_store


label shopping_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="shopping_center")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="shopping_center")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_shopping_center
        elif interaction == "date":
            jump expression "date_" + char_choice
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_shopping_center
        else:
            jump location_shopping_center
    else:
        jump location_shopping_center


screen shopping_center_screen():
    modal True

    # Cafe
    button:
        xpos 300
        ypos 620
        xsize 100
        ysize 100
        action Return("cafe")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/coffe.png" zoom 0.4 xalign 0.5

    # Clothing Store
    button:
        xpos 750
        ypos 620
        xsize 100
        ysize 100
        action Return("clothing")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/cloth.png" zoom 0.4 xalign 0.5

    # Food Store
    button:
        xpos 1180
        ypos 620
        xsize 100
        ysize 100
        action Return("food")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/apple.png" zoom 0.4 xalign 0.5

    # General Store
    button:
        xpos 1600
        ypos 620
        xsize 100
        ysize 100
        action Return("general")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/store.png" zoom 0.4 xalign 0.5

    # Talk to someone
    button:
        xpos 980
        ypos 950
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5

    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40
