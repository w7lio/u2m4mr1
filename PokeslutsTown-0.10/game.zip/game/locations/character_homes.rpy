# ============================================================
# POKETOWN — locations/character_homes.rpy
# ============================================================

label location_home_delia_leaf:
    $ current_location = "home_delia_leaf"
    scene bg delia_home

    $ home_dl_choice = renpy.call_screen("delia_home_screen")

    if home_dl_choice == "living":
        jump location_delia_home_living
    elif home_dl_choice == "kitchen":
        jump location_delia_home_kitchen
    elif home_dl_choice == "leave":
        jump time_slot
    else:
        jump time_slot


label location_delia_home_living:
    $ char_choice = renpy.call_screen("character_select_screen", location="home_delia_leaf")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="home_delia_leaf")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_home_delia_leaf
        elif interaction == "date":
            jump expression "date_" + char_choice
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_home_delia_leaf
        else:
            jump location_home_delia_leaf
    else:
        jump location_home_delia_leaf


label location_delia_home_kitchen:
    narrator "The kitchen. Delia might be cooking something."
    $ char_choice = renpy.call_screen("character_select_screen", location="home_delia_leaf")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="home_delia_leaf")
        if interaction == "talk":
            $ current_slot += 1
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ current_slot += 1
            jump location_home_delia_leaf
        else:
            jump location_home_delia_leaf
    else:
        jump location_home_delia_leaf


screen delia_home_screen():
    modal True

    # Living room
    button:
        xpos 960
        ypos 590
        xsize 100
        ysize 100
        action Return("living")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5


    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40
