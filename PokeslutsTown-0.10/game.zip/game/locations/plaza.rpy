# ============================================================
# POKETOWN — locations/plaza.rpy
# ============================================================

label location_plaza:
    $ current_location = "plaza"
    if current_slot <= 2:
        scene bg plaza_day
    else:
        scene bg plaza_night
    with fade

    $ plaza_choice = renpy.call_screen("plaza_screen")

    if plaza_choice == "characters":
        jump plaza_characters
    elif plaza_choice == "missions":
        jump plaza_bulletin_board
    elif plaza_choice == "leave":
        jump time_slot
    else:
        jump time_slot


label plaza_bulletin_board:
    call screen bulletin_board_screen
    jump location_plaza


label plaza_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="plaza")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="plaza")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_plaza
        elif interaction == "date":
            jump expression "date_" + char_choice
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_plaza
        else:
            jump location_plaza
    else:
        jump location_plaza


screen plaza_screen():
    modal True

    # Talk to someone
    button:
        xpos 960
        ypos 455
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5


    # Missions
    button:
        xpos 1525
        ypos 475
        xsize 100
        ysize 100
        action Return("missions")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/board.png" zoom 0.4 xalign 0.5

    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40
