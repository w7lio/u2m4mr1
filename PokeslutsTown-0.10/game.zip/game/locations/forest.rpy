# ============================================================
# POKETOWN — locations/forest.rpy
# ============================================================

label location_forest:
    $ current_location = "forest"
    if current_slot <= 2:
        scene bg forest_day
    else:
        scene bg forest_night
    with fade

    $ forest_choice = renpy.call_screen("forest_screen")

    if forest_choice == "explore":
        jump forest_explore
    elif forest_choice == "characters":
        jump forest_characters
    elif forest_choice == "leave":
        jump time_slot
    else:
        jump time_slot


label forest_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="forest")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="forest")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_forest
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_forest
        else:
            jump location_forest
    else:
        jump location_forest


label forest_explore:
    $ encountered_poke = get_random_pokemon()

    if encountered_poke is None:
        narrator "The forest is quiet. There are no more Pokemon to find here."
        narrator "You have caught them all."
        jump time_slot

    $ poke_data  = POKEMON_DATA[encountered_poke]
    $ poke_state = pokemon_state[encountered_poke]
    $ event      = get_current_event(encountered_poke)

    if event is None:
        narrator "The forest is quiet today."
        jump time_slot

    if event["type"] == "free":
        jump forest_event_free
    elif event["type"] == "stat":
        jump forest_event_stat
    elif event["type"] == "choice":
        jump forest_event_choice
    elif event["type"] == "food":
        jump forest_event_food
    elif event["type"] == "capture":
        jump forest_event_capture


label forest_event_free:
    narrator "You observe quietly. Something passes between you."
    call expression event["narrative_label"] from _call_expression
    $ advance_pokemon_event(encountered_poke)
    $ trust = pokemon_state[encountered_poke]["trust"]
    "Trust with [poke_data['name']] increased! ([trust]/100)"
    $ advance_slot(2)
    jump time_slot


label forest_event_stat:
    $ req       = event["requirement"]
    $ stat_name = req["stat"]
    $ stat_val  = get_stat_value(stat_name)
    $ req_val   = req["value"]

    if stat_val >= req_val:
        call expression event["narrative_label"] from _call_expression_1
        narrator "Your experience shows. The encounter goes well."
        $ advance_pokemon_event(encountered_poke)
        $ trust = pokemon_state[encountered_poke]["trust"]
        "Trust with [poke_data['name']] increased! ([trust]/100)"
        $ advance_slot(2)
    else:
        $ fail_text = event.get("fail_text", "The encounter doesn't go well.")
        "[fail_text]"
        "You need [stat_name.capitalize()] 15 or higher for this encounter."
        $ advance_slot(2)
    jump time_slot


label forest_event_choice:
    $ choices = event["choices"]
    $ mg_fail_text  = ""
    $ choice_result = None

    call expression event["narrative_label"] from _call_expression_2

    call screen forest_choice_screen

    if choice_result is None:
        jump time_slot

    if choice_result:
        call expression event.get("narrative_label_post", "forest_choice_no_post") from _call_expression_3
        $ advance_pokemon_event(encountered_poke)
        $ trust = pokemon_state[encountered_poke]["trust"]
        "Trust with [poke_data['name']] increased! ([trust]/100)"
        $ advance_slot(2)
    else:
        narrator "The moment is lost. Try again next time."
        $ advance_slot(2)
    jump time_slot


label forest_event_food:
    $ req     = event["requirement"]
    $ food_id = req["food_id"]

    if has_food_item(food_id):
        call expression event["narrative_label"] from _call_expression_4
        $ consume_food_item(food_id)
        $ advance_pokemon_event(encountered_poke)
        $ trust = pokemon_state[encountered_poke]["trust"]
        "Trust with [poke_data['name']] increased! ([trust]/100)"
        $ advance_slot(2)
    else:
        $ fail_text = event.get("fail_text", "You don't have what they need.")
        "[fail_text]"
        "You need [req['food_name']] in your inventory."
        $ advance_slot(2)
    jump time_slot


label forest_event_capture:
    narrator "The moment has come. [poke_data['name']] is ready to be caught."
    narrator "You reach for a Pokeball."

    python:
        import random
        _divisor     = 3 if capture_difficulty == "easy" else 1
        mg_cap_total = max(5, random.randint(16, 20) // _divisor)
        mg_cap_balls     = generate_pokeballs(mg_cap_total)
        mg_cap_clicked   = []
        mg_cap_time_left = 8
        mg_cap_running   = True
        mg_cap_result    = False

    $ capture_success = renpy.call_screen("minigame_capture_screen")

    if capture_success:
        $ capture_pokemon(encountered_poke)
        $ advance_pokemon_event(encountered_poke)
        "[poke_data['icon']] [poke_data['name']] was caught!"
        "Added to your Pokedex."
        call expression event["narrative_label"] from _call_expression_5
        $ advance_slot(2)
    else:
        narrator "The Pokeball missed. [poke_data['name']] slipped away."
        narrator "You can try again next time."
        $ advance_slot(2)
    jump time_slot


screen forest_screen():
    modal True

    button:
        xpos 1170
        ypos 365
        xsize 100
        ysize 100
        action Return("explore")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/explore.png" zoom 0.4 xalign 0.5

    button:
        xpos 270
        ypos 395
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5
    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40
