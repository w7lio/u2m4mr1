# ============================================================
# POKETOWN — locations/food_store.rpy
# ============================================================

label location_food_store:
    $ current_location = "food_store"
    scene bg food_store
    with fade

    $ fs_choice = renpy.call_screen("food_store_screen")

    if fs_choice == "produce":
        jump food_store_produce
    elif fs_choice == "meats":
        jump food_store_meats
    elif fs_choice == "characters":
        jump food_store_characters
    elif fs_choice == "leave":
        jump location_shopping_center
    else:
        jump location_shopping_center


label food_store_produce:
    call screen food_store_produce_screen
    jump location_food_store


label food_store_meats:
    call screen food_store_meats_screen
    jump location_food_store


label food_store_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="food_store")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="food_store")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_food_store
        elif interaction == "date":
            jump expression "date_" + char_choice
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_food_store
        else:
            jump location_food_store
    else:
        jump location_food_store


screen food_store_screen():
    modal True

    # Fruits & Vegetables
    button:
        xpos 680
        ypos 450
        xsize 100
        ysize 100
        action Return("produce")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/apple.png" zoom 0.4 xalign 0.5

    # Meats
    button:
        xpos 190
        ypos 400
        xsize 100
        ysize 100
        action Return("meats")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/meat.png" zoom 0.4 xalign 0.5

    # Talk
    button:
        xpos 1510
        ypos 340
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5

    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40


# ============================================================
# SHOP SCREENS — kept from original
# ============================================================

screen food_store_produce_screen():
    modal True
    add "images/ui/food.png" xalign 0.5 yalign 0 zoom .80 yoffset 195

    frame:
        xalign 0.5
        yalign 0.5
        xsize 500
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🍎 Fruits & Vegetables" size 24 bold True xalign 0.5 color "#FFD700" yoffset -12
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90" outlines [(2, "#000000", 0, 0)] yoffset 12

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 460
                ysize 400

                vbox:
                    spacing 10

                    for item in FOOD_STORE_CATALOG["always"]:
                        frame:
                            xfill True
                            background "#22222200"
                            padding (15, 10)
                            hbox:
                                spacing 10
                                text item["icon"] size 28 yalign 0.5
                                vbox:
                                    spacing 3
                                    xsize 240
                                    text item["name"] size 20 bold True color "#FFFFFF"
                                    text item["rarity"].replace("_", " ").capitalize() size 14 color "#888888"
                                vbox:
                                    spacing 6
                                    xalign 1.0
                                    yalign 0.5
                                    text ("$" + str(item["price"])) size 20 bold True color "#FFD700" xalign 1.0
                                    textbutton "Buy":
                                        xalign 1.0
                                        sensitive money >= item["price"]
                                        action Function(buy_food_item, item)
                                        text_size 18
                                        if money >= item["price"]:
                                            text_color "#90EE90"
                                        else:
                                            text_color "#555555"

                    if food_store_rare_unlocked:
                        for item in FOOD_STORE_CATALOG["after_event"]:
                            frame:
                                xfill True
                                background "#2A1F2A"
                                padding (15, 10)
                                hbox:
                                    spacing 10
                                    text item["icon"] size 28 yalign 0.5
                                    vbox:
                                        spacing 3
                                        xsize 240
                                        text item["name"] size 20 bold True color "#FFFFFF"
                                        text item["rarity"].replace("_", " ").capitalize() size 14 color "#E74C3C"
                                    vbox:
                                        spacing 6
                                        xalign 1.0
                                        yalign 0.5
                                        text ("$" + str(item["price"])) size 20 bold True color "#FFD700" xalign 1.0
                                        textbutton "Buy":
                                            xalign 1.0
                                            sensitive money >= item["price"]
                                            action Function(buy_food_item, item)
                                            text_size 18
                                            if money >= item["price"]:
                                                text_color "#90EE90"
                                            else:
                                                text_color "#555555"

            null height 5

            textbutton "← Back":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#000000"
                yoffset -5


screen food_store_meats_screen():
    modal True
    add "images/ui/food.png" xalign 0.5 yalign 0 zoom .80 yoffset 195

    frame:
        xalign 0.5
        yalign 0.5
        xsize 500
        ysize 650
        background "#11111100"
        padding (20, 20)

        vbox:
            spacing 15
            xalign 0.5

            text "🥩 Meats" size 24 bold True xalign 0.5 color "#FFD700" yoffset -12
            text ("💰 $" + str(money)) size 20 xalign 0.5 color "#90EE90" outlines [(2, "#000000", 0, 0)] yoffset 12

            null height 5

            viewport:
                scrollbars "vertical"
                mousewheel True
                draggable True
                xsize 460
                ysize 400

                vbox:
                    spacing 10

                    for item in FOOD_STORE_CATALOG["meats"]:
                        frame:
                            xfill True
                            background "#22222200"
                            padding (15, 10)
                            hbox:
                                spacing 10
                                text item["icon"] size 28 yalign 0.5
                                vbox:
                                    spacing 3
                                    xsize 240
                                    text item["name"] size 20 bold True color "#FFFFFF"
                                    text item["rarity"].replace("_", " ").capitalize() size 14 color "#888888"
                                vbox:
                                    spacing 6
                                    xalign 1.0
                                    yalign 0.5
                                    text ("$" + str(item["price"])) size 20 bold True color "#FFD700" xalign 1.0
                                    textbutton "Buy":
                                        xalign 1.0
                                        sensitive money >= item["price"]
                                        action Function(buy_food_item, item)
                                        text_size 18
                                        if money >= item["price"]:
                                            text_color "#90EE90"
                                        else:
                                            text_color "#555555"

            null height 5

            textbutton "← Back":
                xalign 0.5
                action Return()
                text_size 20
                text_color "#000000"
                yoffset -5


init python:
    def buy_food_item(item):
        import renpy
        if renpy.store.money < item["price"]:
            return
        renpy.store.money -= item["price"]
        food_item = {
            "id":       item["id"],
            "name":     item["name"],
            "icon":     item["icon"],
            "quantity": 1,
        }
        found = False
        for f in renpy.store.inventory_food:
            if f["id"] == food_item["id"]:
                f["quantity"] += 1
                found = True
                break
        if not found:
            renpy.store.inventory_food.append(food_item)
