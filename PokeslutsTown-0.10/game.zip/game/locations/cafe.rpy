# ============================================================
# POKETOWN — locations/cafe.rpy
# ============================================================

label location_cafe:
    $ current_location = "cafe"
    scene cafe
    with fade

    $ cafe_choice = renpy.call_screen("cafe_screen")

    if cafe_choice == "work":
        jump cafe_work
    elif cafe_choice == "characters":
        jump cafe_characters
    elif cafe_choice == "leave":
        jump location_shopping_center
    else:
        jump time_slot


label cafe_work:
    jump minigame_charisma_start


label cafe_characters:
    $ char_choice = renpy.call_screen("character_select_screen", location="cafe")
    if char_choice and isinstance(char_choice, str):
        $ interaction = renpy.call_screen("character_interaction_menu", char_id=char_choice, location="cafe")
        if interaction == "talk":
            jump expression "interact_" + char_choice
        elif interaction == "gift":
            $ gift_result = renpy.call_screen("gift_screen", char_id=char_choice)
            if gift_result and isinstance(gift_result, tuple):
                $ gift_type, gift_id = gift_result
                $ success, result = give_gift(char_choice, gift_id, gift_type)
                if success:
                    $ gift_message = char_choice.capitalize() + " appreciated the gift! ❤️ +" + str(result)
                    "[gift_message]"
                $ advance_slot()
            jump location_cafe
        elif interaction == "date":
            jump expression "date_" + char_choice
        elif interaction == "outfit":
            call screen skin_selector(char_id=char_choice)
            jump location_cafe
        else:
            jump location_cafe
    else:
        jump location_cafe


screen cafe_screen():
    modal True

    # Work
    button:
        xpos 590
        ypos 395
        xsize 100
        ysize 100
        action If(
            character_progress["lusamine"] >= 2,
            true=Return("work"),
            false=Notify("You don't work here yet.")
        )
        at glow_on_hover        
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/coffe.png" zoom 0.4 xalign 0.5

    # Talk
    button:
        xpos 1580
        ypos 350
        xsize 100
        ysize 100
        action Return("characters")
        at glow_on_hover
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 4
            add "images/ui/icons/interact.png" zoom 0.4 xalign 0.5
    frame:
        xalign 1.0
        yalign 1.0
        xpadding 20
        ypadding 15
        background "#00000000"
        imagebutton:
            idle "images/ui/icons/return.png"
            at glow_on_hover 
            action Return("leave")

    # HUD 
    frame:
        xalign 0.0
        yalign 0.0
        xpadding 20
        ypadding 25
        background "images/ui/bar.png"
        hbox:
            spacing 20
            text ("📅 Day " + str(current_day) + " — " + get_day_name()) size 22 color "#FFFFFF"
            text slot_names[current_slot] size 22 color "#FFD700"
            text ("💰 $" + str(money)) size 22 color "#90EE90"
            text ("⏳ " + str(5 - current_slot) + " slots left") size 22 color "#CCCCCC"

    frame:
        xalign 0.0
        yalign 1.0
        xpadding 20
        ypadding 20
        background "#00000000"

        textbutton "📱":
            action Show("phone_screen")
            text_size 40
